# Source Generated with Decompyle++
# File: R_07.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    if vars[706] and vars[1001]:
        stage.loadBg(2, 8)
        stage.jumpScene(17)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            119,
            34,
            54,
            1],
        [
            126,
            50,
            54,
            3]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.setEventName('편지')
    stage.delay(3)
    stage.setStageName('푸양 여포 저택')
    stage.delay(3)
    stage.unit(119).setAction(3)
    stage.say('&119\n판사님, 당신의 계획은 정말 기발합니다.\n&126\n사소한 계획들, 별로 언급할 가치도 없고,\n주군 무술 실력은 세상에서 정말 독보적입니다.')
    stage.unit(119).setAction(0)
    stage.say('&119\n앞으로 우리는 무엇을 해야 할까요?\n조조 전투에서 졌다고 그냥 넘기지 않을 거야.\n&126\n주군, 나도 같은 생각이야.')
    stage.unit(126).setAction(0, 1)
    stage.say('&126\n조조 곧 다시 등장할 .......\n&119\n흠...... 우린 부주의할 수 없어.')
    stage.unit(126).setAction(0, 3)
    stage.delay(3)
    stage.unit(126).move(48, 54, 3)
    stage.say('&126\n주군, 이렇게 하는 게 어때?\n그래서 .......\n&119\n좋아, .......')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    model.unitJoin(18, 0, 0)
    if vars[1013]:
        gvars[0] = 18
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene2():
    stage.bgSound(-1)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1],
        [
            16,
            38,
            46,
            1],
        [
            20,
            60,
            52,
            3],
        [
            22,
            60,
            46,
            3],
        [
            21,
            60,
            40,
            3]])
    stage.draw()
    stage.delay(3)
    stage.setStageName('조조군의 주영지인 푸양 외곽')
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('&0\n젠장! 여포 아이 정말 대단해!')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n여포 정말 강력한 상대입니다!')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n하지만 이 때문에 반격을 포기할 수는 없습니다.')
    stage.unit(21).setAction(0, 2)
    stage.say('&21\n네, .......')
    stage.showUnit(181, 49, 16, 3)
    stage.say('&181\n보고해!')
    stage.unit(0).setAction(0)
    stage.unit(22).setAction(0, 3)
    stage.unit(20).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.unit(181).move(49, 52, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 푸양에 사는 한 남자가 당신과 면담을 요청했습니다.')
    model.setFace(2)
    stage.unit(0).setAction(2)
    stage.say('&0\n군사 회의가 진행 중이니 나중에 이야기할 수 있어.\n&181\n그는 여포 문제에 대한 ......이라고 말했다.')
    stage.bgSound(12)
    stage.delay(7)
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n뭐라고? …… 좋아, 데려와.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.showUnit(204, 49, 16, 2)
    stage.say('&204\n무례하게 굴어서 죄송합니다.')
    stage.unit(204).move(49, 52, 2)
    stage.delay(3)
    stage.unit(204).setAction(11)
    stage.say('&0\n여포 일 때문에 왔다고 들었어.\n&204\n네, 여기 제 주인님께서 보내신 편지가 있습니다.\n&0\n신뢰?')
    stage.unit(1).move(45, 52, 1)
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(204).setAction(11)
    stage.delay(3)
    stage.unit(204).setAction(0, 3)
    stage.delay(3)
    stage.unit(204).setAction(5, 3)
    stage.delay(5)
    stage.unit(204).setAction(0, 3)
    stage.unit(1).move(38, 52, 3)
    stage.delay(1)
    stage.unit(204).setAction(0, 2)
    stage.unit(1).move(38, 67, 1)
    stage.delay(1)
    stage.unit(1).move(45, 67, 1)
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.delay(5)
    stage.unit(0).setAction(5, 3)
    stage.delay(10)
    stage.unit(1).move(38, 67, 0)
    stage.delay(1)
    stage.unit(1).move(38, 52, 1)
    stage.unit(1).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(5, 0)
    stage.say('&0\n오? "조의 군대가 공격할 때, 그는 도시 내부에서 내부자로 행동할 것이다"?\n흠................')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n왜 그렇게 위험한 짓을 했어?\n진실이 드러나면 여포가 널 죽일 거야.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n논리적으로 상인들은 항상 이익 추구적이다,\n그렇지?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n이 계획이 성공하더라도,\n당신이 얻는 혜택은 당신 자신의 생명만큼 소중하지 않습니다.')
    stage.unit(204).setAction(11, 2)
    stage.say('&204\n이제 푸양의 상인들이 도시 안에 여포 있기 때문에,\n그들은 더 이상 사업을 할 수 없습니다.\n&204\n여포 임의적인 징수와 폭력적인 징집, 권력자들의 교활함과 약탈,\n마치 평범한 집밥처럼 말이죠.\n&204\n만약 조공이 푸양으로 돌아가지 못한다면,\n우리 중 누구도 살아남지 못했어요.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n그래서 그런 일이 있었던 거구나...\n이런 일들은 정말 여포 자신의 일처럼 보입니다.')
    stage.say('&18\n잠시만 기다려 주세요.')
    stage.showUnit(18, 49, 16, 2)
    stage.unit(18).move(49, 44, 2)
    stage.say('&0\n아, 쯔양이구나.\n도시로 보내 정찰하는 건 정말 힘들어요.\n&18\n주군 푸양 시는 백성들이 도시를 떠나는 것을 금지했다,\n감시가 매우 엄격합니다.\n&18\n이 남자는 실제로 도시를 떠나 우리 캠프로 왔어요,\n이 편지는 아마도 여포 함정이었을 .......')
    stage.unit(204).setAction(0)
    stage.delay(3)
    stage.unit(204).setAction(0, 0)
    stage.say('&204\n그 이유는............\n내 주인이 문지기 병사들에게 뇌물을 줬기 때문이야.')
    stage.unit(204).setAction(0, 2)
    stage.say('&204\nI ...... 거짓말 안 해! 다 ...... 모두 사실이야!\n&204\n돌아가야 해. 늦으면 주인님이 걱정하실 거야,\n조공, 제발 믿어주세요!')
    stage.unit(204).move(43, 52, 3)
    stage.delay(1)
    stage.unit(204).move(43, 30, 0)
    stage.delay(1)
    stage.unit(204).move(49, 30, 1)
    stage.delay(1)
    stage.unit(204).move(49, 16, 0)
    stage.unit(204).hide()
    stage.unit(18).move(49, 52, 2)
    stage.say('&18\n주군, 아직도 함정인 것 같아......?\n&0\n하지만 만약 그게 사실이라면,\n이건 일생에 한 번뿐인 기회야.\n&0\n이제 우리는 빠르게 푸양을 되찾아야 한다,\n쯔양, 너도 전투에 참여해야 해.')
    stage.unit(18).setAction(6)
    stage.say('&18\n네.')
    stage.bgSound(15)
    stage.delay(3)
    stage.unit(18).setAction(0)
    stage.delay(3)
    stage.unit(18).move(49, 40, 0)
    stage.delay(1)
    stage.unit(18).move(38, 40, 1)
    stage.unit(18).setAction(0)
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 11, [
        16,
        18])
    gvars[4076] = 0
    gvars[4057] = 7
    stage.setBattlePos([
        [
            28,
            13],
        [
            28,
            14],
        [
            30,
            13],
        [
            30,
            14],
        [
            28,
            12],
        [
            30,
            12],
        [
            29,
            13],
        [
            29,
            15],
        [
            28,
            15],
        [
            29,
            12],
        [
            30,
            15],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(18):
        stage.say('&18\n주군, 그 사람은 여전히 믿을 수 없어.')
    if stage.unitClickTest(20):
        stage.say('&20\n푸양 도시 전체가 전장이 될 것이다,\n공격아군 도시 동쪽에서 시작되었다.')
    if stage.unitClickTest(1):
        stage.say('&1\n이번에는 반드시 여포을 제거해야 한다!')
    if stage.unitClickTest(22):
        stage.say('&22\n쯔양 씨는 대포 트럭 캐러밴 지휘관이야,\n공격 범위가 가장 넓고, 이번에는 전적으로 당신에게 달려 있습니다.\n&18\n하지만 다른 한편으로는 이동이 너무 번거롭습니다.......')
    if stage.unitClickTest(16):
        stage.say('&16\n무기, 갑옷, 병력 모두 경험치가 있죠?\n레벨 상승도 다르게 보이나요?\n&20\n하하하, 장군 전위,\n무기는 공격 시 경험치를 증가시킵니다.\n방어구는 방어 시 경험치를 증가시킵니다.\n&16\n아, 그렇군요.\n그러니까 공격할 때도 병력 경험치가 증가하는 거죠?\n&20\n네, 만약 당신이 고레벨 상대를 이기면,\n또한 상당히 증가할 것입니다.')
    if stage.unitClickTest(21):
        stage.say('&21\n여포의 용기는 정말 놀랍습니다.\n마치 신이나 유령이 지상에 내려온 것 같았다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
