# Source Generated with Decompyle++
# File: R_20.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(13)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 73)
    stage.draw()
    stage.setEventName('원소 사망')
    stage.setStageName('캉팅 리버사이드')
    stage.showUnits([
        [
            113,
            95,
            77,
            3],
        [
            114,
            95,
            69,
            3],
        [
            101,
            95,
            77,
            3],
        [
            115,
            95,
            69,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(113),
            83,
            77,
            3],
        [
            stage.unit(114),
            83,
            69,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(113),
            50,
            77,
            3],
        [
            stage.unit(114),
            50,
            69,
            3],
        [
            stage.unit(101),
            62,
            77,
            3],
        [
            stage.unit(115),
            62,
            69,
            3]])
    stage.say('&101\n음, ..........')
    stage.unit(101).setAction(9)
    stage.delay(3)
    stage.unit(114).setAction(0, 1)
    stage.unit(115).setAction(0, 2)
    stage.delay(3)
    stage.unit(113).setAction(0, 1)
    stage.say('&113\n아! 아버지?')
    stage.unit(114).move(52, 69, 1)
    stage.say('&114\n일어나세요, 아버지!')
    stage.say('&101\n더 이상 걸을 수 없었어요.\n내 운명이 도망치고 있는 것 같아.......')
    stage.unit(115).move(62, 71, 2)
    stage.say('&115\n기운 내!\n만약 아버지가 여기서 쓰러지면,\n우리 나라는 무엇을 해야 할까요?\n&115\n우리가 예시로 가면,\n우리는 또한 재정비할 수 있습니다.\n&114\n아버지!\n&101\nI... 내 자리가 ......\n......에게 맡겨졌다 선부가 ......를 물려받았다\n&115\n응?')
    stage.unit(113).setAction(3)
    stage.say('&113\n너, 뭐라고 했어!\n어떻게 이럴 수 있지!!')
    stage.unit(113).setAction(0)
    stage.say('&114\n…… 아버지 .......')
    stage.unit(101).setAction(1)
    stage.delay(3)
    stage.unit(101).setAction(1, 2)
    stage.say('&101\n그 미운 조나라는 놈이야......\n&101\nI ...... 나 곧 .........\n우리가 세상을 이겼어요!!\n&101\n안타깝게도!')
    stage.unit(101).setAction(10)
    stage.say('&114\n아버지!!\n&113\n(…… 어떻게 이런 일이 일어날 수 있지! 왕위를 원상에게 넘기라고!?\n인정하지 않겠습니다, 절대 인정하지 않을 겁니다!!\nI ...... 나는 장남이니까 상속자가 되어야 해! )\n&115\n…… 아버지.')
    stage.info('가장 천하를 차지할 가능성이 있던 원소이 죽고, 세 명의 마음속 속마음을 가진 아들을 남겨 좁은 관계 속에서 예성으로 철수했다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            2,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.delay(3)
    stage.setStageName('캉팅 조조 주 진영')
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n신고됐어.')
    stage.unit(181).move(49, 22, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 원소 황하에서 죽었어.\n&22\n뭐라고? 원소 죽었다고!?')
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3, 2)
    stage.say('&1\n맹덕, 정말 좋네요.\n드디어 원소를 근절했습니다!!')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n…………。')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n…… 안녕.\n맹덕, 너 왜 그래?\n원소 죽었.......')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군.............')
    stage.unit(0).setAction(0, 0)
    stage.say('……원소의 후계자는 누구입니까?\n주군께 보고드립니다. 어린 아들 원상입니다.\n어린 아들이라니...? \n네. 원소가 임종 직전에 직접 말씀하셨습니다.\n정말요? 수고했구나. 물러가거라...\n예.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.delay(3)
    stage.unit(1).setAction(3, 2)
    stage.say('&1\n안녕, 맹덕......\n도대체 무슨 일이 있었던 거야?')
    stage.unit(1).setAction(0, 2)
    stage.say('&0\n......원양.\n&1\n응?\n&0\n어릴 때부터 원소 알았어,\n그는 저에게 엄청난 영향을 주었어요.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n원소 저와 몇 가지 닮은 점이 있습니다.\n&1\n………\n&0\n그가 떠난 지금, 나는 조금 슬퍼.\n&1\n흠...... 알겠습니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('아니, 됐다. 생각해보니 나는 감상에 젖는 사람이 아닌 것 같군.')
    stage.unit(0).setAction(17)
    stage.say('&0\n음, 이번 원정의 목적은 달성되었다.\n전 군대는 승리의 승리를 거두고 쉬두로 돌아갔다.')
    stage.unit(1).setAction(17)
    stage.say('&1\n오!')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n잠시만 기다려 주세요.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(0)
    stage.say('&0\n응? 문약, 무슨 일이야?')
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 아군 승리의 귀환 전에,\n어쩌면 다른 곳도 공격하는 것도 고려해보세요.')
    stage.say('&0\n음, 유비 말하는 거야?\n&20\n정확히 그렇습니다.')
    stage.unit(20).setAction(0)
    stage.say('&20\n유비와 다른 이들은 현재 랑산에 기지를 세웠습니다.\n근처에 산적들을 모아 병력을 늘리세요.')
    stage.unit(20).setAction(6)
    stage.say('&20\n그를 제거하러 가는 게 어때......?\n&0\n좋아, 빈손으로 쉬두로 돌아갈 수는 없었다.\n전멸시켜라!')
    stage.unit(0).setAction(17)
    stage.say('&0\n알았어! 랑산으로 가.\n공격해유비!')
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        2,
        7,
        6])
    gvars[4076] = 0
    gvars[4057] = 20
    stage.setBattlePos([
        [
            12,
            1],
        [
            13,
            2],
        [
            10,
            1],
        [
            15,
            2],
        [
            9,
            2],
        [
            16,
            1],
        [
            9,
            0],
        [
            15,
            0],
        [
            12,
            3],
        [
            14,
            3],
        [
            13,
            4],
        [
            14,
            1],
        [
            11,
            2],
        [
            13,
            0],
        [
            11,
            0]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        stage.clsUnit()
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n도적들이 도우려 유비지만,\n하지만 결국 그들은 무리였다.\n&0\n산속에서 싸우는 것에 불과하다,\n산적들이 그들의 물속에 있었고,\n부주의하지 마!\n&1\n흠.')
    if stage.unitClickTest(2):
        stage.say('&2\n제발 제가 처리하게 관우.')
    if stage.unitClickTest(20):
        stage.say('&20\n전장은 산으로 가득하다,\n장군 허저가 행동하게 하자......\n&15\n오! 그래서 네가 문약 노전략가인 거구나,\n정말 통찰력이 있네요.\n&20\n하하하.')
    if stage.unitClickTest(22):
        stage.say('&22\n조운 유비군에 합류한 것 같아요.\n&0\n조운? 서주에서 본 그 호랑이 장군?\n&22\n네.\n그의 무술 실력은 관우와 장비에 필적할 수 있었다.\n&0\n아, 흥미롭네요.')
    if stage.unitClickTest(15):
        stage.say('&15\n랑산? 그럼 산이었구나.\n이제 내가 자랑할 차례야!')
    if stage.unitClickTest(21):
        stage.say('&21\nHowever유비 이 남자는 외교에 매우 능숙했다.\n&0\n맞아.\n그는 한때 원소을 성공적으로 활용한 적이 있다.')
    return False


def scene3():
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            32,
            53,
            37,
            2],
        [
            3,
            42,
            52,
            1],
        [
            33,
            42,
            58,
            1],
        [
            74,
            67,
            52,
            3],
        [
            75,
            67,
            58,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('랑산유비 주 진영')
    stage.delay(3)
    stage.unit(32).setAction(3)
    stage.say('&32\n뭐라고!?\n조의 군대가 랑산을 향해 돌진하고 있다고!?')
    stage.say('&75\n네, 제 부하들이 봤어요.\n분명 조조의 깃발일 거야.')
    stage.unit(32).setAction(0)
    stage.say('&32\n그래서.........\n조조 완전히 패배한 원소?\n&3\n아마도 바로 그럴 것이다.\n조조 정말 무서워요!')
    stage.unit(33).setAction(0, 0)
    stage.say('&33\n이봐, 이봐!\n지금은 적을 찬양할 때가 아닙니다.')
    stage.unit(33).setAction(0, 1)
    stage.say('&32\n네, 맞아요.\n무슨 일이 있어도,\n이 모든 것이 조의 군대의 공격을 막을 수 있었다.')
    stage.unit(74).setAction(3)
    stage.say('&74\n주군 걱정할 필요 없어.\n이 지역은 우리 영토입니다,\n안심하세요.')
    stage.unit(74).setAction(0)
    stage.delay(3)
    stage.unit(75).setAction(3)
    stage.say('&75\n맞아!')
    stage.unit(75).setAction(0)
    stage.say('&32\n흠.')
    stage.unit(32).setAction(17)
    stage.say('&32\n좋아! 모두 방어를 강화해,\n조조 군대의 공격을 막기 위해서였다.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
