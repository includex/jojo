# Source Generated with Decompyle++
# File: S_48.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24], [
        '(16,2)',
        '(15,2)',
        '(15,3)',
        '(16,3)',
        '(15,15)'])
    stage.nearEvent([
        0,
        76,
        3,
        83,
        3,
        87,
        3,
        82,
        3,
        96], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy([
        {
            'id': 76,
            'x': 16,
            'y': 2,
            'lv': 6,
            'i': 0 },
        {
            'id': 79,
            'x': 15,
            'y': 3,
            'lv': 6,
            'i': 1 },
        {
            'id': 86,
            'x': 16,
            'y': 3,
            'lv': 6,
            'i': 2 },
        {
            'id': 85,
            'x': 16,
            'y': 12,
            'lv': 6,
            'i': 3 },
        {
            'id': 96,
            'x': 15,
            'y': 12,
            'lv': 4,
            'i': 4 },
        {
            'id': 83,
            'x': 16,
            'y': 11,
            'lv': 4,
            'i': 5 },
        {
            'id': 282,
            'x': 17,
            'y': 11,
            'lv': 0,
            'i': 6 },
        {
            'id': 310,
            'x': 15,
            'y': 11,
            'lv': 0,
            'i': 7 },
        {
            'id': 311,
            'x': 14,
            'y': 11,
            'lv': 0,
            'i': 8 },
        {
            'id': 92,
            'x': 15,
            'y': 15,
            'dir': 3,
            'lv': 4,
            'i': 9 },
        {
            'id': 210,
            'x': 15,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'i': 10 },
        {
            'id': 211,
            'x': 15,
            'y': 16,
            'dir': 3,
            'lv': 0,
            'i': 11 },
        {
            'id': 234,
            'x': 16,
            'y': 15,
            'dir': 3,
            'lv': 0,
            'i': 12 },
        {
            'id': 82,
            'hide': 1,
            'x': 5,
            'y': 15,
            'dir': 1,
            'lv': 4,
            'ai': 1,
            'i': 13 },
        {
            'id': 87,
            'hide': 1,
            'x': 5,
            'y': 16,
            'dir': 1,
            'lv': 4,
            'ai': 1,
            'i': 14 },
        {
            'id': 235,
            'hide': 1,
            'x': 4,
            'y': 15,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 236,
            'hide': 1,
            'x': 4,
            'y': 16,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 318,
            'hide': 1,
            'x': 3,
            'y': 15,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 319,
            'hide': 1,
            'x': 3,
            'y': 16,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 320,
            'hide': 1,
            'x': 5,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 321,
            'hide': 1,
            'x': 4,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 84,
            'hide': 1,
            'x': 19,
            'y': 20,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 21 },
        {
            'id': 78,
            'hide': 1,
            'x': 19,
            'y': 21,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 22 },
        {
            'id': 358,
            'hide': 1,
            'x': 19,
            'y': 22,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 23 },
        {
            'id': 359,
            'hide': 1,
            'x': 19,
            'y': 20,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 24 },
        {
            'id': 360,
            'hide': 1,
            'x': 19,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 25 },
        {
            'id': 361,
            'hide': 1,
            'x': 19,
            'y': 22,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 26 },
        {
            'id': 362,
            'hide': 1,
            'x': 19,
            'y': 20,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 27 },
        {
            'id': 363,
            'hide': 1,
            'x': 19,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 28 },
        {
            'id': 364,
            'hide': 1,
            'x': 19,
            'y': 22,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 29 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 6,
            'y': 2,
            'dir': 1 },
        {
            'idx': 1,
            'x': 6,
            'y': 3,
            'dir': 1 },
        {
            'idx': 2,
            'x': 6,
            'y': 1,
            'dir': 1 },
        {
            'idx': 3,
            'x': 6,
            'y': 4,
            'dir': 1 },
        {
            'idx': 4,
            'x': 5,
            'y': 2,
            'dir': 1 },
        {
            'idx': 5,
            'x': 5,
            'y': 3,
            'dir': 1 },
        {
            'idx': 6,
            'x': 5,
            'y': 1,
            'dir': 1 },
        {
            'idx': 7,
            'x': 5,
            'y': 4,
            'dir': 1 },
        {
            'idx': 8,
            'x': 4,
            'y': 2,
            'dir': 1 },
        {
            'idx': 9,
            'x': 4,
            'y': 3,
            'dir': 1 },
        {
            'idx': 10,
            'x': 4,
            'y': 1,
            'dir': 1 },
        {
            'idx': 11,
            'x': 4,
            'y': 4,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(48)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(3)
    stage.unit(0).setDir(stage.countDir(0, 76))
    stage.unit(0).setAction(5)
    stage.say('&0\n이제 장링성에 대한 공격이 시작된다.\n군대 전체가 공격을 시작했다!')
    stage.unit(0).setAction(0)
    stage.unit(3).setDir(stage.countDir(3, 76))
    stage.unit(3).setAction(5)
    stage.say('&3\n관의 의형제들과 아들들은 깊은 피의 원한을 가지고 있다,\n여기서 갚아야 해!')
    stage.unit(3).setAction(0)
    stage.unit(96).setDir(stage.countDir(96, 3))
    stage.say('&96\n정말 관우하지 않나요!?\n그래서 그는 조조로 망명한 것이다!')
    stage.unit(83).setDir(stage.countDir(83, 96))
    stage.say('&83\n딩펑, 우리가 관우에게 표적이 됐어.\n그는 장비와 관평의 복수를 위해 여기 온 게 틀림없어.\n어떻게 해야 할까요?')
    stage.unit(85).setDir(stage.countDir(85, 83))
    stage.say('&85\n뭘 두려워하는 거야!\n관우 오게 못 할 거야!\n너희는 뒤에서 화살을 쏴.')
    stage.unit(92).setDir(stage.countDir(92, 3))
    stage.unit(92).setAction(7)
    stage.say('&92\n젠장, 관우 데려다 줄게!')
    stage.unit(92).setAction(0)
    stage.unit(76).setDir(stage.countDir(76, 79))
    stage.unit(79).setDir(stage.countDir(79, 76))
    stage.unit(86).setDir(stage.countDir(86, 76))
    stage.say('&86\n사장님...... 어, 그러니까 주군.\n이 작은 병력으로 정말 버틸 수 있을까?\n&79\n곧 증원군이 도착할 것이다,\n그 후에는 계속 지원할 수 있습니다.\n&76\n사실, 장링을 잃어도 상관없다.\n시간을 더 벌 수만 있다면,\n레드 클리프스에서 병력 배치에 사용됨.\n&79\n저우 사령관은 이미 홍벽에서 준비를 마쳤어야 했다.\n여기서 정면으로 싸울 필요 없적군.\n&86\n물론 그게 최선이지만, 진짜 걱정은 ......')
    stage.setWinCondition('승리 조건\n1. 후퇴손권.\n\n패배 조건\n1. 조조 사망\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('손권를 이겨라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[548] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[11] and stage.round() >= 1 and stage.curCamp() == 0:
        stage.unit(84).show()
        stage.unit(84).move(15, 20, 3)
        stage.unit(78).show()
        stage.unit(78).move(15, 21, 3)
        stage.unit(358).show()
        stage.unit(358).move(15, 22, 3)
        stage.unit(359).show()
        stage.unit(359).move(16, 20, 3)
        stage.unit(360).show()
        stage.unit(360).move(16, 21, 3)
        stage.unit(361).show()
        stage.unit(361).move(16, 22, 3)
        stage.unit(362).show()
        stage.unit(362).move(17, 20, 3)
        stage.unit(363).show()
        stage.unit(363).move(17, 21, 3)
        stage.unit(364).show()
        stage.unit(364).move(17, 22, 3)
        stage.say('&78\n서둘러, 양쪽 모두 이미 싸우기 시작했어!\n&84\n주군, 늦어서 죄송합니다.\n다음은 우리에게 맡기세요!')
        stage.unit(78).setDir(stage.countDir(78, 76))
        stage.unit(84).setDir(stage.countDir(84, 76))
        stage.say('&78\n주군, 즈징은 이미 도착해 있었다.\n드디어 제시간에 도착했어요, 정말 좋았어요.\n&84\n적은 어디에 있는가, 어디에 있는가?\n인내심이 별로 없어,\n어서 와서 죽어!')
        if not vars[52]:
            stage.unit(79).setDir(stage.countDir(79, 76))
            stage.say('&79\n주군 증원군이 도착했다.')
        stage.unit(76).setDir(stage.countDir(76, 78))
        stage.unit(76).setAction(5)
        stage.say('&76\n노숙와 감녕 도착했지?\n좋아, 조의 군대를 포위하고 다시 공격해라!')
        stage.unit(76).setAction(0)
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.say('벽안아, 정말 치밀한 계획이구나! 이 싸움은 어떻게 해야 잘 풀릴까?')
        sel = stage.choice('매복 증원군을 만나 격퇴하기 위해서였다\n집중 공격 손권', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n적군 군사력은 두려워할 필요가 없습니다,\n우리는 차분하게 한 사람씩 대응해야 합니다.')
            stage.unit(0).setAction(0)
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.say('&76\n흠, 이 병력 수로는 그들을 겁주지 못할 것 같군.\n좋아! 이런 상황에서 두 군대가 싸우고 있다니,\n아직 조금 더 시간을 벌 수 있어.')
            stage.unit(79).setDir(stage.countDir(79, 76))
            stage.say('&79\n치비로 서둘러야 해!\n&76\n좋아, 모든 병사들, 내 명령을 들어라!\n이 모든 게 네 노력 덕분이야.\n무슨 일이 있어도 시간을 벌려고 노력하세요.')
            stage.unit(79).setDir(stage.countDir(79, 86))
            stage.unit(86).setDir(stage.countDir(86, 79))
            stage.say('&79\n저우타이, 너도 지켜주군.\n&86\n위험이 없다면 갈 의향이 있어.\n그럼 이 일은 당신에게 맡기겠습니다.')
            stage.unit(76).hide()
            stage.unit(79).hide()
            stage.unit(86).hide()
            stage.say('&0\n뭐라고! 손권 도망쳤다고!?')
            if not vars[61]:
                if not vars[54]:
                    stage.say('&82\n조금만 더 시간을 벌 수 있다면,\n일정 레벨에 도달하면 그냥 도망가세요,\n어쨌든, 주군 볼 수가 없어.')
                if not vars[55]:
                    stage.say('&87\n관우 우리에게 복수하러 온 것 같군요,\n이곳은 오래 머무르기에 적합하지 않아.\n아마 도망칠 때가 된 것 같아요!')
                if not vars[57]:
                    stage.say('&96\n시간 벌기 문제는 나한테 맡겨, 딩펑.\n복수하러 온다 해도 관우을 지킬 방법을 찾아야 ......')
                if not vars[56]:
                    stage.say('&83\n관우 정말 큰 문제입니다......\n이전 전투에서 관평을 공격했어,\n그를 마주치지 않는 게 좋아.')
            stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('전부 전멸시적군!')
            vars[3] = 1
        elif sel == 2:
            stage.unit(0).setDir(stage.countDir(0, 76))
            stage.say('&0\n비록 적군 병력이 크지는 않지만,\n하지만 협공 공격에 휘말리는 건 쉽지 않아.')
            stage.unit(0).setAction(5)
            stage.say('&0\n우리는 완전히 포위되어야 한다,\n손권를 이겨라!')
            stage.unit(0).setAction(0)
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.say('&76\n조조 무력으로 포위망을 돌파할 계획이었다,\n내 쪽으로 바로 다가오는 거야!?\n&76\n좋아, 원래는 치비로 돌아가고 싶었어,\n그렇다면 미끼로 두자.\n어쩌면 한 번에 조조 쓸어버릴 수 있을지도 몰라!')
            stage.unit(76).setAI(1)
            stage.unit(79).setAI(1)
            stage.unit(86).setAI(1)
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 16, 2):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 15, 2):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 15, 3):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 16, 3):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 15, 15):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[2] and not vars[6] and stage.totalRectUnit(0, 12, 13, 19, 23) >= 3 and stage.curCamp() == 2:
        stage.unit(87).show()
        stage.unit(82).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(82).setDir(stage.countDir(82, 0))
        stage.unit(87).setDir(stage.countDir(87, 0))
        stage.say('&87\n헤헤, 속았구나? 조조.\n제가 가장 잘하는 건 속임수를 써서 적을 공격하는 거예요!\n&82\n주군 우리 공연을 보고 있어.\n그가 조조를 죽인다면 대단한 성취가 될 거야!')
        stage.unit(76).setDir(stage.countDir(76, 87))
        stage.unit(76).setAction(5)
        stage.say('&76\n좋아! 조조군을 공격해!')
        stage.unit(76).setAction(0)
        stage.unit(0).setDir(stage.countDir(0, 82))
        stage.say('&0\n매복 ......인가요?\n적군 오래전에 준비한 것 같다.')
        stage.setAI(10, 11, 19, 17, 2, 1)
        vars[2] = 1
        vars[6] = 1
    if not vars[2] and not vars[30] and stage.isInRect(1025, 2, 13, 6, 17):
        stage.unit(87).show()
        stage.unit(82).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(82).setDir(stage.countDir(82, 0))
        stage.unit(87).setDir(stage.countDir(87, 0))
        stage.unit(82).setAction(10)
        stage.say('&82\n아니, 발각됐어......\n&87\n흥! 적을 물리칠 수만 있다면 그걸로 충분해.\n어쨌든, 소위 매복 부대는,\n조만간 적 바로 앞에 나타나게 될 거야.')
        stage.unit(76).setDir(stage.countDir(76, 87))
        stage.say('&76\n쳇, 그렇다면, 우리는 전력을 다해 싸울 수밖에 없어!\n도시를 지킬 필요 없어; 모두가 온 힘을 다해 조조을 공격하고 있어.')
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.say('역시 매복군이 있군! 다른 계략도 있을 것 같아.')
        stage.setAI(10, 11, 19, 17, 2, 1)
        vars[2] = 1
        vars[30] = 1
    if not vars[40] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n손권, 순종적으로 항복할 의향이 있습니까?\n&76\n말 헛소리하지 마.\n나는 절대 항복하지 않을 거야!\n&0\n그래서 나는 우를 파괴할 수밖에 없다.')
        vars[40] = 1
    if vars[3] and not vars[41] and stage.isNear(3, 83, False):
        stage.unit(3).setDir(stage.countDir(3, 83))
        stage.unit(83).setDir(stage.countDir(83, 3))
        stage.say('&3\n나는 매성에서 전사한 관평의 복수를 하겠다!\n&83\n으, 와!\n지금 도망쳐!')
        stage.unit(83).hide()
        stage.say('&3\n그는 실제로 도망치는 데 성공했다.')
        vars[41] = 1
    if vars[3] and not vars[42] and stage.isNear(3, 87, False):
        stage.unit(3).setDir(stage.countDir(3, 87))
        stage.unit(87).setDir(stage.countDir(87, 3))
        stage.say('&3\n나는 마이성에서 전사한 관소오의 복수를 원한다!\n&87\n흥! 난 너랑 싸우지 않을 거야.\n안녕!')
        stage.unit(87).hide()
        stage.say('&3\n도망치려는 거야? 도망가지 마!\n장군이라고 불릴 자격이 없어!')
        vars[42] = 1
    if vars[3] and not vars[43] and stage.isNear(3, 82, False):
        stage.unit(3).setDir(stage.countDir(3, 82))
        stage.unit(82).setDir(stage.countDir(82, 3))
        stage.say('&3\n나는 매성에서 전사한 관싱의 복수를 하겠다!\n&82\n응? 관우야!\n(시간을 벌기 위해 목숨을 잃을 필요는 없다,\n…… 후퇴! )')
        stage.unit(82).hide()
        stage.say('&3\n어떻게 그렇게 쉽게 도망칠 수 있지!?\n혹시 속임수가 있을까요?')
        vars[43] = 1
    if vars[3] and not vars[44] and stage.isNear(3, 96, False):
        stage.unit(3).setDir(stage.countDir(3, 96))
        stage.unit(96).setDir(stage.countDir(96, 3))
        stage.say('&3\n나는 마이성에서 전사한 셋째 형의 복수를 원한다!\n&96\n미안, 용기가 없어.\n후퇴!')
        stage.unit(96).hide()
        stage.say('&3\n도망쳤다고!? 정말 화가 나.')
        vars[44] = 1
    if vars[11] and not vars[3] and not vars[45] and stage.isNear(3, 83, True):
        stage.unit(3).setDir(stage.countDir(3, 83))
        stage.unit(83).setDir(stage.countDir(83, 3))
        stage.say('&3\n내 아들 관평의 목숨을 돌려줘!\n목숨을 내놓아!\n&83\n아니, 아니야......\n잠깐, 잠깐!\n&3\n말은 그만해! 목숨을 내놔!\n&83\n음, 그리고 손권주군 앞에서 도망칠 수 없어,\n이건 큰 문제야.')
        vars[45] = 1
    if vars[11] and not vars[3] and not vars[46] and stage.isNear(3, 87, True):
        stage.unit(3).setDir(stage.countDir(3, 87))
        stage.unit(87).setDir(stage.countDir(87, 3))
        stage.say('&3\n찾았어.\n관소의 복수를 원해!\n&87\n아, 이런, 짜증나는 남자를 만났어!')
        vars[46] = 1
    if vars[11] and not vars[3] and not vars[47] and stage.isNear(3, 82, True):
        stage.unit(3).setDir(stage.countDir(3, 82))
        stage.unit(82).setDir(stage.countDir(82, 3))
        stage.say('&3\n감히 관싱을 죽일 수 있단 말인가......\n절대 그냥 두지 않을 거야!\n&82\n음, 관우!\n이건 좋지 않아.\n&82\n음, 음, ......\n하지만 주군에서는 물러설 수 없었다.\n이건 완전 재앙이야!')
        vars[47] = 1
    if vars[11] and not vars[3] and not vars[48] and stage.isNear(3, 96, True):
        stage.unit(3).setDir(stage.countDir(3, 96))
        stage.unit(96).setDir(stage.countDir(96, 3))
        stage.say('&3\n딩펑, 나는 셋째 형의 복수를 원해!\n&96\n음, 관우?\n좋아! 가자!')
        vars[48] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&76\n나는 무력했다.\n후퇴!')
        stage.unit(76).hide()
        if not vars[52]:
            stage.say('&79\n억지로 하지 않는 게 나을 것 같아.\n나도 후퇴할 거야!')
            stage.unit(79).hide()
        if not vars[53]:
            stage.say('&86\n주군 모두 떠났다,\n우리도 후퇴하자.')
            stage.unit(86).hide()
        if not vars[58]:
            stage.say('&85\n계획대로 후퇴하라!')
            stage.unit(85).hide()
        if not vars[61]:
            stage.say('&78\n계속 싸울 필요 없어.\n전군을 후퇴시켜라!')
            stage.unit(78).hide()
        if not vars[60]:
            stage.say('&84\n뭐라고? 전력 질주하며 싸우고 있어!\n어떻게 그렇게 쉽게 후퇴할 수 있었을까?\n아직 킬 경험도 못 했어.')
            stage.unit(84).hide()
        stage.setRectUnitHide(0, 0, 19, 23, 2)
        stage.say('&0\n아무도 오나라 군대가 이렇게 쉽게 후퇴할 것이라 예상하지 못했다.\n이 전투가 단지 시간을 벌기 위한 것일까?\n&0\n그럼 괜찮아.\n네가 어떤 속임수를 써도,\n네 모든 속임수를 폭로하겠다.\n&0\n좋아, 전 군대가 장링에 주둔했어!\n명령 기다리고 있어!')
        if vars[3]:
            stage.reward()
        else:
            stage.reward(0, [
                160,
                -1])
        stage.end()
        vars[50] = 1
        vars[100] = 1
        vars[0] = 1
        vars[648] = 1
        return True
    if not vars[51] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n와!\n노숙 물러났다.')
        stage.unit(78).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n선택의 여지가 없었습니다.\n후퇴.')
        stage.unit(79).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n쳇, 이제 후퇴할 때가 된 것 같아.\n후퇴, 후퇴!')
        stage.unit(86).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n와!\n후퇴, 후퇴!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n아파!\n쳇, 후퇴.')
        stage.unit(87).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n더는 못 참겠어, 더는 못 참겠어! 후퇴!\n"빨리, 얼른 가!"')
        stage.unit(83).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(96, 7, 0, 2):
        stage.say("&96\n사람들은 종종 '억지로 하지 마라'고 말합니다.\n일단 후퇴하자.")
        stage.unit(96).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n정말 미운 참 어려워!\n오늘의 굴욕은 앞으로 네가 갚아야 해!')
        stage.unit(85).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n뭐, 졌어?\n쳇, 선택의 여지가 없네요.\n후퇴!')
        stage.unit(92).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n아파, 이 녀석아!\n젠장, 더 이상 싸울 수 없어.\n철수해, 훗!')
        stage.unit(84).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(3, 7, 0, 2):
        vars[61] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n자, 아군 이겼어!\nHowever손권 군대 내 상황이 다소 이상했지만,\n그들은 전혀 싸울 생각이 없는 것 같다......\n&0\n이 도시가 미끼일 수도 있을까?\n또 다른 속임수 주유 아니야?\n어쨌든 조심하는 것이 최선입니다.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[648] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
