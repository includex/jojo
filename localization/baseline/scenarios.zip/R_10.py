# Source Generated with Decompyle++
# File: R_10.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            149,
            49,
            67],
        [
            1,
            38,
            54,
            2,
            6],
        [
            16,
            38,
            48,
            2,
            6],
        [
            15,
            38,
            42,
            2,
            6],
        [
            20,
            60,
            54,
            2,
            6],
        [
            22,
            60,
            48,
            2,
            6],
        [
            21,
            60,
            42,
            2,
            6],
        [
            0,
            49,
            54,
            2,
            6]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setEventName('호가의 선율')
    stage.setStageName('장안 근처, 조조군의 본진')
    stage.say('&149\n조 장관님, 저를 구해 주셔서 감사합니다. 감사합니다.\n&0\n폐하께서는 그렇게 격식을 차릴 필요 없습니다; 이것이 신하와 신하의 의무입니다.\n&149\n조 대신, 이제부터 저를 도와주세요.\n&0\n네! 폐하.')
    stage.unit(149).move(56, 67, 1)
    stage.delay(1)
    stage.unit(149).move(56, 24, 0)
    stage.delay(1)
    stage.unit(149).move(49, 24, 3)
    stage.delay(1)
    stage.unit(149).move(49, 16, 0)
    stage.unit(149).hide()
    stage.unit(0).setAction(0, 2)
    stage.unit(1).setAction(0, 1)
    stage.unit(16).setAction(0, 1)
    stage.unit(15).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(22).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).move(56, 54, 1)
    stage.delay(1)
    stage.unit(0).move(56, 67, 2)
    stage.delay(1)
    stage.unit(0).move(49, 67, 3)
    stage.delay(1)
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n저 사람이 천자의 아들이야......\n그는 전혀 기술이 없었다,\n그래서 ...... 방송됩니다.\n&0\n그게 천자의 성향이야, 원양.\n이렇게 해야만 황제가 될 수 있다.')
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n흥.......')
    stage.say('하지만 드디어 소원대로 되었군요.')
    stage.unit(0).setAction(3, 0)
    stage.say('여러 장수님들의 노력 덕분에 이 전쟁에서 승리할 수 있었습니다.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n하지만 맹덕, 서황 정말 싸울 수 있어.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n흠, 이제 몇몇을 이끌고 있는 것 같네,\n근처 캠프.......')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n만약 그런 영웅이 그렇게 죽는다면,\n안타깝네...\n그를 아군에 영입하고 싶어요.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군, 서황 일은 내게 남겨둬.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n문약, 좋은 전략이 있나요?')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n만약 그렇다면, 누군가를 보내서 그를 설득해 항복하게 할 수 있습니다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n버닝, 응답해.')
    stage.delay(3)
    stage.showUnit(25, 49, 16, 2)
    stage.say('&25\n무례하게 굴어서 죄송합니다.')
    stage.unit(1).setAction(0, 1)
    stage.unit(25).move(49, 54, 2)
    stage.delay(3)
    stage.unit(25).setAction(6)
    stage.say('&25\n조공께 경의를 표하러 왔습니다. 저는 만충, 본잉이라 불립니다.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n이 사람은 뛰어난 지혜와 전략을 지녔다,\n추천할 적절한 기회를 기다리고 있었습니다.\n&20\n더욱이 그는 서황과도 가까운 우정을 지녔다.\n&20\n그가 서황을 설득한 사람이었다.\n&25\n내게 맡겨.\n&0\n좋아, 버닝, 네게 맡길게.\n일이 성공하면 꼭 잘 활용할게.\n&25\n감사합니다, 선생님. 그럼 즉시 쉬황 진영으로 가겠습니다.\n&0\n음, 네가 결정해.')
    stage.unit(25).setAction(0)
    stage.delay(3)
    stage.unit(25).move(49, 16, 0)
    stage.unit(25).hide()
    stage.delay(3)
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n버닝이 실패할 거라고 생각하지 않아요,\n서황 반드시 아군에 합류할 거예요.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 18)
    stage.showUnits([
        [
            13,
            35,
            55,
            1],
        [
            25,
            48,
            55,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('그날 밤, .......', 3)
    stage.setStageName('장안 인근 교외, 서황군 본진')
    stage.say('&13\n버닝, 나를 설득하려는 거야surrender조조?\n&25\n정확히 그렇습니다.')
    stage.unit(25).setAction(0, 2)
    stage.say('&25\n조 경은 과거는 잊고 당신을 더 신뢰할 만하게 만들려 한다고 했어요.')
    stage.unit(25).setAction(0, 3)
    stage.say('&25\n나랑 같이 조조 섬기는 게 어때?')
    stage.unit(13).setAction(0, 2)
    stage.delay(3)
    stage.unit(13).move(35, 59, 2)
    stage.say('&13\n하지만......\n못 하겠어.')
    stage.unit(25).move(48, 59, 2)
    stage.delay(3)
    stage.unit(25).setAction(0, 3)
    stage.say('&25\n공명아, 네 주군 좀 봐.')
    stage.unit(25).setAction(0, 2)
    stage.say('&25\n그는 오직 자신의 쾌락만을 신경 썼다,\n그는 평민들의 고난을 완전히 무시했다.')
    stage.unit(25).setAction(0, 3)
    stage.say('&25\n그런 사람에게 충성하는 것이 필요한가요?\n&13\n…….')
    stage.unit(25).setAction(0, 1)
    stage.delay(3)
    stage.unit(25).move(52, 59, 1)
    stage.say('&25\n그런 사람 밑에서 일하면서 그게 뭔지도 모른다면,\n그는 세상으로부터 조롱받을 것이다.')
    stage.unit(25).setAction(0, 3)
    stage.say('&25\n공명, 무술을 보여줘야 하지 않겠어,\n더 의미 있는 무언가를 위해 싸우고 있을까?')
    stage.unit(13).setAction(0, 1)
    stage.say('&13\n…… 음, 나는 항복할 의향이 있조조.')
    stage.unit(25).move(48, 59, 3)
    stage.say('&25\n아, 드디어 알아냈구나!\n&25\n그렇다면 지체할 시간이 없습니다!\n내일 아침, 나와 함께 바로 조의 진영으로 가라.\n&13\n좋아.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(18)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            25,
            45,
            54,
            2],
        [
            13,
            53,
            54,
            2,
            6]])
    stage.draw()
    stage.setStageName('장안 근처, 조조군의 본진')
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('공명, 드디어 오셨군요. 당신을 뵙게 되어 정말 기쁩니다. 소인은 앞으로 반드시 어른께 충성을 다하며, 목숨을 바치는 것도 아끼지 않겠습니다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n자, 버닝, 정말 잘했어.')
    stage.unit(25).setAction(6)
    stage.say('&25\n칭찬 주군 감사합니다.')
    stage.say('&0\n너희 둘 피곤하지?\n오늘은 잘 쉴 수 있어,\n내일 환영 연회를 열 거야.\n&13\n셰 주군.\n&25\n먼저 가서 죄송합니다.')
    stage.unit(25).setAction(0)
    stage.unit(13).setAction(0)
    stage.delay(3)
    stage.unit(13).move(49, 54, 3)
    stage.delay(1)
    stage.unit(13).move(49, 50, 0)
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(13),
            49,
            46,
            0],
        [
            stage.unit(25),
            49,
            54,
            1]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(13),
            49,
            16,
            0],
        [
            stage.unit(25),
            49,
            24,
            0]])
    stage.unit(13).hide()
    stage.unit(25).move(49, 16, 0)
    stage.unit(25).hide()
    stage.bgSound(-1)
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n펑샤오 문약, 앞으로 어떻게 해야 아군?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n이각. 곽사 의지하는 유일한 의지, 쉬공밍,\n이제 그들은 이미 아군에 복종했다,\n이제 그들의 시간이 다 된 것 같아.')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n정확히 그렇습니다. 더 이상 공격할 필요가 없다고 생각합니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n나도 그렇게 생각해.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그럼 폐하의 .......')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n폐하께서는 낙양에 정착하시길 원하시는 것 같다...\n&20\n하지만 저는 동의하지 않습니다.')
    stage.say('&20\n이전의 대화재로 이미 낙양은 폐허가 되었다.\n&20\n옛 모습을 복원하고 싶다면,\n이 과정은 필연적으로 엄청난 시간과 비용이 필요합니다.\n게다가 낙양의 공안 상태도 열악했다.')
    stage.unit(22).setAction(6, 2)
    stage.say('&22\n곧 봉건 영주들은 천상의 아들을 환영하는 것의 가치를 깨닫게 될 것이다.')
    stage.say('&22\n우리는 수도를 주군의 영향권으로 옮겨야 합니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n나도 그렇게 생각해, 그러니까 수도를 쉬창으로 옮기자!\n그곳에 도착하면 다른 영주들을 두려워할 필요가 없습니다.\n&22\n저는 반대하지 않습니다.')
    stage.unit(0).setAction(17, 0)
    stage.say('&0\n알겠습니다! 바로 추모서 제출 준비하겠습니다.\n이 일이 해결되는 한,\n우리는 황제를 맞이하는 위대한 임무를 완수했습니다!\n&20\n네.\n&22\n네.')
    model.unitJoin(13, 0, 0)
    model.unitJoin(25, 0, 0)
    if vars[1013]:
        gvars[0] = 13
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 25
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.effectSound(202, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(149, 173, 76)
    stage.showHead(0, 237, 76)
    stage.bottomTxt('헌제는 수도를 이전조조 요청하는 청원을 승인했다.', False, False, False)
    stage.delay(8)
    stage.head(0).move(397, 111)
    stage.head(149).move(333, 111)
    stage.bottomTxt('한나라의 수도는 이후 조조가 다스리는 서창으로 옮겨졌다.\n그때부터 쉬창은 쉬두로 이름이 바뀌었다.', True, True, False)
    stage.delay(10)
    stage.bottomTxt('조조 이렇게 황제를 환영하는 위대한 임무를 완수했다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene3():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            49,
            40,
            2],
        [
            22,
            57,
            40,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.unit(0).setAction(3)
    stage.say('&0\n문약, 이제 황제가 환영받았으니,\n앞으로 캠페인에는 정당한 이유가 있을 것이다.\n&0\n모든 것이 우리가 예상한 대로 순조롭게 진행되었습니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n그래, 이제부터 주군의 적이 되는 자는\n법정에 대한 불복종을 의미합니다.')
    stage.unit(20).setAction(0)
    stage.say('&20\n세상을 지배하기 위해,\n진짜 전쟁이 시작되려 하고 있었다.')
    stage.say('&22\n영주들은 천상의 아들을 맞이하는 것의 중요성을 깨달았다,\n앞으로 그들은 분명히 우리에게 대규모 공세를 감행할 것이다.\n&0\n흠.')
    stage.unit(0).move(34, 59, 2)
    stage.say('&0\n첫 번째 가시는 여포,\n지금 상태는 어떠신가요?')
    stage.say('&22\n이제 여포 서저우로 도망쳤다,\n유비와 함께.')
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(3, 1)
    stage.say('&0\n뭐라고! 유비?!')
    model.setFace(2)
    stage.unit(0).setAction(2, 1)
    stage.say('&0\n이건 처리하기 쉽지 않아요,\n유비와 여포가 힘을 합친다면,\n그 힘은 두려움을 불러일으킬 정도다!')
    stage.say('&20\n주군 너무 걱정할 필요 없어.')
    stage.say('&20\n유비 부하들의 반대를 무시했다는 소문을 들었습니다,\n그녀는 여포을 받아들이겠다고 고집했다.')
    stage.say('&20\n그들 사이의 유대는 연약하다,\n곧 관계가 끊어질 거야.')
    model.setFace(0)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n다른 세력들도 중요한 움직임을 보이고 있나요?')
    stage.say('&22\n강둥의 손책은 꽤 눈에 띄네요,\n현재 중국은 영향력을 적극적으로 확장하고 있습니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n손책? "손견 아들이지?"\n손견 죽은 후에,\n그는 원술의 보호와 보호를 받아들였.......')
    stage.say("&22\n그는 이제 원술를 떠나 독립했다,\n거센 파도의 힘으로 강동을 지휘했다.\n&22\n요령 '작은 지배자'로 알려진 이 나라는 꽤 강력합니다,\n젊은 세대는 정말 강력하다고 할 수 있습니다.")
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n그래서 이렇게 ...... 있어요—진짜로, 호랑이 아버지가 개 아들처럼 강한 거죠.')
    stage.say('&20\n여포, 유비, 손책,\n그리고 원소, 원술, 그리고 다른 이들,\n그들은 모두 패권을 향한 길에 주군 강력한 적들이다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 336, 106)
    stage.showHead(32, 486, 132)
    stage.showHead(119, 550, 132)
    stage.bottomTxt('순욱가 말했듯이, 곧 그와 여포가 적이 된 after유비,', False, False, False)
    stage.delay(8)
    stage.head(32).move(400, 106)
    stage.head(119).move(492, 132)
    stage.delay(5)
    stage.bottomTxt('유비 여포에 의해 서저우에서 쫓겨나 조조에게 피신했다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            49,
            70],
        [
            32,
            49,
            55,
            3,
            6],
        [
            33,
            59,
            52,
            3],
        [
            3,
            59,
            58,
            3],
        [
            20,
            49,
            40,
            2],
        [
            22,
            55,
            40,
            2],
        [
            24,
            61,
            40,
            2],
        [
            21,
            67,
            40,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n현덕 공, 서주 전투 이후,\n아직 만난 적 없어.\n&32\n네.')
    stage.unit(0).setAction(0)
    stage.say('&0\n당신에 대해 다 들었어요,\n여포 쉬저우를 속였다고 들었지?')
    stage.unit(32).setAction(0)
    stage.say('&32\n그때 우리는 싸우고 있었원술,\n뜻밖에도 여포 이 상황을 이용했다.')
    stage.unit(0).move(34, 59, 2)
    stage.say('각하께서는 비록 서주를 잃으셨지만, 당신 같은 인물이라면 만약 의지할 곳이 없다면 너무 아깝습니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n나는 이미 폐하께 너를 위주 주지사로 추천했다,\n이제 취임할 수 있어.')
    stage.say('&32\n(뭐라고! )\n&33\n(응? )\n&3\n(조조 늙은 도둑은 뭘 꾸미고 있는 거지? )')
    stage.delay(3)
    stage.unit(32).setAction(6)
    stage.say('&32\n…… 선생님의 친절에 진심으로 감사드립니다.')
    stage.say('&0\n전혀 아니에요, 왜 그렇게 공손해요?')
    stage.unit(32).setAction(0)
    stage.say('&32\n그럼 바로 위저우로 가겠습니다.\n&0\n서두를 필요 없어요, 오늘은 모두를 위한 숙소를 준비해 두었어요,\n먼저 잠깐 쉬자.')
    stage.unit(32).setAction(6)
    stage.say('&32\n좋아.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(33),
            95,
            52,
            1],
        [
            stage.unit(3),
            95,
            58,
            1],
        [
            stage.unit(32),
            85,
            55,
            1]])
    stage.unit(33).hide()
    stage.unit(3).hide()
    stage.unit(32).move(95, 55, 1)
    stage.unit(32).hide()
    stage.delay(3)
    stage.unit(1).setAction(0, 3)
    stage.say('&1\n맹덕, 왜 그들을 그렇게 잘 대하지?')
    stage.unit(1).setAction(3, 3)
    stage.say('&1\n도겸를 공격할 때, 그들이 소란을 일으켰다,\n그냥 죽여야 한다고 생각해.')
    stage.say('&22\n정말로, 이 사람이 너무 위험유비\n그리고 앞으로는 분명 큰 재앙이 될 것입니다.\n&21\n네, 지금이 근본 원인을 제거하고 미래의 문제를 제거할 때입니다.')
    stage.unit(24).setAction(0, 3)
    stage.say('&24\n하지만.........\n만약 유비 아군에 모집된다면 어땠을까요?')
    stage.unit(22).setAction(0, 1)
    stage.say('&22\n이 생각은 그저 희망사항일 뿐입니다.\n유비 기발적으로 남보다 아래에 서는 사람이 아니다.')
    stage.unit(0).move(34, 55, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n……문약, 네 생각은 어떠냐?')
    stage.unit(24).setAction(0, 2)
    stage.unit(22).setAction(0, 2)
    stage.unit(1).setAction(0, 0)
    stage.delay(5)
    stage.unit(20).setAction(6)
    stage.say('&20\n유비 확실히 위험하지만, .......')
    stage.unit(20).setAction(0)
    stage.say('&20\n주군 유비 이미 세계적으로 유명한 인물이었다.\n&20\n우리가 유비를 죽인다면,\n사람들은 주군가 잔인한 악당이라고 생각할 수도 있겠죠.')
    stage.say('&0\n저도 문약 같은 생각이에요.')
    stage.say('&1\n하지만 .......')
    stage.say('&0\n원양, 유비 나랑 많이 비슷하지 않아?')
    stage.say('&1\n비슷한가요?')
    stage.unit(1).setAction(3, 0)
    stage.say('&1\n어떻게 닮았나요?')
    stage.unit(1).setAction(0, 0)
    stage.delay(5)
    stage.unit(0).move(31, 55, 3)
    stage.unit(0).setAction(0)
    stage.say('&0\n유비 류황제의 혈통을 이용하려면,\n저는 또한 매우 비슷한 천국의 아들(Son of Heaven)을 사용합니다.\n&21\n아니면 죽여야 할까!\n&22\n지금 유비 죽이지 않으면 미래 세대가 주님을 언급할 거야\n유비와 대중이 권력을 잡으면, 그들은 유비를 영웅으로 볼 것이다,\n주군 영웅이야!')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n미래 세대가 어떻게 생각하든 중요하지 않아요.')
    stage.unit(0).setAction(0, 3)
    stage.say('당신의 일에는 아직 관심이 없습니다.')
    stage.delay(3)
    stage.showUnit(181, 95, 55, 3)
    stage.say('&181\n신고됐어.')
    stage.unit(181).move(61, 55, 3)
    stage.say('&181\n방금 만청이 아군를 공격할 계획장수 있다는 소식을 들었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n뭐라고!\n&20\n이 말이 매우 사실일 가능성이 큽니다.\n장수 장지의 조카이자 동탁의 부하였다.\n그는 분명히 주군를 깊이 미워할 거예요.')
    stage.unit(0).move(34, 55, 1)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n정말로 자신을 과대평가하고 있다; 그가 공격할 때까지 기다릴 필요도 없다,\n먼저 공격하자.\n&20\n잠깐.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n무슨 일이야, 그문약?\n&20\n주군, 병력을 가볍게 발사하는 것은 너무 위험합니다.\n&20\n아군 쉽게 이사 간다면,\n여포 몇 년 전 푸양을 공격했을 때처럼,\n만약 그들이 다시 쉬두를 공격한다면, 어떻게 해야 할까?')
    model.setFace(2)
    stage.unit(0).setAction(2)
    stage.say('&0\n그건 사실이야.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(2, 2)
    stage.say('...하지만 장수는 그냥 둘 수는 없어.\n우리가 여포에게 금은과 관직을 주고,\n그가 유비와 화해하게 하는 건 어때?\n결국 유비는 주군이 통제하는 예주목이니까.\n여포가 유비와 사이좋게 지내기만 하면,\n여포가 주군을 공격하지 않을 거야.')
    model.setFace(0)
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠, 훌륭한 계획이네요.\n문약, 바로 처리할게.')
    stage.unit(0).setAction(17, 1)
    stage.say('&0\n문제가 해결되면 완청을 공격하라!')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n네.')
    stage.effectSound(200, 255)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 345, 110)
    stage.bottomTxt('이 시점에서,', False, False, False)
    stage.delay(5)
    stage.showHead(143, 262, 136)
    stage.delay(5)
    stage.bottomTxt('장수 완청을 점령했고,', True, False, False)
    stage.delay(5)
    stage.showHead(119, 489, 138)
    stage.delay(5)
    stage.bottomTxt('여포 그 후 쉬저우를 점령한다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('순욱 예상대로 여포 화해하기로 동의했다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('걱정 없는 조조 군대,', True, True, False)
    stage.delay(5)
    stage.head(0).move(326, 136)
    stage.delay(5)
    stage.bottomTxt('그리하여 그들은 완시에 대한 전면적인 공격을 개시할 수 있었다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene5():
    stage.loadBg(2, 48)
    stage.showUnits([
        [
            143,
            53,
            31,
            2],
        [
            23,
            53,
            48,
            0,
            6]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('완 장수 맨션')
    stage.say('&143\n뭐라고! 조조 먼저 군대를 보냈어!\n&23\n네.')
    stage.unit(143).move(49, 31, 3)
    stage.say('&143\n흠.......')
    stage.unit(143).setAction(0, 2)
    stage.say('&143\n원허, 이 싸움에서 이길 가능성이 있나?\n&23\n조의 군대는 전투에 경험이 풍부한 정예 부대였다.\n우린 이길 기회가 없어.')
    stage.unit(143).setAction(2, 2)
    stage.say('&143\n흠.......\n&23\n주군, 항복할 수밖에 없는 것 같아.')
    stage.unit(143).setAction(0, 2)
    stage.say('&143\n복수는 못 하겠지?\n&23\n전투에서 싸우면 헛되이 목숨을 잃게 될 뿐이야,\n우리는 참아내고 적절한 순간을 기다려야 합니다.')
    stage.unit(143).setAction(0, 3)
    stage.delay(5)
    stage.say('&143\n…… 음, 항복할 수밖에 없어.')
    stage.unit(143).setAction(0, 1)
    stage.delay(3)
    stage.unit(143).move(53, 31, 1)
    stage.delay(3)
    stage.unit(143).setAction(0, 2)
    stage.say('&143\n원허, 너는 사절로 가서 조의 진영에 가서 항복하라.\n&23\n네.')
    stage.effectSound(200, 255)
    stage.delay(3)
    stage.bgSound(15)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1],
        [
            16,
            38,
            46,
            1],
        [
            13,
            38,
            40,
            1],
        [
            20,
            60,
            52,
            3],
        [
            22,
            60,
            46,
            3],
        [
            18,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('완 외곽, 조조군의 본진')
    stage.unit(0).setAction(3)
    stage.say('&0\n곧 완청에 도착했다,\n한 번에 반드시 잡아야 해!')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 9, [
        16,
        12])
    gvars[4076] = 0
    gvars[4057] = 10
    stage.setBattlePos([
        [
            12,
            8],
        [
            20,
            8],
        [
            1,
            8],
        [
            14,
            6],
        [
            13,
            11],
        [
            10,
            9],
        [
            1,
            10],
        [
            0,
            8],
        [
            1,
            7],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene6():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        return True
    if stage.unitClickTest(13):
        stage.say('&13\n나는 궁수 부대를 이끌었다.\n그런데 만총은 풍수 대가지?')
    if stage.unitClickTest(20):
        stage.say('&20\n최근에 장수 그의 곁에 자원 활용 가능한 전략가가 있다고 들었어.\n&0\n그래? 전략가.......')
    if stage.unitClickTest(1):
        stage.say('&1\n반드시 장수 목을 베어 모두에게 보여줄 거야!')
    if stage.unitClickTest(22):
        stage.say('&22\n완청이 번성하고 활기차다고 들었어.\n&22\n정말 믿기 힘들다,\n장수 내부 감찰 관리 재능을 가지고 있습니다.')
    if stage.unitClickTest(16):
        stage.say('전위. 거기! 어, 아무것도 아니야... 어떻게 됐어? 무슨 생각이라도 있는 것 같네. (무슨 일이지...? 전위가 나를 떠나려는 것 같은 기분이 들어...)')
    if stage.unitClickTest(18):
        stage.say('&18\n소품만으로도 충분한가요?')
    return False


def scene7():
    stage.showUnit(181, 49, 16, 3)
    stage.say('&181\n신고됐어.')
    stage.unit(181).move(49, 46, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&0\n무슨 일이야? 곧 출발할 거야.\n&181\n…… 완청에서 사절단이 도착해 항복했다.\n&0\n뭐라고?')
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('...좋아, 데려와라.\n예. 안녕하십니까.')
    stage.unit(181).setAction(0, 2)
    stage.delay(3)
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.showUnit(23, 49, 16, 2)
    stage.say('&23\n안녕하세요.')
    stage.unit(0).setAction(0, 0)
    stage.unit(23).move(49, 52, 2)
    stage.delay(3)
    stage.unit(23).setAction(6, 2)
    stage.delay(3)
    stage.say('&0\n나는 조조이고, 당신이 항복을 요청하러 온 사절장수 맞습니까?\n&23\n네.\n&23\n우리는 무장 해제를 할 계획입니다,\n그리고 완청을 조 재상에게 넘겼다.\n&23\n주군장수 너를 대면할 생각은 없었어.\n&23\n제발, 무슨 일이 있어도 장수주군를 관대하게 대해줘,\n총리께서 자비를 베풀어 주시길 바랍니다.')
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.say('&0\n흠.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n음, 장수의 요청에 동의할게.\n&23\n감사합니다, 선생님.\n&0\n사절, 이름이 뭐죠?\n&23\n아래, 가후.')
    stage.unit(0).setAction(3, 0)
    stage.say('&0\n뭐라고? 너 가후 자원허야?')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n한때 두 명의 무서운 장군, 여포과 마텅을 물리쳤죠,\n왜 지금 싸움 없이 항복했을까......?\n&23\n이 두 사람은 용감했지만 전략이 부족했다,\n하지만 당신처럼 현명하고 용감한 사람을 상대할 때는,\n내 재능은 훨씬 뒤처져.')
    model.setFace(3)
    stage.unit(0).setAction(3, 1)
    stage.say('하하하.')
    model.setFace(0)
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n좋아, 돌아가서 말해장수,\n이번에는 더 이상 추격하지 않겠습니다.\n&23\n감사합니다, 총리님. 저는 이만 가보겠습니다.')
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).move(49, 16, 0)
    stage.unit(23).hide()
    stage.say('&0\n문약, 가후 전설처럼 이 사람이 능력 있는 사람 아니야?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군, 이 사람을 과소평가하면 안 돼.')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n네, 이 사람을 절대 부주의해서는 안 됩니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠.......')
    stage.effectSound(200, 255)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(0, 36)
    stage.draw()
    stage.info('조조 항복장수 동의하고 경호원들과 함께 완청에 들어갔다.')
    stage.info('조조 단 한 명의 병사도 없이 완청을 점령했다,\n지금은 완성에서 여유롭게 쉬고 있다.')
    stage.bgSound(-1)
    return False


def scene8():
    stage.loadBg(2, 39)
    stage.showUnits([
        [
            0,
            68,
            59,
            1,
            1],
        [
            30,
            68,
            49,
            2,
            1]])
    stage.draw()
    stage.setStageName('완 파빌리온')
    stage.say('&30\n삼촌, 완청은 꽤 매력적인 곳이에요.')
    model.setFace(3)
    stage.say('&0\n흠.')
    model.setFace(0)
    stage.say('&0\n응?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).move(55, 59, 3)
    stage.delay(1)
    stage.unit(0).move(55, 65, 2)
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(30).setAction(0)
    stage.say('&30\n삼촌, 무슨 일이에요?')
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('안민, 후가의 현음을 들었느냐?\n아?')
    stage.unit(30).move(55, 49, 3)
    stage.delay(3)
    stage.unit(30).setAction(0, 2)
    stage.say('&30\n목소리가 꽤 ......고 아름답네요.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n톤이 정말 훌륭합니다...\n이런 일은 정말 전례가 없습니다.')
    stage.unit(30).move(55, 55, 2)
    stage.say('&30\n삼촌, 나 생각 중이야.........\n후지아를 연기하는 사람이 조우 가문 출신일까?')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n조우 부인? 그녀는 장지의 아내였어,\n비할 데 없는 미녀로 칭송받는 조우 가문?\n&30\n맞아. 장지가 죽은 후,\n그녀는 조카에게 의지해 장수었다.\n&30\n그녀가 아름답다고 들었어,\n아니면 후가를 잘 연주하는 실력자인가요......')
    stage.say('&0\n오?\n&30\n삼촌, 그냥 조우 부인을 여기로 데려오면 어떨까요?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그렇게 말할 ...... 있었다.')
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('좋아, 빨리 데려와.\n그만둬, 하지 않는 게 낫지.', -1)
    if sel == 1:
        vars[304] = 1
        stage.addAmbition(10)
        stage.bgSound(-1)
        stage.say('좋습니다. 그녀를 데려가십시오…\n좀 더 예의 있게 하십시오.\n&30\n네입니다.')
        stage.unit(30).move(55, 30, 0)
        stage.unit(0).setAction(0, 2)
        stage.unit(30).hide()
        stage.info('잠시 후에, .......', 3)
        stage.say('&30\n삼촌, 제가 그녀를 여기 데려왔어요.')
        stage.unit(0).setAction(0, 0)
        stage.showUnit(30, 55, 30, 2)
        stage.unit(30).move(55, 40, 2)
        stage.delay(3)
        stage.unit(30).setAction(0, 0)
        stage.delay(3)
        stage.say('&30\n이쪽으로 오세요.\n&156\n그리고 총리에게 경의를 표했다.')
        stage.showUnit(156, 55, 30, 2)
        stage.unitsMove([
            [
                stage.unit(30),
                65,
                40,
                1],
            [
                stage.unit(156),
                55,
                40,
                2]])
        stage.delay(3)
        stage.unit(30).setAction(0, 2)
        stage.say('&30\n이 신사는 조맹덕이었다.')
        model.setFace(3)
        stage.unit(0).setAction(3, 0)
        stage.say('&0\n오, 기다리고 있어.')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(30).setAction(0, 2)
        stage.unit(0).move(55, 60, 0)
        stage.delay(1)
        stage.unit(0).move(72, 60, 1)
        stage.delay(3)
        model.setFace(0)
        stage.unit(0).setAction(0, 3)
        stage.say('&0\n이리 와, 제발.\n&156\n네.')
        stage.delay(3)
        stage.unit(156).move(55, 60, 2)
        stage.delay(1)
        stage.unit(0).setAction(0, 3)
        stage.unit(156).setAction(0, 1)
        stage.unit(156).move(62, 60, 1)
        stage.delay(10)
        stage.say('&30\n삼촌, 조앙과 저는 아직 처리할 일이 있습니다,\n그럼 일단 물러날게.\n&0\n흠.')
        stage.unit(30).move(55, 40, 3)
        stage.delay(1)
        stage.unit(30).move(55, 30, 0)
        stage.unit(30).hide()
        stage.delay(3)
        stage.unit(0).setAction(1, 3)
        stage.unit(156).setAction(1, 1)
        stage.delay(3)
        stage.say('부인, 당신이 연주하는 호가는 너무나 아름답군요....\n대인께서 아껴주시네요.')
        stage.unit(0).setAction(1, 2)
        stage.say('&0\n여기서 한 곡 연주해 주실 수 있나요?\n&156\n이건 .......')
        stage.unit(156).setAction(8, 1)
        stage.delay(10)
    elif sel == 2:
        vars[304] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n됐어, 이럴 필요 없어.')
        stage.unit(0).setAction(0, 1)
        model.setFace(3)
        stage.say('&0\n그냥 먼 음악을 듣고,\n반대편에서 술을 마시는 것도 좋다.\n&30\n네.')
        model.setFace(0)
    stage.clsUnit()
    return False


def scene9():
    stage.loadBg(2, 48)
    stage.showUnits([
        [
            143,
            53,
            30,
            2],
        [
            23,
            53,
            48,
            0,
            6]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('완 장수 맨션')
    if vars[304]:
        stage.delay(3)
        stage.unit(143).setAction(2)
        stage.say('&143\n뭐야!! 조조와 조우 부인?\n&23\n네, 술 한 잔 하라는 요청을 받았어요.')
        stage.unit(143).move(49, 30, 3)
        stage.delay(3)
        stage.unit(143).setAction(2)
        stage.say('&143\n개자식! 어떻게 감히 도시에서 나를 창피하게 만들다니,\n"너는 장가의 여자들을 노골적으로 괴롭히고 있어!"')
        stage.unit(143).setAction(0, 2)
        stage.delay(3)
        stage.unit(143).setAction(2, 2)
        stage.say('&143\n조, 늙은 도둑! 절대 용서하지 않을 거야!\n&23\n네 기분을 이해해,\n하지만 진정하자.\n&23\n조조Although 내가 지금 부주의하다면,\n그의 군대는 여전히 강력했다,\n&23\n만약 직접 대결이 벌어진다면, 아군 이길 가능성은 전혀 없다.')
        stage.unit(23).setAction(0, 0)
        stage.delay(5)
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n사실 계획이 있어.')
        stage.unit(143).setAction(0)
        stage.say('&143\n뭐라고?')
        stage.unit(23).setAction(0, 0)
        stage.say('&23\n지금 조조를 지키는 자는 전위,\n그래서 먼저 그가 제거되어야 했다.')
        stage.unit(143).move(53, 30, 2)
        stage.say('&143\n하지만 전위 군대에서 두드러진 강인한 장군입니다.')
        stage.unit(23).setAction(6, 0)
        stage.say('&23\n걱정 마, 이미 그를 처리할 방법이 있어.')
        stage.unit(23).setAction(0, 0)
        stage.delay(3)
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n후처얼? 후처얼은 어디 있어!?')
    if not vars[304]:
        stage.delay(3)
        stage.unit(143).setAction(2)
        stage.say('&143\n젠장, 조가 이 배신자를 숨기고 있어!')
        stage.unit(23).setAction(0)
        stage.say('&23\n주군 이 말이 너무 거칠게 들릴 수도 있어요.\n&143\n원허, 내가 어떻게 거칠지 않을 수 있겠어?\n이 한 화살을 복수하지 못한다면,\n어떻게 조상들을 마주할 수 있겠어!')
        stage.unit(143).move(49, 30, 3)
        stage.delay(3)
        stage.unit(143).setAction(2)
        stage.say('&143\n원허, 이 굴욕을 더 이상 참을 수 없어.\n도둑 조와 끝까지 싸울 거야!')
        stage.unit(23).setAction(6)
        stage.say('&23\n네 기분을 이해해,\n하지만 진정하자.\n&23\n조조Although 내가 지금 부주의하다면,\n그의 군대는 여전히 강력했다.\n&23\n만약 직접 대결이 벌어진다면, 아군 이길 가능성은 전혀 없다.')
        stage.unit(23).setAction(0, 0)
        stage.delay(3)
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n사실 계획이 있어.')
        stage.unit(143).setAction(0, -1)
        stage.delay(3)
        stage.unit(143).setAction(0, 2)
        stage.say('&143\n뭐라고?')
        stage.unit(23).setAction(0, 0)
        stage.say('&23\n지금 조조를 지키는 자는 전위,\n그래서 먼저 그가 제거되어야 했다.\n&143\n하지만 전위 군대를 지휘하는 강인한 장군이다.')
        stage.unit(23).setAction(6, 0)
        stage.say('&23\n걱정 마, 이미 그를 처리할 방법이 있어.')
        stage.unit(23).setAction(0, 0)
        stage.delay(3)
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n후체얼! 후체얼은 어디 있어!?')
    stage.showUnit(144, 53, 98)
    stage.say('&144\n나한테 전화했어?')
    stage.unit(144).move(53, 58, 0)
    stage.say('&23\n흠.\n&23\n후체얼, 내 명령대로 해라,\n연회를 열고 전위들을 환대하며 접대하라,\n그럼 그의 무기를 빼앗아.\n&144\n그래! 오늘 밤, 내가 움직일 거야.\n&23\n흠.')
    stage.unit(144).move(53, 98, 2)
    stage.unit(144).hide()
    stage.delay(3)
    stage.unit(23).setAction(0, 0)
    stage.say('&23\n주군, 후처얼이 보고할 때,\n또 한 번 기습 공격을 시작합시다.\n&143\n흠.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    stage.loadBg(2, 48)
    stage.showUnits([
        [
            143,
            53,
            30,
            2],
        [
            23,
            53,
            48]])
    stage.draw()
    stage.info('그날 밤, .......', 3)
    stage.setStageName('완 장수 맨션')
    stage.say('&143\n후처얼은 아직 돌아오지 않았나요?\n군대는 이미 준비되어 있었다.\n&23\n곧 돌아올 거야.')
    stage.showUnit(144, 53, 98)
    stage.say('&144\n보고해!')
    stage.unit(23).setAction(0, 2)
    stage.unit(144).move(53, 58, 0)
    stage.say('&23\n후처얼, 잘 되고 있니?\n&144\n네.')
    stage.unit(23).move(53, 50, 2)
    stage.say('&23\n잘했어요!\n이제 배신자 조를 제거할 수 있겠군!')
    stage.unit(143).setAction(17, 2)
    stage.say('&143\n좋아, 가자!')
    stage.clsUnit()
    return False


def scene10():
    stage.loadBg(2, 39)
    stage.showUnits([
        [
            0,
            68,
            59,
            0,
            1],
        [
            30,
            68,
            49,
            2,
            1]])
    stage.draw()
    stage.setStageName('완 파빌리온')
    stage.delay(3)
    stage.unit(0).setAction(1, 1)
    stage.say('&0\n응? 말발굽 소리는 어디서 났지......')
    stage.showUnit(31, 55, 30, 2)
    stage.say('&31\n아버지!')
    stage.effectSound(207, 0)
    stage.delay(3)
    stage.unit(0).setAction(1, 3)
    stage.unit(30).setAction(1, 3)
    stage.unit(31).move(55, 59, 2)
    stage.delay(3)
    stage.unit(31).setAction(2, 1)
    stage.say('&31\n아버지, 뭔가 이상해요!')
    stage.unit(30).setAction(0, 3)
    stage.unit(0).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).move(67, 59, 3)
    stage.say('&0\n무슨 일이야? 조앙!\n&31\n아버지, 배신당장수 있습니다!')
    model.setFace(2)
    stage.unit(0).setAction(2, 3)
    stage.say('&0\n뭐라고!?')
    stage.unit(31).setAction(0, 1)
    stage.say('&31\n이 정자는 이미 적군에 둘러싸여 있다,\n아버지, 빨리 도망가세요!')
    model.setFace(0)
    stage.unit(0).setAction(0, 3)
    stage.say('전위는 어떻게 됐어? 전위가 아버지 길을 열기 위해 필사적으로 싸우고 있어.')
    model.setFace(2)
    stage.unit(0).setAction(2, 3)
    stage.say('&0\n젠장! 장수 아이를 정말 과소평가했어!\n&31\n아버지, 저와 함께 가세요, 시간이 촉박합니다!')
    model.setFace(0)
    stage.unit(0).setAction(0, 3)
    stage.say('좋습니다. 모두 맡겨라, 조앙!')
    stage.unitsMove([
        [
            stage.unit(31),
            55,
            47,
            0],
        [
            stage.unit(0),
            55,
            59,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(31),
            55,
            30,
            0],
        [
            stage.unit(0),
            55,
            42,
            0]])
    stage.unit(31).hide()
    stage.unitsMove([
        [
            stage.unit(0),
            55,
            30,
            0],
        [
            stage.unit(30),
            55,
            49,
            3]])
    stage.unit(0).hide()
    stage.unit(30).move(55, 30, 0)
    stage.unit(30).hide()
    stage.delay(3)
    stage.effectSound(207, 255)
    stage.clsUnit()
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
