# Source Generated with Decompyle++
# File: R_15.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(17)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            32,
            35,
            52,
            1],
        [
            3,
            35,
            46,
            1],
        [
            20,
            63,
            52,
            3],
        [
            22,
            63,
            46,
            3]])
    stage.draw()
    stage.setEventName('안녕! 사랑하는 여인')
    stage.setStageName('샤피 외곽, 조조군의 본군 진영')
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n여포 이미 그를 자신의 텐트로 데려갔다.\n&0\n흠.')
    stage.unit(181).move(49, 21, 2)
    stage.showUnit(119, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            26,
            2],
        [
            stage.unit(119),
            49,
            21,
            2]])
    stage.showUnit(182, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            52,
            2],
        [
            stage.unit(119),
            49,
            47,
            2],
        [
            stage.unit(182),
            49,
            42,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            43,
            52,
            3],
        [
            stage.unit(119),
            49,
            52,
            2],
        [
            stage.unit(182),
            49,
            47,
            2]])
    stage.delay(1)
    stage.unit(181).setAction(0, 2)
    stage.unit(182).move(55, 47, 1)
    stage.delay(1)
    stage.unit(182).move(55, 52, 2)
    stage.say('&0\n여포, 너와 나의 싸움은 드디어 끝났어.\n&119\n......조조, 부탁이 있어.\n&119\n내 머리는 네게 맡길게,\n하지만 네가 초선 놓아주길 바래.')
    if vars[302]:
        stage.say('초선이라……?')
    if not vars[302]:
        stage.say('&0\n그녀가 대중 대신인 왕윤 장관의 딸인가요......')
    stage.say('&119\n제발.........\n&0\n…… 약속할게.\n&119\n감사합니다.')
    stage.say('&119\n이게 내가 남은 소원의 전부야.')
    stage.unit(119).setAction(3)
    stage.say('&119\n자, 날 죽여!')
    stage.unit(119).setAction(0)
    stage.say('&0\n처형장으로 호위여포 즉시 참수하라!\n&181\n네.')
    stage.unitsMove([
        [
            stage.unit(181),
            46,
            52,
            1],
        [
            stage.unit(182),
            52,
            52,
            3]])
    stage.delay(5)
    stage.unit(119).move(49, 50, 0)
    stage.say('&119\n초선.............')
    stage.unitsMove([
        [
            stage.unit(119),
            49,
            16,
            0],
        [
            stage.unit(181),
            46,
            21,
            0],
        [
            stage.unit(182),
            52,
            21,
            0]])
    stage.unit(119).hide()
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.unit(182).move(49, 16, 0)
    stage.unit(182).hide()
    stage.delay(10)
    stage.effectSound(36, 1)
    stage.delay(10)
    stage.say('&0\n…………。')
    stage.delay(10)
    return False


def scene1():
    stage.delay(5)
    stage.showUnit(181, 49, 16, 2)
    stage.delay(3)
    stage.unit(181).move(49, 21, 2)
    stage.showUnit(17, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            26,
            2],
        [
            stage.unit(17),
            49,
            21,
            2]])
    stage.showUnit(182, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            52,
            2],
        [
            stage.unit(17),
            49,
            47,
            2],
        [
            stage.unit(182),
            49,
            42,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            43,
            52,
            3],
        [
            stage.unit(17),
            49,
            52,
            2],
        [
            stage.unit(182),
            49,
            47,
            2]])
    stage.delay(1)
    stage.unit(181).setAction(0, 2)
    stage.unit(182).move(55, 47, 1)
    stage.delay(1)
    stage.unit(182).move(55, 52, 2)
    stage.say('&181\n적군 장군이 그를 데려왔초선.')
    stage.say('초선아. 왕 어른 댁을 떠난 지 벌써 몇 년이나 되었니? 응....')
    stage.unit(17).setAction(6)
    stage.say('&17\n조 공, 봉선 ......?\n&0\n이미 참수당했다.')
    stage.unit(17).setAction(0)
    stage.say('&17\n…………。')
    stage.unit(0).setAction(0, 1)
    stage.say('봉선이 마지막으로 바라는 것은, 나를 용서해 달라는 것이었어.')
    stage.unit(0).setAction(0, 0)
    stage.say('초선아, 나를 따라와.')
    stage.say('&17\n초선 이해했다..........')
    stage.say('&17\n하지만 조 공, 단 한 가지 부탁이 있습니다,\n내 말에 동의할 수 있겠어?\n&0\n무슨 일이야?')
    stage.say('&17\n봉선 머리 좀 건네줄래?\n그의 영혼을 애도하고 싶어.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n알겠어......... 좋아.\n약속할게.')
    stage.unit(17).setAction(6)
    stage.say('&17\n감사합니다, 선생님.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n먼저 쉬어야 해.\n&17\n네.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n머물 곳을 초선 줘.\n&181\n네, 명령에 따르세요!')
    stage.unitsMove([
        [
            stage.unit(17),
            49,
            16,
            0],
        [
            stage.unit(181),
            43,
            26,
            0],
        [
            stage.unit(182),
            55,
            26,
            0]])
    stage.unit(17).hide()
    stage.unit(181).move(49, 26, 1)
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            20,
            0],
        [
            stage.unit(182),
            49,
            26,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            16,
            0],
        [
            stage.unit(182),
            49,
            22,
            0]])
    stage.unit(181).hide()
    stage.unit(182).move(49, 16, 0)
    stage.unit(182).hide()
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    model.unitJoin(17, 0, 0)
    if vars[1013]:
        gvars[0] = 17
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene2():
    stage.delay(10)
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n장료 가져왔어.\n&0\n흠.')
    stage.unit(181).move(49, 21, 2)
    stage.showUnit(2, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            26,
            2],
        [
            stage.unit(2),
            49,
            21,
            2]])
    stage.showUnit(182, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            52,
            2],
        [
            stage.unit(2),
            49,
            47,
            2],
        [
            stage.unit(182),
            49,
            42,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            43,
            52,
            3],
        [
            stage.unit(2),
            49,
            52,
            2],
        [
            stage.unit(182),
            49,
            47,
            2]])
    stage.delay(1)
    stage.unit(181).setAction(0, 2)
    stage.unit(182).move(55, 47, 1)
    stage.delay(1)
    stage.unit(182).move(55, 52, 2)
    stage.unit(0).setAction(3)
    stage.say('&0\n정말 기뻐, 원위안.\n네가 내 파벌에 합류할 줄은 몰랐어.\n&0\n원위안, 알고 있니.........\n난 항상 널 영입하고 싶었어.\n&2\n…… 뤼 장군이 참수되었나요?')
    stage.unit(0).setAction(0)
    stage.say('&0\n네.\n&2\n루 장군은 죽기 전에 뭐라고 했나요?\n&0\n그냥 나한테 초선 보내달라고 해.')
    stage.unit(2).setAction(0, 1)
    stage.say('&2\n......로 무엇을 하실 건가요, 선생님?\n&0\n이것이 장군의 마지막 소원입니다,\n물론 동의했지.\n&2\n정말......?')
    stage.unit(2).setAction(0, 2)
    stage.delay(3)
    stage.unit(2).setAction(6)
    stage.say('&2\n그렇다면 저는 반대장료 없습니다.\n이제부터 나는 총리님께 최고의 충성과 봉사로 봉사할 것이다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n흠!\n원위안, 네가 그렇게 말해주길 기다렸어.\n&2\n네. (장군 여포,\n초선 맡겨.\n평안히 쉬길 바랍니다......... )')
    stage.unit(0).setAction(0)
    stage.say('&0\n좋아, 너도 피곤하겠지.\n일찍 내려가서 쉬어.\n&2\n네.')
    stage.unit(2).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(2),
            49,
            16,
            0],
        [
            stage.unit(181),
            43,
            26,
            0],
        [
            stage.unit(182),
            55,
            26,
            0]])
    stage.unit(2).hide()
    stage.unit(181).move(49, 26, 1)
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            20,
            0],
        [
            stage.unit(182),
            49,
            26,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            16,
            0],
        [
            stage.unit(182),
            49,
            22,
            0]])
    stage.unit(181).hide()
    stage.unit(182).move(49, 16, 0)
    stage.unit(182).hide()
    stage.bgSound(-1)
    stage.effectSound(203, 0)
    stage.delay(3)
    model.unitJoin(2, 0, 0)
    if vars[1013]:
        gvars[0] = 2
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.say('&0\n현덕 경.')
    stage.unit(32).move(49, 52, 1)
    stage.delay(3)
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n네.')
    stage.say('&0\n네 군대가 나를 따라 쉬두로 돌아가길 바란다.')
    stage.say('&0\n그리고 나와 함께 폐하를 뵙러 가라,\n그리고 반란군에 대한 대승을 보고했다.')
    stage.say('&32\n폐하를 뵙...... 건가?')
    stage.say('&32\n유비 이해했어.')
    stage.unit(0).setAction(3)
    stage.say('좋습니다, 모두 고생하셨습니다.\n오늘은 충분히 쉬겠습니다,\n내일 승리로 돌아와 허도로 귀환하겠습니다.')
    stage.unit(0).setAction(0)
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(19)
    stage.delay(3)
    stage.loadBg(2, 61)
    stage.showUnit(0, 55, 61, 3)
    stage.draw()
    stage.setStageName('쉬두, 향부 정원')
    stage.showUnit(20, 90, 69, 3)
    stage.unit(20).move(61, 69, 3)
    stage.unit(20).setAction(0)
    stage.say('&20\n주군.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n문약 응?\n아직도 쉬지 않아?')
    stage.unit(20).setAction(6)
    stage.say('&20\n주군 일찍 쉬어야 .......')
    stage.unit(20).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n잠이 안 와.')
    stage.unit(20).setAction(6)
    stage.say('&20\n주군 아직도 여포 생각하고 있어?')
    stage.unit(20).setAction(0)
    stage.delay(8)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n……문약, 너는 어떻게 생각하느냐?\n그게 정말 여포의 마지막 소원인가?')
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n이 사람은 .........,\n하지만 그는 온전히 오직 초선만 생각할 수 있다,\n이 모든 게 단지 한 여자 때문이야!\n&0\n이 때문에 그들은 모든 것을 잃었을 뿐만 아니라,\n장군이라는 이상조차 .......')
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 장군이 정의를 위해 살 수 있다면,\n물론, 사랑하는 것을 위해 싸울 수도 있습니다.')
    stage.unit(20).setAction(0)
    stage.say('&20\n그래서 저는 여포 행복한 사람이라고 생각해요.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n사랑하는 사람들만을 위한 건가요?\n글쎄, 그건 못 할 것 같아.')
    stage.unit(20).setAction(6)
    stage.say('&20\n속담에 있듯이, 모든 사람은 각자의 야망이 있습니다.')
    stage.unit(20).setAction(0)
    stage.delay(8)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n네...... 맞아요.\n여포 자신의 열망을 위해 죽는다,\n나도 내 야망을 위해 싸울 것이다.')
    stage.delay(8)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(16)
    stage.delay(3)
    stage.sectionName(2, '허베이를 둘러싼 분쟁')
    stage.loadBg(1, 0)
    stage.draw()
    stage.setEventName('공격 유비')
    stage.delay(10)
    stage.showHead(0, 496, 124)
    stage.showHead(32, 496, 204)
    stage.showHead(119, 560, 164)
    stage.delay(5)
    stage.bottomTxt('세계에서 비할 데 없는 여포이 샤피에서 죽었고,', False, False, False)
    stage.delay(5)
    stage.head(119).hide()
    stage.delay(10)
    stage.head(0).move(300, 116)
    stage.head(32).move(364, 116)
    stage.bottomTxt('조조와 유비은 승리의 기분으로 서두로 돌아와 황제 앞에 자신들을 소개했다.', True, True, False)
    stage.delay(12)
    stage.showHead(149, 332, 36)
    stage.delay(5)
    stage.bottomTxt("헌제는 유비가 한나라 가문의 일원임을 알게 되어 매우 기뻐하며 유비를 '황실 삼촌'이라고 불렀다.", True, True, True)
    stage.bgSound(-1)
    return False


def scene5():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            32,
            50,
            40,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.showUnit(25, 95, 55, 3)
    stage.say('&25\n보고해.')
    stage.unit(25).move(48, 55, 3)
    stage.unit(25).setAction(0)
    stage.delay(3)
    stage.unit(25).setAction(6)
    stage.say('&25\n만총이 무례했어.')
    stage.unit(0).setAction(3)
    stage.say('&0\n오, 버닝.\n너를 여기저기 정찰하러 보내는 건 정말 힘든 일이야.')
    stage.say('&25\n셰 주군.')
    stage.unit(0).setAction(0)
    stage.say('&0\n어때?\n여러 곳에서 움직임이 있나요......?')
    stage.unit(25).setAction(0)
    stage.say('&25\n답변 주군.')
    stage.say('&25\n북평의 공손찬은 원소 제거되었다.')
    stage.unit(32).setAction(3)
    stage.say('&32\n응?\n......공손찬 ...... 완전히 전멸했다고!?')
    stage.unit(25).setAction(0, 0)
    stage.say('&25\n네.')
    stage.unit(32).setAction(0)
    stage.say('&32\n정말............?')
    stage.say('맞다. 유 대인께서 공손찬 밑에서 잠시 지내셨었죠? 예. 비록 성한 자는 쇠퇴하기 마련이지만, 그의 불행은 정말 안타깝습니다. 음.')
    stage.say('백녕, 다른 상황은 어떻습니까?')
    stage.unit(25).setAction(0, 3)
    stage.say('&25\n루난에서 온 원술은 북쪽으로 가야 한다.\n&0\n원술?')
    stage.unit(0).setAction(0, 2)
    stage.say('원소에게 의탁하려는 건가? 아마도 그럴 것 같군……')
    stage.unit(0).move(34, 59, 2)
    stage.say('&0\n이건 좋지 않아. 원술 언급할 가치가 없을 수도 있어,\n하지만 원소 강점이 강화된다면 훨씬 더 어려워질 것이다.\n&32\n………….')
    stage.unit(0).move(34, 55, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n절대 원술가 북쪽으로 가는 것을 허락할 수 없습니다.')
    stage.unit(0).setAction(17, 1)
    stage.say('그가 원소에게 투항하기 전에, 그를 제거해야 합니다!')
    stage.unit(32).setAction(6, 2)
    stage.say('&32\n잠시만 기다려 주세요.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n응?\n현덕 주인, 무슨 일입니까?')
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n조 총리님, 제가 가서 원술를 벌할까요?\n&0\n너는?\n&32\n네.')
    stage.say('&32\n원술와 원소는 가족이야,\n원술를 제거하면 원소 공격할 수 있습니다,\n또한 보귀의 복수를 위한 방법이기도 했다.\n&0\n음, 그렇구나, 그렇구나..........')
    stage.effectSound(200, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('맡기유비\n폐를 끼칠 필요 없yourself유비', 0)
    if sel == 1:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.unit(0).setAction(3, 1)
        stage.say('&0\\n좋습니다! 바로 당신을 파견하겠습니다.\\n&32\\n감사합니다, 총상님.')
    elif sel == 2:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.say('&0\n현덕 주인, 걱정하지 마십시오.\n첫째, 당신은 이제 황실 삼촌입니다,\n폐하께서 당신을 매우 좋아하십니다.\n&0\n만약 네가 원술를 벌한다면,\n폐하께서 외로우실 거예요.\n&32\n안 돼! 어쨌든 이 일은 유비에게 맡겨.\n&32\n적은 거짓 황제원술 내가 가서 벌하겠다,\n폐하께서 분명히 기뻐하실 것입니다.\n&0\n흠......... 좋아.\n그렇게 고집하니까,\n네가 맡길게.\n&32\n그리고 총리님께 감사드립니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n시간이 없으니 병사와 군수품을 빌려주겠다,\n바로 출발합시다.')
    stage.unit(32).setAction(6, 2)
    stage.say('&32\n네, 바로 준비하겠습니다.\n&0\n흠.')
    stage.effectSound(200, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 323, 100)
    stage.showHead(32, 387, 100)
    stage.delay(8)
    stage.showHead(136, 351, 188)
    stage.bottomTxt('루난에서 원술 완전히 패배했고 회복하지 못했다,', False, False, False)
    stage.delay(5)
    stage.head(136).move(451, 188)
    stage.head(136).move(479, 56)
    stage.bottomTxt('그는 이후 이복형 원소에게 피신하러 갔다.', True, False, False)
    stage.delay(5)
    stage.head(32).move(415, 56)
    stage.bottomTxt('하지만 북쪽으로 가는 길에,', True, True, False)
    stage.delay(5)
    stage.head(136).hide()
    stage.delay(5)
    stage.bottomTxt('조조에서 병력을 빌린 유비들에게 살해당했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('원술 죽은 직후, 유비.......', True, True, True)
    stage.bgSound(-1)
    return False


def scene6():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            6,
            58,
            70],
        [
            18,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.showUnit(181, 95, 55, 3)
    stage.say('&181\n보고해!')
    stage.unit(181).move(48, 55, 3)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 방금 통지를 받았어,\n쉬저우는 유비군에 점령당했다.')
    model.setFace(2)
    stage.unit(0).setAction(2)
    stage.say('&0\n뭐라고!?\n&22\n유비 쉬저우 ......를 점령했나?\n&181\nMoreover유비 원소와 동맹을 맺었다.\n&21\n뜻밖에도 그는 원술를 죽였다,\n심지어 원술의 형과 동맹을 맺기도 했다,\n이런 외교적 전술은 정말 영리하다.')
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(2)
    stage.say('&0\n정말 미운 유비!\n어떻게 감히 나를 속이냐!\n그저 배신으로 친절을 갚는 것뿐이에요!')
    stage.unit(0).move(30, 55, 3)
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('&0\n이 굴욕을 삼킬 수 없어!\n즉시 쉬저우를 탈환하라!\n병력을 보내라!')
    stage.unit(20).setAction(6)
    stage.say('&20\n잠깐.')
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('&0\n문약, 무슨 일이야!?\n&20\n주군 지금 병력을 보내는 것은 너무 위험하다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n네.\n먼저 주변 방어를 공고히 해야 해.')
    stage.unit(24).setAction(0)
    stage.delay(5)
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n주변에...... 장수 말하는 거야?')
    stage.unit(20).setAction(6)
    stage.say('&20\n맞아요, 왜 장수와 동맹을 맺지 않나요?\n주군 어떻게 생각하는지 궁금하네요.\n&0\n장수와의 동맹?\n&20\n네.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n흠.............')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n음, 이게 최선의 방법인 것 같아.')
    stage.unit(0).move(34, 55, 1)
    stage.say('&0\n쯔양!')
    stage.unit(18).move(62, 70, 3)
    stage.delay(1)
    stage.unit(18).move(62, 55, 0)
    stage.delay(3)
    stage.unit(18).setAction(0, 3)
    stage.say('&18\n존재한다.\n&0\n나는 너를 완성으로 보내는 사절로 임명한다,\n장수와 동맹을 맺으세요.')
    stage.unit(18).setAction(6, 3)
    stage.say('&18\n네.')
    stage.clsUnit()
    stage.effectSound(202, 255)
    return False


def scene7():
    stage.loadBg(2, 48)
    stage.showUnits([
        [
            23,
            39,
            48,
            1],
        [
            18,
            53,
            48,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.setStageName('완 장수 맨션')
    stage.delay(3)
    stage.unit(18).setAction(6, 3)
    stage.say('&18\n저는 조조 공이 보낸 사신, 유예입니다.\n&23\n아래, 가후.')
    stage.unit(18).setAction(0)
    stage.say('&18\n가후Mr. 장수, ...... 영주는 어디 계십니까?"\n&23\n내 주군가 현재 병력을 검토 중이다,\n할 말 있으면 그냥 말해.\n&18\n정말......?\n&23\n뭘 원해?')
    stage.unit(18).setAction(6)
    stage.say('&18\n저는 장수 경과 동맹을 맺으러 왔습니다.\n&23\n아, 우리와 동맹을 맺으려는 ......?\n&18\n네.')
    stage.unit(18).setAction(0)
    stage.say('&18\n우리 가족주군 무기를 옥과 비단으로 바꾸길 바란다,\n과거의 불행은 사라지게 하소서,\n그는 장수 경과 악수하며 화해했다.')
    stage.unit(23).setAction(0, 2)
    stage.say('&23\n흠............\n&18\n여러분은 어떻게 생각하세요?')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n아, 그렇군요.\n꼭 제 주군에게 전해드릴게요,\n내일 답장할게.')
    stage.unit(18).setAction(6)
    stage.say('&18\n바로 답장할 수 없나요?')
    stage.unit(23).setAction(6)
    stage.say('&23\n저는 단지 부하일 뿐입니다. 주군와 상의하기 전에,\n죄송하지만 답변하기 어렵습니다. 조금만 기다려 주세요.\n&18\n정말?\n좋아.\n그럼 내일 다시 와서 답변을 기다리겠습니다.\n&23\n좋아.')
    stage.showUnit(181, 53, 93)
    stage.say('&181\n신고됐어.')
    stage.unit(23).setAction(0, 2)
    stage.unit(18).setAction(0, 2)
    stage.unit(181).move(53, 80, 0)
    stage.say('&181\n가후 선생님,\n허베이원소 사절을 보냈다.')
    stage.unit(18).move(53, 50, 2)
    stage.say('&18\n오!\n&23\n그래? 제발.')
    stage.unit(181).move(53, 93, 2)
    stage.unit(181).hide()
    stage.delay(3)
    stage.unit(18).setAction(0, 3)
    stage.say('&18\n자 ......가후 씨, 이.......')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n아, 괜찮아.\n손님방에서 쉬세요.\n&18\n좋아, .......')
    stage.unit(18).setAction(0, 2)
    stage.say('&18\n(상황이 안 좋아지고 있어.\n원소 장수와 동맹을 맺고 싶어하는 것도 분명합니다. )')
    stage.unit(18).move(53, 93, 2)
    stage.unit(18).hide()
    stage.showUnit(192, 53, 93)
    stage.say('&192\n무례하게 굴어서 죄송합니다.')
    stage.unit(192).move(53, 48, 0)
    stage.delay(3)
    stage.unit(192).setAction(0, 3)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n나는 전략가가후,\n당신은 원소가 보낸 전령임에 틀림없군요.')
    stage.unit(23).setAction(0)
    stage.say('&192\n네.\n&23\n필요한 게 있나요?\n&192\n네.\n주군 정말로 장수 경과 동맹을 맺고 싶어 한다.\n&23\n동맹? 주군 내 가족?\n&192\n네.......')
    stage.unit(23).setAction(0, 3)
    stage.say('&23\n음음 ......,\n&23\n하하하!')
    stage.say('&192\n이거 ...... 그게 뭐가 웃기지?')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n하하하!\n어떻게 웃지 않을 수 있겠는가?\n원소와 그 무리들은 실제로 우리 가족의 주군과 동맹을 맺고 싶어 해!')
    stage.unit(192).setAction(2)
    stage.say('&192\n뭐라고...... 뭐라고!\n이런 말은 정말 믿기 어렵습니다!\n&23\n솔직히 말할게요.\n내 주군는 절대 원소 사람들과 동맹을 맺지 않을 거야.\n돌아가야 해!')
    stage.unit(192).setAction(0)
    stage.say('&192\n아직 장수님을 만나본 적 없어요.')
    stage.unit(23).setAction(0, 3)
    stage.say('&23\n이런 사소한 일들이,\n내 주군은 간섭하지 않을 거야.')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n돌아가야 해!')
    stage.unit(192).setAction(2)
    stage.say('&192\n음...... 너 ...... 후회할 거야!')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(192).move(53, 93, 2)
    stage.unit(192).hide()
    stage.delay(3)
    stage.unit(23).setAction(0, 2)
    stage.say('&23\n흥, 그게 네가 말하면 되는 전부야.')
    stage.delay(10)
    stage.showUnit(143, 53, 93)
    stage.say('&143\n원허!')
    stage.unit(143).move(53, 48, 0)
    stage.delay(3)
    stage.unit(143).setAction(0, 3)
    stage.delay(3)
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n그래서 이렇게 일찍 돌아온 게 주군였다.\n&143\n원허, 네 계획이 뭐야!?\n&23\n응?')
    stage.unit(143).setAction(2)
    stage.say('&143\n그만 연기해!\n당신은 조조 사자를 관대하게 대하네요,\n하지만 그는 원소의 전령을 쫓아냈다!\n&23\n네.\n&143\n거절할 생각은 전혀 없었어요!\n원허, 도대체 무슨 꿍꿍이야?\n&23\n진정하세요,\n그냥 주군 탈출구를 찾고 있었을 뿐이야.')
    stage.unit(23).setAction(0, 3)
    stage.say('&23\n아군 이렇게 독립적으로 남는다면,\n이 혼란스러운 시대에 살아남기 어려울 것이다,\n누군가와 팀을 이룰 수 있다면 .......')
    stage.unit(143).setAction(0)
    stage.say('&143\n저도 그걸 알고 있어요!\n그런데 왜 원소 조조 대신 선택하지 않았을까요?\n분명히 엄청난 힘으로 원소 있어.')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n오늘날 원소는 정말로 강력한 나라입니다.\n&23\n하지만 두세 년 후에는 어떨까요?\n미래에 초점을 맞춘다면,\n지금이 조조을 선택할 때입니다.')
    stage.unit(143).setAction(2)
    stage.say('&143\n잊으셨나요!?\n우린 한때 조씨 가문 사람들을 죽였어!\n&23\n조조 이 모든 게 영원히 사라졌다고 했어요.')
    stage.unit(23).setAction(0, 2)
    stage.say('&23\n이 관대한 관대함으로,\n원소 비교할 수 없어요.')
    stage.unit(143).setAction(0)
    stage.say('&143\n조조 앞으로 ...... 원소보다 더 강해질 수 있을까요?')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n틀림없어.\n&143\n좋아. 다른 방법은 없어!\n믿을게.\n&23\n네.')
    stage.unit(23).setAction(6, 1)
    stage.say('&23\n게다가 조조의 군대에 합류할 때가 된 것 같다.')
    stage.unit(143).setAction(2)
    stage.say('&143\n뭐라고!? 그의 부하가 되고 싶어?\n&23\n큰 나무 아래에서 쉬는 게 정말 좋아.')
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n좀 더 솔직히 말하면, 우리는 고립되어 있고,\n이 혼란스러운 시대에 생존은 불가능합니다.')
    stage.unit(143).setAction(0)
    stage.say('&143\n……… 알겠어. 네 말이 틀릴 리 없어,\n나도 조조 합류할게.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene8():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            6,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            143,
            54,
            58,
            3,
            6],
        [
            23,
            54,
            52,
            3,
            6],
        [
            18,
            48,
            55,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.setStageName('서두, 총리 관저')
    stage.unit(0).setAction(3)
    stage.say('&0\n장 장군님, 드디어 도착하셨군요.\n&143\n네.\n&0\n너 같은 사람이 나를 도우러 온다면,\n마음이 편안해졌어요.')
    stage.unit(0).setAction(0)
    stage.say('&0\n쯔양, 수고했어.\n큰 공로를 드릴게요.')
    stage.unit(18).setAction(6)
    stage.say('&18\n칭찬해 주셔서 감사합니다, 총리님.')
    stage.unit(18).setAction(0)
    stage.say('&0\n예전처럼 완청을 계속 다스려 주시길 바랍니다.\n&143\n정말 감사합니다.')
    stage.unit(143).setAction(0)
    stage.say('&143\n그럼 바로 완청으로 돌아갈게.\n&0\n흠.')
    stage.unit(143).setAction(6)
    stage.say('&143\n이만 가겠습니다.\n&0\n원허, 할 말이 있어.\n너는 여기 있어.\n&23\n네.')
    stage.unit(143).setAction(0)
    stage.delay(3)
    stage.unit(143).move(95, 58, 1)
    stage.unit(143).hide()
    stage.say('&0\n원허, 내 진영에 남아 네 재능을 발휘할 수 있겠니?\n잘 활용할게.')
    stage.effectSound(202, 255)
    stage.bgSound(18)
    stage.delay(3)
    stage.say('&23\n모든 것은 총리의 명령에 달려 있습니다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n오, 원허, 머무르기로 했구나?\n&23\n네.')
    model.setFace(3)
    stage.say('하하하, 문화.\n이러한 인재가 당신에게 있어,\n나라 하나를 얻는 것과 같습니다!\n&23\n상청의 칭찬은 과장입니다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n문약 이제 그는 유비를 이길 수 있었다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n네.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\\n좋습니다! 주저우로 병력을 파견합니다!\\n유비를 토벌하겠습니다!')
    model.unitJoin(23, 0, 0)
    if vars[1013]:
        gvars[0] = 23
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 338, 94)
    stage.showHead(143, 274, 139)
    stage.showHead(32, 492, 119)
    stage.bottomTxt('완의 장수가 조조 지휘에 합류했다.', False, False, False)
    stage.delay(5)
    stage.head(143).hide()
    stage.delay(8)
    stage.bottomTxt('조조 즉시 군대를 동원하라,', True, True, False)
    stage.delay(5)
    stage.head(0).move(428, 119)
    stage.delay(5)
    stage.bottomTxt('군대가 서저우로 파견되어 유비 진압했다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene9():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            17,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            23,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('샤피 외곽, 조조군의 본군 진영')
    stage.say('&0\n문약, 원소에서 무슨 일이 일어나고 있지?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n그는 유비를 지지하고 싶지 않았다.\n&0\n큰 귀 도둑의 시대는 끝났다.')
    stage.unit(0).setAction(17, 0)
    stage.say('좋습니다, 출전합니다!')
    stage.unit(0).setAction(0, 0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        2,
        17,
        22,
        23,
        20])
    gvars[4076] = 0
    gvars[4057] = 15
    stage.setBattlePos([
        [
            1,
            2],
        [
            3,
            4],
        [
            2,
            3],
        [
            2,
            1],
        [
            0,
            3],
        [
            0,
            1],
        [
            4,
            3],
        [
            2,
            5],
        [
            3,
            2],
        [
            1,
            4],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene10():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(23):
        stage.say('&23\n저는 풍샤오 씨처럼 도교 승려입니다.\n&23\n원원장군이 기병대를 지휘한다,\n하지만 그는 지금 여기 없었다.')
    if stage.unitClickTest(20):
        stage.say('&20\n전장은 강으로 둘러싸인 두 도시로 이루어져 있습니다.\n&0\n두 도시......?\n&20\n네, 북쪽에는 쉬저우시, 남동쪽에는 샤피시가 있습니다.')
    if stage.unitClickTest(17):
        stage.say('&17\n저는 댄서입니다.\n&15\n댄서?\n어, 그게 무슨 팀이야?\n&17\n마치 무술가처럼, 허저 장군.\n&15\n...... 하지 마 나를 장군 허저라고 부르지 마!\n하하하.')
    if stage.unitClickTest(15):
        stage.say('&0\n허저.\n&15\n흠......\n&1\n안녕, 허저.\n&17\n장군 허저......\n&15\n흠.........\n&0\n허저!\n&15\n하... 하추!\n응? 응, 미안.\n&0\n…… 좋아, 좋아.')
    if stage.unitClickTest(1):
        stage.say('&1\n아이템 가게에서 인장 리본을 받은 것 같아요.\n&1\n일정 수준에 도달한 병력에 대해 사용된다면,\n그들은 더 강력한 유닛으로 승진할 것 같습니다.')
    if stage.unitClickTest(22):
        stage.say('&22\n내가 원소라면,\n그는 쉬두를 공격할 기회를 절대 놓치지 않을 것이다.\n&22\n원소This 사람은 정말 천상의 비밀을 놓쳤다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
