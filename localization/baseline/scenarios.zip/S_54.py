# Source Generated with Decompyle++
# File: S_54.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(17,19)',
        '(16,19)',
        '(16,9)',
        '(19,9)',
        '(6,19)',
        '(6,22)',
        '(27,19)',
        '(27,22)'])
    stage.nearEvent([
        3,
        57,
        17,
        72])
    stage.nearEvent([
        0,
        57,
        0,
        71,
        0,
        72], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 50, 'x': 16, 'y': 19, 'dir': 1, 'lv': 6, 'i': 0},
         {'id': 37, 'x': 17, 'y': 19, 'dir': 1, 'lv': 6, 'i': 1},
         {'id': 210, 'x': 17, 'y': 18, 'dir': 1, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 17, 'y': 20, 'dir': 1, 'lv': 0, 'i': 3},
         {'id': 234, 'x': 16, 'y': 18, 'dir': 1, 'lv': 0, 'i': 4},
         {'id': 235, 'x': 16, 'y': 20, 'dir': 1, 'lv': 0, 'i': 5},
         {'id': 212, 'x': 29, 'y': 20, 'dir': 1, 'lv': 0, 'i': 6},
         {'id': 213, 'x': 29, 'y': 21, 'dir': 1, 'lv': 0, 'i': 7},
         {'id': 236, 'x': 28, 'y': 20, 'dir': 1, 'lv': 0, 'i': 8},
         {'id': 237, 'x': 28, 'y': 21, 'dir': 1, 'lv': 0, 'i': 9},
         {'id': 298, 'x': 27, 'y': 19, 'dir': 1, 'lv': 0, 'i': 10},
         {'id': 299, 'x': 27, 'y': 22, 'dir': 1, 'lv': 0, 'i': 11},
         {'id': 38, 'x': 6, 'y': 19, 'dir': 1, 'lv': 4, 'i': 12},
         {'id': 43, 'x': 6, 'y': 22, 'dir': 1, 'lv': 4, 'i': 13},
         {'id': 214, 'x': 8, 'y': 20, 'dir': 1, 'lv': 0, 'i': 14},
         {'id': 215, 'x': 8, 'y': 21, 'dir': 1, 'lv': 0, 'i': 15},
         {'id': 300, 'x': 5, 'y': 20, 'dir': 1, 'lv': 0, 'i': 16},
         {'id': 301, 'x': 5, 'y': 21, 'dir': 1, 'lv': 0, 'i': 17},
         {'id': 39, 'x': 19, 'y': 9, 'lv': 4, 'i': 18},
         {'id': 40, 'x': 16, 'y': 9, 'lv': 4, 'i': 19},
         {'id': 216, 'x': 17, 'y': 11, 'lv': 0, 'i': 20},
         {'id': 217, 'x': 18, 'y': 11, 'lv': 0, 'i': 21},
         {'id': 302, 'x': 17, 'y': 8, 'lv': 0, 'i': 22},
         {'id': 303, 'x': 18, 'y': 8, 'lv': 0, 'i': 23},
         {'id': 71, 'hide': 1, 'x': 31, 'y': 15, 'lv': 4, 'ai': 1, 'i': 24},
         {'id': 73, 'hide': 1, 'x': 31, 'y': 14, 'lv': 4, 'ai': 1, 'i': 25},
         {'id': 382, 'hide': 1, 'x': 30, 'y': 15, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 383, 'hide': 1, 'x': 32, 'y': 15, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 390, 'hide': 1, 'x': 30, 'y': 14, 'lv': 0, 'ai': 1, 'i': 28},
         {'id': 391, 'hide': 1, 'x': 32, 'y': 14, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 72, 'hide': 1, 'x': 31, 'y': 27, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 30},
         {'id': 61, 'hide': 1, 'x': 31, 'y': 26, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 31},
         {'id': 310, 'hide': 1, 'x': 30, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 311, 'hide': 1, 'x': 32, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 312, 'hide': 1, 'x': 30, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 313, 'hide': 1, 'x': 32, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 58, 'hide': 1, 'x': 2, 'y': 14, 'lv': 6, 'ai': 1, 'i': 36},
         {'id': 462, 'hide': 1, 'x': 1, 'y': 14, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 463, 'hide': 1, 'x': 3, 'y': 14, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 464, 'hide': 1, 'x': 1, 'y': 15, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 465, 'hide': 1, 'x': 2, 'y': 15, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 466, 'hide': 1, 'x': 3, 'y': 15, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 57, 'hide': 1, 'x': 2, 'y': 27, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 42},
         {'id': 467, 'hide': 1, 'x': 1, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 43},
         {'id': 468, 'hide': 1, 'x': 3, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 44},
         {'id': 469, 'hide': 1, 'x': 1, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 45},
         {'id': 470, 'hide': 1, 'x': 2, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 46},
         {'id': 471, 'hide': 1, 'x': 3, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 47},
         {'id': 60, 'hide': 1, 'x': 22, 'y': 5, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 48},
         {'id': 218, 'hide': 1, 'x': 22, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 49},
         {'id': 219, 'hide': 1, 'x': 22, 'y': 6, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 50},
         {'id': 238, 'hide': 1, 'x': 23, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 51},
         {'id': 239, 'hide': 1, 'x': 23, 'y': 5, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 52},
         {'id': 240, 'hide': 1, 'x': 23, 'y': 6, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 59, 'hide': 1, 'x': 12, 'y': 5, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 54},
         {'id': 220, 'hide': 1, 'x': 13, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 221, 'hide': 1, 'x': 13, 'y': 5, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 56},
         {'id': 222, 'hide': 1, 'x': 13, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 241, 'hide': 1, 'x': 12, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 58},
         {'id': 242, 'hide': 1, 'x': 12, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 59}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 35,
            'y': 20,
            'dir': 3 },
        {
            'idx': 1,
            'x': 35,
            'y': 21,
            'dir': 3 },
        {
            'idx': 2,
            'x': 35,
            'y': 19,
            'dir': 3 },
        {
            'idx': 3,
            'x': 35,
            'y': 22,
            'dir': 3 },
        {
            'idx': 4,
            'x': 36,
            'y': 20,
            'dir': 3 },
        {
            'idx': 5,
            'x': 36,
            'y': 21,
            'dir': 3 },
        {
            'idx': 6,
            'x': 36,
            'y': 19,
            'dir': 3 },
        {
            'idx': 7,
            'x': 36,
            'y': 22,
            'dir': 3 },
        {
            'idx': 8,
            'x': 37,
            'y': 20,
            'dir': 3 },
        {
            'idx': 9,
            'x': 37,
            'y': 21,
            'dir': 3 },
        {
            'idx': 10,
            'x': 37,
            'y': 19,
            'dir': 3 },
        {
            'idx': 11,
            'x': 37,
            'y': 22,
            'dir': 3 },
        {
            'idx': 12,
            'x': 38,
            'y': 20,
            'dir': 3 },
        {
            'idx': 13,
            'x': 38,
            'y': 21,
            'dir': 3 },
        {
            'idx': 14,
            'x': 38,
            'y': 19,
            'dir': 3 }])
    stage.loadBg(54)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab21')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab21')
    stage.draw()
    stage.bgSound(3)
    stage.unit(0).setDir(stage.countDir(0, 50))
    stage.say('&0\n여기가 검정 맞지? 여기 없는 것 같공명.\n아마도 여기서 다시 아군의 공격을 막으려 했을 것이다.\n나는 그가 만족하도록 절대 허락하지 않을 거야.')
    stage.unit(0).setAction(5)
    stage.say('&0\n전군으로 진격하라! 한 번의 결정적인 일격으로 적군를 전멸시켜라!\n우리는 가능한 한 빨리 지앙에를 잡아야 합니다.\n시간이 없어!')
    stage.unit(0).setAction(0)
    stage.unit(50).setDir(stage.countDir(50, 0))
    stage.unit(37).setDir(stage.countDir(37, 0))
    stage.unit(43).setDir(stage.countDir(43, 0))
    stage.unit(40).setDir(stage.countDir(40, 0))
    stage.say('&50\n헤헤헤,\n내 마수의 방어를 뚫을 수 있겠어?\n&37\n절대 이곳을 통과하게 해서는 안 됩니다!\n&43\n언제든 은둔에서 나와 싸울 수 있어.\n이번에는 조조에게 교훈을 줘야 한다!')
    stage.unit(38).setDir(stage.countDir(38, 50))
    stage.say('&38\n계획은 이미 철저히 계획되어 있었다.\n&40\n전 영주는 왕국을 평정하려는 유비 원했다,\n나, 손첸은 반드시 이루겠다.')
    stage.unit(39).setDir(stage.countDir(39, 50))
    stage.say('&39\n나도 준비됐어.')
    stage.unit(50).setAction(5)
    stage.say('&50\n좋아, 조의 군대와 맞서자!')
    stage.unit(50).setAction(0)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[554] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 17, 19):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 16, 19):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 16, 9):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 19, 9):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 6, 19):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 6, 22):
        stage.getItem(151, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 27, 19):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 27, 22):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if not vars[2] and not vars[6] and stage.totalRectUnit(0, 11, 14, 22, 25) >= 12 and stage.curCamp() == 2:
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.unit(50).setAction(5)
        stage.say('&50\n하하하, 속았구나, 조조!\n군사 전략에 능하고 교활한 계략으로 가득 차 있다는 말을 오래전부터 들었는데,\n그 이상은 아닌 것 같아요.')
        stage.unit(50).setAction(0)
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(73).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(72).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(61).show()
        stage.unit(312).show()
        stage.unit(313).show()
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.say('&61\n항상 방법이 있는 것 같아.\n좋아, 나가서 적과 맞서자!')
        stage.unit(72).setDir(2)
        stage.unit(72).setAction(1)
        stage.say('&72\n조공, 이쪽에서 인사드립니다.\n나는 남쪽 왕국의 무용수 주융이다, 나를 기억해야 한다!\n오늘 네 목숨을 빼앗게 해줘.')
        stage.unit(71).setAction(6)
        stage.say('&71\n공명 씨가 남쪽에서 와서 지원을 하라고 위임했으니,\n물론 좋은 연기를 해야 해.\n어서, 어서!')
        stage.unit(71).setAction(0)
        stage.say('&73\n리안, 나도 나가서 싸워야 해?')
        stage.unit(57).show()
        stage.unit(467).show()
        stage.unit(468).show()
        stage.unit(469).show()
        stage.unit(470).show()
        stage.unit(471).show()
        stage.unit(58).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(466).show()
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(57).setAction(5)
        stage.say('&57\n조조!\n이번에는 아버지의 죽음을 복수해야 한다.\n마다이, 싸워서 빠져나가!')
        stage.unit(57).setAction(0)
        stage.say('&58\n좋아!')
        stage.unit(60).show()
        stage.unit(218).show()
        stage.unit(219).show()
        stage.unit(238).show()
        stage.unit(239).show()
        stage.unit(240).show()
        stage.unit(59).show()
        stage.unit(241).show()
        stage.unit(242).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(222).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.say('&60\n젠장, 공명 또 어디로 도망간 거지?\n위험한 일들을 다 나한테 떠넘겼잖아,\n이 사람 정말 무책임해!\n&59\n여기 지형에 너무 익숙해서,\n내 매복을 눈치채지 못한 것 같조조......')
        stage.unit(0).setDir(stage.countDir(0, 61))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 것이라 예상하지 못했다......\n&0\n공명를 죽이려면 먼저 이곳을 뚫어야 하는 것 같아......\n하지만 적을 뒤에 남겨두는 것도 위험하다.')
        sel = stage.choice('북문 돌파\n전멸시키적군', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n공명 지금 기도 의식 중일 수도 있습니다.\n&0\n아직도 지체할 여유가 없는 것 같아요,\n우리는 가능한 한 빨리 베이관을 돌파해야 한다!')
            stage.unit(0).setAction(0)
            stage.say('&57\n배신자 조, 도망가지 마!\n&72\n싸우러 왔다면 왜 도망쳤어?\n이모조차도 감히 그를 때리지 못했다,\n도대체 무슨 영웅이야!\n&59\n한 걸음도 넘게 하지 않을 거야!')
            if not vars[51]:
                stage.unit(39).setAction(5)
                stage.say('&39\n방어를 강화해! 막아적군.')
                stage.unit(39).setAction(0)
            else:
                stage.unit(60).setAction(5)
                stage.say('&60\n만약 조조가 도망친다면,\n그게 내 책임 아니야?\n빨리 베이관의 방어를 강화하라!')
                stage.unit(60).setAction(0)
            stage.unit(59).setAI(4, -1, 15, 8)
            stage.unit(241).setAI(4, -1, 15, 8)
            stage.unit(242).setAI(4, -1, 15, 8)
            stage.unit(238).setAI(4, -1, 20, 8)
            stage.unit(239).setAI(4, -1, 20, 8)
            stage.unit(240).setAI(4, -1, 20, 8)
            stage.unit(60).setAI(4, -1, 18, 10)
            stage.unit(218).setAI(4, -1, 18, 10)
            stage.unit(219).setAI(4, -1, 18, 10)
            stage.unit(220).setAI(4, -1, 17, 10)
            stage.unit(221).setAI(4, -1, 17, 10)
            stage.unit(222).setAI(4, -1, 17, 10)
            stage.setWinCondition('승리 조건\n1. 북문을 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('검정을 돌파한다!')
            stage.heightLight(15, 0, 20, 1)
            vars[3] = 1
        elif sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n군대 전체가 적군를 마주하고 있다!\n그들 앞에 있는 적들을 완전히 쓸어버려라!\n&0\n만약 당신이 장벽을 직접 뚫는다면,\n아군 뒤에 적군을 남기고,\n그때부터는 필연적으로 위험해질 것이다.\n&0\n비록 시간이 좀 걸리겠지만,\n하지만 미래에 대한 걱정을 없앨 수 있습니다.')
            stage.unit(0).setAction(0)
            stage.say('&71\n오? 그들은 도망가지 않아!\n배짱이 좀 있네.')
            stage.setAI(5, 15, 7, 16, 2, 3, 38, 0, 0)
            stage.setAI(5, 25, 7, 26, 2, 3, 43, 0, 0)
            if not vars[51]:
                stage.unit(39).setAction(5)
                stage.say('&39\n방어를 강화해! 막아적군!')
                stage.unit(39).setAction(0)
            else:
                stage.unit(59).setAction(5)
                stage.say('&59\n빨리! 방어를 강화해!')
                stage.unit(59).setAction(0)
            stage.unit(59).setAI(4, -1, 15, 8)
            stage.unit(241).setAI(4, -1, 15, 8)
            stage.unit(242).setAI(4, -1, 15, 8)
            stage.unit(238).setAI(4, -1, 20, 8)
            stage.unit(239).setAI(4, -1, 20, 8)
            stage.unit(240).setAI(4, -1, 20, 8)
            stage.unit(60).setAI(4, -1, 18, 10)
            stage.unit(218).setAI(4, -1, 18, 10)
            stage.unit(219).setAI(4, -1, 18, 10)
            stage.unit(220).setAI(4, -1, 17, 10)
            stage.unit(221).setAI(4, -1, 17, 10)
            stage.unit(222).setAI(4, -1, 17, 10)
        vars[2] = 1
        vars[6] = 1
    if not vars[30] and stage.isInRect(1025, 25, 12, 29, 28):
        stage.setAI(27, 19, 29, 22, 2, 0)
        vars[30] = 1
    if not vars[31] and stage.isInRect(1025, 14, 16, 20, 22):
        stage.setAI(16, 18, 17, 20, 2, 0)
        vars[31] = 1
    if not vars[2] and not vars[32] and stage.isInRect(1025, 30, 11, 33, 16):
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(73).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(73).setDir(stage.countDir(73, 0))
        stage.unit(71).setDir(stage.countDir(71, 73))
        stage.say('&73\n오, 안 돼! 발각된 거야?\n&71\n선택의 여지가 없어, 그냥 싸워!')
        stage.unit(72).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(61).show()
        stage.unit(312).show()
        stage.unit(313).show()
        stage.unit(72).setDir(stage.countDir(72, 71))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.say('&72\n너희 남자들은 정말 쓸모없어.\n그래서 저, 주융만이 조조 목을 베었어요,\n체면을 살릴 체면을 좀 줘!\n&61\n조조 꿰뚫어봤어?\n이제 적에게 매복이 발견되었으니,\n아직도 이곳을 지켜야 할 필요가 있을까요?')
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.say('&50\n흠, 내가 가진 모든 정거장을 다 써도,\n하지만 내 부하들은 모두 무능해......')
        stage.unit(50).setAction(5)
        stage.say('&50\n선택의 여지가 없었습니다.\n매복 병력을 모두 배치해 조의 군대를 전폭력으로 공격하라!')
        stage.unit(50).setAction(0)
        stage.unit(57).show()
        stage.unit(467).show()
        stage.unit(468).show()
        stage.unit(469).show()
        stage.unit(470).show()
        stage.unit(471).show()
        stage.unit(58).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(466).show()
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.say('&57\n매복을 설치하는 건 내 의도에 완전히 어긋나는 일이야!\n명예롭게 정면으로 조조 맞서자!\n&58\n조조, 목숨을 걸어!')
        stage.unit(60).show()
        stage.unit(218).show()
        stage.unit(219).show()
        stage.unit(238).show()
        stage.unit(239).show()
        stage.unit(240).show()
        stage.unit(59).show()
        stage.unit(241).show()
        stage.unit(242).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(222).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.say('&60\n남쪽 야만인 병사들이 장악하는 것밖에 남지 않은 것 같았다.\n아무리 경험이 많아도 조의 군대를 상대할 수 없습니다!\n&59\n매복 실패도 선택의 여지가 없는 문제입니다,\n그들은 재배치할 수밖에 없었다.\n&50\n지금 동관을 응원할 거야,\n북문과 서문을 지켜야 한다!')
        stage.setAI(5, 15, 7, 16, 2, 3, 38, 0, 0)
        stage.setAI(5, 25, 7, 26, 2, 3, 43, 0, 0)
        if not vars[51]:
            stage.unit(39).setAction(5)
            stage.say('&39\n이해했어.\n방어를 강화하세요!')
            stage.unit(39).setAction(0)
        else:
            stage.unit(59).setAction(5)
            stage.say('&59\n빨리, 방어를 강화해!')
            stage.unit(59).setAction(0)
        stage.setAI(12, 8, 13, 10, 2, 3, 40, 0, 0)
        stage.setAI(22, 8, 23, 10, 2, 3, 39, 0, 0)
        stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 거라 예상하지 못했다......\n이 전투는 쉽게 이기지 못할 것 같다.')
        vars[2] = 1
        vars[32] = 1
        vars[33] = 1
    if not vars[2] and not vars[33] and stage.isInRect(1025, 30, 25, 33, 28):
        stage.unit(72).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(61).show()
        stage.unit(312).show()
        stage.unit(313).show()
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.say('&72\n어? 걸렸어?\n아, 아름다운 여자들은 너무 눈에 띄는 거야.\n젠장, 조준, 예리한 눈으로 미녀를 알아보는 법을 진짜 안다!\n&61\n매복이 발견되었나?\n그렇다면, 남은 것은 품위 있는 전투뿐이다.')
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(73).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(71).setDir(stage.countDir(71, 72))
        stage.unit(73).setDir(stage.countDir(73, 72))
        stage.say('&71\n내 아내가 위험해!\n멍유, 나랑 싸워서 나가!\n&73\n응?\n지금 나가는 거야!?\n아니, 제발.')
        stage.unit(57).show()
        stage.unit(467).show()
        stage.unit(468).show()
        stage.unit(469).show()
        stage.unit(470).show()
        stage.unit(471).show()
        stage.unit(58).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(466).show()
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.say('&57\n매복을 설치하는 건 내 의도에 완전히 어긋나는 일이야!\n명예롭게 정면으로 조조 맞서자!\n&58\n조조, 목숨을 걸어!')
        stage.unit(60).show()
        stage.unit(218).show()
        stage.unit(219).show()
        stage.unit(238).show()
        stage.unit(239).show()
        stage.unit(240).show()
        stage.unit(59).show()
        stage.unit(241).show()
        stage.unit(242).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(222).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.say('&60\n남쪽 야만인 병사들이 장악하는 것밖에 남지 않은 것 같았다.\n아무리 경험이 많아도 조의 군대를 상대할 수 없습니다!\n&59\n매복 실패도 선택의 여지가 없는 문제입니다,\n그래서 재배치해야 했습니다.\n&50\n지금 동관을 응원할 거야,\n북문과 서문을 지켜야 한다!')
        stage.setAI(5, 15, 7, 16, 2, 3, 38, 0, 0)
        stage.setAI(5, 25, 7, 26, 2, 3, 43, 0, 0)
        if not vars[51]:
            stage.unit(39).setAction(5)
            stage.say('&39\n이해했어.\n방어를 강화하세요!')
            stage.unit(39).setAction(0)
        else:
            stage.unit(59).setAction(5)
            stage.say('&59\n빨리, 방어를 강화해!')
            stage.unit(59).setAction(0)
        stage.setAI(12, 8, 13, 10, 2, 3, 40, 0, 0)
        stage.setAI(22, 8, 23, 10, 2, 3, 39, 0, 0)
        stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 거라 예상하지 못했다......\n이 전투는 쉽게 이기지 못할 것 같다.')
        vars[2] = 1
        vars[33] = 1
        vars[32] = 1
    if vars[3] and not vars[34] and stage.isInRect(0, 15, 0, 20, 1):
        stage.resumeCtrl()
        if not vars[63]:
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.say('&57\n배신자 조, 도망가지 마!')
        if not vars[58]:
            stage.say('&58\n우회할 방법을 찾아야 할 것 같아,\n우리는 양평관으로 급히 가야 했어......')
        vars[34] = 1
        stage.unit(0).setAction(5)
        stage.say('&0\n전속력으로 앞으로 나아가!\n우리는 공명의 음모를 반드시 무너뜨려야 한다!')
        stage.unit(0).setAction(0)
        stage.reward(0, [
            144,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[654] = 1
        vars[754] = 1
        return True
    if not vars[35] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 14, 10, 27):
        if not vars[2]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.unit(50).setAction(5)
            stage.say('&50\n하하하, 속았구나, 조조!\n군사 전략에 능하고 교활한 계략으로 가득 차 있다는 말을 오래전부터 들었는데,\n그 이상은 아닌 것 같아요.')
            stage.unit(50).setAction(0)
            stage.unit(71).show()
            stage.unit(382).show()
            stage.unit(383).show()
            stage.unit(73).show()
            stage.unit(390).show()
            stage.unit(391).show()
            stage.unit(72).show()
            stage.unit(310).show()
            stage.unit(311).show()
            stage.unit(61).show()
            stage.unit(312).show()
            stage.unit(313).show()
            stage.unit(61).setDir(stage.countDir(61, 0))
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.say('&61\n항상 방법이 있는 것 같아.\n좋아, 나가서 적과 맞서자!')
            stage.unit(72).setDir(2)
            stage.unit(72).setAction(1)
            stage.say('&72\n조공, 이쪽에서 인사드립니다.\n나는 남쪽 왕국의 무용수 주융이다, 나를 기억해야 한다!\n오늘 네 목숨을 빼앗게 해줘.')
            stage.unit(71).setAction(6)
            stage.say('&71\n공명 씨가 남쪽에서 와서 지원을 하라고 위임했으니,\n물론 좋은 연기를 해야 해.\n어서, 어서!')
            stage.unit(71).setAction(0)
            stage.say('&73\n나-나도 싸우러 나가?')
            stage.unit(57).show()
            stage.unit(467).show()
            stage.unit(468).show()
            stage.unit(469).show()
            stage.unit(470).show()
            stage.unit(471).show()
            stage.unit(58).show()
            stage.unit(462).show()
            stage.unit(463).show()
            stage.unit(464).show()
            stage.unit(465).show()
            stage.unit(466).show()
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(57).setAction(5)
            stage.say('&57\n조조!\n이번에는 아버지의 죽음을 복수해야 한다.\n마다이, 싸워서 빠져나가!')
            stage.unit(57).setAction(0)
            stage.say('&58\n좋아!')
            stage.unit(60).show()
            stage.unit(218).show()
            stage.unit(219).show()
            stage.unit(238).show()
            stage.unit(239).show()
            stage.unit(240).show()
            stage.unit(59).show()
            stage.unit(241).show()
            stage.unit(242).show()
            stage.unit(220).show()
            stage.unit(221).show()
            stage.unit(222).show()
            stage.unit(60).setDir(stage.countDir(60, 0))
            stage.unit(59).setDir(stage.countDir(59, 0))
            stage.say('&60\n젠장, 공명 또 어디로 도망간 거지?\n위험한 일들을 다 나한테 떠넘겼잖아,\n이 사람 정말 무책임해!\n&59\n여기 지형에 너무 익숙해서,\n내 매복 지점도 못 찾조조 것 같네......')
            stage.unit(0).setDir(stage.countDir(0, 61))
            stage.unit(0).setDir(stage.countDir(0, 57))
            stage.unit(0).setDir(stage.countDir(0, 60))
            stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 것이라 예상하지 못했다......\n&0\n공명를 죽이려면 먼저 이곳을 뚫어야 하는 것 같아......\n하지만 적을 뒤에 남겨두는 것도 위험하다.')
            sel = stage.choice('북문 돌파\n전멸시키적군', -1)
            if sel == 1:
                stage.unit(0).setAction(5)
                stage.say('&0\n공명 지금 기도 의식 중일 수도 있습니다.\n&0\n아직도 지체할 여유가 없는 것 같아요,\n우리는 가능한 한 빨리 베이관을 돌파해야 한다!')
                stage.unit(0).setAction(0)
                stage.say('&57\n배신자 조, 도망가지 마!\n&72\n싸우러 왔다면 왜 도망쳤어?\n이모조차도 감히 그를 때리지 못했다,\n도대체 무슨 영웅이야!\n&59\n한 걸음도 넘게 하지 않을 거야!')
                if not vars[51]:
                    stage.unit(39).setAction(5)
                    stage.say('&39\n방어를 강화해! 막아적군.')
                    stage.unit(39).setAction(0)
                else:
                    stage.unit(60).setAction(5)
                    stage.say('&60\n만약 조조가 도망친다면,\n그게 내 책임 아니야?\n빨리 베이관의 방어를 강화하라!')
                    stage.unit(60).setAction(0)
                stage.unit(59).setAI(4, -1, 15, 8)
                stage.unit(241).setAI(4, -1, 15, 8)
                stage.unit(242).setAI(4, -1, 15, 8)
                stage.unit(238).setAI(4, -1, 20, 8)
                stage.unit(239).setAI(4, -1, 20, 8)
                stage.unit(240).setAI(4, -1, 20, 8)
                stage.unit(60).setAI(4, -1, 18, 10)
                stage.unit(218).setAI(4, -1, 18, 10)
                stage.unit(219).setAI(4, -1, 18, 10)
                stage.unit(220).setAI(4, -1, 17, 10)
                stage.unit(221).setAI(4, -1, 17, 10)
                stage.unit(222).setAI(4, -1, 17, 10)
                stage.setWinCondition('승리 조건\n1. 북문을 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
                stage.showWinCondition('검정을 돌파한다!')
                stage.heightLight(15, 0, 20, 1)
                vars[3] = 1
                vars[36] = 1
            elif sel == 2:
                stage.unit(0).setAction(5)
                stage.say('&0\n군대 전체가 적군를 마주하고 있다!\n그들 앞에 있는 적들을 완전히 쓸어버려라!\n&0\n만약 당신이 장벽을 직접 뚫는다면,\n아군 뒤에 적군을 남기고,\n그때부터는 필연적으로 위험해질 것이다.\n&0\n비록 시간이 좀 걸리겠지만,\n하지만 미래에 대한 걱정을 없앨 수 있습니다.')
                stage.unit(0).setAction(0)
                stage.say('&71\n오? 그들은 도망가지 않아!\n배짱이 좀 있네.')
            vars[2] = 1
        elif vars[3]:
            if not vars[50]:
                stage.unit(38).setDir(stage.countDir(38, 0))
                stage.unit(38).setAction(2)
                stage.say('&38\n조의 군대가 공격한다!\n방어를 강화하세요!')
            stage.setAI(0, 14, 9, 27, 2, 0)
            if not vars[51]:
                stage.unit(39).setDir(stage.countDir(39, 0))
                stage.unit(39).setAction(5)
                stage.say('&39\n적군 습격 뒤에!\n공격 시작!')
                stage.unit(39).setAction(0)
            stage.setAI(12, 0, 23, 12, 2, 1)
            vars[36] = 1
        else:
            stage.setAI(0, 14, 9, 27, 2, 0)
        vars[35] = 1
    if not vars[36] and stage.curCamp() == 2 and stage.isInRect(1025, 12, 0, 23, 13):
        if not vars[2]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.unit(50).setAction(5)
            stage.say('&50\n하하하, 속았구나, 조조!\n군사 전략에 능하고 교활한 계략으로 가득 차 있다는 말을 오래전부터 들었는데,\n그 이상은 아닌 것 같아요.')
            stage.unit(50).setAction(0)
            stage.unit(71).show()
            stage.unit(382).show()
            stage.unit(383).show()
            stage.unit(73).show()
            stage.unit(390).show()
            stage.unit(391).show()
            stage.unit(72).show()
            stage.unit(310).show()
            stage.unit(311).show()
            stage.unit(61).show()
            stage.unit(312).show()
            stage.unit(313).show()
            stage.unit(61).setDir(stage.countDir(61, 0))
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.say('&61\n항상 방법이 있는 것 같아.\n좋아, 나가서 적과 맞서자!')
            stage.unit(72).setDir(2)
            stage.unit(72).setAction(1)
            stage.say('&72\n조공, 이쪽에서 인사드립니다.\n나는 남쪽 왕국의 무용수 주융이다, 나를 기억해야 한다!\n오늘 네 목숨을 빼앗게 해줘.')
            stage.unit(71).setAction(6)
            stage.say('&71\n공명 씨가 남쪽에서 와서 지원을 하라고 위임했으니,\n물론 좋은 연기를 해야 해.\n어서, 어서!')
            stage.unit(71).setAction(0)
            stage.say('&71\n나-나도 싸우러 나가?')
            stage.unit(57).show()
            stage.unit(467).show()
            stage.unit(468).show()
            stage.unit(469).show()
            stage.unit(470).show()
            stage.unit(471).show()
            stage.unit(58).show()
            stage.unit(462).show()
            stage.unit(463).show()
            stage.unit(464).show()
            stage.unit(465).show()
            stage.unit(466).show()
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(57).setAction(5)
            stage.say('&57\n조조!\n이번에는 아버지의 죽음을 복수해야 한다.\n마다이, 싸워서 빠져나가!')
            stage.unit(57).setAction(0)
            stage.say('&58\n좋아!')
            stage.unit(60).show()
            stage.unit(218).show()
            stage.unit(219).show()
            stage.unit(238).show()
            stage.unit(239).show()
            stage.unit(240).show()
            stage.unit(59).show()
            stage.unit(241).show()
            stage.unit(242).show()
            stage.unit(220).show()
            stage.unit(221).show()
            stage.unit(222).show()
            stage.unit(60).setDir(stage.countDir(60, 0))
            stage.unit(59).setDir(stage.countDir(59, 0))
            stage.say('&60\n젠장, 공명 또 어디로 도망간 거지?\n위험한 일들을 다 나한테 떠넘겼잖아,\n이 사람 정말 무책임해!\n&59\n여기 지형에 너무 익숙해서,\n내 매복 지점도 못 찾조조 것 같네......')
            stage.unit(0).setDir(stage.countDir(0, 61))
            stage.unit(0).setDir(stage.countDir(0, 57))
            stage.unit(0).setDir(stage.countDir(0, 60))
            stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 것이라 예상하지 못했다......\n&0\n공명를 죽이려면 먼저 이곳을 뚫어야 하는 것 같아......\n하지만 적을 뒤에 남겨두는 것도 위험하다.')
            sel = stage.choice('북문 돌파\n전멸시키적군', -1)
            if sel == 1:
                stage.unit(0).setAction(5)
                stage.say('&0\n공명 지금 기도 의식 중일 수도 있습니다.\n&0\n아직도 지체할 여유가 없는 것 같아요,\n우리는 가능한 한 빨리 베이관을 돌파해야 한다!')
                stage.unit(0).setAction(0)
                stage.say('&57\n배신자 조, 도망가지 마!\n&72\n싸우러 왔다면 왜 도망쳤어?\n이모조차도 감히 그를 때리지 못했다,\n도대체 무슨 영웅이야!\n&59\n한 걸음도 넘게 하지 않을 거야!')
                if not vars[51]:
                    stage.unit(39).setAction(5)
                    stage.say('&39\n방어를 강화해! 막아적군.')
                    stage.unit(39).setAction(0)
                else:
                    stage.unit(60).setAction(5)
                    stage.say('&60\n만약 조조가 도망친다면,\n그게 내 책임 아니야?\n빨리 베이관의 방어를 강화하라!')
                    stage.unit(60).setAction(0)
                stage.unit(59).setAI(4, -1, 15, 8)
                stage.unit(241).setAI(4, -1, 15, 8)
                stage.unit(242).setAI(4, -1, 15, 8)
                stage.unit(238).setAI(4, -1, 20, 8)
                stage.unit(239).setAI(4, -1, 20, 8)
                stage.unit(240).setAI(4, -1, 20, 8)
                stage.unit(60).setAI(4, -1, 18, 10)
                stage.unit(218).setAI(4, -1, 18, 10)
                stage.unit(219).setAI(4, -1, 18, 10)
                stage.unit(220).setAI(4, -1, 17, 10)
                stage.unit(221).setAI(4, -1, 17, 10)
                stage.unit(222).setAI(4, -1, 17, 10)
                stage.setWinCondition('승리 조건\n1. 북문을 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 30턴을 초과하기.')
                stage.showWinCondition('검정을 돌파한다!')
                stage.heightLight(15, 0, 20, 1)
                vars[3] = 1
                vars[35] = 1
            elif sel == 2:
                stage.unit(0).setAction(5)
                stage.say('&0\n군대 전체가 적군를 마주하고 있다!\n그 앞의 적들을 완전히 전멸시켜라!\n&0\n만약 당신이 장벽을 직접 뚫는다면,\n아군 뒤에 적군을 남기고,\n그때부터는 필연적으로 위험해질 것이다.\n&0\n비록 시간이 좀 걸리겠지만,\n하지만 미래에 대한 걱정을 없앨 수 있습니다.')
                stage.unit(0).setAction(0)
                stage.say('&71\n오? 그들은 도망가지 않아!\n배짱이 좀 있네.')
            vars[2] = 1
        elif vars[3]:
            if not vars[51]:
                stage.unit(39).setAction(2)
                stage.say('&39\n계속 힘내세요!\n시간을 벌어야 해!')
            stage.setAI(12, 0, 23, 12, 2, 0)
            if not vars[50]:
                stage.unit(38).setDir(stage.countDir(38, 0))
                stage.unit(38).setAction(5)
                stage.say('&38\n좋아, 지금이 기회야!\n공격 시작!\n기습 공격이 뒤에 적군다!')
                stage.unit(38).setAction(0)
            stage.setAI(0, 14, 9, 27, 2, 1)
            vars[35] = 1
        else:
            stage.setAI(12, 0, 22, 12, 2, 0)
        vars[36] = 1
    if not vars[40] and stage.isNear(0, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&57\n오늘은 승자와 패자를 결정해야 합니다!\n거기 가만히 있고 움직이지 마.\n&0\n하하하, 마초...... 정말 결심이 대단하네요!\n만약 너 같은 악당이 몇 명 더 나타난다면,\n항상 네 곁에 있을 조맹덕!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 71, True):
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(0).setDir(stage.countDir(0, 71))
        stage.say('&71\n오늘 전투는 모두 공명 씨가 맡았다.\n비록 당신에게 원한은 없지만,\n하지만 난 여전히 네 목숨을 빼앗을 거야, 하하하!\n&0\n상황이 얼마나 심각한지 너는 전혀 몰라.\n공명 이미 악마에게 빙의된 상태,\n내 길을 막지 마. 서둘러 남쪽 나라로 돌아가.\n&71\n공명 씨는 진정으로 마법을 다룰 줄 아십니다,\n하지만 그를 악마라고 부르는 것은 너무 무례할 것이다,\n너희 위나라는 정말 야만적이구나.')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 72, True):
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(0).setDir(stage.countDir(0, 72))
        stage.say('&72\n와, 진짜 남자네.\n무슨 일이야, 그냥 잠깐 나랑 좀 있어.\n&0\n너랑 신경 쓸 시간 없어.\n길을 막지 말고, 비켜!\n&72\n하하하, 비켜 주시겠지만 저는 거부합니다.\n지나가고 싶으면 실력 좀 보여줘!')
        vars[42] = 1
    if not vars[43] and stage.isNear(3, 57, False):
        stage.unit(57).setDir(stage.countDir(57, 3))
        stage.unit(3).setDir(stage.countDir(3, 57))
        stage.say('&57\n관우Move 제발!\n내 길을 막으려 하면 너도 죽일 거야!\n&3\n멍치, 관에게서 한 마디 들어줘.\n지금은 논쟁할 때가 아니야; 이미 공명 ......\n&57\n고집 부리지 마!\n나는 아버지의 복수를 원해,\n다른 일은 나랑 상관없어!\n&3\n다른 방법이 없는 것 같아.')
        fight = stage.startFight(3, 57, 5)
        fight.showUnit(False, '다시 한 번 말할게요.\n비켜, 관우!', 8)
        fight.showUnit(True, '나도 급한 일이 있어.\n길을 비켜야 해!', 9)
        fight.setAction(False, 6)
        fight.say(False, '흠, 그럼 이 문제는 당신과 해결해야겠네요.\n이걸 받아라!', True)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack1(False, 3, False)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 1, True)
        fight.setAction(True, 1)
        fight.setAction(False, 1)
        fight.attack1(True, 2, True)
        stage.delay(15)
        fight.setAction(False, 6)
        fight.say(False, '관우 정말 강력하다,\n널 죽이는 게 쉽지 않네......', True)
        fight.setAction(True, 6)
        fight.say(True, '그의 무술은 정말 대단했다; 그래서 그와 장비가 대등한 것도 당연했다.\n이번에는 조 총리가 골칫거리의 적을 데려왔다.', True)
        fight.end()
        vars[43] = 1
    if not vars[44] and stage.isNear(17, 72, False):
        stage.unit(72).setDir(stage.countDir(72, 17))
        stage.unit(17).setDir(stage.countDir(17, 72))
        stage.say('&72\n춤 실력이 꽤 좋다고 들었어.\n북쪽과 남쪽 춤 중 어느 쪽이 가장 좋을까?\n결전을 하자.\n&17\n키에 상관없이 춤을 추고,\n이렇게 경쟁하는 건 의미가 없어.')
        fight = stage.startFight(72, 17, 5)
        fight.showUnit(False, '시간 낭비하지 마!\n남부 춤은 열정으로 가득 차 있다,\n분위기가 활기차할수록 좋습니다!', 8)
        fight.showUnit(True, '내가 보여줄게\n북부 춤의 평온함.', 6)
        fight.showStart()
        fight.setAction(False, 5)
        fight.say(False, '지켜보세요,\n자세히 보세요!', True)
        fight.setAction(False, 15)
        fight.setAction(False, 0)
        fight.say(False, '흥, 그래서 뭐?\n내 춤 꽤 잘 추지?', True)
        fight.setAction(True, 0)
        fight.say(True, '네 춤 동작은 정말 아름답다,\n전투에 사용하는 것은 정말 아쉬운 일이었다.', True)
        fight.setAction(False, 9)
        fight.say(False, '흥!\n이번엔 네 차례야.', True)
        fight.setAction(True, 14)
        fight.setAction(True, 6)
        fight.say(True, '내 창피함을 드러내다니!', True)
        fight.setAction(False, 0)
        fight.say(False, '왜 그렇게 예의 바르게 굴어!\n그녀는 내가 상상했던 것보다 훨씬 더 잘 춤췄다.', True)
        fight.end()
        stage.unit(0).setDir(stage.countDir(0, 17))
        stage.say('초선은 여전히 춤 실력이 정교하구나. 상대방마저도 감탄하게 만드는구나.')
        if not vars[55]:
            stage.unit(71).setDir(stage.countDir(71, 72))
            stage.effectSound(21, 1)
            stage.say('&71\n내 아내를 언제 보든 상관없이,\n모두가 그녀의 춤 동작이 정말 매력적이라고 생각했다.\n어떻게 봐도 제 아내는 한 단계 위에 있다고 느껴요.')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(38, 7, 0, 2):
        stage.say('&38\n와! 좋지 않아...... 내 인생은 끝났어......')
        stage.unit(38).hide(2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(39, 7, 0, 2):
        stage.say('&39\n어떤 경우에도 적군 지나가게 해서는 안 됩니다......\n절대 안 돼.')
        stage.unit(39).hide(2)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n안 돼, 물러나는 게 낫겠어!')
        if not vars[2]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.unit(50).setAction(5)
            stage.say('&50\n매복 공격!\n조의 군대가 진격하는 것을 막기 위해서였다.')
            stage.unit(50).setAction(0)
            stage.unit(71).show()
            stage.unit(382).show()
            stage.unit(383).show()
            stage.unit(73).show()
            stage.unit(390).show()
            stage.unit(391).show()
            stage.unit(72).show()
            stage.unit(310).show()
            stage.unit(311).show()
            stage.unit(61).show()
            stage.unit(312).show()
            stage.unit(313).show()
            stage.unit(61).setDir(stage.countDir(61, 0))
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.say('&61\n항상 방법이 있는 것 같아.\n좋아, 나가서 적과 맞서자!')
            stage.unit(72).setDir(2)
            stage.unit(72).setAction(1)
            stage.say('&72\n조공, 이쪽에서 인사드립니다.\n나는 남쪽 왕국의 무용수 주융이다, 나를 기억해야 한다!\n오늘 네 목숨을 빼앗게 해줘.')
            stage.unit(71).setAction(6)
            stage.say('&71\n공명 씨가 남쪽에서 와서 지원을 하라고 위임했으니,\n물론 좋은 연기를 해야 해.\n어서, 어서!')
            stage.unit(71).setAction(0)
            stage.say('&73\n나-나도 싸우러 나가?')
            stage.unit(57).show()
            stage.unit(467).show()
            stage.unit(468).show()
            stage.unit(469).show()
            stage.unit(470).show()
            stage.unit(471).show()
            stage.unit(58).show()
            stage.unit(462).show()
            stage.unit(463).show()
            stage.unit(464).show()
            stage.unit(465).show()
            stage.unit(466).show()
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(57).setAction(5)
            stage.say('&57\n조조!\n이번에는 아버지의 죽음을 복수해야 한다.\n마다이, 싸워서 빠져나가!')
            stage.unit(57).setAction(0)
            stage.say('&58\n좋아!')
            stage.unit(60).show()
            stage.unit(218).show()
            stage.unit(219).show()
            stage.unit(238).show()
            stage.unit(239).show()
            stage.unit(240).show()
            stage.unit(59).show()
            stage.unit(241).show()
            stage.unit(242).show()
            stage.unit(220).show()
            stage.unit(221).show()
            stage.unit(222).show()
            stage.unit(60).setDir(stage.countDir(60, 0))
            stage.unit(59).setDir(stage.countDir(59, 0))
            stage.say('&60\n젠장, 공명 또 어디로 도망간 거지?\n위험한 일들을 다 나한테 떠넘겼잖아,\n이 사람 정말 무책임해!\n&59\n여기 지형에 너무 익숙해서,\n내 매복 지점도 못 찾조조 것 같네......')
            stage.unit(50).hide()
            stage.unit(0).setDir(stage.countDir(0, 61))
            stage.unit(0).setDir(stage.countDir(0, 57))
            stage.unit(0).setDir(stage.countDir(0, 60))
            stage.say('&0\n아무도 슈 군대가 이렇게 강력한 전투력을 가질 것이라 예상하지 못했다......\n&0\n공명를 죽이려면 먼저 이곳을 뚫어야 하는 것 같아......\n하지만 적을 뒤에 남겨두는 것도 위험하다.')
            sel = stage.choice('북문 돌파\n전멸시키적군', -1)
            if sel == 1:
                stage.unit(0).setAction(5)
                stage.say('&0\n공명 지금 기도 의식 중일 수도 있습니다.\n&0\n아직도 지체할 여유가 없는 것 같아요,\n우리는 가능한 한 빨리 베이관을 돌파해야 한다!')
                stage.unit(0).setAction(0)
                stage.say('&57\n배신자 조, 도망가지 마!\n&72\n싸우러 왔다면 왜 도망쳤어?\n이모조차도 감히 그를 때리지 못했다,\n도대체 무슨 영웅이야!\n&59\n한 걸음도 넘게 하지 않을 거야!')
                if not vars[51]:
                    stage.unit(39).setAction(5)
                    stage.say('&39\n방어를 강화해! 막아적군.')
                    stage.unit(39).setAction(0)
                else:
                    stage.unit(60).setAction(5)
                    stage.say('&60\n만약 조조가 도망친다면,\n그게 내 책임 아니야?\n빨리 베이관의 방어를 강화하라!')
                    stage.unit(60).setAction(0)
                stage.unit(59).setAI(4, -1, 15, 8)
                stage.unit(241).setAI(4, -1, 15, 8)
                stage.unit(242).setAI(4, -1, 15, 8)
                stage.unit(238).setAI(4, -1, 20, 8)
                stage.unit(239).setAI(4, -1, 20, 8)
                stage.unit(240).setAI(4, -1, 20, 8)
                stage.unit(60).setAI(4, -1, 18, 10)
                stage.unit(218).setAI(4, -1, 18, 10)
                stage.unit(219).setAI(4, -1, 18, 10)
                stage.unit(220).setAI(4, -1, 17, 10)
                stage.unit(221).setAI(4, -1, 17, 10)
                stage.unit(222).setAI(4, -1, 17, 10)
                stage.setWinCondition('승리 조건 1. 베이관을 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
                stage.showWinCondition('검정을 돌파한다!')
                stage.heightLight(15, 0, 20, 1)
                vars[3] = 1
            elif sel == 2:
                stage.unit(0).setAction(5)
                stage.say('&0\n군대 전체가 적군를 마주하고 있다!\n그 앞의 적들을 완전히 전멸시켜라!\n&0\n만약 당신이 장벽을 직접 뚫는다면,\n아군 뒤에 적군을 남기고,\n그때부터는 필연적으로 위험해질 것이다.\n&0\n비록 시간이 좀 걸리겠지만,\n하지만 미래에 대한 걱정을 없앨 수 있습니다.')
                stage.unit(0).setAction(0)
                stage.say('&71\n오? 그들은 도망가지 않아!\n배짱이 좀 있네.')
                stage.setAI(5, 15, 7, 16, 2, 3, 38, 0, 0)
                stage.setAI(5, 25, 7, 26, 2, 3, 43, 0, 0)
                if not vars[51]:
                    stage.unit(39).setAction(2)
                    stage.say('&39\n방어를 강화해! 막아적군!')
                else:
                    stage.unit(59).setAction(5)
                    stage.say('&59\n빨리, 방어를 강화해!')
                    stage.unit(59).setAction(0)
                stage.unit(59).setAI(4, -1, 15, 8)
                stage.unit(241).setAI(4, -1, 15, 8)
                stage.unit(242).setAI(4, -1, 15, 8)
                stage.unit(238).setAI(4, -1, 20, 8)
                stage.unit(239).setAI(4, -1, 20, 8)
                stage.unit(240).setAI(4, -1, 20, 8)
                stage.unit(60).setAI(4, -1, 18, 10)
                stage.unit(218).setAI(4, -1, 18, 10)
                stage.unit(219).setAI(4, -1, 18, 10)
                stage.unit(220).setAI(4, -1, 17, 10)
                stage.unit(221).setAI(4, -1, 17, 10)
                stage.unit(222).setAI(4, -1, 17, 10)
            vars[2] = 1
        else:
            stage.say('&50\n좋아!\n이 빚은 양평관에서 갚을 것이다!')
            stage.unit(50).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(59, 7, 0, 2):
        stage.say('&59\n와!\n나 망했어...... 말도 안 돼!')
        stage.unit(59).hide(2)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n유비주군, 손첸은 비켜버렸어......\n손첸이 동행하게 해주세요, 음.')
        stage.unit(40).hide(2)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n이거 큰일이야!\n후퇴!')
        stage.unit(71).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n오?\n내가 진짜로 패배한 거야?\n빨리 뛰어!')
        stage.unit(73).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n음, 조준은 꽤 인상적이네.\n하지만 나는 끈질긴 사람이야,\n다음에 다시 찾아올게.')
        stage.unit(72).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n좋지 않아, 먼저 후퇴하자......')
        stage.unit(58).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n정말 여기서 죽고 싶지 않아.\n일단 후퇴하자!')
        stage.unit(37).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(61, 7, 0, 2):
        stage.say('&61\n안 돼! 더는 못 참겠어...... 이게 끝이야......')
        stage.unit(61).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(43, 7, 0, 2):
        stage.say('&43\n나도 죽어가는 걸까?\n전 영주 지안용이 바로 당신을 안내하러 갈 것입니다.')
        stage.unit(43).hide(2)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(60, 7, 0, 2):
        stage.say('&60\n안 좋으니 도망가......\n아, 더는 못 참겠어...... 내 앞에 있던 모든 게 칠흑같이 어두웠어.')
        stage.unit(60).hide(2)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n이번에는 내 실수였어,\n도둑조조Old, 운이 좋다고 생각해."\n다음에 너랑 마주치면 절대 그냥 두지 않을 거야!')
        stage.unit(57).hide(1)
        vars[63] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아요, 이렇게 하면 미래에 대한 걱정이 없어요.\n전체 군대는 계속 전진했다.\n우리는 공명 음모를 반드시 진압해야 합니다.')
        stage.reward(0, [
            144,
            -1])
        stage.end()
        vars[0] = 1
        vars[654] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조의 군대는 서나라 군대에 결정적으로 패배하고 도망쳤다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
