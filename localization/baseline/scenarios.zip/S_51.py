# Source Generated with Decompyle++
# File: S_51.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(19,19)',
        '(19,20)',
        '(20,19)',
        '(20,20)'])
    stage.nearEvent([
        3,
        96,
        3,
        82])
    stage.nearEvent([
        0,
        77,
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(40, -2, 76, 0, 0, 1)
    stage.createEnemy(
        [{'id': 76, 'x': 19, 'y': 20, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 77, 'x': 20, 'y': 20, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 79, 'x': 19, 'y': 19, 'dir': 0, 'lv': 6, 'i': 2},
         {'id': 350, 'x': 20, 'y': 19, 'dir': 0, 'lv': 0, 'i': 3},
         {'id': 82, 'x': 20, 'y': 13, 'dir': 0, 'lv': 4, 'i': 4},
         {'id': 92, 'x': 20, 'y': 14, 'dir': 0, 'lv': 4, 'i': 5},
         {'id': 210, 'x': 19, 'y': 13, 'dir': 0, 'lv': 0, 'i': 6},
         {'id': 211, 'x': 18, 'y': 14, 'dir': 0, 'lv': 0, 'i': 7},
         {'id': 212, 'x': 21, 'y': 14, 'dir': 0, 'lv': 0, 'i': 8},
         {'id': 234, 'x': 19, 'y': 14, 'dir': 0, 'lv': 0, 'i': 9},
         {'id': 84, 'x': 10, 'y': 12, 'dir': 3, 'lv': 6, 'i': 10},
         {'id': 86, 'x': 10, 'y': 13, 'dir': 3, 'lv': 4, 'i': 11},
         {'id': 361, 'x': 10, 'y': 11, 'dir': 3, 'lv': 0, 'i': 12},
         {'id': 358, 'x': 10, 'y': 14, 'dir': 3, 'lv': 0, 'i': 13},
         {'id': 359, 'x': 9, 'y': 12, 'dir': 3, 'lv': 0, 'i': 14},
         {'id': 360, 'x': 9, 'y': 13, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 81, 'x': 14, 'y': 19, 'dir': 3, 'lv': 6, 'i': 16},
         {'id': 88, 'x': 14, 'y': 20, 'dir': 3, 'lv': 4, 'i': 17},
         {'id': 213, 'x': 13, 'y': 19, 'dir': 3, 'lv': 0, 'i': 18},
         {'id': 214, 'x': 13, 'y': 20, 'dir': 3, 'lv': 0, 'i': 19},
         {'id': 235, 'x': 14, 'y': 18, 'dir': 3, 'lv': 0, 'i': 20},
         {'id': 236, 'x': 14, 'y': 21, 'dir': 3, 'lv': 0, 'i': 21},
         {'id': 85, 'x': 29, 'y': 12, 'dir': 1, 'lv': 6, 'i': 22},
         {'id': 96, 'x': 29, 'y': 13, 'dir': 1, 'lv': 4, 'i': 23},
         {'id': 282, 'x': 29, 'y': 11, 'dir': 1, 'lv': 0, 'i': 24},
         {'id': 258, 'x': 30, 'y': 12, 'dir': 1, 'lv': 0, 'i': 25},
         {'id': 310, 'x': 30, 'y': 13, 'dir': 1, 'lv': 0, 'i': 26},
         {'id': 311, 'x': 29, 'y': 14, 'dir': 1, 'lv': 0, 'i': 27},
         {'id': 78, 'x': 25, 'y': 19, 'dir': 1, 'lv': 6, 'i': 28},
         {'id': 80, 'x': 25, 'y': 20, 'dir': 1, 'lv': 6, 'i': 29},
         {'id': 215, 'x': 26, 'y': 19, 'dir': 1, 'lv': 0, 'i': 30},
         {'id': 216, 'x': 26, 'y': 20, 'dir': 1, 'lv': 0, 'i': 31},
         {'id': 237, 'x': 25, 'y': 18, 'dir': 1, 'lv': 0, 'i': 32},
         {'id': 238, 'x': 25, 'y': 21, 'dir': 1, 'lv': 0, 'i': 33},
         {'id': 298, 'x': 16, 'y': 10, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 34},
         {'id': 299, 'x': 16, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 35},
         {'id': 300, 'x': 23, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 36},
         {'id': 301, 'x': 23, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 37},
         {'id': 302, 'x': 6, 'y': 9, 'lv': 0, 'ai': 0, 'i': 38},
         {'id': 303, 'x': 7, 'y': 9, 'lv': 0, 'ai': 0, 'i': 39},
         {'id': 304, 'x': 32, 'y': 9, 'lv': 0, 'ai': 0, 'i': 40},
         {'id': 305, 'x': 33, 'y': 9, 'lv': 0, 'ai': 0, 'i': 41},
         {'id': 306, 'hide': 1, 'x': 14, 'y': 16, 'lv': 0, 'ai': 0, 'i': 42},
         {'id': 307, 'hide': 1, 'x': 16, 'y': 16, 'lv': 0, 'ai': 0, 'i': 43},
         {'id': 308, 'hide': 1, 'x': 23, 'y': 16, 'lv': 0, 'ai': 0, 'i': 44},
         {'id': 309, 'hide': 1, 'x': 25, 'y': 16, 'lv': 0, 'ai': 0, 'i': 45},
         {'id': 239, 'x': 16, 'y': 11, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 46},
         {'id': 240, 'x': 23, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 47},
         {'id': 241, 'x': 5, 'y': 9, 'lv': 0, 'ai': 0, 'i': 48},
         {'id': 242, 'x': 8, 'y': 9, 'lv': 0, 'ai': 0, 'i': 49},
         {'id': 243, 'x': 31, 'y': 9, 'lv': 0, 'ai': 0, 'i': 50},
         {'id': 244, 'x': 34, 'y': 9, 'lv': 0, 'ai': 0, 'i': 51},
         {'id': 245, 'hide': 1, 'x': 15, 'y': 16, 'lv': 0, 'ai': 0, 'i': 52},
         {'id': 246, 'hide': 1, 'x': 24, 'y': 16, 'lv': 0, 'ai': 0, 'i': 53},
         {'id': 414, 'x': 8, 'y': 18, 'dir': 3, 'lv': 0, 'i': 54},
         {'id': 415, 'x': 8, 'y': 19, 'dir': 3, 'lv': 0, 'i': 55},
         {'id': 416, 'x': 8, 'y': 20, 'dir': 3, 'lv': 0, 'i': 56},
         {'id': 417, 'x': 8, 'y': 21, 'dir': 3, 'lv': 0, 'i': 57},
         {'id': 418, 'x': 11, 'y': 8, 'dir': 0, 'lv': 0, 'i': 58},
         {'id': 419, 'x': 12, 'y': 8, 'dir': 0, 'lv': 0, 'i': 59},
         {'id': 420, 'x': 13, 'y': 8, 'dir': 0, 'lv': 0, 'i': 60},
         {'id': 421, 'x': 14, 'y': 8, 'dir': 0, 'lv': 0, 'i': 61},
         {'id': 422, 'x': 31, 'y': 18, 'dir': 1, 'lv': 0, 'i': 62},
         {'id': 423, 'x': 31, 'y': 19, 'dir': 1, 'lv': 0, 'i': 63},
         {'id': 424, 'x': 31, 'y': 20, 'dir': 1, 'lv': 0, 'i': 64},
         {'id': 425, 'x': 31, 'y': 21, 'dir': 1, 'lv': 0, 'i': 65},
         {'id': 426, 'x': 25, 'y': 8, 'dir': 0, 'lv': 0, 'i': 66},
         {'id': 427, 'x': 26, 'y': 8, 'dir': 0, 'lv': 0, 'i': 67},
         {'id': 428, 'x': 27, 'y': 8, 'dir': 0, 'lv': 0, 'i': 68},
         {'id': 429, 'x': 28, 'y': 8, 'dir': 0, 'lv': 0, 'i': 69},
         {'id': 430, 'x': 18, 'y': 18, 'dir': 0, 'lv': 0, 'i': 70},
         {'id': 431, 'x': 21, 'y': 18, 'dir': 0, 'lv': 0, 'i': 71},
         {'id': 432, 'x': 18, 'y': 21, 'dir': 0, 'lv': 0, 'i': 72},
         {'id': 433, 'x': 21, 'y': 21, 'dir': 0, 'lv': 0, 'i': 73}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 19,
            'y': 1 },
        {
            'idx': 1,
            'x': 1,
            'y': 20,
            'dir': 1 },
        {
            'idx': 2,
            'x': 38,
            'y': 19,
            'dir': 3 },
        {
            'idx': 3,
            'x': 20,
            'y': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 19,
            'dir': 1 },
        {
            'idx': 5,
            'x': 38,
            'y': 20,
            'dir': 3 },
        {
            'idx': 6,
            'x': 18,
            'y': 1 },
        {
            'idx': 7,
            'x': 1,
            'y': 21,
            'dir': 1 },
        {
            'idx': 8,
            'x': 38,
            'y': 18,
            'dir': 3 },
        {
            'idx': 9,
            'x': 21,
            'y': 1 },
        {
            'idx': 10,
            'x': 1,
            'y': 18,
            'dir': 1 },
        {
            'idx': 11,
            'x': 38,
            'y': 21,
            'dir': 3 },
        {
            'idx': 12,
            'x': 19 },
        {
            'idx': 13,
            'y': 20,
            'dir': 1 },
        {
            'idx': 14,
            'x': 39,
            'y': 19,
            'dir': 3 }])
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(51)
    stage.setObjects(True, 17, [
        [
            55,
            9,
            19],
        [
            56,
            9,
            20]])
    stage.setObjects(True, 17, [
        [
            57,
            12,
            9],
        [
            58,
            13,
            9]])
    stage.setObjects(True, 17, [
        [
            59,
            26,
            9],
        [
            60,
            27,
            9]])
    stage.setObjects(True, 17, [
        [
            53,
            30,
            19],
        [
            54,
            30,
            20]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab34')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab34')
    stage.draw()
    stage.bgSound(5)
    stage.unit(0).setDir(stage.countDir(0, 76))
    stage.say('&0\n이곳이 점령되는 한,\n오나라 군대는 더 이상 의지할 곳이 없었다.')
    stage.unit(0).setAction(5)
    stage.say('&0\n전면 군대 공격!\n손권를 죽이고 우를 점령하라!')
    stage.unit(0).setAction(0)
    stage.unit(79).setDir(stage.countDir(79, 0))
    stage.say('&79\n결국 그들은 이 지점에 이르게 되었다.\n손권주군,\n쓸데없는 저항을 그만두자......')
    stage.unit(76).setDir(stage.countDir(76, 79))
    stage.say('&76\n세상을 지배하는 것은 아버지와 형제들의 열망이다,\n선 가문의 꿈은 쉽게 포기해서는 안 된다.')
    stage.unit(76).setDir(stage.countDir(76, 77))
    stage.say('&76\n주유, 정말 다른 방법이 없는 걸까?')
    stage.unit(77).setDir(stage.countDir(77, 76))
    stage.say('&77\n공진은 이미 준비가 되어 있었다.\n이것은 공명 선인들이 나무 인형을 조종하기 위해 가르치는 비밀 기술이다.\n&76\n나무 인형을 조종할 수 있어?\n&77\n쓰러져도 다시 부활해 싸울 수 있어,\n천하 무적의 비밀 기술이라 할 수 있다.\n&76\n이런 불멸의 예술이 존재한다면, 왜 이전에는 사용되지 않았을까요?\n&77\n왜냐하면 그것이 수행자의 수명을 단축시키기 때문이다,\n보통은 가볍게 사용할 수 없지만, ......\n지금이 바로 그걸 사용할 완벽한 시기야.')
    stage.unit(77).setDir(stage.countDir(77, 78))
    stage.unit(78).setDir(stage.countDir(78, 76))
    stage.unit(80).setDir(stage.countDir(80, 76))
    stage.unit(81).setDir(stage.countDir(81, 76))
    stage.unit(88).setDir(stage.countDir(88, 76))
    stage.say("&77\n우를 위해서라도 이번에는 여러분 모두에게 의지해야 합니다.\n노숙, 여몽, 육손, 장자오.\n장군들이 내 주군을 충성스럽게 섬기길 바란다.\n&78\n저는 주저 없이 결심할 것임을 이해합니다.\n&80\n우나라에 모든 것을 바치자!\n내 여몽 인생은 '깃털처럼 가벼워'야.\n설령 의를 위해 자신을 희생하더라도 후회 없이 죽겠다!\n&81\n단 한 생명을 희생하는 것이 오나라를 구할 수 있다면,\n나, 루보얀은 내 생명과 영혼을 바칠 준비가 되어 있다.\n&88\n저는 완전히 준비되어 있습니다,\n그리고 지휘관의 명령에 신중히 복종할 것이다.")
    stage.unit(76).setDir(stage.countDir(76, 78))
    stage.say('&76\n수고해 주셔서 감사합니다.\n이 전투가 끝나면 평화롭게 쉬고 회복할 수 있을 거야.\n&82\n주군, 정면 대결은 우리에게 남겨!\n&92\n나는 절대 악당을 통과시키지 않을 거야!\n&84\n끝까지 버티고 절대 포기하지 않을 거야!\n용기 있으면 나한테 덤벼!\n&86\n나는 조의 군대가 전혀 두렵지 않다!\n&85\n승패가 이 한 수에 달려 있다!\n&96\n더는 기다릴 수 없어.')
    stage.unit(77).setDir(0)
    stage.unit(78).setDir(1)
    stage.unit(80).setDir(1)
    stage.unit(81).setDir(3)
    stage.unit(88).setDir(3)
    stage.unit(76).setDir(stage.countDir(76, 0))
    stage.unit(76).setAction(2)
    stage.say('&76\n이 전투는 동우의 생존과 관련이 있다.\n조조, 이번에는 네가 나를 새로운 모습으로 보게 해줄게!')
    stage.setWinCondition('승리 조건\n1. 손권 패배.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 40명을 초과한다.')
    stage.showWinCondition('손권를 이겨라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[551] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[70] and stage.round() == 4:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[70] = 1
    if not vars[71] and stage.round() == 7:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[71] = 1
    if not vars[72] and stage.round() == 10:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[72] = 1
    if not vars[73] and stage.round() == 13:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[73] = 1
    if not vars[74] and stage.round() == 16:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[74] = 1
    if not vars[75] and stage.round() == 19:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[75] = 1
    if not vars[76] and stage.round() == 22:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[76] = 1
    if not vars[77] and stage.round() == 25:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[77] = 1
    if not vars[78] and stage.round() == 28:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[78] = 1
    if not vars[79] and stage.round() == 31:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[79] = 1
    if not vars[80] and stage.round() == 34:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[80] = 1
    if not vars[81] and stage.round() == 37:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[81] = 1
    if not vars[82] and stage.round() == 40:
        if vars[32] and not vars[51]:
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
        if vars[32] and not vars[57]:
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        if vars[33] and not vars[58]:
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
        if vars[33] and not vars[63]:
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
        if vars[34] and not vars[55]:
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        vars[82] = 1
    if not vars[20] and stage.isInPos(1025, 19, 19):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 19, 20):
        stage.getItem(152, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 20, 19):
        stage.getItem(152, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 20, 20):
        stage.getItem(152, -1, True, 1025)
        vars[23] = 1
    if not vars[30] and not vars[34] and stage.isInRect(1025, 29, 11, 33, 14):
        if not vars[59]:
            stage.unit(85).setAction(5)
            stage.say('&85\n적을 지나가지 못하게 해!\n목숨을 걸더라도 이곳을 지켜야 해!')
            stage.unit(85).setAction(0)
        if not vars[53]:
            stage.unit(96).setAction(2)
            stage.say('&96\n또 실패하면 끝장이야.\n죽음조차도 적이 이곳을 통과하지 못하게 할 것이다.')
        stage.setAI(29, 11, 31, 14, 2, 1)
        vars[30] = 1
    if not vars[31] and not vars[34] and stage.isInRect(1025, 6, 11, 10, 14):
        if not vars[64]:
            stage.unit(84).setAction(7)
            stage.say('&84\n적이 온다!\n죽고 싶으면 나한테 덤벼라!')
            stage.unit(84).setAction(0)
        if not vars[52]:
            stage.say('&86\n절대 통과시킬 수 없어!')
        stage.setAI(8, 11, 10, 14, 2, 1)
        vars[31] = 1
    if not vars[32] and stage.isInRect(1025, 9, 9, 13, 23):
        if not vars[57]:
            stage.unit(88).setAction(5)
            stage.say('&88\n자, 나무 인간아, 다시 살아나!\n조의 공격을 막아라!')
            stage.unit(88).setAction(0)
            stage.unit(418).show(11, 8, 0)
            stage.unit(419).show(12, 8, 0)
            stage.unit(420).show(13, 8, 0)
            stage.unit(421).show(14, 8, 0)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
            stage.setObjects(False, 16, [
                [
                    57,
                    12,
                    9],
                [
                    58,
                    13,
                    9]])
        if not vars[51]:
            stage.unit(81).setAction(5)
            stage.say('&81\n반복된 집중 훈련 후,\n이 비밀 기술이 마침내 쓸모가 있었다.\n게다가 나무 인간이 죽은 후에도 계속 부활할 수 있어!')
            stage.unit(81).setAction(0)
            stage.unit(414).show(8, 18, 3)
            stage.unit(415).show(8, 19, 3)
            stage.unit(416).show(8, 20, 3)
            stage.unit(417).show(8, 21, 3)
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.setObjects(False, 16, [
                [
                    55,
                    9,
                    19],
                [
                    56,
                    9,
                    20]])
        vars[32] = 1
    if not vars[33] and stage.isInRect(1025, 26, 9, 30, 23):
        if not vars[63]:
            stage.unit(80).setAction(5)
            stage.say('&80\n나무 인형들 앞에서 조의 군대는 무력했다.\n부활해라, 나무 인간아!')
            stage.unit(80).setAction(0)
            stage.unit(426).show(25, 8, 0)
            stage.unit(427).show(26, 8, 0)
            stage.unit(428).show(27, 8, 0)
            stage.unit(429).show(28, 8, 0)
            stage.unit(426).setAI(1)
            stage.unit(427).setAI(1)
            stage.unit(428).setAI(1)
            stage.unit(429).setAI(1)
            stage.setObjects(False, 16, [
                [
                    59,
                    26,
                    9],
                [
                    60,
                    27,
                    9]])
        if not vars[58]:
            stage.unit(78).setAction(5)
            stage.say('&78\n제발, 다시 살아나, 나무 인간!\n무승조조 내 우나라를 구하라.')
            stage.unit(78).setAction(0)
            stage.unit(422).show(31, 18, 1)
            stage.unit(423).show(31, 19, 1)
            stage.unit(424).show(31, 20, 1)
            stage.unit(425).show(31, 21, 1)
            stage.unit(422).setAI(1)
            stage.unit(423).setAI(1)
            stage.unit(424).setAI(1)
            stage.unit(425).setAI(1)
            stage.setObjects(False, 16, [
                [
                    53,
                    30,
                    19],
                [
                    54,
                    30,
                    20]])
        vars[33] = 1
    if not vars[34] and stage.curCamp() == 2 and stage.isInRect(1025, 13, 13, 26, 23):
        if not vars[55]:
            stage.unit(77).setAction(5)
            stage.say('&77\n조조 군대의 피가 나무 인형들을 물들이게 하라.\n조조의 군대는 두려움에 떨었다,\n이는 오나라 부흥의 찬사를 받는 사례가 될 것이다.\n&77\n부활해라, 나무 인간아!\n조조 군대의 대패와 주유 위대한 승리를 기원합니다!')
            stage.unit(77).setAction(0)
            stage.unit(430).show(18, 18, 0)
            stage.unit(431).show(21, 18, 0)
            stage.unit(432).show(18, 21, 0)
            stage.unit(433).show(21, 21, 0)
            stage.unit(430).setAI(1)
            stage.unit(431).setAI(1)
            stage.unit(432).setAI(1)
            stage.unit(433).setAI(1)
        if not vars[56]:
            stage.say('&79\n그는 더 이상 조의 군대가 주군 접근하는 것을 허락할 수 없었다.\n반드시 그들을 막아낼 방법을 찾아야 해!')
        if not vars[50]:
            stage.say('&76\n조조!\n죽어도 포기하지 않을 거야, 손권 죽어!')
        if not vars[32]:
            if not vars[57]:
                stage.unit(88).setAction(5)
                stage.say('&88\n자, 나무 인간아, 다시 살아나!\n조의 공격을 막아라!')
                stage.unit(88).setAction(0)
                stage.unit(418).show(11, 8, 0)
                stage.unit(419).show(12, 8, 0)
                stage.unit(420).show(13, 8, 0)
                stage.unit(421).show(14, 8, 0)
                stage.unit(418).setAI(1)
                stage.unit(419).setAI(1)
                stage.unit(420).setAI(1)
                stage.unit(421).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        57,
                        12,
                        9],
                    [
                        58,
                        13,
                        9]])
            if not vars[51]:
                stage.unit(81).setAction(5)
                stage.say('&81\n반복된 집중 훈련 후,\n이 비밀 기술이 마침내 쓸모가 있었다.\n게다가 나무 인간이 죽은 후에도 계속 부활할 수 있어!')
                stage.unit(81).setAction(0)
                stage.unit(414).show(8, 18, 3)
                stage.unit(415).show(8, 19, 3)
                stage.unit(416).show(8, 20, 3)
                stage.unit(417).show(8, 21, 3)
                stage.unit(414).setAI(1)
                stage.unit(415).setAI(1)
                stage.unit(416).setAI(1)
                stage.unit(417).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        55,
                        9,
                        19],
                    [
                        56,
                        9,
                        20]])
            vars[32] = 1
        if not vars[33]:
            if not vars[63]:
                stage.unit(80).setAction(5)
                stage.say('&80\n나무 인형들 앞에서 조의 군대는 무력했다.\n부활해라, 나무 인간아!')
                stage.unit(80).setAction(0)
                stage.unit(426).show(25, 8, 0)
                stage.unit(427).show(26, 8, 0)
                stage.unit(428).show(27, 8, 0)
                stage.unit(429).show(28, 8, 0)
                stage.unit(426).setAI(1)
                stage.unit(427).setAI(1)
                stage.unit(428).setAI(1)
                stage.unit(429).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        59,
                        26,
                        9],
                    [
                        60,
                        27,
                        9]])
            if not vars[58]:
                stage.unit(78).setAction(5)
                stage.say('&78\n제발, 다시 살아나, 나무 인간!\n무승조조 내 우나라를 구하라.')
                stage.unit(78).setAction(0)
                stage.unit(422).show(31, 18, 1)
                stage.unit(423).show(31, 19, 1)
                stage.unit(424).show(31, 20, 1)
                stage.unit(425).show(31, 21, 1)
                stage.unit(422).setAI(1)
                stage.unit(423).setAI(1)
                stage.unit(424).setAI(1)
                stage.unit(425).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        53,
                        30,
                        19],
                    [
                        54,
                        30,
                        20]])
            vars[33] = 1
        stage.setAI(0, 0, 39, 23, 2, 1)
        stage.unit(76).setAI(2)
        stage.unit(77).setAI(2)
        stage.unit(79).setAI(0)
        stage.unit(350).setAI(0)
        stage.unit(81).setAI(3, 76, 0, 0)
        stage.unit(88).setAI(3, 76, 0, 0)
        stage.unit(78).setAI(3, 76, 0, 0)
        stage.unit(80).setAI(3, 76, 0, 0)
        vars[34] = 1
    if not vars[40] and stage.isNear(0, 77, True):
        stage.unit(0).setDir(stage.countDir(0, 77))
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&0\n주유, 네 죽음의 시간이 왔어.\n정확히 무슨 의도me공명인지 말해봐.\n&77\n이 일은 원래 나와는 아무 상관없었어,\n하지만 모든 것이 순조롭게 진행되는 것을 보면,\n정말 화가 나요.\n&77\n음, 만약 네가 나를 이길 수 있다면,\n말해줄게.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n손권, 너도 드디어 끝에 도달했구나.\n&76\n그렇다면, 아버지와 형의 명예를 더럽히지 않는 것으로,\n전장에서 존엄하게 죽었다!')
        vars[41] = 1
    if not vars[42] and stage.isNear(3, 96, False):
        stage.unit(3).setDir(stage.countDir(3, 96))
        stage.unit(96).setDir(stage.countDir(96, 3))
        stage.say('&3\n너 딩펑이야?\n관과 해결하자!')
        fight = stage.startFight(3, 96, 5)
        fight.showUnit(True, '지옥의 왕을 만나러 보내주겠다!', 0)
        fight.showUnit(False, '흥!', 9)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack1(False, 1, True)
        stage.delay(10)
        fight.setAction(True, 8)
        fight.say(True, '정말 순진했어!', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, False)
        fight.attack2(True, 0, False)
        fight.attack2(True, 1, False)
        stage.delay(20)
        fight.say(False, '역시나, 나는 여전히 그를 이기지 못했다......\n…… 말도 안 돼!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '셋째 형님, 내가 복수했어요.\n행복해?', True)
        fight.end()
        stage.unit(96).hide(2)
        vars[42] = 1
    if not vars[43] and stage.isNear(3, 82, False):
        stage.unit(3).setDir(stage.countDir(3, 82))
        stage.unit(82).setDir(stage.countDir(82, 3))
        stage.say('&3\n판장, 드디어 찾았어!\n&82\n아, 관관우인가!?')
        fight = stage.startFight(3, 82, 5)
        fight.showUnit(True, '죽을 준비가 됐어?', 8)
        fight.showUnit(False, '……으윽!', 6)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '음, 아!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 4, False)
        stage.delay(5)
        fight.setAction(False, 1)
        fight.say(False, '하!', True)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.say(False, '말도 안 돼!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 6)
        stage.delay(10)
        fight.say(True, '관싱, 나는 네 아버지로서 복수했다.\n편히 쉬세요......', True)
        fight.end()
        stage.unit(82).hide(2)
        stage.getItem(118, -1, True, 3)
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.say('&76\n상황이 절망적인가요?\n차라리 항복하는 게 낫겠다.\n&0\n훌륭해.\n너희 부하들과 오 백성들이여,\n조조가 반드시 그들의 안전을 보장할 거야.\n&76\n그럼 편히 쉴 수 있겠네...... 음음음......\n때가 온 것 같아...... 안녕, 친구조조......\n약속을 어길 수 없어...... 거짓말 안 해......')
        stage.unit(76).hide(2)
        vars[50] = 1
        if not vars[58]:
            stage.say('&78\n주군!\n즈징이 너희와 함께 있으러 왔어.\n말도 안 돼!')
            stage.unit(78).hide(2)
            stage.unit(422).hide(1)
            stage.unit(423).hide(1)
            stage.unit(424).hide(1)
            stage.unit(425).hide(1)
            vars[58] = 1
        if not vars[63]:
            stage.say('&80\n"충성스러운 신하가 두 주인을 섬기지 않는다."\n나도 같이 갈게.')
            stage.unit(80).hide(2)
            stage.unit(426).hide(1)
            stage.unit(427).hide(1)
            stage.unit(428).hide(1)
            stage.unit(429).hide(1)
            vars[63] = 1
        if not vars[51]:
            stage.say('&81\n주군, 육손 끝까지 따라갈 준비가 되어 있어.\n말도 안 돼!')
            stage.unit(81).hide(2)
            stage.unit(414).hide(1)
            stage.unit(415).hide(1)
            stage.unit(416).hide(1)
            stage.unit(417).hide(1)
            vars[51] = 1
        if not vars[57]:
            stage.say('&88\n죽더라도 나는 오나라 장군으로 봉사하고 싶다.')
            stage.unit(88).hide(2)
            stage.unit(418).hide(1)
            stage.unit(419).hide(1)
            stage.unit(420).hide(1)
            stage.unit(421).hide(1)
            vars[57] = 1
        if not vars[55]:
            stage.unit(77).setAction(4)
            stage.say('&77\n안타깝게도 우의 기세는 이미 사라졌다......\n뜻밖에도 결국 그는 공명......에게 조종당했다\n&77\n나는 그저 따라갈 수밖에 없었주군......\n하지만 아직 중요한 일이 남아 있어.\n주군, 잠시만 기다려 주유.')
            stage.unit(77).setAction(0)
            stage.unit(77).setDir(stage.countDir(77, 0))
            stage.say('&77\n음음,\n조조 일을 당신에게 맡길 줄은 몰랐어요......')
            stage.unit(77).hide(1)
            stage.unit(430).hide(1)
            stage.unit(431).hide(1)
            stage.unit(432).hide(1)
            stage.unit(433).hide(1)
            vars[55] = 1
        stage.say('동오는 이미 우리 위군에게 점령당했습니다. 하지만 난세를 평정하기 전까지 공명을 제거하지 않으면, 진정한 평화는 오지 않을 겁니다. 전군은 일단 건업에서 대기하며 새로운 지시를 기다리겠습니다.')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[651] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n흠!\n내 죽음이 왔다!')
        stage.unit(81).hide(2)
        stage.unit(414).hide(1)
        stage.unit(415).hide(1)
        stage.unit(416).hide(1)
        stage.unit(417).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n오, 안 돼!\n이 사람 손에 죽다니 믿기지 않아......\n말도 안 돼!')
        stage.unit(86).hide(2)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n허용되지 않습니다......\n그는 일어설 수 없었다......\n음음!')
        stage.unit(96).hide(2)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n혹시 내가 명성이나 지위를 얻기 전에 죽은 걸까?\n정말 안타깝네요!')
        stage.unit(82).hide(2)
        stage.getItem(118, -1, True, 1027)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(77, 7, 0, 2):
        stage.unit(77).setAction(4)
        stage.say('&77\n안타깝게도 우는 국가를 부흥시키지 못했다......\n뜻밖에도 결국 그는 공명......에게 조종당했다')
        stage.unit(77).hide(1)
        stage.unit(430).hide(1)
        stage.unit(431).hide(1)
        stage.unit(432).hide(1)
        stage.unit(433).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n주군, 쯔위는 무력했다.\n음......')
        stage.unit(79).hide(2)
        stage.getItem(52, -1, True, 1027)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n음음! 소환사가 도착한 것 같아......')
        stage.unit(88).hide(2)
        stage.unit(418).hide(1)
        stage.unit(419).hide(1)
        stage.unit(420).hide(1)
        stage.unit(421).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n아, 아, 아!\n정말 이걸 할 거야...... 으으.')
        stage.unit(78).hide(2)
        stage.unit(422).hide(1)
        stage.unit(423).hide(1)
        stage.unit(424).hide(1)
        stage.unit(425).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n내 인생이 끝난 것 같아!\n정말 화가 나네요...... 말도 안 돼요.')
        stage.unit(85).hide(2)
        stage.getItem(110, -1, True, 1027)
        vars[59] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n와!\n수많은 적을 죽일 수 있게 해주고,\n죽어도 만족할 거예요......')
        stage.unit(92).hide(2)
        vars[61] = 1
    if not vars[63] and stage.unitStateTest(80, 7, 0, 2):
        stage.say('&80\n"인생은 꿈과 같아."\n전장에서 죽는 것도 일종의 재미입니다. 거짓말 아니에요......')
        stage.unit(80).hide(2)
        stage.unit(426).hide(1)
        stage.unit(427).hide(1)
        stage.unit(428).hide(1)
        stage.unit(429).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n안 돼! 다쳤어......\n음, 음... 사실 치명적인 부상이야......\n정말 원하지 않는다는 것......')
        stage.unit(84).hide(2)
        stage.getItem(91, -1, True, 1027)
        vars[64] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('동오는 이미 우리 위군에게 점령당했습니다. 하지만 난세를 평정하기 전까지 공명을 제거하지 않으면, 진정한 평화는 오지 않을 겁니다. 전군은 일단 건업에서 대기하며 새로운 지시를 기다리겠습니다.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[651] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
