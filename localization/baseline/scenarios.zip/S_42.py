# Source Generated with Decompyle++
# File: S_42.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,4)',
        '(14,3)',
        '(13,3)',
        '(14,4)'])
    stage.nearEvent([
        9,
        58])
    stage.nearEvent([
        0,
        69], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 13, 'y': 4, 'lv': 6, 'i': 0},
         {'id': 69, 'x': 13, 'y': 6, 'lv': 6, 'i': 1},
         {'id': 55, 'x': 12, 'y': 6, 'lv': 4, 'i': 2},
         {'id': 56, 'x': 15, 'y': 6, 'lv': 4, 'i': 3},
         {'id': 350, 'x': 14, 'y': 6, 'lv': 0, 'i': 4},
         {'id': 298, 'x': 11, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 299, 'x': 11, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 300, 'x': 13, 'y': 10, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 301, 'x': 14, 'y': 10, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 302, 'x': 7, 'y': 9, 'lv': 0, 'i': 9},
         {'id': 303, 'x': 7, 'y': 10, 'lv': 0, 'i': 10},
         {'id': 304, 'x': 8, 'y': 10, 'lv': 0, 'i': 11},
         {'id': 210, 'x': 4, 'y': 9, 'lv': 0, 'i': 12},
         {'id': 211, 'x': 4, 'y': 10, 'lv': 0, 'i': 13},
         {'id': 212, 'x': 6, 'y': 13, 'dir': 1, 'lv': 0, 'i': 14},
         {'id': 213, 'x': 7, 'y': 13, 'dir': 1, 'lv': 0, 'i': 15},
         {'id': 234, 'x': 3, 'y': 9, 'lv': 0, 'i': 16},
         {'id': 235, 'x': 5, 'y': 9, 'lv': 0, 'i': 17},
         {'id': 236, 'x': 6, 'y': 12, 'dir': 1, 'lv': 0, 'i': 18},
         {'id': 237, 'x': 6, 'y': 14, 'dir': 1, 'lv': 0, 'i': 19},
         {'id': 58, 'x': 7, 'y': 3, 'dir': 3, 'lv': 6, 'i': 20},
         {'id': 50, 'x': 7, 'y': 5, 'dir': 3, 'lv': 6, 'i': 21},
         {'id': 60, 'x': 6, 'y': 4, 'dir': 3, 'lv': 4, 'i': 22},
         {'id': 214, 'x': 6, 'y': 3, 'dir': 3, 'lv': 0, 'i': 23},
         {'id': 462, 'x': 7, 'y': 4, 'dir': 3, 'lv': 0, 'i': 24},
         {'id': 342, 'x': 7, 'y': 2, 'dir': 3, 'lv': 0, 'i': 25},
         {'id': 72, 'x': 12, 'y': 14, 'lv': 6, 'i': 26},
         {'id': 71, 'x': 13, 'y': 14, 'lv': 4, 'i': 27},
         {'id': 73, 'x': 14, 'y': 14, 'lv': 4, 'i': 28},
         {'id': 382, 'x': 15, 'y': 14, 'lv': 0, 'i': 29},
         {'id': 384, 'x': 13, 'y': 15, 'lv': 0, 'i': 30},
         {'id': 383, 'x': 14, 'y': 15, 'lv': 0, 'i': 31},
         {'id': 310, 'hide': 1, 'x': 23, 'y': 17, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 32},
         {'id': 311, 'hide': 1, 'x': 23, 'y': 18, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 33},
         {'id': 312, 'hide': 1, 'x': 23, 'y': 19, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 34},
         {'id': 318, 'hide': 1, 'x': 23, 'y': 17, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 35},
         {'id': 319, 'hide': 1, 'x': 23, 'y': 18, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 36},
         {'id': 320, 'hide': 1, 'x': 23, 'y': 19, 'dir': 3, 'lv': -2, 'ai': 1, 'i': 37},
         {'id': 414, 'hide': 1, 'x': 12, 'y': 8, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 415, 'hide': 1, 'x': 13, 'y': 8, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 416, 'hide': 1, 'x': 14, 'y': 8, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 417, 'hide': 1, 'x': 15, 'y': 8, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 215, 'x': 12, 'y': 5, 'lv': 0, 'i': 42},
         {'id': 216, 'x': 13, 'y': 5, 'lv': 0, 'i': 43},
         {'id': 217, 'x': 14, 'y': 5, 'lv': 0, 'i': 44},
         {'id': 218, 'x': 15, 'y': 5, 'lv': 0, 'i': 45}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 13,
            'y': 20,
            'dir': 0 },
        {
            'idx': 1,
            'x': 14,
            'y': 20,
            'dir': 0 },
        {
            'idx': 2,
            'x': 12,
            'y': 20,
            'dir': 0 },
        {
            'idx': 3,
            'x': 15,
            'y': 20,
            'dir': 0 },
        {
            'idx': 4,
            'x': 13,
            'y': 21,
            'dir': 0 },
        {
            'idx': 5,
            'x': 14,
            'y': 21,
            'dir': 0 },
        {
            'idx': 6,
            'x': 12,
            'y': 21,
            'dir': 0 },
        {
            'idx': 7,
            'x': 15,
            'y': 21,
            'dir': 0 },
        {
            'idx': 8,
            'x': 13,
            'y': 22,
            'dir': 0 },
        {
            'idx': 9,
            'x': 14,
            'y': 22,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(42)
    stage.setObjects(True, 17, [
        [
            41,
            17,
            3],
        [
            42,
            17,
            4]])
    stage.setObjects(True, 17, [
        [
            39,
            21,
            3],
        [
            40,
            21,
            4]])
    stage.setObjects(True, 17, [
        [
            43,
            13,
            11],
        [
            44,
            14,
            11]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(4)
    stage.unit(72).setDir(stage.countDir(72, 0))
    stage.unit(71).setDir(stage.countDir(71, 0))
    stage.unit(73).setDir(stage.countDir(73, 0))
    stage.say('&72\n여러분, 잘 들어요, 이곳을 지켜야 해요,\n만약 그들이 다시 성공한다면,\n그러면 남부 사람들 앞에서 완전히 창피할 거야.\n&71\n맞아요.\n&73\n난 별로 신경 안 써.')
    stage.unit(58).setDir(stage.countDir(58, 0))
    stage.say('&58\n마텡의 군대는 나만 남았다.\n무슨 일이 있어도 이 화살의 복수를 할 거야.')
    stage.unit(60).setDir(stage.countDir(60, 35))
    stage.say('&60\n(공명 이 사람은 왜 여기 숨어 있는 거야?\n여기서 조의 군대를 막으려는 거야? )')
    stage.unit(50).setDir(stage.countDir(50, 0))
    stage.say('&50\n겁쟁이는 가난만 걱정할 줄 알아.')
    stage.unit(56).setDir(stage.countDir(56, 0))
    stage.unit(55).setDir(stage.countDir(55, 0))
    stage.say('&56\n이제 나는 오직 공명만 믿을 수 있다,\n무슨 일이 있어도 버텨야 해......\n&55\n분명히 전환점이 올 것입니다.\n자신감을 잃지 마세요.')
    stage.unit(69).setDir(stage.countDir(69, 35))
    stage.say('&69\n공명 선생님, 조의 군대가 이미 성문에 도착했습니다.\n명령을 내리십시오.')
    stage.unit(35).setDir(stage.countDir(35, 69))
    stage.say('&35\n이미 필요한 사람들에게 지시를 내렸습니다.\n장웨이, 내가 가르쳐준 전략 기억나?\n&69\n네, 모두 기억합니다.\n&35\n그래? 좋아.\n이 도시에서 조금만 더 버텨라,\n분명히 전환점이 올 것입니다.')
    stage.unit(0).setDir(stage.countDir(0, 35))
    stage.say('&0\n비록 서나라가 멸망했지만, 장기적인 계획을 위해,\n그는 서의 전 신하들을 그냥 내보낼 수 없었다.')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n하지만 아군 사상자도 상당했다......\nNow공명 바이디 성의 성문은 꽉 닫혀 있다......\n그것을 담으려면 많은 노력이 필요할 수 있습니다.')
    stage.unit(0).setDir(stage.countDir(0, 19))
    stage.say('&0\n중달, 좋은 조언이 있나요?\n&19\n이 방법이 성공할 가능성은 낮지만 시도해볼 가치가 있습니다.\n즉, 그들은 선봉대의 난만 군대에 뇌물을 주적군 셈이다.\n총리는 어떻게 생각할까?\n&0\n돈에 휘둘리는 사람은 없을 것 같아요.\n&19\n슈가 이미 무너졌으니 개인적인 감정에 신경 쓸 필요가 없었다.\n아직도 난만의 안전을 걱정한다면......\n&0\n그래서 그런 거야.\n남쪽 나라의 안전을 보장한다면,\n그들이 마지막 순간에 탈영할 가능성은 여전히 있나요?\n&19\n확률은 50%여야 합니다......')
    sel = stage.choice('말은 소용없어, 그냥 공격해.\n금 1,000냥을 협상해라', -1)
    if sel == 1:
        stage.say('&0\n우리는 방금 슈를 데려갔어,\n건설에 쓰인 돈은 낭비되어서는 안 됩니다.')
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(0).setAction(5)
        stage.say('&0\n이 도시를 그냥 그렇게 가져가자.\n전면 공격!')
        stage.unit(0).setAction(0)
        stage.say('&19\n복종해.')
    elif sel == 2:
        stage.say('&0\n좋아.\n만약 사상자를 줄일 수 있다면,\n이 방법은 실제로 시도해볼 가치가 있습니다.')
        stage.unit(0).setDir(stage.countDir(0, 71))
        stage.say('&0\n멍화, 잘 들어!\n당장 여기서 나가면,\n나는 네 나라를 공격하지 않겠다고 약속해.\n&0\n게다가 금 1,000냥을 받게 될 거야.\n슈는 파괴되었고, 너는 그들을 위해 싸울 이유가 없다.\n동의한다면 양쪽 모두에게 좋은 일이죠?')
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.say('&72\n우리 가격이 그렇게 싸지 않아.\n우리를 설득하려면 다시 한 번 진심을 보여줘야 해.')
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.say('&71\n맞아! 우리 피해도 상당하다,\n이 작은 돈이 어떻게 우리를 유혹할 수 있겠어?\n&0\n설득하는 걸 멈춰야 해,\n아니면 다시 더 높은 가격을 제시할까요?\n흠...... 어떻게 해야 할까요?')
        sel = stage.choice('무의미한 협상을 멈춰라\n금 2,000냥을 협상했다', -1)
        if sel == 1:
            stage.say('&0\n더 이상 돈을 마련할 수가 없었어요.\n여러분 모두 스스로 방법을 찾아야 합니다!\n&71\n하하하!\n우리는 결코 돈에 휘둘리지 않습니다,\n당신의 판단은 사실 꽤 정확합니다.\n&72\n남부 나라 사람들은 마음에 감동받는다,\n그들은 실제로 우리에게 돈을 주려 해,\n우릴 이렇게 얕보면 분명 후회할 거야!')
        elif sel == 2:
            stage.say('&0\n금 2,000냥을 바치겠습니다!')
            stage.unit(73).setDir(stage.countDir(73, 0))
            stage.say('&73\n2,000냥짜리 금으로 몇 개의 찐빵을 살 수 있을까?\n한 ...... 아니면 두 개......\n하아, 나도 모르겠어.')
            stage.unit(72).setDir(stage.countDir(72, 73))
            stage.say('&72\n이 돈으로 찐빵을 사고,\n죽을 때까지 먹게 만들 수도 있어!')
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.say('&72\n이 정도의 돈만으로는 여전히 부족합니다.\n다시 입찰하게 할게요!\n어떠신가요, 조 공?')
            sel = stage.choice('무의미한 협상을 멈춰라\n4,000냥 금으로 협상했다', -1)
            if sel == 1:
                stage.say('&0\n더 이상 생각해낼 수가 없어.\n선택의 여지가 없어, 그냥 공격해!\n&73\n아, 내 찐빵이 날아가네......\n&72\n앞으로 찐빵 얼마든지 먹어도 돼.\n&72\n지금 중요한 건 한 번에 앞으로 나아가는 거야!\n그렇지 않으면 막다른 길이야,\n이해나 하니?\n&71\n맞아!\n어쩌면 상황을 뒤집어 조조 수도 있겠네요.')
            elif sel == 2:
                stage.say('&0\n이것이 최종 가격입니다.\n금 4,000냥, 그 이상은 안 돼!\n&71\n아, 그럼 반대 없네요.')
    stage.setWinCondition('승리 조건\n1. 모든 적을 제거한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('적을 제거하라!')
    stage.startOper()
    vars[542] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[11] and stage.round() == 7:
        stage.unit(71).show(23, 17, 3)
        stage.unit(71).move(18, 17, 3)
        stage.unit(73).show(23, 18, 3)
        stage.unit(73).move(18, 18, 3)
        stage.unit(72).show(23, 19, 3)
        stage.unit(72).move(18, 19, 3)
        stage.unit(382).show(23, 17, 3)
        stage.unit(382).move(19, 17, 3)
        stage.unit(383).show(23, 18, 3)
        stage.unit(383).move(19, 18, 3)
        stage.unit(384).show(23, 19, 3)
        stage.unit(384).move(19, 19, 3)
        stage.unit(71).setAI(1)
        stage.unit(73).setAI(1)
        stage.unit(72).setAI(1)
        stage.unit(382).setAI(1)
        stage.unit(383).setAI(1)
        stage.unit(384).setAI(1)
        stage.unit(310).show()
        stage.unit(310).move(20, 17, 3)
        stage.unit(311).show()
        stage.unit(311).move(20, 18, 3)
        stage.unit(312).show()
        stage.unit(312).move(20, 19, 3)
        stage.unit(318).show()
        stage.unit(318).move(21, 17, 3)
        stage.unit(319).show()
        stage.unit(319).move(21, 18, 3)
        stage.unit(320).show()
        stage.unit(320).move(21, 19, 3)
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(73).setDir(stage.countDir(73, 0))
        stage.say('&71\n휴, 좀 늦은 것 같네요.\n하지만 병력은 이미 계획대로 이동했다.\n&72\n음음음, 조조 선생님,\n네가 준 돈은 이미 다 썼어.\n덕분에 괜찮은 용병도 고용했어.\n&73\n너무 배고파요......')
        stage.unit(0).setDir(stage.countDir(0, 71))
        stage.say('&0\n공명 남부 야만인들의 사기를 그렇게 잘 통제할 수 있었나요?\n지금은 상황이 나빠지고 있어......')
        if not vars[60]:
            stage.unit(19).setDir(stage.countDir(19, 71))
            stage.say('&19\n남부 야만군에 대한 뇌물조차도,\n공명 미리 예측할 수 있나요?')
        if not vars[51]:
            stage.unit(69).setDir(stage.countDir(69, 71))
            stage.say('&69\n아, 드디어 돌아왔구나!\n잠시 의심했던 점 용서해 주세요.\n정말 감사합니다!')
        if not vars[57]:
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(58).setAction(5)
            stage.say('&58\n좋아, 이제 조조 쫓아가자.\n이 훌륭한 기회를 놓치지 마세요!')
            stage.unit(58).setAction(0)
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 71))
            stage.say('&35\n모두 내 지시를 따르고 있지?\n이제 계획대로 조조을 추구하세요.')
        vars[11] = 1
    if vars[11] and not vars[12] and not vars[51] and not vars[52] and not vars[54] and stage.round() == 9 and stage.totalRectUnit(0, 10, 12, 17, 19) == 0:
        stage.unit(71).setDir(stage.countDir(71, 69))
        stage.unit(72).setDir(stage.countDir(72, 69))
        stage.unit(71).setAction(5)
        stage.say('&71\n문 열어!\n우린 들어갈 수 없어.')
        stage.unit(71).setAction(0)
        stage.say('&72\n빨리 열어!\n우릴 더 원해?')
        stage.unit(69).setDir(stage.countDir(69, 71))
        stage.unit(69).setAction(6)
        stage.say('&69\n흠, 흠!\n문 열어!\n서둘러!')
        stage.unit(69).setAction(0)
        stage.setObjects(False, 16, [
            [
                43,
                13,
                11],
            [
                44,
                14,
                11]])
        vars[12] = 1
    if vars[3] and not vars[51] and not vars[70] and stage.round() == 10:
        stage.say('&69\n이 나무 조각상들은 원래 생명이 없었다,\n부적으로 조종하는 한,\n사람은 죽었다가 다시 살아나는 일이 수없이 반복됩니다.\n&69\n부활해라, 나무 인간아!\n주인의 명령을 따라 조의 군대를 공격하라!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[70] = 1
    if vars[3] and not vars[51] and not vars[71] and stage.round() == 13:
        if not vars[70]:
            stage.say('&69\n이 나무 조각상들은 원래 생명이 없었다,\n부적으로 조종하는 한,\n사람은 죽었다가 다시 살아나는 일이 수없이 반복됩니다.\n&69\n부활해라, 나무 인간아!\n주인의 명령을 따라 조의 군대를 공격하라!')
        else:
            stage.say('&69\n하하하!\n부활해라, 나무 인간아!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[71] = 1
    if vars[3] and not vars[51] and not vars[72] and stage.round() == 16:
        stage.say('&69\n하하하! 내가 장웨이가 명령만 내리면,\n나무 인간은 수없이 부활할 수 있습니다.\n부활해!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[72] = 1
    if vars[3] and not vars[51] and not vars[73] and stage.round() == 19:
        stage.say('&69\n부활해라, 나무 인간아!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[73] = 1
    if vars[3] and not vars[51] and not vars[74] and stage.round() == 22:
        stage.say('&69\n그래서 조의 군대가 그렇게 끈질기구나!\n나무 조각상이 다시 살아나게 하라.')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[74] = 1
    if vars[3] and not vars[51] and not vars[75] and stage.round() == 25:
        stage.say('&69\n음, 젠장, 차오준, 정말 끈질기네!\n나무 인간, 공격해조조!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[75] = 1
    if vars[3] and not vars[51] and not vars[76] and stage.round() == 28:
        stage.say('&69\n나무 조각상이 다시 살아나게 하라.')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[76] = 1
    if vars[3] and not vars[51] and not vars[77] and stage.round() == 31:
        stage.say('&69\n나무 인형은 이미 여러 번 부활시켰습니다......\n이대로 계속되면 버틸 수 없을 거야.\n&69\n하지만 아직 포기할 때는 아니었다.\n부활해라, 나무 인간아!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[77] = 1
    if vars[3] and not vars[51] and not vars[78] and stage.round() == 34:
        stage.say('&69\n나무 인형들, 나와라!\n바이디 시티를 지켜라!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[78] = 1
    if vars[3] and not vars[51] and not vars[79] and stage.round() == 37:
        stage.say('&69\n조금 부족해.\n어서! 나무 인형!\n다시 부활해 조조을 공격했다.')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[79] = 1
    if vars[3] and not vars[51] and not vars[80] and stage.round() == 40:
        stage.say('&69\n이번에는 꼭 이겨야지, 그렇지!?\n안전하게 나무 인형을 부활시키자!')
        stage.unit(414).show(12, 8, 2)
        stage.unit(415).show(13, 8, 2)
        stage.unit(416).show(14, 8, 2)
        stage.unit(417).show(15, 8, 2)
        vars[3] = 0
        vars[61] = 0
        vars[62] = 0
        vars[63] = 0
        vars[64] = 0
        vars[80] = 1
    if not vars[20] and stage.isInPos(1025, 13, 4):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 14, 3):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 13, 3):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 14, 4):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[2] and not vars[30] and stage.isInRect(1025, 12, 13, 15, 17):
        if not vars[54]:
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.say('&72\n헤헤헤.\n드디어 여기까지 왔는데, 기다리다 거의 죽을 뻔했어요.\n여러분, 용기를 내서 참여해 주세요!')
        if not vars[52]:
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.say('&71\n남부 사람들의 대담함을 보여줘!')
        if not vars[53]:
            stage.unit(73).setDir(stage.countDir(73, 1025))
            stage.say('&73\n왜 이렇게 말이 길어!')
        stage.setAI(12, 13, 15, 16, 2, 1)
        vars[30] = 1
    if not vars[32] and stage.isInRect(1025, 11, 5, 16, 9):
        if not vars[58]:
            stage.unit(56).setDir(stage.countDir(56, 0))
            stage.say('&56\n여기서 죽는 거야...... 아니!\n나는 여전히 포기할 수 없다—끝까지 싸워야 한다!')
        if not vars[59]:
            stage.unit(55).setDir(stage.countDir(55, 0))
            stage.say('&55\n흠......')
        if not vars[51]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n내가 장웨이 혼자 남겨진다 해도,\n그는 끝까지 싸워야 한다.\n어서! 조준!')
        stage.setAI(12, 5, 15, 7, 2, 1)
        vars[32] = 1
    if not vars[33] and stage.isInRect(1025, 2, 7, 10, 15):
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        stage.unit(304).setAI(0)
        vars[33] = 1
    if not vars[34] and not vars[51] and stage.isInRect(1025, 6, 0, 21, 10) and stage.curCamp() == 2:
        stage.unit(69).setDir(stage.countDir(69, 0))
        stage.say('&69\n계획에 따라 조조의 군대가 투입되었다.\n모든 것은 공명 어른들의 지시에 따랐다.\n이제 지켜봐!')
        stage.unit(69).setAction(5)
        stage.say('&69\n나와라, 나무 인형아!\n조의 군대를 공격해라!')
        stage.unit(69).setAction(0)
        stage.unit(414).show()
        stage.unit(415).show()
        stage.unit(416).show()
        stage.unit(417).show()
        stage.unit(0).setDir(stage.countDir(0, 414))
        stage.say('&0\n음, 그럼 저게 뭐야!?\n정말 이상해 보여요......')
        if not vars[60]:
            stage.unit(19).setDir(stage.countDir(19, 414))
            stage.unit(19).setAction(10)
            stage.say('&19\n뭐라고? 이 사람 공명,\n심지어 나무 인형도 사용되고 있다고요!?')
            stage.unit(19).setDir(stage.countDir(19, 0))
            stage.say('&19\n주군, 이건 불사의 예술의 한 종류야,\n이것은 물질에 생명을 부여할 수 있는 불멸의 예술 같은 것이다.\n공명This 사람은 정말 무서워!"')
        if not vars[50] and stage.totalRectUnit(0, 11, 0, 23, 6) == 0:
            stage.unit(69).setDir(stage.countDir(69, 35))
            stage.say('&69\n공명 선생님, 지시에 따르세요,\n불사의 기술은 이미 발동되어 있었다.')
            stage.unit(35).setDir(stage.countDir(35, 69))
            stage.say('&35\n좋아, 장웨이.\n그 다음 전략에 사용하세요.\n&69\n네!\n&35\n계획이 준비되었으니,\n너무 억지로 싸우지 마세요.\n알겠어?\n&69\n장웨이는 알고 있었다.\n&35\n그러니 이제부터는 전적으로 여러분에게 달려 있습니다.')
            stage.setObjects(False, 16, [
                [
                    41,
                    17,
                    3],
                [
                    42,
                    17,
                    4]])
            stage.setObjects(False, 16, [
                [
                    39,
                    21,
                    3],
                [
                    40,
                    21,
                    4]])
            stage.unit(35).move(23, 4, 1)
            stage.unit(35).hide()
            vars[50] = 1
            stage.unit(0).setDir(1)
            stage.say('&0\n오, 안 돼!\n도망공명 거야?')
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(218).setAI(1)
        if not vars[31]:
            if not vars[56]:
                stage.unit(60).setDir(stage.countDir(60, 0))
                stage.say('&60\n이제 남은 유일한 선택지는 조조를 직접 공격하는 것뿐이었다!')
            if not vars[55]:
                stage.unit(50).setDir(stage.countDir(50, 0))
                stage.say('&50\n이게 바로 나, 마수가 내 재능을 뽐낼 기회야.\n내가 어떻게 그를 상대하는지 지켜봐! 음, 음, 음.')
            if not vars[57]:
                stage.unit(58).setDir(stage.countDir(58, 0))
                stage.say('&58\n조조 어디 있는 거야?!\n저 사람한테 한 판 줘야겠어......')
            stage.setAI(5, 2, 8, 5, 2, 1)
            vars[31] = 1
        vars[34] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 3, 2, 8, 7):
        if not vars[56]:
            stage.unit(60).setDir(stage.countDir(60, 0))
            stage.say('&60\n음, 음, 음...... 나 벌써 끝난 거야!?')
        if not vars[55]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n이게 바로 나, 마수가 내 재능을 뽐낼 기회야.\n내가 어떻게 그를 상대하는지 지켜봐! 음, 음, 음.')
        if not vars[57]:
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.say('&58\n조조 어디 있는 거야?!\n저 사람한테 한 판 줘야겠어......')
        stage.setAI(5, 2, 8, 5, 2, 1)
        vars[31] = 1
    if not vars[40] and stage.isNear(0, 69, True):
        stage.unit(0).setDir(stage.countDir(0, 69))
        stage.unit(69).setDir(stage.countDir(69, 0))
        stage.say('&0\n이제 슈나라는 이미 무너졌고,\n아무리 저항해도 의미가 없어,\n강웨이, 순종적으로 항복하는 게 좋을 거야.\n&69\n공명 주님께서 아직 살아 계시다면,\n야망 있는 사람은 절대 주인을 배신하지 않는다.')
        vars[40] = 1
    if not vars[41] and stage.isNear(9, 58, False):
        stage.unit(9).setDir(stage.countDir(9, 58))
        stage.unit(58).setDir(stage.countDir(58, 9))
        stage.say('&9\n마다이 장군, 왜 빨리 항복하지 않습니까?\n우리는 한때 함께 싸웠다,\n왜 지금 서로를 죽이고 있는 거야?\n&58\n조의 진영에 항복한 데는 당신만의 의도가 있을 거예요,\n그래서 비판하지 않을게.\n&58\n하지만 마텅준 군대의 마지막 멤버로서,\n그는 마지막 순간까지 절대 포기하지 않을 것이다.\n방덕 이 결판을 내보자.\n&9\n이 모든 게 운명의 장난이야!\n방덕 무력했다......')
        fight = stage.startFight(9, 58, 5)
        fight.showUnit(False, '오랫동안 너와 싸우고 싶었어,\n방덕, 주저하지 마!', 9)
        fight.showUnit(True, '너 같은 사람을 마주하며,\n나는 주저하지 않을 거야.\n칼 조심해!', 6)
        fight.showStart()
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.setAction(False, 8)
        fight.say(False, '운전해!', True)
        fight.attack2(False, 1, True)
        fight.attack1(True, 3, True)
        stage.delay(10)
        fight.setAction(True, 10)
        fight.setAction(True, 6)
        fight.say(True, '이걸 받아라!', True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack1(False, 1, True)
        fight.attack1(True, 2, False)
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        stage.delay(15)
        fight.say(False, '음, 더 이상 못 하겠어......\n방덕, 저승에서 기다리고 있어......\n…… 절대 안 돼.', True)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '나도 혼란이 끝난 후에 죽을 생각이야,\n거기서 기다려.', True)
        fight.setAction(True, 1)
        fight.say(True, '안녕히 계세요, 마다이 장군.', True)
        fight.end()
        stage.unit(58).hide(2)
        vars[57] = 1
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n일단 후퇴하자.\n이건 내가 예상했던 바로 그 모습이었다.')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n오, 안 돼!\n다른 방법은 없었다; 후퇴만이 유일한 선택이었다.\n증오하는 조군, 이게 끝이라고 생각하지 마라!')
        stage.unit(69).hide(1)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[61] = 1
        vars[62] = 1
        vars[63] = 1
        vars[64] = 1
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(71, 7, 0, 2):
        stage.unit(71).setAction(9)
        stage.say('&71\n아, 아, 아!\n지금까지 버티는 한계에 다다랐습니다.\n후퇴!')
        stage.unit(71).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n아파, 아파!\n더는 못 참겠어, 지금 물러나!')
        stage.unit(73).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n죽으면 모든 것을 잃게 됩니다.\n이번엔 그냥 순종적으로 물러나자.\n다음엔 그렇게 싸구려 같은 건 없을 거야.')
        stage.unit(72).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n너무 부주의했어, 음... 물러날 수밖에 없어......\n아니, 몸이 움직일 수가 없었어.\n이런 곳에서 죽을 줄은 전혀 몰랐어......')
        stage.unit(50).hide(2)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(60, 7, 0, 2):
        stage.say('&60\n와!\n더 일찍 은둔했어야 했는데......\n기침, 기침...... 거짓말 아니......')
        stage.unit(60).hide(2)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n내 목숨이 달려 있어!\n마텅준 군대의 마지막 병사가 곧 죽을 뻔했다.\n&58\n조조, 평화롭고 번영하는 시대를 만들어 주길 바랍니다,\n그렇지 않으면 내가 마다이가 저승에서 와서 네 목숨을 거둘 거야......')
        stage.unit(58).hide(2)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(56, 7, 0, 2):
        stage.say('&56\n여기서 죽어도 후회는 없어!\n거짓말 아니에요......')
        stage.unit(56).hide(2)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(55, 7, 0, 2):
        stage.say('&55\n후회...... 나도 떠날 거야.\n거짓말 아니에요......')
        stage.unit(55).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(19, 7, 0, 2):
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(414, 7, 0, 2):
        vars[3] = 1
        vars[61] = 1
        stage.unit(414).hide(1)
    if not vars[62] and stage.unitStateTest(415, 7, 0, 2):
        vars[3] = 1
        vars[62] = 1
        stage.unit(415).hide(1)
    if not vars[63] and stage.unitStateTest(416, 7, 0, 2):
        vars[3] = 1
        vars[63] = 1
        stage.unit(416).hide(1)
    if not vars[64] and stage.unitStateTest(417, 7, 0, 2):
        vars[3] = 1
        vars[64] = 1
        stage.unit(417).hide(1)
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 백디 시티를 점령했어.\n슈의 잔재들은 더 이상 저항할 능력이 없게 될 것이다,\n아군 이겼어!')
        stage.reward(0, [
            145,
            -1])
        stage.end()
        vars[0] = 1
        vars[642] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 공명군 앞에서 큰 패배를 겪었지만 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
