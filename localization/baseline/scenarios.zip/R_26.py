# Source Generated with Decompyle++
# File: R_26.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(1, 0)
    stage.draw()
    stage.setEventName('조조 남쪽으로 향했다')
    stage.delay(5)
    stage.showHead(1, 296, 127)
    stage.showHead(32, 232, 171)
    stage.delay(5)
    stage.bottomTxt('조조군은 공명의 계략에 결정적으로 패배했다.', False, False, False)
    stage.delay(8)
    stage.head(1).move(330, 99)
    stage.delay(5)
    stage.bottomTxt('하후돈 어쩔 수 없이 남은 병사들을 모아 쉬두로 돌아갈 수밖에 없었다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    model.setFace(4)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            15,
            52,
            70],
        [
            2,
            58,
            70],
        [
            13,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            1,
            52,
            55,
            3,
            12],
        [
            14,
            58,
            52,
            3,
            11],
        [
            11,
            58,
            58,
            3,
            11]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n원양, 왜 그렇게 초라한 상태야?\n&1\n그때는 자랑했지만, 지금은 참담한 패배로 돌아왔다,\n그리고 더 이상 총리를 볼 얼굴이 없었다,\n원하는 대로 처리해 주세요.\n&0\n어떻게 그들을 물리쳤나요,\n화재 공격을 받았다고 들었공명?')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n좁은 길에서는 화염 공격을 막아야 하며; 군사 전략에 능숙하다,\n전투에 단련된 너, 이것조차 잊었나?\n&1\n할 말이 없고, 오직 죽음에 대한 희망뿐이야.')
    stage.unit(0).setAction(0, 1)
    stage.effectSound(201, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('전쟁에서는 승패가 흔하다; 이번에는 용서하겠다.\n패배한 장군은 죽어 마땅하다; 그는 용서해서는 안 된다.', 0)
    if sel == 1:
        vars[310] = 1
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('&0\n원양, 돌아가서 쉬어."\n원제와 만청도 열심히 일했어요,\n내려가서 쉬어.\n&1\n맹덕... 이렇게 봐줄 거야?\n&0\n전쟁에서는 승패가 흔한 법이죠,\n다음에 싸울 때는 실수를 만회해야 해.\n&1\n나를 살려두면 군 기법을 어떻게 지킬 수 있겠느냐?\n빨리 내려줘야 해!!')
        stage.say('&0\n당신의 말과 행동은 군 규율을 지켰습니다,\n그렇지 않니, 문약?')
        stage.unit(20).setAction(6)
        stage.say('&20\n네, 주군 말씀하신 대로입니다.')
        stage.unit(20).setAction(0)
        stage.say('&1\n………\n&0\n군 기율을 지켰습니다.\n장군으로서 이제부터 전장에서 굴욕을 복수해야 한다.\n&1\n하지만.........')
        stage.unit(0).setAction(0, 3)
        stage.say('&0\n원양, 헛되이 죽게 두지 않을 거야.\n&1\n…… 네.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n좋아! 너희 셋은 내려가서 쉬어.\n&1\n네.\n&14\n네.\n&11\n네.')
    elif sel == 2:
        vars[310] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('&0\n원양, 네 말이 맞아.\n이 참담한 패배는 정말로 용서받을 수 없습니다.\n&1\n......')
        stage.unit(0).setAction(17)
        stage.say('&0\n좋아! 군법에 따라 처리해.\n하후돈 목을 베어버려!!')
        stage.unit(15).setAction(3)
        stage.say('&15\n！！')
        stage.unit(2).setAction(6)
        stage.say('&2\n뭐야!!')
        stage.unit(20).setAction(6)
        stage.say('&20\n주군 기다려.')
        stage.unit(15).setAction(0)
        stage.unit(2).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0)
        stage.say('&0\n무슨 일이야, 문약?\n&20\n주군, 샤후우 장군은 정말로 중대한 죄를 저질렀습니다,\n장군의 사형죄를 용서해 주시길 간청합니다.')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n안 돼! 이렇게 하면 군율을 어떻게 엄격하게 지킬 수 있겠어?\n&20\n장군님의 죽음을 각오한 결심은 이미 군율을 세웠지만,\n부디 주군께서 사형에 처하는 것을 면해주십시오.')
        stage.unit(2).setAction(6)
        stage.say('&2\n나도 너를 위해 간청한다,\n샤호우 장군 같은 위대한 장군 없이는 어떻게 아군 수 있겠는가!')
        stage.unit(13).setAction(6)
        stage.say('&13\n그냥 주군 여분 샤호우 장군을 요청하세요.')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n좋아.\n이렇게 그를 위해 애원하니,\n이번엔 봐주자.')
        stage.unit(0).setAction(17)
        stage.say('&0\n하지만 원양,\n다음에 싸울 때는 오늘의 굴욕을 씻어내야 해!\n&1\n…… 네!')
        stage.unit(0).setAction(0)
        stage.say('&0\n그럼 내려가서 쉬어도 돼.\n원저, 만청, 너희 둘도 내려가.\n&1\n네.\n&14\n네.\n&11\n네.')
    stage.unit(14).setAction(0)
    stage.unit(11).setAction(0)
    stage.unitsMove([
        [
            stage.unit(11),
            98,
            58,
            1],
        [
            stage.unit(14),
            98,
            52,
            1],
        [
            stage.unit(1),
            92,
            55,
            1]])
    stage.unit(14).hide()
    stage.unit(11).hide()
    stage.unit(1).move(98, 55, 1)
    stage.unit(1).hide()
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n응......\n누가 공명가 그런 능력을 가질 수 있을 거라 생각했겠는가......')
    stage.unit(21).setAction(6)
    stage.say('&21\n공명의 교활함은 정말 대단하다.')
    stage.unit(21).setAction(0)
    stage.say('&0\n하지만 그는 유비가 계속 오만하게 행동하도록 내버려 둘 수 없었다.\n&0\n즉시 제거하고 싶어......')
    stage.unit(0).setAction(3)
    stage.say('좋습니다. 이 기회를 빌어 남방을 평정합시다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n전 군대에 남쪽을 진압할 준비를 명령하라!')
    stage.unit(0).setAction(17)
    stage.say('&0\n나는 류뱌오를 제거하고 징저우에 유비 할 것이다,\n그리고 동우의 손권!!')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 335, 84)
    stage.delay(5)
    stage.showHead(32, 252, 155)
    stage.delay(5)
    stage.bottomTxt('신예의 유비,', False, False, False)
    stage.delay(5)
    stage.showHead(150, 316, 195)
    stage.delay(5)
    stage.bottomTxt('징저우의 류뱌오,', True, False, False)
    stage.delay(5)
    stage.showHead(76, 575, 216)
    stage.delay(5)
    stage.bottomTxt('동부 오의 손권은 양쯔강 남쪽에서 더 안정적이었다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('남부를 평정하는 첫걸음조조,', True, True, False)
    stage.delay(5)
    stage.head(0).move(316, 84)
    stage.delay(5)
    stage.bottomTxt('신예를 공격할 유비였다.', True, False, True)
    stage.bottomTxt('갑작스러운 공격으로 신예는 버려졌조조 troops유비.', False, False, False)
    stage.delay(5)
    stage.head(32).hide()
    stage.delay(5)
    stage.bottomTxt('조조 군대는 거의 공격받지 못했고,', True, True, False)
    stage.delay(5)
    stage.head(0).move(316, 115)
    stage.delay(5)
    stage.bottomTxt('남쪽으로 향해 그들은 류뱌오가 거주하던 향양 교외에 도착했다.', True, False, True)
    stage.bgSound(15)
    stage.loadBg(2, 53)
    model.setFace(128)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            7,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            23,
            64,
            58,
            3],
        [
            24,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('향양 근처, 조의 주요 진영')
    stage.say('&0\n이렇게 쉽게 여기 오다니,\n류비아오는 무슨 생각을 하고 있었던 걸까......')
    stage.unit(24).setAction(0, 2)
    stage.say('&24\n이상하게도, 만약 그것이 아군를 더 깊이 끌어들이려는 것이라면,\n저항은 전혀 없었다.\n&0\n흠.')
    stage.showUnit(181, 54, 22, 2)
    stage.say('&181\n보고해.')
    stage.unit(24).setAction(0, 3)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군 향양의 사절단이 항복을 요청했다.\n&0\n뭐라고!?\n항복을 요청하는 사절이라고!?\n…… 좋아, 데려와.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.unit(23).setAction(0, 2)
    stage.say('&23\n화살 한 발도 쏘기 전에 항복하라고? ......?\n정말 류비아오가 무슨 생각을 했는지 이해가 안 돼.')
    stage.showUnit(27, 54, 22, 2)
    stage.say('&27\n안녕하세요.')
    stage.unit(23).setAction(0, 3)
    stage.unit(27).move(54, 64, 2)
    stage.delay(3)
    stage.unit(27).setAction(11)
    stage.say('&27\n그리고 처음으로 총리에게 경의를 표했다.\n마지막 장군 원핀은 중예라고 불렀다.\n&0\n음, 난 조조.\n항복을 요청하는 사절이시죠!\n&27\n네.\n&0\n왜 류뱌오는 전투 진형을 갖지 않았는가,\n그래서 나한테 항복하기로 한 거야?\n&27\n......주군께께 돌아가셨어요.\n&27\n이후 후대 유총이 경주를 전쟁의 고통에서 구해주었다.\n토지를 재무장관에게 제공하기로 결정되었습니다.\n&27\n총장님께 연민과 연민을 보여주시길 간청합니다,\n꼭 저희 요청에 동의해 주세요.\n&0\n좋아! 동의해.\n&27\n그는 총리에게 감사를 표했다.')
    stage.say('&0\n원핀, 너한테 물어볼 게 있어,\n신예의 유비은 지금 어디에 있지?\n&27\n......유비 항복을 지지하지 않았다,\n지금 그는 동우로 도망치고 있다.\n&0\n정말?\n좋아! 류총이 징저우를 계속 지키게 하라.\n&0\n아군 계속 유비을 쫓았다.\n&0\n하후돈, 장합!\n너희 둘을 선봉대로 임명한다,\n그들은 신속히 유비를 추격했다.')
    if vars[310]:
        stage.unit(1).setAction(6)
        stage.say('&1\n네.')
        stage.unit(7).setAction(6)
        stage.say('&7\n네.')
        stage.unit(1).setAction(0)
        stage.unit(7).setAction(0)
    if not vars[310]:
        stage.say('&0\n원양, 우리는 과거의 수치심을 씻어내야 합니다!')
        stage.unit(1).setAction(3)
        stage.say('&1\n네!')
        stage.unit(1).setAction(0)
    stage.delay(5)
    stage.showUnit(28, 55, 22, 2)
    stage.unit(28).move(55, 26, 2)
    stage.showUnit(26, 55, 22, 2)
    stage.unitsMove([
        [
            stage.unit(28),
            50,
            56,
            2],
        [
            stage.unit(26),
            58,
            56,
            2]])
    stage.unit(26).setAction(0)
    stage.unit(28).setAction(0)
    stage.say('&26\n주군!')
    stage.unit(0).setAction(3)
    stage.say('&0\n아, 샤후우엔이랑 샤후제이구나?')
    stage.unit(0).setAction(0)
    stage.say('&28\n주군, 우리 모두 이 싸움에 합류하자!\n&26\n우리 둘은 아직 전장에 나가본 적이 없어,\n기회를 주주군 주세요.\n&0\n음, 잘 말씀하셨네요.\n좋아, 주력 지원만 맡아,\n너희 둘은 공덕을 얻기 위해 열심히 일해야 해.\n&28\n네.\n&26\n고마워요, 주군.\n그럼 출발 준비를 합시다.')
    stage.unit(26).move(55, 56, 3)
    stage.unitsMove([
        [
            stage.unit(26),
            55,
            52,
            0],
        [
            stage.unit(28),
            55,
            56,
            2]])
    stage.unitsMove([
        [
            stage.unit(26),
            55,
            22,
            0],
        [
            stage.unit(28),
            55,
            26,
            0]])
    stage.unit(26).hide()
    stage.unit(28).move(55, 22, 0)
    stage.unit(28).hide()
    stage.say('&0\n원평 장군은 아군 징저우 지리에 익숙하지 않다,\n선봉이 되어 주세요.\n&27\n이제 이 겸손한 장군이 이미 항복했으니,\n너는 내 주군야,\n나는 당연히 최고의 충성심으로 봉사할 것이다.\n&27\n즉시 준비하고 여기서 물러나겠습니다.\n&0\n흠! 전장에서 보자.')
    stage.unit(27).setAction(0)
    stage.delay(3)
    stage.unit(27).move(54, 22, 0)
    stage.unit(27).hide()
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('좋습니다, 출전합니다!')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        1,
        7], [
        22])
    gvars[4076] = 0
    gvars[4057] = 26
    stage.setBattlePos([
        [
            2,
            2],
        [
            0,
            1],
        [
            1,
            0],
        [
            2,
            3],
        [
            3,
            2],
        [
            1,
            3],
        [
            3,
            1],
        [
            1,
            1],
        [
            0,
            2],
        [
            2,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n공명!\n이번에는 반드시 복수해야 해.')
    if stage.unitClickTest(7):
        stage.say('&0\n장 장군님도 싸움에 참여하세요.\n&7\n네.')
    if stage.unitClickTest(15):
        stage.say('&15\n전에 류비오의 군대가 꽤 강력하다는 이야기를 들은 적이 있다,\n정말 그들과 싸우고 싶어요.\n&0\n그게 바로 내가 계획한 거야.')
    if stage.unitClickTest(23):
        stage.say('&0\n원허, 류총의 상황에 대해 알고 있니?\n&23\n어쨌든 아직 아이일 뿐이었다.\n별로 뛰어나지 않은 것 같아요.\n&0\n흥, 그러니까 아직 우유 냄새가 나고 젖지 않은 아이일 뿐이네.\n&23\n네.')
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장은 어디였지?\n&20\n나가사카 슬로프 근처에 있고 싶어요.\n&0\n창반 경사면...... 거기에 강이 있을 거야.\n&20\n네, 중앙 지역에서는,\n강이 크지 않아.')
    if stage.unitClickTest(24):
        stage.say('&24\n주군, 보고를 받은 직후,\n유비 아기와 함께 있었다.\n&0\n아기야?\n유비 아이?\n&24\n네.\n아기 남자아이였는데, 이름은 아 두였다.\n&0\n아두?\n참 이상한 이름이네.\n&24\n그의 어머니가 북두칠성을 삼키는 꿈을 꾸었다고 전해진다,\n그리고 그때서야 그녀는 이 아이를 임신하게 되었고,\n그래서 이름이 붙여졌습니다.\n&0\n오?\n북두칠성의 삼켜버렸.......')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
