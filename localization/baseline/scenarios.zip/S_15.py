# Source Generated with Decompyle++
# File: S_15.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(16,0)',
        '(29,18)'])
    stage.nearEvent([
        2,
        3])
    stage.nearEvent([
        0,
        3,
        17,
        3,
        23,
        3,
        22,
        3,
        20,
        3], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 3, 0, 0, 1)
    stage.createEnemy([
        {
            'id': 3,
            'x': 29,
            'y': 18,
            'dir': 0,
            'lv': 6,
            'i': 0 },
        {
            'id': 258,
            'x': 25,
            'y': 18,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 1 },
        {
            'id': 259,
            'x': 25,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 2 },
        {
            'id': 260,
            'x': 25,
            'y': 19,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 3 },
        {
            'id': 261,
            'x': 30,
            'y': 15,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 262,
            'x': 29,
            'y': 15,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 263,
            'x': 28,
            'y': 15,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 282,
            'x': 26,
            'y': 18,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 7 },
        {
            'id': 283,
            'x': 29,
            'y': 16,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 8 },
        {
            'id': 210,
            'x': 27,
            'y': 18,
            'dir': 3,
            'lv': 0,
            'i': 9 },
        {
            'id': 211,
            'x': 29,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'i': 10 },
        {
            'id': 212,
            'x': 29,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 11 },
        {
            'id': 298,
            'x': 30,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 12 },
        {
            'id': 41,
            'x': 16,
            'y': 2,
            'lv': 4,
            'ai': 0,
            'i': 13 },
        {
            'id': 213,
            'x': 18,
            'y': 2,
            'lv': 0,
            'ai': 0,
            'i': 14 },
        {
            'id': 214,
            'x': 17,
            'y': 3,
            'lv': 0,
            'ai': 0,
            'i': 15 },
        {
            'id': 215,
            'x': 15,
            'y': 3,
            'lv': 0,
            'ai': 0,
            'i': 16 },
        {
            'id': 216,
            'x': 14,
            'y': 2,
            'lv': 0,
            'ai': 0,
            'i': 17 },
        {
            'id': 43,
            'x': 16,
            'y': 0,
            'lv': 4,
            'i': 18 },
        {
            'id': 217,
            'x': 16,
            'y': 1,
            'lv': 0,
            'i': 19 },
        {
            'id': 234,
            'x': 15,
            'y': 0,
            'lv': 0,
            'i': 20 },
        {
            'id': 235,
            'x': 16,
            'y': 0,
            'lv': 0,
            'i': 21 },
        {
            'id': 32,
            'hide': 1,
            'x': 7,
            'y': 18,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 22 },
        {
            'id': 33,
            'hide': 1,
            'x': 6,
            'y': 17,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 23 },
        {
            'id': 40,
            'hide': 1,
            'x': 8,
            'y': 19,
            'dir': 0,
            'lv': 4,
            'ai': 1,
            'i': 24 },
        {
            'id': 264,
            'hide': 1,
            'x': 5,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 25 },
        {
            'id': 265,
            'hide': 1,
            'x': 8,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 26 },
        {
            'id': 284,
            'hide': 1,
            'x': 6,
            'y': 18,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 27 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 1,
            'y': 2 },
        {
            'idx': 1,
            'x': 3,
            'y': 4 },
        {
            'idx': 2,
            'x': 2,
            'y': 3 },
        {
            'idx': 3,
            'x': 2,
            'y': 1 },
        {
            'idx': 4,
            'y': 3 },
        {
            'idx': 5,
            'y': 1 },
        {
            'idx': 6,
            'x': 4,
            'y': 3 },
        {
            'idx': 7,
            'x': 2,
            'y': 5 },
        {
            'idx': 8,
            'x': 3,
            'y': 2 },
        {
            'idx': 9,
            'x': 1,
            'y': 4 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(41, -1, 0, -1, 0, 23)
    stage.loadBg(15)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(5)
    stage.unit(43).setDir(stage.countDir(43, 0))
    stage.say('&43\n조조 공격하려 하고 있다,\n주군에 대한 소식 있나요?')
    stage.unit(41).setDir(stage.countDir(41, 0))
    stage.say('&41\n흠, 주군 매복을 준비하러 간 것 같네,\n샤피를 공격하는 조조을 준비하고 있었다.\n&43\n조조 앞에서 모든 일이 순조롭게 진행되길 바랍니다......\n&41\n주군 직접 샤피를 매복한 것 같아.\n&43\n너무 위험해......\n만약 그들이 노출된다면, 주군의 생명이 위험해질 것이다.\n이건 정말 말도 안 되는 소리입니다!')
    stage.unit(3).setDir(stage.countDir(3, 0))
    stage.say('&3\n(왠지 불길한 예감이 들어...\n방금 전, 내가 형의 물건을 지켰어야 했...... )\n&3\n(셋째 형에 따라 다르네......\n내 동생을 지켜줘! )')
    stage.unit(0).setDir(stage.countDir(0, 3))
    stage.say('&0\n샤피로 가는 길은 두 개가 있습니다.\n쉬저우를 공격하는 길로 가는 게 좋을까?\n아니면 바로 샤피로 갈까?')
    stage.unit(0).setDir(stage.countDir(0, 22))
    stage.say('곽가, 무슨 좋은 생각이 있나!')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n만약 당신이 바로 샤피로 간다면,\n좁은 숲길을 건너야 해,\n적의 매복에 빠졌을 가능성이 매우 높았다.')
    stage.unit(20).setDir(stage.countDir(20, 0))
    stage.say('&20\n그리고 신속히 서저우로 행군하라,\n설주를 한 번에 점령했다고 해서 뭐가 어때?')
    stage.unit(23).setDir(stage.countDir(23, 0))
    stage.say('&23\n그렇다면\n쉬저우 시를 공격할 때,\n또한 뒤에서 공격받을 위험도 있습니다.\n&22\n매복 부대를 유인하는 게 더 나을 거야,\n먼저, 매복을 제거하세요.\n&0\n매복이 어디에 있을 것 같아?\n&22\n아마도 숲길 양쪽에 있었을 것이다,\n그 외에도 남쪽에 산이 있습니다.')
    stage.unit(0).setDir(2)
    stage.unit(22).setDir(2)
    stage.unit(20).setDir(2)
    stage.unit(23).setDir(2)
    stage.unit(17).setDir(stage.countDir(17, 0))
    stage.say('&17\n바로 샤피로 가는 게 어때?')
    stage.unit(2).setDir(stage.countDir(2, 17))
    stage.say('&2\n초선, 이게 우리의 첫 전투야,\n모두의 리드를 따라가면 됩니다.\n그러니 그 부분은 걱정하지 않으셔도 됩니다.\n&2\n억지로 하지 않길 바랄 뿐이에요.')
    stage.unit(17).setDir(stage.countDir(17, 2))
    stage.say('&17\n장 장군님, 잘 챙겨주셔서 감사합니다.\n우리가 더 이상 주인-하인 관계가 아니니,\n너무 격식 차리지 마세요.\n&2\n어떻게 그럴 수 있지?\n나도 루 장군을 위해 너를 보호하는 거야.')
    stage.unit(2).setDir(2)
    stage.unit(17).setDir(2)
    stage.setWinCondition('승리 조건\n1. 샤피 점령.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('샤피 시를 점령하라!')
    stage.heightLight(29, 18, 29, 18)
    stage.startOper()
    vars[515] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[51] and vars[52] and vars[53] and vars[54] and not vars[11] and stage.round() >= 1:
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.say('&0\n차를 몰고 떠날 수 있유비장비......\n이 유명한 장군들이,\n이 전투의 승리는 이미 그의 손에 다가왔다.\n&0\n이제 피청에 있는 관우만 남아 있다,\n하지만 그는 전국적으로 명성을 얻은 영웅이었다,\n오랫동안 그를 내 지휘관으로 영입하고 싶었어,\n&0\n그를 죽이는 건 정말 안타까운 일이야.')
        sel = stage.choice('설득관우\n생포관우', -1)
        if sel == 1:
            stage.say('&0\n샤피는 다시 공격받을 수 있습니다.\n누가 가서 관우를 설득해 항복하게 하겠는가!')
            stage.unit(2).setDir(stage.countDir(2, 0))
            stage.unit(17).setDir(stage.countDir(17, 0))
            stage.unit(22).setDir(stage.countDir(22, 0))
            stage.unit(23).setDir(stage.countDir(23, 0))
            stage.unit(20).setDir(stage.countDir(20, 0))
            stage.say('&2\n저는 이 책임을 기꺼이 맡겠습니다,\n관우 분명히 항복하도록 설득될 거야.\n&17\n불필요한 희생을 피할 수 있다면,\n저도 갈 의향이 있습니다......\n&22\n제발 보내줘!\n오랫동안 저와 좋은 대화를 나누고 싶었관우.\n&23\n자신의 강점을 지혜로 사용할 수 있었고,\n뛰어난 무술 실력으로 관우을 설득하며,\n정말 즐거운 경험이에요! 저도 가후 시도해보고 싶어요.\n&20\n하하하, 관우 아군 합류한다면,\n아군 전투력은 확실히 크게 강화될 것입니다,\n무슨 일이 있어도 그를 설득해 항복하게 해야 해.\n&0\n첫째, 관우를 샤피에서 유인해 나와야 한다......\n&0\n포로들을 샤피로 돌려보내라,\n그들이 유비와 장비에게 자신의 상황을 알리게 하세요.\n예를 들어 그들의 패배를 생각해보면, 이제 그들의 운명은 알 수 없다......\n&0\n관우 이 말을 들었어,\n그는 분명 유비를 구하고 싶어 하는 것 같다.\n이 점에만 집중하세요.')
            stage.unit(2).setDir(stage.countDir(2, 3))
            stage.unit(17).setDir(stage.countDir(17, 3))
            stage.unit(22).setDir(stage.countDir(22, 3))
            stage.unit(23).setDir(stage.countDir(23, 3))
            stage.unit(20).setDir(stage.countDir(20, 3))
            vars[2] = 1
        elif sel == 2:
            stage.say('&0\n샤피는 다시 공격받을 수 있습니다.\n누가 나를 잡으러 가겠관우!')
            stage.unit(2).setDir(stage.countDir(2, 0))
            stage.unit(17).setDir(stage.countDir(17, 0))
            stage.say('&2\n제발 날 놔줘!\n그는 현명하고 용감한 장군이라고 전해진다,\n&2\n장군으로서 정말 그와 싸우고 싶어!\nPlease주군 꼭 보내줘!"\n&17\n부디 보내주세요,\n장 장군과 관장군 모두 충성을 중시했다,\n그리고 사람들의 존경을 받았다.\n&17\n둘이 싸우는 건 보고 싶지 않아.\n&17\n그래서 저는 이 역할을 맡고자 합니다.\n&0\n응.........\n첫째, 관우를 샤피에서 유인해야 한다......\n&0\n포로들을 샤피로 돌려보내라,\n그들이 유비와 장비에게 상황을 알리게 하세요.\n예를 들어 그들의 패배를 생각해보면, 이제 그들의 운명은 알 수 없다......\n&0\n관우 이 말을 들었어요,\n그는 분명 유비를 구하고 싶어 하는 것 같다.\n이 점에만 집중하세요.')
            stage.unit(2).setDir(stage.countDir(2, 3))
            stage.unit(17).setDir(stage.countDir(17, 3))
            vars[3] = 1
        stage.talk(210, 210, '관 장군님, 뭔가 이상해요!\n주군와 장군은 전투에서 패배했다.\n현재 두 사람 모두 운명은 알려지지 않았습니다!')
        stage.unit(3).setAction(10)
        stage.say('&3\n뭐라고! 형과 셋째 형이라고!?\n어떻게 이 분야에 들어오게 되었나요?\n이봐, 네가 말하길 생명과 죽음은 불확실하다고 했지?')
        stage.talk(210, 210, '탈출한 병사들에 따르면,\n유비군이 참패했기 때문에, 정확히 누가 죽었을까요?\n아무도 확신하지 못한다......')
        stage.unit(3).setDir(3)
        stage.say('&3\n…………\n좋아, 나는 도시를 떠나 내 동생을 찾을게.\n이 도시를 죽을 때까지 지켜야 해!')
        stage.unit(3).setAI(4, -1, 14, 15)
        stage.unit(258).setAI(4, -1, 13, 13)
        stage.unit(259).setAI(4, -1, 13, 13)
        stage.unit(260).setAI(4, -1, 13, 13)
        stage.unit(282).setAI(4, -1, 13, 13)
        stage.unit(261).setAI(4, -1, 15, 13)
        stage.unit(262).setAI(4, -1, 15, 13)
        stage.unit(263).setAI(4, -1, 15, 13)
        stage.unit(283).setAI(4, -1, 15, 13)
        stage.setWinCondition('승리 조건\n1. 관우 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
        if vars[2]:
            stage.showWinCondition('항복을 설득하는 관우!')
        if vars[3]:
            stage.showWinCondition('생포관우!')
        stage.unit(3).heightLight()
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 16, 0):
        stage.getItem(151, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 29, 18):
        stage.getItem(151, 0, True, 1025)
        if vars[11]:
            stage.talk(2, 197, '주군 순찰대는 유비 부부와 자녀를 보호했다.\n어떤 지침이 있주군지 궁금하네요.')
            stage.say('&0\n흠, 잘 부탁해.\n그들이 다치게 둘 수 없어!')
        vars[21] = 1
    if not vars[30] and not vars[31] and not vars[32] and not vars[36] and stage.isInRect(1025, 4, 16, 9, 19):
        stage.unit(32).show()
        stage.unit(33).show()
        stage.unit(40).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(33).setAction(10)
        stage.say('&33\n아, 발각됐네!')
        stage.unit(40).setDir(stage.countDir(40, 33))
        stage.say('&40\n장 장군, 침묵할 수 없다면,\n매복 전술이 실패했다!\n잠깐이라도 진정할 수 없니?\n&33\n네가 한 말 다 알아,\n하지만 조용히 있는 건 정말 답답해요!\n선택의 여지가 없으니 도전을 받아들여!')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n흥, 네 매복 전술이라니,\n난 오래전에 간파했어!\n죽을 준비를 해라!')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.unit(32).setAction(2)
        stage.say('&32\n이제는 도망치는 것조차 불가능해졌다.........\n셋째 형, 손첸, 온 힘을 다해 죽을 때까지 싸워라!')
        vars[30] = 1
    if not vars[30] and not vars[31] and not vars[32] and not vars[36] and stage.isInRect(1025, 13, 10, 20, 19) and stage.curCamp() == 2:
        stage.unit(32).show()
        stage.unit(33).show()
        stage.unit(40).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(33).setDir(stage.countDir(33, 0))
        stage.say('&33\n하하하하.\n속았구나, 조조!\n우리의 기습 공격에 깜짝 놀랐겠지?')
        stage.unit(0).setDir(stage.countDir(0, 33))
        stage.say('&0\n그래서 장비였다!\n거기서 뭐 하는 거야?\n&33\n정말 침착하게 있네?\n현재 상황을 알고 계신가요?\n&0\n흥, 네가 매복을 준비하는 줄 알았어,\n내 목숨을 줘.')
        stage.unit(40).setDir(stage.countDir(40, 0))
        stage.say('&40\n그가 노출된 것 같아.\n이건 좋지 않았다......')
        stage.unit(33).setAction(5)
        stage.say('&33\n흥, 진정하려고 애쓰는 것 같아,\n돌진해!')
        stage.unit(33).setAction(0)
        stage.unit(32).setDir(stage.countDir(32, 33))
        stage.say('&32\n진정해, 셋째 형!\n적이 매복을 간파한 것 같아!\n우리는 살아서 돌아와야 해.')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.unit(33).setDir(stage.countDir(33, 0))
        stage.unit(32).setAction(5)
        stage.say('&32\n돌격!')
        stage.unit(32).setAction(0)
        vars[31] = 1
    if not vars[30] and not vars[31] and not vars[32] and not vars[36] and stage.isInRect(1025, 21, 0, 31, 19):
        stage.unit(32).show()
        stage.unit(33).show()
        stage.unit(40).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(32).setDir(stage.countDir(32, 33))
        stage.unit(33).setDir(stage.countDir(33, 32))
        stage.unit(40).setDir(stage.countDir(40, 32))
        stage.say('&32\n좀 이상하네요.........\n조조의 군대는 어디로 갔나요?\n왜 그의 흔적이 전혀 없는 거지?')
        stage.unit(33).setAction(7)
        stage.say('&33\n하하하. 그들은 우리를 두려워하는 모양이야,\n싸우지 말고 도망쳐라!')
        stage.unit(33).setAction(0)
        stage.say('&32\n그들이 여기까지 온 것 같지 않아요,\n그들은 조용히 철수할 것이다.')
        stage.unit(40).setDir(0)
        stage.unit(40).setAction(10)
        stage.say('&40\n주님, 저기 보세요주군 주세요!\n북쪽에서 검은 연기가 피어오르고 있다......\n그것이 쉬저우의 방향이었다!')
        stage.unit(32).setDir(0)
        stage.unit(33).setDir(0)
        stage.unit(32).setAction(10)
        stage.say('&32\n아-아, 안 돼!\n알고 보니 조의 군대는 먼저 서저우를 점령할 계획이었다.\n그럼 돌아가서 샤피를 공격해!')
        stage.unit(33).setAction(10)
        stage.say('&33\n뭐라고!?\n&40\n주군, 어떻게 해야 하지?\n&32\n먼저 급히 돌아가서 구출하자.')
        vars[32] = 1
    if not vars[33] and stage.isInRect(3, 13, 14, 14, 16):
        stage.say('&3\n형......!\n셋째 형......!\n어디 ......?')
        stage.unit(3).setDir(0)
        stage.unit(3).setDir(1)
        stage.unit(3).setDir(2)
        stage.unit(3).setDir(3)
        stage.unit(3).setAI(4, -1, 9, 16)
        stage.unit(258).setAI(4, -1, 8, 13)
        stage.unit(259).setAI(4, -1, 8, 13)
        stage.unit(260).setAI(4, -1, 8, 13)
        stage.unit(282).setAI(4, -1, 8, 13)
        stage.unit(261).setAI(4, -1, 11, 15)
        stage.unit(262).setAI(4, -1, 11, 15)
        stage.unit(263).setAI(4, -1, 11, 15)
        stage.unit(283).setAI(4, -1, 11, 15)
        vars[33] = 1
    if not vars[34] and stage.isInRect(3, 8, 15, 10, 17):
        stage.say('&3\n형, 빨리 대답해 주세요!\n삼형님! 어디 있니?')
        stage.unit(3).setDir(0)
        stage.unit(3).setDir(1)
        stage.unit(3).setDir(2)
        stage.unit(3).setDir(3)
        stage.unit(3).setAI(4, -1, 5, 11)
        stage.unit(258).setAI(4, -1, 5, 9)
        stage.unit(259).setAI(4, -1, 5, 9)
        stage.unit(260).setAI(4, -1, 5, 9)
        stage.unit(282).setAI(4, -1, 5, 9)
        stage.unit(261).setAI(4, -1, 7, 12)
        stage.unit(262).setAI(4, -1, 7, 12)
        stage.unit(263).setAI(4, -1, 7, 12)
        stage.unit(283).setAI(4, -1, 7, 12)
        vars[34] = 1
    if not vars[35] and stage.isInRect(3, 4, 10, 6, 12):
        stage.unit(3).setDir(0)
        stage.unit(3).setDir(1)
        stage.unit(3).setDir(2)
        stage.unit(3).setDir(3)
        stage.unit(3).setAction(4)
        stage.say('&3\n…………\n아니, 어디서도 못 찾겠어.\n증오스러운 조나라 군대......')
        stage.unit(3).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(283).setAI(1)
        vars[35] = 1
    if vars[2] and not vars[40] and stage.isNear(0, 3, True):
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(3).setDir(stage.countDir(3, 0))
        stage.say('&0\n너 같은 위대한 장군을 죽이다니,\n정말 안타깝네요.........\n그들이 내 편에 올 때 얼마나 효과적일까?\n&3\n당신의 친절한 마음을 받는 것은 드문 일입니다,\n하지만 아직 지지 않았어,\n그는 죽을 생각이 없었다.\n&0\n그러나 의형제들은 유비하고 장비,\n하지만 그의 행방은 알려지지 않았고, 행방도 알려지지 않았다......\n&3\n내 형제들은 아직 살아 있을 거야,\n그때 우리는 함께 살고 함께 죽기로 맹세했어.\n좋아, 더 이상 할 말 없어!\n&0\n응......')
        vars[40] = 1
    if vars[2] and not vars[41] and stage.isNear(2, 3, False):
        stage.unit(2).setDir(stage.countDir(2, 3))
        stage.unit(3).setDir(stage.countDir(3, 2))
        stage.say('&2\n관 장군, 항복할 생각이 아니십니까?\n&3\n내 형은 아직 살아 있어,\n더 이상 할 말 없어.\n&2\n하지만 유비 영주에서 주요 장교들까지,\n모두 흔적도 없이 사라졌어,\n앞으로 무엇을 계획하고 있나요?\n&3\n주군 아직 살아 있을 거야......\n확실히 ......')
        if vars[21]:
            stage.say('&2\n그렇다면 유비의 아내와 아이들은 어떻게 되는 걸까요?\n&3\n그게 무슨 뜻이야!?\n&2\n걱정 마세요!\n우리는 이미 현덕 공의 아내와 아이들을 제대로 보호했습니다.\n&3\n설마 샤피가 무너진 걸까......?\n저는 부주의관우 있어요......\n&2\n아내와 자녀를 소홀히 유비면,\n충성과 정의의 길에 반하는 것이다.\n&2\n유비 찾기 전에,\n먼저 조조주군 서빙하는 게 어때?\n&2\n저는 유비 성인, 기혼 여성, 아이들의 안전을 보장하겠습니다,\n이 문제는 가족과 상의할 주군.\n&3\n… 수고해 주셔서 감사합니다, 장료 장군님,\n모든 걸 중재해 주세요.\n&3\n이제는 이게 필요 없어,\n그를 조 경에게 넘겨 주세요.')
            stage.getItem(160, 0, True, 2)
            stage.unit(3).hide()
            stage.setRectUnitHide(0, 0, 31, 31, 2)
        if not vars[21]:
            stage.say('&2\n정말......?\n그럼 어쩔 수 없이 무력으로 쓸 수밖에 없네!\n관 장군, 이 문제를 저와 해결해 주세요!\n&3\n그게 바로 내가 생각한 거야. 어서!')
            fight = stage.startFight(2, 3, 5)
            fight.showUnit(True, '관 장군님!\n당신은 장군 여포의 무술에 감탄하게 만들었어요,\n오늘은 내가 직접 경험해보려 해!', 9)
            fight.showUnit(False, '그렇게 예의 바르게 굴 필요 없어!\n장료, 전력을 다해 싸우자!', 10)
            fight.showStart()
            fight.setAction(True, 8)
            fight.say(True, '이걸 받아라!', True)
            fight.setAction(True, 2)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack1(False, 2, True)
            fight.setAction(False, 2)
            fight.attack1(False, 4, False)
            fight.setAction(False, 1)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(True, 0, True)
            fight.attack2(False, 0, True)
            fight.attack2(False, 0, True)
            fight.attack1(False, 3, False)
            fight.setAction(False, 2)
            fight.attack1(False, 2, True)
            fight.say(True, '(음, 정말 대단하구나!\n역시 무성이라 할 만하군!)', True)
            stage.delay(10)
            fight.setAction(False, 0)
            fight.say(False, '무슨 일이야, 장료?\n그런 무술 실력으로,\n아직도 나를 이기고 싶어?', True)
            fight.setAction(True, 0)
            fight.say(True, '(이 사람이 이렇게 죽는 건 너무 아깝잖아!\n어떻게든 그를 항복시키도록 해야겠어!)', True)
            fight.end()
        vars[41] = 1
    if vars[2] and not vars[42] and stage.isNear(17, 3, True):
        stage.unit(17).setDir(stage.countDir(17, 3))
        stage.unit(3).setDir(stage.countDir(3, 17))
        stage.say('&17\n관장군, 제발 제 말 좀 들어주세요.\n&3\n왜 여기 여자가 있지!?\n여포에서 본 ......가 기억나요.\n&17\n관장군을 만난 초선 있습니다.\n관장군은 현재 상황을 알고 있을 것이다,\n항복할 의지가 있다면 이 전쟁은 진압될 수 있습니다.\n&3\n그때도 항복을 거부하지 않았여포?\n&17\n내 임무는 이 싸움을 멈추는 거야.\n&17\n관장군, 부탁드립니다.\n전쟁이 길어질수록 더 많은 무고한 사람들이 고통받게 될 것입니다.\n그러니 어쨌든 ......해 주세요.\n&3\n우리의 생각이 일치하지만,\n하지만 나는 항복할 수 없다.\n&3\n결국 이 전쟁은,\n우리가 시작한 게 아니야.\n용서해 주세요.')
        vars[42] = 1
    if vars[2] and not vars[43] and stage.isNear(23, 3, True):
        stage.unit(23).setDir(stage.countDir(23, 3))
        stage.unit(3).setDir(stage.countDir(3, 23))
        stage.say('&23\n이 혼란스러운 세상을 진정시키기 위해,\n강력한 군대와 엄격한 군사 규율이 필요합니다.\n&23\n조조주군 혼란스러운 시대를 진정시킬 힘을 지녔다,\n하지만 지금은 적도 많고 인재도 부족해서,\n&23\n장군관우 문학적, 군사적 재능을 모두 갖춘 인물입니다.\n우리 주군 정말 너 같은 재능이 필요해.\n&23\n항복해!\n함께 합시다\n평화를 회복하라.\n&3\n혼란스러운 세상에 평화를 회복하기 위해,\n가족을 조조 주군고 저를 봉신으로 인정해주기만 하면 충분합니다.\n이렇게 해서 규율 있는 국가가 수립될 수 있다.\n&23\n응.........')
        vars[43] = 1
    if vars[2] and not vars[44] and stage.isNear(22, 3, True):
        stage.unit(22).setDir(stage.countDir(22, 3))
        stage.unit(3).setDir(stage.countDir(3, 22))
        stage.say('&22\n네 무공은 유비 깃발 아래 있다,\n완전히 활용할 수 없습니다.\n&22\n네가 아군 지휘에 합류할 의지가 있다면,\n능력을 완전히 활용할 수 있을 뿐만 아니라,\n또한 현재의 어려움을 극복하는 데도 도움이 될 수 있습니다.\n&22\n관우, 아군에 합류하는 건 어때?\n재능 때문에 그렇게 인정받지 못하고 싶진 않겠지?\n&3\n나는 내 자신을 지키지 못했고,\n하지만 세상 사람들을 위해서였다.\n&3\n개인적인 이익을 위해 싸우지 않을 거야.\n뒤로 물러서!\n&22\n음음!')
        vars[44] = 1
    if vars[2] and not vars[45] and stage.isNear(20, 3, True):
        stage.unit(20).setDir(stage.countDir(20, 3))
        stage.unit(3).setDir(stage.countDir(3, 20))
        stage.say('&20\n군대의 혼란 속에서 이미 죽었다는 소문을 들유비었어,\n관장군은 앞으로 무엇을 계획하고 있을까?\n어떻게 투자아군 있나요?\n&3\n조조의 전략가로서,\n그럼에도 불구하고 그들은 여전히 자신의 삶이나 죽음을 알지 못한다,\n이것이 그들이 아직 살아 있다는 증거입니다.\n&3\n저는 두 신사의 직책을 맡을 생각이 없습니다.\n제발, 혀 쓸데없이만 해.\n&20\n요 요 요......')
        vars[45] = 1
    if vars[3] and not vars[46] and stage.isNear(0, 3, False):
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(3).setDir(stage.countDir(3, 0))
        stage.say('&0\n윤창, 나를 섬겨라!\n절대 너를 부당하게 대하지 않을 거야.\n&3\n다시 묻는 건 노력 낭비일 거예요!\n서둘러 전쟁을 시작해!')
        vars[46] = 1
    if vars[3] and not vars[47] and stage.isNear(2, 3, False):
        stage.unit(2).setDir(stage.countDir(2, 3))
        stage.unit(3).setDir(stage.countDir(3, 2))
        stage.say('&2\n관 장군님, 함께 주군 모시죠!\n&3\n죄송하지만, 제 주군은 한 명뿐입니다......')
        stage.say('&2\n정말......?\n그럼 어쩔 수 없이 무력으로 쓸 수밖에 없네!\n관 장군, 이 문제를 저와 해결해 주세요!\n&3\n그게 바로 내가 생각한 거야. 어서!')
        fight = stage.startFight(2, 3, 5)
        fight.showUnit(True, '관장군! 여포 장군님께서 무술에 감탄하셨습니다,\n오늘은 내가 직접 경험해보려 해!', 9)
        fight.showUnit(False, '그렇게 예의 바르게 굴 필요 없어!\n장료, 전력을 다해 싸우자!', 10)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '이걸 받아라!', True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 2, True)
        fight.setAction(False, 2)
        fight.attack1(False, 4, False)
        fight.setAction(False, 1)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 3, False)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        fight.say(True, '(음, 정말 대단하구나!\n역시 무성이라 할 만하군!)', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '무슨 일이야, 장료?\n그런 무술 실력으로,\n아직도 나를 이기고 싶어?', True)
        fight.setAction(True, 0)
        fight.say(True, '(이 사람이 이렇게 죽는 건 너무 아깝잖아!\n어떻게든 그를 항복시키도록 해야겠어!)', True)
        fight.end()
        vars[47] = 1
    if vars[3] and not vars[48] and stage.isNear(17, 3, False):
        stage.unit(17).setDir(stage.countDir(17, 3))
        stage.unit(3).setDir(stage.countDir(3, 17))
        stage.say('&17\n관 장군님, 제가 막지 않으면,\n이 싸움은 계속될 것이다.\n제발, 이 쓸데없는 싸움초선 그만둬!\n&3\n여자!?\n&17\n무술도 좀 알아,\n장군님, 주저하지 말.......')
        vars[48] = 1
    if not vars[50] and stage.unitStateTest(3, 7, 0, 2):
        if not vars[11]:
            stage.say('&3\n음, 정말 안타깝네요.\n어떻게 그들이 자아피를 무심코 버릴 수 있단 말인가......\n&3\n이제는 그의 아내와 자녀들조차 붙잡혔다......\n형을 실망시켰어!\n내가 죽어도 너한테 갚을 게 없어......')
            if not vars[52]:
                stage.say('&33\n언제 다들 떨어졌어?\n이제 샤피도 사라졌다......\n&33\n어쩔 수 없으니 무림에 들어가 또 다른 기회를 찾아야 해!\n젠장, 조조 기억해!')
                stage.unit(33).hide()
            if not vars[51]:
                stage.say('&32\n뜻밖에도 샤피가 떨어졌다......\n내 아내와 아이들—아니, 나는 둘째 남동생이 있어,\n그들이 안전한지 궁금하네요?\n&32\n잃어버린 장비도 걱정스럽습니다......\n이제 유일한 선택지는 살아남는 것뿐이다!\n먼저, 허베이 원소에 가서 합류하세요.')
                stage.unit(32).hide()
        if vars[11]:
            stage.say('&3\n음, 정말 안타깝네요.\n굴욕을 견디고 생명에 매달리기보다는......\n&3\n안 돼!\n나는 샤피에 남아 있는 형과 아내, 그리고 아이들을 버릴 수 없다,\n그렇게 하면 형에게 큰 수치가 될 거야.\n&3\n설령 전투에서 패배해 포로가 된다 해도,\n저도 그들을 지키기로 결심했습니다.\n여기서 절대 죽을 수 없어......')
        stage.unit(3).hide(1)
        stage.setRectUnitHide(0, 0, 31, 31, 2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n이대로 가면 목숨만 잃을 거야,\n일단 여기서 떠나자.\n&32\n둘째와 셋째 형제들이 조금 걱정되긴 했지만,\n하지만 아마도 죽임을 당하지는 않을 거라고 믿습니다.\n먼저 원소로 도망쳐야겠어.')
        stage.unit(32).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n형, 어디야?\n빨리 대답해!\n&33\n모두 각자의 길을 갔다......\n어쩔 수 없으니 무림에 들어가 또 다른 기회를 찾아야 해!\n젠장, 조조 기억해!')
        stage.unit(33).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(41, 7, 0, 2):
        stage.say('&41\n주군 함정에 빠진 것 같아.\n다른 선택지가 없어 그들은 후퇴할 수밖에 없었다!')
        stage.unit(41).hide(1)
        if not vars[30] and not vars[31] and not vars[32] and not vars[36]:
            stage.unit(32).show()
            stage.unit(33).show()
            stage.unit(40).show()
            stage.unit(264).show()
            stage.unit(265).show()
            stage.unit(284).show()
            stage.unit(32).setDir(stage.countDir(32, 33))
            stage.unit(33).setDir(stage.countDir(33, 32))
            stage.unit(40).setDir(stage.countDir(40, 32))
            stage.say('&32\n좀 이상하네요.........\n조조의 군대는 어디로 갔나요?\n왜 그의 흔적이 전혀 없는 거지?')
            stage.unit(33).setAction(7)
            stage.say('&33\n하하하.\n우리를 두려워하는 모양이야,\n싸우지 말고 도망쳐라!')
            stage.unit(33).setAction(0)
            stage.say('&32\n그들이 여기까지 온 것 같지 않아요,\n그들은 조용히 철수할 것이다.')
            stage.unit(40).setDir(0)
            stage.unit(40).setAction(10)
            stage.say('&40\n주님, 저쪽을 주군 보세요!\n북쪽에서 검은 연기가 피어오르고 있다......\n그것이 쉬저우의 방향이었다!')
            stage.unit(32).setDir(0)
            stage.unit(33).setDir(0)
            stage.unit(32).setAction(10)
            stage.say('&32\n아-아, 안 돼!\n알고 보니 조의 군대는 먼저 서저우를 점령할 계획이었다.\n그럼 돌아가서 샤피를 공격해!')
            stage.unit(33).setAction(10)
            stage.say('&33\n뭐라고!?\n&40\n주군, 어떻게 해야 하지?\n&32\n먼저 급히 돌아가서 구출하자.')
            vars[36] = 1
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(43, 7, 0, 2):
        stage.say('&43\n쉬저우는 이미 함락되었다.\n후퇴, 후퇴!')
        stage.unit(43).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n더는 못 참겠어, 후퇴해!')
        stage.unit(40).hide(1)
        vars[55] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n훌륭해! 관우 이미 내 손에 있어,\n샤피 성도 함락되었다.\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[615] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
