# Source Generated with Decompyle++
# File: S_17.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(6,2)',
        '(15,3)'])
    stage.nearEvent([
        3,
        109])
    stage.nearEvent([
        0,
        101,
        0,
        105,
        2,
        109], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 406,
            'hide': 1,
            'x': 21,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 6,
            'targetX': 10,
            'targetY': 21,
            'i': 0 },
        {
            'id': 407,
            'hide': 1,
            'x': 22,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'ai': 6,
            'targetX': 10,
            'targetY': 22,
            'i': 1 },
        {
            'id': 408,
            'hide': 1,
            'x': 22,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'ai': 6,
            'targetX': 12,
            'targetY': 21,
            'i': 2 },
        {
            'id': 409,
            'hide': 1,
            'x': 23,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 6,
            'targetX': 12,
            'targetY': 22,
            'i': 3 },
        {
            'id': 3,
            'x': 11,
            'y': 22,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 4 }])
    stage.createEnemy([
        {
            'id': 101,
            'x': 6,
            'y': 2,
            'lv': 6,
            'i': 0 },
        {
            'id': 105,
            'x': 5,
            'y': 2,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 210,
            'x': 7,
            'y': 1,
            'lv': 0,
            'ai': 0,
            'i': 2 },
        {
            'id': 211,
            'x': 7,
            'y': 3,
            'lv': 0,
            'ai': 0,
            'i': 3 },
        {
            'id': 212,
            'x': 4,
            'y': 10,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 213,
            'x': 3,
            'y': 9,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 214,
            'x': 5,
            'y': 9,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 234,
            'x': 4,
            'y': 8,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 103,
            'x': 3,
            'y': 5,
            'lv': 4,
            'i': 8 },
        {
            'id': 261,
            'x': 4,
            'y': 5,
            'lv': 0,
            'i': 9 },
        {
            'id': 262,
            'x': 2,
            'y': 5,
            'lv': 0,
            'i': 10 },
        {
            'id': 284,
            'x': 3,
            'y': 4,
            'lv': 0,
            'i': 11 },
        {
            'id': 106,
            'x': 7,
            'y': 6,
            'lv': 6,
            'i': 12 },
        {
            'id': 267,
            'x': 6,
            'y': 6,
            'lv': 0,
            'i': 13 },
        {
            'id': 268,
            'x': 8,
            'y': 6,
            'lv': 0,
            'i': 14 },
        {
            'id': 285,
            'x': 7,
            'y': 5,
            'lv': 0,
            'i': 15 },
        {
            'id': 109,
            'x': 18,
            'y': 6,
            'lv': 6,
            'ai': 1,
            'i': 16 },
        {
            'id': 264,
            'x': 17,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 286,
            'x': 18,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 265,
            'x': 16,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 266,
            'x': 16,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 350,
            'x': 15,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 21 },
        {
            'id': 287,
            'x': 14,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 22 },
        {
            'id': 283,
            'x': 14,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 23 },
        {
            'id': 342,
            'x': 4,
            'y': 9,
            'lv': 0,
            'ai': 1,
            'i': 24 },
        {
            'id': 263,
            'x': 3,
            'y': 6,
            'lv': 0,
            'i': 25 },
        {
            'id': 269,
            'x': 7,
            'y': 7,
            'lv': 0,
            'i': 26 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 11,
            'y': 21,
            'dir': 0 },
        {
            'idx': 1,
            'x': 15,
            'y': 14,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 2,
            'x': 20,
            'y': 14,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 3,
            'x': 4,
            'y': 16,
            'dir': 0 },
        {
            'idx': 4,
            'x': 3,
            'y': 15,
            'dir': 0 },
        {
            'idx': 5,
            'x': 5,
            'y': 15,
            'dir': 0 },
        {
            'idx': 6,
            'x': 15,
            'y': 13,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 7,
            'x': 20,
            'y': 13,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 8,
            'x': 15,
            'y': 12,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 9,
            'x': 20,
            'y': 12,
            'dir': 3,
            'hide': 1 }])
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(101, -1, 0, -1, 0, 4)
    stage.setEnemyEquip(109, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(106, 52, 0, -1, 0, -1)
    stage.setEnemyEquip(103, -1, 0, -1, 0, 8)
    stage.loadBg(17)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(4)
    stage.unit(101).setDir(stage.countDir(101, 105))
    stage.say('&101\n저수, 전투는 어떻게 되고 있나?')
    stage.unit(105).setDir(stage.countDir(105, 101))
    stage.say('&105\n원초우는 동쪽의 교량을 확보했다.\n&101\n옌량이 죽었지만,\n아군 원초우도 있어요.\n&105\n그는 두 명의 강인한 장군 중 한 명아군,\n게다가 그는 많은 병력을 지휘하고 있었다,\n이번에는 아마도 상대방에게 지지 않을 것이다.')
    stage.unit(106).setDir(stage.countDir(106, 103))
    stage.unit(103).setDir(stage.countDir(103, 106))
    stage.say('&106\n곽투 경.\n서쪽 건널목 다리는 사실상 아군에 의해 점령되었습니다.\n병력 격차가 너무 크다 아군 패배하지 않을 것이다.\n&103\n제가 직접 책임을 맡으라는 요청을 받았으니,\n이 배틀은 이미 확실한 승리야!\n사실 그게 방해가 될까 봐 걱정심배.\n&106\n(이 녀석은 아직도 이래,\n믿기 힘들어! )')
    stage.unit(109).setAction(7)
    stage.say('&109\n조조What 정말 대단해요,\n용기가 있으면 내 원추한테 한 대 맞아라!\n하하하!')
    stage.unit(109).setAction(0)
    stage.unit(101).setDir(stage.countDir(101, 0))
    stage.unit(105).setDir(stage.countDir(105, 0))
    stage.unit(106).setDir(stage.countDir(106, 0))
    stage.unit(103).setDir(stage.countDir(103, 0))
    stage.unit(0).setDir(stage.countDir(0, 3))
    stage.say('&0\n윤창, 저 문학과 무술 속 광대 같으니 좀 봐.\n&3\n오직 야만적인 용기만 있고 지혜와 전략이 부족했다.\n자신의 군사력에 과도하게 자신감을 가진 자,\n몇 가지 전략만 있으면 쉽게 처리할 수 있었다.\n&0\n음, 나는 이미 원위안을 매복시켰어,\n그리고 보급팀을 이용해 그를 속이게 하세요.\n&3\n정말 영리한 계획이네,\n하지만 보급 호송대를 지키기 어려웠다.\n&3\n제발 원초우와 마주하게 해주세요.')
    sel = stage.choice('관우 전투를 위해 파견되었다\n보급팀이 적을 유인하게 놔둬', -1)
    if sel == 1:
        stage.say('&0\n그래? 좋아, 맡길게!\n우리는 원초우를 처형해야 한다.\n&3\n관이 명령을 받았다!')
        stage.unit(0).setDir(0)
        stage.unit(3).move(18, 8, 0)
        stage.say('&3\n당신이 원초우인가요?\n내가 관, 너를 처리할게!\n덤벼라!\n&109\n흥, 자랑하는 법 참 아시네요!\n좋아, 내가 처리할게!')
        stage.unit(109).move(18, 7, 2)
        stage.unit(109).setAction(6)
        stage.unit(109).setAction(0)
        stage.unit(3).setAction(2)
        stage.effectSound(31, 1)
        stage.delay(10)
        stage.say('&3\n음, 정말 견딜 수가 없어!')
        stage.unit(3).move(18, 12, 2)
        stage.unit(109).setAction(5)
        stage.say('&109\n어디 가는 거야!')
        stage.unit(109).setAction(0)
        stage.unit(109).move(18, 11, 2)
        stage.unit(264).move(17, 9, 2)
        stage.unit(286).move(18, 9, 2)
        stage.unit(3).setDir(stage.countDir(3, 109))
        stage.unit(109).setAction(6)
        stage.unit(109).setAction(0)
        stage.unit(3).setAction(2)
        stage.effectSound(31, 1)
        stage.delay(10)
        stage.say('&3\n응?\n누가 그가 정말 그런 재능을 가지고 있을 줄 알았겠는가......')
        stage.unit(3).move(18, 17, 2)
        stage.unit(109).setAction(7)
        stage.say('&109\n뻔뻔한 허풍쟁이!\n용기 있으면 도망가지 말고 나랑 맞붙어!')
        stage.unit(109).setAction(0)
        stage.unit(109).move(18, 15, 2)
        stage.unit(264).move(17, 12, 2)
        stage.unit(286).move(18, 12, 2)
        stage.unit(3).setDir(stage.countDir(3, 109))
        stage.unit(3).setAction(5)
        stage.say('&3\n좋아, 지금이 그때야!')
        stage.unit(3).setAction(0)
        stage.unit(1, 1).show()
        stage.unit(2, 1).show()
        stage.unit(6, 1).show()
        stage.unit(7, 1).show()
        stage.unit(8, 1).show()
        stage.unit(9, 1).show()
        stage.unit(109).setAction(10)
        stage.unit(109).setDir(stage.countDir(109, 2))
        stage.unit(109).setAction(8)
        stage.say('&109\n뭐야, 매복이라고!?\n……… 오, 안 돼!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(264) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(286) }])
        stage.unit(109).setDir(stage.countDir(109, 3))
        stage.say('&109\n흠, 감히 나를 누명 씌우다니!\n어떻게 그런 비열한 수단으로 ...... 수 있지!')
        stage.unit(2).setDir(stage.countDir(2, 3))
        stage.say('&2\n진정으로 관장군이라 불릴 자격이 있다,\n너무 쉽게 미끼를 물게 만들었어!\n&3\n어리석은 원초우!\n내가 너를 옌량 만나러 데려갈게!\n&109\n와아......')
    elif sel == 2:
        stage.say('아직 당신이 출전할 정도는 아닙니다. 만약 손해가 걱정된다면, 싸움을 멈추세요. 아무튼 필요할 때는 어쩔 수 없이 희생해야 합니다. 관우는 알겠습니다.')
        stage.unit(0).setDir(stage.countDir(0, 109))
        stage.unit(0).setAction(5)
        stage.say('&0\n그럼 유인 병력을 보내라......')
        stage.unit(0).setAction(0)
        stage.unit(406).show()
        stage.unit(407).show()
        stage.unit(408).show()
        stage.unit(409).show()
        stage.unit(109).setDir(stage.countDir(109, 406))
        stage.unit(109).setAction(10)
        stage.say('&109\n어떻게?\n적의 증원군인가요?')
        stage.unit(406).move(18, 10, 3)
        stage.unit(407).move(19, 9, 3)
        stage.unit(408).move(19, 11, 3)
        stage.unit(409).move(20, 10, 3)
        stage.unit(109).setDir(stage.countDir(109, 406))
        stage.say('&109\n보급팀에서 온 ...... 같아.\n경비대조차 없었고,\n조조 정말 부주의했어!')
        stage.unit(406).move(17, 13, 2)
        stage.unit(407).move(18, 12, 2)
        stage.unit(408).move(18, 14, 2)
        stage.unit(409).move(19, 13, 2)
        stage.unit(109).setAction(5)
        stage.say('&109\n좋아, 모두 돌진하자!\n그들이 도시에 들어가기 전에,\n곡식을 다 낚아채!')
        stage.unit(109).setAction(0)
        stage.unit(109).move(17, 12, 2)
        stage.unit(264).move(17, 11, 2)
        stage.unit(286).move(18, 11, 2)
        stage.unit(265).move(17, 8, 2)
        stage.unit(266).move(18, 7, 2)
        stage.unit(350).move(17, 7, 2)
        stage.unit(287).move(18, 6, 2)
        stage.unit(283).move(17, 6, 2)
        stage.unit(109).setDir(stage.countDir(109, 407))
        stage.attackAction(109, 407, 1)
        stage.delay(10)
        stage.unit(407).setAction(4)
        stage.unit(407).hide(1)
        stage.unit(109).setDir(2)
        stage.unit(109).setAction(1)
        stage.say('&109\n하하하!\n어서 잡아!')
        stage.unit(406).move(17, 17, 2)
        stage.unit(408).move(18, 18, 2)
        stage.unit(409).move(19, 17, 2)
        stage.unit(109).move(18, 17, 2)
        stage.unit(264).move(18, 16, 2)
        stage.unit(286).move(19, 16, 2)
        stage.unit(265).move(18, 14, 2)
        stage.unit(266).move(18, 13, 2)
        stage.unit(350).move(18, 12, 2)
        stage.unit(287).move(18, 11, 2)
        stage.unit(283).move(17, 11, 2)
        stage.unit(109).setDir(stage.countDir(109, 406))
        stage.attackAction(109, 406, 1)
        stage.delay(10)
        stage.unit(406).setAction(4)
        stage.unit(406).hide(1)
        stage.unit(109).setDir(stage.countDir(109, 409))
        stage.attackAction(109, 409, 1)
        stage.delay(10)
        stage.unit(409).setAction(4)
        stage.unit(409).hide(1)
        stage.unit(109).setDir(2)
        stage.say('&109\n정말 쓸모없어!\n하하하하!')
        stage.say('때가 된 것 같아......')
        stage.unit(0).setAction(5)
        stage.unit(1, 1).show()
        stage.unit(2, 1).show()
        stage.unit(6, 1).show()
        stage.unit(7, 1).show()
        stage.unit(8, 1).show()
        stage.unit(9, 1).show()
        stage.unit(109).setDir(0)
        stage.unit(109).setAction(8)
        stage.say('&109\n뭐야, 매복이라고!?')
        stage.unit(109).setAction(4)
        stage.say('&109\n……… 오, 안 돼!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 16,
                'y1': 10,
                'x2': 19,
                'y2': 16,
                'camp': 2 }])
        stage.unit(109).setDir(stage.countDir(109, 0))
        stage.say('&109\n응, 조조 늙은 도둑!\n감히 나를 해치려 음모를 꾸미다니?\n그런 비열한 수단을 쓰다니!')
        stage.unit(2).setDir(stage.countDir(2, 109))
        stage.say('&2\n원초우, 목숨 걸고 와!\n&109\n흠, 이대로 가면......\n다른 방법이 없어, 일단 후퇴하자!\n돌아오면 다시 모이자!')
        stage.unit(109).move(17, 10, 0)
        stage.say('&3\n적은 이미 함정에 빠져 있었다.\n그럼 나, 관이 나서서 도와야겠네.')
        stage.unit(3).move(17, 21, 0)
        vars[2] = 1
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건.\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[517] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and not vars[30] and not vars[43] and not vars[52] and stage.round() == 3 and stage.curCamp() == 2:
        stage.unit(103).setAI(0)
        stage.unit(261).setAI(0)
        stage.unit(262).setAI(0)
        stage.unit(263).setAI(0)
        stage.unit(284).setAI(0)
        if stage.totalUnit(0) >= 9:
            stage.unit(103).setDir(stage.countDir(103, 0))
            stage.say('&103\n증오스러운 조조......\n이렇게 대립적일 줄은 몰랐어요!')
            stage.unit(103).setAI(1)
            stage.unit(261).setAI(1)
            stage.unit(262).setAI(1)
            stage.unit(263).setAI(1)
            stage.unit(284).setAI(1)
        vars[11] = 1
    if not vars[12] and not vars[30] and not vars[43] and not vars[52] and stage.round() == 5 and stage.curCamp() == 2:
        stage.unit(106).setAI(0)
        stage.unit(267).setAI(0)
        stage.unit(268).setAI(0)
        stage.unit(269).setAI(0)
        stage.unit(285).setAI(0)
        if stage.totalUnit(0) >= 9:
            stage.unit(106).setDir(stage.countDir(106, 0))
            stage.say('&106\n흥, 정말 실망스러워!')
            stage.unit(106).setAI(1)
            stage.unit(267).setAI(1)
            stage.unit(268).setAI(1)
            stage.unit(269).setAI(1)
            stage.unit(285).setAI(1)
        vars[12] = 1
    if vars[2] and not vars[13] and stage.round() == 1 and stage.curCamp() == 2:
        stage.unit(109).setAI(6, -1, 15, 3)
        stage.unit(286).setAI(6, -1, 15, 3)
        stage.unit(287).setAI(6, -1, 15, 3)
        stage.unit(350).setAI(6, -1, 15, 3)
        vars[13] = 1
    if vars[2] and not vars[14] and stage.round() == 2 and stage.curCamp() == 0:
        stage.unit(109).setAI(4, -1, 15, 3)
        stage.unit(286).setAI(4, -1, 15, 3)
        stage.unit(287).setAI(4, -1, 15, 3)
        stage.unit(350).setAI(4, -1, 15, 3)
        vars[14] = 1
    if not vars[20] and stage.isInPos(1025, 6, 2):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 15, 3):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(408, 12, 21):
        stage.getItem(151, 0, True, 1025)
        stage.unit(408).hide()
        vars[22] = 1
    if not vars[30] and stage.isInRect(1025, 0, 0, 12, 8):
        stage.unit(101).setAction(8)
        stage.say('&101\n적을 어떻게 여기 가까이 끌어들이지?\n누군가, 이리 와! 빨리 막아!')
        stage.unit(103).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(284).setAI(1)
        stage.unit(106).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(268).setAI(1)
        stage.unit(269).setAI(1)
        stage.unit(285).setAI(1)
        vars[30] = 1
    if not vars[40] and stage.isNear(0, 101, True):
        stage.unit(0).setDir(stage.countDir(0, 101))
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.say('&0\n원소, 목숨을 걸어!\n도망칠 곳이 없어!\n&101\n무슨 헛소리를 하는 거야!\n내가 어떻게 이겼는지 봐!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 105, True):
        stage.unit(0).setDir(stage.countDir(0, 105))
        stage.unit(105).setDir(stage.countDir(105, 0))
        stage.say('&0\n비켜! 날 막지 마!\n원소 어디 있어!\n&105\n응, 주군!\n빨리 도망쳐!')
        vars[41] = 1
    if not vars[42] and stage.isNear(2, 109, False):
        stage.unit(2).setDir(stage.countDir(2, 109))
        stage.unit(109).setDir(stage.countDir(109, 2))
        stage.say('&2\n네 목을 가져가러 장료다!\n&109\n하하하!\n좋아! 덤벼!')
        stage.attackAction(2, 109, 2)
        stage.delay(10)
        stage.unit(109).setAction(6)
        stage.unit(109).setAction(0)
        stage.unit(2).setAction(2)
        stage.effectSound(31, 1)
        stage.delay(10)
        stage.say('&2\n놀랍네요!\n&109\n넌 내 당수에 안 돼!\n나를 이기려면 10년이 걸릴 거야!')
        vars[42] = 1
    if not vars[43] and stage.isNear(3, 109, False):
        stage.unit(109).setDir(stage.countDir(109, 3))
        stage.unit(3).setDir(stage.countDir(3, 109))
        stage.say('&109\n관우, 내가 처리할게!\n&3\n훌륭해! 도전을 받아들이겠습니다.')
        fight = stage.startFight(3, 109, 5)
        fight.showUnit(False, '자, 이봐, 관우. 나랑 같이 해결해!\n네가 얼마나 대단한지 보여줘!', 9)
        fight.showUnit(True, '나는 주저하지 않을 거야.\n이리 와, 이거 받아!', 10)
        fight.showStart()
        fight.setAction(False, 0)
        fight.say(False, '이걸 받아라!', True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.say(True, '무슨 일이야? 이게 네가 할 수 있는 전부야?', True)
        fight.say(False, '음음!', True)
        fight.setAction(True, 8)
        fight.say(True, '이제 내가 움직일 차례야!', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, False)
        fight.attack2(True, 0, False)
        fight.attack2(True, 1, False)
        fight.say(False, '와아아!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 1)
        stage.delay(5)
        fight.setAction(True, 6)
        fight.say(True, '나는 이미 적 장군 원초우를 죽였관운장!', True)
        fight.end()
        stage.unit(109).hide(2)
        stage.getItem(110, 0, True, 3)
        if not vars[50] and not vars[51]:
            stage.unit(105).setDir(stage.countDir(105, 101))
            stage.say('&105\n주군, 원초우가 적의 함정에 빠졌다는 소식을 들었다......\n관우의 손에 죽었어......')
            stage.unit(101).setDir(stage.countDir(101, 0))
            stage.say('&101\n뭐라고, 원초우!\n흠, 원초우도 옌량을 따랐다......\n조조와 나는 화해할 수 없어!\n&101\n그런데 또 이런 관우 하는 거야?\n젠장, 유비 또 조조와 공모하는 건가?')
        stage.unit(103).setAI(3, 0, 0, 0)
        stage.unit(261).setAI(3, 0, 0, 0)
        stage.unit(262).setAI(3, 0, 0, 0)
        stage.unit(263).setAI(3, 0, 0, 0)
        stage.unit(284).setAI(3, 0, 0, 0)
        stage.unit(106).setAI(3, 0, 0, 0)
        stage.unit(267).setAI(3, 0, 0, 0)
        stage.unit(268).setAI(3, 0, 0, 0)
        stage.unit(269).setAI(3, 0, 0, 0)
        stage.unit(285).setAI(3, 0, 0, 0)
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(101, 7, 0, 2):
        stage.say('&101\n음음음!\n다른 방법은 없어!\n후퇴!')
        stage.unit(101).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(105, 7, 0, 2):
        stage.say('&105\n음, 또 어떻게 졌지?')
        stage.unit(105).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(109, 7, 0, 2):
        stage.say('&109\n와아!')
        stage.unit(109).hide(2)
        stage.getItem(110, 0, True, 1027)
        stage.say('&101\n흠, 원초우도 ..........\n절대 저와 공존하지 않겠다고 맹세조조!')
        stage.unit(103).setAI(3, 0, 0, 0)
        stage.unit(261).setAI(3, 0, 0, 0)
        stage.unit(262).setAI(3, 0, 0, 0)
        stage.unit(263).setAI(3, 0, 0, 0)
        stage.unit(284).setAI(3, 0, 0, 0)
        stage.unit(106).setAI(3, 0, 0, 0)
        stage.unit(267).setAI(3, 0, 0, 0)
        stage.unit(268).setAI(3, 0, 0, 0)
        stage.unit(269).setAI(3, 0, 0, 0)
        stage.unit(285).setAI(3, 0, 0, 0)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(103, 7, 0, 2):
        stage.say('&103\n다른 분들은 어떻게 지내고 있을지 궁금하네요.\n혼자서는 큰 그림을 감당할 수 없어,\n먼저 후퇴하는 게 낫다!')
        stage.unit(103).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(106, 7, 0, 2):
        stage.say('&106\n이게 어떻게 가능하지!')
        stage.unit(106).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n더 이상 싸울 수 없어.\n네 능력 밖으로 할 필요 없어,\n난 물러나는 게 낫겠어.')
        stage.unit(3).hide(1)
        vars[55] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어.\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[617] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원소에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
