# Source Generated with Decompyle++
# File: R_11.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    if vars[710]:
        stage.bgSound(13)
        stage.delay(3)
        stage.loadBg(2, 35)
        stage.showUnits([
            [
                0,
                59,
                66],
            [
                181,
                69,
                58,
                3,
                11],
            [
                182,
                69,
                66,
                3,
                11]])
        stage.draw()
        stage.setEventName('가짜 황제원술')
        stage.setStageName('완 리버사이드')
        stage.info('그의 순간적인 부주의 때문에,\n주요 손실의 전위 조조,\n나중에, 완청 근처 강가에서,\n전위의 영혼을 기리기 위해 무덤을 지었어.')
        stage.delay(5)
        stage.say('전위……. 내 부주의로 네 목숨까지 날리게 하다니…….')
        stage.delay(5)
        stage.unit(0).setAction(0, 3)
        stage.delay(5)
        stage.say('&0\n너를 잃었으니,\n아들 조앙을 잃는 것보다 더 아파요.')
        stage.delay(5)
        stage.say('&182\n주군,\n우리는 전위 장군의 유물 중 하나다\n이 옷이 발견되었다.')
        stage.delay(5)
        stage.unit(0).setAction(0, 1)
        stage.delay(5)
        stage.unit(0).move(65, 66, 1)
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(5)
        stage.delay(5)
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).move(59, 66, 3)
        stage.delay(10)
        stage.unit(0).setAction(5)
        stage.say('&0\n이건 ......,')
        model.unitJoin(16, 255, 0)
        stage.getItem(90, 0)
        stage.delay(10)
        stage.say('&0\n알고 보니 유물 ...... 전위였다.')
        stage.say('&181\n......, 장군 전위!!\n&182\n우리는 반드시 복수해야 해!!')
        stage.unit(0).setAction(0)
        stage.delay(8)
        stage.say('&0\n……。')
        stage.clsUnit()
        stage.bgSound(-1)
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(143, 253, 147)
    stage.showHead(0, 317, 147)
    stage.bottomTxt('조조 심각한 타격을 입은 장수,', False, False, False)
    stage.delay(5)
    stage.head(0).move(338, 106)
    stage.delay(5)
    stage.bottomTxt('쉬두로 돌아와 재편성했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('어느 날,', True, True, False)
    stage.delay(8)
    stage.showHead(136, 427, 178)
    stage.delay(5)
    stage.bottomTxt('수춘 원술이 갑자기 자신을 황제로 선언했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('곧 소식이 조조에게 전해졌다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene1():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    if not vars[710]:
        stage.setEventName('가짜 황제원술')
    stage.setStageName('쉬두 조조 저택')
    stage.unit(22).setAction(6, 2)
    stage.say('&22\n이번에는 원술 스스로 황제를 선포했다,\n우리는 절대 그를 쉽게 넘기면 안 됩니다.\n즉시 군대를 보내 진압해야 합니다!')
    stage.unit(22).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6, 2)
    stage.say('&21\n네.\n그렇지 않으면 필연적으로 그를 비방하고 황제라고 부르는 사람들이 있을 것이다.')
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(6, 2)
    stage.say('&24\n하지만 우리가 아까 싸웠을 때, 장수\n이미 큰 타격이었어요.')
    stage.say('&24\n원술 작은 인물일 수도 있습니다,\n그러나 그의 군사력은 과소평가해서는 안 된다.')
    stage.unit(21).setAction(0, 3)
    stage.say('&21\n아군 손실은 상상할 수 없을 것입니다!')
    stage.unit(24).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(0, 1)
    stage.say('&24\n원술 맞서는 것은 무모한 선택일 수 있습니다.')
    stage.say('&21\n왜 이렇게 말하냐고요?')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n우리가 혼자 공격할 필요 없원술.\n&20\n유비, 여포, 그리고 그들도 행동하게 손책 두세요.')
    stage.unit(24).setAction(0, 3)
    stage.say('&24\n응?')
    stage.say('&21\n응.......')
    stage.unit(22).setAction(0, 3)
    stage.say('&22\n그래서 그렇게 된 거.......')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n포고가 내려지면 네 군대가 함께 공격할 것이다,\n우리의 손실은 최소화될 것입니다.')
    stage.unit(22).setAction(0, 3)
    stage.say('&22\n주군, 이 방식이 효과가 있을 것입니다.')
    stage.unit(0).setAction(3, 1)
    stage.say('&0\n그럼 즉시 사절을 보내라.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n세 부대가 합류하기로 결정하자,\n원술 요새, 쇼춘을 공격해라!')
    stage.unit(0).setAction(2, 1)
    stage.say('&0\n이는 원술가 황제를 거짓으로 주장한 것에 대한 보복이었다.')
    stage.effectSound(201, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 332, 98)
    stage.showHead(136, 428, 171)
    stage.bottomTxt('유비,', False, False, False)
    stage.delay(5)
    stage.showHead(32, 396, 80)
    stage.bottomTxt('여포,', True, False, False)
    stage.delay(5)
    stage.showHead(119, 517, 125)
    stage.bottomTxt('손책', True, False, False)
    stage.delay(5)
    stage.showHead(100, 567, 211)
    stage.bottomTxt('공격 요청을 받은 후, 조조', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 즉시 원술를 공격하기 위해 군대를 보내겠다고 약속했다,', True, False, False)
    stage.delay(5)
    stage.head(32).move(428, 91)
    stage.head(0).move(364, 171)
    stage.head(100).move(567, 221)
    stage.head(100).move(492, 221)
    stage.head(119).move(492, 141)
    stage.bottomTxt('그는 이후 군대를 이끌고 원술의 요새인 쇼춘을 공격했다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene2():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            13,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            24,
            60,
            42,
            3]])
    stage.draw()
    stage.info('이 시기에 쇼춘에는 끊임없이 많은 비가 내렸다,\n홍수로 인한 피해는 매우 심각했습니다.')
    stage.setStageName('수춘 외곽 조조군 본진')
    stage.say('&0\n문약, 나머지 세 부대는 어떻게 배치되나요?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군에게 보고합니다,')
    stage.say('&20\n유비문은 동문에, 여포문은 서문에 있습니다.\n손책 각각 남문에 야영을 쳤다.')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n주군....... 정도\n&0\n응? 무슨 일이야?\n&20\n상황은 이렇습니다.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군 최근 수춘 지역에 연속적인 폭우가 내렸다는 것도 알고 있습니다.\n지금은 홍수로 인해 땅이 진흙투성이가 되었습니다.\n&20\n그 결과, 병력의 이동은,\n꽤 어려울 거예요.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠.\n하지만 지금은 그런 낙담스러운 말을 할 때가 아니었다.')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(17, 0)
    stage.say('&0\n공격을 시작하자.\n&20\n네.')
    stage.unit(0).setAction(0, 0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 12, [
        22])
    gvars[4076] = 0
    gvars[4057] = 11
    stage.setBattlePos([
        [
            12,
            0],
        [
            13,
            0],
        [
            13,
            2],
        [
            12,
            2],
        [
            11,
            2],
        [
            12,
            1],
        [
            14,
            1],
        [
            10,
            1],
        [
            13,
            1],
        [
            11,
            1],
        [
            10,
            0],
        [
            14,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n쇼춘의 홍수는 예상보다 심각했다.\n&20\n전장은 거의 늪지대로 변해 있었다.\n&0\n흠! 이로 인해 병력 이동에 큰 어려움이 발생했다.')
    if stage.unitClickTest(22):
        stage.say('&22\n얼마 전, 나는 처음으로 손책를 봤어,\n이 사람은 진정한 황제의 위엄을 지녔지만, .......\n&0\n하지만 뭐?\n&22\n수명을 연장하는 것이 어려울 것 같아 두렵습니다.\n&0\n아.......')
    if stage.unitClickTest(15):
        stage.say('&15\n밭이 물에 잠겼다—농부들이 고생하고 있겠지?\n우리는 그들을 도울 방법을 찾아야 해.')
    if stage.unitClickTest(13):
        stage.say('&13\n원술This 재앙은 세상에 절대 남겨져서는 안 된다.')
    if stage.unitClickTest(24):
        stage.say('&24\n괜찮유비 것 같아요,\nHowever여포와 손책 아마 아무런 조치도 취하지 않을 것입니다.\n&0\n저도 그렇게 생각해요.')
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 서두르지 않으면,\n원술 머리는 유비 그들에게 가져갈 거야.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
