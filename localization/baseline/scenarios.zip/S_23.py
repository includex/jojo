# Source Generated with Decompyle++
# File: S_23.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(18,1)',
        '(17,2)'])
    stage.nearEvent([
        12,
        113,
        10,
        103])
    stage.nearEvent([
        0,
        113], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 113, 0, 3, 1)
    stage.createEnemy(
        [{'id': 113, 'x': 18, 'y': 1, 'dir': 3, 'lv': 4, 'i': 0},
         {'id': 210, 'x': 16, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 1},
         {'id': 211, 'x': 16, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 2},
         {'id': 212, 'x': 17, 'y': 3, 'lv': 0, 'ai': 0, 'i': 3},
         {'id': 213, 'x': 18, 'y': 3, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 298, 'x': 17, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 299, 'x': 10, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 6},
         {'id': 300, 'x': 10, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 7},
         {'id': 301, 'x': 18, 'y': 9, 'lv': 0, 'ai': 1, 'i': 8},
         {'id': 112, 'x': 11, 'y': 4, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 9},
         {'id': 214, 'x': 10, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 10},
         {'id': 215, 'x': 10, 'y': 5, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 11},
         {'id': 234, 'x': 10, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 235, 'x': 10, 'y': 6, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 302, 'x': 11, 'y': 5, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 103, 'x': 15, 'y': 8, 'lv': 4, 'ai': 1, 'i': 15},
         {'id': 216, 'x': 14, 'y': 9, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 217, 'x': 15, 'y': 9, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 236, 'x': 13, 'y': 9, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 237, 'x': 16, 'y': 9, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 303, 'x': 14, 'y': 8, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 218, 'x': 7, 'y': 4, 'dir': 3, 'lv': 0, 'i': 21},
         {'id': 219, 'x': 7, 'y': 5, 'dir': 3, 'lv': 0, 'i': 22},
         {'id': 238, 'x': 8, 'y': 4, 'dir': 3, 'lv': 0, 'i': 23},
         {'id': 239, 'x': 8, 'y': 5, 'dir': 3, 'lv': 0, 'i': 24},
         {'id': 220, 'x': 14, 'y': 12, 'lv': 0, 'i': 25},
         {'id': 221, 'x': 15, 'y': 12, 'lv': 0, 'i': 26},
         {'id': 240, 'x': 14, 'y': 11, 'lv': 0, 'i': 27},
         {'id': 241, 'x': 15, 'y': 11, 'lv': 0, 'i': 28},
         {'id': 318, 'hide': 1, 'x': 1, 'y': 2, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 319, 'hide': 1, 'x': 1, 'y': 3, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 320, 'hide': 1, 'x': 1, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 321, 'hide': 1, 'x': 0, 'y': 5, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 322, 'hide': 1, 'x': 14, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 323, 'hide': 1, 'x': 15, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 324, 'hide': 1, 'x': 16, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 325, 'hide': 1, 'x': 17, 'y': 17, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 36}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 2,
            'y': 16,
            'dir': 1 },
        {
            'idx': 1,
            'x': 3,
            'y': 17,
            'dir': 1 },
        {
            'idx': 2,
            'x': 6,
            'y': 16,
            'dir': 1 },
        {
            'idx': 3,
            'x': 3,
            'y': 13,
            'dir': 1 },
        {
            'idx': 4,
            'x': 5,
            'y': 15,
            'dir': 1 },
        {
            'idx': 5,
            'x': 4,
            'y': 14,
            'dir': 1 },
        {
            'idx': 6,
            'x': 5,
            'y': 17,
            'dir': 1 },
        {
            'idx': 7,
            'x': 2,
            'y': 14,
            'dir': 1 },
        {
            'idx': 8,
            'x': 4,
            'y': 16,
            'dir': 1 },
        {
            'idx': 9,
            'x': 3,
            'y': 15,
            'dir': 1 },
        {
            'idx': 10,
            'x': 6,
            'y': 18,
            'dir': 1 },
        {
            'idx': 11,
            'x': 1,
            'y': 15,
            'dir': 0 },
        {
            'idx': 12,
            'x': 4,
            'y': 18,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(113, -1, 0, 12, 0, -1)
    stage.setEnemyEquip(103, -1, 0, -1, 0, 8)
    stage.setEnemyEquip(112, -1, 0, -1, 0, 20)
    stage.loadBg(23)
    stage.setObjects(True, 17, [
        [
            18,
            9,
            4],
        [
            19,
            9,
            5]])
    stage.setObjects(True, 17, [
        [
            20,
            14,
            10],
        [
            21,
            15,
            10]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab31')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab31')
    stage.draw()
    stage.bgSound(5)
    stage.unit(113).setAction(4)
    stage.say('&113\n오늘 이런 상황에 처할 줄은 전혀 예상하지 못했습니다.')
    stage.unit(112).setDir(stage.countDir(112, 113))
    stage.unit(103).setDir(stage.countDir(103, 113))
    stage.unit(112).setAction(5)
    stage.say('&112\n주군, 괜찮아,\n난피의 성벽은 요새화되어 있습니다.\n쉽게 떨어지지 않을 거야.')
    stage.unit(112).setAction(0)
    stage.unit(103).setAction(5)
    stage.say('&103\n내가 궈투가 여기 있는 한,\n조조을 두려워할 필요는 전혀 없었다.')
    stage.unit(103).setAction(0)
    stage.unit(0).setDir(stage.countDir(0, 22))
    stage.say('&0\n이 도시는 방어하기 쉽지만 공격하기는 어렵다,\n곽가, 무슨 영리한 계획이 있어?')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n네.\n군대는 두 가지 경로로 나눌 수 있습니다.\n동시에 공격......')
    stage.unit(22).setAction(9)
    stage.say('&22\n음, 기침!')
    stage.unit(0).setDir(stage.countDir(0, 22))
    stage.say('&0\n괜찮지, 곽가?\n아직도 병이 안 낫니?\n&22\n조금 추위에 걸렸지만......\n지금은 쉴 수 없어......\n&22\n걱정하지 않으셔도 주군습니다.\n이 감기는 심각한 건 아니야.\n기침, 기침......\n&0\n너무 고집이 세......')
    stage.unit(0).setDir(stage.countDir(0, 8))
    stage.say('&0\n조비!')
    stage.unit(8).setDir(stage.countDir(8, 0))
    stage.say('&8\n존재한다.\n아버지, 왜 아들을 부르십니까!\n&0\n공로를 얻기 위해 네 병력의 절반을 줄게.\n&8\n나는 반드시 아버지의 기대에 부응할 것이다.\n&0\n음, 네가 결정해.')
    stage.unit(0).setDir(stage.countDir(0, 22))
    stage.say('곽가, 네가 조비를 보좌해라.\n예…… 콜록, 콜록……')
    stage.unit(0, 1).move(4, 11, 0)
    stage.unit(3, 1).move(4, 10, 0)
    stage.unit(5, 1).move(5, 10, 0)
    stage.unit(7, 1).move(3, 10, 0)
    stage.unit(9, 1).move(5, 11, 0)
    stage.unit(11, 1).move(3, 11, 0)
    stage.unit(1, 1).move(8, 15, 1)
    stage.unit(2, 1).move(9, 15, 1)
    stage.unit(4, 1).move(9, 14, 1)
    stage.unit(6, 1).move(9, 16, 1)
    stage.unit(8, 1).move(8, 14, 1)
    stage.unit(10, 1).move(8, 16, 1)
    stage.unit(12, 1).move(8, 17, 1)
    stage.setWinCondition('승리 조건\n1. 원담 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('원담를 물리쳐라!')
    stage.unit(113).heightLight()
    stage.startOper()
    vars[523] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 18, 1):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 17, 2):
        stage.getItem(153, -1, True, 1025)
        vars[21] = 1
    if not vars[6] and stage.totalRectUnit(2, 7, 4, 8, 5) < 4:
        stage.unit(112).setDir(2)
        stage.unit(112).setAction(1)
        stage.say('&112\n자, 시작하자.\n빨리!')
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(320).setAction(5)
        stage.say('&320\n얘들아!')
        stage.unit(320).setAction(0)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[6] = 1
    if not vars[7] and stage.totalRectUnit(2, 14, 11, 15, 12) < 4:
        stage.unit(103).setDir(2)
        stage.unit(103).setAction(1)
        stage.say('&103\n지금 행동하세요!\n뒤에서 공격해!')
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(324).show()
        stage.unit(325).show()
        stage.unit(323).setAction(5)
        stage.say('&323\n좋아, 지금이 딱 맞아!')
        stage.unit(323).setAction(0)
        stage.unit(220).setAI(1)
        stage.unit(221).setAI(1)
        stage.unit(240).setAI(1)
        stage.unit(241).setAI(1)
        vars[7] = 1
    if not vars[8] and stage.totalRectUnit(2, 9, 11, 19, 19) < 3 and stage.totalRectUnit(2, 0, 0, 8, 19) < 3:
        if not vars[51] and not vars[52]:
            stage.unit(113).setDir(stage.countDir(113, 103))
            stage.unit(113).setAction(4)
            stage.say('&113\n젠장......... 음음!\n지금은 그렇습니다......\n차라리 항복하는 게 낫겠다.')
            stage.unit(103).setDir(stage.countDir(103, 113))
            stage.say('&103\n주님, 주군! 뭐라고 했어!\n항복!?\n&113\n위대한 사람들의 목숨을 희생하는 대신,\n차라리 조조 항복하는 게 나을 거야,\n조조도 동의할 것 같아요.')
            stage.unit(103).setAction(4)
            stage.say('&103\n………\n(나, 궈투, 곧 패배한 장군이 될 것인가?)\n왜 이렇게 된 거지! )')
            stage.unit(113).setDir(stage.countDir(113, 112))
            stage.say('&113\n신핑, 가서 항복조조 구걸해.')
            stage.unit(112).setDir(stage.countDir(112, 113))
            stage.say('&112\n…… 네, 저는 제 사명을 다할 것입니다.')
            stage.setObjects(False, 16, [
                [
                    18,
                    9,
                    4],
                [
                    19,
                    9,
                    5]])
            stage.unit(112).move(9, 4, 3)
            stage.unit(112).setDir(stage.countDir(112, 0))
            stage.say('&112\n총리, 그 사소한 사람은 정말 말하기 힘들다,\n우리 가족주군 총리님께 항복하고 싶어 합니다.\n&112\n계속 싸우면 불필요한 희생만 늘어날 뿐이야,\n아군의 요청에 꼭 동의해 주시기 바랍니다.')
            stage.unit(0).setDir(stage.countDir(0, 112))
            stage.say('(……지금 원담을 놓아주는 것은 백 가지 해악만 있을 뿐 이익은 하나도 없어……)')
            sel = stage.choice('항복은 받아들여지지 않는다\n신평만 받아들여진다\n항복 받아들여', -1)
            if sel == 1:
                stage.say('&0\n네가 진심으로 항복하는 건 드물다,\n하지만 동의할 수는 없어요,\n원담 타인에게 타협하는 타입이 아니에요.')
                stage.unit(0).setAction(5)
                stage.say('&0\n성문이 열렸다! \n전군이 쇄도하라! \n일거에 성을 함락시키자!')
                stage.unit(0).setAction(0)
                stage.unit(112).setAction(10)
                stage.say('&112\n무-무슨 ......?\n조조 정말 이기고 싶어!')
                stage.unit(113).setDir(stage.countDir(113, 0))
                stage.say('&113\n도둑조조Old!"\n나도 너와 함께 죽을 거야,\n군대 전체가 전면적인 공격을 감행해 조조과 싸웠다.')
            elif sel == 2:
                stage.say('&0\n신핑, 네 brother신비에서 배워\n포기원담 항복아군?\n&112\n총리는 아직도 아군 받아들이지 않는가?\n&0\n이제 너무 늦었어......\n하지만 나는 너를 받아들일 수 있어.\n&112\n그건 안 돼.\n내 남동생과 나는 각자 자신의 영주를 섬기고 있어.')
                stage.unit(112).move(15, 2, 1)
                stage.unit(112).setDir(stage.countDir(112, 113))
                stage.say('&112\n안타깝게도.........\n조조 항복을 받아들일 생각이 없습니다,\n우리는 죽을 때까지 싸울 수밖에 없어.')
                stage.unit(113).setDir(stage.countDir(113, 112))
                stage.say('&113\n무슨 ......!?\n그냥 순종적으로 돌아왔어?\n&112\n이건, 이건 이유......\n&113\n네 형도 조조에 합류했다고 들었어.\n&113\n그러니까 네가 위험에 처한 생명이 없다고 생각하는 거지?\n흥, 이 비열한 악당아!\n&112\n뭐-뭐...!\n주군You 잘못 의심하고 있어......')
                stage.unit(112).setAction(4)
                stage.unit(112).setAction(6)
                stage.unit(112).setAction(0)
                stage.say('&112\n그렇다면.........\n단 한 번의 죽음만이 내 무죄를 증명해......\n흠......')
                stage.unit(112).hide(2)
                stage.say('&113\n아, 아... 신, 신핑......\n이 분노로 또 한 명의 충성스러운 대신을 잃었어요,\n정말로, 천국이 나를 데려갔다......')
                stage.unit(103).setDir(stage.countDir(103, 113))
                stage.say('&103\n주군, 지금 후회해도 소용없어.\n다른 방법이 없어, 전투 준비하자!\n&113\n흠, 흠... 전 군대를 동원해!\n죽을 때까지 싸운다면,\n아직도 희망의 빛이 남아 있을지도 모른다.\n&103\n(절대 실패할 수 없습니다.\n절대 아니에요! )')
                stage.unit(113).setAI(1)
                stage.unit(210).setAI(1)
                stage.unit(211).setAI(1)
                stage.unit(212).setAI(1)
                stage.unit(213).setAI(1)
                stage.unit(218).setAI(1)
                stage.unit(219).setAI(1)
                stage.unit(220).setAI(1)
                stage.unit(221).setAI(1)
                stage.unit(238).setAI(1)
                stage.unit(239).setAI(1)
                stage.unit(240).setAI(1)
                stage.unit(241).setAI(1)
                stage.unit(298).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        20,
                        14,
                        10],
                    [
                        21,
                        15,
                        10]])
            elif sel == 3:
                stage.say('&0\n음, 알겠어......\n군인들은 책임을 지지 않을 것입니다.\n&0\n하지만 나는 원담 놓을 수 없어,\n머리 위로 손을 얹어.\n&112\n허용되지 않습니다......\n&0\n그렇다면 이 문제에 협상의 여지는 없습니다.')
                stage.unit(112).move(15, 2, 1)
                stage.unit(112).setDir(stage.countDir(112, 113))
                stage.say('&112\n조조 말했지, 주군 목이 넘겨지기만 한다면,\n그는 과거는 잊기로 했다.')
                stage.unit(113).setDir(stage.countDir(113, 117))
                stage.unit(113).setAction(8)
                stage.say('&113\n뭐-뭐라고!\n내 목을 원해?\n정말 웃기네!\n&112\n주군... 나도 너와 함께 죽게 해줘,\n무고한 사람들이 희생되는 것을 막기 위해,\n신핑은 마음을 굳혔다.\n&113\n농담하지 마! 아직 죽고 싶지 않아,\n조조 늙은 악당과 죽을 때까지 싸우고 싶어.')
                stage.unit(103).setDir(stage.countDir(103, 113))
                stage.say('&103\n(만약 그런 지휘관이 있다면,\n아무리 똑똑해도 조조를 이길 수 없어,\n내 시간이 다 된 것 같아...... )')
                stage.unit(113).setDir(stage.countDir(113, 0))
                stage.unit(113).setAction(5)
                stage.say('&113\n전면군 공격! 후퇴하는 자는 처형한다!\n조조 죽을 때까지 싸워라!')
                stage.unit(113).setAction(0)
                stage.unit(210).setAI(1)
                stage.unit(211).setAI(1)
                stage.unit(212).setAI(1)
                stage.unit(213).setAI(1)
                stage.unit(218).setAI(1)
                stage.unit(219).setAI(1)
                stage.unit(220).setAI(1)
                stage.unit(221).setAI(1)
                stage.unit(238).setAI(1)
                stage.unit(239).setAI(1)
                stage.unit(240).setAI(1)
                stage.unit(241).setAI(1)
                stage.unit(298).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        20,
                        14,
                        10],
                    [
                        21,
                        15,
                        10]])
                stage.say('&215\n정말 웃기네!\n여기서 죽고 싶지 않아!')
                stage.unit(215).hide()
                stage.say('&234\n도와줘—도와줘......\n목숨을 걸고 도망칠 거야......')
                stage.unit(234).hide()
                stage.say('&303\n난 아직도 살고 싶어,\n이렇게 죽으면 안 돼!')
                stage.unit(303).hide()
                stage.say('&237\n더 이상 여기 있고 싶지 않아......')
                stage.unit(237).hide()
                stage.say('&113\n흥! 쓸모없는 녀석!')
            else:
                stage.unit(113).setDir(stage.countDir(113, 0))
                stage.unit(113).setAction(4)
                stage.say('&113\n응......\n이대로는 안 돼...\n전면 군대 공격!\n&113\n성문을 열고 싸워 나가라,\n직접 공격조조,\n싸워서 빠져나가!')
                stage.unit(113).setAI(1)
                stage.unit(210).setAI(1)
                stage.unit(211).setAI(1)
                stage.unit(212).setAI(1)
                stage.unit(213).setAI(1)
                stage.unit(218).setAI(1)
                stage.unit(219).setAI(1)
                stage.unit(220).setAI(1)
                stage.unit(221).setAI(1)
                stage.unit(238).setAI(1)
                stage.unit(239).setAI(1)
                stage.unit(240).setAI(1)
                stage.unit(241).setAI(1)
                stage.unit(298).setAI(1)
                stage.setObjects(False, 16, [
                    [
                        18,
                        9,
                        4],
                    [
                        19,
                        9,
                        5]])
                stage.setObjects(False, 16, [
                    [
                        20,
                        14,
                        10],
                    [
                        21,
                        15,
                        10]])
        vars[8] = 1
    if not vars[40] and stage.isNear(0, 113, True):
        stage.unit(0).setDir(stage.countDir(0, 113))
        stage.unit(113).setDir(stage.countDir(113, 0))
        stage.say('&0\n도망칠 곳이 없어.\n&113\n음, 조조!')
        vars[40] = 1
    if not vars[41] and stage.isNear(12, 113, False):
        stage.unit(12).setDir(stage.countDir(12, 113))
        stage.unit(113).setDir(stage.countDir(113, 12))
        stage.say('&12\n원담, 내 목숨을 줘!\n&113\n뭐라고!')
        fight = stage.startFight(12, 113, 5)
        fight.showUnit(False, '이 녀석아, 내 길을 비켜!\n내가 얼마나 원담한지 몰라?', 9)
        fight.showUnit(True, '나는 조씨의 대장군이다,\n너랑 싸우기엔 충분히 충분해.\n자, 누가 먼저 오는지 보자!', 6)
        fight.showStart()
        fight.say(False, '음, 별로야.', True)
        fight.setAction(False, 1)
        fight.setAction(True, 8)
        fight.say(True, '아직도 도망치려고 하는 거야!?', True)
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        fight.setAction(True, 1)
        fight.attack2(True, 1, False)
        fight.say(False, '와아!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 1)
        fight.setAction(True, 9)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '내가 원담 목을 베었어!', True)
        fight.end()
        stage.unit(113).hide(2)
        vars[50] = 1
        stage.getItem(80, -1, True, 12)
        stage.resumeCtrl()
        if not vars[51]:
            stage.unit(112).setDir(stage.countDir(112, 113))
            stage.say('&112\n어떻게 이런 일이 일어날 수 있지!?\n어떻게 주군 죽을 수 있겠어......')
            vars[51] = 1
        if not vars[52]:
            stage.unit(103).setDir(stage.countDir(103, 113))
            stage.unit(103).setAction(4)
            stage.say('&103\n됐어, 됐어......')
            vars[52] = 1
        stage.setRectUnitHide(0, 0, 19, 19, 2, 2)
        vars[41] = 1
    if not vars[42] and stage.isNear(10, 103, False):
        stage.unit(10).setDir(stage.countDir(10, 103))
        stage.unit(103).setDir(stage.countDir(103, 10))
        stage.say('&10\n우리가 찾았어, 궈투!\n&103\n응? 누구야!?')
        fight = stage.startFight(10, 103, 0)
        fight.showUnit(True, '나는 악진이고, 르원첸이다!\n궈투, 말에서 내려 죽음을 받아들여라!', 8)
        fight.showUnit(False, '꺼져! 이 자식아!\n나는 전쟁에서 전략과 전략에 의존한다,\n일대일로 싸우고 싶지 않아!', 9)
        fight.showStart()
        fight.setAction(False, 6)
        fight.say(False, '흥!\n너랑 신경 쓸 시간 없어!', True)
        fight.setAction(False, 4)
        stage.delay(5)
        fight.setAction(False, 1)
        fight.setAction(False, 3)
        fight.setAction(False, 3)
        fight.say(True, '도망가지 마!', True)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.setAction(False, 1)
        stage.delay(10)
        fight.setAction(False, 4)
        stage.delay(10)
        fight.say(False, '나, 나, 궈투......\n여기서 죽을 거야?\n음......', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 0)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '궈투는 이미 처형됐어!\n한 번에 적군을 짓누르라!', True)
        fight.end()
        stage.unit(103).hide(2)
        vars[52] = 1
        stage.getItem(127, -1, True, 10)
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(113, 7, 0, 2):
        stage.say('&113\n젠장... 젠장!\n흠......')
        stage.unit(113).hide(2)
        stage.getItem(80, -1, True, 1027)
        stage.resumeCtrl()
        if not vars[51]:
            stage.unit(112).setDir(stage.countDir(112, 113))
            stage.say('&112\n어떻게 이런 일이 일어날 수 있지!?\n주군 어떻게 죽었어......')
            vars[51] = 1
        if not vars[52]:
            stage.unit(103).setDir(stage.countDir(103, 113))
            stage.unit(103).setAction(4)
            stage.say('&103\n됐어, 됐어......')
            vars[52] = 1
        stage.setRectUnitHide(0, 0, 19, 19, 2, 2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(112, 7, 0, 2):
        stage.say('&112\n이게 저한테도 일어나는 일인가요......\n아니, 아니야......')
        stage.unit(112).hide(2)
        stage.getItem(127, -1, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(103, 7, 0, 2):
        stage.say('&103\n음, 기침......\n…………')
        stage.unit(103).hide(2)
        stage.getItem(115, -1, True, 1027)
        vars[52] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[0] = 1
        vars[623] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원담에게 졌다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
