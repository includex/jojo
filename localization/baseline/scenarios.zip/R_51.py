# Source Generated with Decompyle++
# File: R_51.marshal (Python 3.9)


def scene0():
    '''주유 패배하고 도망쳤다'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 31)
    stage.showUnits([
        [
            76,
            5,
            51,
            1],
        [
            77,
            5,
            51,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('주유 패배하고 도망쳤다')
    stage.setStageName('루수코우 외곽의 산길')
    stage.unit(76).move(15, 51, 1)
    stage.unitsMove([
        [
            stage.unit(76),
            68,
            51,
            1],
        [
            stage.unit(77),
            58,
            51,
            1]])
    stage.unit(77).setAction(0)
    stage.unit(76).setAction(0)
    stage.delay(3)
    stage.unit(76).setAction(2)
    stage.say('&76\n…… 젠장!\n조조 이렇게 강력할 줄은 몰랐어!')
    stage.unit(76).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n주군, 우리는 지안예를 죽을 때까지 붙잡을 것이다,\n최종 결전을 펼쳐라!')
    stage.unit(76).setAction(0, 3)
    stage.delay(3)
    stage.unit(77).setAction(17)
    stage.say('&77\n동무의 모든 병사들은 생명의 횃불을 최대한 태우겠다고 맹세한다,\n조조의 군대와 목숨을 걸고 싸우는 것.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(76).setAction(17)
    stage.say('&76\n그래, 내 아버지와 형제들이 피로 쌓은 기초,\n절대 내 손에 의해 파괴되게 두면 안 돼!')
    stage.unit(76).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(6)
    stage.say('&77\n주군 말씀이 전적으로 맞습니다.\n주군 이 결정이 있으므로,\n우리 오나라가 반드시 이길 것이다.\n&77\n…… 음음!\n음! 음!')
    stage.unit(76).setAction(3)
    stage.say('&76\n공...... 공진, 괜찮아!?\n&77\n…… 걱정 마, 지안예로 돌아가자.')
    stage.unit(76).setAction(0)
    stage.say('&76\n흠, 흠......')
    stage.unit(76).setAction(0, 1)
    stage.delay(5)
    stage.unit(77).setAction(17, 1)
    stage.say('&77\n(하늘이시여, 제발 조금만 더 시간을 주세요,\n어떻게 이렇게 죽을 수가 있지!\n동오가 통국할 때까지 살고 싶다! )')
    stage.unit(77).setAction(0, 1)
    stage.unitsMove([
        [
            stage.unit(76),
            95,
            51,
            1],
        [
            stage.unit(77),
            85,
            51,
            1]])
    stage.unit(76).hide()
    stage.unit(77).move(95, 51, 1)
    stage.delay(3)
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 406, 212)
    stage.showHead(76, 470, 212)
    stage.bottomTxt('오나라 군대는 루슈커우의 핵심 요새를 잃었고,', False, False, False)
    stage.delay(5)
    stage.head(76).move(513, 184)
    stage.delay(5)
    stage.bottomTxt('그들은 지안예 기지 지역으로 후퇴했다.', True, True, True)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            15,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('조조군의 주영지인 락쉬 입구')
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕 그들은 마침내 오나라 군대를 절박한 상황에 몰아넣었다.\n지안예의 손권은 아마 이미 꽤 어두운 얼굴일 것이다.')
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n아무리 지안예가 강해도,\n이제 오나라 군대는 우리를 막을 힘이 없습니다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n손권 지금 절박한 상황에 처해 있다,\n도망칠 길이 없었다.')
    stage.unit(20).setAction(0)
    stage.say("&0\n오늘날 세워진 국가손권 전부 상속입니다\n그의 아버지는 손견고, 형인 '리틀 오버로드'가 손책 설립되었습니다.")
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n따라서 이 전투는 매우 고된 전투였다,\n모두가 부주의해서는 안 됩니다.')
    stage.unit(1).setAction(0)
    stage.say('&1\n우리 모두 알고 있잖아, 맹덕!')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('좋습니다, 군사를 동쪽으로 진격하여 오나라를 멸망시키고!\n삼국 삼분 체제를 무너뜨리겠습니다!')
    stage.unit(0).setAction(0)
    stage.unit(0).setAction(0, 0)
    stage.unit(1).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.unit(23).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 51
    stage.setBattlePos([
        [
            19,
            1],
        [
            1,
            20],
        [
            38,
            19],
        [
            20,
            1],
        [
            1,
            19],
        [
            38,
            20],
        [
            18,
            1],
        [
            1,
            21],
        [
            38,
            18],
        [
            21,
            1],
        [
            1,
            18],
        [
            38,
            21],
        [
            19,
            0],
        [
            0,
            20],
        [
            39,
            19]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n전투에 임하라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n건예시는 거대하다,\n성벽은 4층 구조로 이루어져 있습니다.\n도시 전역에 울타리도 설치되었다.\n&0\n그래서 선 가문이 지은 거구나,\n하지만 그들은 여전히 그것을 포획할 방법을 찾아야 했다.')
    if stage.unitClickTest(3):
        stage.say('&3\n나는 반드시 오나라 군대를 전멸시킬 것이다,\n죽은 의형제의 복수를 하라.')
    if stage.unitClickTest(19):
        stage.say('&19\n(레드 클리프의 제단......?\n과거에 고대 경전에서,\n저도 이런 걸 본 적 있는 것 같아요...... )')
    if stage.unitClickTest(1):
        stage.say('&1\n갑자기 손견가 그리워졌어요,\n그는 또한 수년 전 동탁 캠페인 현장을 회상했다.\n&1\n그의 아들은 정말 과소평가해서는 안 된다.')
    if stage.unitClickTest(23):
        stage.say('&23\n주유 아직 그들의 비장의 카드를 완전히 드러내지 않은 것 같습니다.\n&23\n분명 그 뒤에 뭔가 속임수가 숨겨져 있을 거야.')
    if stage.unitClickTest(15):
        stage.say('&15\n공성전은 전적으로 육지에서 벌어진다,\n그 말에 마음이 놓였어요.\n&15\n꼭 싸워허저 걸어!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
