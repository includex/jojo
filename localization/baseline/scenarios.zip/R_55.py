# Source Generated with Decompyle++
# File: R_55.marshal (Python 3.9)


def scene0():
    '''제단을 찾아라!'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(16)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 166, 226)
    stage.showHead(50, 13, 190)
    stage.bottomTxt('서군은 청두에서 북쪽으로 진격했다.', False, False, False)
    stage.delay(5)
    stage.head(50).move(76, 147)
    stage.delay(5)
    stage.bottomTxt('그리고 지엔거 고개를 죽을 때까지 방어했다.', True, False, False)
    stage.delay(10)
    stage.head(0).move(140, 187)
    stage.delay(5)
    stage.bottomTxt('조의 군대는 적을 추격하며 승리했다,', True, True, False)
    stage.delay(5)
    stage.head(50).hide()
    stage.delay(5)
    stage.head(0).move(108, 167)
    stage.bottomTxt('치열한 전투 끝에 그들은 지엔거를 돌파했다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setEventName('제단을 찾아라!')
    stage.setStageName('지엔거 조조 본진')
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n증오스러운 공명, 그는 지엔에에 있지 않다,\n그는 분명 다른 제단에 갔을 거야!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(2)
    stage.say('&1\n젠장! 도대체 저 사람은 어디로 간 공명지!?')
    stage.unit(1).setAction(0)
    stage.delay(5)
    stage.showUnit(19, 54, 22, 2)
    stage.say('&19\n주군, 제단 위치를 이미 알았어!')
    stage.unit(0).setAction(3)
    stage.say('&0\n드디어 알았구나?\n정말 쓰라린 기다림이었다.')
    stage.unit(0).setAction(0)
    stage.unit(19).move(54, 58, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n고대 문헌은 네 개의 제단의 위치를 지적합니다.\n네 방향으로 있어야 해: 동, 서, 남, 북.\n&19\n먼저, 붉은 절벽과 바이디 시의 위치를 살펴보겠습니다.\n붉은 절벽은 남쪽에 있을 것이고, 바이디 시티는 분명 서쪽에 있을 것이다.')
    stage.unit(19).setAction(0)
    stage.say('&19\n레드 클리프와 바이디 시티의 위치를 기준으로 위치를 계산하세요......')
    stage.unit(19).setAction(6)
    stage.say('&19\n북쪽 제단은 장안 지역에 있었던 것으로 추정됩니다.\n동쪽 제단은 쉬두 근처에 있습니다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n그들이 창안과 쉬두에 있으니 안심할 수 있었다,\n우리 백성들은 분명히 제단을 짓고 있다는 걸 알게 될 거야!')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n하지만 장군님, 공명의 전략을 경솔하게 생각해서는 안 됩니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 즉시 조사하러 누군가를 보내야 한다고 생각했어.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n네, 더 이상 미룰 수 없습니다!')
    stage.unit(19).setAction(0)
    stage.say('&0\n흠.\nAlright......가후.')
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n존재한다.')
    stage.unit(23).setAction(0)
    stage.say('여기에서 장안으로 가면 허도보다 가깝습니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n원래는 즉시 대군을 장안으로 보내려 했는데,\n하지만 군대의 움직임은 너무 느린 듯했다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n장안 주변 지형에 익숙하니,\n그는 소규모 부대를 이끌고 장안으로 향했다.\n제단 위치를 조사해!')
    stage.unit(23).setAction(6)
    stage.say('&23\n네, 안심하세요, 주군.')
    stage.unit(23).setAction(0)
    stage.say('...초선!')
    stage.unit(17).setAction(0, 2)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n존재한다.')
    stage.say('&0\n너희에게 쉬두로 가서 조사하라고 명령한다,\n유비 유언장을 배달하는 두 명의 도우미도 여기 있지?\n&17\n네, 그들은 젊은 여성을 도와줄 것입니다.\n&17\n그럼 바로 출발하겠습니다.')
    stage.unit(17).setAction(0)
    stage.unit(17).move(54, 52, 1)
    stage.unitsMove([
        [
            stage.unit(17),
            54,
            40,
            0],
        [
            stage.unit(23),
            54,
            52,
            3]])
    stage.unitsMove([
        [
            stage.unit(17),
            54,
            22,
            0],
        [
            stage.unit(23),
            54,
            34,
            0]])
    stage.unit(17).hide()
    stage.unit(23).move(54, 22, 0)
    stage.unit(23).hide()
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('좋습니다. 우리도 진군합니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n하지만 주군 장안에 가려면 양평관을 거쳐야 합니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n정확히 그렇습니다.\n양평관과 지건고는 서나라의 두 주요 관문으로 알려져 있습니다.\n&19\n공명 절대 우리가 순조롭게 통과하게 하지 않을 거야.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n그렇다면, 우리는 물러서서는 안 됩니다.\n모든 장애물을 뚫어야만 앞으로 나아갈 수 있습니다!')
    stage.unit(0).setAction(0)
    stage.unit(19).move(64, 58, 3)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [], [
        17,
        23])
    gvars[4076] = 0
    gvars[4057] = 55
    stage.setBattlePos([
        [
            9,
            35],
        [
            8,
            35],
        [
            10,
            35],
        [
            7,
            35],
        [
            11,
            35],
        [
            9,
            35],
        [
            8,
            35],
        [
            10,
            35],
        [
            7,
            35],
        [
            11,
            35],
        [
            9,
            35],
        [
            8,
            35],
        [
            10,
            35],
        [
            7,
            35],
        [
            11,
            35]])
    return False


def scene1():
    if stage.battleTest():
        stage.say('&0\n출발!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n양평관에는 남문과 동문이 있습니다.\n&0\n그럼 남문에서 공격할 거라는 뜻아군?\n&20\n네.')
    if stage.unitClickTest(19):
        stage.say('&19\n도교 부대는 현무석을 사용할 수 있습니다.\n&19\n이 옥은 모든 군대의 상태를 바꿀 수 있다.\n&0\n주를 바꾸...... 건가요?\n다양한 능력을 강화하거나 낮추는 것?\n하지만 모든 단위는 .........\n&19\n네, 아군이든 적이든 상관없이 작동합니다.\n&3\n때로는 적군 능력을 향상시킬 수 있습니다,\n그리고 아군의 능력도 떨어졌죠?\n&19\n네.\n&3\n이게 얼마나 위험한 힘인가!')
    if stage.unitClickTest(3):
        stage.say('&3\n강경관과 양평관은 모두 위나라에 맞서 방어하기 위해 건설되었다.\n운명이 정말 사람들을 속이고 있는 것 같아!')
    if stage.unitClickTest(1):
        stage.say('&1\n만약 우리가 바이디 시티에 행진하듯,\n그거 정말 대단할 거야.\n맹덕, 서둘러 출발하자.\n&0\n흠.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
