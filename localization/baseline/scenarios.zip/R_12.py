# Source Generated with Decompyle++
# File: R_12.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 47)
    stage.showUnits([
        [
            0,
            71,
            52,
            3],
        [
            20,
            54,
            38,
            2],
        [
            22,
            48,
            38,
            2],
        [
            24,
            42,
            38,
            2],
        [
            21,
            36,
            38,
            2],
        [
            1,
            54,
            68],
        [
            15,
            48,
            68],
        [
            6,
            42,
            68],
        [
            5,
            36,
            68]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setEventName('인형 내놔')
    stage.setStageName('수춘 임시 총리 관저')
    stage.say('&0\n원술 어디로 도망갔지?')
    stage.unit(20).setAction(0, 1)
    stage.say('&20\n그들은 남은 병력을 모아 루난으로 도망친 것 같다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n...... 루난?')
    stage.unit(22).setAction(0, 1)
    stage.say('&22\n가짜 황제는 이름뿐 존재하지만 실제로는 멸망한 원술,\n더 이상 추적할 필요가 없었다.')
    stage.unit(22).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(0, 1)
    stage.say('&24\n네.')
    stage.unit(24).setAction(0, 2)
    stage.say('&0\n흠.......')
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n다른 세 군대는 어떤가요?')
    stage.unit(20).setAction(0, 1)
    stage.say('&20\n여포와 손책 각각 각자의 영토로 돌아갔습니다,\n쇼춘에는 유비만 남아 있어.\n&0\n좋아, 샤오페이에게 가유비게.\n&20\n샤오페이? 여포 쉬저우 인근?\n&0\n흠.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n여포This 애 ......, 절대 그냥 넘어갈 수 없어."')
    stage.unit(0).move(71, 56, 2)
    stage.say('&0\n유비 여포에 맞서는 전초기지가 되게 하자.')
    stage.unit(0).move(71, 52, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n즉시 준비해.')
    stage.unit(20).setAction(6, 1)
    stage.say('&20\n네.')
    stage.unit(0).setAction(17, 3)
    stage.say('좋습니다. 승리하여 서도로 돌아오겠습니다.')
    stage.effectSound(201, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 388, 169)
    stage.showHead(32, 452, 169)
    stage.bottomTxt('그래서,', False, False, False)
    stage.delay(5)
    stage.head(0).move(337, 93)
    stage.bottomTxt('조조 승리의 마음으로 쉬두로 돌아갔다,', True, False, False)
    stage.delay(5)
    stage.head(32).move(432, 110)
    stage.bottomTxt('유비 샤오페이로 가라는 명령을 받았다.', True, False, True)
    stage.bottomTxt('이 시기, 장안의 ......,', False, True, False)
    stage.delay(5)
    stage.showHead(131, 157, 91)
    stage.showHead(129, 221, 91)
    stage.bottomTxt('권력이 쇠퇴하는 이각과 곽사들,', True, True, False)
    stage.delay(5)
    stage.head(131).hide()
    stage.head(129).hide()
    stage.delay(5)
    stage.bottomTxt('결국 그는 반란을 일으킨 병사들에게 살해당했다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene1():
    '''서두, 총리 관저'''
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            6,
            58,
            70],
        [
            5,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n이각와 곽사가 반란군에게 살해당했다는 소식을 들었습니다.\n이게 사실인가요? 문약.\n&20\n네, 주군.\n이 병사를 어떻게 처리할 계획이야?')
    stage.effectSound(205, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('그는 공식 직책을 부여받고 관대한 대우를 받았다\n충성과 의를 이해하지 못하는 자들을 처형했다', 0)
    if sel == 1:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(205, 0)
        stage.delay(3)
        stage.say('&0\n그리고 그에게 공식 계급을 부여했다,\n그는 공식적으로 장안의 주둔군 사령관직을 맡았다.\n문약, 바로 처리하러 가!')
    elif sel == 2:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        stage.effectSound(205, 0)
        stage.delay(3)
        stage.say('&0\n이유가 무엇이든, 배신하고 주인을 죽인 것,\n그들은 정말 감사할 줄 모르는 사람이에요.\n&0\n즉시 목을 베어라!\n이제부터 장안을 방어하는 임무는,\n아군 중에서 선발되어 이 직책을 맡았습니다.\n&0\n선택은 네게 맡길게, 문약.\n즉시 준비해!')
    stage.unit(20).setAction(6)
    stage.say('&20\n네.')
    stage.showUnit(181, 95, 55, 3)
    stage.say('&181\n보고해!')
    stage.unit(20).setAction(0)
    stage.unit(181).move(48, 55, 3)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 완청의 스파이가 보고를 전달했다.\n&0\n완청에서?\n&181\n네.\n&181\n보고에 따르면 장수 징저우의 류뱌오와 힘을 합쳤다고 한다.\n음산한 의도의 징후가 보였다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n뭐라고!?\n정말 그런가요?\n&181\n이 점은 절대적으로 사실입니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(22).setAction(6)
    stage.say('&22\n주군, 이 상황은 심각해졌어.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6, 2)
    stage.say('&21\n흠.')
    stage.unit(21).setAction(0, 2)
    stage.say('&21\n류뱌오는 당시 동탁 전쟁에 참여하지 않았다.\n자신의 나라를 발전시키는 데 온 마음을 다한 그는 절대적인 자존심을 지닌 인물입니다.')
    stage.say('&21\n특히 그가 손견를 물리쳤으니,\n그들의 병력은 분명하다.')
    stage.unit(24).setAction(6, 2)
    stage.say('&24\n우리가 먼저 공격해야 해,\n즉시 완청을 공격했다.')
    stage.unit(24).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n저도 같은 생각이에요.\n그가 완전히 자리 잡기 전에 제거해야 해.\n&0\n맞아요......')
    stage.unit(0).setAction(17, 1)
    stage.say('&0\n좋아! 전 군대가 완청으로 행군했다.\n가자!')
    stage.effectSound(205, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 346, 83)
    stage.bottomTxt('완청의 장수을 보기', False, False, False)
    stage.delay(5)
    stage.showHead(143, 248, 144)
    stage.delay(5)
    stage.bottomTxt('안절부절못하는 기색을 보이고,', True, False, False)
    stage.delay(7)
    stage.head(0).move(312, 104)
    stage.delay(7)
    stage.bottomTxt('조의 군대가 다시 완성을 공격했다.', True, True, True)
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            21,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            24,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('완 외곽, 조조군의 본진')
    stage.say('&0\n우리는 완청에서 고통스러운 경험을 했습니다,\n공격하기 전에 전략을 세워야 해......\n문약, 완청 상황은 어때?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n특별한 사정은 없습니다,\n네 벽 사이의 동쪽 벽,\n일부 부품은 고장 났습니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n뭐, 동쪽 벽?\n&20\n네.')
    stage.unit(1).setAction(3, 1)
    stage.say('&1\n맹덕, 그럼 망설일 필요 없어,\n동쪽 벽에서 돌진해.')
    stage.unit(1).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.say('아니요, 서쪽 성벽을 공격합시다.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n뭐라고?! 왜?')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n이건 동쪽과 서쪽을 공격하는 속임수야.\n&0\n흠.')
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n동쪽으로 속임수하고 서쪽을 공격하는 전략은 무엇인가요?')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n장수 우리의 목표가 서쪽 벽이라고 생각하게 만들어.\n&20\n물론 장수 서쪽 성벽에 병력을 집중시킬 것이다.\n&20\n그래서 우리 정예 부대들은,\n이것은 방어가 약한 동쪽 성벽을 공격할 기회였다.\n&1\n그래서 그렇게 된 거.......\n&0\n정확히 그렇습니다.')
    stage.unit(0).setAction(17, 0)
    stage.say('&0\n전투 계획이 확정되었다.\n가자!')
    stage.unit(0).setAction(0, 0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 8)
    gvars[4076] = 0
    gvars[4057] = 12
    stage.setBattlePos([
        [
            11,
            9],
        [
            11,
            10],
        [
            10,
            8],
        [
            10,
            11],
        [
            10,
            9],
        [
            10,
            10],
        [
            11,
            8],
        [
            11,
            11],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene3():
    if stage.unitClickTest(22):
        stage.say('&22\n주군, 정면으로 돌진하자.\n&0\n왜?\n&22\n장수군에는 그런 가후이 있습니다,\n우리의 기만 전략이 그를 속일 수 있을까?\n&0\n항상 네 전략이 적에게 통할까 봐 걱정한다면,\n그럼 절대 성공하지 못할 거야.\n&22\n이건 .......')
    if stage.unitClickTest(20):
        stage.say('&20\n전장의 지형에 관해서는,\n완청은 높은 산들로 둘러싸여 있습니다.\n&0\n평지가 없나요?\n&20\n성벽 인근 지역은 다소 평평합니다,\n다른 곳에서는 좁은 길들만 있습니다.\n&0\n...... 경로?')
    if stage.unitClickTest(21):
        stage.say('&21\n가후의 행동은 우려스럽습니다,\n류비아오의 행동도 비슷했다.\n&0\n흠.')
    if stage.unitClickTest(24):
        stage.say('&24\n우리는 신속하고 단호하게 싸워야 한다!')
    if stage.unitClickTest(15):
        stage.say('&15\n꼭 나를 전투에 보내 줘.')
    if stage.unitClickTest(1):
        stage.say('&1\n나는 몇 년 전 완에서 죽은 동포들의 복수를 할 것이다.')
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.say('&22\n(동쪽으로 속임수하고, 서쪽으로 공격... 성공할 수 있을까?\n정말 그 가후...... 숨길 수 있어? )')
        stage.bgSound(-1)
        stage.clsUnit()
        return True

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
