# Source Generated with Decompyle++
# File: S_31.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(7,22)',
        '(8,23)'])
    stage.nearEvent([
        15,
        57])
    stage.nearEvent([
        0,
        57,
        0,
        58,
        0,
        9,
        12,
        139], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 139, 0, 4, 2)
    stage.createFriend([
        {
            'id': 148,
            'hide': 1,
            'x': 0,
            'y': 13,
            'dir': 1,
            'lv': 6,
            'ai': 0,
            'i': 0 }])
    stage.createEnemy([
        {
            'id': 139,
            'x': 7,
            'y': 22,
            'dir': 0,
            'lv': 6,
            'i': 0 },
        {
            'id': 58,
            'x': 8,
            'y': 21,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 1 },
        {
            'id': 9,
            'x': 6,
            'y': 21,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 2 },
        {
            'id': 138,
            'hide': 1,
            'x': 9,
            'y': 21,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 3 },
        {
            'id': 462,
            'x': 8,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 463,
            'x': 7,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 464,
            'x': 6,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 465,
            'x': 9,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 342,
            'x': 9,
            'y': 21,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 390,
            'x': 2,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 391,
            'x': 3,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 392,
            'x': 12,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 393,
            'x': 13,
            'y': 19,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 234,
            'x': 2,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 235,
            'x': 3,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 14 },
        {
            'id': 236,
            'x': 12,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 237,
            'x': 13,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 57,
            'x': 7,
            'y': 21,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 17 },
        {
            'id': 298,
            'x': 8,
            'y': 22,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 18 },
        {
            'id': 299,
            'x': 7,
            'y': 23,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 19 },
        {
            'id': 210,
            'x': 5,
            'y': 22,
            'dir': 3,
            'lv': 0,
            'i': 20 },
        {
            'id': 211,
            'x': 5,
            'y': 23,
            'dir': 3,
            'lv': 0,
            'i': 21 },
        {
            'id': 212,
            'x': 7,
            'y': 25,
            'lv': 0,
            'i': 22 },
        {
            'id': 213,
            'x': 8,
            'y': 25,
            'lv': 0,
            'i': 23 },
        {
            'id': 214,
            'x': 10,
            'y': 22,
            'dir': 1,
            'lv': 0,
            'i': 24 },
        {
            'id': 215,
            'x': 10,
            'y': 23,
            'dir': 1,
            'lv': 0,
            'i': 25 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 8,
            'y': 5 },
        {
            'idx': 1,
            'x': 18,
            'y': 29,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 2,
            'x': 18,
            'y': 30,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 3,
            'x': 8,
            'y': 1 },
        {
            'idx': 4,
            'x': 9,
            'y': 1 },
        {
            'idx': 5,
            'x': 17,
            'y': 30,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 6,
            'x': 8,
            'y': 6 },
        {
            'idx': 7,
            'x': 18,
            'y': 28,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 8,
            'x': 9,
            'y': 6 },
        {
            'idx': 9,
            'x': 19,
            'y': 29,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 10,
            'x': 7,
            'y': 6 },
        {
            'idx': 11,
            'x': 17,
            'y': 31,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 12,
            'x': 9,
            'y': 5 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(9, 0, 0, 0, 0, 12)
    stage.setEnemyEquip(139, -1, 0, -1, 0, 2)
    stage.loadBg(31)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(3)
    stage.unit(58).setDir(stage.countDir(58, 57))
    stage.say('&58\n우리의 맹렬한 공격 아래,\n조의 군대는 붕괴 직전이었다.\n또 한 번 맹렬한 공격을 개시하라!')
    stage.unit(139).setDir(stage.countDir(139, 58))
    stage.say('&139\n조급해하지 마.\n비록 모든 경기를 이기고 확실한 우위를 유지하고 있지만,\n하지만 아군 이미 매우 지쳐 있었다.\n&57\n한씽 삼촌 말이 일리가 있어.\n잠시 휴식을 취하자,\n내일 아침 일찍 공격을 개시하세요.')
    stage.unit(9).setDir(stage.countDir(9, 57))
    stage.say('&9\n그럼 군 전체에 명령을 내렸다.\n&9\n어쩌면 적군 매복하러 올지도 몰라.\n모두가 부주의해서는 안 되며 경계를 늦추지 말아야 합니다.')
    stage.unit(58).setDir(0)
    stage.unit(139).setDir(0)
    stage.unit(9).setDir(0)
    stage.say('&23\n주군 적이 여러 차례 공격을 감행했다,\n우리 사슴 요새는 이미 심각하게 파괴되었고,\n다음 공격을 견디기 어려울 것이다.\n&0\n알아!\n하지만 불평만 할 수는 없어.')
    stage.unit(0).setDir(stage.countDir(0, 15))
    stage.say('&0\n허저, 사슴 요새의 급한 수리는 어땠나요?\n&15\n그는 서두르긴 했지만......')
    stage.unit(0).setDir(stage.countDir(0, 57))
    stage.say('&0\n조홍과 서황이 이끄는 분산 부대는...\n지금 적군 후방으로 우회했습니다.\n만약 그들이 적의 사초를 무사히 점령한다면...\n&23\n하지만 분산 부대만으로는,\n상대 대군을 상대하기 어려울 것 같습니다.\n주군은 어떻게 지원할 계획이신가요?\n&0\n(이건 정말 문제네요... \n주력 부대로 적의 시선을 끌어, \n분산 부대가 적 사초를 무사히 점령하게 해야 할까요?)\n&0\n(아니면 분산 부대의 공격에 맞춰서,\n적군을 협공해야 할까요...?)')
    sel = stage.choice('주력 병력을 이용해 적군\n그리고 양쪽 sides적군에서 각각 별도의 병력을 파견해 공격을 시도했다', -1)
    if sel == 1:
        stage.say('&0\n병력이 적의 사슴 울타리를 점령하러 파견될 수 있는지,\n아군 주력 부대가 얼마나 적군 버틸 수 있느냐에 달려 있습니다!\n&23\n적과 싸우려고 유인 전술을 쓰다니, 그치?')
        stage.unit(0).setDir(stage.countDir(0, 23))
        stage.say('&0\n그래서 내가 직접 미끼 역할을 하기로 했어,\n유혹적군 몰려들었어!\n이것은 위험한 도박이 될 것입니다.\n&0\n허저, 너랑 가후 여기 있어,\n루자이 복구를 가속화하고 방어선을 강화하라!\n&15\n하지만...... 알겠어, 이해했어.')
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.unit(0).setAction(5)
        stage.say('좋습니다! 진형을 갖추겠습니다!')
        stage.unit(0).setAction(0)
        stage.unit(10, 1).move(7, 12, 2)
        stage.unit(6, 1).move(8, 12, 2)
        stage.unit(8, 1).move(9, 12, 2)
        stage.unit(0, 1).move(8, 11, 2)
        stage.unit(12, 1).move(9, 11, 2)
        stage.say('&57\n응? 조조 진형에서 빠져나가!?\n좋아! 우리도 싸울 거야.\n전 군대에 전투 투입 명령을 내려라!\n&139\n난 여기서 방어했어.\n적이 그들을 속이고 있을지도 모른다,\n모두 각별히 조심해야 합니다.\n&58\n걱정 마.\n맞죠, 장군 방덕?\n&9\n한삔 장군, 안심하십시오.\n우리는 신중하게 진행할 것입니다.')
        stage.unit(462).move(6, 15, 0)
        stage.unit(463).move(7, 15, 0)
        stage.unit(464).move(8, 15, 0)
        stage.unit(465).move(9, 15, 0)
        stage.unit(9).move(6, 16, 0)
        stage.unit(57).move(7, 16, 0)
        stage.unit(58).move(8, 16, 0)
        stage.unit(342).move(9, 16, 0)
        stage.unit(390).move(3, 15, 0)
        stage.unit(391).move(4, 15, 0)
        stage.unit(392).move(11, 15, 0)
        stage.unit(393).move(12, 15, 0)
        stage.unit(234).move(3, 16, 0)
        stage.unit(235).move(4, 16, 0)
        stage.unit(236).move(11, 16, 0)
        stage.unit(237).move(12, 16, 0)
        stage.say('적과 아군의 병력 차이가 너무 크군. 하지만 어쨌든 적군의 병력을 묶어두어야 해.')
        stage.unit(0, 1).move(8, 10, 2)
        stage.unit(12, 1).move(9, 10, 2)
        stage.unit(10, 1).move(7, 11, 2)
        stage.unit(6, 1).move(8, 11, 2)
        stage.unit(8, 1).move(9, 11, 2)
        stage.say('&0\n모든 병사들, 죽을 각오로 싸워라!\n우리는 이곳을 단단히 지켜야 한다!')
        stage.unit(0, 1).move(8, 9, 2)
        stage.unit(12, 1).move(9, 9, 2)
        stage.unit(10, 1).move(7, 10, 2)
        stage.unit(6, 1).move(8, 10, 2)
        stage.unit(8, 1).move(9, 10, 2)
        stage.say('&57\n아군 끌어들이는 것 같아?\n하지만 강가에서는 매복의 흔적이 보이지 않았다.\n&9\n조심스럽게 단계별로 진행하는 것이 가장 좋습니다.\n&0\n적군 유난히 조심스럽지만, 오히려 우리에게 유리하게 작용하고 있습니다.')
        stage.unit(0).setDir(3)
        stage.say('&0\n!? 아?')
        stage.unit(148).show()
        stage.unit(148).move(6, 13, 1)
        stage.unit(148).move(6, 8, 0)
        stage.unit(148).move(9, 8, 1)
        stage.unit(148).move(9, 2, 2)
        stage.say('&148\n좀 걱정하는 것 같지 않아?\n도와줄게.\n&15\n이 신참은 누구야!')
        stage.unit(0).setDir(stage.countDir(0, 148))
        stage.say('&0\n아, 저 사람 멍메이 씨 아니야?\n네가 항상 산과 들판에서 은둔하며 살았다고 들었어,\n어떻게 오늘 여기까지 오게 된 거지?\n&0\n허저, 무례해서는 안 됩니다.\n그 노인은 신비로운 기운과 지혜의 현자를 지녔다,\n그는 좋은 전략을 안내해 주시기 바랍니다.\n&148\n어떻게 선인의 기운과 도교 사제의 정신을 가질 수 있겠는가?\n그는 그냥 은둔하는 노인이었어.\n&148\n나는 조조와 잠깐 인연이 있다,\n원래는 그를 도와주고 싶었어요,\n그래서 여기 온 거야.\n&23\n멍메이 씨는 어떻게 우리를 도울 계획이야?\n&148\n사슴 요새 수리에 시간이 많이 걸린다는 걸 알겠어요,\n비상시에만 임시로 버티고 싶다면,\n사실 좋은 아이디어가 있어요.\n&15\n어떤 방법으로?\n&148\n울타리 근처에 잔해를 쌓아두고,\n강물을 돌려 그 위로 쏟아내고,\n이렇게 추운 날씨라면 금방 얼 것이다.\n&23\n알겠어요!\n그 결과, 자연 요새인 얼음 도시가 형성되었습니다.\n쉽게 완료할 수 있습니다.')
        stage.unit(15).move(6, 1, 3)
        stage.say('&15\n그럼 빨리 행동합시다.')
        stage.setObjects(True, 15, [
            [
                27,
                5,
                0],
            [
                28,
                5,
                1],
            [
                29,
                5,
                2],
            [
                30,
                5,
                3]])
        stage.unit(15).move(8, 2, 2)
        stage.say('&15\n이건 물을 줘야 해!')
        stage.setObjects(True, 15, [
            [
                31,
                6,
                3],
            [
                32,
                7,
                3]])
        stage.setObjects(True, 15, [
            [
                33,
                10,
                3],
            [
                34,
                11,
                3]])
        stage.unit(15).move(11, 1, 1)
        stage.say('&15\n여기서도.')
        stage.setObjects(True, 15, [
            [
                35,
                12,
                3],
            [
                36,
                12,
                2],
            [
                37,
                12,
                1],
            [
                38,
                12,
                0]])
        stage.unit(15).move(9, 1, 2)
        stage.say('&15\n오, 오, 끝났어!\n&23\n정말 좋네요!\n&148\n좋아, 그럼 이만 가볼게!\n이제부터는 너희가 열심히 일해야 해.')
        stage.unit(148).hide()
        stage.say('&0\n네, 멍메이 씨. 차오는 깊이 감사했다.\n좋아, 모든 병사들은 루자이로 철수하라!\n사슴 요새를 지켜서 적의 공격을 막아라.\n&58\n그, 그 빛나는 도시,\n정확히 무슨 일이 있었던 거야......?\n도대체 무슨 일이 있었던 거야!?\n&139\n네, 아이스 시티입니다!\n음, 진짜 요새를 지었네!\n&9\n이걸로 어떻게 공격하든,\n그리고 신속히 사슴 요새를 수리했다.\n이 혹독한 겨울에, 이 건물은 정말 요새처럼 단단하다.\n&57\n아이스 시티는 과연 어떤 곳일까요!\n두려워하지 마! 전면적인 군대 공격!\n우리는 온 힘을 다해 그들을 물리쳐야 해!')
        vars[2] = 1
    elif sel == 2:
        stage.say('&0\n적을 막아도,\n이 도시는 여전히 지키기 매우 어려웠다.\n&23\n그리고 부대가 도착할 때까지 버텨.\n&0\n그럼 여기 강가에서 적절한 순간을 기다리자!\n적에게 쉽게 알리는 것은 오히려 더 위험할 뿐이다!\n&9\n적군은 강가에 진을 치려는 듯했다,\n시간을 벌기 위해 요새를 건설하세요.\n&58\n그들의 대립은 그저 노력 낭비였다.\n&139\n그럼에도 불구하고 우리는 가만히 있을 수 없습니다.\n&57\n병사들이 완전히 휴식을 취하게 한 후,\n그럼 계획을 따라 그들과 맞서세요!')
        stage.unit(57).setAI(0)
        stage.unit(58).setAI(0)
        stage.unit(9).setAI(0)
        stage.unit(462).setAI(0)
        stage.unit(463).setAI(0)
        stage.unit(464).setAI(0)
        stage.unit(465).setAI(0)
        stage.unit(342).setAI(0)
        stage.unit(390).setAI(0)
        stage.unit(391).setAI(0)
        stage.unit(392).setAI(0)
        stage.unit(393).setAI(0)
        stage.unit(234).setAI(0)
        stage.unit(235).setAI(0)
        stage.unit(236).setAI(0)
        stage.unit(237).setAI(0)
    stage.setWinCondition('승리 조건\n1. 한슭을 격퇴한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('한윽을 쫓아내!')
    stage.unit(139).heightLight()
    stage.startOper()
    vars[531] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 4:
        stage.unit(1, 1).show()
        stage.unit(2, 1).show()
        stage.unit(5, 1).show()
        stage.unit(7, 1).show()
        stage.unit(9, 1).show()
        stage.unit(11, 1).show()
        if vars[2]:
            stage.say('&12\n우리는 적의 뒤로 성공적으로 기동했다.\n&13\n적이 우리 흔적을 찾지 못한 것 같아.\n&12\n지금 주군 적을 막고 있다,\n이건 정말 우리의 절호의 기회입니다!\n한 번에 적진을 점령하자!\n&13\n전면 돌격! 돌격!')
        elif vars[30]:
            stage.say('&12\n음, 좋지 않네요.\n전투는 이미 시작되었다.\n&13\n서둘러! 조금이라도 늦으면 본진이 위험해진다.\n돌격!')
        else:
            stage.say('&12\n우리는 적의 뒤로 성공적으로 기동했습니다.\n&13\n모든 병사들, 서둘러, 돌격!')
            stage.unit(0).setDir(stage.countDir(0, 139))
            stage.unit(0).setAction(5)
            stage.say('&0\n좋아! 전면적인 군대 공격!\n양쪽에서 적을 공격할 병력을 보내라!')
            stage.unit(0).setAction(0)
        vars[11] = 1
    if vars[11] and not vars[2] and not vars[12] and not vars[30] and stage.round() == 6 and stage.curCamp() == 2:
        stage.say('&139\n음, 협공에 휘말릴 줄은 몰랐어......\n하지만 이 단지 이 군대들만으로도,\n더블팀이 어떤 역할을 할 수 있을까요?')
        if not vars[51]:
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.say('&57\n도둑조조Old 교활한 녀석이구나.')
        if not vars[52]:
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.say('&58\n네가 성공하게 두지 않을 거야!')
        if not vars[53]:
            stage.unit(9).setDir(stage.countDir(9, 0))
            stage.say('&9\n네가 해야 할 일은 조조 목을 베는 것뿐이다!\n이 협공 공격만으로는 아군을 흔들기에는 부족했다.')
        stage.unit(57).setAI(1)
        stage.unit(58).setAI(1)
        stage.unit(138).setAI(1)
        stage.unit(9).setAI(1)
        stage.unit(462).setAI(1)
        stage.unit(463).setAI(1)
        stage.unit(464).setAI(1)
        stage.unit(465).setAI(1)
        stage.unit(342).setAI(1)
        stage.unit(390).setAI(4, -1, 7, 22)
        stage.unit(391).setAI(4, -1, 7, 22)
        stage.unit(392).setAI(4, -1, 7, 22)
        stage.unit(393).setAI(4, -1, 7, 22)
        stage.unit(234).setAI(4, -1, 7, 22)
        stage.unit(235).setAI(4, -1, 7, 22)
        stage.unit(236).setAI(4, -1, 7, 22)
        stage.unit(237).setAI(4, -1, 7, 22)
        vars[12] = 1
    if not vars[20] and stage.isInPos(1025, 7, 22):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 8, 23):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[2] and not vars[12] and not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 10, 15, 31):
        if not vars[50] and not vars[51] and not vars[52] and not vars[53]:
            stage.say('&57\n조준은 아마도 기다리느라 조급해졌을 것이다.\n전 군대를 동원하라! 조조 완전히 격파하라!\n&58\n와, 이 쥐들을 물리쳐라!\n&57\n삼촌, 캠프는 당신에게 맡길게요!\n&139\n알았어, 걱정 마.\n나, 한윅은 진영을 죽을 때까지 지키겠다고 맹세한다!')
        stage.unit(57).setAI(1)
        stage.unit(58).setAI(1)
        stage.unit(138).setAI(1)
        stage.unit(9).setAI(1)
        stage.unit(462).setAI(1)
        stage.unit(463).setAI(1)
        stage.unit(464).setAI(1)
        stage.unit(465).setAI(1)
        stage.unit(342).setAI(1)
        stage.unit(390).setAI(4, -1, 7, 22)
        stage.unit(391).setAI(4, -1, 7, 22)
        stage.unit(392).setAI(4, -1, 7, 22)
        stage.unit(393).setAI(4, -1, 7, 22)
        stage.unit(234).setAI(4, -1, 7, 22)
        stage.unit(235).setAI(4, -1, 7, 22)
        stage.unit(236).setAI(4, -1, 7, 22)
        stage.unit(237).setAI(4, -1, 7, 22)
        vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 4, 19, 11, 26):
        stage.say('&139\n음, 적이 진영에 침입하지 못하게 해!\n빨리 반격해!')
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        if vars[2]:
            if not vars[51]:
                stage.unit(57).setDir(stage.countDir(57, 139))
                stage.say('&57\n안 돼...... 캠프 ......\n빨리 후퇴해!\n진영을 지켜라!')
            if not vars[53]:
                stage.unit(9).setDir(stage.countDir(9, 139))
                stage.say('&9\n한웩 장군이 위험에 처해 있었다.\n군대 전체를 철수시켜라!\n캠프를 지켜라!')
            if not vars[52]:
                stage.unit(58).setDir(stage.countDir(58, 139))
                stage.say('&58\n음, 젠장, 조조 늙은 도둑!\n실제로 양쪽에서 공격하기 위해 병력을 보냈습니다......\n너무 교활해.')
        stage.unit(57).setAI(4, -1, 7, 22)
        stage.unit(58).setAI(4, -1, 7, 22)
        stage.unit(138).setAI(4, -1, 7, 22)
        stage.unit(9).setAI(4, -1, 7, 22)
        stage.unit(462).setAI(4, -1, 7, 22)
        stage.unit(463).setAI(4, -1, 7, 22)
        stage.unit(464).setAI(4, -1, 7, 22)
        stage.unit(465).setAI(4, -1, 7, 22)
        stage.unit(342).setAI(4, -1, 7, 22)
        stage.unit(390).setAI(4, -1, 7, 22)
        stage.unit(391).setAI(4, -1, 7, 22)
        stage.unit(392).setAI(4, -1, 7, 22)
        stage.unit(393).setAI(4, -1, 7, 22)
        stage.unit(234).setAI(4, -1, 7, 22)
        stage.unit(235).setAI(4, -1, 7, 22)
        stage.unit(236).setAI(4, -1, 7, 22)
        stage.unit(237).setAI(4, -1, 7, 22)
        vars[31] = 1
    if not vars[40] and stage.isNear(15, 57, False):
        stage.unit(15).setDir(stage.countDir(15, 57))
        stage.unit(57).setDir(stage.countDir(57, 15))
        stage.say('&15\n헤, 너 마초하겠다.\n너랑 싸우고 싶어!\n&57\n흥미롭군요, 저는 마멍치가 끝까지 동행하겠습니다!')
        fight = stage.startFight(15, 57, 5)
        fight.showUnit(True, '허저.\n마초! 직접 경험해봤어요!', 9)
        fight.showUnit(False, '그래서 그런 거야.\n호랑이 광신자로 알려진 허저이신가요?\n당신 같은 상대가 있어서 정말 멋져요!', 8)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '이걸 받아라!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 3, False)
        fight.say(True, '아, 너무 더워......\n땀이 눈으로 흘러들어오고,\n정말 참을 수가 없어요!', True)
        fight.setAction(False, 0)
        fight.setAction(True, 6)
        fight.say(True, '마초!\n기다려!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 2)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.setAction(False, 6)
        fight.say(False, '하하하. 좋아! 기다릴게!\n땀을 닦는 게 정말 나를 설득할 수 있을까?', True)
        fight.end()
        stage.say('&15\n먼저 이 셔츠 벗을게.')
        stage.effectSound(9, 1)
        stage.say('&57\n하하하.\n넌 정말 대단해,\n그가 실제로 상의를 벗고 나에게 도전했어!\n&15\n자, 다시 싸우자!\n&57\n바로 그 생각이었어요!')
        fight = stage.startFight(15, 57, 5)
        fight.showUnit(True, '음, 정말 멋지다.\n기다리게 해서 미안해, 마초.\n자, 계속 싸워.', 0)
        fight.showUnit(False, '하하하, 정말 흥미로운 사람이네요.\n방금 너 때문에 오래 기다리게 했어,\n이제 그는 재미를 좀 가져야 했다.', 0)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '난 싸워서 뚫고 나갈 거야!', True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 4, False)
        fight.setAction(False, 1)
        fight.attack1(True, 3, False)
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(True, 2, True)
        stage.delay(10)
        fight.setAction(True, 12)
        fight.say(True, '쉭! 쉭! 쉭!', False)
        fight.setAction(False, 12)
        fight.say(False, '아! 아! 아!', True)
        fight.setAction(True, 6)
        fight.say(True, '너—정말 재능이 있구나, 마초.', True)
        fight.setAction(False, 6)
        fight.say(False, '......\n이번엔 무승부로 하자.', True)
        fight.end()
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&0\n뜻밖에도 그는 허저로 그림을 그릴 수 있었다,\n마초 평판은 충분히 합당한 것 같습니다.\n&15\n옷 ...... 빨리 옷 줘.\n상의를 벗고 갈 수 없어,\n전장을 돌아다니며.')
        stage.effectSound(9, 1)
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&57\n드디어 보자, 조조.\n네가 꿈에도 나타나는 살인자야!\n오늘은 절대 너를 그냥 내보내지 않을 거야.\n&0\n삶과 죽음은 혼돈의 시대의 운명이다,\n고통과 증오 속에 살며,\n혼란스러운 시대에 살아남는 것은 불가능합니다.')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 58, True):
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(0).setDir(stage.countDir(0, 58))
        stage.say('&58\n조조, 네 죽음이 왔다!\n&0\n대담하군!')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 9, True):
        stage.unit(9).setDir(stage.countDir(9, 0))
        stage.unit(0).setDir(stage.countDir(0, 9))
        stage.say('&9\n아버지의 죽음주군 복수하고 싶어!\n목숨을 내놔!\n&0\n아직 죽을 계획은 없었어,\n이 혼란스러운 세상에서도 나는 여전히 네가 필요해!\n그래서 너한테 지지 않을 거야.')
        vars[43] = 1
    if not vars[44] and stage.isNear(12, 139, True):
        stage.unit(12).setDir(stage.countDir(12, 139))
        stage.unit(139).setDir(stage.countDir(139, 12))
        stage.say('&12\n한수이! 내 목숨을 줘!\n네 진영은 이미 내가 차지했어, 조홍!\n&139\n날 죽이고 싶어? 흥!\n반격!')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(139, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&139\n와!\n마텡 형, 미안해......\n더 이상 네 아들을 지킬 수 없어...... 흠, 음.')
        stage.unit(139).hide(2)
        stage.getItem(109, -1, True, 1027)
        if not vars[51]:
            stage.unit(57).setDir(stage.countDir(57, 1027))
            stage.say('&57\n한과 한쑤는 삼촌이었다......\n젠장, 조조 도둑!\n전군을 신속히 후퇴시켜라!')
        if not vars[53]:
            stage.unit(9).setDir(stage.countDir(9, 1027))
            stage.say('&9\n뭐라고! 캠프가 점령 중이야?\n예상치 못하게도 결국 실패했다......\n조조 정말 무서워요.')
        if not vars[52]:
            stage.unit(58).setDir(stage.countDir(58, 1027))
            stage.say('&58\n이 시점에서 다른 방법이 없었다.\n…… 안타깝네, 철수해!')
        stage.setRectUnitHide(0, 0, 19, 31, 2)
        vars[50] = 1
        stage.say('&0\n휴, 시량군은 정말 골칫거리입니다.')
        if vars[2]:
            stage.reward()
        else:
            stage.reward(0, [
                160,
                -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[631] = 1
        return True
    if not vars[51] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n흠, 아버지...... 실패했어요.\n후퇴.')
        stage.unit(57).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n나... 진짜 실패했어......?\n한숨, 먼저 나갈게!')
        stage.unit(58).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(9, 7, 0, 2):
        stage.say('&9\n음, 그거 말도 안 돼......\n후퇴가 필요한가요?')
        stage.unit(9).hide(1)
        vars[53] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적군 떠났어!\n아군 이겼어!')
        if vars[2]:
            stage.reward()
        else:
            stage.reward(0, [
                160,
                -1])
        stage.end()
        vars[0] = 1
        vars[631] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 마초군 앞에서 큰 패배를 당하고 후퇴했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
