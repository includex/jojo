# Source Generated with Decompyle++
# File: R_28.marshal (Python 3.9)


def scene0():
    stage.bgSound(0)
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            7,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            23,
            64,
            58,
            3],
        [
            24,
            64,
            52,
            3]])
    stage.draw()
    stage.info('황개이의 항복에 동의한 지 사흘 후,\n약속된 날이 마침내 찾아왔다.')
    stage.setStageName('울린조조 주 진영')
    stage.unit(0).setAction(17)
    stage.say('&0\n오늘은 황가이와 약속을 잡은 날이야,\n청룡 깃발을 단 배가 도착했을 때,\n출발하자!')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n맹덕!')
    stage.unit(0).setAction(0)
    stage.say('&0\n무슨 일이야, 원양?')
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕, 그냥 밖에서 순찰하고 있었어,\n바람이 바뀐 것을 느꼈다.')
    stage.unit(1).setAction(0)
    stage.say('&1\n한때 뒷바람이었던 것이 이제는 맞바람으로 변했다,\n왠지 항상 불길한 예감이 감돌았다.\n&0\n원양, 평소엔 이렇지 않잖아.\n바람 방향에 대해 걱정할 필요 없어요.')
    stage.unit(0).setAction(17)
    stage.say('좋습니다! 모두 출발 준비를 하십시오!')
    stage.unit(0).setAction(0)
    stage.unit(1).setAction(0, 1)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        2,
        21])
    gvars[4076] = 0
    gvars[4057] = 28
    stage.setBattlePos([
        [
            16,
            21],
        [
            8,
            20],
        [
            15,
            21],
        [
            16,
            20],
        [
            25,
            22],
        [
            25,
            23],
        [
            17,
            8],
        [
            18,
            8],
        [
            7,
            10],
        [
            10,
            13],
        [
            27,
            15],
        [
            25,
            5],
        [
            9,
            19],
        [
            24,
            21],
        [
            23,
            20]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 항상 불길한 예감이 들어.')
    if stage.unitClickTest(20):
        stage.say("&0\n문약, 전장의 지형은 어떤가요?\n&20\n네. 전장은 거의 전부 물로 이루어져 있었습니다.\n&0\n'남부의 배와 북부의 말'이라는 말은 정말 사실입니다.\n하지만 지형이 급격히 수역으로 변해도,\n전체적인 상황은 여전히 아군에게 유리합니다.")
    if stage.unitClickTest(15):
        stage.say('&15\n물속에서 싸우고 있다고? 아, 안타깝게도!\n&1\n장군 허저, 무슨 일이죠?\n왜 한숨을 쉬어?\n&15\n응? 안 돼...... 아무것도 ......!\n&1\n장군허저 수영을 못하는 걸까......\n&15\n아니...... 그건 사실이 아니에요!! 네!!')
    if stage.unitClickTest(7):
        stage.say('&7\n이상하게도, 왜 바람의 방향이 바뀌었을까요?\n계절이 북서쪽으로 불고 있을 거예요......')
    if stage.unitClickTest(24):
        stage.say('&24\n강 건너편에는 유비군의 깃발이 보이지 않는다,\n유비 공명 관측관할 계획인 것 같습니다.')
    if stage.unitClickTest(23):
        stage.say('&23\n나는 항상 황가이가 진심으로 항복하지 않는다고 느낀다.\n&0\n하하, 원허.\n편집증은 전투에서 이길 수 없어.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
