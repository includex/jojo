# Source Generated with Decompyle++
# File: R_16.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            2,
            38,
            48,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.setEventName('실종 유비')
    stage.delay(3)
    stage.setStageName('서저우 외곽에 있는 조조군 본진')
    stage.say('&0\n이번 작전으로 모두 수고 많았소.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n안타깝게도 그들은 유비.......를 제거할 수 없었다\n&0\n흠.......\n&0\n원위안, 윤창은 어떻게 지내?\n&2\n네.')
    stage.unit(20).setAction(0, 3)
    stage.unit(2).move(49, 48, 1)
    stage.delay(3)
    stage.unit(2).setAction(0, 2)
    stage.say('&2\n그는 두 명의 유비 아내와 함께 있었다.\n&0\n정말?\n좋아, 그를 여기로 데려와.\n&2\n네.')
    stage.unit(2).move(49, 16, 0)
    stage.unit(2).hide()
    stage.say('&0\n잠시 쉬어주세요.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n네.')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n네.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n…… 네.')
    stage.unit(1).setAction(0, 1)
    stage.unit(22).setAction(0, 3)
    stage.unit(20).setAction(0, 3)
    stage.delay(3)
    stage.unit(1).move(49, 54, 1)
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(1),
            49,
            42,
            0],
        [
            stage.unit(20),
            49,
            54,
            3],
        [
            stage.unit(22),
            49,
            48,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(1),
            49,
            16,
            0],
        [
            stage.unit(20),
            49,
            26,
            0],
        [
            stage.unit(22),
            49,
            21,
            0]])
    stage.unit(1).hide()
    stage.unitsMove([
        [
            stage.unit(22),
            49,
            16,
            0],
        [
            stage.unit(20),
            49,
            21,
            0]])
    stage.unit(22).hide()
    stage.unit(20).move(49, 16, 0)
    stage.unit(20).hide()
    stage.delay(10)
    stage.showUnit(2, 49, 16, 2)
    stage.unit(2).move(49, 21, 2)
    stage.showUnit(3, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(2),
            49,
            52,
            2],
        [
            stage.unit(3),
            49,
            47,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(2),
            41,
            52,
            3],
        [
            stage.unit(3),
            49,
            52,
            2]])
    stage.delay(3)
    stage.unit(2).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n구름은 길고,\n내 캠프에 남아 봉사할 수 있겠니?')
    stage.unit(0).setAction(0)
    stage.say('&3\n…… 조건이 세 가지 있어,\n총리님께서 동의하실 수 있다면,\n관은 뒤에 남았다.')
    stage.effectSound(203, 255)
    stage.bgSound(11)
    stage.delay(3)
    stage.say('&0\n흠. 세 가지 조건이 뭐야?\n&3\n첫째, 한에게는 항복할 관우 있지만 조에게는 항복하지 않아.\n&0\n흠.\n&3\n둘째, 두 숙녀를 저에게 맡기주군 바랍니다,\n두 여성의 안전을 꼭 지켜주세요.\n&0\n아, 그것도 쉽네.\n&3\n셋째,\n&3\n내 주군유비가 아직 살아 있다는 걸 알게 되면,\n제발, 총리님, 즉시 이곳을 떠나게 해 주세요.')
    model.setFace(1)
    stage.say('&0\n……!!\n&3\n어떻게 할까?')
    model.setFace(0)
    sel = stage.choice('좋아\n……', 0)
    if sel == 1:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(203, 0)
        model.setFace(0)
        stage.delay(3)
        stage.say('&0\n좋아. 이 세 가지 조건에 동의할게.')
        stage.unit(3).setAction(6)
        stage.say('&3\n이런 부당한 요청을 들어주셔서 감사합니다, 총리님.\n&3\n그래서 나, 관이 두 숙녀에게 이 이야기를 해주겠다.')
    elif sel == 2:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        model.setFace(0)
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.say('&0\n…….\n&3\n……보아하니 승낙하지 않으시는군요.\n그렇다면 어서 저의 목을 베어주세요.\n&2\n주…… 주군!\n&0\n잠깐, 운장!\n……좋다. 세 가지 조건에 동의하겠다.\n&3\n형상께서 후회하지 않으시겠습니까?\n&0\n물론이다. 나 조조는 늘 말한 바가 곧 법이니.')
        stage.unit(3).setAction(6)
        stage.say('&3\n이런 부당한 요청을 들어주셔서 감사합니다, 총리님.\n&3\n그래서 나, 관이 두 숙녀에게 이 이야기를 해주겠다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).move(49, 47, 0)
    stage.say('&3\n(형과 셋째 형은 안전할지 궁금하네...... )')
    stage.unit(3).move(49, 16, 0)
    stage.unit(3).hide()
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그가 유비가 아직 살아 있다는 사실을 알게 되자마자,\n윤창이 나를 떠나려 했어......')
    stage.unit(2).setAction(0, 2)
    stage.say('&2\n윤창전은 진정한 ...... 충성심을 가진 사람이었다.')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n좋아.\n윤창이 알아내게 해\n유비 우리 사이의 간극을 벌리고 있어.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 490, 150)
    stage.showHead(32, 554, 150)
    stage.showHead(101, 350, 27)
    stage.bottomTxt('유비가 조조에게 패배한 후,', False, False, False)
    stage.delay(5)
    stage.head(32).move(554, 70)
    stage.head(32).move(414, 27)
    stage.delay(8)
    stage.bottomTxt('그는 이후 예에서 원소에게 피신했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            101,
            52,
            28,
            2],
        [
            106,
            38,
            48,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('예 원소 저택')
    stage.showUnit(181, 52, 92)
    stage.say('&181\n주군, 유비가 도착했어.\n&101\n흠, 빨리 와주세요.\n&181\n네.')
    stage.unit(181).hide()
    stage.showUnit(32, 52, 98)
    stage.delay(10)
    stage.unit(32).move(52, 48, 0)
    stage.say('&32\n원소 주님께서 힘이 부족하신 ......유비,\n쉬저우는 조조에 의해 점령되었다.\n&101\n음, 들었어.\n정말 재앙이야.\n&106\n유비Sir, 너만 그런 거야?"')
    stage.unit(32).setAction(0, 3)
    stage.say('&32\n네.\n그의 의형제인 관우와 장비 모두 전장에서 떨어졌다.\n&101\n그래서 그런 거야.')
    stage.unit(32).setAction(0, 0)
    stage.say('&32\n그들이 아직 살아 있을까......\n&101\n좋아, 너무 슬퍼하지 마.\n관우. 장비 전역에서 유명한 영웅들이야,\n괜찮을 거야.\n&32\n그랬으면 좋겠네요......\n&101\n지금은 그냥 내 곁에 있어줘.\n&32\n…… 응. (관우, 장비...... )')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 63)
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('수두, 총리 관저 근처야')
    stage.showUnit(0, 85, 66, 3)
    stage.unit(0).move(73, 66, 3)
    stage.showUnit(3, 81, 66, 3)
    stage.unitsMove([
        [
            stage.unit(0),
            65,
            66,
            3],
        [
            stage.unit(3),
            73,
            66,
            3]])
    stage.showUnit(155, 81, 66, 3)
    stage.unitsMove([
        [
            stage.unit(0),
            57,
            66,
            3],
        [
            stage.unit(3),
            65,
            66,
            3],
        [
            stage.unit(155),
            73,
            66,
            3]])
    stage.showUnit(154, 81, 66, 3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n윤창, 이 저택은 네 것이다,\n오늘부터 여기 있어.\n&3\n그는 총리에게 감사를 표했다.\n&0\n그럼 그냥 두자.......')
    stage.unit(0).move(20, 66, 3)
    stage.unit(0).hide()
    stage.unitsMove([
        [
            stage.unit(3),
            57,
            66,
            3],
        [
            stage.unit(155),
            65,
            66,
            3],
        [
            stage.unit(154),
            73,
            66,
            3]])
    stage.delay(3)
    stage.unit(3).setAction(0, 1)
    stage.say('&3\n제발, 형수님들, 여기 계세요.\n&155\n그럼 이삼촌은 어디에 사세요?\n&3\n저는 컨시어지 오두막에 살고 있어요.\n&154\n하지만 이게 조조 ...... 아닌가?\n&3\n이제 내 형이 사라졌어,\n너희 두 형수는 내 주군이야.\n&3\n편안한 집에서 주군히 쉬게 하소서,\n조 총리는 나를 탓하지 않을 거야.\n&155\n둘째 삼촌 .......\n&154\n모두 둘째 삼촌에게 달려 있어.......')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(0, 35)
    stage.draw()
    stage.info('조조 쉬두로 돌아와 관우의 마음을 얻기 위해 가능한 모든 방법을 시도했다.')
    stage.info('조조 호화로운 저택을 관우 제공하기 위해,\n3일마다 작은 연회, 5일마다 성대한 연회,\n매일 금과 은 보물이 나눠집니다.')
    stage.info('하지만 관우의 마음은 조조에 움직였다,\n조조 점점 더 걱정이 커지고 있다.')
    stage.bgSound(-1)
    stage.loadBg(2, 25)
    stage.showUnits([
        [
            2,
            56,
            55,
            1],
        [
            3,
            78,
            55,
            1]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('쉬두, 향부 정원')
    stage.showUnit(0, 66, 80)
    stage.delay(10)
    stage.say('&0\n뭐, 너희 둘 다 여기 있어?')
    stage.unit(2).setAction(0, 2)
    stage.say('&2\n아, 주군.\n&0\n원위안.\n&2\n그래?')
    stage.unit(2).move(56, 80, 1)
    stage.delay(5)
    stage.unit(0).move(62, 80, 3)
    stage.say('&0\n윤창의 말이 밖에 묶여 있나요?\n&2\n네.\n&0\n윤창 같은 장군이 이렇게 형편없는 말을 타고 다닌다니,\n그냥 맞지 않는 거예요.\n&0\n가서 그 말을 데려와.\n&2\n어떤 말......?\n&0\n아무도 탈 수 없는 거야.\n&2\n윤창한테 줘!?\n&0\n네.\n&2\n알겠습니다.')
    stage.unit(2).move(56, 98, 2)
    stage.unit(2).hide()
    stage.unit(0).move(62, 55, 1)
    stage.say('&0\n구름이 길다.')
    stage.unit(3).setAction(0, 3)
    stage.say('&3\n응? 그래서 조 총리였구나.\n멀리서 환영하지 못하는 것,\n관은 그저 생각에 잠겨 있었다......\n&0\n아, 괜찮아.')
    stage.unit(0).move(68, 55, 1)
    stage.unit(0).setAction(0)
    stage.say('&0\n쉬두에서의 시간은 어땠나요?\n&3\n총리님의 배려 덕분에,\n인생은 매우 즐겁습니다.\n&0\n정말...... 좋아.')
    stage.unit(0).setAction(0, 2)
    stage.say('맞다. 당신은 허도를 좋아하나요? 네, 허도는 정말 번화해서 마치 꿈속의 도시 같아요.')
    stage.unit(3).setAction(0, 1)
    stage.say('&3\n관이 형을 생각하고 있는 게 틀림없어,\n아마 그래서 꿈속에 있는 것 같은 느낌이 들 거예요.......')
    stage.unit(0).setAction(0, 1)
    stage.say('...여전히 아무것도 변한 게 없군.')
    stage.showUnits([
        [
            2,
            60,
            87],
        [
            198,
            60,
            92]])
    stage.say('&2\n주군.\n말을 데려왔어.')
    stage.unit(0).setAction(0, 2)
    stage.unitsMove([
        [
            stage.unit(2),
            60,
            55,
            1],
        [
            stage.unit(198),
            60,
            63,
            0]])
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n아, 수고하셨어요.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n윤창.\n이 말은 네 거야.')
    stage.unit(3).setAction(0, 3)
    stage.say('&3\n응?')
    stage.delay(5)
    stage.unit(3).move(78, 63, 2)
    stage.delay(1)
    stage.unit(0).setAction(0, 2)
    stage.unit(2).setAction(0, 2)
    stage.unit(3).move(68, 63, 3)
    stage.say('&3\n이...... 이 말이 ......\n&0\n맞아.\n이것이 여포 타는 것입니다,\n하루에 천 마일을 이동하는 붉은 토끼 말.')
    stage.unit(3).setAction(0, 0)
    stage.say('&3\n총리가 관목에게 허락하려 한다고?\n&0\n흠.\n&0\n이 여포 공격 중에 획득한 것이었다,\n하지만 아무도 이 차를 타는 데 익숙해지지 못합니다.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n탈 수 있을 거라고 생각해요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n그리고 총리에게 큰 은혜에 감사했다.')
    stage.unit(3).setAction(0)
    stage.say('&3\n바로 시승해도 될까요?\n&0\n흠.')
    stage.unit(3).setAction(0, 3)
    stage.delay(3)
    stage.unit(3).move(62, 63, 3)
    stage.say('&3\n아, 정말 유명한 말에 걸맞네.\n조 총리님, 정말 감사합니다.\n&0\n꽤 만족한 것 같네요.')
    stage.unit(3).setAction(0, 0)
    stage.say('&3\n네.\n&3\n만약 우리가 형의 행방을 알게 된다면,\n관은 즉시 그를 만나러 갈 수 있었다.')
    stage.unit(3).setAction(0, 2)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(3),
            62,
            98,
            2],
        [
            stage.unit(198),
            60,
            98,
            2]])
    stage.unit(3).hide()
    stage.unit(198).hide()
    model.setFace(0)
    stage.say('&0\n………….\n&2\n운장, 너는…….')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            2,
            49,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n원위안, 윤창은 내 마음을 이해하지 못하는 거야?')
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n저는 어떻게 해야 할지 몰랐습니다......\n&2\n주군, 윤창 집에 갔어,\n그가 진짜 무슨 뜻인지 알아봅시다.\n&2\n윤창은 재상의 큰 은총을 깊이 받았다,\n감사하지 않을 이유가 없습니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n맞아.\n도와줄래......?')
    stage.unit(2).setAction(6)
    stage.say('&2\n저에게 맡겨 주세요.')
    stage.unit(2).setAction(0)
    stage.delay(3)
    stage.unit(2).move(81, 40, 2)
    stage.unit(2).hide()
    stage.say('&0\n유비 진짜 어떤 사람일까......?')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.loadBg(2, 0)
    stage.showUnit(3, 40, 54, 1)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('쉬관우 주')
    stage.say('&2\n관 장군 계신가요?\n&3\n누구세요?')
    stage.showUnit(2, 90, 54, 3)
    stage.say('&2\n나야.\n&3\n아, 원위안이구나.')
    stage.unit(2).move(52, 54, 3)
    stage.say('&3\n급한 일이라도 있나요?\n&2\n아니, 아무것도 아니야.\n&3\n정말?\n&3\n오늘도 조 재상이 다시 관에게 선물을 보냈다,\n그에게 감사의 뜻을 전하려고 편지를 씁니다.\n&2\n정말?\n그런데 총리께서 큰 은혜를 받으셨습니다,\n계획이 뭐야?\n&3\n관은 총리에게 깊이 감사했다.\n&2\n하지만 유현덕 소식을 듣고 나서는,\n여기서 나갈 거지?\n&3\n…… 네.\n&2\n총리를 섬기고 싶지 않아?\n&3\n내가 어디에 있든,\n내 마음은 항상 내 형과 함께해.\n&2\n흠......\n&3\n…… 원원의 형.\n&3\n관이 떠나기 전에,\n우리는 군사적 성공을 이뤄야 합니다,\n재상님의 은혜에 보답하기 위해서였다.\n&3\n부디 총리님께 알려주시기 바랍니다.\n&2\n…… 흠.')
    stage.unit(2).move(90, 54, 1)
    stage.say('&2\n방해해서 미안해.')
    stage.unit(2).move(98, 54, 1)
    stage.unit(2).hide()
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene6():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            49,
            40,
            2],
        [
            2,
            49,
            55,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말...?\n관우 그렇게 말해?')
    stage.unit(2).setAction(6)
    stage.say('&2\n네.')
    stage.unit(2).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n진정으로 의롭고 변함없는 영광이네,\n그래서 나는 그를 더 붙잡고 싶다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n주군.')
    stage.unit(0).setAction(0)
    stage.say('&0\n어떻게?\n&20\n관우 잘 지킬 좋은 계획이 있어.\n&0\n뭐라고?')
    stage.unit(20).setAction(0)
    stage.say('&20\n관우 충성스럽고 충성스러운 사람입니다.\n&20\n군사적 공로를 입증하지 못해 갚지 못하면, 주군\n그는 절대 쉬두를 떠나지 않을 것이다.\n&0\n아마도.\n&20\n반대로 생각해보면 어떨까요?\n관우가 이름을 알릴 기회만 주어지지 않는 한 그걸로 충분하다.\n&0\n흠.............')
    stage.unit(2).setAction(0, 0)
    stage.say('&2\n윤창을 이렇게 계속 두려는 거야?')
    stage.unit(20).setAction(6)
    stage.say('&20\n아니요, 원원 장군님.\n윤창이 진심으로 받아들일 때까지주군.')
    stage.unit(20).setAction(0)
    stage.unit(2).setAction(0, 3)
    stage.delay(3)
    stage.say('&0\n알겠습니다.\n윤창을 전장에 데려가지 말자.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene7():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            101,
            52,
            28,
            2],
        [
            106,
            38,
            48,
            1],
        [
            32,
            38,
            54,
            1],
        [
            110,
            67,
            48,
            3],
        [
            105,
            67,
            54,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('그 순간,', 3)
    stage.setStageName('예 원소 저택')
    stage.say('&101\n저는 곧 조조에 반대하는 캠페인을 벌일 예정입니다.\n여러분은 어떻게 생각하시나요?')
    stage.unit(110).setAction(6)
    stage.say('&110\n주군.\n&110\n저는 이 시기가 공격보다 수비가 더 중요하다고 믿습니다.\n우리는 국방에 집중하고 국가 강세를 강화해야 합니다.\n다가올 전투를 준비하기 위해 병력을 훈련시키고 있었다.\n&110\n이런 식으로 두세 년 후에,\n쉬두의 조조은 점점 지쳐 지칠 것이다,\n그럼 한 번에 밀고 부숴버리자.')
    stage.unit(110).setAction(0)
    stage.say('&101\n흠.')
    stage.unit(106).setAction(6)
    stage.say('&106\n배신자들과 배신자들은 천자의 아들을 무시조조,\n어떻게 그를 2년이나 더 참을 수 있겠어?')
    stage.unit(106).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(6)
    stage.say('&32\n심배 말씀이 전적으로 맞습니다.\n그는 가능한 한 빨리 처벌받아야 해.')
    stage.unit(32).setAction(0)
    stage.say('&101\n흠.')
    stage.unit(106).setAction(6)
    stage.say('&106\n조나라 군대에 비해 아군 군사력이 부족하다.\n또한 절대적인 이점도 가지고 있습니다.')
    stage.unit(110).setAction(2)
    stage.say('&110\n심배!\n&110\n조의 군대는 병력이 적었지만,\n하지만 모두 전투 경험이 풍부한 장군들이었다\n그가 지휘하는 정예 부대.\n&110\n너무 부주의하면,\n위험이 있을 거야!')
    stage.unit(106).setAction(0)
    stage.say('&106\n오!\n아군 이미 공손찬를 물리쳤다,\n아군의 힘을 믿지 않나요?')
    stage.unit(110).setAction(0)
    stage.say('&110\n음, .......')
    stage.unit(110).setAction(2)
    stage.say('&110\n그런 말 한 적 없어!\n&106\n그럼 정말 근시안적이네요.\n&101\n천풍, 아군 이제 강력해졌다,\n사기 절정에 달해 있다,\n그래도 패배조조 걸까요?')
    stage.unit(110).setAction(0)
    stage.say('&110\n주군, 절대 조조를 과소평가하지 마.\n이 남자는 수많은 주요 전투를 겪었고,\n매우 경험이 많아요.')
    stage.unit(101).setAction(0, 0)
    stage.say('&101\n……………。')
    stage.delay(5)
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n결심했어.\n조조를 벌할 준비를 해라.')
    stage.unit(110).setAction(3)
    stage.say('&110\n주요 ......주군!!\n&101\n톈펑, 돌아가서 반성해.')
    stage.unit(110).setAction(0)
    stage.delay(3)
    stage.unit(110).setAction(0, 1)
    stage.delay(3)
    stage.unit(110).setAction(2)
    stage.say('&110\n어떻게 이렇게 부주의할 수 있지......!\n&101\n다른 사람들은 전투 준비를 하러 갔다.')
    stage.unit(101).setAction(17)
    stage.say('&101\ntraitors조조을 벌주고 싶어!')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(105).setAction(0, 1)
    stage.say('&105\n(천풍이 여전히 옳다,\n지금은 싸울 때가 아니다조조,\n하지만 이제는 다른 방법이 없었다. )')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene8():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            49,
            40,
            2],
        [
            22,
            55,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.showUnit(181, 90, 55, 3)
    stage.say('&181\n주군! 원소 군대가 바이마 국경 근처에 집결했다,\n우리 국경을 공격하려 한다!\n&0\n흠, 드디어 왔네?\n그는 즉시 직원들을 소집해 논의를 진행했다.\n&181\n네.')
    stage.unit(181).hide()
    stage.showUnit(3, 90, 55, 3)
    stage.delay(10)
    stage.say('&3\n총리님!')
    stage.unit(3).move(49, 55, 3)
    stage.say('&0\n아, 관우다!')
    stage.unit(3).setAction(6)
    stage.say('&3\n관이 원소가 침략한다는 소식을 들었을 때,\n그리고 즉시 이곳으로 달려왔다,\n꼭 관이 돌격을 이끌도록 해.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('하하하.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n이렇게 생각해줘서 기뻐,\n하지만 이번에는 싸울 필요가 없어.\n&0\n적합한 상대가 있다면,\n그때 다시 전화할게."\n&3\n그래서 그렇게 된 거.......')
    stage.unit(3).move(95, 55, 1)
    stage.unit(3).hide()
    stage.showUnit(1, 95, 55, 3)
    stage.delay(10)
    stage.unit(1).move(73, 55, 3)
    stage.showUnit(24, 85, 40, 3)
    stage.unitsMove([
        [
            stage.unit(1),
            67,
            55,
            3],
        [
            stage.unit(24),
            79,
            40,
            3]])
    stage.showUnit(21, 85, 40, 3)
    stage.unitsMove([
        [
            stage.unit(1),
            49,
            55,
            3],
        [
            stage.unit(24),
            61,
            40,
            2],
        [
            stage.unit(21),
            67,
            40,
            2]])
    model.setFace(128)
    stage.say('&1\n드디어 원소 공격할 거야!')
    stage.unit(24).setAction(6)
    stage.say('&20\n원소 병력 수에서 절대적인 우위를 점했다.\n이번 전투는 매우 치열할 것입니다.')
    stage.unit(24).setAction(0)
    stage.say('&0\n흠.')
    stage.unit(0).setAction(17)
    stage.say('모두들 출발할 준비를 하세요.')
    stage.effectSound(202, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(101, 353, 11)
    stage.showHead(0, 325, 128)
    stage.delay(8)
    stage.head(101).move(353, 34)
    stage.delay(5)
    stage.bottomTxt('원소군은 황하를 따라 남쪽으로 진군하여 바이마로 진격했다.', False, False, False)
    stage.delay(8)
    stage.head(0).move(353, 114)
    stage.delay(8)
    stage.bottomTxt('조의 군대는 그들을 저지하기 위해 병력을 파견했다.', True, True, True)
    return False


def scene9():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            2,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            24,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('바이마 조조군 본군 진영')
    stage.unit(0).setAction(17)
    stage.say('&0\n무슨 일이 있어도 위안의 공격을 막아야 했다!')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10)
    gvars[4076] = 0
    gvars[4057] = 16
    stage.setBattlePos([
        [
            17,
            18],
        [
            15,
            9],
        [
            17,
            9],
        [
            9,
            14],
        [
            9,
            13],
        [
            8,
            15],
        [
            16,
            16],
        [
            15,
            17],
        [
            17,
            17],
        [
            18,
            17]])
    return False


def scene10():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 왜 관우 뛰게 하지 않지?\n&0\n응?\n아...... 그가 거기 있을 필요 없어.\n&1\n그렇긴 해도......')
    if stage.unitClickTest(24):
        stage.say('&24\n군대의 훈련이 개별 개인에 집중되어 있나요?\n앞으로의 전투를 위해,\n또한 각 부대의 훈련 방식에 주의를 기울이세요.')
    if stage.unitClickTest(2):
        stage.say('&2\n오래전에 옌량과 원초우에 대해 들었어,\n원소군에서 두 명의 강인한 장군으로 알려져 있다.\n&0\n흠.')
    if stage.unitClickTest(15):
        stage.say('&15\n옌량과 원초우.........\n대단하다고 들었는데?\n사실 그들과 싸우고 싶어요.')
    if stage.unitClickTest(22):
        stage.say('&22\n주군, 방금 보고서를 받았어요,\n원소의 선봉은 위대한 장군 옌량이었다.\n&0\n아, 이 사람이 옌량에게 주도권을 맡겼원소 거야?\n&0\n그는 나를 정말 골칫거리로 여기는 것 같아.')
    if stage.unitClickTest(20):
        stage.say('&20\n바이마 전투는 강에 의해 두 구역으로 나뉘었다.\n다리 건너는 승패의 결정적 지점이 될 것이다.\n&0\n음, 다리가 몇 개나 있지?\n&20\n동쪽과 서쪽 양쪽에 하나씩 있습니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
