# Source Generated with Decompyle++
# File: S_25.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(13,28)'])
    stage.nearEvent([
        1,
        35,
        1,
        32,
        1,
        3,
        1,
        33,
        11,
        3,
        11,
        33], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 35, 1, 1, 1)
    stage.createFriend([
        {
            'id': 406,
            'x': 11,
            'y': 6,
            'lv': 0,
            'i': 0 },
        {
            'id': 407,
            'x': 10,
            'y': 5,
            'lv': 0,
            'i': 1 },
        {
            'id': 408,
            'x': 12,
            'y': 5,
            'lv': 0,
            'i': 2 },
        {
            'id': 409,
            'x': 11,
            'y': 4,
            'lv': 0,
            'i': 3 }])
    stage.createEnemy([
        {
            'id': 35,
            'x': 13,
            'y': 28,
            'dir': 3,
            'lv': 6,
            'i': 0 },
        {
            'id': 41,
            'x': 13,
            'y': 27,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 1 },
        {
            'id': 42,
            'x': 12,
            'y': 28,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 2 },
        {
            'id': 32,
            'x': 8,
            'y': 15,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 3 },
        {
            'id': 34,
            'x': 8,
            'y': 15,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 4 },
        {
            'id': 258,
            'x': 7,
            'y': 14,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 3,
            'hide': 1,
            'x': 6,
            'y': 8,
            'dir': 1,
            'lv': 6,
            'ai': 1,
            'i': 6 },
        {
            'id': 318,
            'hide': 1,
            'x': 7,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 319,
            'hide': 1,
            'x': 7,
            'y': 9,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 234,
            'hide': 1,
            'x': 6,
            'y': 6,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 33,
            'hide': 1,
            'x': 14,
            'y': 6,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 10 },
        {
            'id': 320,
            'hide': 1,
            'x': 13,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 321,
            'hide': 1,
            'x': 15,
            'y': 5,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 235,
            'hide': 1,
            'x': 14,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 46,
            'hide': 1,
            'x': 9,
            'y': 17,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 14 },
        {
            'id': 322,
            'hide': 1,
            'x': 8,
            'y': 19,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 323,
            'hide': 1,
            'x': 9,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 324,
            'hide': 1,
            'x': 11,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 45,
            'hide': 1,
            'x': 3,
            'y': 17,
            'dir': 1,
            'lv': 4,
            'ai': 1,
            'i': 18 },
        {
            'id': 325,
            'hide': 1,
            'x': 3,
            'y': 18,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 326,
            'hide': 1,
            'x': 4,
            'y': 21,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 327,
            'hide': 1,
            'x': 5,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 21 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 10,
            'y': 11 },
        {
            'idx': 1,
            'x': 10,
            'y': 9 },
        {
            'idx': 2,
            'x': 11,
            'y': 8 },
        {
            'idx': 3,
            'x': 9,
            'y': 10 },
        {
            'idx': 4,
            'x': 11,
            'y': 10 },
        {
            'idx': 5,
            'x': 9,
            'y': 8 },
        {
            'idx': 6,
            'x': 12,
            'y': 9 },
        {
            'idx': 7,
            'x': 10,
            'y': 7 },
        {
            'idx': 8,
            'x': 12,
            'y': 7 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(42, -1, 0, -1, 0, 22)
    stage.setEnemyEquip(41, -1, 0, -1, 0, 23)
    stage.loadBg(25)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab30')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab30')
    stage.draw()
    stage.bgSound(6)
    stage.unit(42).setDir(stage.countDir(42, 35))
    stage.unit(42).setAction(8)
    stage.say('&42\n아니, 뭔가 잘못됐어! 심각해!\n조의 군대가 강을 건넜다!\n어떻게 해야 하지? 어떻게 해야 하지?\n&35\n당황하지 마세요!\n내가 미주 씨 임무를 맡겼던 거 기억하지?\n&41\n아, 지금 생각해보니 뭔가 생각났어.\n그는 단지 윤창 장군과 이데 장군을 매복 준비에 보내는 것뿐이었다.\n&35\n남은 것은 주군와 쯔롱의 일뿐이었다,\n만약 적을 더 깊이 유인할 수 있다면,\n모든 게 계획대로 진행될 거야. 하하하!')
    stage.unit(42).setDir(3)
    stage.unit(1).setAction(7)
    stage.say('&1\n봐, 저건 적군이야!\n정말 지치고 약한 병사였다.\n그들을 박살내라!')
    stage.unit(1).setAction(0)
    stage.say('&14\n샤호우 장군, 부주의하면 안 됩니다!\n&11\n상대는 공명,\n순욱 씨가 한 말 잊었어?\n&1\n그 늙고 약하며 장애가 있는 병사들을 두려워할 게 뭐가 있겠어!\n이 사람들은 어떤 속임수도 생각해내지 못했어.\n&32\n모든 게 네 몫이야, 쯔롱!')
    stage.unit(34).setDir(stage.countDir(34, 32))
    stage.say('&34\n내게 맡겨!')
    stage.unit(34).move(9, 13, 0)
    stage.say('&34\n저는 창산의 자오쯔롱입니다,\n조의 군대 중에 감히 나와 싸울 사람이 있나?\n&1\n내가 싸울 거야!\n조운, 네 목은 내 거야!\n잘라서 주군에게 줄게!')
    stage.unit(1).move(9, 12, 2)
    stage.unit(34).setAction(2)
    stage.say('&34\n넌 나한테 상대가 안 돼,\n다른 강력한 캐릭터를 시도해 보세요.\n&1\n뭐-뭐라고!')
    stage.unit(34).setDir(2)
    stage.say('&34\n정말 실망스러운 순간이야!\n처음에는 조의 군대가 강력한 장군들로 가득 차 있다고 생각했다......\n누가 상상이나 했겠는가, 단 한 명의 하후돈만이 싸울 의지가 있을 거라고......')
    stage.unit(34).move(8, 14, 2)
    stage.say('&34\n주군, 서둘러 후퇴해.\n그는 정말 소문대로—성격이 급한 사람이었다.\n분명히 따라잡을 거라고 믿어요!\n&32\n좋아! 후퇴, 후퇴!')
    stage.unit(32).move(6, 18, 2)
    stage.unit(258).move(6, 17, 2)
    stage.unit(34).move(7, 17, 2)
    stage.unit(1).setAction(5)
    stage.say('&1\n어떻게 감히 내 하후돈을 속일 수 있어!\n멈춰, 조운!')
    stage.unit(1).setAction(0)
    sel = stage.choice('선봉대를 동원해 추격하라\n전 군대가 추격을 개시했다', 1)
    if sel == 1:
        stage.unit(1).setDir(stage.countDir(1, 11))
        stage.unit(11).setDir(stage.countDir(11, 1))
        stage.say('&1\n이전, 군 곡물 부대를 보호하러 왔네,\n내가 가서 박살낼 거야!\n&11\n적의 함정에 빠지지 않도록 조심하세요.\n&1\n걱정 마.')
        stage.unit(1).setDir(stage.countDir(1, 14))
        stage.unit(14).setDir(stage.countDir(14, 1))
        stage.say('&1\n유진아, 나랑 같이 가!\n적이 도망치지 못하게 해!\n&14\n네!')
        stage.unit(0, 1).move(7, 16, 2)
        stage.unit(3, 1).move(7, 14, 2)
        stage.unit(4, 1).move(9, 14, 2)
        stage.unit(1, 1).move(9, 12, 2)
        stage.say('&1\n조운 가지 말고 나랑 경쟁하자!"\n&34\n약한 놈을 죽이고 싶지 않아!')
        stage.unit(32).move(6, 23, 2)
        stage.unit(258).move(6, 22, 2)
        stage.unit(34).move(7, 22, 2)
        stage.say('&1\n감히 나를 약하다고 부르다니!?\n어떻게 감히 나를 이렇게 속일 수 있어!\n절대 봐주지 않을 거야, 절대!')
        stage.unit(0, 1).move(6, 20, 2)
        stage.unit(3, 1).move(6, 18, 2)
        stage.unit(4, 1).move(7, 17, 2)
        stage.unit(1, 1).move(8, 15, 2)
        stage.say('&11\n적의 움직임을 어떻게 관찰하지,\n그냥 좀 이상하게 느껴져요.\n매복이 있을 수도 있을까?\n&11\n여기 도로는 좁아,\n모두 강 바로 옆의 잔디 경사면입니다.\n그럴 수도 있............')
        stage.unit(11).setAction(10)
        stage.say('&11\n네, 맞아요!\n그들은 분명히 불 속임수를 쓸 거예요!')
        stage.unit(11).move(10, 12, 2)
        stage.unit(11).setAction(9)
        stage.say('&11\n서둘러!\n장군에게 즉시 통보해야 합니다.')
        stage.unit(11).move(8, 14, 2)
        stage.unit(14).setDir(stage.countDir(14, 11))
        stage.unit(11).setDir(stage.countDir(11, 14))
        stage.say('&14\n왜 그렇게 당황wrong이전지?\n&11\n샤호우 장군은 어때?\n&14\n추격하는 적은 멀리 갔어.\n무슨 일이야?\n&11\n적이 화염 공격을 계획하는 것 같다,\n너무 깊게 들어가면......\n&14\n…… 맞아요!\n바로 샤후우 장군님께 알리겠습니다!\n당신은 곡물 부대를 지키러 왔어요!\n&11\n흠, 부탁할게!')
        stage.unit(11).move(10, 11, 0)
        stage.unit(14).move(6, 19, 2)
        stage.say('&14\n샤호우 장군님! 적지 깊숙이 들어갔군요!\n적은 화염 공격을 이용해 반격하려는 듯 보였아군......\n&1\n화염 공격!? 그래서.........\n실제로 도로는 울창한 식생으로 둘러싸여 있었다......\n안 돼! 즉시 후퇴해!')
        stage.unit(32).setDir(stage.countDir(32, 1))
        stage.unit(35).setDir(stage.countDir(35, 1))
        stage.say('&32\n이제 와서 생각해보니 이미 너무 늦었어요!\n&35\n지금 행동하세요!')
        stage.unit(46).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(324).show()
        stage.unit(46).setAction(5)
        stage.say('&46\n좋아, 시간이야.\n불을 지르라! 불태워라! 불태워라!\n그리고 불을 이용해 조의 군대를 포위했다.')
        stage.unit(46).setAction(0)
        stage.setFires(True, [
            [
                9,
                22],
            [
                8,
                22],
            [
                8,
                21]])
        stage.setFires(True, [
            [
                7,
                19],
            [
                7,
                18],
            [
                8,
                18]])
        stage.setFires(True, [
            [
                8,
                16],
            [
                9,
                16],
            [
                10,
                16]])
        stage.setFires(True, [
            [
                9,
                15],
            [
                10,
                15]])
        stage.setFires(True, [
            [
                10,
                13],
            [
                11,
                13],
            [
                11,
                12]])
        stage.unit(45).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(327).show()
        stage.unit(45).setAction(6)
        stage.say('&45\n좋아, 불도 피우자.\n태워버려!')
        stage.unit(45).setAction(0)
        stage.setFires(True, [
            [
                5,
                21],
            [
                5,
                20],
            [
                4,
                20],
            [
                4,
                19]])
        stage.setFires(True, [
            [
                4,
                17],
            [
                5,
                17],
            [
                5,
                16],
            [
                5,
                15],
            [
                6,
                15]])
        stage.setFires(True, [
            [
                6,
                13],
            [
                7,
                13],
            [
                7,
                12],
            [
                7,
                11]])
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(3, 1) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(4, 1) }])
        stage.unit(14).setDir(0)
        stage.unit(1).setDir(0)
        stage.unit(11).setDir(stage.countDir(11, 1))
        stage.say('&14\n속았어!\n불에 맞을 줄은 몰랐어......\n&1\n진정해!\n당황하지 마세요!\n강 건너편으로 물러나!\n&11\n안 돼! 아직 한 걸음 늦었어.\n빨리, 모두 가서 샤호우 장군을 구해!')
        stage.unit(3).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(234).show()
        stage.say('&3\n네가 원하는 걸 못 얻게 할 거야!\n방화!')
        stage.setFires(True, [
            [
                8,
                9],
            [
                9,
                7]])
        stage.setFire(True, 9, 5)
        stage.setFire(True, 10, 4)
        stage.unit(33).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(235).show()
        stage.say('&33\n하하하.\n여러분, 빨리 곡식을 잡으세요!')
        stage.setFires(True, [
            [
                12,
                10],
            [
                13,
                8],
            [
                13,
                7]])
        stage.setFire(True, 12, 6)
        stage.say('&406\n음, 와......')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(406) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(407) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(408) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(409) }])
        stage.say('&11\n음음음음음!')
    elif sel == 2:
        stage.say('&1\n군대 전체가 적을 추격한다!\n돌격! 쫓아라!\n&11\n하지만 그 결과,\n보급팀이 따라올 수 없어!\n&14\n만약 이것이 공명의 전략이라면,\n매복이 있을 수도 있어......')
        stage.unit(1).setDir(stage.countDir(1, 14))
        stage.say('&1\n유비 매복 부대는 두려워할 게 없어!\n정말 매복이 있다면 내가 쫓아낼 거야!')
        stage.unit(1).setDir(stage.countDir(1, 34))
        stage.say('&1\n그건 잊어버려!\n전면 군대 추격!')
        stage.unit(0, 1).move(7, 16, 2)
        stage.unit(3, 1).move(7, 14, 2)
        stage.unit(4, 1).move(9, 14, 2)
        stage.unit(1, 1).move(9, 13, 2)
        stage.unit(5, 1).move(8, 12, 2)
        stage.unit(6, 1).move(10, 12, 2)
        stage.unit(2, 1).move(9, 11, 2)
        stage.unit(7, 1).move(9, 10, 2)
        stage.unit(8, 1).move(10, 10, 2)
        stage.unit(406).move(10, 9, 2)
        stage.unit(407).move(9, 8, 2)
        stage.unit(408).move(11, 8, 2)
        stage.unit(409).move(10, 7, 2)
        stage.say('&1\n조운 가지 말고 나랑 경쟁하자!"\n&34\n약한 놈을 죽이고 싶지 않아!')
        stage.unit(32).setDir(stage.countDir(32, 34))
        stage.say('&32\n쯔롱, 빨리 후퇴해! 서둘러!')
        stage.unit(32).move(6, 23, 2)
        stage.unit(258).move(6, 22, 2)
        stage.unit(34).move(7, 22, 2)
        stage.say('&1\n감히 나를 약하다고 부르다니!?\n어떻게 감히 나를 이렇게 속일 수 있어!\n절대 봐주지 않을 거야, 절대!')
        stage.unit(0, 1).move(6, 20, 2)
        stage.say('&14\n샤호우 장군님, 잠시만 기다려 주세요!\n&11\n아-아, 안 돼.')
        stage.unit(3, 1).move(6, 18, 2)
        stage.unit(4, 1).move(7, 17, 2)
        stage.unit(1, 1).move(7, 16, 2)
        stage.unit(5, 1).move(7, 15, 2)
        stage.unit(6, 1).move(8, 15, 2)
        stage.unit(2, 1).move(7, 14, 2)
        stage.unit(7, 1).move(8, 14, 2)
        stage.unit(8, 1).move(9, 14, 2)
        stage.unit(406).move(9, 12, 2)
        stage.unit(407).move(8, 11, 2)
        stage.unit(408).move(10, 11, 2)
        stage.unit(409).move(9, 10, 2)
        stage.say('&32\n자, 이제 때가 왔어.\n군대 전체가 추격을 시작했다!')
        stage.unit(32).setDir(stage.countDir(32, 1))
        stage.unit(34).setDir(stage.countDir(34, 1))
        stage.unit(258).setDir(stage.countDir(258, 1))
        stage.say('&34\n샤호우 장군님, 제 임무는 완료되었습니다.\n지금 만나자!\n&1\n임무?\n아, 설마!?')
        stage.unit(35).setDir(stage.countDir(35, 1))
        stage.unit(35).setAction(5)
        stage.say('&35\n좋아, 매복 공격 명령을 내라!')
        stage.unit(35).setAction(0)
        stage.unit(46).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(324).show()
        stage.unit(46).setAction(5)
        stage.say('&46\n좋아, 시간이야.\n불을 지르라! 불태워라! 불태워라!\n그리고 불을 이용해 조의 군대를 포위했다.')
        stage.unit(46).setAction(0)
        stage.setFires(True, [
            [
                9,
                22],
            [
                8,
                22],
            [
                8,
                21]])
        stage.setFires(True, [
            [
                7,
                19],
            [
                7,
                18],
            [
                8,
                18]])
        stage.setFires(True, [
            [
                8,
                16],
            [
                9,
                16],
            [
                10,
                16]])
        stage.setFires(True, [
            [
                9,
                15],
            [
                10,
                15]])
        stage.setFires(True, [
            [
                10,
                13],
            [
                11,
                13],
            [
                11,
                12]])
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(4, 1) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(8, 1) }])
        stage.say('&11\n음, 정말 함정이네요......\n하지만 적군의 진실은 이미 드러났다!\n모두 진정하세요!')
        stage.unit(45).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(327).show()
        stage.unit(45).setAction(6)
        stage.say('&45\n좋아, 불도 피우자.\n태워버려!')
        stage.unit(45).setAction(0)
        stage.setFires(True, [
            [
                5,
                21],
            [
                5,
                20],
            [
                4,
                20],
            [
                4,
                19]])
        stage.setFires(True, [
            [
                4,
                17],
            [
                5,
                17],
            [
                5,
                16],
            [
                5,
                15],
            [
                6,
                15]])
        stage.setFires(True, [
            [
                6,
                13],
            [
                7,
                13],
            [
                7,
                12],
            [
                7,
                11]])
        stage.unit(14).setAction(8)
        stage.say('&14\n무슨 일이 있었던 거야!?\n&1\n!!!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(3, 1) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(7, 1) }])
        stage.unit(14).setDir(0)
        stage.unit(1).setDir(0)
        stage.say('&14\n속았어!\n불에 맞을 줄은 몰랐어......\n&1\n진정해!\n당황하지 마세요!\n먼저 강 건너편으로 후퇴해!')
        stage.unit(3).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(234).show()
        stage.say('&3\n좋아, 탈출로를 막아!')
        stage.unit(33).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(235).show()
        stage.say('&33\n하하하!\n너희 뒤에 모든 결점이 있니!?')
        stage.say('&406\n와!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'unit': stage.unit(406) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(407) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(408) },
            {
                'hStatus': [
                    9],
                'unit': stage.unit(409) }])
        stage.unit(11).setDir(stage.countDir(11, 3))
        stage.say('&11\n흠, 우리 뒤에도 적이 있네.\n이거 큰일이야!\n&1\n아-아, 안 돼!\n이런 상황이 계속되면 탈출로가 봉쇄될 것이다.')
        stage.unit(1).setDir(stage.countDir(1, 35))
        stage.say('&1\n그런데, 산적을 잡으려면 먼저 왕을 잡아야 해.\n한 번에 공명 죽여!')
        stage.unit(35).heightLight()
        stage.unit(1).setDir(0)
        stage.say('&1\n그렇긴 해도, 이제 후퇴할 때입니다.\n이대로 계속되면 완전한 멸망으로 이어질 것입니다,\n손실은 최소화되어야 합니다.')
        vars[2] = 1
    stage.unit(32).setAI(1)
    stage.unit(34).setAI(1)
    stage.unit(258).setAI(1)
    stage.setWinCondition('승리 조건\n1. 하후돈 북쪽 끝에 도달합니다.\n2. 제갈량 격퇴.\n\n패배 조건\n1. 하후돈 사망.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('하후돈 도망쳐!')
    stage.unit(1).heightLight()
    stage.heightLight(8, 0, 11, 1)
    stage.startOper()
    vars[525] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and not vars[50] and stage.round() >= 1 and stage.unitStateTest(35, 7, 80, 1):
        stage.resumeCtrl()
        stage.unit(35).setAction(5)
        stage.say('&35\n우리의 목표는 달성되었습니다,\n여기 더 머무르는 건 의미가 없어.\n후퇴.')
        stage.unit(35).setAction(0)
        vars[50] = 1
        if not vars[53]:
            stage.say('&32\n이제 후퇴할 시간이다.\n전군을 후퇴시켜라!')
            vars[53] = 1
        if not vars[54]:
            stage.say('&34\n오늘은 여기까지입니다.\n조운 물러났다.')
            vars[54] = 1
        if not vars[55]:
            stage.say('&3\n또한 상당한 양의 군수품도 가져갔다.\n이제 물러날 때입니다.\n좋아, 군대 전체가 후퇴하고 있어.')
            vars[55] = 1
        if not vars[56]:
            stage.say('&33\n쳇, 살인이 충분히 만족스럽지 않았던 것 같아.\n진심이야.')
            vars[56] = 1
        stage.setRectUnitHide(0, 0, 19, 31, 2)
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 13, 28):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[30] and stage.isInRect(1, 8, 0, 11, 1):
        stage.resumeCtrl()
        stage.say('&1\n쉭...... 드디어 위험에서 벗어났다.\n증오스러운 공명, 정말 무서운 녀석이었다.\n하지만 이 원한은 꼭 ......')
        stage.unit(1).setAction(5)
        stage.say('&1\n전군을 후퇴시켜라!\n서둘러!')
        stage.unit(1).setAction(0)
        stage.setRectUnitHide(0, 0, 19, 31, 4)
        vars[30] = 1
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[625] = 1
        return True
    if not vars[40] and stage.isNear(1, 35, True):
        stage.unit(35).setDir(stage.countDir(35, 1))
        stage.unit(1).setDir(stage.countDir(1, 35))
        stage.say("&35\n당신이 조나라 군대의 유명한 장군, '눈먼 샤호우' 맞죠?\n당신의 명성과 소문은 오래전부터 들었습니다.\n&35\n저는 제갈량이고, 공명 스타일을 가지고 있습니다.\n&35\n이제 나는 유비의 전략가다.\n&35\n이제부터는 자주 교류해야 할 거야,\n먼저 장군님께 인사드리겠습니다.\n&1\n젠장! 감히 나를 속이냐,\n후회하게 만들 거야.\n&35\n하하하.\n소문대로,\n장군은 조급하다......")
        vars[40] = 1
    if not vars[41] and stage.isNear(1, 32, True):
        stage.unit(1).setDir(stage.countDir(1, 32))
        stage.unit(32).setDir(stage.countDir(32, 1))
        stage.say('&1\n내가 네 목을 베면,\n그렇게 하면 이 실패를 만회할 수 있습니다.\n&32\n아직 해야 할 일이 많아요.\n너랑 시간 낭비할 시간이 없어.')
        vars[41] = 1
    if not vars[42] and stage.isNear(1, 3, True):
        stage.unit(3).setDir(stage.countDir(3, 1))
        stage.unit(1).setDir(stage.countDir(1, 3))
        stage.say('&3\n샤호우 장군.\n전장에서는 칼과 칼날이 무자비하다,\n목숨을 내놓아!\n&1\n전장에서 죽는 것은 장군의 바람이다.\n하지만 아직 여기서 죽을 생각은 없어.\n반드시 포위를 돌파할 거야!')
        vars[42] = 1
    if not vars[43] and stage.isNear(1, 33, True):
        stage.unit(33).setDir(stage.countDir(33, 1))
        stage.unit(1).setDir(stage.countDir(1, 33))
        stage.say('&33\n이봐, 이봐, 이거 나랑 해결해!\n&1\n흠, 이 순간이 아니었다면,\n저도 정말 ............')
        vars[43] = 1
    if not vars[44] and stage.isNear(11, 3, True):
        stage.unit(3).setDir(stage.countDir(3, 11))
        stage.unit(11).setDir(stage.countDir(11, 3))
        stage.say('&3\n이전장군, 죽을 준비를 하십시오.\n&11\n응...... 관 장군이야!\n상대가 너무 강력했다; 상황이 좋지 않았다.')
        vars[44] = 1
    if not vars[45] and stage.isNear(11, 33, True):
        stage.unit(33).setDir(stage.countDir(33, 11))
        stage.unit(11).setDir(stage.countDir(11, 33))
        stage.say('&33\n하하하하!\n조의 군대는 특별할 게 없었다.\n&11\n음, 음, ......\n그건 네 계획이 아니야,\n자랑할 게 뭐가 있겠어!')
        vars[45] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.resumeCtrl()
        stage.unit(35).setAction(5)
        stage.say('&35\n조의 군대는 정말 강력하다.\n&35\n하지만 목표가 달성되었으니 후퇴는 괜찮았다.\n안녕!')
        stage.unit(35).setAction(0)
        stage.unit(35).hide(1)
        if not vars[53]:
            stage.say('&32\n이제 후퇴할 시간이다.\n전군을 후퇴시켜라!')
            vars[53] = 1
        if not vars[54]:
            stage.say('&34\n오늘은 여기까지입니다.\n조운 물러났다.')
            vars[54] = 1
        if not vars[55]:
            stage.say('&3\n또한 상당한 양의 군수품도 가져갔다.\n이제 물러날 때입니다.\n좋아, 군대 전체가 후퇴하고 있어.')
            vars[55] = 1
        if not vars[56]:
            stage.say('&33\n쳇, 죽이는 게 충분히 만족스럽지 않은 것 같아.\n진심이야.')
            vars[56] = 1
        stage.setRectUnitHide(0, 0, 19, 31, 2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(41, 7, 0, 2):
        stage.say('&41\n이렇게 부끄러울 줄은 몰랐어요......\n이 원한은 언젠가 반드시 ...... 될 것이다')
        stage.unit(41).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(42, 7, 0, 2):
        stage.say('&42\n음!\n36가지 전략 중에서 후퇴가 가장 좋습니다.\n후퇴, 후퇴, 서둘러!')
        stage.unit(42).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n이제는 후퇴하는 것이 문제가 되지 않습니다.\n그럼 한 걸음 나아가자.')
        stage.unit(32).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n젠장, 정말 미운 심하군!\n일단 후퇴하자!')
        stage.unit(34).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n적이 이미 심각한 피해를 입었으니,\n지금이 철수할 때야.\n후퇴!')
        stage.unit(3).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n세 번째 할아버지께 이걸 기억해 주세요!\n이번엔 널 보내줄게.')
        stage.unit(33).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(46, 7, 0, 2):
        stage.say('&46\n아버지, 관평이 후퇴했습니다.\n조조, 다시 만날 때까지.')
        stage.unit(46).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(45, 7, 0, 2):
        stage.say('&45\n쓰러졌어!\n흠, 후퇴!')
        stage.unit(45).hide(1)
        vars[58] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.talk(11, 186, '하후돈 장군님, 적이 후퇴했습니다.')
        stage.say('&1\n하지만 군수품 대부분도 잃었고,\n적을 더 추격하는 것은 불가능했다.\n&1\n그래서 그들은 먼저 후퇴할 수밖에 없었다.\n겉보기에는 아군이 이긴 것처럼 보이지만, 실제로는 실패입니다.\n지금 주군 분노할 거야.')
        stage.reward(0, [
            94,
            -1])
        stage.end()
        vars[0] = 1
        vars[625] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
