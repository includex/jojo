# Source Generated with Decompyle++
# File: R_23.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 28)
    stage.showUnits([
        [
            181,
            58,
            70,
            1],
        [
            8,
            58,
            16,
            2]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.delay(3)
    stage.setEventName('목표는 is원담')
    stage.setStageName('저택 앞에 원상 있어')
    stage.unit(8).move(58, 54, 2)
    stage.delay(3)
    stage.unit(8).setAction(0, 3)
    stage.say('&8\n아, 여기가 예시의 저택 맞죠?\n정말 인상적이야.\n&8\n흠...... 안을 확인하고 있어?')
    stage.unit(181).move(58, 64, 0)
    stage.say('&181\n멈춰, 출입 금지!')
    stage.unit(8).setAction(0, 2)
    stage.say('&8\n뭐라고?\n&181\n이것은 조 재상의 명령이었다,\n아무도 들어올 수 없어!\n&8\n넌 나를 몰라!\n나는 조비, 조조의 정통 아들이다!\n&181\n이 .......\n&8\n너, 아무것도 아닌 사람이 날 막고 싶어?\n지금 비키지 않으면 널 베어버릴 거야!\n&181\nI ...... I ......')
    stage.unit(8).move(43, 54, 3)
    stage.say('&181\n......')
    stage.effectSound(205, 255)
    stage.clsUnit()
    stage.loadBg(2, 28)
    stage.showUnit(181, 58, 70, 1)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('그날 저녁', 3)
    stage.showUnits([
        [
            0,
            58,
            16,
            2],
        [
            22,
            58,
            6,
            2]])
    stage.unitsMove([
        [
            stage.unit(0),
            58,
            54,
            2],
        [
            stage.unit(22),
            58,
            44,
            2]])
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(0, 0)
    stage.say('&181\n그래서 주군였다!')
    stage.say('&0\n음, 수고하셨습니다.')
    stage.delay(5)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n응?')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n어떻게? 누군가 들어간 것 같아!')
    model.setFace(2)
    stage.unit(0).setAction(2)
    stage.say('&0\n아무도 들어오지 못하게 한다고 했잖아,\n잊으셨나요!!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n그래! 잊지 않았어.......\n&181\n조비의 후계자가 들어갔다......')
    stage.unit(0).setAction(2)
    stage.say('&0\n뭐라고!?')
    stage.effectSound(202, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('처벌 조비\n용서해 조비', 0)
    if sel == 1:
        vars[308] = 1
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.unit(0).setAction(0)
        stage.say('&0\n이 아이...... 꽤 대담하네!')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(2)
        stage.say('봉효, 당장 자환을 체포해라. 군법에 따라 처분할 것이다!!')
        stage.unit(22).setAction(6)
        stage.say('&22\n잠깐, 주군.\n&22\n예시는 얼마 전 점령당한 참이었다,\n아마 누군가 안에 숨어 있을지도 몰라.\n&22\n정당한 상속인으로서, 조비\n박물관에 입장하기 전에 점검주군 이루어집니다.\n과장이 아니에요.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&0\n흠......\n&0\n맞아요...... 좋아요.\n이 문제는 더 이상 다루지 않을 것입니다.\n이전 명령을 철회하세요.')
        stage.unit(22).setAction(6)
        stage.say('&22\n네.')
        stage.unit(0).setAction(0, 1)
        stage.say('봉효......')
        stage.unit(22).setAction(0)
        stage.say('&22\n그래?\n&0\n원소의 실수를 반복하고 싶지 않아요,\n그냥 적법한 아들에게 특권을 부여하면 됩니다.\n&22\n이 ............')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('하하하.\n봉효, 들어가세요!')
        stage.unit(22).setAction(6)
        stage.say('&22\n네, 네.')
    elif sel == 2:
        vars[308] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n잊어버려.\n&181\n응?\n&0\n예 시티는 방금 함락되었고,\n그곳에는 수상한 인물들이 많이 숨어 있을 수 있습니다.\n&0\n정자인 자환으로서,\n들어가기 전에 시설을 점검했어,\n과장이 아닙니다.')
        stage.unit(0).setAction(0, 0)
        stage.say('봉효.')
        stage.unit(22).setAction(6)
        stage.say('&22\n네, 저도 그렇게 생각해요.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('하하하.\n봉효, 들어가세요!')
        stage.unit(22).setAction(6)
        stage.say('&22\n네, 네.')
    model.setFace(0)
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            0,
            53,
            28,
            2],
        [
            1,
            68,
            48,
            3],
        [
            15,
            68,
            54,
            3],
        [
            8,
            68,
            60,
            3],
        [
            13,
            68,
            66,
            3],
        [
            2,
            68,
            72,
            3],
        [
            20,
            38,
            48,
            1],
        [
            22,
            38,
            54,
            1],
        [
            24,
            38,
            60,
            1],
        [
            21,
            38,
            66,
            1],
        [
            23,
            38,
            72,
            1],
        [
            192,
            53,
            48]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('원담 예시가 함락되었다는 소식을 듣고 사절단을 보내 맞조조.')
    stage.setStageName('예 @ 임시 총리 관저')
    stage.say('&192\n우리 가족주군 총리의 승리를 축하합니다.\n&0\n너무 예의 바르셔서 정말 미안해요.\n&0\n그런데 사절이야.\n병력을 함께 보내는 것이 원담 아니었나?\n왜 군대를 보내지 않았을까?\n&192\n응? 이거...... 이거......')
    stage.unit(192).setAction(6)
    stage.say('&192\n현재 이 지역의 공공 보안이 매우 열악하기 때문입니다......\n따라서 총리의 전투를 돕기 위한 인원은 파견되지 않았다......')
    stage.unit(192).setAction(0)
    stage.say('&0\n네, 그게 맞는 것 같아요.')
    stage.unit(0).setAction(3)
    stage.say('&0\n그래서.........')
    stage.unit(0).setAction(0)
    stage.say('&0\n나는 그곳에 군대를 보내고 싶원담,\n그를 위해 무법자들을 제거하라.')
    stage.unit(192).setAction(6)
    stage.say('&192\n응?\n...... ...... 총리를 더 괴롭힐 필요 없어.\n&0\n그렇게 예의 바르게 굴 필요 없어,\n이 악명 높은 법 위반자들의 평판,\n조는 이 이야기를 오래전부터 들어왔다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n그들은 원담, 궈투, 신평이다.')
    stage.unit(192).setAction(0)
    stage.say('&192\n뭐라고 했어......\n총리가 농담하는 거지......!?')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n농담할 시간 없어......')
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n공범도 똑같이 참수당해 마땅해!!')
    stage.unit(192).setAction(3)
    stage.say('&192\n어!?')
    stage.unit(192).setAction(0)
    stage.say('&0\n멍청이들!\n내가 원담 같은 바보에게 속을 것 같아?\n나를 이용해 권력을 다지려고? 꿈도 꾸지 마!\n&0\n들어라! 돌아가서 원담에게 전해, 목숨을 끊고 죽음을 기다리라고 해!!')
    stage.unit(0).setAction(0)
    stage.say('&0\n네 목을 베길 원해,\n그들을 거기서 원담 보내야 할까?')
    stage.unit(192).setAction(6)
    stage.say('&192\n아!\n총리님, 살려 주세요!')
    stage.unit(0).setAction(2)
    stage.say('&0\n그럼 빨리 돌아와서 전해!\n안 그러면 네 목을 잘라서 돌려보낼 거야!\n나를 얕보지 말라고 전해줘, 조맹덕!!\n&192\n네...... 네!')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(192).move(53, 98, 2)
    stage.unit(192).hide()
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.unit(1).setAction(0, 0)
    stage.say('&1\n그 남자는 너무 무서워서 울 것 같았어요.\n&1\n나는 오랫동안 이 아이원담 기대했어,\n그들은 함께 싸우기 위해 병력을 보내지 않을 것이다.\n맹덕, 넌 정말 대단해.\n&0\n사절의 내면의 공황,\n또한 원담 감염시킬 수 있습니다.\n이것도 하나의 전략입니다.\n&1\n네, 네.')
    stage.unit(1).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n하하하.\n정말 원담 표정을 보고 싶어!\n좋아! 난피로 행진한다!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(17)
    stage.say('&1\n네!')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(22).setAction(4)
    stage.say('&22\n흠, 기침, 기침.........')
    stage.unit(0).setAction(3)
    stage.say('봉효!')
    stage.unit(24).setAction(0, 0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n펑샤오!')
    stage.unit(0).setAction(0)
    stage.say('&0\n무슨 일이야, 펑샤오?')
    stage.unit(22).setAction(0)
    stage.say('&22\n아, 별일 아니야......\n가벼운 감기일 뿐이고, 곧 나을 거예요.\n걱정하지 마세요.\n&0\n………\n(지난 전투 때, 그는 기침을 멈출 수 없었다,\n그럴 수도 있겠......... )')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 308, 45)
    stage.showHead(115, 372, 45)
    stage.showHead(113, 460, 28)
    stage.delay(8)
    stage.head(115).move(390, 30)
    stage.delay(8)
    stage.head(115).hide()
    stage.delay(5)
    stage.bottomTxt('원상가 직책을 버리고 예시로 도망친 후,', False, False, False)
    stage.delay(5)
    stage.head(0).move(340, 45)
    stage.delay(5)
    stage.bottomTxt('조조 이곳을 점령했어,', True, True, False)
    stage.delay(8)
    stage.head(0).move(396, 45)
    stage.delay(5)
    stage.bottomTxt('그리고 원담가 위치한 난피를 계속 공격했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 42)
    stage.showUnits([
        [
            113,
            54,
            70],
        [
            103,
            35,
            56,
            1],
        [
            112,
            71,
            56,
            3],
        [
            192,
            53,
            56,
            2,
            6]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.setStageName('난피 원담 저택')
    stage.delay(3)
    stage.unit(113).setAction(3)
    stage.say('&113\n뭐라고...... 뭐라고!?\n조조 나를 벌주고 싶어!')
    stage.say('&192\n...... ......\n그는 매우 분노한 표정이었다......')
    stage.unit(113).setAction(0)
    stage.say('&113\n응.........\n우리 계획이 드러난 걸까......\n&113\n궈투!!')
    stage.unit(103).setAction(6)
    stage.say('&103\n존재한다.')
    stage.unit(103).setAction(0)
    stage.delay(3)
    stage.unit(113).setAction(2)
    stage.say('&113\n이 어리석은 생각을 한 건 다 네 잘못이야,\n그래서 이렇게 된 거예요!!\n어떻게 할 계획이야!')
    stage.unit(113).setAction(0)
    stage.say('&103\n...... 하지만 ......')
    stage.unit(113).setAction(2)
    stage.say('&113\n닥쳐! 네 설명 듣기 싫어!\n그를 끌고 나와 즉시 목을 베어라!')
    stage.unit(112).setAction(0, 2)
    stage.say('&112\n잠시만 기다려 주세요.')
    stage.unit(113).setAction(0)
    stage.say('&113\n무슨 일이야? 신핑.')
    stage.unit(112).setAction(6)
    stage.say('&112\n주군,\n이제, 조조를 무찌르는 것 외에도,\n우리에겐 탈출구가 없어.\n&112\n만약 이 순간 곽투가 죽는다면,\n그게 오히려 조조 행복하게 해.')
    stage.unit(113).setAction(0, 1)
    stage.say('&113\n무슨 ......?')
    stage.unit(113).setAction(0, 0)
    stage.say('&113\n응...... 맞아.\n젠장, 방어를 강화해!\n조조 맞설 준비를 해!\n&103\n네.\n&112\n네.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            6,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            24,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('난피 외곽, 조조군 본군 진영')
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n좋아! 한 번에 원담 쓸어버려!')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 13, [
        22,
        8])
    gvars[4076] = 0
    gvars[4057] = 23
    stage.setBattlePos([
        [
            2,
            16],
        [
            3,
            17],
        [
            6,
            16],
        [
            3,
            13],
        [
            5,
            15],
        [
            4,
            14],
        [
            5,
            17],
        [
            2,
            14],
        [
            4,
            16],
        [
            3,
            15],
        [
            6,
            18],
        [
            1,
            15],
        [
            4,
            18],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n원담This 애는 항상 우리를 과소평가해,\n맹덕, 제발 제가 선봉이 되게 해주세요.')
    if stage.unitClickTest(20):
        stage.say('&20\n난피 도시는 매우 광대합니다.\n패배에 대해 마음의 준비를 하는 것이 가장 좋습니다.')
    if stage.unitClickTest(22):
        stage.say('&22\n마지막 전투 이후,\n우리는 모두 조비 후계자에게 감탄했다,\n주군처럼 무공 용맹을 지닌 것.\n&0\n음, 이 아이는 아직 경험이 좀 필요해.')
    if stage.unitClickTest(6):
        stage.say('&6\n포위전 중에,\n우리의 장거리 공격 부대는 매우 효과적입니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n원담 이 사람이 별로 똑똑해 보이지 않는다고 들었어요.\n&0\n네.\n&15\n코 다리를 부러뜨리는 걸 봐.')
    if stage.unitClickTest(24):
        stage.say('&24\n원담 캠프에는 포병 수레와 기타 대규모 병력이 배치되어 있었다.\n방어는 매우 견고했다.\n&0\n포병 호송......?\n그건 좀 골칫거리였어.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
