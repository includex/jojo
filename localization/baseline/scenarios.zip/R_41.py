# Source Generated with Decompyle++
# File: R_41.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    stage.clsUnit()
    stage.bgSound(0)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 100, 120)
    stage.showHead(35, 36, 120)
    stage.bottomTxt('쑤 군대', False, False, False)
    stage.delay(5)
    stage.head(35).move(9, 181)
    stage.delay(5)
    stage.bottomTxt('그들은 청두에 있는 마지막 요새로 도망쳤다.', True, False, True)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            8,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setEventName('유비 확립된 국가')
    stage.setStageName('청두 외곽 조조군 본진')
    if vars[740]:
        stage.say('&0\n드디어 여기까지 왔어요.')
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n청두가 바로 네 앞에 있어,\n한 번에 끝내자.')
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n물론 그게 틀린 건 아니지만,\nHowever아군 아직 행군할 충분한 보급품을 확보하지 못했다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(0, 2)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n네.\n짧고 결정적인 전투를 벌일 수밖에 없었다.')
        stage.unit(21).setAction(0)
        stage.say('&0\n원양, 네가 선봉을 맡아.')
        stage.unit(1).setAction(0, 2)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n아, 내게 맡겨.')
        stage.unit(1).setAction(0)
        stage.say('&0\n쯔환, 너도 전투에 나가야 해.\n나는 이미 조장을 전투에 보냈다.')
        stage.unit(8).setAction(0, 2)
        stage.delay(3)
        stage.say('&8\n네.')
        stage.unit(0).setAction(17)
        stage.say('&0\n슈 왕국은 유비가 혼자 힘으로 세웠다.\n존경을 표하자면,\n우리 조씨는 직접 슈를 무너뜨려야 해.')
        stage.unit(0).setAction(0)
        stage.unit(1).setAction(0, 1)
        stage.unit(8).setAction(0, 1)
        stage.unit(20).setAction(0, 3)
        stage.unit(19).setAction(0, 3)
        stage.unit(21).setAction(0, 3)
    if not vars[740]:
        stage.say('&0\n드디어 여기까지 왔어요.')
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n군대가 억지로 행군하기 때문일 뿐이다,\n대부분의 병력은 뒤처졌다.')
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n그럼에도 불구하고 충분한 식량을 확보하는 데 성공했다......')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(0, 2)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n이 전투는 길고 고된 싸움일 것이다,\n우리는 절대 조급해해서는 안 됩니다.')
        stage.unit(21).setAction(0)
        stage.say('&0\n흠.\n원양, 당신은 포워드로 플레이합니다.')
        stage.unit(1).setAction(0, 2)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n아, 내게 맡겨.')
        stage.unit(1).setAction(0)
        stage.say('&0\n쯔환, 너도 전투에 나가야 해.\n나는 이미 조장을 전투에 보냈다.')
        stage.unit(8).setAction(0, 2)
        stage.say('&8\n네.')
        stage.unit(0).setAction(17)
        stage.say('&0\n슈 왕국은 유비가 혼자 힘으로 세웠다.\n존경을 표하자면,\n우리 조씨가 직접 수씨를 무너뜨릴 거야.')
        stage.unit(0).setAction(0)
        stage.unit(1).setAction(0, 1)
        stage.unit(8).setAction(0, 1)
        stage.unit(20).setAction(0, 3)
        stage.unit(19).setAction(0, 3)
        stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    if vars[740]:
        gvars[4076] = 0
        gvars[4057] = 41
        stage.setJoinBattle(1, 15, [
            1,
            4,
            5,
            12,
            8])
        stage.setBattlePos([
            [
                19,
                3],
            [
                20,
                3],
            [
                18,
                3],
            [
                21,
                3],
            [
                17,
                3],
            [
                19,
                2],
            [
                20,
                2],
            [
                18,
                2],
            [
                21,
                2],
            [
                17,
                2],
            [
                19,
                1],
            [
                20,
                1],
            [
                18,
                1],
            [
                21,
                1],
            [
                17,
                1]])
    if not vars[740]:
        gvars[4076] = 0
        gvars[4057] = 41
        stage.setJoinBattle(1, 13, [
            1,
            4,
            5,
            12,
            8])
        stage.setBattlePos([
            [
                19,
                3],
            [
                20,
                3],
            [
                18,
                3],
            [
                21,
                3],
            [
                17,
                3],
            [
                19,
                2],
            [
                20,
                2],
            [
                18,
                2],
            [
                21,
                2],
            [
                17,
                2],
            [
                19,
                1],
            [
                20,
                1],
            [
                18,
                1],
            [
                21,
                1],
            [
                17,
                1]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출격.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n...... 온 부족에게 싸우라고 명령할 수 있나?\n맹덕, 네 기분 이해해......')
    if stage.unitClickTest(20):
        stage.say('&20\n전장은 청두 전체 도시가 될 것이다,\n이곳은 진정한 슈 왕국의 수도로서 명성을 얻어야겠네요.\n&20\n내가 본 어떤 도시보다도 훨씬 컸다.')
    if stage.unitClickTest(19):
        if vars[740]:
            stage.say('&19\n우리가 소모전을 한다면,\n아군 보급품은 상대적으로 부족했다,\n이 부분주군 계속 주목해 주세요.')
        if not vars[740]:
            stage.say('&19\n소규모 병력이 도시를 공격한다면,\n많은 시간이 걸릴 거야,\n공격할 때는 조심하세요.')
    if stage.unitClickTest(21):
        stage.say('&21\n마지막 전투에서 그는 청룡옥을 얻었다,\n그 안에는 청룡의 힘이 숨어 있다.\n&0\n아쥬르 드래곤의 힘?\n&20\n아, 그러니까 번개를 소환하는 게 영리한 전략이구나?\n&21\n네.\n하지만 이 기술을 사용할 수 있는 사람은 오직 말을 타고 있는 전략가들뿐입니다.\n&0\n말을 타고 학자들과 전략을 세우는 것......\n그럼 장비를 사마의 주세요.')
    if stage.unitClickTest(8):
        stage.say('&0\n즈환, 이거 잘 이해해야 하지?\n너는 조씨의 장남이야,\n조씨 가문의 명예를 더럽히지 마라.\n&8\n네, 아버지.')
    if stage.unitClickTest(15):
        stage.say('&15\n제발 싸우게 해줘.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
