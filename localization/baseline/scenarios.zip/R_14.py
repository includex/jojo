# Source Generated with Decompyle++
# File: R_14.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 31)
    stage.showUnits([
        [
            119,
            5,
            54,
            1],
        [
            126,
            5,
            46,
            1],
        [
            2,
            5,
            50,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('여포 그리고 초선')
    stage.setStageName('쉬저우 외곽의 산길')
    stage.unit(2).move(15, 50, 1)
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(2),
            70,
            50,
            1],
        [
            stage.unit(119),
            60,
            54,
            1],
        [
            stage.unit(126),
            60,
            46,
            1]])
    stage.unit(126).setAction(0)
    stage.unit(119).setAction(0)
    stage.unit(2).setAction(0)
    stage.say('&126\n휘익, 휘익.\n주군, 추격자들을 따돌린 것 같조조.\n&119\n흠.......')
    stage.unit(126).setAction(0, 2)
    stage.say('&126\n먼저, 머물 곳을 찾아,\n다시 모이자.\n&119\n…… 샤피에 도착했다.\n샤피로 가자.')
    stage.unit(2).setAction(0, 2)
    stage.delay(5)
    stage.say('&126\n…… 알겠습니다.\n샤피에서 조조와 결정적인 전투를 벌이자.\n&119\n흠. (초선 샤피에서는 초선 죽을 수 없다. )')
    stage.unit(2).setAction(0, 1)
    stage.say('&2\n(내 인생이 정말 이렇게 끝나는 걸까?)\n이제부터 군사 장군의 정신으로,\n목숨을 걸고 싸워라. )')
    stage.unitsMove([
        [
            stage.unit(2),
            95,
            50,
            1],
        [
            stage.unit(119),
            85,
            54,
            1],
        [
            stage.unit(126),
            85,
            46,
            1]])
    stage.unit(2).hide()
    stage.unitsMove([
        [
            stage.unit(119),
            95,
            54,
            1],
        [
            stage.unit(126),
            95,
            46,
            1]])
    stage.unit(119).hide()
    stage.unit(126).hide()
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    '''샤피 초선 거주지'''
    stage.bgSound(17)
    stage.delay(3)
    stage.loadBg(2, 2)
    stage.showUnit(17, 53, 53, 1)
    stage.draw()
    stage.setStageName('샤피 초선 거주지')
    stage.showUnit(119, 53, 27, 2)
    stage.say('&119\n초선!')
    stage.unit(17).setAction(0, 0)
    stage.unit(119).move(53, 45, 2)
    stage.say('&17\n봉선.......\n&119\n초선.......')
    stage.unit(17).move(53, 57, 2)
    stage.say('&17\n난 다 알아,\n조나라 군대가 여기 공격하러 오는 건가?\n&119\n이미 알고 있......\n&17\n방금 천 경께 물어봤어.\n&119\n죄송합니다, .........,\n어쩌면 우리 모두 이 전쟁에서 죽을지도 몰라.\n&17\n…………….')
    if vars[302]:
        stage.unit(119).move(53, 47, 2)
        stage.say('&119\n초선! 지금 당장 여기서 도망쳐야 해.')
        stage.unit(17).setAction(0, 0)
        stage.say('&17\n응?')
        stage.unit(119).setAction(3, 2)
        stage.say('&119\n조조로 가자.\n&17\n조조......?')
        stage.unit(119).setAction(0, 2)
        stage.say('&119\n조조 정말 너를 좋아하는 것 같아,\n분명히 너를 후하게 대할 거야.')
        stage.unit(119).setAction(0, 0)
        stage.say('&119\n이 혼란스러운 세상에서 더 이상 살 수 없을 것 같아요.\n하지만 살아남아야 해.............')
        stage.delay(10)
        stage.unit(17).setAction(0, 1)
        stage.say('&17\n......봉선, 난 안 갈 거야.')
        stage.unit(119).setAction(0, 2)
        stage.say('&119\n왜!?')
        stage.unit(17).setAction(0, 0)
        stage.say('&17\n당신과 함께 싸우고 싶어요.')
    if not vars[302]:
        stage.delay(10)
        stage.unit(119).move(53, 47, 2)
        stage.say('&119\n초선, 당장 이 도시를 떠나.\n&119\n무슨 일이 있어도 그들은 살아남아야 했다.')
        stage.unit(119).setAction(3, 2)
        stage.say('&119\n지금 탈출할 기회를 이용하세요.\n살아남아야 해!')
        stage.unit(119).setAction(0, 2)
        stage.delay(10)
        stage.unit(17).setAction(0, 0)
        stage.say('&17\n......봉선, 난 안 갈 거야.\n&119\n뭐라고!?\n&17\n당신과 함께 싸우고 싶어요.')
        stage.delay(3)
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n봉선, 아직 진 게 아니야.\n&119\n초선...... 하지만 .......')
    stage.unit(17).setAction(0, 0)
    stage.delay(3)
    stage.unit(17).move(53, 48, 0)
    stage.say('&17\n너무 낙담한 채,\n전혀 너 같지 않아.')
    stage.unit(17).setAction(6, 0)
    stage.say('&17\n나는 봉선와 함께 있고 싶다,\n마지막 순간까지.\n&17\n다시는 나를 떠나라고 하지 말아 주세요.\n&119\n…… 좋아.')
    stage.unit(17).setAction(0, 0)
    stage.delay(5)
    stage.unit(119).move(53, 42, 0)
    stage.delay(3)
    stage.unit(119).setAction(0, 2)
    stage.say('&119\n내가 직접 보여줄게, 조조\n나는 하늘 아래에서 비할 데 없는 용기를 여포.\n&17\n네.')
    stage.unit(119).move(53, 27, 0)
    stage.unit(119).hide()
    stage.delay(3)
    stage.unit(17).setAction(0, 1)
    stage.say('&17\n......봉선, 고마워.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 414, 73)
    stage.showHead(119, 478, 113)
    stage.showHead(32, 414, 153)
    stage.bottomTxt('여포 조조와 유비 연합군에게 서저우에서 패배했다.', False, False, False)
    stage.delay(5)
    stage.head(119).move(546, 153)
    stage.delay(5)
    stage.bottomTxt('그는 패배하여 샤피로 도망쳤고, 그곳에서 도시를 굳건히 지켰다.', True, False, False)
    stage.delay(8)
    stage.head(32).move(482, 193)
    stage.head(0).move(482, 113)
    stage.delay(5)
    stage.bottomTxt('조조 여포가 숨을 돌릴 틈도 주지 않고 공격을 계속했다.', True, True, True)
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            6,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3],
        [
            32,
            49,
            52,
            2]])
    stage.draw()
    stage.setStageName('샤피 외곽, 조조군의 본군 진영')
    stage.say('&0\n현덕 군이 마침내 여포를 가뒀다.\n&32\n네.')
    stage.unit(0).setAction(3)
    stage.say('&0\n현덕 공, 저는 제 병력을 세 갈로로 나누어 나누려 합니다,\n그들은 각각 북문, 동문, 서문을 공격했다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n그러니 네 부대가 남문에서 공격하길 바란다.')
    stage.unit(32).setAction(6)
    stage.say('&32\n좋아.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(32).move(49, 16, 0)
    stage.unit(32).hide()
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n이번에는 반드시 여포을 제거해야 합니다.')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 14
    stage.setBattlePos([
        [
            13,
            1],
        [
            26,
            15],
        [
            1,
            18],
        [
            14,
            1],
        [
            26,
            16],
        [
            1,
            19],
        [
            12,
            2],
        [
            26,
            14],
        [
            1,
            17],
        [
            15,
            2],
        [
            26,
            17],
        [
            1,
            20],
        [
            13,
            2],
        [
            27,
            15],
        [
            0,
            18]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n하피 시에는 사방에 성문이 있습니다.\n&20\n또한, 북쪽에서 동쪽으로 흐르는 강이 있습니다.\n서쪽에서 남쪽으로 산과 숲이 이 지역을 둘러싸고 있습니다.')
    if stage.unitClickTest(22):
        stage.say('&22\n샤피 시 밖에는 눈이 많이 내린 것 같았다.\n&15\n오! 눈이 왔어!?\n&20\n쉬 장군님, 뭐가 기뻐할 게 있나요?\n&20\n눈 덮인 평원에서는 화염 전략이 더 이상 쓸모가 없습니다.\n&15\n그래요...... 정말요!? 쉽지 않을 거예요......\n&22\n눈이 아직도 내리는 것 같아,\n그 결과 도시 내에서는 사용할 수 없었습니다.\n&15\n…… 정말 감당하기 힘들어요.')
    if stage.unitClickTest(6):
        stage.say('&6\n상대가 여포이므로,\n완비해야 합니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n여포This 남자는 정말 다루기 힘들어요.')
    if stage.unitClickTest(1):
        if vars[302]:
            stage.say('&1\n그런데. 방금 샤피 성벽에서 봤어,\n여성 장군이 있는 것 같아.\n&0\n여성 장군?\n&1\n네, 꽤 예뻐요.\n하지만 전에 싸웠을 때, 여포\n하지만 저는 한 번도 본 적이 없습니다.\n&0\n(여성 장군...... 혹시 초선......일까요? )')
        if not vars[302]:
            stage.say('&1\n도시를 방어하는 것은 여포 스타일과는 조금 다르다.')
    if stage.unitClickTest(21):
        stage.say('&21\n그 장료는 재능 있는 장군이었고,\n여기서 죽는다면 정말 안타까울 거야.\n&0\n흠.')
    if stage.unitClickTest(32):
        stage.say('&32\n남문을 저에게 넘겨주세요.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
