# Source Generated with Decompyle++
# File: R_50.marshal (Python 3.9)


def scene0():
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.loadBg(2, 72)
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setEventName('모든 것은 동우를 위한 것이다')
    stage.setStageName('레드 클리프 외곽, 강가에 있습니다')
    stage.showUnit(76, 69, 95)
    stage.unit(76).move(69, 85, 0)
    stage.showUnit(77, 69, 95)
    stage.unitsMove([
        [
            stage.unit(76),
            69,
            45,
            0],
        [
            stage.unit(77),
            69,
            55,
            0]])
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n주군, 동우의 운명에는 아직 희망이 남아 있었다!\n낙담하지 마세요!')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(76).setAction(0, 2)
    stage.say('&76\n......주유.\n물어보고 싶은 게 있어.')
    stage.unit(77).setAction(6)
    stage.say('&77\n주군가 무슨 질문을 하는지 모르겠어요.')
    stage.unit(77).setAction(0)
    stage.say('&76\n우리 동우가 유비를 죽음으로 몰아넣었으니,\n그렇다면 슈에게는 우리가 적이다.\n&76\n그러나 붉은 절벽 전투에서는,\n쑤 군대는 우리 오나라를 위해 싸웠고,\n정확히 무슨 일이 있었던 거야?')
    stage.unit(77).setAction(6)
    stage.say('&77\n주군, 공진도 마음속으로 스스로에게 물었다,\n그래서 공진이 모든 걸 다 설명할 거야.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 1)
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\nfact주유 하오제의 마음은 이미 더럽혀졌다,\n그는 불의한 자들과 맹세를 했다.')
    stage.unit(77).setAction(0)
    stage.say('&76\n공명Really...... 역시 예상대로였다.')
    stage.unit(77).setAction(0, 0)
    stage.delay(3)
    stage.unit(77).setAction(6)
    stage.say('&77\n공명 주군을 배신하고 충성을 버린 배신자다,\n서에서 실질적인 권력을 잡기 위해서는,\n주군 죽일 계획이야.\n&76\n공명 해를 끼치려는 음모유비......?\n공명 진짜 ...... 정말 믿기지 않아!\n&77\n공명 더러운 날개를 휘저으며,\n공진이 지키는 집에 우아하게 도착했다.\n그는 유혹적인 미소를 지으며 거래를 제안했다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 1)
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n그가 말하길, 우리가 그를 죽이는 데 도움을 준다면 유비,\n그냥 징저우를 우리에게 넘겨라!\n&76\n흠.')
    stage.unit(77).setAction(0)
    stage.say('&77\n…… 공진은 그와 함께 이 맹세를 했다.')
    stage.unit(77).setAction(0, 0)
    stage.delay(3)
    stage.unit(77).setAction(6)
    stage.say('&77\n나중에 공진이 그를 성공적으로 제거유비 도왔다.\n&77\n그는 또한 보상으로 부유한 징저우를 받았다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 1)
    stage.say('&77\n하지만 저는 그런 주유 본 적이 없어요\n배신자와 반역자들조조 결국 우를 침공했다......')
    stage.unit(77).setAction(17)
    stage.say('&77\n공진이 한 모든 일은 오로지 동오를 위한 것이었다,\n그래서 동우가 세계를 통일할 수 있었던 것이다......')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 0)
    stage.delay(3)
    stage.unit(77).setAction(11)
    stage.say('&77\n제 잘못을 용서주군 부탁드립니다.\n&76\n…… 음, 어쩔 수 없이 이렇게 할 수밖에 없어.\n&76\n하지만 지금, 이 시점에서는,\n어떻게 해야 할까요?')
    stage.unit(77).setAction(0)
    stage.say('&77\n유쉬 고개가 전선에 있고,\n수도와 건예로 가는 주요 관문입니다.\n아군 이 위치에서 조조의 공격을 막아야 했다.')
    stage.unit(77).setAction(6)
    stage.say('&77\n주군, 조나라를 산적들의 짓밟음으로부터 지키기 위해,\n남은 병력을 여러 곳에서 모아 루쉬관으로 향할 것이다.\n&77\n주군 주유가 급히 돌아오기 전에 돌아올 수 있을 거야,\n루쉬 고개 방어를 강화하라고?\n&76\n좋아.\n트롤들을 재조직하라고 명령육손 거야.\n&77\nSo주유 일단 주군에게 작별 인사를 하자.\n&76\n음, 도와주셔서 감사합니다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).move(75, 55, 1)
    stage.unit(77).move(75, 10, 1)
    stage.unit(76).setAction(0, 0)
    stage.unit(77).hide()
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 288, 231)
    stage.showHead(76, 352, 231)
    stage.bottomTxt('오나라 군대는 붉은 절벽에서 패배했다.', False, False, False)
    stage.delay(5)
    stage.head(76).move(443, 214)
    stage.delay(5)
    stage.bottomTxt('그리고 루스코우로 후퇴했다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            15,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('레드 클리프: 조조군의 주요 진영')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('이번 작전에서 모두들 정말 잘했습니다. 수고했어요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 정말 아름다운 승리였습니다.\n강력한 동오 해군조차도,\n한동안 힘을 회복하는 것은 어려울 것이다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n주군, 이 좋은 기회를 놓치지 마,\n한 번에 동오를 완전히 없애자.')
    stage.unit(23).setAction(0)
    stage.say('&0\n흠.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n주군 이상은 아니야,\n중달 붉은 절벽의 우 진영에서 붉은 제단을 발견했다,\n정말 수상하다.')
    stage.unit(19).setAction(0)
    stage.say('&0\n흠.\n사마의, 이게 무슨 용도로 쓰인다고 생각해?')
    stage.unit(19).setAction(6)
    stage.say('&19\n부하들도 알 수 없었다.\n아마도 기도를 위한 것일지도 모른다......')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n이봐, 이봐, 저게 위기 상황에 처한 거 아닐까?\n신들의 축복을 빌 무언가?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 3)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n아니요, 장군님, 말씀하신 것이 잘못되었습니다.\n실제로 주유 같은 이들에게 어떻게 신성한 힘에 의존할 수 있겠는가?')
    stage.unit(19).setAction(0)
    stage.say('&0\n이제 끝없이 논쟁해도 소용없어.\n지금은 오나라 군대를 상대하는 데 전념해야 한다.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n네.')
    stage.unit(19).setAction(0)
    stage.say('&0\n문약, 오나라 군대는 지금 어디에 있지?')
    stage.unit(20).setAction(6)
    stage.say('&20\n그들은 이미 지안예 근처 루쉬 입으로 후퇴했다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n루쉬 입구...... 건예 근처인가요?\n그러면 오나라 군대는 필사적으로 싸울 것이다.')
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n그러나 맹덕보다 더 이상 하지 않는다,\n그렇다고 해서 앞으로 나아가는 걸 멈출 수는 없어.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n흠.\n좋아, 누수 입구로 가자!\n우리는 반드시 오나라 군대를 완전히 무찌르야 한다!')
    stage.unit(0).setAction(0)
    stage.unit(1).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.unit(23).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        19])
    gvars[4076] = 0
    gvars[4057] = 50
    stage.setBattlePos([
        [
            12,
            12],
        [
            13,
            12],
        [
            11,
            12],
        [
            14,
            12],
        [
            10,
            12],
        [
            15,
            12],
        [
            12,
            11],
        [
            13,
            11],
        [
            11,
            11],
        [
            14,
            11],
        [
            10,
            11],
        [
            15,
            11],
        [
            12,
            8],
        [
            13,
            8],
        [
            12,
            7]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n전투에 임하라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n전장은 여전히 양쯔강 건너편에서 벌어지고 있었다.')
    if stage.unitClickTest(19):
        stage.say('&19\n(그 제단은 아직도 사람들을 걱정하게 만든다,\n정확히 어떤 용도로 쓰이나요...... )\n&19\n(음, 일단 이 문제는 제쳐두자.)\n우리는 이 전투에 집중해야 한다. )')
    if stage.unitClickTest(23):
        stage.say('&23\n방금 전, 스파이가 군사 정보를 가져왔어,\n동오 진영에서는 허주유 육손의 흔적이 없었다.')
    if stage.unitClickTest(1):
        stage.say('&1\n이로 인해 오나라 군대는 준비할 시간이 없다,\n한 번에 계속 진행합시다.\n&0\n흠.')
    if stage.unitClickTest(3):
        stage.say('&3\n관은 해상이나 육상 전투에 방해받지 않습니다.\n내가 원하는 건 온 힘을 다해 적을 죽이는 것뿐이야.')
    if stage.unitClickTest(15):
        stage.say('&1\n그런데, 허저, 시 준비됐어?\n&15\n응?\n&1\n무슨 뜻이야, 아?\n맹덕 꽤 많은 걸 가르쳐줬어야 했잖아, 그렇지?\n정확히 무엇을 만들었나요?\n&15\n…… 나는 포기했다.\n&1\n포기하라고? 왜?\n&15\n이유...... 말하고 싶지 않아.\n&1\n아, 그렇구나......\n어쨌든, 대략 짐작할 수 있어요.\n&15\n흥, 절대 마음에 담지 않겠습니다.\n어쨌든, 나는 전사가 되기 위해 태어났어.\n&0\n요 요 요......')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
