# Source Generated with Decompyle++
# File: R_04.marshal (Python 3.9)


def scene0():
    if vars[1002]:
        stage.infoTransfer(18, '')
    if vars[303] and vars[703]:
        model.initLocalVar()
        stage.clsUnit()
        stage.setMenuVisible(False)
        stage.loadBg(2, 54)
        stage.showUnits([
            [
                101,
                54,
                35,
                2],
            [
                99,
                42,
                68,
                1],
            [
                136,
                42,
                60,
                1],
            [
                145,
                42,
                52,
                1],
            [
                161,
                67,
                52,
                3],
            [
                32,
                67,
                60,
                3],
            [
                181,
                54,
                60,
                0,
                11]])
        stage.draw()
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.setEventName('전략의 연쇄')
        stage.setStageName('뤄양: 연합군 본진')
        stage.unit(101).setAction(3)
        stage.say('&101\n뭐라고? 조조 군대가 군대의 매복에 걸렸동탁!\n참담한 패배!\n&181\n네.')
        stage.unit(101).setAction(0)
        stage.say('&101\n지금 조조 어디에 있지?\n&181\n남은 병력을 모아 낙양으로 돌아가고 있었다.')
        stage.say('&101\n흠.......')
        stage.unit(136).setAction(3)
        stage.say('&136\n헤헤, 그렇게 자랑했는데도 결국 졌네.')
        stage.unit(136).setAction(0)
        stage.delay(3)
        stage.unit(99).setAction(0, 0)
        stage.say('&99\n전투에서 졌다고? 정말?')
        stage.delay(3)
        stage.unit(136).setAction(0, 2)
        stage.say('&136\n물론, 그들은 동탁의 매복 부대에 의해 완전히 패배했다.')
        stage.unit(99).setAction(0, 1)
        stage.say('&99\n세상 사람들은 그렇게 생각하지 않아. 이 추구는 동탁,\n조조 분명히 유명해질 거야.')
        stage.unit(136).setAction(0, 1)
        stage.delay(5)
        stage.unit(32).setAction(6)
        stage.say('&32\n실제로 우리 연합군은 그들을 추격할 사람을 단 한 명조조 했다.')
        stage.unit(32).setAction(0)
        stage.say('&32\n조조의 행동이 사람들이 동탁에 동참하도록 영감을 주길 바랍니다.')
        stage.say('&101\n…………。')
        stage.effectSound(203, 255)
        stage.clsUnit()
    if vars[303] and not vars[703]:
        model.initLocalVar()
        stage.clsUnit()
        stage.setMenuVisible(False)
        stage.loadBg(2, 54)
        stage.showUnits([
            [
                101,
                54,
                37,
                2],
            [
                99,
                42,
                68,
                1],
            [
                136,
                42,
                60,
                1],
            [
                145,
                42,
                52,
                1],
            [
                161,
                67,
                52,
                3],
            [
                32,
                67,
                60,
                3],
            [
                181,
                54,
                60,
                0,
                11]])
        stage.draw()
        stage.setEventName('전략의 연쇄')
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.setStageName('뤄양: 연합군 본진')
        stage.delay(10)
        stage.unit(101).setAction(0, 0)
        stage.say('&101\n정말? 조조 못 잡았동탁?\n&181\n네.')
        stage.unit(101).setAction(0, 2)
        stage.say('&101\n지금 조조 어디에 있지?\n&181\n그들은 로양으로 돌아가기 위해 병력을 모으고 있었다.')
        stage.say('&101\n흠.......')
        stage.unit(136).setAction(3)
        stage.say('&136\n헤헤, 방금 전까지 군대를 보내려고 서두르고 있었잖아!\n정말 말도 안 돼.')
        stage.unit(136).setAction(0)
        stage.delay(3)
        stage.unit(99).setAction(0, 0)
        stage.say('&99\n말도 안 된다고?\n정말 그런가요?')
        stage.unit(136).setAction(0, 2)
        stage.say('&136\n물론이죠!\n그는 동탁 도망치게 놔뒀다.')
        stage.unit(99).setAction(0, 1)
        stage.say('&99\n그게 조조 진짜 목적은 아니었어.')
        stage.unit(136).setAction(0, 1)
        stage.delay(5)
        stage.unit(32).setAction(6)
        stage.say('&32\n정확히 그렇습니다.\n우리 연합군 중 조조명만이 추격을 위해 갔동탁,\n조조의 행동이 사람들이 동탁에 동참하도록 영감을 주길 바랍니다.')
        stage.unit(32).setAction(0)
        stage.say('&99\n그는 목표를 달성했다.')
        stage.say('&101\n……。')
        stage.effectSound(203, 255)
        stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            101,
            54,
            37,
            2],
        [
            99,
            42,
            68,
            1],
        [
            136,
            42,
            60,
            1],
        [
            145,
            42,
            52,
            1],
        [
            161,
            67,
            52,
            3],
        [
            32,
            67,
            60,
            3]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    if not vars[303]:
        stage.setEventName('전략의 연쇄')
    stage.info('다음 날, .......', 3)
    stage.setStageName('뤄양: 연합군 본진')
    if not vars[303]:
        stage.delay(10)
        stage.unit(101).setAction(0, 3)
        stage.delay(10)
        stage.unit(101).setAction(0, 1)
        stage.delay(10)
        stage.unit(101).setAction(0, 2)
        stage.say('&101\n어디 갔조조?')
        stage.unit(32).setAction(6)
        stage.say('&32\n그는 아침 일찍부터 어디에도 보이지 않았다.')
        stage.unit(32).setAction(0)
        stage.delay(3)
        stage.unit(101).setAction(2)
        stage.say('&101\n이 사람 무슨 꿍꿍이야?')
        stage.delay(3)
        stage.unit(101).setAction(0)
        stage.say('&101\n…… 잊어버려.\n동맹의 향후 계획에 대해 논의해 봅시다.')
    stage.unit(101).setAction(3)
    stage.say('&101\n좋은 전략이 있나요?')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).move(58, 37, 1)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n우리는 두 번이나 동탁군을 격파하고 낙양을 탈환했습니다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).move(54, 37, 3)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n게다가 천체 현상들은 동탁 인연이 다했다는 신호였다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n저는 동맹이 더 이상 의미가 없다고 생각합니다......')
    stage.unit(161).setAction(6)
    stage.say('&161\n벤추의 말에 깊이 공감합니다,\n결국 우리는 우리의 역할을 다했습니다.')
    stage.unit(161).setAction(0)
    stage.delay(3)
    stage.unit(145).setAction(6)
    stage.say('&145\n동탁을 없애지 못한 것은 분명 유감스러운 일입니다.\n하지만 그는 자신의 영역을 그냥 방치할 수 없었다.')
    stage.unit(145).setAction(0)
    stage.say('&32\n……。')
    stage.delay(5)
    stage.say('&101\n아무도 반대하지 않는 것 같네요,\n그럼 동맹은 해체될 거야.')
    stage.delay(5)
    stage.unit(99).setAction(0, 2)
    stage.say('&99\n이미 결정됐으니 먼저 물러나게 해주세요.')
    stage.unit(101).setAction(3)
    stage.say('&101\n아, 선 장군님. 작별 연회도 있네요......')
    stage.unit(101).setAction(0)
    stage.delay(5)
    stage.unit(99).setAction(0, 1)
    stage.say('&99\n몸이 좋지 않아 참여하지 않기로 했습니다.')
    stage.unit(136).setAction(0, 2)
    stage.say('&136\n흥! 이 사람은 너무 자연스럽다.')
    stage.unit(99).setAction(0, 0)
    stage.say('&99\n......원술, 조만간 네 목을 베어버릴 거야.')
    stage.unit(136).setAction(3)
    stage.say('&136\n응?')
    stage.unit(136).setAction(0)
    stage.delay(5)
    stage.unit(99).setAction(0, 2)
    stage.say('&99\n잠시 목에 머리를 기대세요. 흥!\n…… 그리고 자리를 떠났다.')
    stage.unit(99).move(42, 90, 2)
    stage.unit(136).setAction(0, 2)
    stage.unit(99).hide()
    if vars[303]:
        stage.delay(10)
        stage.showUnit(0, 54, 92)
        stage.say('&0\n원소Sir, 연합군을 해산시키고 싶다는 거야?"')
        stage.unit(145).setAction(0, 2)
        stage.unit(136).setAction(0, 2)
        stage.unit(143).setAction(0, 2)
        stage.unit(161).setAction(0, 2)
        stage.unit(32).setAction(0, 2)
        stage.delay(3)
        stage.unit(101).setAction(3)
        stage.say('&101\n아, 조조, 드디어 돌아왔구나.')
        stage.unit(101).setAction(0)
        stage.unit(0).move(54, 52, 0)
        stage.unit(0).setAction(0)
        stage.unit(145).setAction(0, 1)
        stage.unit(136).setAction(0, 1)
        stage.unit(161).setAction(0, 3)
        stage.unit(143).setAction(0, 3)
        stage.unit(32).setAction(0, 3)
        stage.delay(3)
        stage.say('&0\n하지만 원소 선생님, 동탁 아직 살아 있습니다.')
        stage.delay(5)
        stage.unit(101).setAction(2)
        stage.say('&101\n조조 전체 상황이 정리되었고 연합군은 해산되었다.')
        stage.unit(101).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 2)
        stage.delay(5)
        stage.say('여러 군벌들이 모두 동의했습니까?')
        stage.unit(145).setAction(6)
        stage.say('&145\n조조, 네 기분 이해해,\n하지만 우리는 우리 영역을 그냥 버릴 수 없어.')
        stage.unit(145).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 3)
        stage.delay(10)
        stage.unit(0).setAction(0, 2)
        stage.say('...알았다.')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n그럼, 이만 가볼게요.')
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 2)
        stage.delay(3)
        stage.unit(101).setAction(3)
        stage.say('&101\n응? 조조, 아직 송별회가 있어......')
        stage.unit(101).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n원소 선생님, 귀한 옥은 아직 동탁 손에 있습니다,\n이거 잊지 마.')
    if not vars[303]:
        stage.delay(10)
        stage.showUnit(0, 54, 92)
        stage.say('&0\n원소Sir, 연합군을 해산시키고 싶다는 거야?"')
        stage.unit(101).setAction(2)
        stage.say('&101\n조조, 도대체 무슨 일 하고 지냈어?')
        stage.unit(101).setAction(0)
        stage.unit(136).setAction(0, 1)
        stage.unit(0).move(54, 52, 0)
        stage.unit(0).setAction(0)
        stage.say('&0\n하지만 원소 선생님, 동탁 아직 살아 있습니다.')
        stage.delay(3)
        stage.unit(101).setAction(2)
        stage.say('&101\n조조, 전체 상황은 정리됐어! 연합군이 해산됐어.')
        stage.unit(101).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 2)
        stage.delay(5)
        stage.say('여러 군벌들이 모두 동의했습니까?')
        stage.unit(145).setAction(6)
        stage.say('&145\n조조, 네 기분 이해해,\n하지만 우리 영역을 무시할 수는 없어.')
        stage.unit(145).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 3)
        stage.delay(10)
        stage.unit(0).setAction(0, 2)
        stage.say('...알았다.')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n그럼, 이만 가볼게요.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 2)
        stage.delay(5)
        stage.unit(101).setAction(3)
        stage.say('&101\n응? 조조, 아직 송별회가 있어......')
        stage.unit(101).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n원소 선생님, 귀한 옥은 아직 동탁 손에 있습니다,\n이거 잊지 마.')
    stage.unit(0).move(54, 98, 2)
    stage.unit(0).hide()
    stage.delay(10)
    stage.say('&101\n바오위......?')
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n한나라가 쇠퇴했는데, 황제가 여전히 어떤 가치를 지녔던 걸까요?')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n한나라가 쇠퇴하고 있나요......?')
    stage.delay(5)
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.delay(5)
    stage.bgSound(-1)
    stage.loadBg(2, 3)
    stage.showUnit(153, 58, 70, 3, 1)
    stage.draw()
    stage.delay(3)
    stage.setStageName('장안, 왕윈의 저택')
    stage.showUnit(181, 30, 60, 1)
    stage.unit(181).move(38, 60, 1)
    stage.say('&181\n왕 경, 오늘 밤 총리님 관저에서 축하 연회가 열립니다.\n&181\n동탁Prime 장관님, 꼭 참석해 주세요."')
    stage.unit(153).move(58, 60, 3)
    stage.say('&153\n축하 연회? 뭘 축하?\n우리는 아직도 연합군과 싸우고 있지 않았나요?\n&181\n연합군은 며칠 전에 해산되어 총리가 축하해야 했습니다.')
    stage.bgSound(17)
    stage.delay(5)
    stage.unit(153).setAction(3)
    stage.say('&153\n뭐라고? 연합군이 해체됐다고!?')
    stage.unit(181).move(40, 60, 1)
    stage.say('&181\n꼭 참석해 주세요.')
    stage.unit(153).setAction(0)
    stage.delay(5)
    stage.unit(153).setAction(0, 1)
    stage.say('&153\n…… 어떻게 거절할 수 있겠어?\n총리님께 꼭 참석하겠다고 전해 주세요.\n&181\n네.')
    stage.unit(181).move(30, 60, 3)
    stage.unit(181).hide()
    stage.unit(153).move(58, 70, 2)
    stage.delay(3)
    stage.unit(153).setAction(1)
    stage.say('&153\n연합군 ...... 연합군은 해산.......')
    stage.unit(153).setAction(9)
    stage.say('&153\n우우우우...... 끝났어.......\n더 이상 동탁를 제거할 희망은 없습니다, 폐하.......')
    stage.delay(10)
    stage.showUnit(17, 30, 60, 1)
    stage.say('&17\n아버지.')
    stage.unit(17).move(58, 60, 2)
    stage.say('&17\n아버지 .......')
    stage.unit(153).setAction(1, 2)
    stage.delay(3)
    stage.unit(153).setAction(1, 0)
    stage.say('&153\n초선...... 솔직히 말할게...\n연합군은 해산.......')
    stage.unit(17).setAction(6, 2)
    stage.say('&17\n…… 딸은 그녀가 방금 한 말을 모두 들었다.\n…… 아버지, 조심하세요.')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n착한 딸.')
    stage.unit(153).setAction(0, 2)
    stage.say('&153\n하지만 이미 희망이 없었다.')
    stage.unit(17).setAction(0)
    stage.say('&17\n…… 아빠, 아직 희망이 있어요.')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n뭐라고? 그게 무슨 뜻이야?')
    stage.say('&17\n딸은 아이디어가 떠올랐다.')
    stage.unit(153).move(58, 68, 0)
    stage.say('&153\n...... 너? 무슨 생각이야......?')
    stage.unit(17).move(58, 56, 0)
    stage.say('&17\n그래서 .......')
    stage.delay(15)
    stage.unit(153).setAction(3, 0)
    stage.say('&153\n뭐라고?\n안 돼! 초선, 이건 절대 안 돼!')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n하지만 아버지에게는 다른 선택지가 없었다.')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n설령 세상을 위해서라도,\n당신도 .......')
    stage.unit(17).setAction(0, 0)
    stage.say('&17\n딸의 안전에 대해 걱정할 필요는 없으며, 항상 그런 것은 아닙니다\n세상을 위해, 그리고 당신에게 보답하기 위해서요...... 이거 내 대신 들어줘\n고아는 자신의 딸처럼 자라.')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n그래서 아버지를 위해서, 딸은 이 일을 해야 했다.')
    stage.unit(153).setAction(6, 0)
    stage.say('&153\n아버지께서 미안하십니다, 초선.......')
    stage.unit(153).setAction(0, 0)
    stage.unit(17).move(58, 60, 2)
    stage.delay(5)
    stage.unit(17).setAction(6, 2)
    stage.say('&17\n이렇게 하죠, 아버지.......')
    stage.unit(17).move(30, 60, 3)
    stage.unit(17).hide()
    stage.unit(153).setAction(0, 3)
    stage.delay(3)
    stage.unit(153).move(58, 70, 2)
    stage.delay(6)
    stage.unit(153).setAction(1, 2)
    stage.delay(3)
    stage.unit(153).setAction(9, 2)
    stage.say('&153\n......초선.')
    stage.info('초선의 계획은 먼저 여포와 결혼 약혼을 주선하는 것이었다,\n그리고 자신을 동탁에게 내어주며 여포을 도발했다,\n자신의 손으로 동탁를 죽이는 것.')
    stage.info("그녀의 열여덟 살 딸은 양아버지에게 보답하기 위해,\n그는 의로움을 위해 자신을 희생할 각오가 되어 있었고, 후대들은 이를 '연계 전략'이라 부른다.")
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 3)
    stage.showUnits([
        [
            153,
            58,
            70],
        [
            119,
            58,
            60,
            2]])
    stage.delay(5)
    stage.draw()
    stage.setStageName('장안, 왕윈의 저택')
    stage.say('&119\n왕 경, 저는 지금 결혼할 능력이 없습니다.......')
    stage.unit(153).setAction(3)
    stage.say('&153\n장군님, 그런 말 하지 마세요,\n내 작은 딸이 한 번 장군님 외에는 아무와도 결혼하지 않겠다고 말한 적이 있다.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(153).move(58, 68, 0)
    stage.say('&153\n웃지 말고 한 번만 만나 봐.\n&119\n좋아, 왕 경이 그렇게 말했으니 .......')
    stage.unit(153).setAction(3)
    stage.say('&153\n오, 동의했구나! 좋네.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(0, 3)
    stage.say('&153\n초선,초선.')
    stage.delay(8)
    stage.showUnit(17, 30, 60, 1)
    stage.say('&17\n아빠, 온다.')
    stage.unit(119).setAction(0, 3)
    stage.delay(3)
    stage.unit(17).move(50, 60, 1)
    stage.unit(119).setAction(3, 3)
    stage.say('&119\n오?')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n이건 내 딸 초선야, 어때?')
    stage.unit(119).setAction(0, 3)
    stage.say('&119\n이건 ...... 이건 너무 ...... 정말 아름다워.......')
    stage.unit(17).setAction(6, 1)
    stage.say('&17\n셰 장군이 호의를 베푼다.')
    stage.unit(119).move(56, 60, 3)
    stage.say('&119\n아니...... 정말 아름답다.......')
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 40)
    stage.showUnits([
        [
            127,
            58,
            60,
            3],
        [
            17,
            55,
            60,
            1]])
    stage.draw()
    stage.setStageName('장안동탁 현')
    stage.say('&127\n초선, 너 정말 아름다워.\n&17\n총리가 또 나를 조롱했어.\n&127\n하하하.')
    stage.showUnit(119, 58, 31, 2)
    stage.say('&119\n대부님, 저를 부르셨나요?')
    stage.unit(127).setAction(0, 0)
    stage.say('&127\n아, 여포.')
    stage.unit(119).setAction(3)
    stage.say('&119\n밍크......초선 어떻게 그럴 수 있지!?')
    stage.unit(119).setAction(2)
    stage.say('&119\n......동탁, 너!!')
    stage.clsUnit()
    stage.loadBg(0, 9)
    stage.draw()
    stage.info("왕윤의 '계획의 연쇄'가 마침내 성공했고, 피해자가 동탁\n여포 그들을 죽였고, 복수를 위해 여포동탁\n이각. 전쟁이 시작곽사.")
    stage.info('왕운은 무술여포 잘 알고 있었고 반드시 해낼 것이라 믿었다\n승리를 거두자 그는 황제에게 보고하러 궁으로 갔다.')
    return False


def scene5():
    stage.loadBg(2, 15)
    stage.showUnits([
        [
            149,
            27,
            55,
            1],
        [
            153,
            45,
            55,
            3,
            6]])
    stage.draw()
    stage.setStageName('장안궁')
    stage.say('&149\n뭐라고! 왕윤, 진짜야?\n&153\n예, 폐하.\n&149\n동탁......동탁는 이미 죽었어......!\n&153\n네.\n루 장군은 동탁의 전 부하들과 싸우고 있었이각 곽사.\n&149\n아니, 심각하지 않을 거지?\n&153\n걱정 마십시오, 류 장군의 무사는 세계 어느 누구도 추종할 수 없습니다.\n그는 절대 패배하지 않을 것이다.\n&149\n그래요? 감사합니다, 친애하는 장관님.')
    stage.say('&182\n아!\n&181\n와!!')
    stage.showUnit(181, 94, 55, 3)
    stage.unit(181).move(90, 55, 3)
    stage.effectSound(38, 1)
    stage.unit(181).setAction(10)
    stage.delay(3)
    stage.unit(153).setAction(0, 1)
    stage.say('&153\n무슨 일이 있었던 거야!?')
    stage.showUnits([
        [
            131,
            95,
            52,
            3],
        [
            129,
            95,
            58,
            3]])
    stage.unitsMove([
        [
            stage.unit(131),
            55,
            52,
            3],
        [
            stage.unit(129),
            55,
            58,
            3]])
    stage.delay(3)
    stage.unit(131).setAction(2)
    stage.say('&131\n왕윤, 정말 여기 있었구나!')
    stage.unit(131).setAction(0)
    stage.delay(3)
    stage.unit(129).setAction(0)
    stage.say('&129\n너도 네 날이 있지?')
    stage.unit(129).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(3)
    stage.say('&153\n이각,곽사!')
    stage.unit(153).setAction(0)
    stage.say('&153\n......여포 패배할 수 있었을까요!?')
    stage.unit(131).setAction(3)
    stage.say('&131\n바보야! 가후 전략을 아군,\n여포 하나쯤은 걱정할 게 없어요!')
    stage.unit(131).setAction(0)
    stage.say('&153\n가후......?')
    stage.unit(129).setAction(3)
    stage.say('&129\n여포와 네 딸은 아마 이미 함께 지옥의 왕을 만나러 갔을 거야!\n왕윤, 너도 도망칠 수 없어!')
    stage.unit(129).setAction(0)
    stage.delay(5)
    stage.unit(153).setAction(0, 2)
    stage.say('&153\n......초선.......')
    stage.say('&149\n왜 두 장군이 궁에서 그런 학살을 저질렀을까?\n제발 그만해!')
    stage.unit(131).setAction(6)
    stage.say('&131\n폐하, 왕운이 죽는 대로 즉시 철수하겠습니다.')
    stage.unit(131).setAction(0)
    stage.delay(5)
    stage.say('&153\n한숨...... 지금 내가 가진 건 .......뿐이야.')
    stage.effectSound(34, 1)
    stage.unit(153).setAction(14)
    stage.delay(10)
    stage.effectSound(35, 1)
    stage.unit(153).setAction(10)
    stage.say('&153\n아.......')
    stage.delay(10)
    stage.say('&153\n......초선.......')
    stage.say('&149\n왕 ...... 왕 아이칭......!')
    stage.unit(131).setAction(3)
    stage.say('&131\n하하하!!')
    stage.unit(129).setAction(3)
    stage.say('&129\n하하하!')
    stage.delay(5)
    stage.clsUnit()
    return False


def scene6():
    stage.loadBg(2, 3)
    stage.showUnit(17, 60, 60, 1)
    stage.draw()
    stage.setStageName('뤄양, 왕윈의 거처')
    stage.say('&17\n무슨 일이야? 내 마음에는 항상 불길한 예감이 있어.')
    stage.unit(17).setAction(6)
    stage.say('&17\n아버지는 궁으로 갔다—혹시 예상치 못한 ......을 만난 걸까?')
    stage.showUnit(119, 30, 60, 1)
    stage.say('&119\n초선!')
    stage.unit(17).setAction(0, 1)
    stage.delay(3)
    stage.unit(17).setAction(0, 3)
    stage.unit(119).move(50, 60, 1)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n루 장군님, 무슨 일입니까?')
    stage.unit(17).setAction(0)
    stage.say('&119\n초선, 나는 그들의 계략 이각에 빠졌어,\n아군 제거되었습니다.')
    stage.unit(119).setAction(17)
    stage.say('&119\n궁전도 그들에게 점령당했다!')
    stage.unit(119).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n응? 아버지는 아직 궁 안에 계셔!\n루 장군님, 제 아버지는 괜찮으신가요!!')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(119).setAction(0, 3)
    stage.delay(3)
    stage.unit(119).move(46, 60, 3)
    stage.delay(8)
    stage.unit(119).setAction(0, 1)
    stage.say('&119\n초선...\n왕윤 공은 이각와 다른 이들에게 자살을 강요당했다.\n&17\n아빠가 자살하셨어......?')
    stage.unit(17).setAction(0, 2)
    stage.delay(3)
    stage.unit(17).setAction(9)
    stage.say('&17\n아, 아빠.......')
    stage.unit(119).move(50, 60, 1)
    stage.say('&119\n초선, 네가 많이 슬픈 거 알아,\n하지만 지금은 울 때가 아니에요!\n곧 도착할 거야!')
    stage.unit(119).setAction(17)
    stage.say('&119\n나와 함께 장안에서 탈출하라!')
    stage.unit(119).setAction(0)
    stage.say('&17\n…… 하지만 .......')
    stage.say('&119\n왕 경이 죽어가실 때도 당신을 생각하고 있었다고 들었어요.')
    stage.unit(119).setAction(17)
    stage.say('&119\n살아남아야 해!\n이 모든 것은 왕 경을 위한 것입니다!')
    stage.unit(119).setAction(0)
    stage.delay(5)
    stage.unit(17).setAction(0)
    stage.say('&17\n…… 알겠습니다, 류 장군님.\n아빠...... 나 살아남을 거야!')
    stage.unit(119).setAction(3)
    stage.say('&119\n나도 살고 싶어,\n무슨 일이 있어도, 이 혼란스러운 세상에서 함께 살아남아야 해!\n&119\n어서, 이봐초선!')
    stage.unit(119).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(0, 3)
    stage.say('&17\n흠, 류 장군.')
    stage.unitsMove([
        [
            stage.unit(119),
            30,
            60,
            3],
        [
            stage.unit(17),
            40,
            60,
            3]])
    stage.unit(119).hide()
    stage.unit(17).move(30, 60, 3)
    stage.unit(17).hide()
    stage.delay(5)
    stage.bgSound(-1)
    stage.delay(5)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(127, 140, 83)
    stage.bottomTxt('동탁', False, True, False)
    stage.delay(5)
    stage.showHead(119, 260, 83)
    stage.bottomTxt('그리고 여포', True, False, False)
    stage.delay(5)
    stage.bottomTxt('한때 한나라 수도인 장안에서 권력을 쥐고 있었다.', True, False, False)
    stage.delay(5)
    stage.bottomTxt('하지만 동탁가 여포에게 살해당했기 때문에,', True, True, False)
    stage.head(127).hide()
    stage.delay(5)
    stage.bottomTxt('여포 또한 장안에서 추방당했다.', True, False, False)
    stage.head(119).move(356, 83)
    stage.head(119).hide()
    stage.delay(5)
    stage.bottomTxt('동탁과 여포 이후,', False, True, False)
    stage.showHead(131, 140, 83)
    stage.bottomTxt('이각', True, False, False)
    stage.delay(5)
    stage.showHead(129, 260, 83)
    stage.bottomTxt('그리고 곽사', True, False, False)
    stage.delay(5)
    stage.bottomTxt('장안에서 정권을 장악했고,\n그럼에도 불구하고 그들의 폭정은 과거와 비교해 전혀 변하지 않았습니다.', True, False, True)
    stage.bottomTxt('그 순간,', False, True, False)
    stage.delay(5)
    stage.showHead(0, 404, 83)
    stage.bottomTxt('조조 반동탁 동맹만 남았다면,\n그는 동군의 도지로 임명되었다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('그의 배치지는 연주의 푸양이었다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene7():
    stage.bgSound(18)
    stage.loadBg(2, 27)
    stage.showUnits([
        [
            181,
            75,
            59,
            0,
            16],
        [
            202,
            76,
            55,
            3]])
    stage.unit(202).move(75, 55, 3)
    stage.showUnit(182, 75, 51, 2, 16)
    stage.draw()
    stage.setStageName('푸양 조조 저택 앞에서')
    stage.say('&181\n흠, 세게 해!\n&182\n아......!')
    stage.delay(5)
    stage.showUnit(0, 43, 58, 1)
    stage.delay(5)
    stage.say('&181\n이봐......!\n&0\n뭐 하는 거야?')
    stage.delay(5)
    stage.unit(181).setAction(0, 3)
    stage.unit(182).setAction(0, 3)
    stage.say('&181\n아, 그러니까 주군구나!\n어젯밤, 강한 바람이 군기 깃발을 날려버렸.......\n&182\n우리는 그것을 똑바로 세우고 싶어...\n하지만 너무 무거웠다.......')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하, 두세 명의 힘으로는 이 큰 깃발을 들어 올릴 수 없어.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.showUnits([
        [
            1,
            60,
            24,
            2],
        [
            16,
            60,
            16,
            2]])
    stage.say('&1\n맹덕!')
    stage.delay(5)
    stage.unitsMove([
        [
            stage.unit(1),
            60,
            48,
            2],
        [
            stage.unit(16),
            60,
            40,
            2]])
    stage.say('&0\n오, 원양!')
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕, 당신에게 추천하는 사람이 있어요.')
    stage.unit(1).setAction(0)
    stage.delay(5)
    stage.unit(1).setAction(0, 0)
    stage.say('&1\n이건 .......')
    stage.unit(16).move(72, 40, 1)
    stage.delay(1)
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n응? 야, 어디 가는 거야!?')
    stage.unit(16).move(72, 56, 1)
    stage.say('&16\n비켜, 내가 처리할게.')
    stage.unit(181).setAction(0, 0)
    stage.say('&181\n...... 할 수 있겠어?')
    stage.unit(182).setAction(0, 2)
    stage.say('&182\n혼자 옮길 수 없으니 다치지 않도록 조심하세요.')
    stage.delay(5)
    stage.unit(16).setAction(13)
    stage.say('&16\n음, 음, 아......!!')
    stage.say('&16\n이봐!')
    stage.effectSound(128, 1)
    stage.unit(202).setAction(1)
    stage.delay(10)
    stage.say('&181\n정말 신성한 힘이야!\n&182\n응? 똑바로 서 있어!')
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n어? 원양, 그 사람 얘기하는 거야!?')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n그것은 그들이 순찰 중에 마주친 바로 그 존재였다.')
    stage.delay(10)
    stage.unitsMove([
        [
            stage.unit(182),
            75,
            53,
            2],
        [
            stage.unit(181),
            75,
            59,
            0]])
    stage.unit(181).setAction(16)
    stage.unit(182).setAction(16)
    stage.delay(10)
    stage.unit(16).setAction(0, 3)
    stage.delay(3)
    stage.unit(16).move(65, 56, 3)
    stage.unit(16).setAction(0)
    stage.delay(5)
    stage.unit(16).setAction(6)
    stage.say('&16\n저는 전위입니다.')
    stage.unit(16).setAction(0)
    stage.say('&16\n이전에 조공은 동탁와 싸웠다,\n그는 위대한 원칙을 깊이 이해했고, 그의 겸손한 하인들은 그를 깊이 존경했다.')
    stage.unit(16).setAction(6)
    stage.say('&16\n조 공, 제가 전진적인 충성을 다해 모시게 해 주십시오!!')
    stage.unit(16).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.say('&0\n멋지군요, 무술이 정말 좋으시네요,\n내 곁에 있어줘!')
    stage.unit(16).setAction(6)
    stage.say('&16\n정말 영광이에요, 정말 감사합니다, 주군!')
    stage.unit(16).setAction(0)
    stage.say('&0\n원양, 나도 너한테 소개하고 싶은 사람 있어.')
    stage.say('&1\n누구세요?\n&0\n어서, 먼저 들어와. 곧 도착할 거야.')
    stage.clsUnit()
    return False


def scene8():
    stage.loadBg(2, 12)
    stage.showUnits([
        [
            0,
            29,
            54,
            1],
        [
            1,
            46,
            40,
            2],
        [
            20,
            46,
            52,
            3],
        [
            24,
            46,
            58,
            3]])
    stage.draw()
    stage.setStageName('푸양 조조 저택')
    stage.say('&0\n저는 조맹덕입니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n저는 순욱, 예자 문약입니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n나는 순욱의 조카 순유, 공다라고 불린다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n나는 .......')
    stage.delay(3)
    stage.unit(20).setAction(0, 0)
    stage.say('&20\n당신은 오랜 세월 잘 알려진 하후돈 장군이시겠군요.\n&1\n…… 아.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하! 그를 칭찬할 필요 없습니다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n당신이 내 전략가가 되고 싶어 한다는 소문을 들었어요,\n그럼 먼저 두 분께 세상의 현황에 대해 여쭤보겠습니다.')
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n좋아.')
    stage.unit(20).setAction(6, 3)
    stage.say('&20\n현재 전국 세 곳에서 세 가지 주요 교란이 발생하고 있습니다.')
    stage.say('&20\n첫 번째는 허베이성으로, 원소와 공손찬가 갈등을 빚고 있습니다.\n그러나 위원의 군대가 우위를 점하고 있었고, 허베이 통일은 시간 문제였다.\n&1\n흥! 원소 여전히 우위를 점하고 있어!\n&0\n좋아요, 계속해 주세요!')
    stage.say('&20\n손견 이전에 징저우의 류뱌오에게 패배했다.')
    stage.say('&0\n뭐라고? 손견 패배했어?\n&20\n네, 그리고 손견 그 자리에서 죽었어요.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\nReally...손견 그가 .......')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그럼 그 후 선 가족은 어떻게 되었나요?\n&20\n그의 장남 손책가 추종자들을 이끌고 원술에 합류했다.\n&0\n...... 원술 손에 있는가? 적의 천막으로 탈영하며,\n너무 아이러니하네요.......')
    stage.say('&20\n다음으로, 장안의 상황에 관해서는,\n조카가 설명해 순유.')
    stage.unit(20).setAction(0, 3)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n좋아.')
    stage.say('&24\n동탁가 죽은 후, 이각와 곽사은 여포 군대를 격파했다,\n그는 법원에서 최고 권력을 쥐고 있었다.\n&24\n사나운 서량 장군 마텅이 그들과 싸웠으나 패배했다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n뭐, 여포뿐만 아니라 마텅도 패배했어!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n왜 이길 수 없는 걸까?\n&20\n이각 전투에 군사 고문가후 있었기 때문에,\n두 사람은 가후의 함정에 빠져 패배한 것 같습니다.')
    stage.say('&0\n가후 자원허 .......')
    if vars[302]:
        stage.say('공달, 듣기로 여포가 패주할 때 왕윤 어른이 자결했다고 하던데, 그의 딸은 어떻게 되었습니까?')
        stage.unit(24).setAction(6)
        stage.say('&24\n아, 저 사람이 왕 경의 딸인가요?\n&0\n음, 그녀 이름이 초선......?\n&24\n도망칠 때 여포 기억나, 들었어,\n여자를 데려왔으니 아마 .......')
        stage.unit(24).setAction(0)
        stage.say('&0\n그래... 그럼 아직 살아 있는 거야?')
        stage.unit(1).setAction(3)
        stage.say('&1\n맹덕, 평범한 여자가 뭘 신경 써?\n그녀를 아세요?')
        stage.unit(1).setAction(0)
        stage.say('아니요, 아무것도 아닙니다…….')
    stage.unit(24).setAction(6)
    stage.say('&24\n이각. 곽사의 폭정은 과거의 동탁과 다름없다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.say('&0\n흠.')
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n혼란스러운 시기에는 힘이 정의를 이긴다.\n문약, 내가 얼마나 강하다고 생각해?')
    stage.unit(20).setAction(6)
    stage.say('&20\n상대적으로 약한 존재입니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(2)
    stage.say('&1\n뭐라고!')
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n하하하, 원양, 화내지 마.\n그게 현실이에요.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0)
    stage.delay(10)
    stage.say('&0\n문약, 내 힘은 정말 약하다,\n그래서 지금이 우리의 역량을 확장할 때입니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n오늘날 세상에는 세 가지 종류의 권력이 있다: 지능, 무력,\n그리고 천자의 권력. 먼저, 황실의 설득을 해야 한다\n그들을 믿고 천자를 지지하며, 천자의 인질로 잡아 봉건 영주들을 지휘하게 하라.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n그때가 오면, 충성스러운 신하들과 용맹한 장군들이,\n또한 당신의 지휘 아래 모일 것입니다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n우선, 천자의 힘을 의지해야 하죠......?')
    stage.unit(24).setAction(6)
    stage.say('&24\n장안이 황단의 잔존 세력을 진압하라는 칙령을 내릴 계획이라고 들었습니다.\n황실 사절이 곧 도착할 것이다.')
    stage.unit(24).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n아, 황제의 칙령이 황제의 잔존 세력을 진압하라는 명령이었나?')
    stage.unit(20).setAction(6)
    stage.say('&20\n이것은 궁정의 신뢰를 얻을 수 있는 좋은 기회였다,\n분명히 받아들일 거지?')
    stage.unit(20).setAction(0)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('물론 알고 있지.\n아니, 두고 보자.', 0)
    if sel == 1:
        stage.addAmbition(2)
        stage.bgSound(18)
        stage.delay(3)
        stage.say('&0\n어떻게 받아들이지 않을 수 있겠어요?')
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        stage.unit(20).setAction(0)
    elif sel == 2:
        stage.addAmbition(-2)
        stage.bgSound(18)
        stage.delay(3)
        stage.say('&0\n흠...... 어떻게 해야 할까요?\n아군 여기 온 지 얼마 안 됐어.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n지금 병력을 모집하는 것이 정말 최선의 전략일까요?')
        stage.unit(20).setAction(6)
        stage.say('&20\n왜 망설이십니까, 선생님?')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(24).setAction(6)
        stage.say('&24\n네, 기회를 놓치지 마세요.')
        stage.unit(24).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n흠...... 알겠어, 이해했어. 받아들일게.')
        stage.unit(20).setAction(6)
        stage.say('&20\n이거 정말 좋아.')
        stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n좋아, 공다 문약!\n너희 둘이 내 전략가가 되어 달라고 부탁할게.\n지혜로 아군를 도와주세요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n감사합니다, 선생님.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n네.')
    stage.unit(24).setAction(0)
    stage.delay(5)
    stage.clsUnit()
    stage.bgSound(-1)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 397, 79)
    stage.bottomTxt('얼마 지나지 않아,', False, False, False)
    stage.delay(5)
    stage.bottomTxt('순유 말했듯이,\n황반 반군을 진압하기 위한 황제 명령이 조조 도착했다.', True, True, False)
    stage.delay(10)
    stage.showHead(187, 516, 36)
    stage.delay(5)
    stage.bottomTxt('그래서 조조 대규모 군대를 이끌고 병력을 파견했다,', True, True, False)
    stage.delay(5)
    stage.head(0).move(396, 36)
    stage.delay(5)
    stage.bottomTxt('황번의 요새인 청주로 향한다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene9():
    model.unitJoin(16, 0, 0)
    model.unitJoin(20, 0, 0)
    model.unitJoin(24, 0, 0)
    if vars[1013]:
        gvars[0] = 16
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 20
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 24
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene10():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1],
        [
            6,
            38,
            46,
            1],
        [
            16,
            38,
            40,
            1],
        [
            20,
            60,
            52,
            3],
        [
            24,
            60,
            46,
            3],
        [
            5,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('청주 조조군 본진')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        16,
        20,
        24])
    gvars[4076] = 0
    gvars[4057] = 4
    stage.setBattlePos([
        [
            1,
            16],
        [
            2,
            17],
        [
            0,
            16],
        [
            2,
            18],
        [
            1,
            15],
        [
            3,
            17],
        [
            2,
            16],
        [
            1,
            17],
        [
            0,
            17],
        [
            1,
            18],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene11():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n전위This 무술가야,\n민첩하고 적의 공격을 덜 받는다.')
    if stage.unitClickTest(6):
        stage.say('&6\n순욱 신사는 전략가입니다,\n공격 전략에 능숙하고,\n하지만 탱크 파이터는 다소 부족한 .......')
    if stage.unitClickTest(16):
        stage.say('&16\n난 나 자신에게 충분해, 걱정하지 마.\n하하하!')
    if stage.unitClickTest(24):
        stage.say('&24\n나는 풍수 대가야. 뒷받침은 나한테 맡겨.')
    if stage.unitClickTest(20):
        stage.say('&20\n미래의 전투 전에,\n먼저 전장의 상황을 간단히 설명하겠습니다.\n&0\n흠, 네가 믿고 있어.\n&20\n네.\n&20\n이번에는 전장이 거의 전부 산과 숲으로 이루어져 있었다,\n그 결과 이동성이 감소할 것입니다.\n&20\n전장에는 세 개의 산이 있다,\n모든 언덕 꼭대기 근처에는 황번 마을들이 있습니다.')
    if stage.unitClickTest(5):
        stage.say('&5\n황번군은 우리와 맞설 수 없었다.\n&0\n절대 부주의하지 마세요!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
