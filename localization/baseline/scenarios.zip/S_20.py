# Source Generated with Decompyle++
# File: S_20.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,13)',
        '(13,12)',
        '(1,24)',
        '(2,25)'])
    stage.nearEvent([
        2,
        34,
        74,
        7,
        75,
        6])
    stage.nearEvent([
        34,
        7], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 32, 0, 0, 1)
    stage.createEnemy([
        {
            'id': 32,
            'x': 13,
            'y': 13,
            'dir': 0,
            'lv': 6,
            'i': 0 },
        {
            'id': 34,
            'x': 13,
            'y': 11,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 210,
            'x': 12,
            'y': 11,
            'dir': 0,
            'lv': 0,
            'i': 2 },
        {
            'id': 211,
            'x': 14,
            'y': 11,
            'dir': 0,
            'lv': 0,
            'i': 3 },
        {
            'id': 318,
            'x': 12,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'i': 4 },
        {
            'id': 319,
            'x': 14,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'i': 5 },
        {
            'id': 298,
            'x': 13,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 3,
            'x': 11,
            'y': 14,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 7 },
        {
            'id': 46,
            'x': 12,
            'y': 13,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 8 },
        {
            'id': 47,
            'x': 12,
            'y': 14,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 9 },
        {
            'id': 33,
            'x': 15,
            'y': 14,
            'dir': 1,
            'lv': 6,
            'ai': 0,
            'i': 10 },
        {
            'id': 320,
            'x': 14,
            'y': 13,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 11 },
        {
            'id': 321,
            'x': 14,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 12 },
        {
            'id': 74,
            'x': 1,
            'y': 24,
            'dir': 0,
            'lv': 4,
            'ai': 0,
            'i': 13 },
        {
            'id': 40,
            'x': 2,
            'y': 24,
            'dir': 0,
            'lv': 4,
            'ai': 0,
            'i': 14 },
        {
            'id': 42,
            'x': 2,
            'y': 25,
            'dir': 0,
            'lv': 4,
            'ai': 0,
            'i': 15 },
        {
            'id': 212,
            'x': 1,
            'y': 21,
            'dir': 0,
            'lv': 0,
            'i': 16 },
        {
            'id': 213,
            'x': 2,
            'y': 21,
            'dir': 0,
            'lv': 0,
            'i': 17 },
        {
            'id': 234,
            'x': 1,
            'y': 22,
            'dir': 0,
            'lv': 0,
            'i': 18 },
        {
            'id': 235,
            'x': 2,
            'y': 22,
            'dir': 0,
            'lv': 0,
            'i': 19 },
        {
            'id': 299,
            'x': 1,
            'y': 25,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 20 },
        {
            'id': 214,
            'x': 5,
            'y': 24,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 21 },
        {
            'id': 215,
            'x': 5,
            'y': 25,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 22 },
        {
            'id': 75,
            'x': 4,
            'y': 24,
            'dir': 1,
            'lv': 4,
            'i': 23 },
        {
            'id': 406,
            'x': 4,
            'y': 25,
            'dir': 1,
            'lv': 0,
            'i': 24 },
        {
            'id': 407,
            'x': 3,
            'y': 24,
            'dir': 1,
            'lv': 0,
            'i': 25 },
        {
            'id': 408,
            'x': 3,
            'y': 25,
            'dir': 1,
            'lv': 0,
            'i': 26 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 12,
            'y': 1 },
        {
            'idx': 1,
            'x': 13,
            'y': 2 },
        {
            'idx': 2,
            'x': 10,
            'y': 1,
            'hide': 1 },
        {
            'idx': 3,
            'x': 15,
            'y': 2,
            'hide': 1 },
        {
            'idx': 4,
            'x': 9,
            'y': 2,
            'hide': 1 },
        {
            'idx': 5,
            'x': 16,
            'y': 1,
            'hide': 1 },
        {
            'idx': 6,
            'x': 9,
            'hide': 1 },
        {
            'idx': 7,
            'x': 15,
            'hide': 1 },
        {
            'idx': 8,
            'x': 12,
            'y': 3,
            'hide': 1 },
        {
            'idx': 9,
            'x': 14,
            'y': 3,
            'hide': 1 },
        {
            'idx': 10,
            'x': 13,
            'y': 4,
            'hide': 1 },
        {
            'idx': 11,
            'x': 14,
            'y': 1 },
        {
            'idx': 12,
            'x': 11,
            'y': 2 },
        {
            'idx': 13,
            'x': 13 },
        {
            'idx': 14,
            'x': 11 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(42, -1, 0, -1, 0, 22)
    stage.loadBg(20)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(1)
    stage.unit(42).setAction(8)
    stage.say('&42\n조의 군대는 랑산 북쪽에 진을 쳤다,\n7일째 움직임이 없었어,\n정확히 무엇을 하려는 걸까요?')
    stage.unit(74).setDir(stage.countDir(74, 42))
    stage.say('&74\n미팡 씨, 진정하세요.\n네가 한 말 때문에 불안해.')
    stage.unit(40).setDir(stage.countDir(40, 75))
    stage.say('&40\n공두, 수송팀 준비됐어?\n주군 초조하게 기다리고 있었다.')
    stage.unit(75).setDir(stage.countDir(75, 40))
    stage.say('&75\n선첸 씨, 준비되셨군요,\n지금 유비에게 보내겠습니다.')
    stage.unit(75).setDir(1)
    stage.unit(75).setAction(5)
    stage.say('&75\n자, 모두 가자.\n서둘러, 서둘러, 너무 느리지 마!')
    stage.unit(75).setAction(0)
    stage.unit(75).move(9, 24, 1)
    stage.unit(406).move(9, 25, 1)
    stage.unit(407).move(8, 24, 1)
    stage.unit(408).move(8, 25, 1)
    stage.unit(33).setDir(stage.countDir(33, 32))
    stage.say('&33\n아직 싸우지 않을 거조조!\n서로를 바라보는 그런 모습,\n거의 지쳤어요!')
    stage.unit(32).setDir(stage.countDir(32, 33))
    stage.say('&32\n잠깐만, 셋째 형.\n조조 자제하는 게 좀 이상하네,\n아마 또 장난치는 걸지도 몰라.')
    stage.unit(3).setDir(stage.countDir(3, 32))
    stage.say('&3\n저와 제 형도 같은 생각을 했습니다.\n뭔가 계획이 있을 거야.')
    stage.unit(32).setDir(stage.countDir(32, 3))
    stage.unit(34).setDir(stage.countDir(34, 32))
    stage.say('&34\n현재 군대의 보급품은 부족합니다,\n수송대가 도착하기 전에,\n아군 행동할 수 없다.')
    stage.unit(32).setDir(stage.countDir(32, 33))
    stage.say('&32\n네, 삼형님. 배고픈데 어떻게 싸울 수 있죠?\n수송대가 도착하기 전에,\n우리는 견뎌야 했습니다.\n&33\n그럼 모두가 배고파서 그런 거야?\n그럼 왜 수송대는 아직 도착하지 않았지?')
    stage.unit(75).move(14, 24, 1)
    stage.unit(406).move(14, 25, 1)
    stage.unit(407).move(13, 24, 1)
    stage.unit(408).move(13, 25, 1)
    stage.say('&75\n랑산의 요새는 견고하고 견고했다.\n하지만 공급은 매우 어려웠다,\n늦지 마!')
    stage.unit(2).setDir(stage.countDir(2, 0))
    stage.say('&2\n주군, 병력을 배치하고 파견할 때가 되었을 것이다,\n루난 유비에 대한 기습 공격......\n그리고 이제 병력을 수송할 시간이다.\n&2\n주군 더 큰 군사력을 가진 부대를 파견할 계획이다,\n루난을 공격할까, 아니면 병력을 수송할까?')
    sel = stage.choice('물론, 루난 시였다\n물론, 수송 부대가\n기습 공격은 중단되었다', -1)
    if sel == 1:
        stage.say('&0\n루난시!\n그 도시를 점령하는 한,\n유비 산적일 뿐이야.\n&2\n보급이 끊긴 유비군,\n그때쯤이면 산에서 굶어 죽을 거야.\n알겠어요!')
        stage.createMine([
            {
                'idx': 2,
                'x': 1,
                'y': 16,
                'hide': 1 },
            {
                'idx': 3,
                'x': 22,
                'y': 22,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 4,
                'y': 17,
                'hide': 1 },
            {
                'idx': 5,
                'x': 21,
                'y': 23,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 6,
                'x': 2,
                'y': 17,
                'hide': 1 },
            {
                'idx': 7,
                'x': 21,
                'y': 21,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 8,
                'x': 3,
                'y': 16,
                'hide': 1 },
            {
                'idx': 9,
                'y': 15,
                'hide': 1 },
            {
                'idx': 10,
                'x': 2,
                'y': 15,
                'hide': 1 }])
    elif sel == 2:
        stage.say('&0\n대부분의 분견대가 수송 유닛을 공격하게 하세요.')
        stage.say('&2\n루난 시를 공격하지 않을 거야?\n&0\n루난 시에 대한 기습 공격은 속임수였다,\n랑산에 흩어진 적이 진짜 ......\n&0\n기습 수송대 병력들이,\n랑샨의 사슴 요새를 포위하는 본대 진영에 합류하라.\n&2\n그래서 그런 거야.\n주군의 계획은 정말 영리했다!')
        stage.createMine([
            {
                'idx': 2,
                'x': 1,
                'y': 16,
                'hide': 1 },
            {
                'idx': 3,
                'x': 22,
                'y': 22,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 4,
                'y': 17,
                'hide': 1 },
            {
                'idx': 5,
                'x': 21,
                'y': 23,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 6,
                'x': 2,
                'y': 17,
                'hide': 1 },
            {
                'idx': 7,
                'x': 21,
                'y': 21,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 8,
                'x': 22,
                'y': 20,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 9,
                'x': 22,
                'y': 24,
                'dir': 3,
                'hide': 1 },
            {
                'idx': 10,
                'x': 23,
                'y': 21,
                'dir': 3,
                'hide': 1 }])
        vars[2] = 1
    elif sel == 3:
        stage.say('아니요, 기습하지 않겠습니다.')
        stage.unit(2).setAction(10)
        stage.say('&2\n뭐라고 했어?\n왜 주군 이 아이디어를 포기했을까?\n&0\n이 두 곳에 기습 공격을 감행한다면,\n유비 랑산에서 자리를 지켰을 뿐이야.\n그렇지 않으면 루난 시를 방어하기 위해 병력을 분산시킬 것이다.\n&2\n그래서 그런 거구나! 때가 되면 전 군대를 동원할 수 있어,\n주요 캠프 유비 몇 개 공격하세요.\n&0\n그의 지휘 아래 유비 관우 유명한 장군들이 있었다,\n원위안은 가볍게 여겨서는 안 된다.\n&2\n네.')
        stage.unit(32).setAI(2)
        vars[3] = 1
    stage.unit(75).move(18, 23, 1)
    stage.unit(406).move(18, 24, 1)
    stage.unit(407).move(17, 23, 1)
    stage.unit(408).move(17, 24, 1)
    stage.unit(75).setAI(3, 32, 0, 0)
    stage.unit(406).setAI(6, -1, 13, 13)
    stage.unit(407).setAI(6, -1, 13, 13)
    stage.unit(408).setAI(6, -1, 13, 13)
    stage.unit(75).setDir(3)
    stage.unit(75).setAction(2)
    stage.say('&75\n마침내 우리는 산기슭에 도착했다.\n조금만 더, 최선을 다하자!')
    if not vars[3]:
        if not vars[2]:
            stage.unit(3, 1).show()
            stage.unit(5, 1).show()
            stage.unit(7, 1).show()
        if vars[2]:
            stage.unit(3, 1).show()
            stage.unit(5, 1).show()
            stage.unit(7, 1).show()
            stage.unit(8, 1).show()
            stage.unit(9, 1).show()
            stage.unit(10, 1).show()
        stage.unit(6).setDir(stage.countDir(6, 75))
        stage.unit(6).setAction(5)
        stage.say('&6\n하하하!\n이 곡식은 이제 우리 거야!')
        stage.unit(6).setAction(0)
        stage.unit(75).setDir(stage.countDir(75, 6))
        stage.unit(75).setAction(10)
        stage.say('&75\n뭐라고!\n어떻게 조준이 여기 있을 수 있지!?')
        stage.unit(75).setDir(stage.countDir(75, 32))
        stage.unit(75).setAction(5)
        stage.say('&75\n모두, 서둘러 돌진해,\n그는 재빨리 랑샨의 사슴 요새로 도망쳤다.')
        stage.unit(75).setAction(0)
        stage.unit(34).setDir(stage.countDir(34, 32))
        stage.say('&34\n주군, 뭔가 이상해!\n수송 부대가 이쪽으로 오고 있다는 보고를 방금 받았어,\n그들은 조조의 군대에게 공격당했다!')
        stage.unit(32).setDir(stage.countDir(32, 33))
        stage.say('&32\n어떻게 이런 일이 일어날 수 있지...!?\n셋째 형, 즉시 구하러 가!')
        stage.unit(33).setDir(stage.countDir(33, 75))
        stage.unit(33).setAction(5)
        stage.say('&33\n뭐라고? 내가 기다리는 음식이 너무 초조해서,\n어떻게 조조 그걸 빼앗을 수 있겠어!\n여러분, 저를 따라 수송팀을 구출하세요.')
        stage.unit(33).setAction(0)
        stage.unit(3).setDir(stage.countDir(3, 75))
        stage.say('&3\n역시나, 또 다른 속임수였다조조......\n그는 오랫동안 속임수가 있을지도 모른다고 의심해왔다.')
        stage.unit(33).setAI(4, -1, 19, 23)
        stage.unit(320).setAI(4, -1, 19, 23)
        stage.unit(321).setAI(4, -1, 19, 23)
        if not vars[2]:
            stage.unit(2, 1).show()
            stage.unit(4, 1).show()
            stage.unit(6, 1).show()
            stage.unit(8, 1).show()
            stage.unit(9, 1).show()
            stage.unit(10, 1).show()
        if vars[2]:
            stage.unit(2, 1).show()
            stage.unit(4, 1).show()
            stage.unit(6, 1).show()
        stage.unit(7).setAction(5)
        stage.say('&7\n즉시 루난 시를 넘겨라!\n그렇지 않으면 도시와 사람들을 불태울 수 있었다.')
        stage.unit(7).setAction(0)
        stage.unit(42).setDir(stage.countDir(42, 7))
        stage.unit(42).setAction(8)
        stage.say('&42\n뭐야, 조나라 군대가 공격한다고!?\n그들이 랑샨 주변에 온 것 같아,\n어떻게 해야 하지? 어떻게 해야 하지?')
        stage.unit(74).setDir(stage.countDir(74, 7))
        stage.say('&74\n미팡 씨! 지금 당황하면 안 돼.\n싸울 준비를 하자!')
        stage.unit(34).setDir(stage.countDir(34, 32))
        stage.say('&34\n주군, 나쁜 일이 생겼어.\n적이 루난 시 ......을 공격하고 있다!')
        stage.unit(32).setDir(stage.countDir(32, 3))
        stage.say('&32\n음음 흠 흠흠 ......\n둘째 형, 지금 여기서 아무 일도 일어나지 않을 거야,\n먼저 루난시를 구하러 가야 해.')
        stage.unit(3).setDir(stage.countDir(3, 32))
        stage.say('&3\n그러니까 형도 특히 조심해야 해......')
        stage.unit(3).setDir(3)
        stage.unit(3).setAction(5)
        stage.say('&3\n가자!\n모두 언덕을 건너 전속력으로 전진했다!')
        stage.unit(3).setAction(0)
        stage.unit(3).setAI(4, -1, 2, 18)
        stage.unit(46).setAI(4, -1, 2, 18)
        stage.unit(47).setAI(4, -1, 2, 18)
    if vars[3]:
        stage.unit(3, 1).show()
        stage.unit(5, 1).show()
        stage.unit(7, 1).show()
        stage.unit(6).setDir(stage.countDir(6, 0))
        stage.say('&6\n하후연 부대를 이끌고 돌아갔다.')
        stage.unit(2, 1).show()
        stage.unit(4, 1).show()
        stage.unit(6, 1).show()
        stage.unit(8, 1).show()
        stage.unit(9, 1).show()
        stage.unit(10, 1).show()
        stage.unit(7).setDir(stage.countDir(7, 0))
        stage.say('&7\n장합 모든 병력을 함께 이끌어라!')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n군대 전체가 이제 공세를 시작하고 있습니다......\n랑산 루자이의 유비.\n모두가 부주의해서는 안 됩니다.')
    stage.bgSound(5)
    stage.setWinCondition('승리 조건\n1. 유비 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('유비 격퇴해!')
    stage.unit(32).heightLight()
    stage.startOper()
    vars[520] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[3] and not vars[11] and stage.round() == 5:
        stage.unit(3).setAI(1)
        stage.unit(46).setAI(1)
        stage.unit(47).setAI(1)
        vars[11] = 1
    if not vars[3] and not vars[12] and stage.round() == 3:
        stage.unit(33).setAI(1)
        stage.unit(320).setAI(1)
        stage.unit(321).setAI(1)
        vars[12] = 1
    if vars[22] and not vars[3] and not vars[13] and not vars[50] and stage.round() >= 6 and stage.curCamp() == 2:
        stage.unit(3).setAction(4)
        stage.say('&3\n루난 시는 이미 패배를 당했다......\n먼저 형에게 돌아가는 게 낫겠어......')
        stage.unit(3).setDir(stage.countDir(3, 32))
        stage.unit(3).setAI(3, 32, 0, 0)
        stage.unit(46).setAI(3, 32, 0, 0)
        stage.unit(47).setAI(3, 32, 0, 0)
        stage.unit(40).setAI(3, 32, 0, 0)
        stage.unit(42).setAI(3, 32, 0, 0)
        stage.unit(74).setAI(3, 32, 0, 0)
        vars[13] = 1
    if vars[60] and vars[61] and vars[62] and not vars[3] and not vars[14] and not vars[50] and stage.round() >= 4 and stage.curCamp() == 2:
        stage.unit(33).setAction(6)
        stage.say('&33\n수송 부대는 이미 패배했다......\n먼저 형에게 물러나는 게 낫겠어......')
        stage.unit(33).setAction(0)
        stage.unit(33).setDir(stage.countDir(33, 32))
        stage.unit(33).setAI(3, 32, 0, 0)
        stage.unit(320).setAI(3, 32, 0, 0)
        stage.unit(321).setAI(3, 32, 0, 0)
        vars[14] = 1
    if not vars[20] and stage.isInPos(1025, 13, 13):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 13, 12):
        stage.getItem(150, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 1, 24):
        stage.getItem(152, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 2, 25):
        stage.getItem(150, -1, True, 1025)
        vars[23] = 1
    if not vars[3] and not vars[6] and not vars[22] and stage.totalRectUnit(2, 8, 6, 18, 18) < 5 and stage.totalRectUnit(0, 8, 6, 18, 18) >= 6 and stage.curCamp() == 2:
        stage.say('&32\n랑산의 사슴 요새는 이미 패배한 상태였다......\n지금은 루난시로 도망치는 게 낫다.')
        stage.unit(32).setAI(6, -1, 1, 24)
        stage.unit(34).setAI(6, -1, 1, 24)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(318).setAI(1)
        stage.unit(319).setAI(1)
        vars[6] = 1
    if vars[3] and not vars[7] and not vars[22] and stage.totalRectUnit(2, 8, 6, 18, 18) < 7 and stage.totalRectUnit(0, 8, 6, 18, 18) >= 8 and stage.curCamp() == 2:
        stage.say('&32\n랑산의 사슴 요새는 이미 패배한 상태였다......\n지금은 루난시로 도망치는 게 낫다.')
        stage.unit(32).setAI(6, -1, 1, 24)
        stage.unit(34).setAI(6, -1, 1, 24)
        stage.unit(3).setAI(6, -1, 1, 24)
        stage.unit(46).setAI(6, -1, 1, 24)
        stage.unit(47).setAI(6, -1, 1, 24)
        stage.unit(33).setAI(6, -1, 1, 24)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(318).setAI(1)
        stage.unit(319).setAI(1)
        vars[7] = 1
    if not vars[30] and not vars[53] and stage.isInRect(1025, 0, 20, 6, 27) and stage.curCamp() == 2:
        stage.unit(40).setAction(5)
        stage.say('&40\n적이 도시에 들어오지 못하게 하라!')
        stage.unit(40).setAction(0)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[30] = 1
    if not vars[6] and not vars[7] and not vars[31] and not vars[50] and stage.isInRect(406, 12, 11, 14, 14):
        stage.unit(32).setDir(stage.countDir(32, 406))
        stage.say('&32\n오, 곡식이 도착했어.\n즉시 병사들에게 배치하라!')
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 2,
                'x1': 8,
                'y1': 6,
                'x2': 18,
                'y2': 18,
                'camp': 2 }])
        stage.unit(406).hide()
        vars[31] = 1
    if not vars[6] and not vars[7] and not vars[32] and not vars[50] and stage.isInRect(407, 12, 11, 14, 14):
        stage.unit(32).setDir(stage.countDir(32, 407))
        stage.say('&32\n오, 곡식이 도착했어.\n즉시 병사들에게 배치하라!')
        stage.setUnitStatus([
            {
                'status': 0,
                'lift': 2,
                'x1': 8,
                'y1': 6,
                'x2': 18,
                'y2': 18,
                'camp': 2 }])
        stage.unit(407).hide()
        vars[32] = 1
    if not vars[6] and not vars[7] and not vars[33] and not vars[50] and stage.isInRect(408, 12, 11, 14, 14):
        stage.unit(32).setDir(stage.countDir(32, 408))
        stage.say('&32\n오, 곡식이 도착했네,\n병사들에게 맡겨라!')
        stage.setUnitStatus([
            {
                'status': 3,
                'lift': 2,
                'x1': 8,
                'y1': 6,
                'x2': 18,
                'y2': 18,
                'camp': 2 }])
        stage.unit(408).hide()
        vars[33] = 1
    if not vars[6] and not vars[7] and not vars[34] and stage.isInRect(1025, 9, 8, 17, 17):
        stage.unit(318).setAI(1)
        stage.unit(319).setAI(1)
        stage.unit(34).setAI(1)
        if vars[3]:
            stage.unit(3).setAI(1)
            stage.unit(46).setAI(1)
            stage.unit(47).setAI(1)
            stage.unit(33).setAI(1)
            stage.unit(320).setAI(1)
            stage.unit(321).setAI(1)
        vars[34] = 1
    if not vars[35] and stage.isInRect(32, 0, 20, 6, 27):
        stage.unit(32).setAI(0)
        vars[35] = 1
    if not vars[36] and stage.isInRect(34, 0, 20, 6, 27):
        stage.unit(34).setAI(0)
        vars[36] = 1
    if not vars[40] and stage.isNear(2, 34, False):
        stage.unit(2).setDir(stage.countDir(2, 34))
        stage.unit(34).setDir(stage.countDir(34, 2))
        stage.say('&2\n조운, 내 총알 밑에 유령이 되어 버려!\n&34\n만나게 해줘.')
        fight = stage.startFight(2, 34, 5)
        fight.showUnit(True, '조운!\n네 목숨을 빼앗으러 왔장료!', 9)
        fight.showUnit(False, '지금은 크게 말하지 마,\n싸움이 끝날 때까지 기다려!', 9)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '이걸 받아라!', True)
        fight.setAction(True, 8)
        fight.say(True, '어서!', True)
        fight.attack2(True, 2, True)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.say(True, '음, 놓쳤다고!?', True)
        fight.setAction(False, 1)
        fight.say(False, '바로 죽일 수 있는 상대가 아닌 것 같아!', True)
        stage.delay(5)
        fight.setAction(False, 2)
        fight.setAction(False, 8)
        fight.say(False, '그게 게임의 끝이야!\n이걸 받아라!', True)
        fight.setAction(True, 2)
        fight.setAction(True, 9)
        fight.say(True, '딱 맞춰 왔네요!\n나도 진짜 실력을 보여줄 거야!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, True)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.say(True, '뭐, 네 뒤에?', False)
        fight.setAction(False, 8)
        fight.say(False, '너무 느리게 움직이고 있어!', False)
        fight.attack1(False, 2, True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 3, True)
        stage.delay(5)
        fight.say(False, '응!', False)
        fight.say(True, '내 묘기를 써!', False)
        fight.setAction(True, 2)
        fight.attack2(True, 1, True)
        fight.setAction(False, 1)
        fight.setAction(True, 1)
        fight.attack1(False, 3, True)
        stage.delay(10)
        fight.setAction(True, 9)
        fight.say(True, '정말 인상적인 조운.\n네가 내 사격 실력을 꺾었어......', True)
        fight.setAction(False, 6)
        fight.say(False, '당신도 정말 뛰어나네요......', True)
        fight.end()
        vars[40] = 1
    if not vars[41] and stage.isNear(34, 7, False):
        stage.unit(7).setDir(stage.countDir(7, 34))
        stage.unit(34).setDir(stage.countDir(34, 7))
        stage.say('&7\n네 머리를 장합 가져가게 해줘.\n&34\n그렇게 간단하지 않아.')
        stage.attackAction(7, 34, 2)
        stage.delay(10)
        stage.attackAction(7, 34, 2)
        stage.delay(10)
        stage.attackAction(7, 34, 2)
        stage.delay(10)
        stage.say('&7\n흠, 정말 능숙하네요.\n화살 하나도 맞지 않았어.\n&34\n조금 더 연습하러 돌아가는 게 어때,\n그럼 다시 와서 도전해 봐.')
        vars[41] = 1
    if not vars[42] and stage.isNear(74, 7, False):
        stage.unit(74).setDir(stage.countDir(74, 7))
        stage.unit(7).setDir(stage.countDir(7, 74))
        stage.say('&74\n루난시는 쉽게 네가 빼앗기지 않을 거야!\n&7\n내 화살을 받으면,\n아직도 말할 수 있는지 보자!')
        fight = stage.startFight(7, 74, 5)
        fight.showUnit(True, '내가 장합 활과 화살을 보여줄게!', 9)
        fight.showUnit(False, '흥! 네 화살이 뭐가 그렇게 무서워!', 10)
        fight.showStart()
        fight.setAction(True, 1)
        stage.delay(5)
        fight.setAction(True, 2)
        fight.setAction(False, 8)
        fight.say(False, '멈춰!\n도망가고 싶어?', False)
        fight.setAction(False, 2)
        fight.setAction(True, 1)
        fight.attack1(True, 1, False)
        stage.delay(5)
        fight.setAction(True, 0)
        fight.say(True, '응?', True)
        fight.setAction(False, 8)
        fight.say(False, '하하하!\n이 방법은 너무 구식이야!', True)
        fight.setAction(True, 8)
        fight.say(True, '아, 그럼 이 움직임은 어때?', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.say(False, '음-음!\n아-너무 빨리!', False)
        fight.say(True, '이거 받아라! 난 다른 비장도 있어!', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, False)
        fight.attack2(True, 0, False)
        fight.attack1(True, 0, True)
        stage.delay(5)
        fight.setAction(False, 11)
        fight.say(False, '음... 어떻게 그럴 수 있지.........', True)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '전술은 날이 갈수록 발전합니다.\n날 과소평가하는 것 같아!', True)
        fight.end()
        stage.unit(74).hide(2)
        vars[57] = 1
        vars[42] = 1
    if not vars[43] and stage.isNear(75, 6, False):
        stage.unit(75).setDir(stage.countDir(75, 6))
        stage.unit(6).setDir(stage.countDir(6, 75))
        stage.say('&75\n형유비 곡식을 훔치고 싶어?\n먼저 내가 널 죽이는 걸 봐.\n&6\n그런 능력이 있나요?')
        fight = stage.startFight(6, 74, 5)
        fight.showUnit(False, '하하하!\n도망가고 싶으면 지금이 기회야!', 10)
        fight.showUnit(True, '왜 내가 하후연 출마하겠어?', 0)
        fight.showStart()
        fight.setAction(False, 10)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.say(False, '이 검 한 방은 어때!\n무섭지?', True)
        fight.say(True, '……………', True)
        fight.setAction(False, 10)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.attack1(True, 0, True)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.say(False, '와.........', True)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '자랑만 아는 사람이야......', True)
        fight.setAction(True, 3)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.end()
        stage.unit(75).hide(2)
        vars[59] = 1
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(32, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&32\n좋지 않아.\n빨리 후퇴해, 군대 전체가 후퇴해!')
        stage.unit(32).hide(1)
        if not vars[54]:
            stage.say('&34\n우리는 후퇴할 수밖에 없었다!')
        if not vars[51]:
            stage.say('&3\n형, 형... 내가 할 수 있는 게 없어......\n난 후퇴한다!')
        if not vars[52]:
            stage.say('&33\n아-아, 안 돼!\n그는 물러날 수밖에 없었다.\n빨리 후퇴해!')
        if not vars[58]:
            stage.unit(42).setAction(8)
            stage.say('&42\n주여, 주군! 아니, 뭔가 잘못됐어!\n루난도 예외는 아니다......\n"후퇴, 후퇴!"')
        stage.setRectUnitHide(0, 0, 23, 27, 2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n젠장, 우리 전술은 통하지 않아.\n형, 좋은 전략가를 찾아야 해.\n후퇴!')
        stage.unit(3).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n젠장! 다 너무 배고파서 그래.\n배고프고 지쳤어. 다음에 또 싸우자......\n후퇴!')
        stage.unit(33).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n주군, 미안해.\n난 후퇴한다!')
        stage.unit(40).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n좋지 않아!\n난 후퇴한다!')
        stage.unit(34).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(46, 7, 0, 2):
        stage.say('&46\n패배했다......\n먼저 후퇴하자.\n다음에 싸우자!')
        stage.unit(46).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(47, 7, 0, 2):
        stage.say('&47\n응.\n무술은 아직 수준에 미치지 못해!\n먼저 돌아가서 연습하세요.')
        stage.unit(47).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(74, 7, 0, 2):
        stage.say('&74\n음-음.\n유비Big 형, 류피는 이번에 정말 끝났어.\n와... 아!')
        stage.unit(74).hide(2)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(42, 7, 0, 2):
        stage.say('&42\n너무 아파서 더는 못 참겠어......\n죽을 정도로 심각하지는 않았다.\n지금 후퇴하자!')
        stage.unit(42).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(75, 7, 0, 2):
        stage.say('&75\n흠, 못 하겠어......\n와!')
        stage.unit(75).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(406, 7, 0, 2):
        stage.unit(406).hide(1)
        stage.getItem(151, -1, True, 1025)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(407, 7, 0, 2):
        stage.unit(407).hide(1)
        stage.getItem(151, -1, True, 1025)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(408, 7, 0, 2):
        stage.unit(408).hide(1)
        stage.getItem(151, -1, True, 1025)
        vars[62] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 물리쳤어!\n아군 이겼어!')
        if vars[22] and vars[59] and vars[60] and vars[61] and vars[62]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[620] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
