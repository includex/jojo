# Source Generated with Decompyle++
# File: S_38.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24], [
        '(14,29)',
        '(13,29)',
        '(7,13)',
        '(7,10)',
        '(7,16)'])
    stage.nearEvent([
        9,
        3,
        9,
        47])
    stage.nearEvent([
        14,
        47,
        0,
        47], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 2, 3)
    stage.createEnemy(
        [{'id': 51, 'x': 14, 'y': 29, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 0},
         {'id': 53, 'x': 14, 'y': 28, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 1},
         {'id': 49, 'x': 12, 'y': 30, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 2},
         {'id': 39, 'x': 15, 'y': 30, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 3},
         {'id': 258, 'x': 14, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 259, 'x': 13, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 282, 'x': 13, 'y': 28, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 210, 'x': 11, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 211, 'x': 11, 'y': 30, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 212, 'x': 16, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 213, 'x': 16, 'y': 30, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 10},
         {'id': 234, 'x': 12, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 11},
         {'id': 235, 'x': 15, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 298, 'x': 13, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 66, 'x': 7, 'y': 10, 'dir': 3, 'lv': 6, 'i': 14},
         {'id': 44, 'x': 7, 'y': 16, 'dir': 3, 'lv': 4, 'i': 15},
         {'id': 260, 'x': 8, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 16},
         {'id': 261, 'x': 8, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 17},
         {'id': 283, 'x': 9, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 18},
         {'id': 390, 'x': 8, 'y': 15, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 19},
         {'id': 391, 'x': 8, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 20},
         {'id': 382, 'x': 8, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 21},
         {'id': 214, 'hide': 1, 'x': 6, 'y': 10, 'dir': 3, 'lv': 0, 'i': 22},
         {'id': 215, 'hide': 1, 'x': 6, 'y': 13, 'dir': 3, 'lv': 0, 'i': 23},
         {'id': 216, 'hide': 1, 'x': 6, 'y': 16, 'dir': 3, 'lv': 0, 'i': 24},
         {'id': 217, 'x': 7, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 25},
         {'id': 218, 'x': 8, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 26},
         {'id': 236, 'x': 8, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 27},
         {'id': 237, 'x': 8, 'y': 14, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 3, 'x': 20, 'y': 5, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 29},
         {'id': 46, 'x': 20, 'y': 4, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 30},
         {'id': 47, 'x': 12, 'y': 5, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 31},
         {'id': 219, 'x': 10, 'y': 5, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 220, 'x': 11, 'y': 5, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 221, 'x': 12, 'y': 4, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 222, 'x': 19, 'y': 4, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 223, 'x': 21, 'y': 3, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 238, 'x': 11, 'y': 6, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 239, 'hide': 1, 'x': 13, 'y': 5, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 240, 'hide': 1, 'x': 18, 'y': 6, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 241, 'x': 21, 'y': 4, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 40}]
    )
    stage.createMine([
        {
            'idx': 0,
            'y': 14,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 1,
            'x': 17,
            'y': 13,
            'dir': 3 },
        {
            'idx': 2,
            'x': 17,
            'y': 14,
            'dir': 3 },
        {
            'idx': 3,
            'x': 10,
            'y': 2 },
        {
            'idx': 4,
            'x': 18,
            'y': 1 },
        {
            'idx': 5,
            'x': 19 },
        {
            'idx': 6,
            'x': 11,
            'y': 1 },
        {
            'idx': 7,
            'x': 17,
            'y': 1 },
        {
            'idx': 8,
            'x': 9,
            'y': 1 },
        {
            'idx': 9,
            'x': 1,
            'y': 15,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 10,
            'x': 1,
            'y': 13,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 11,
            'x': 1,
            'y': 14,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 12,
            'x': 1,
            'y': 12,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 13,
            'y': 13,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 14,
            'y': 15,
            'dir': 1,
            'hide': 1 }])
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(51, -1, 0, -1, 0, 11)
    stage.loadBg(38)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(2)
    stage.unit(51).setDir(stage.countDir(51, 5))
    stage.say('&51\n식량 공급이 이미 바닥난 상황을 고려하면,\n왜 판성의 수호자는 아직도 완강하게 버티고 있는 걸까?\n&51\n이로써 조조 증원군이 곧 도착할 거야.\n우리가 빨리 잡지 않으면......')
    stage.heightLight(17, 13, 17, 13)
    stage.unit(39).setDir(stage.countDir(39, 51))
    stage.say('&39\n왕 장군님, 걱정 마십시오.\n&39\n그 앞에는 판청이 너무 꽉 둘러싸여 물 한 방울도 새지 않을 정도였다,\n이 도시를 점령하는 것은 시간 문제일 뿐이다,\n게다가 조조 증원군이 이곳에 쉽게 접근할 수 없을 것이다.')
    stage.unit(53).setDir(stage.countDir(53, 39))
    stage.say('&53\n그럼에도 불구하고,\n조조 없는 증원군이 가장 이상적이었다.\n그래서 가능한 한 빨리 전면 공격을 개시하는 게 최선입니다.')
    stage.unit(49).setDir(stage.countDir(49, 53))
    stage.say('&49\n만약 증원군이 총공격 시점에 도착한다면,\n아군 포위 공격에 휘말릴 위험에 처할 수 있었다.\n&49\n증원군을 막기 위해,\n현재 편성은 여전히 최선의 전략입니다.\n&49\n무슨 일이 있어도, 증원군의 경로가 차단되는 한,\n만약 당신이 판성을 공격하는 데 집중한다면,\n그럼 승리는 우리 거야.')
    stage.unit(51).setDir(0)
    stage.unit(39).setDir(0)
    stage.unit(53).setDir(0)
    stage.unit(49).setDir(0)
    stage.unit(5).setDir(0)
    stage.unit(5).setDir(3)
    stage.unit(5).setDir(2)
    stage.unit(5).setAction(4)
    stage.say('&5\n판청은 너무 꽉 둘러싸여 한 사람도 통과할 수 없었다,\n주변 상황은 예측할 수 없다,\n정말 다른 방법이 없는 건가요......')
    stage.unit(25).setDir(stage.countDir(25, 5))
    stage.say('&25\n주군 증원군이 언제든 도착할 수 있다,\n지금 완전히 절망한다면, 끝난 거야.\n장군님, 잠시만 기다려 주세요!')
    stage.unit(9).setDir(stage.countDir(9, 46))
    stage.say('&9\n음, 상대가 물 공격을 쓸 줄은 몰랐네요.\n빨리 해결책을 내놓지 않으면 큰일 날 거야!\n조인 장군은 안전한지 궁금하네......')
    stage.unit(46).setDir(stage.countDir(46, 3))
    stage.say('&46\n아버지! 물을 막고 도시를 침수시키려는 계획이 성공했습니다.\n정말 멋져요!')
    stage.unit(3).setDir(stage.countDir(3, 46))
    stage.say('&3\n이제 남은 건 조의 군대를 공격하는 것뿐이었다.')
    stage.unit(14).setDir(stage.countDir(14, 47))
    stage.unit(14).setAction(2)
    stage.say('&14\n어, 이거 큰일 났어!\n이대로 가면 하나씩 패배할 거야.\n만약 그들이 포위망을 뚫지 못한다면적군 말이죠......')
    stage.unit(47).setDir(stage.countDir(47, 9))
    stage.unit(47).setAction(5)
    stage.say('&47\n방덕! 너는 옛 주인의 은혜를 잊었구나,\n그리고 적들에게 피신했고,\n정말 배은망덕한 하수인이야!')
    stage.unit(47).setAction(0)
    stage.unit(9).setDir(stage.countDir(9, 47))
    stage.say('&9\n흠!')
    stage.say('&47\n사무라이로서 자존심이 없구나!\n죽은 후 어떻게 마 텅 장군을 마주하겠어!')
    stage.say('&9\n음, 음!')
    stage.unit(14).setDir(stage.countDir(14, 9))
    stage.say('&14\n방덕Sir, 흥분하지 마!"\n이건 계획이야!')
    stage.unit(47).setAction(6)
    stage.say('&47\n나랑 경쟁하고 싶주창어?\n흥! 감히 그럴 수 없겠지?\n겁쟁이 배신자야!')
    stage.unit(47).setAction(0)
    stage.unit(9).setAction(2)
    stage.say('&9\n좋아!\n머리 씻고 기다려!')
    stage.unit(14).setAction(4)
    stage.say('&14\n(아, 안 돼! 통제 불능이 됐어......\n도대체 이 빌어먹을 주창은 게 뭐야......\n항상 불길한 예감이 들어요...... )')
    stage.unit(0, 1).show()
    stage.unit(9, 1).show()
    stage.unit(10, 1).show()
    stage.unit(11, 1).show()
    stage.unit(12, 1).show()
    stage.unit(13, 1).show()
    stage.unit(14, 1).show()
    stage.unit(66).setDir(2)
    stage.unit(66).setAction(1)
    stage.say('&66\n조조, 네 악행은 여기서 끝이야.\n오늘은 네 목을 가져갈 거야!')
    stage.unit(44).setDir(stage.countDir(44, 0))
    stage.say('&44\n조조 왔어!\n여기 통과시키지 않을 거야!')
    stage.unit(0).setDir(stage.countDir(0, 44))
    stage.say('&0\n완전히 포위되어 빠져나갈 길이 없다고?\n적의 포위망을 뚫는 게 쉽지 않을 것 같아.\n응.')
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 판성의 몰락.\n3. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[538] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[2] and not vars[7] and not vars[11] and stage.curCamp() == 2 and stage.round() == 20:
        stage.resumeCtrl()
        stage.talk(186, 186, '주님, 주군!\n곡식이 부족해 판청 주민들은,\n이미 적군 항복을 위한 폭동이 일어났다.')
        stage.say('&0\n정말......?\n아니면 구할 시간이 없었던 걸까?')
        vars[11] = 1
        stage.info('조조 유비군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[20] and stage.isInPos(1025, 14, 29):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 13, 29):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 7, 13):
        stage.getItem(152, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 7, 10):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 7, 16):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[2] and not vars[25] and stage.isInPos(1026, 17, 13):
        stage.resumeCtrl()
        stage.say('&0\n끝났어! 판청이 무너졌어.')
        if not vars[55]:
            stage.say('&51\n쉭!\n마침내 그들은 판청을 점령했다.')
        if not vars[56]:
            stage.unit(53).setDir(stage.countDir(53, 0))
            stage.say('&53\n조조, 네 죽음이 왔다!\n그냥 순종적으로 죽음을 받아들여라!')
        if not vars[57]:
            stage.say('&49\n이제 조조는 고립되고 무력해졌다,\n이 승리는 우리의 것이 될 운명입니다.')
        if not vars[58]:
            stage.say('&39\n조조 증원군만 모으면,\n전투는 끝났다.')
        vars[25] = 1
        stage.info('조조 유비군 앞에서 큰 패배를 당하고 후퇴했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[6] and not vars[7] and not vars[55] and stage.curCamp() == 2 and stage.totalRectUnit(0, 8, 10, 23, 31) >= 3:
        stage.say('&51\n음, 포위 진형이 곧 무너질 거야.\n유일한 선택지는 주력 부대를 동원해 판성을 공격하는 것뿐인 것 같다!')
        if not vars[56]:
            stage.say('&53\n서둘러!')
        if not vars[57]:
            stage.say('&49\n다른 방법은 없었다.\n군대 전체를 동원하라!')
        if not vars[58]:
            stage.say('&39\n만약 우리가 기운을 모아 한 번에 판성을 점령하지 못한다면,\n우리 상황은 위험해.\n서둘러!')
        stage.say('&0\n적군의 주력 세력이 행동을 시작했습니다,\n이대로라면 판청을 지키기 어려울 것이다,\n어떻게 해야 할까요?')
        sel = stage.choice('그리고 판청을 죽을 때까지 방어했다\n그리고 판청 방어를 포기했다', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n방법이 분명 있을 거야!\n무슨 일이 있어도 반드시 판청을 지켜야 해!\n빨리! 적군 판청에게 가까이 가지 못하게 해!')
            stage.unit(0).setAction(0)
            stage.unit(39).setAI(4, -1, 17, 13)
            stage.unit(49).setAI(4, -1, 17, 13)
            stage.unit(53).setAI(4, -1, 17, 13)
            stage.unit(258).setAI(4, -1, 17, 13)
            stage.unit(259).setAI(4, -1, 17, 13)
            stage.unit(282).setAI(4, -1, 17, 13)
            stage.unit(210).setAI(4, -1, 17, 13)
            stage.unit(211).setAI(4, -1, 17, 13)
            stage.unit(212).setAI(4, -1, 17, 13)
            stage.unit(213).setAI(4, -1, 17, 13)
            stage.unit(234).setAI(4, -1, 17, 13)
            stage.unit(235).setAI(4, -1, 17, 13)
        elif sel == 2:
            stage.unit(0).setDir(stage.countDir(0, 51))
            stage.unit(0).setAction(5)
            stage.say('&0\n다른 선택지가 없었다—판청을 포기하는 게 낫다!\n적을 물리친 후에는 다시 점령할 수 있습니다.\n작은 일로 큰 그림을 잃을 여유가 없습니다!')
            stage.unit(0).setAction(0)
            if not vars[56]:
                stage.unit(53).setDir(stage.countDir(53, 0))
                stage.unit(53).setAction(5)
                stage.say('&53\n응? 판청을 포기한 거야!?\n좋아, 상황이 우리에게 매우 유리해,\n계속 나아가 조조의 군대를 무너뜨리자!')
                stage.unit(53).setAction(0)
            if not vars[57]:
                stage.unit(49).setDir(stage.countDir(49, 0))
                stage.unit(49).setAction(5)
                stage.say('&49\n뜻밖에도 그는 판청을 포기했다,\n조조도 이 일로 고민하고 있겠지?\n지금이 바로 조조을 공격하기에 완벽한 시기입니다!')
                stage.unit(49).setAction(0)
            if not vars[58]:
                stage.unit(39).setDir(stage.countDir(39, 0))
                stage.unit(39).setAction(10)
                stage.say('&39\n뭐라고? 판청을 버린다고?\n이제 거의 끝나조조 것 같아요.\n더 세게 밀어!')
            stage.setUnitStatus([
                {
                    'status': 0,
                    'lift': 2,
                    'x1': 0,
                    'y1': 0,
                    'x2': 23,
                    'y2': 31,
                    'camp': 2 }])
            stage.say('&0\n그들이 우위를 점하게 하세요.')
            stage.setAI(0, 0, 23, 31, 2, 3, 0, 0, 0)
            stage.setMaxRound(30)
            stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('전부 전멸시적군!')
            vars[2] = 1
        vars[6] = 1
    if not vars[2] and not vars[7] and not vars[55] and stage.totalUnit(2) < 14 and stage.totalUnit(0) >= 8 and stage.curCamp() == 2:
        stage.unit(51).setDir(stage.countDir(51, 0))
        stage.unit(51).setAction(5)
        stage.say('&51\n아, 상황이 점점 악화되고 있어!\n우리가 판성을 점령하는 데 실패했으니,\n그리고 군대 전체가 전멸해서는 안 된다. 후퇴!')
        stage.unit(51).setAction(0)
        if not vars[56]:
            stage.unit(53).setDir(stage.countDir(53, 51))
            stage.say('&53\n내가 물러나길 원해!?\n정말 낙담스럽습니다......\n한숨, 다른 선택지가 없으니 후퇴하라!')
        if not vars[57]:
            stage.unit(49).setDir(stage.countDir(49, 51))
            stage.say('&49\n이것은 현명한 결정이었습니다.\n우리도 후퇴하자!')
        if not vars[58]:
            stage.unit(39).setAction(5)
            stage.say('&39\n빨리! 후퇴!')
            stage.unit(39).setAction(0)
        stage.setAI(0, 0, 23, 31, 2, 6, -1, 17, 31)
        stage.unit(0).setDir(stage.countDir(0, 51))
        stage.unit(0).setAction(5)
        stage.say('그들이 도망치게 두지 마세요! 그들을 섬멸해서, 그들이 판성을 공격할 생각을 못 하게 해야 합니다!')
        stage.unit(0).setAction(0)
        stage.setMaxRound(30)
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 판성의 몰락.\n3. 턴 수가 30명을 초과한다.')
        stage.showWinCondition('전부 전멸시적군!')
        vars[7] = 1
    if vars[7] and not vars[30] and stage.isInRect(1026, 0, 29, 23, 31):
        stage.setRectUnitHide(0, 29, 23, 31, 2)
    if not vars[40] and stage.isNear(9, 3, False):
        stage.unit(9).setDir(stage.countDir(9, 3))
        stage.unit(3).setDir(stage.countDir(3, 9))
        stage.say('&9\n이 문제를 해결합시다!\n&3\n좋아, 너랑 좀 만나자!')
        fight = stage.startFight(9, 3, 5)
        fight.showUnit(True, '나는 방덕, 링밍이라는 스타일이야.', 6)
        fight.showUnit(False, '나는 관우, 스타일 윤창이야!\n방덕Look 칼 앞에 있어!"', 9)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 3, True)
        fight.setAction(True, 2)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack1(False, 2, True)
        stage.delay(15)
        fight.setAction(True, 0)
        fight.say(True, '(흥미롭군. 무장으로서의 뜨거운 피가 끓어오르는구나!\n……하지만 지금 내 마음은 번성에 가 있다.\n더 이상 너와 싸울 여유가 없어……)', True)
        fight.setAction(True, 1)
        fight.say(True, '다른 방법은 없었다.\n여기서 멈추자!', True)
        fight.setAction(True, 3)
        fight.setAction(False, 3)
        fight.say(False, '대전투의 절정에서,\n왜 싸우지도 않고 도망쳤어?\n방덕Don 도망치지 마!', True)
        fight.setAction(True, 1)
        fight.say(True, '지금 두 군대는 여전히 치열한 전투 중이다,\n어떻게 너 때문에 이렇게 큰 일을 미룰 수 있겠어!', True)
        fight.setAction(False, 9)
        fight.say(False, '관도 같은 생각을 했다.\n그러나 너는 승패를 중요하게 여기지 않는다,\n그냥 가만히 있을 수 관우 없어!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 3)
        fight.setAction(False, 3)
        fight.say(True, '(반드시 이 자를 따돌려야 해……\n내가 번성을 구해야 해……번성이 날 기다리고 있어……)', True)
        fight.setAction(True, 1)
        fight.say(True, '아, 이번엔 용서해 주세요!', True)
        fight.attack1(True, 0, False)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.say(False, '아, 안 돼, 음, 이거 큰일이야!\n독화살에 중독된 거야......', True)
        fight.setAction(True, 8)
        fight.say(True, '다행히도 치명적인 부상은 아니었다,\n혹은 독이 몸 전체에 완전히 퍼지기 전에,\n전장을 빨리 떠나!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.setAction(False, 3)
        fight.say(False, '도망가지 마...... 안 돼!', False)
        fight.setAction(False, 12)
        fight.say(False, '아, 아......\n내 관우가 실제로 ......... 있을 거라고는 전혀 예상하지 못했다\n정말 오판이야!', True)
        fight.end()
        if not vars[51]:
            stage.unit(46).setDir(stage.countDir(46, 3))
            stage.say('&46\n아버지, 아버지!!')
        stage.say('&3\n다른 선택지가 없어, 지금은 후퇴해야 해!')
        stage.unit(3).hide()
        vars[40] = 1
    if not vars[42] and stage.isNear(9, 47, False):
        stage.unit(47).setDir(stage.countDir(47, 9))
        stage.unit(9).setDir(stage.countDir(9, 47))
        stage.say('&47\n자, 결전하자, 방덕!\n&9\n바로 그 생각이었어요!')
        fight = stage.startFight(9, 47, 5)
        fight.showUnit(False, '아직 장군의 자질이 남아 있네.\n주창 만나러 갈게!', 9)
        fight.showUnit(True, '천만에요!\n용기 있으면 어서!', 6)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(True, 4, True)
        fight.setAction(True, 1)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, True)
        fight.setAction(True, 1)
        fight.attack2(False, 0, True)
        fight.attack1(True, 2, True)
        stage.delay(10)
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.say(False, '(정말 대단한 인물이야……\n어쩔 수 없겠네. 원래 이렇게 할 생각은 아니었는데……)', True)
        stage.delay(5)
        fight.setAction(False, 8)
        fight.say(False, '하하하!\n방덕, 안타깝네!\n판청이 방금 붙잡혔어!', True)
        fight.setAction(True, 1)
        fight.say(True, '응!\n조인General!', True)
        fight.attack2(False, 1, False)
        stage.delay(5)
        fight.setAction(True, 11)
        fight.say(True, '음......\n아, 안 돼......', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '어때?\nme유비주군 따라가고 싶어?\n그럼 네 목숨은 살려줄 수 있어.', True)
        fight.say(False, '마초 장군도 현재 슈군 계급에 있습니다.\n아군에게 항복하는 게 낫겠어.', True)
        fight.setAction(True, 1)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 2, True)
        stage.delay(5)
        fight.setAction(True, 12)
        fight.say(True, '나, 내 주군은 단지 조 재상일 뿐이야,\n헛소리 그만해!', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '내 비열한 방법을 조롱해도 돼,\n하지만 정말 그렇게 죽고 싶어?', True)
        fight.say(True, '저는—우리가 군 장군이니까,\n주군의 명령에 복종할 것,\n때로는 비열한 수단을 써야 할 때도 있습니다.', True)
        fight.say(True, '자, 더 말해봐야 소용없어.\n나는 죽을 준비가 되어 있다.', True)
        fight.say(False, '마지막 할 말 있어......?', True)
        fight.say(True, '할 말 없어......\n그는 단지 총리와의 약속을 지키지 못했을 뿐이다......\n후회를 느끼고 있어......', True)
        stage.delay(5)
        fight.setAction(False, 8)
        fight.say(False, '목숨을 내놓아!', True)
        fight.setAction(False, 2)
        fight.attack2(False, 1, False)
        stage.delay(5)
        fight.setAction(True, 11)
        stage.delay(5)
        fight.say(True, '한숨, 조 재상님......\n먼저 가볼게......', True)
        fight.death(False)
        fight.setAction(False, 1)
        fight.say(False, '진정한 장군이라 용서해 주십시오,\n만약 어떤 적절도 위반이 있다면,\n언젠가 저승에서 너에게 사과할 수밖에 없을 거야.', True)
        fight.end()
        stage.unit(9).retreatTxt(False)
        stage.unit(9).hide(2)
        vars[738] = 1
        stage.unit(0).setDir(stage.countDir(0, 47))
        stage.unit(0).setAction(4)
        stage.say('&0\n방덕 아......\n천국은 왜 이런 거지......')
        vars[42] = 1
    if not vars[43] and stage.isNear(14, 47, True):
        stage.unit(47).setDir(stage.countDir(47, 14))
        stage.unit(14).setDir(stage.countDir(14, 47))
        stage.say('&47\n유진, 빨리 항복해!\n도망칠 곳이 없어!\n&14\n흠, 어떻게 이렇게 ...... 수 있지?')
        vars[43] = 1
    if vars[42] and not vars[44] and stage.isNear(0, 47, True):
        stage.unit(0).setDir(stage.countDir(0, 47))
        stage.unit(47).setDir(stage.countDir(47, 0))
        stage.say('&47\n조조 보이네.\n목숨을 내놓아!\n&0\n잠깐, 주창.\n네가 널 죽이는 거야방덕?\n&47\n맞아, 내가 해냈어.\n&0\n정말...... 그럼 방덕 죽은 거야?\n&47\n방덕 마지막 순간까지 너에게 충성할 거야,\n그의 죽음은 군사 장군의 모범으로 볼 수 있다.\n&0\n정말?\n방덕 일을 챙겨줘서 고마워,\n깊이 감사조맹덕.\n&47\n그래서, 죽을 준비 됐어?\n&0\n어떻게 그런 말이 나올 수 있지?\n방덕가 하얀 옷을 입고 죽는 것을 허락할 수 없으니,\n절대 네가 나한테 지는 걸 절대 못 해!')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n음, 후퇴!\n징저우 땅은 위나라와 오나라 사이에 있다,\n방어하기 어렵게 만들었다.\n&3\n그때부터 전장에서 달리거나 싸우는 대신,\n내정에 집중하고 방위를 강화하는 것이 더 나을 것입니다.')
        stage.unit(3).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(46, 7, 0, 2):
        stage.say('&46\n흠, 패배감.\n아직 무술에 능숙하지 않아요......\n&46\n먼저 무술을 열심히 수련하는 것이 더 낫습니다,\n네 마음속에서 진정으로 이해할 때까지,\n다시 전장에서 싸우자.')
        stage.unit(46).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(47, 7, 0, 2):
        stage.say('&47\n길을 잃었어.\n그는 자신의 기술을 완전히 익히지 못한 것만 탓했다!\n&47\n이번에는 돌아왔을 때 도시 방어에 집중해야 했다,\n스스로를 다시 훈련하세요.')
        stage.unit(47).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(66, 7, 0, 2):
        stage.say('&66\n지금은 후퇴할 수밖에 없는 것 같군!')
        stage.unit(66).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(44, 7, 0, 2):
        stage.say('&44\n젠장! 진짜 졌어.\n철회하고 다시 시도해!')
        stage.unit(44).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(51, 7, 0, 2):
        stage.say('&51\n와!\n전쟁에 적합하지 않은 것 같아.\n도시에 머물면서 내부 업무를 관리하는 게 낫지.')
        stage.unit(51).hide(2)
        stage.getItem(118, -1, True, 1027)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(53, 7, 0, 2):
        stage.say('&53\n흠, 이곳에서 죽을 순 없어.\n후퇴!')
        stage.unit(53).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(49, 7, 0, 2):
        stage.say('&49\n안 돼, 안 돼......\n가장 좋은 전략은 36가지 전략을 들고 도망치는 것입니다!')
        stage.unit(49).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(39, 7, 0, 2):
        stage.say('&39\n후퇴, 후퇴!')
        stage.unit(39).hide(1)
        vars[58] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 제거했어!\n아군 이겼어!')
        if not vars[2]:
            stage.reward()
        else:
            stage.reward(0, [
                160,
                -1])
        stage.end()
        vars[0] = 1
        vars[638] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비 앞에서 참담한 패배를 당했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
