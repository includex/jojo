# Source Generated with Decompyle++
# File: R_40.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 160, 76)
    stage.showHead(35, 96, 76)
    stage.bottomTxt('양평관에서 패배한 슈군', False, False, False)
    stage.delay(5)
    stage.head(35).move(40, 130)
    stage.delay(5)
    stage.bottomTxt('패배하여 지엔거로 도망쳤다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setEventName('계속 전진하세요')
    stage.setStageName('한중: 조조군의 본진')
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕, 성공했어!\n그들은 마침내 한중을 다시 붙잡았다.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n한중은 슈의 전략적 요충지였다.\n&19\n지금이 슈를 한 번에 결정적으로 쓸어버릴 때다.')
    stage.unit(19).setAction(0)
    stage.say('&0\n하지만 공명 서군의 주력군은 여전히 그곳에 있었다,\n문약, 지금 슈 군대는 어디에 있지?')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n네.\n한중의 장거에 요새를 세웠다,\n그리고 병력을 모았다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n정말? 그거 골치 아프네.')
    stage.unit(20).setAction(6)
    stage.say('&20\n지금 공격하면,\n상당한 피해를 견딜 정신적 준비가 되어 있어야 합니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n하지만 지금은 공격뿐이다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n흠.\n좋아, 군대는 강거로 행군하라.\n무슨 일이 있어도 우리는 촉군을 전멸시켜야 한다!')
    stage.unit(0).setAction(0)
    stage.unit(1).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        19])
    gvars[4076] = 0
    gvars[4057] = 40
    stage.setBattlePos([
        [
            18,
            1],
        [
            17,
            1],
        [
            18,
            2],
        [
            17,
            2],
        [
            19,
            2],
        [
            16,
            2],
        [
            19,
            1],
        [
            16,
            1],
        [
            20,
            1],
        [
            15,
            1],
        [
            18,
            0],
        [
            17,
            0],
        [
            19,
            0],
        [
            16,
            0],
        [
            15,
            0]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.delay(3)
        stage.clsUnit()
        stage.loadBg(1, 0)
        stage.draw()
        stage.showHead(0, 130, 77)
        stage.showHead(35, 38, 128)
        stage.bottomTxt('조의 군대', False, False, False)
        stage.delay(5)
        stage.head(0).move(102, 128)
        stage.delay(5)
        stage.bottomTxt('그리고 군대를 이끌고 지앙거로 진격했다.', True, False, True)
        stage.loadBg(2, 54)
        stage.showUnits([
            [
                35,
                53,
                37,
                2],
            [
                54,
                67,
                52,
                3],
            [
                53,
                67,
                58,
                3],
            [
                66,
                67,
                64,
                3],
            [
                34,
                42,
                52,
                1],
            [
                50,
                42,
                58,
                1],
            [
                69,
                42,
                64,
                1],
            [
                194,
                53,
                53,
                0,
                6]])
        stage.draw()
        stage.delay(3)
        stage.info('지금 이 순간에는......', 3)
        stage.setStageName('지건거는 류산 군대의 본거지입니다')
        stage.say('&35\n그래? 손권 외교 관계 복원에 동의했나?\n&194\n네.\n그는 두 나라가 연합해 조위를 물리치길 바란다고 말했다.')
        stage.unit(194).setAction(0)
        stage.say('&35\n흠.\n이 임무는 당신의 책임입니다,\n내려가서 쉬어.')
        stage.unit(194).setAction(6)
        stage.say('&194\n네.')
        stage.unit(194).setAction(0)
        stage.delay(3)
        stage.unit(194).move(53, 95, 2)
        stage.unit(194).hide()
        stage.say('&35\n위나라의 번영과 힘을 보고,\n손권도 좀 긴장할 거야.')
        stage.unit(69).setAction(6)
        stage.say('&69\n적어도 이렇게 하면 동우가 뒤에서 공격하지 않을 것이다.')
        stage.unit(69).setAction(0)
        stage.say('&35\n좋아,\n그 다음에는 장거에서 위나라 군대를 막아내기만 하면 됩니다.')
        stage.unit(53).setAction(0, 0)
        stage.say('&53\n하지만 총리는 총리입니다,\n위나라 군대도 이전에 양평관에서 큰 피해를 입었다.\n정말로 이곳을 공격하러 올까?\n&35\n분명히 그렇습니다.\n조조 공격 타이밍에 익숙하다,\n여기서 멀지 않아.')
        stage.unit(66).setAction(0, 0)
        stage.say('&66\n그렇게 빠른 걸까?')
        stage.unit(50).setAction(3)
        stage.say('&50\n쳇, 쳇, 너무 순진해.\n위나라 군대는 정말 여기서 멀지 않았다.')
        stage.unit(50).setAction(0)
        stage.delay(3)
        stage.unit(53).setAction(0, 3)
        stage.delay(3)
        stage.unit(66).setAction(0, 3)
        stage.say('&66\n흠')
        stage.showUnit(183, 53, 90)
        stage.say('&183\n신고됐어.')
        stage.say('&183\n위나라 군대는 도시 외곽 평야에 몇 리 떨어진 곳에 진을 쳤다.')
        stage.unit(35).setAction(17)
        stage.say('&35\n온다!\n모두가 자신의 직책을 지켰다,\n위나라 군대와 맞서 공격하기 위해서였다.')
        stage.unit(35).setAction(0)
        stage.say('&35\n(유비주군,\n너는 서나라를 me공명에게 맡겼다\n나는 위나라 군대를 반드시 무너뜨려야 한다. )')
        stage.bgSound(-1)
        stage.clsUnit()
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n앞에는 거대한 패스가 서 있다,\n그래서 공명 손에 지은 요새인 거구나.\n&0\n음, 공명 것도 꽤 인상적이네요.')
    if stage.unitClickTest(19):
        stage.say('&19\n첩보 보고서에 따르면,\n이곳을 점령하고 청두로 진격하려면,\n두 가지 장애물을 극복해야 합니다.\n&0\n음, 검문소가 두 군데?')
    if stage.unitClickTest(17):
        stage.say('&17\n슈로가 매우 위험한 산길이라고 들었어.')
    if stage.unitClickTest(15):
        stage.say('&0\n허저, 왜 그렇게 안절부절못해 보이니?\n&15\n응? 엉덩이가 좀 가려워.\n&17\n짜증나네요, 왜 이런 일이 일어나는 걸까요?\n제발, 잡지 마!\n&15\n하지만 어쩔 수 없었어요......')
    if stage.unitClickTest(21):
        stage.say('&21\n뜻밖에도, 국가의 생존을 걸린 전투에서,\n류산 본인은 직접 전투를 감독하지 않았다......\n&0\n흥, 아버지랑 멀리 떨어진 것 같네.')
    if stage.unitClickTest(1):
        stage.say('&1\n여기에는 우뚝 솟은 산들과 가파른 능선이 풍부하다,\n군인들은 고향이 그리워지기 시작했다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
