# Source Generated with Decompyle++
# File: S_45.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(19,19)',
        '(19,20)',
        '(20,19)',
        '(20,20)'])
    stage.nearEvent([
        0,
        35,
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(40, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 19, 'y': 20, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 76, 'x': 20, 'y': 20, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 79, 'x': 19, 'y': 19, 'dir': 0, 'lv': 6, 'i': 2},
         {'id': 350, 'x': 20, 'y': 19, 'dir': 0, 'lv': 0, 'i': 3},
         {'id': 69, 'x': 19, 'y': 17, 'dir': 0, 'lv': 6, 'i': 4},
         {'id': 351, 'x': 20, 'y': 17, 'dir': 0, 'lv': 0, 'i': 5},
         {'id': 88, 'x': 13, 'y': 19, 'dir': 3, 'lv': 4, 'i': 6},
         {'id': 352, 'x': 13, 'y': 20, 'dir': 3, 'lv': 0, 'i': 7},
         {'id': 78, 'x': 26, 'y': 19, 'dir': 1, 'lv': 6, 'i': 8},
         {'id': 353, 'x': 26, 'y': 20, 'dir': 1, 'lv': 0, 'i': 9},
         {'id': 85, 'x': 18, 'y': 14, 'dir': 0, 'lv': 6, 'i': 10},
         {'id': 83, 'x': 19, 'y': 14, 'dir': 0, 'lv': 4, 'i': 11},
         {'id': 92, 'x': 20, 'y': 14, 'dir': 0, 'lv': 4, 'i': 12},
         {'id': 258, 'x': 21, 'y': 14, 'dir': 0, 'lv': 0, 'i': 13},
         {'id': 210, 'x': 19, 'y': 13, 'dir': 0, 'lv': 0, 'i': 14},
         {'id': 211, 'x': 20, 'y': 13, 'dir': 0, 'lv': 0, 'i': 15},
         {'id': 81, 'x': 10, 'y': 12, 'dir': 3, 'lv': 6, 'i': 16},
         {'id': 86, 'x': 10, 'y': 14, 'dir': 3, 'lv': 4, 'i': 17},
         {'id': 96, 'x': 10, 'y': 13, 'dir': 3, 'lv': 4, 'i': 18},
         {'id': 82, 'x': 10, 'y': 11, 'dir': 3, 'lv': 4, 'i': 19},
         {'id': 212, 'x': 9, 'y': 12, 'dir': 3, 'lv': 0, 'i': 20},
         {'id': 213, 'x': 9, 'y': 13, 'dir': 3, 'lv': 0, 'i': 21},
         {'id': 72, 'x': 29, 'y': 14, 'dir': 1, 'lv': 6, 'i': 22},
         {'id': 71, 'x': 29, 'y': 13, 'dir': 1, 'lv': 4, 'i': 23},
         {'id': 73, 'x': 29, 'y': 12, 'dir': 1, 'lv': 4, 'i': 24},
         {'id': 390, 'x': 29, 'y': 11, 'dir': 1, 'lv': 0, 'i': 25},
         {'id': 214, 'x': 30, 'y': 12, 'dir': 1, 'lv': 0, 'i': 26},
         {'id': 215, 'x': 30, 'y': 13, 'dir': 1, 'lv': 0, 'i': 27},
         {'id': 298, 'x': 16, 'y': 10, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 299, 'x': 16, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 300, 'x': 23, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 301, 'x': 23, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 31},
         {'id': 302, 'x': 6, 'y': 9, 'lv': 0, 'ai': 0, 'i': 32},
         {'id': 303, 'x': 7, 'y': 9, 'lv': 0, 'ai': 0, 'i': 33},
         {'id': 304, 'x': 32, 'y': 9, 'lv': 0, 'ai': 0, 'i': 34},
         {'id': 305, 'x': 33, 'y': 9, 'lv': 0, 'ai': 0, 'i': 35},
         {'id': 306, 'x': 14, 'y': 16, 'lv': 0, 'ai': 0, 'i': 36},
         {'id': 307, 'x': 16, 'y': 16, 'lv': 0, 'ai': 0, 'i': 37},
         {'id': 308, 'x': 23, 'y': 16, 'lv': 0, 'ai': 0, 'i': 38},
         {'id': 309, 'x': 25, 'y': 16, 'lv': 0, 'ai': 0, 'i': 39},
         {'id': 234, 'x': 16, 'y': 11, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 40},
         {'id': 235, 'x': 23, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 41},
         {'id': 236, 'x': 5, 'y': 9, 'lv': 0, 'ai': 0, 'i': 42},
         {'id': 237, 'x': 8, 'y': 9, 'lv': 0, 'ai': 0, 'i': 43},
         {'id': 238, 'x': 31, 'y': 9, 'lv': 0, 'ai': 0, 'i': 44},
         {'id': 239, 'x': 34, 'y': 9, 'lv': 0, 'ai': 0, 'i': 45},
         {'id': 240, 'x': 15, 'y': 16, 'lv': 0, 'ai': 0, 'i': 46},
         {'id': 241, 'x': 24, 'y': 16, 'lv': 0, 'ai': 0, 'i': 47},
         {'id': 414, 'hide': 1, 'x': 18, 'y': 18, 'lv': 0, 'ai': 1, 'i': 48},
         {'id': 415, 'hide': 1, 'x': 18, 'y': 21, 'lv': 0, 'ai': 1, 'i': 49},
         {'id': 416, 'hide': 1, 'x': 21, 'y': 18, 'lv': 0, 'ai': 1, 'i': 50},
         {'id': 417, 'hide': 1, 'x': 21, 'y': 21, 'lv': 0, 'ai': 1, 'i': 51},
         {'id': 418, 'hide': 1, 'x': 18, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 52},
         {'id': 419, 'hide': 1, 'x': 19, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 420, 'hide': 1, 'x': 20, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 421, 'hide': 1, 'x': 21, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 422,
          'hide': 1,
          'x': 12,
          'y': 18,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 11,
          'targetY': 12,
          'i': 56},
         {'id': 423,
          'hide': 1,
          'x': 12,
          'y': 19,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 11,
          'targetY': 12,
          'i': 57},
         {'id': 424,
          'hide': 1,
          'x': 12,
          'y': 20,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 11,
          'targetY': 12,
          'i': 58},
         {'id': 425,
          'hide': 1,
          'x': 12,
          'y': 21,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 11,
          'targetY': 12,
          'i': 59},
         {'id': 426,
          'hide': 1,
          'x': 27,
          'y': 18,
          'dir': 1,
          'lv': 0,
          'ai': 4,
          'targetX': 28,
          'targetY': 12,
          'i': 60},
         {'id': 427,
          'hide': 1,
          'x': 27,
          'y': 19,
          'dir': 1,
          'lv': 0,
          'ai': 4,
          'targetX': 28,
          'targetY': 12,
          'i': 61},
         {'id': 428,
          'hide': 1,
          'x': 27,
          'y': 20,
          'dir': 1,
          'lv': 0,
          'ai': 4,
          'targetX': 28,
          'targetY': 12,
          'i': 62},
         {'id': 429,
          'hide': 1,
          'x': 27,
          'y': 21,
          'dir': 1,
          'lv': 0,
          'ai': 4,
          'targetX': 28,
          'targetY': 12,
          'i': 63},
         {'id': 216, 'hide': 1, 'x': 10, 'y': 17, 'dir': 0, 'lv': 0, 'i': 64},
         {'id': 217, 'hide': 1, 'x': 11, 'y': 17, 'dir': 0, 'lv': 0, 'i': 65},
         {'id': 218, 'hide': 1, 'x': 12, 'y': 17, 'dir': 0, 'lv': 0, 'i': 66},
         {'id': 219, 'hide': 1, 'x': 27, 'y': 17, 'dir': 0, 'lv': 0, 'i': 67},
         {'id': 220, 'hide': 1, 'x': 28, 'y': 17, 'dir': 0, 'lv': 0, 'i': 68},
         {'id': 221, 'hide': 1, 'x': 29, 'y': 17, 'dir': 0, 'lv': 0, 'i': 69}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 19,
            'y': 1 },
        {
            'idx': 1,
            'x': 1,
            'y': 20,
            'dir': 1 },
        {
            'idx': 2,
            'x': 38,
            'y': 19,
            'dir': 3 },
        {
            'idx': 3,
            'x': 20,
            'y': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 19,
            'dir': 1 },
        {
            'idx': 5,
            'x': 38,
            'y': 20,
            'dir': 3 },
        {
            'idx': 6,
            'x': 18,
            'y': 1 },
        {
            'idx': 7,
            'x': 1,
            'y': 21,
            'dir': 1 },
        {
            'idx': 8,
            'x': 38,
            'y': 18,
            'dir': 3 },
        {
            'idx': 9,
            'x': 21,
            'y': 1 },
        {
            'idx': 10,
            'x': 1,
            'y': 18,
            'dir': 1 },
        {
            'idx': 11,
            'x': 38,
            'y': 21,
            'dir': 3 },
        {
            'idx': 12,
            'x': 19 },
        {
            'idx': 13,
            'y': 20,
            'dir': 1 },
        {
            'idx': 14,
            'x': 39,
            'y': 19,
            'dir': 3 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.loadBg(45)
    stage.setObjects(True, 17, [
        [
            47,
            9,
            19],
        [
            47,
            9,
            20]])
    stage.setObjects(True, 17, [
        [
            49,
            12,
            9],
        [
            50,
            13,
            9]])
    stage.setObjects(True, 17, [
        [
            51,
            26,
            9],
        [
            52,
            27,
            9]])
    stage.setObjects(True, 17, [
        [
            45,
            30,
            19],
        [
            46,
            30,
            20]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab35')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab35')
    stage.draw()
    stage.bgSound(9)
    stage.unit(0).setDir(stage.countDir(0, 35))
    stage.say('&0\n마침내 마지막 순간이 왔다.\n우가 패배하면 더 이상 적은 없을 것이다.\n이것이 왕국 통일의 마지막 전투가 될 것이다!')
    stage.unit(0).setAction(5)
    stage.say('&0\n전면 돌격!\n모두가 용감히 싸워야 한다,\n혼란스러운 시대에 완벽한 결말을 써라!')
    stage.unit(0).setAction(0)
    stage.unit(79).setAction(4)
    stage.say('&79\n마침내 그들은 이 마지막 순간을 맞이하게 되었다.\n이렇게 그냥 항복할 거야?\n&76\n나는 아버지와 형제들의 뜻을 물려받았다,\n뜻밖에도 오늘 그 위대한 사업은 미완성으로 남았고, 그는 후회 속에 세상을 떠났다!\n조상들의 유산을 이어가며 끝까지 싸우게 해주세요.\n&35\n왜 천국은 조조를 헤게모니를 이루도록 선택했는가,\n그리고 유비 경과 손권 경이 아니라?\n이 최종 전투에서 그것을 명확히 보고 싶습니다.')
    stage.unit(69).setDir(stage.countDir(69, 35))
    stage.say('&69\n공명 사장님, 우리는 아직 포기할 수 없습니다.\n설령 내가, 장웨이가 목숨을 걸더라도,\n그들은 싸워서 빠져나가야 하고, 또 싸워서 빠져나가야 한다.')
    stage.unit(69).setDir(stage.countDir(69, 0))
    stage.unit(69).setAction(5)
    stage.say('&69\n나와! 나무 인형!')
    stage.unit(69).setAction(0)
    stage.unit(418).show()
    stage.unit(419).show()
    stage.unit(420).show()
    stage.unit(421).show()
    stage.unit(78).setAction(5)
    stage.say('&78\n주군...... 당신의 생각을 이해합니다.\n나노숙 함께 살고 죽게 해줘.\n시작해, 나무 남자.')
    stage.unit(78).setAction(0)
    stage.unit(426).show()
    stage.unit(427).show()
    stage.unit(428).show()
    stage.unit(429).show()
    stage.unit(88).setAction(5)
    stage.say('&88\n나는 절대 조조에게 굴복하지 않을 것이다.\n무슨 일이 있어도 현재의 난처를 뚫어야 했다.\n나무 인간 군대, 빨리 나와라!')
    stage.unit(88).setAction(0)
    stage.unit(422).show()
    stage.unit(423).show()
    stage.unit(424).show()
    stage.unit(425).show()
    stage.unit(85).setAction(2)
    stage.say('&85\n내가 링통이 여기 있는 한,\n선을 넘으려 생각도 하지 마!\n&92\n쏴, 쏴, 쏴! 모두 쏴라!\n&83\n동우 장군들의 용맹함을 보여라!')
    stage.unit(72).setDir(stage.countDir(72, 71))
    stage.say('&72\n마침내 생사가 걸린 순간이었다.')
    stage.unit(71).setDir(stage.countDir(71, 72))
    stage.say('&71\n위험이 있다면 빨리 도망쳐야 해.\n우리는 함께 살고 함께 죽었고,\n그는 이미 슈에게 정의를 다했으니 죽을 필요가 없었다.\n&72\n무슨 소리야? 네가 아니었다면, 왕이,\n어떻게 해야 하지! 도망가야 할 사람은 너야.\n&71\n무슨 헛소리를 하는 거야! 나는 야만왕의 명예를 더럽히지 않기 위해 그렇게 한다,\n네가 여기 남아서 싸웠으니, 떠나야 할 사람이야!')
    stage.unit(72).setAction(4)
    stage.say('&72\n무슨 헛소리를 하는 거야!\n나는 너와 삶과 죽음을 나누고 싶어.')
    stage.unit(73).setDir(stage.countDir(73, 72))
    stage.say('&73\n정말 너희들 이해가 안 돼,\n이 싸움에서 이기면 충분하지 않나요?')
    stage.unit(72).setDir(stage.countDir(72, 73))
    stage.say('&72\n하하하.\n맞아요, 안절부절 못하는 건 소용없어요.\n여러분, 기운 내세요!')
    stage.unit(81).setAction(5)
    stage.say('&81\n갑옷을 입고 검을 휘두르라!\n우리는 끝까지 온 힘을 다해 싸워야 한다!\n궁극적인 승리는 분명 우리 몫일 것이다.')
    stage.unit(81).setAction(0)
    stage.say('&82\n어쨌든 방법이 있을 거야.\n하지만 싸움만이 앞으로 나아갈 길인 것 같다.\n&96\n적은 이전 전투부터 지금까지 끊임없이 싸워왔다,\n오직 장기적인 싸움을 해야만 희망을 가질 수 있는 것 같습니다.\n&86\n이 상황에서는 우리가 언급조차 할 가치가 없어요.')
    stage.bgSound(10)
    stage.setWinCondition('승리 조건\n1. 제갈량와 손권을 격파한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 40명을 초과한다.')
    stage.showWinCondition('제갈량 손권 쓰러뜨려라!')
    stage.unit(35).heightLight()
    stage.unit(76).heightLight()
    stage.startOper()
    vars[545] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if stage.round() >= 1:
        if not vars[33]:
            stage.setAI(11, 11, 12, 14, 2, 1)
            stage.setAI(27, 11, 28, 14, 2, 1)
        else:
            stage.setAI(0, 0, 39, 23, 2, 1)
            stage.unit(35).setAI(2)
    if not vars[70] and stage.round() == 6:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[70] = 1
    if not vars[71] and stage.round() == 9:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[71] = 1
    if not vars[72] and stage.round() == 12:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[72] = 1
    if not vars[73] and stage.round() == 15:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[73] = 1
    if not vars[74] and stage.round() == 18:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[74] = 1
    if not vars[75] and stage.round() == 21:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[75] = 1
    if not vars[76] and stage.round() == 24:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[76] = 1
    if not vars[77] and stage.round() == 27:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[77] = 1
    if not vars[78] and stage.round() == 30:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[78] = 1
    if not vars[79] and stage.round() == 33:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[79] = 1
    if not vars[80] and stage.round() == 36:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[80] = 1
    if not vars[81] and stage.round() == 39:
        if vars[33] and not vars[50]:
            stage.unit(414).show(18, 18, 2)
            stage.unit(415).show(18, 21, 2)
            stage.unit(416).show(21, 18, 2)
            stage.unit(417).show(21, 21, 2)
        if not vars[51]:
            stage.unit(418).show(18, 16, 0)
            stage.unit(419).show(19, 16, 0)
            stage.unit(420).show(20, 16, 0)
            stage.unit(421).show(21, 16, 0)
        if not vars[57]:
            stage.unit(422).show(12, 18, 3)
            stage.unit(423).show(12, 19, 3)
            stage.unit(424).show(12, 20, 3)
            stage.unit(425).show(12, 21, 3)
        if not vars[58]:
            stage.unit(426).show(27, 18, 1)
            stage.unit(427).show(27, 19, 1)
            stage.unit(428).show(27, 20, 1)
            stage.unit(429).show(27, 21, 1)
        vars[81] = 1
    if not vars[20] and stage.isInPos(1025, 19, 19):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 19, 20):
        stage.getItem(152, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 20, 19):
        stage.getItem(152, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 20, 20):
        stage.getItem(152, -1, True, 1025)
        vars[23] = 1
    if not vars[30] and not vars[33] and stage.isInRect(1025, 29, 11, 33, 14):
        if not vars[54]:
            stage.unit(72).setAction(5)
            stage.say('&72\n이것이 주융이 마지막으로 춤을 춘 순간이었다.\n여러분, 눈 깜빡이지 마세요!')
            stage.unit(72).setAction(0)
        if not vars[52]:
            stage.unit(71).setAction(5)
            stage.say('&71\n어서, 어서!\n나를 이기고 싶다면, 멍화, 나를 데려와라!')
            stage.unit(71).setAction(0)
        if not vars[53]:
            stage.say('&73\n좋아!\n내가 해야 할 일은 너를 이기는 것뿐이야.\n최선을 다할게요!')
        stage.setAI(29, 11, 31, 14, 2, 1)
        vars[30] = 1
    if not vars[31] and not vars[33] and stage.isInRect(1025, 18, 10, 21, 14):
        if not vars[59]:
            stage.unit(85).setAction(5)
            stage.say('&85\n적군 못 오게 해!\n무슨 일이 있어도 반드시 지켜야 해!')
            stage.unit(85).setAction(0)
        if not vars[60]:
            stage.unit(83).setAction(5)
            stage.say('&83\n저 녀석들 가까이 오지 못하게 해!\n우리는 지칠 때까지 죽을 때까지 싸워야 해!"')
            stage.unit(83).setAction(0)
        if not vars[61]:
            stage.say('&92\n죽고 싶으면 나한테 덤벼라!')
        stage.setAI(18, 12, 21, 14, 2, 1)
        vars[31] = 1
    if not vars[32] and not vars[33] and stage.isInRect(1025, 6, 11, 10, 14):
        if not vars[62]:
            stage.unit(81).setAction(2)
            stage.say('&81\n이제 생사가 걸린 순간을 맞이하며,\n또한 제 실력을 보여줄 육손 시간이기도 합니다.')
        if not vars[63]:
            stage.unit(86).setAction(5)
            stage.say('&86\n내가 너희 모두를 이길 거야.')
            stage.unit(86).setAction(0)
        if not vars[64]:
            stage.say('&96\n무슨 일이 있어도 우리는 버텨야 해......')
        if not vars[65]:
            stage.say('&82\n마침내 도착했습니다.\n방법을 찾아야 해......')
        stage.setAI(8, 11, 10, 14, 2, 1)
        vars[32] = 1
    if not vars[33] and stage.isInRect(1025, 13, 13, 26, 23):
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n우리는 절대 조조에게 굴복해서는 안 된다!\n나와! 나무 인형!\n조조 진짜 어떤 실력을 가지고 있는지 알려주세요!')
            stage.unit(35).setAction(0)
            stage.unit(414).show()
            stage.unit(415).show()
            stage.unit(416).show()
            stage.unit(417).show()
        if not vars[56]:
            stage.say('&79\n마침내 생사가 걸린 순간이었다.')
        if not vars[55]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.unit(76).setAction(5)
            stage.say('&76\n조조 진정한 영웅이야, 혼란스러운 시대를 지배하는 거지,\n하지만 그가 쉽게 왕좌를 차지하게 두진 않을 거야.\n나도 싸움에 합류할게!')
            stage.unit(76).setAction(0)
        stage.setAI(0, 0, 39, 23, 2, 1)
        stage.unit(35).setAI(2)
        vars[33] = 1
    if not vars[40] and stage.isNear(0, 35, True):
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&0\n공명, 순종적으로 항복해.\n상황이 이미 끝났다는 걸 알아야 해.\n&35\n어떻게 당신에게 절할 수 있겠습니까,\n너 정말 부주의해—조심해, 안 그러면 죽어!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n네가 용감한 아버지와 형제들이 있다는 걸 알아,\n그래서 쉽게 항복하지 않게 하려는 거죠.\n하지만 계속 저항하는 것은 무의미했다, 손권.\n&76\n아버지와 형제들은 분명히 저에게 깊은 영향을 주셨습니다,\n하지만 잊지 마세요, 한때 저는 혼란스러운 시기를 지배하고 싶었어요,\n항복은 단순히 불가능합니다.')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n여기서 끝내라, 나는 시골로 물러나겠다,\n조조 세상을 어떻게 다스리는지 보세요.\n안녕!')
        if vars[55]:
            stage.resumeCtrl()
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.say('&35\n그는 옳고 그름, 선과 악에 대해 묻지 않고, 오직 세상의 평화를 추구했다.\n이것이 바로 국민들이 추구하는 결과입니다.\n&35\n그래서 제가 끊임없이 조언을 해주고 있지만,\n그럼에도 하늘은 여전히 조조를 선택했다.\n&35\n조조 평화롭고 번영하는 시대를 이룰 수 있어야 합니다!\n그렇게 하면 시골에서 평화롭게 살 수 있었을 텐데.')
            stage.unit(35).hide()
            stage.unit(414).hide()
            stage.unit(415).hide()
            stage.unit(416).hide()
            stage.unit(417).hide()
            stage.bgSound(7)
            stage.say('&5\n휴, 드디어 끝난 거야?\n&20\n끝난 것 같아.\n&15\n성공했어요, 드디어 성공했어요!\n&14\n휴, 정말 힘든 싸움이었어요.\n&0\n우리가 또 이겼어.\n&1\n이렇게 하면 내외 문제도 없을 거야,\n세상은 결국 평화로워질 것이다.\n&2\n주군, 세상을 평안시킨 것을 축하합니다!\n&3\n총리님께 축하드립니다.\n&25\n주군, 지배를 달성한 것을 축하합니다.\n오늘은 정말 기쁜 날입니다!\n&11\n네, 축하해요, 축하해요!\n&10\n정말 기쁜 순간이야!\n&8\n나는 오래전부터 아버지가 분명 세상을 평정시킬 것임을 알고 있었다.\n&4\n아버지, 축하드립니다.\n&22\n펑샤오는 항상 주군가 위대한 일을 이룰 것이라 믿었다.\n&0\n하지만 아직 축하하기엔 너무 이르다.\n첫째, 우리는 약한 주변 세력을 진정해야 합니다,\n그래야만 진정한 왕국 통일이 이루어질 수 있다.\n&7\n주군 왜 이렇게까지 하는가,\n남은 새우 병사들과 게 장군들은 제거해야 장합 남았다!\n&9\n이런 사소한 일은 우리에게 맡겨라!\n&13\n간신히 살아남은 반군들은 곧 파괴될 것이다.\n&21\n남은 약한 그룹에 대해 걱정하지 마세요주군 주세요.\n&19\n무시해도 그들은 항복하러 올 것이다.\n&0\n하지만 더 중요한 것은,\n우리는 법을 엄격히 집행하고 세계에 평화를 가져와야 합니다.\n&23\n즉, 우리는 중요한 사명을 가지고 있습니다.\n저는 가후 전적으로 주군 지지하겠습니다.\n&24\n다음 임무는 공무원으로 일하는 것이었습니다.\n&18\n그때부터 우리의 발명과 혁신은 궁극적으로 사람들의 생계에 적용될 것입니다.\n&0\n요컨대, 앞으로도 모두가 계속 저를 도와주조조 바랍니다.\n좋아, 승리의 마음으로 수도로 돌아가자!\n&16\n이런 날을 보게 될 줄은 몰랐어,\n돌이켜보면, 정말 긴 여정이었어요.\n&12\n마침내 그날이 왔다,\n하지만 우리는 수많은 고난도 겪었습니다.\n&6\n정말 힘든 여정이에요.\n&17\n봉선,\n초선 마침내 세상에 평화를 보았다.\n이제부터 세상을 위해 최선을 다하겠습니다.')
            stage.reward(0, None, True)
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[645] = 1
            return True
        stage.unit(35).hide()
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        stage.say('&0\n그럼 그냥 손권 쓰러뜨려!')
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n공명 장군님, 제가 하급 장군으로서 무능했던 점 용서해 주십시오.\n장웨이는 의지와 힘이 있었...... 음, 음.')
        stage.unit(69).hide(2)
        stage.unit(418).hide()
        stage.unit(419).hide()
        stage.unit(420).hide()
        stage.unit(421).hide()
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(71, 7, 0, 2):
        if not vars[54]:
            stage.unit(72).setDir(stage.countDir(72, 71))
            stage.say('&72\n여보, 괜찮아!?\n빨리 도망쳐야 해!\n꼭 다시 달려갈게요......')
            stage.unit(71).setDir(stage.countDir(71, 72))
            stage.say('&71\n잊지 마, 우리는 여전히 남부를 함께 다스려야 해,\n살아서 돌아와야 해!')
        else:
            stage.say('&71\n음, 더 이상 싸울 수 없어!\n나는 아직 주융과 맹세가 있어.\n어떻게 이렇게 죽을 수 있지? 안녕!')
        stage.unit(71).hide()
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n그들은 버틸 수 없었다.\n남쪽으로 돌아가야겠어.')
        stage.unit(73).hide()
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(72, 7, 0, 2):
        if not vars[52]:
            stage.unit(71).setDir(stage.countDir(71, 72))
            stage.say('&71\n주롱!\n도망쳐! 주롱!\n널 죽게 두지 않을 거야!')
            stage.unit(72).setDir(stage.countDir(72, 71))
            stage.say('&72\n왕이라는 영광은 잊어버려,\n살아서 돌아와야 해.\n난 항상 널 기다릴 거야!\n&71\n좋아, 동의해!\n이 전투가 끝난 후,\n남쪽으로 돌아가 걱정 없는 시간을 즐기자.\n&72\n여보......\n분명히 할 수 있다고 믿습니다.')
        else:
            stage.say('&72\n멍화는 아직도 남쪽에서 나를 기다리고 있다. 후퇴!\n조조도 좋은 사람이지만,\n하지만 제 남편 멍화는 여전히 최고예요.')
        stage.unit(72).hide()
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n안타깝네. 이렇게 전장에서 죽고 싶지만,\n불행히도 나는 여전히 가시를 견디고 아버지와 형제들 앞에서 용서를 구해야 한다,\n먼저 전장을 떠나는 게 낫다.')
        if vars[50]:
            stage.resumeCtrl()
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.say('&76\n조조, 당신은 내 손권 야망을 빼앗았을 뿐만 아니라,\n또한 혼란스러운 시대에 성공하려는 제 야망도 삼켜버렸습니다.\n&76\n만약 미래에 국민에게 이익이 되는 나라를 세운다면,\n절대 용서하지 않을 손중모.')
            stage.unit(76).hide()
            stage.bgSound(7)
            stage.say('&5\n휴, 드디어 끝난 거야?\n&20\n끝난 것 같아.\n&15\n성공했어요, 드디어 성공했어요!\n&14\n휴, 정말 힘든 싸움이었어요.\n&0\n우리가 또 이겼어.\n&1\n이렇게 하면 내외 문제도 없을 거야,\n세상은 결국 평화로 돌아올 것이다.\n&2\n주군, 세상을 평안시킨 것을 축하합니다!\n&3\n총리님께 축하드립니다.\n&25\n주군, 지배를 달성한 것을 축하합니다.\n오늘은 정말 기쁜 날입니다!\n&11\n네, 축하해요, 축하해요!\n&10\n정말 기쁜 순간이야!\n&8\n나는 오래전부터 아버지가 분명 세상을 평정시킬 것임을 알고 있었다.\n&4\n아버지, 축하드립니다.\n&22\n펑샤오는 항상 주군가 위대한 일을 이룰 것이라 믿었다.\n&0\n하지만 아직 축하하기엔 너무 이르다.\n첫째, 우리는 약한 주변 세력을 진정해야 합니다,\n그래야만 진정한 왕국 통일이 이루어질 수 있다.\n&7\n주군 왜 이렇게까지 하는가,\n남은 새우 병사들과 게 장군들은 제거해야 장합 남았다!\n&9\n이런 사소한 일은 우리에게 맡겨라!\n&13\n간신히 살아남은 반군들은 곧 파괴될 것이다.\n&21\n남은 약한 그룹에 대해 걱정하지 마세요주군 주세요.\n&19\n무시해도 그들은 항복하러 올 것이다.\n&0\n하지만 더 중요한 것은,\n우리는 법을 엄격히 집행하고 세계에 평화를 가져와야 합니다.\n&23\n즉, 우리는 중요한 사명을 가지고 있습니다.\n저는 가후 전적으로 주군 지지하겠습니다.\n&24\n다음 임무는 공무원으로 일하는 것이었습니다.\n&18\n그때부터 우리의 발명과 혁신은 궁극적으로 사람들의 생계에 적용될 것입니다.\n&0\n요컨대, 앞으로도 모두가 계속 저를 도와주조조 바랍니다.\n좋아, 승리의 마음으로 수도로 돌아가자!\n&16\n이런 날을 보게 될 줄은 몰랐어,\n돌이켜보면, 정말 긴 여정이었어요.\n&12\n마침내 그날이 왔다,\n하지만 우리는 수많은 고난도 겪었습니다.\n&6\n정말 힘든 여정이에요.\n&17\n봉선,\n초선 마침내 세상에 평화를 보았다.\n이제부터 세상을 위해 최선을 다하겠습니다.')
            stage.reward(0, None, True)
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[645] = 1
            return True
        stage.unit(76).hide()
        stage.say('&0\n그럼 그냥 공명 쓰러뜨려!')
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n여기서 죽게 되는 건가요?\n내가 first......주군......공명를 떠날게......')
        stage.unit(79).hide(2)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n안타깝네, 주군......!')
        stage.unit(88).hide(2)
        stage.unit(422).hide()
        stage.unit(423).hide()
        stage.unit(424).hide()
        stage.unit(425).hide()
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n흠, 내 죽음의 시간이 왔구나......\n절대 안 돼.')
        stage.unit(78).hide(2)
        stage.unit(426).hide()
        stage.unit(427).hide()
        stage.unit(428).hide()
        stage.unit(429).hide()
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n끝까지 버티고 싸울 수 있는 자들,\n난 이미 매우 만족해...... 으윽!')
        stage.unit(85).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n혹시 제가 잘못된 길을 주군는 걸까요...... 말도 안 돼!')
        stage.unit(83).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n와아!')
        stage.unit(92).hide(2)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n내가 모든 임무를 다했으니,\n이제 나는 후회 없이 죽는다!\n정말 만족스러워...... 음.')
        stage.unit(81).hide(2)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n너—너 진짜 감히 ......\n좋지 않아...... 중요한 부위를 맞혔어......\n말도 안 돼!')
        stage.unit(86).hide(2)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n많이 아프지만 괜찮아, 아직 ......\n이-이게 뭐야...... 피? ……\n설마 나, 딩펑일까......... 설마!')
        stage.unit(96).hide(2)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n아직 죽고 싶지 않아!\n말도 안 돼!')
        stage.unit(82).hide(2)
        vars[65] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&5\n휴, 드디어 끝난 거야?\n&20\n끝난 것 같아.\n&15\n성공했어요, 드디어 성공했어요!\n&14\n휴, 정말 힘든 싸움이었어요.\n&0\n우리가 또 이겼어.\n&1\n이렇게 하면 내외 문제도 없을 거야,\n세상은 결국 평화로 돌아올 것이다.\n&2\n주군, 세상을 평안시킨 것을 축하합니다!\n&3\n총리님께 축하드립니다.\n&25\n주군, 지배를 달성한 것을 축하합니다.\n오늘은 정말 기쁜 날입니다!\n&11\n네, 축하해요, 축하해요!\n&10\n정말 기쁜 순간이야!\n&8\n나는 오래전부터 아버지가 분명 세상을 평정시킬 것임을 알고 있었다.\n&4\n아버지, 축하드립니다.\n&22\n펑샤오는 항상 주군가 위대한 일을 이룰 것이라 믿었다.\n&0\n하지만 아직 축하하기엔 너무 이르다.\n첫째, 우리는 약한 주변 세력을 진정해야 합니다,\n그래야만 진정한 왕국 통일이 이루어질 수 있다.\n&7\n주군 왜 이렇게까지 하는가,\n남은 새우 병사들과 게 장군들은 제거해야 장합 남았다!\n&9\n이런 사소한 일은 우리에게 맡겨라!\n&13\n간신히 살아남은 반군들은 곧 파괴될 것이다.\n&21\n남은 약한 그룹에 대해 걱정하지 마세요주군 주세요.\n&19\n무시해도 그들은 항복하러 올 것이다.\n&0\n하지만 더 중요한 것은,\n우리는 법을 엄격히 집행하고 세계에 평화를 가져와야 합니다.\n&23\n즉, 우리는 중요한 사명을 가지고 있습니다.\n저는 가후 전적으로 주군 지지하겠습니다.\n&24\n다음 임무는 공무원으로 일하는 것이었습니다.\n&18\n그때부터 우리의 발명과 혁신은 궁극적으로 사람들의 생계에 적용될 것입니다.\n&0\n요컨대, 앞으로도 모두가 계속 저를 도와주조조 바랍니다.\n좋아, 승리의 마음으로 수도로 돌아가자!\n&16\n이런 날을 보게 될 줄은 몰랐어,\n돌이켜보면, 정말 긴 여정이었어요.\n&12\n마침내 그날이 왔다,\n하지만 우리는 수많은 고난도 겪었습니다.\n&6\n정말 힘든 여정이에요.\n&17\n봉선,\n초선 마침내 세상에 평화를 보았다.\n이제부터 세상을 위해 최선을 다하겠습니다.')
        stage.reward(0, None, True)
        stage.end()
        vars[0] = 1
        vars[645] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 연합군 앞에서 참패를 당했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    if vars[0]:
        stage.jumpScene(115)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
