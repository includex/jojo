# Source Generated with Decompyle++
# File: R_45.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(0)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 406, 212)
    stage.showHead(76, 470, 212)
    stage.bottomTxt('오나라 군대는 러쉬관이라는 전략적 요충지를 점령했다', False, False, False)
    stage.delay(8)
    stage.head(76).move(513, 184)
    stage.delay(5)
    stage.bottomTxt('그들은 수도 건예로 후퇴했다.', True, False, False)
    stage.delay(10)
    stage.head(0).move(449, 184)
    stage.delay(10)
    stage.bottomTxt('수년간의 혼란의 상황', True, True, False)
    stage.delay(10)
    stage.bottomTxt('곧 끝나려 해.', True, False, True)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            8,
            44,
            58,
            1],
        [
            15,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setEventName('통일 전날 밤')
    stage.setStageName('조조군의 주영지인 락쉬 입구')
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n주군, 그날이 마침내 찾아왔다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n공명 이미 우리 주머니에 들어갔어.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n어떤 방식을 쓰든,\n끝까지 맹렬한 공격만 하면 돼.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n상대방도 같은 생각일 거야.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(8).setAction(0, 2)
    stage.say('&8\n아버지, 이것이 왕국을 평정하기 위한 마지막 전투입니다,\n제발 뭐라도 말해줘.')
    stage.say('&0\n유비, 원소, 그리고 많은 다른 영웅들,\n그 해에 이 전투가 목표이기도 했습니다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n우리의 마음은 그들의 열정과 야망으로 가득 차 있습니다,\n그렇다면 더 이상 말할 필요는 없습니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n남은 건 싸움뿐이야,\n그들의 소원을 들어줍시다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n네.\n모두가 같은 생각을 합니다.\n주군, 세상을 통합하는 길로 나아갑시다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n흠.\n싸울 준비해!')
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.unit(1).setAction(0, 1)
    stage.unit(8).setAction(0, 1)
    stage.unit(19).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 45
    stage.setBattlePos([
        [
            19,
            1],
        [
            1,
            20],
        [
            38,
            19],
        [
            20,
            1],
        [
            1,
            19],
        [
            38,
            20],
        [
            18,
            1],
        [
            1,
            21],
        [
            38,
            18],
        [
            21,
            1],
        [
            1,
            18],
        [
            38,
            21],
        [
            19,
            0],
        [
            0,
            20],
        [
            39,
            19]])
    return False


def scene1():
    if stage.unitClickTest(20):
        stage.say('&20\n지안예는 청두를 능가하는 거대한 도시입니다.\n&20\n성벽은 4층 구조로 이루어져 있습니다.\n진정으로 방어는 쉽지만 공격하기는 어려운 요새였다.\n&0\n방어는 쉽지만 공격하기는 어렵다고? 정말 그런가......?\n&20\n만약 아군 사실이라면,\n반드시 정복될 것입니다.')
    if stage.unitClickTest(8):
        stage.say('&8\n아버지, 이 전투는 왕국의 단합에 관한 것입니다,\n아이가 싸울 수 있도록 꼭 해주세요.')
    if stage.unitClickTest(19):
        stage.say('&0\n사마의, 현재 상황은 어때?\n&19\n이미 주군 색상으로 염색된 상태입니다.')
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 이제 네 세상을 볼 준비가 거의 됐어.')
    if stage.unitClickTest(21):
        stage.say('&21\n주군,\n지금이 길고 혼란스러운 시대를 끝내기에 완벽한 시기입니다.\n&0\n흠.')
    if stage.unitClickTest(15):
        stage.say('&0\n허저, 긴장돼?\n&15\n응?\nI ...... 난 ...... 별로 긴장하지 않아......\n&0\n아, 그거 좋네.')
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('좋습니다, 전투에 나갑니다!')
        stage.bgSound(-1)
        return True

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
