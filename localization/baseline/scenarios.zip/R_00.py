# Source Generated with Decompyle++
# File: R_00.marshal (Python 3.9)


def scene0():
    gvars[4029] = 0
    gvars[4059] = 1
    gvars[4064] = 1
    gvars[4088] = 1
    gvars[4073] = 1
    gvars[4071] = 1
    stage.info("1\n        [C3A☆ '삼국지 조조' 게임 가이드☆]\n\n—————————————————————————\n\n                ☆게임 설명서☆")
    gvars[4071] = 1
    stage.info('2[C3A [장비 성장 차트]]')
    gvars[4071] = 1
    stage.info('3 x s a b c\n합격 요건: 100 90 70 50 0\n자격 있는 성장 5 4 3 2 1\n\n완벽한 상태 100 90 100\n완벽한 성장 4 3 3')
    gvars[4071] = 1
    stage.info('4[C3A [능력 업그레이드 비율]]\n\n  [C28◇ 공격력 10% 상승, 20% 감소]\n  [C3A◇ 방어력 10% 상승, 20% 하락]\n  [C27 정신력 10% 상승, 20% 하락]\n  [C25◇ 폭발 20% 상승 20% 하락]\n  [C76◇사기 20% 상승 20% 하락]')
    gvars[4071] = 1
    stage.info('5[C3A [공로 모드 설명]]\n[C3A☆] [C28] 캐릭터 아바타를 클릭하면 업적을 확인할 수 있습니다.\n[C3A☆] 업그레이드가 필요한 능력은 미리 확인해야 합니다 [C28 체크박스]. 확인 후 해당 아이템을 획득합니다\n  공로를 획득하면 능력이 자동으로 1점씩 증가합니다. ([C28은 고급 점수 필요])\n[C3A☆] 메릿 모드 능력 제한은 [C28110]입니다.\n[C3A☆] [C28 힘 공로]: 물리 공격 하나당 힘 공로 포인트 1점을 얻는다.\n (명중 여부와 상관없이 유효하며, 반격도 효과적입니다)\n[C3A☆] [C28 명령 공로]: 물리 공격 당 1개의 리더십 공로를 얻습니다.\n (맞든 안 맞든 유효)\n[C3A☆] [C28 지능 공로]: 전략이나 중간 전략을 시전할 때마다 지능 공로가 1개씩 얻습니다.\n (타격 여부와 상관없이 효과적이며, 유익한 주문도 효과적입니다)\n[C3A☆] [C28 민첩성 메리트]: 더블 탭이나 물리 블록을 하면 매번 민첩 메리트가 1포인트 추가됩니다.\n[C3A☆] [C28 행운 공로]: 치명타 또는 전략 블록 하나당 행운 공로가 1개씩 추가됩니다\n[C3A☆] 적군 하나씩 막아낼 때마다 5개의 공로 점수가 1점씩 증가합니다.\n[C3A☆] 레벨을 클리어하면 우리 유닛의 각 능력은 공로 보상을 받고, 남은 턴\n  많이 가져갈수록 더 많은 공로 보상을 받게 됩니다. ([C28 비참여 및 후퇴 인원은 사용 불가])\n[C3A☆] 전략 [C28 "강화"] 상태에서 획득한 공로 점수 [C28 두 배].\n[C3A☆] 과일을 먹으면 해당 버프만 제공되며 다섯 가지 능력치는 증가하지 않습니다.')
    gvars[4071] = 1
    stage.info('6[C3A [단축키 설명]]\n[C3A☆]의 일부 단축키 기능은 [C28 메뉴 — 설정]을 통해 직접 설정할 수 있습니다.\n[C3A☆] 번호 [C280-4]: 단계 속도 변화; [C3A0]가 원래 속도이며, [C3A1-4]가 가속, [C3A1]이 가장 빠릅니다.\n[C3A☆] 번호 [C285]: 진영에 따라 다른 색상의 체력 바를 표시합니다.\n[C3A☆] 번호 [C286]: 문자 [C3ABUFF]와 [C28DEBUFF]를 표시합니다.\n[C3A☆] 번호 [C287]: 왼쪽 하단에 캐릭터 능력과 장비를 표시합니다.\n[C3A☆] 숫자 [C288]: 더블 히트의 치명타 확률과 카운터 관계를 표시합니다.\n[C3A☆] 번호 [C289]: 지형 적응 및 이동 비용을 표시합니다.\n[C3A☆] 문자 [C28A]: 턴 시작 시 자동으로 저장되며, 저장 시퀀스 881-900.\n[C3A☆] 문자 [C28B]: 속성 인터페이스는 모든 가능한 전략과 학습 수준을 표시합니다.\n[C3A☆] 글자 [C28C]: 공격자의 스트로크를 표시한다.\n[C3A☆] 문자 [C28D]: 자동 장착 시 강제 배치 불가의 장비를 제거하지 않습니다.\n[C3A☆] 문자 [C28E]: 아군 클릭 후 제어 불가능한 유닛 행동 명령이 표시됩니다.\n[C3A☆] 편지 [C28F]: 통제 불가능한 유닛을 클릭하면 다른 유닛에 대한 증오 수치를 표시한다.\n[C3A☆] 글자 [C28G]: 아군을 클릭한 후 빨간색으로 표시하고 적군 수 있습니다.\n[C3A☆] 문자 [C28H]: 업그레이드 정보를 표시합니다.\n[C3A☆] 문자 [C28Z]: 초가속, 그리고 Z 버튼을 눌러서 취소.\n[C3A☆] [C28Shift]: 스토리 대사를 전속력으로 건너뛰고, 숫자 0을 초기화하세요.\n[C3A☆] [C28 화살표 키]: S가 전장에 있을 때 창 화면 크기를 변경합니다.\n[C3A☆] [C28 왼쪽 키보드 + - 키]: BGM 볼륨 조절.')
    gvars[2226] = 40
    gvars[2227] = 15
    gvars[2228] = 3
    gvars[2229] = 10
    gvars[2230] = 10
    gvars[2231] = 40
    gvars[2232] = 20
    gvars[2233] = 20
    gvars[2234] = 50
    gvars[2235] = 50
    gvars[2236] = 40
    gvars[2237] = 99
    gvars[2238] = 40
    gvars[2239] = 99
    gvars[2240] = 4
    gvars[2241] = 3
    gvars[2242] = 3
    gvars[2243] = 100
    gvars[2244] = 100
    gvars[2245] = 100
    gvars[2246] = 100
    gvars[2247] = 30
    gvars[2248] = 3
    gvars[2249] = 3
    gvars[2250] = 101
    gvars[2251] = 102
    gvars[2252] = 3
    gvars[2253] = 30
    gvars[2254] = 2
    gvars[2255] = 40
    gvars[2256] = 40
    gvars[2257] = 50
    gvars[2258] = 3
    gvars[2259] = 3
    gvars[2260] = 20
    gvars[2261] = 40
    gvars[2262] = 50
    gvars[2263] = 30
    gvars[2264] = 3
    gvars[2265] = 3
    gvars[2266] = 2
    gvars[2267] = 50
    gvars[2268] = 10
    gvars[2269] = 70
    gvars[2270] = 150
    gvars[2271] = 3
    gvars[2272] = 3
    gvars[2273] = 3
    gvars[2274] = 50
    gvars[2275] = 30
    gvars[2276] = 13
    gvars[2277] = 15
    gvars[2278] = 30
    gvars[2279] = 3
    gvars[2280] = 40
    gvars[2281] = 103
    gvars[2282] = 30
    gvars[2283] = 3
    gvars[2284] = 3
    gvars[2285] = 3
    gvars[2286] = 10
    gvars[2287] = 50
    gvars[2288] = 4
    gvars[2289] = 3
    gvars[2290] = 3
    gvars[2291] = 3
    gvars[2292] = 5
    gvars[2293] = 3
    gvars[2294] = 3
    gvars[2295] = 8
    gvars[2296] = 30
    gvars[2297] = 3
    gvars[2298] = 3
    gvars[2299] = 4
    gvars[2300] = 12
    gvars[2301] = 50
    gvars[2302] = 104
    gvars[2303] = 5
    gvars[2304] = 30
    gvars[2305] = 12
    gvars[2306] = 3
    gvars[2307] = 15
    gvars[2308] = 105
    gvars[2309] = 15
    gvars[2310] = 99
    gvars[2311] = 3
    gvars[2312] = 6
    gvars[2313] = 4
    gvars[2314] = 60
    gvars[2315] = 30
    gvars[2316] = 3
    gvars[2317] = 3
    gvars[2318] = 3
    gvars[2319] = 107
    gvars[2320] = 108
    gvars[2321] = 109
    gvars[2322] = 110
    gvars[2323] = 111
    gvars[2324] = 112
    gvars[2325] = 40
    gvars[2326] = 50
    gvars[2327] = 113
    gvars[2426] = 35
    gvars[2427] = 21
    gvars[2428] = 35
    gvars[2429] = 7
    gvars[2430] = 7
    gvars[2431] = 7
    gvars[2432] = 35
    gvars[2433] = 42
    gvars[2434] = 70
    gvars[2435] = 70
    gvars[2436] = 210
    gvars[2437] = 210
    gvars[2438] = 21
    gvars[2439] = 7
    gvars[2440] = 7
    gvars[2441] = 70
    gvars[2442] = 7
    gvars[2443] = 70
    gvars[2444] = 70
    gvars[2445] = 70
    gvars[2446] = 70
    gvars[2447] = 70
    gvars[2448] = 70
    gvars[2449] = 210
    gvars[2450] = 70
    gvars[2451] = 70
    gvars[2452] = 70
    gvars[2453] = 70
    gvars[2454] = 70
    gvars[2455] = 105
    gvars[2456] = 105
    gvars[2457] = 105
    gvars[2458] = 21
    gvars[2459] = 210
    gvars[2460] = 210
    gvars[2461] = 210
    gvars[2462] = 70
    gvars[2463] = 210
    gvars[2464] = 210
    gvars[2465] = 35
    gvars[2466] = 70
    gvars[2467] = 70
    gvars[2468] = 70
    gvars[2469] = 210
    gvars[2470] = 210
    gvars[2471] = 70
    gvars[2472] = 210
    gvars[2473] = 70
    gvars[2474] = 70
    gvars[2475] = 70
    gvars[2476] = 70
    gvars[2477] = 70
    gvars[2478] = 70
    gvars[2479] = 70
    gvars[2480] = 105
    gvars[2481] = 35
    gvars[2482] = 35
    gvars[2483] = 105
    gvars[2484] = 7
    gvars[2485] = 35
    gvars[2486] = 7
    gvars[2487] = 70
    gvars[2488] = 70
    gvars[2489] = 70
    gvars[2490] = 210
    gvars[2491] = 7
    gvars[2492] = 7
    gvars[2493] = 7
    gvars[2494] = 70
    gvars[2495] = 70
    gvars[2496] = 210
    gvars[2497] = 210
    gvars[2498] = 105
    gvars[2499] = 70
    gvars[2500] = 35
    gvars[2501] = 70
    gvars[2502] = 35
    gvars[2503] = 7
    gvars[2504] = 70
    gvars[2505] = 210
    gvars[2506] = 70
    gvars[2507] = 70
    gvars[2508] = 7
    gvars[2509] = 210
    gvars[2510] = 210
    gvars[2511] = 35
    gvars[2512] = 210
    gvars[2513] = 70
    gvars[2514] = 210
    gvars[2515] = 210
    gvars[2516] = 210
    gvars[2517] = 210
    gvars[2518] = 210
    gvars[2519] = 210
    gvars[2520] = 210
    gvars[2521] = 210
    gvars[2522] = 210
    gvars[2523] = 210
    gvars[2524] = 35
    gvars[2525] = 7
    gvars[2526] = 7
    gvars[2527] = 70
    return False


def scene1():
    model.initLocalVar()
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setAmbition(50)
    stage.loadBg(2, 30)
    stage.setEventName('재능의 첫 징후')
    stage.draw()
    stage.effectSound(201, 0)
    stage.showUnit(181, 40, 5, 2)
    stage.unit(181).move(40, 15, 2)
    stage.showUnits([[0, 40, 5, 2], [157, 54, 95]])
    stage.unitsMove([[stage.unit(181), 40, 25, 2], [stage.unit(0), 40, 15, 2], [stage.unit(157), 54, 85, 0]])
    stage.showUnit(182, 40, 5, 2)
    stage.unitsMove([[stage.unit(181), 40, 45, 2], [stage.unit(0), 40, 35, 2], [stage.unit(182), 40, 25, 2], [stage.unit(157), 54, 65, 0]])
    stage.delay(3)
    stage.unit(181).setAction(0, 0)
    stage.say('&181\n대장님, 서둘러야 해요!\n&0\n알아!')
    stage.unitsMove([[stage.unit(181), 40, 60, 2], [stage.unit(0), 40, 50, 2], [stage.unit(182), 40, 40, 2], [stage.unit(157), 54, 50, 0]])
    stage.unit(0).setAction(0)
    stage.unit(181).setAction(0)
    stage.unit(182).setAction(0)
    stage.delay(3)
    stage.unit(157).setAction(0, 3)
    stage.say('&157\n잠시만 기다려 주세요!')
    stage.unit(181).setAction(0, 1)
    stage.say('&181\n이 신참은 누구야? 군인들을 막고 싶어?')
    stage.say('&0\n잠깐.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n선생님, 저한테 필요한 게 있나요?\n나는 정부 기병대의 지휘관이다,\n성은 조, 본명은 조, 자식 맹덕.')
    stage.unit(157).setAction(6)
    stage.say('&157\n사실, 네 모습이 평범한 사람들과 다르다는 걸 눈치챘어,\n그래서 나는 무심코 너에게 불렀어.')
    stage.unit(157).setAction(0)
    stage.say('&181\n야, 우리 대장한테 무례하게 굴지 마!')
    stage.unit(0).setAction(0, 2)
    stage.say('에이, 참견하지 마!')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n선생님, 표정 읽을 줄 아세요?\n&157\n네.\n&0\n흥미롭네요!\n내 얼굴이 어떻게 생겼을까?\n&157\n당신은 좋은 통치 시기에 유능한 장관입니다,\n하지만 앞으로 사람들은 널 교활한 영웅이라고 부를 거야.\n&181\n"너, 뭐라고 했어?"\n&0\n잠깐.\n&0\n선생님, 천국이 곧 혼란에 빠질 것이라는 말씀이신가요?\n&157\n하하, 이 노인은 그런 말 안 했어.\n&0\n노인은 숨길 필요가 없어.\n하지만 교활한 남자의 말은 .......')
    stage.effectSound(201, 255)
    stage.delay(3)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('바로 이게 제가 바라는 거예요\n이건 너무 이른 것 같아', 0)
    if sel == 1:
        stage.addAmbition(10)
        stage.bgSound(-1)
        vars[300] = 1
        stage.delay(3)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        stage.say('&0\n내가 남자로 태어났을 때부터,\n어려운 시기에, 악당은 내가 바라는 바로 그 존재다.')
        stage.unit(0).setAction(0)
        stage.say('&157\n그래서 그런 거구나. 사실 이 노인은 그냥 헛소리만 했어.\n진심으로 부탁드립니다, 선생님, 기분 나쁘게 생각하지 말아 주세요.\n&157\n그리고 나는 자리를 떠나 장군님께서 승리의 시작을 기원한다.')
        stage.unit(157).setAction(0)
    elif sel == 2:
        vars[300] = 0
        stage.addAmbition(-10)
        stage.bgSound(-1)
        stage.delay(3)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('...간웅이라고? 지금 단정 짓기엔 너무 이르지 않나.')
        stage.unit(157).setAction(6)
        stage.say('&157\n그래서 그런 거구나. 사실 이 노인은 그냥 헛소리만 했어.\n진심으로 부탁드립니다, 선생님, 기분 나쁘게 생각하지 말아 주세요.\n&157\n그리고 나는 자리를 떠나 장군님께서 승리의 시작을 기원한다.')
        stage.unit(157).setAction(0)
    stage.say('&157\n떠나기 전에 확인 좀 해야겠어요, 선생님\n당신의 취향과 스타일.')
    label('lab327')
    sel = stage.choice('[C28 클래식 모드]\n[C97 확장 모드]\n[C3A 선택 모드]\n모드 설명', 0)
    if sel == 1:
        vars[1001] = 1
        gvars[1] = 0
        gvars[2] = 100
        gvars[4054] = 1000
        stage.infoTransfer(0, '과일 재배 방식')
        gvars[4054] = 1001
        stage.infoTransfer(0, '여가')
        gvars[4054] = 1002
        stage.infoTransfer(0, '닫기 1')
        label('lab345')
        sel = stage.choice('훈련 모드 [[C28*.1000]]\n난이도 설정 [[C28*.1001*/2%]]\n능력 재계산 [[C28*.1002 재계산]]\n[C3A 게임 시작]', 0)
        if sel == 1:
            if gvars[1] == 0:
                gvars[1] = 1
                gvars[4039] = 1
                gvars[4047] = 1
                gvars[4074] = 1
                gvars[4075] = 1
                gvars[4054] = 1000
                stage.infoTransfer(0, '메릿 모드')
                goto('lab345')
            if gvars[1] == 1:
                gvars[1] = 0
                gvars[4039] = 0
                gvars[4047] = 0
                gvars[4074] = 0
                gvars[4075] = 0
                gvars[4054] = 1000
                stage.infoTransfer(0, '과일 재배 방식')
                goto('lab345')
        if sel == 2:
            if gvars[2] == 100:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 50)
                gvars[4076] = 0
                gvars[2] = 110
                gvars[4033] = 110
                gvars[4034] = 105
                gvars[4054] = 1001
                stage.infoTransfer(0, '보통')
                goto('lab345')
            if gvars[2] == 110:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 75)
                gvars[4076] = 0
                gvars[2] = 120
                gvars[4033] = 120
                gvars[4034] = 115
                gvars[4054] = 1001
                stage.infoTransfer(0, '어렵네요')
                goto('lab345')
            if gvars[2] == 120:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 100)
                gvars[4076] = 0
                gvars[2] = 130
                gvars[4033] = 130
                gvars[4034] = 125
                gvars[4054] = 1001
                stage.infoTransfer(0, '전문가들')
                goto('lab345')
            if gvars[2] == 130:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 25)
                gvars[4076] = 0
                gvars[2] = 100
                gvars[4033] = 100
                gvars[4034] = 100
                gvars[4054] = 1001
                stage.infoTransfer(0, '여가')
                goto('lab345')
        if sel == 3:
            if gvars[4094] == 0:
                gvars[4094] = 1
                gvars[4054] = 1002
                stage.infoTransfer(0, '활성화 1')
                goto('lab345')
            gvars[4094] = 0
            gvars[4054] = 1002
            stage.infoTransfer(0, '닫기 1')
            goto('lab345')
        if sel == 4:
            pass
    elif sel == 2:
        vars[1002] = 1
        vars[1011] = 1
        vars[1013] = 1
        vars[1021] = 1
        vars[1031] = 1
        vars[1041] = 1
        gvars[4035] = 1
        gvars[4063] = 1
        gvars[4065] = 1
        gvars[4066] = 1
        gvars[4081] = 1
        gvars[4088] = 1
        gvars[4094] = 1
        gvars[4076] = 1
        pvars[200] = 4293888
        stage.varOper(0, 200, 2, 0, 3)
        gvars[4076] = 0
        gvars[1] = 0
        gvars[2] = 100
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[6] = 0
        gvars[7] = 0
        gvars[4054] = 1000
        stage.infoTransfer(0, '과일 재배 방식')
        gvars[4054] = 1001
        stage.infoTransfer(0, '여가')
        gvars[4054] = 1005
        stage.infoTransfer(0, '고전적인 무작위성')
        gvars[4054] = 1006
        stage.infoTransfer(0, '닫기 1')
        label('lab509')
        sel = stage.choice('훈련 모드 [[C28*.1000]]\n난이도 설정 [[C28*.1001*/2%]]\n히트 타입 [[C28*.1005]]\n적 처치 보너스 [[C28*.1006 보너스]]\n[C25 옵션 설명]\n[C3A 게임 시작]', 0)
        if sel == 1:
            if gvars[6] == 0:
                gvars[6] = 1
                gvars[4039] = 0
                gvars[4047] = 0
                gvars[4074] = 0
                gvars[4075] = 1
                gvars[4054] = 1000
                stage.infoTransfer(0, '슈퍼 량궈')
                goto('lab509')
            if gvars[6] == 1:
                gvars[6] = 2
                gvars[4039] = 1
                gvars[4047] = 1
                gvars[4074] = 1
                gvars[4075] = 1
                gvars[4054] = 1000
                stage.infoTransfer(0, '메릿 모드')
                goto('lab509')
            if gvars[6] == 2:
                gvars[6] = 0
                gvars[4039] = 0
                gvars[4047] = 0
                gvars[4074] = 0
                gvars[4075] = 0
                gvars[4054] = 1000
                stage.infoTransfer(0, '과일 재배 방식')
                goto('lab509')
        if sel == 2:
            if gvars[2] == 100:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 50)
                gvars[4076] = 0
                gvars[2] = 110
                gvars[4033] = 110
                gvars[4034] = 105
                gvars[4054] = 1001
                stage.infoTransfer(0, '보통')
                goto('lab509')
            if gvars[2] == 110:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 75)
                gvars[4076] = 0
                gvars[2] = 120
                gvars[4033] = 120
                gvars[4034] = 115
                gvars[4054] = 1001
                stage.infoTransfer(0, '어렵네요')
                goto('lab509')
            if gvars[2] == 120:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 100)
                gvars[4076] = 0
                gvars[2] = 130
                gvars[4033] = 130
                gvars[4034] = 125
                gvars[4054] = 1001
                stage.infoTransfer(0, '전문가들')
                goto('lab509')
            if gvars[2] == 130:
                gvars[4076] = 1
                pvars[201] = 4369724
                stage.varOper(0, 201, 2, 0, 25)
                gvars[4076] = 0
                gvars[2] = 100
                gvars[4033] = 100
                gvars[4034] = 100
                gvars[4054] = 1001
                stage.infoTransfer(0, '여가')
                goto('lab509')
        if sel == 3:
            if gvars[1] == 0:
                gvars[1] = 1
                gvars[4077] = 0
                gvars[4017] = 30
                gvars[4018] = 85
                gvars[4054] = 1005
                stage.infoTransfer(0, '보장 최소 모드')
                goto('lab509')
            if gvars[1] == 1:
                gvars[1] = 2
                gvars[4077] = 2
                gvars[4017] = 55
                gvars[4018] = 1
                gvars[4054] = 1005
                stage.infoTransfer(0, '가스 수집 모드')
                goto('lab509')
            if gvars[1] == 2:
                gvars[1] = 0
                gvars[4077] = 2
                gvars[4017] = 0
                gvars[4018] = 0
                gvars[4054] = 1005
                stage.infoTransfer(0, '고전적인 무작위성')
                goto('lab509')
        if sel == 4:
            if gvars[4046] == 0:
                gvars[4046] = 1
                gvars[4054] = 1006
                stage.infoTransfer(0, '활성화 1')
                goto('lab509')
            gvars[4046] = 0
            gvars[4054] = 1006
            stage.infoTransfer(0, '닫기 1')
            goto('lab509')
        if sel == 5:
            label('lab665')
            sel = stage.choice('모드와 난이도\n히트 타입\n킬 보너스 포인트\n[C3A 반환 옵션]', 157)
            if sel == 1:
                stage.say('&157\n[C97 과일 훈련 모드] 클래식 모드를 선택하세요.\n[C26 슈퍼 열매]를 선택하면 [C28적군 성장]이 해제됩니다.\n[C26 슈퍼 과일]을 선택해 장비를 판매하면 [C28 과일 수량 x3]을 얻으세요.\n&157\n[C3A Merit Mode]를 선택하면 [C28적군 성장]이 해제됩니다.\n[C3A Merit Mode]를 선택하면 [C28 장비 자동 업그레이드]가 활성화됩니다.\n&157\n세 가지 모드 모두 [C28110] 캡 캡이 있습니다.\n둘 다 [C28 능력 재계산]과 [C28 브레이크 100 보너스]를 발동합니다.\n&157\n난이도 레벨은 네 가지가 있습니다.\n난이도 수준 [C28적군 성장 계수]는 다양합니다,\n[C3A 퍼센트]는 난이도에 따라 [C28적군 능력 보너스]를 나타냅니다.')
                goto('lab665')
            if sel == 2:
                stage.say('&157\n[C97 클래식 랜덤:]은 저장/불러오기 작업을 통해 사용할 수 있습니다\n히트와 블록 결과를 변경하세요.\n&157\n[C97 보장 모드:] [C28 저장/불러오 작업으로는 사용할 수 없음]\n타격과 블록 결과를 바꿔. 할 수 있어.\n[C28 캐릭터 행동 순서]를 변경하여 결과에 영향을 줍니다.\n&157\n추가로, 공격 명중률 [C28 초과 85% 보장 명중].\n공격 명중률 [C3A가 30% 미만이면 막음].\n&157\n[C97 가스 수집 모델:] 확률 사건에 대한 수학적 기대 축적 방법,\n확률이 발동되지 않으면 수학적 기대가 누적됩니다,\n누적이 100%에 도달하면 필연적으로 발동됩니다.\n&157\n간단히 말해, [C2850%] 치명타 확률 또는 두 배 명중률입니다,\n모든 [C282] 공격은 치명타나 콤보를 발동합니다.\n가스 수집 모드는 무작위 요인을 포함하지 않습니다.')
                goto('lab665')
            if sel == 3:
                stage.say('&157\n적을 물리친 수는 기록될 것입니다.\n일반 속성 인터페이스에서 볼 수 있습니다.\n&157\n적을 처치할 때마다 [C971%]의 능력이 증가합니다.\n적을 처치할 때마다 [C971% 최대 체력과 마나]가 증가합니다.\n적을 [C28,100]로 처치하고, 영구 [C97+1 이동력], [C3A는 한 번만 처치].')
                goto('lab665')
            if sel == 4:
                goto('lab509')
        if sel == 6:
            pass
    elif sel == 3:
        stage.say('&157\n너무 많은 [C28 랜덤 아이템]을 사용하면 경험에 해가 될 수 있습니다.')
        vars[1002] = 1
        gvars[4035] = 1
        gvars[4063] = 1
        gvars[4065] = 1
        gvars[4066] = 1
        gvars[4081] = 1
        gvars[4088] = 1
        gvars[4094] = 1
        gvars[4076] = 1
        pvars[200] = 4293888
        stage.varOper(0, 200, 2, 0, 3)
        gvars[4076] = 0
        gvars[1] = 0
        gvars[2] = 100
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[6] = 0
        gvars[7] = 0
        gvars[4054] = 1000
        stage.infoTransfer(0, '과일 재배 방식')
        gvars[4054] = 1001
        stage.infoTransfer(0, '여가')
        gvars[4054] = 1002
        stage.infoTransfer(0, '고전 군사 부대')
        gvars[4054] = 1003
        stage.infoTransfer(0, '고전 보물')
        gvars[4054] = 1004
        stage.infoTransfer(0, '캐릭터를 닫아요')
        gvars[4054] = 1005
        stage.infoTransfer(0, '고전적인 무작위성')
        gvars[4054] = 1006
        stage.infoTransfer(0, '닫기 1')
        gvars[4054] = 1007
        stage.infoTransfer(0, '군사 부서 폐쇄')
        gvars[4054] = 1008
        stage.infoTransfer(0, '  1')
        label('lab744')
        sel = stage.choice('훈련 모드 [[C28*.1000]]\n유닛 세팅 [[C28*.1002]] [C97*.1008]\n보물 설치 [[C28*.1003]]\n캐릭터 기술 [[C28*.1004 기술]]\n유닛 스킬 [[C28*.1007 특수 스킬]]\n[C3A 다음 페이지]', 0)
        if sel == 1:
            if gvars[6] == 0:
                gvars[6] = 1
                gvars[4039] = 0
                gvars[4047] = 0
                gvars[4074] = 0
                gvars[4075] = 1
                gvars[4054] = 1000
                stage.infoTransfer(0, '슈퍼 량궈')
                goto('lab744')
            if gvars[6] == 1:
                gvars[6] = 2
                gvars[4039] = 1
                gvars[4047] = 1
                gvars[4074] = 1
                gvars[4075] = 1
                gvars[4054] = 1000
                stage.infoTransfer(0, '메릿 모드')
                goto('lab744')
            if gvars[6] == 2:
                gvars[6] = 0
                gvars[4039] = 0
                gvars[4047] = 0
                gvars[4074] = 0
                gvars[4075] = 0
                gvars[4054] = 1000
                stage.infoTransfer(0, '과일 재배 방식')
                goto('lab744')
        if sel == 2:
            if gvars[3] == 0:
                gvars[3] = 1
                vars[1011] = 1
                vars[1012] = 0
                vars[1013] = 1
                gvars[4054] = 1002
                stage.infoTransfer(0, '2부대 확장')
                goto('lab744')
            if gvars[3] == 1:
                gvars[3] = 2
                vars[1011] = 0
                vars[1012] = 1
                vars[1013] = 1
                gvars[4054] = 1002
                stage.infoTransfer(0, '랜덤 부대 유형 2')
                gvars[4054] = 1008
                stage.infoTransfer(0, '신중히 선택하세요!')
                goto('lab744')
            if gvars[3] == 2:
                gvars[3] = 0
                vars[1011] = 0
                vars[1012] = 0
                vars[1013] = 0
                gvars[4054] = 1002
                stage.infoTransfer(0, '고전 군사 부대')
                gvars[4054] = 1008
                stage.infoTransfer(0, '  1')
                goto('lab744')
        if sel == 3:
            if gvars[4] == 0:
                gvars[4] = 1
                vars[1021] = 1
                vars[1022] = 0
                gvars[4054] = 1003
                stage.infoTransfer(0, '보물 확장')
                goto('lab744')
            if gvars[4] == 1:
                gvars[4] = 2
                vars[1021] = 0
                vars[1022] = 1
                gvars[4054] = 1003
                stage.infoTransfer(0, '무작위 효과')
                goto('lab744')
            if gvars[4] == 2:
                gvars[4] = 0
                vars[1021] = 0
                vars[1022] = 0
                gvars[4054] = 1003
                stage.infoTransfer(0, '고전 보물')
                goto('lab744')
        if sel == 4:
            if gvars[5] == 0:
                gvars[5] = 1
                vars[1031] = 1
                vars[1032] = 0
                gvars[4054] = 1004
                stage.infoTransfer(0, '캐릭터 확장하기')
                goto('lab744')
            if gvars[5] == 1:
                gvars[5] = 2
                vars[1031] = 0
                vars[1032] = 1
                gvars[4054] = 1004
                stage.infoTransfer(0, '무작위 등장인물')
                goto('lab744')
            if gvars[5] == 2:
                gvars[5] = 0
                vars[1031] = 0
                vars[1032] = 0
                gvars[4054] = 1004
                stage.infoTransfer(0, '캐릭터를 닫아요')
                goto('lab744')
        if sel == 5:
            if gvars[7] == 0:
                gvars[7] = 1
                vars[1041] = 1
                vars[1042] = 0
                gvars[4054] = 1007
                stage.infoTransfer(0, '부대 유형 확장 1')
                goto('lab744')
            if gvars[7] == 1:
                gvars[7] = 2
                vars[1041] = 0
                vars[1042] = 1
                gvars[4054] = 1007
                stage.infoTransfer(0, '무작위 부대 유형 1')
                goto('lab744')
            if gvars[7] == 2:
                gvars[7] = 0
                vars[1041] = 0
                vars[1042] = 0
                gvars[4054] = 1007
                stage.infoTransfer(0, '군사 부서 폐쇄')
                goto('lab744')
        if sel == 6:
            label('lab911')
            sel = stage.choice('난이도 설정 [[C28*.1001*/2%]]\n히트 타입 [[C28*.1005]]\n적 처치 보너스 [[C28*.1006 보너스]]\n[C25 옵션 설명]\n[C3A 이전 페이지로 돌아가기]\n[C97 설정 완료]', 0)
            if sel == 1:
                if gvars[2] == 100:
                    gvars[4076] = 1
                    pvars[201] = 4369724
                    stage.varOper(0, 201, 2, 0, 50)
                    gvars[4076] = 0
                    gvars[2] = 110
                    gvars[4033] = 110
                    gvars[4034] = 105
                    gvars[4054] = 1001
                    stage.infoTransfer(0, '보통')
                    goto('lab911')
                if gvars[2] == 110:
                    gvars[4076] = 1
                    pvars[201] = 4369724
                    stage.varOper(0, 201, 2, 0, 75)
                    gvars[4076] = 0
                    gvars[2] = 120
                    gvars[4033] = 120
                    gvars[4034] = 115
                    gvars[4054] = 1001
                    stage.infoTransfer(0, '어렵네요')
                    goto('lab911')
                if gvars[2] == 120:
                    gvars[4076] = 1
                    pvars[201] = 4369724
                    stage.varOper(0, 201, 2, 0, 100)
                    gvars[4076] = 0
                    gvars[2] = 130
                    gvars[4033] = 130
                    gvars[4034] = 125
                    gvars[4054] = 1001
                    stage.infoTransfer(0, '전문가들')
                    goto('lab911')
                if gvars[2] == 130:
                    gvars[4076] = 1
                    pvars[201] = 4369724
                    stage.varOper(0, 201, 2, 0, 25)
                    gvars[4076] = 0
                    gvars[2] = 100
                    gvars[4033] = 100
                    gvars[4034] = 100
                    gvars[4054] = 1001
                    stage.infoTransfer(0, '여가')
                    goto('lab911')
            if sel == 2:
                if gvars[1] == 0:
                    gvars[1] = 1
                    gvars[4077] = 0
                    gvars[4017] = 30
                    gvars[4018] = 85
                    gvars[4054] = 1005
                    stage.infoTransfer(0, '보장 최소 모드')
                    goto('lab911')
                if gvars[1] == 1:
                    gvars[1] = 2
                    gvars[4077] = 2
                    gvars[4017] = 55
                    gvars[4018] = 1
                    gvars[4054] = 1005
                    stage.infoTransfer(0, '가스 수집 모드')
                    goto('lab911')
                if gvars[1] == 2:
                    gvars[1] = 0
                    gvars[4077] = 2
                    gvars[4017] = 0
                    gvars[4018] = 0
                    gvars[4054] = 1005
                    stage.infoTransfer(0, '고전적인 무작위성')
                    goto('lab911')
            if sel == 3:
                if gvars[4046] == 0:
                    gvars[4046] = 1
                    gvars[4054] = 1006
                    stage.infoTransfer(0, '활성화 1')
                    goto('lab911')
                gvars[4046] = 0
                gvars[4054] = 1006
                stage.infoTransfer(0, '닫기 1')
                goto('lab911')
            if sel == 4:
                label('lab1031')
                sel = stage.choice('모드와 난이도\n부대 유형과 보물\n특수 효과 설명\n히트 타입\n킬 보너스 포인트\n[C3A 반환 옵션]', 157)
                if sel == 1:
                    stage.say('&157\n[C97 과일 훈련 모드] 클래식 모드를 선택하세요.\n[C26 슈퍼 열매]를 선택하면 [C28적군 성장]이 해제됩니다.\n[C26 슈퍼 과일]을 선택해 장비를 판매하면 [C28 과일 수량 x3]을 얻으세요.\n&157\n[C3A Merit Mode]를 선택하면 [C28적군 성장]이 해제됩니다.\n[C3A Merit Mode]를 선택하면 [C28 장비 자동 업그레이드]가 활성화됩니다.\n&157\n세 가지 모드 모두 [C28110] 캡 캡이 있습니다.\n둘 다 [C28 능력 재계산]과 [C28 브레이크 100 보너스]를 발동합니다.\n&157\n난이도 레벨은 네 가지가 있습니다.\n난이도 수준 [C28적군 성장 계수]는 다양합니다,\n[C3A 퍼센트]는 난이도에 따라 [C28적군 능력 보너스]를 나타냅니다.')
                    goto('lab1031')
                if sel == 2:
                    stage.say('&157\n[C97 클래식 부대 유형:] 아군과 적 유닛의 능력치 등급은 변함이 없습니다.\n[C97 확장 부대 유형:] 원래는 아군과 적군이 [C28 신규 부대 유형]으로 등장합니다.\n[C97 무작위 부대 유형:] 아군 적 장군의 부대 유형은 [C28 무작위]입니다.\n&157\n[C97 클래식 트레저:] 보물 효과는 변함이 없습니다.\n[C97 확장 유물:] 보물은 [C28 신 효과]를 적용합니다.\n[C97 무작위 효과:] 보물 효과는 [C28 무작위 생성]입니다.')
                    goto('lab1031')
                if sel == 3:
                    stage.say('&157\n[C97 캐릭터 스킬 확장:] 캐릭터는 [C28 프리셋] 특수 스킬을 사용합니다.\n[C97 랜덤 캐릭터:] 아군 적은 [C28 랜덤] 특수 스킬을 얻게 됩니다.\n&157\n[C97 유닛 확장 스킬:] 부대에 [C28 프리셋] 특수 스킬을 사용하세요.\n[C97 무작위 부대 유형:] 각 유닛 유형은 [C28 무작위] 특수 스킬을 얻습니다.')
                    goto('lab1031')
                if sel == 4:
                    stage.say('&157\n[C97 클래식 랜덤:]은 저장/불러오기 작업을 통해 사용할 수 있습니다\n히트와 블록 결과를 변경하세요.\n&157\n[C97 보장 모드:] [C28 저장/불러오 작업으로는 사용할 수 없음]\n타격과 블록 결과를 바꿔. 할 수 있어.\n[C28 캐릭터 행동 순서]를 변경하여 결과에 영향을 줍니다.\n&157\n추가로, 공격 명중률 [C28 초과 85% 보장 명중].\n공격 명중률 [C3A가 30% 미만이면 막음].\n&157\n[C97 가스 수집 모델:] 확률 사건에 대한 수학적 기대 축적 방법,\n확률이 발동되지 않으면 수학적 기대가 누적됩니다,\n누적이 100%에 도달하면 필연적으로 발동됩니다.\n&157\n간단히 말해, [C2850%] 치명타 확률 또는 두 배 명중률입니다,\n모든 [C282] 공격은 치명타나 콤보를 발동합니다.\n가스 수집 모드는 무작위 요인을 포함하지 않습니다.')
                    goto('lab1031')
                if sel == 5:
                    stage.say('&157\n적을 물리친 수는 기록될 것입니다.\n일반 속성 인터페이스에서 볼 수 있습니다.\n&157\n적을 처치할 때마다 [C971%]의 능력이 증가합니다.\n적을 처치할 때마다 [C971% 최대 체력과 마나]가 증가합니다.\n적을 [C28,100]로 처치하고, 영구 [C97+1 이동력], [C3A는 한 번만 처치].')
                    goto('lab1031')
                if sel == 6:
                    goto('lab911')
            if sel == 5:
                goto('lab744')
            if sel == 6:
                gvars[10] = 0
                if vars[1012]:
                    gvars[10] += 1
                if vars[1022]:
                    gvars[10] += 1
                if vars[1032]:
                    gvars[10] += 1
                if vars[1042]:
                    gvars[10] += 1
                if gvars[10] >= 2:
                    stage.say('&157\n너무 많은 [C28 랜덤 아이템]을 사용하면 경험에 해가 될 수 있습니다.\n현재 선택한 상태로 계속 사용할 수 있을까요?')
                    if stage.ask() == 0:
                        goto('lab744')
    elif sel == 4:
        stage.say('&157\n[C28 클래식 모드]: 가능한 한 클래식을 복원합니다.\n&157\n[C3A 확장 모드]: 캐릭터 부대 유형과 보물 효과가 완전히 변경되었습니다,\n동시에 캐릭터와 유닛 특수 스킬이 추가되었고, 레벨업 시 자동으로 재계산됩니다.\n능력치 성장이 [C285] 티어로 등등.\n&157\n[C3A 선택 모드]: 게임 콘텐츠를 자유롭게 설정할 수 있습니다, \r[C97 신규 부대], [C97 신규 보물] 등 추가\n또한 여러 개의 [C97 무작위 옵션]이 무료로 선택할 수 있습니다.\n&157\n유물 설명에 따르면 [C28 확장 효과]는 [C97 확장 모드]에서만 작동합니다.\n다른 모드에서는 [C28 효과명]에 따라 효과가 적용됩니다.\n&157\n[C28 클래식 모드] 및 [C3A 확장 모드]\n모든 면에서 큰 차이가 있습니다,\n두 게임은 완전히 다른 게임입니다!')
        goto('lab327')
    if vars[1042]:
        gvars[4076] = 1
        pvars[0] = 5273606
        gvars[0] = 0
        label('lab1114')
        if gvars[0] <= 250:
            stage.varOper(0, 0, 2, 0, 255)
            pvars[0] += 8
            gvars[0] += 1
            goto('lab1114')
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[0] = 5274367
        stage.varOper(0, 0, 2, 0, 1)
        gvars[4076] = 0
        stage.infoTransfer(5, '13\n3\n63\n곰 조련사 - 마비 공격')
        stage.infoTransfer(5, '15\n3\n71\n어스 퍼펫 - 카오스 공격')
        stage.infoTransfer(5, '16\n3\n70\n나무 인간 - 독 공격')
        stage.infoTransfer(5, '100\n3\n36\n댄서 - 주변 상태 회복')
        stage.infoTransfer(5, '135\n3\n66\n인챈트리스 - 모든 능력을 가진 정제된 지원')
        stage.infoTransfer(5, '88\n3\n67\n불멸자 - 특수 효과 모방')
        stage.infoTransfer(5, '57\n3\n72\n황제여—내가 최고로 군림하는 자다')
        stage.infoTransfer(5, '41\n3\n78\n근위 기병 - 전략 면역')
        stage.infoTransfer(5, '89\n3\n79\n데몬킹 - 특수 효과 마스킹')
        gvars[0] = 0
        pvars[1] = 4217744
        gvars[3] = 0
        gvars[4] = 0
        label('lab1148')
        if gvars[0] <= 79:
            gvars[4076] = 0
            gvars[1] = 0
            gvars[2] = 5273606
            gvars[4] = 0
            stage.infoTransfer(26, '157')
            if gvars[4025] == 21:
                goto('lab1148')
            if gvars[4025] == 22:
                goto('lab1148')
            if gvars[4025] == 36:
                goto('lab1148')
            if gvars[4025] == 49:
                goto('lab1148')
            if gvars[4025] == 67:
                goto('lab1148')
            if gvars[4025] >= 3 and gvars[4025] <= 5:
                goto('lab1148')
            if gvars[4025] >= 56 and gvars[4025] <= 57:
                goto('lab1148')
            if gvars[4025] >= 69 and gvars[4025] <= 70:
                goto('lab1148')
            if gvars[4025] >= 83 and gvars[4025] <= 84:
                goto('lab1148')
            if gvars[4025] >= 88 and gvars[4025] <= 89:
                goto('lab1148')
            if gvars[4025] >= 103 and gvars[4025] <= 111:
                goto('lab1148')
            if gvars[4025] >= 119 and gvars[4025] <= 127:
                goto('lab1148')
            if gvars[4025] >= 128 and gvars[4025] <= 156 and (model.random() < 70):
                goto('lab1148')
            gvars[3] = gvars[0]
            if gvars[3] >= 24 and gvars[3] <= 35:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 72:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            if gvars[4] == 0:
                if gvars[4025] >= 27 and gvars[4025] <= 28:
                    goto('lab1148')
                if gvars[4025] >= 39 and gvars[4025] <= 40:
                    goto('lab1148')
                if gvars[4025] >= 42 and gvars[4025] <= 43:
                    goto('lab1148')
                if gvars[4025] >= 45 and gvars[4025] <= 46:
                    goto('lab1148')
                if gvars[4025] >= 73 and gvars[4025] <= 80:
                    goto('lab1148')
                if gvars[4025] >= 92 and gvars[4025] <= 95:
                    goto('lab1148')
                if gvars[4025] >= 153 and gvars[4025] <= 156:
                    goto('lab1148')
                if gvars[4025] == 1:
                    goto('lab1148')
                if gvars[4025] == 58:
                    goto('lab1148')
                if gvars[4025] == 60:
                    goto('lab1148')
                if gvars[4025] == 70:
                    goto('lab1148')
                if gvars[4025] == 86:
                    goto('lab1148')
                if gvars[4025] == 102:
                    goto('lab1148')
                if gvars[4025] == 116:
                    goto('lab1148')
                if gvars[4025] == 130:
                    goto('lab1148')
                if gvars[4025] == 141:
                    goto('lab1148')
                if gvars[4025] == 147:
                    goto('lab1148')
            if gvars[4] == 1:
                if gvars[4025] >= 6 and gvars[4025] <= 17:
                    goto('lab1148')
                if gvars[4025] >= 20 and gvars[4025] <= 26:
                    goto('lab1148')
                if gvars[4025] >= 30 and gvars[4025] <= 31:
                    goto('lab1148')
                if gvars[4025] >= 37 and gvars[4025] <= 38:
                    goto('lab1148')
                if gvars[4025] >= 52 and gvars[4025] <= 53:
                    goto('lab1148')
                if gvars[4025] >= 62 and gvars[4025] <= 63:
                    goto('lab1148')
                if gvars[4025] >= 66 and gvars[4025] <= 68:
                    goto('lab1148')
                if gvars[4025] >= 96 and gvars[4025] <= 98:
                    goto('lab1148')
                if gvars[4025] >= 103 and gvars[4025] <= 104:
                    goto('lab1148')
                if gvars[4025] >= 111 and gvars[4025] <= 114:
                    goto('lab1148')
                if gvars[4025] == 29:
                    goto('lab1148')
                if gvars[4025] == 41:
                    goto('lab1148')
                if gvars[4025] == 44:
                    goto('lab1148')
                if gvars[4025] == 50:
                    goto('lab1148')
                if gvars[4025] == 55:
                    goto('lab1148')
                if gvars[4025] == 59:
                    goto('lab1148')
                if gvars[4025] == 72:
                    goto('lab1148')
                if gvars[4025] == 91:
                    goto('lab1148')
                if gvars[4025] == 99:
                    goto('lab1148')
                if gvars[4025] == 117:
                    goto('lab1148')
                if gvars[4025] == 128:
                    goto('lab1148')
                if gvars[4025] == 140:
                    goto('lab1148')
                if gvars[4025] == 145:
                    goto('lab1148')
                if gvars[4025] == 151:
                    goto('lab1148')
            gvars[1] = gvars[4025]
            gvars[1] *= 8
            gvars[1] += gvars[2]
            gvars[4076] = 1
            pvars[0] = gvars[1]
            stage.varOper(0, 1, 2, 4, 0)
            if stage.varTest(1, 0, 1, 0, 80):
                stage.varOper(0, 0, 2, 1, 1)
                if gvars[0] <= 57:
                    gvars[0] += 3
                else:
                    gvars[0] += 1
                goto('lab1148')
            goto('lab1148')
    if vars[1012]:
        gvars[0] = 0
        pvars[1] = 4217744
        label('lab1542')
        if gvars[0] <= 169:
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[1] *= 4
            gvars[1] += gvars[2]
            gvars[4] = 0
            stage.infoTransfer(26, '80')
            if gvars[4025] == 66 and model.random() < 60:
                goto('lab1542')
            if gvars[4025] == 67 and model.random() < 80:
                goto('lab1542')
            if gvars[4025] == 72 and model.random() < 80:
                goto('lab1542')
            if gvars[4025] == 73:
                goto('lab1542')
            if gvars[4025] == 78 and model.random() < 60:
                goto('lab1542')
            if gvars[4025] == 79 and model.random() < 80:
                goto('lab1542')
            gvars[5] = gvars[4025]
            if gvars[5] <= 59:
                gvars[5] %= 3
                gvars[4025] -= gvars[5]
            if gvars[0] >= 26:
                gvars[3] = gvars[4025]
                if gvars[3] >= 24 and gvars[3] <= 35:
                    gvars[4] = 1
                if gvars[3] >= 65 and gvars[3] <= 66:
                    gvars[4] = 1
                if gvars[3] == 69:
                    gvars[4] = 1
                if gvars[3] == 74:
                    gvars[4] = 1
                if gvars[3] == 0:
                    gvars[4] = 2
                if gvars[3] == 57:
                    gvars[4] = 2
                if gvars[3] == 67:
                    gvars[4] = 2
                if gvars[3] == 72:
                    gvars[4] = 2
                if gvars[3] == 79:
                    gvars[4] = 2
                gvars[6] = stage.unitAttr(gvars[0], 9)
                gvars[7] = stage.unitAttr(gvars[0], 10)
                gvars[8] = stage.unitAttr(gvars[0], 11)
                if gvars[4] == 2:
                    pass
                if gvars[6] >= 40 and gvars[8] <= 34 and (gvars[4] != 0):
                    goto('lab1542')
                if gvars[6] <= 34 and gvars[8] >= 40 and (gvars[4] != 1):
                    goto('lab1542')
            if gvars[4025] == 69:
                stage.infoTransfer(4, '20\n8\n*0\n유혹')
                stage.infoTransfer(4, '46\n5\n*0\n각성')
                stage.infoTransfer(4, '47\n25\n*0\n대각성')
                stage.infoTransfer(4, '39\n1\n*0\n작은 보충 자료')
                stage.infoTransfer(4, '40\n12\n*0\n훌륭한 물자')
                stage.infoTransfer(4, '41\n10\n*0\n증원 병력')
                stage.infoTransfer(4, '42\n20\n*0\n증원 병력')
                stage.infoTransfer(4, '43\n25\n*0\n전달')
                stage.infoTransfer(4, '86\n25\n*0\n소환 2')
                stage.infoTransfer(4, '44\n15\n*0\n제안')
                stage.infoTransfer(4, '45\n22\n*0\n그리고 제안된 전략들')
                stage.infoTransfer(4, '57\n30\n*0\n귀환')
                stage.infoTransfer(4, '71\n18\n*0\n정교하다')
                stage.infoTransfer(4, '74\n28\n*0\n방화')
            gvars[4076] = 1
            stage.varOper(0, 1, 2, 4, 4025)
            pvars[0] = gvars[1]
            stage.varOper(0, 0, 2, 1, 1)
            gvars[0] += 1
            goto('lab1542')
        gvars[2035] = 66
        gvars[2078] = 65
        gvars[2119] = 78
        gvars[0] = 0
        label('lab1717')
        if gvars[0] <= 25:
            model.unitJoin(gvars[0], 0, 2)
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[1] *= 4
            gvars[1] += gvars[2]
            gvars[4076] = 1
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            gvars[4] = 0
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 72:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            if gvars[4] == 0 and gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[4] == 1 and gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            gvars[0] += 1
            goto('lab1717')
        gvars[0] = 1
        label('lab1816')
        if gvars[0] <= 25:
            model.unitJoin(gvars[0], 255, -1)
            gvars[0] += 1
            goto('lab1816')
        gvars[0] = 1
        label('lab1824')
        if gvars[0] <= 25:
            model.unitJoin(gvars[0], 0, 0)
            gvars[0] += 1
            goto('lab1824')
        gvars[0] = 1
        label('lab1831')
        if gvars[0] <= 25:
            model.unitJoin(gvars[0], 255, -1)
            gvars[0] += 1
            goto('lab1831')
        gvars[0] = 0
        label('lab1841')
        if gvars[0] <= 169:
            stage.setFAvatar(gvars[0], 0)
            gvars[0] += 1
            goto('lab1841')
        stage.setFAvatar(35, 46)
        stage.setFAvatar(119, 73)
        if model.random() < 34:
            stage.setFAvatar(119, 91)
        elif model.random() < 50:
            stage.setFAvatar(119, 92)
    if vars[1032]:
        gvars[4076] = 2
        pvars[0] = 5273600
        gvars[0] = 0
        label('lab1874')
        if gvars[0] <= 250:
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 2
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 2
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 4
            gvars[0] += 1
            goto('lab1874')
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[0] = 5274367
        stage.varOper(0, 0, 2, 0, 1)
        gvars[4076] = 0
        gvars[0] = 0
        gvars[3] = 0
        gvars[4] = 0
        pvars[1] = 4217744
        label('lab1900')
        if gvars[0] <= 173:
            gvars[4076] = 0
            gvars[1] = 0
            gvars[2] = 5273600
            stage.infoTransfer(26, '157')
            if gvars[4025] == 36:
                goto('lab1900')
            if gvars[4025] == 49:
                goto('lab1900')
            if gvars[4025] == 67:
                goto('lab1900')
            if gvars[4025] >= 103 and gvars[4025] <= 111:
                goto('lab1900')
            if gvars[4025] >= 119 and gvars[4025] <= 127:
                goto('lab1900')
            if gvars[4025] == 56 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 57 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 83 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 84 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 88 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 89 and model.random() < 75:
                goto('lab1900')
            if gvars[4025] == 138 and model.random() < 50:
                goto('lab1900')
            if gvars[4025] >= 73 and gvars[4025] <= 80 and (model.random() < 66):
                goto('lab1900')
            if gvars[4025] >= 128 and gvars[4025] <= 156 and (model.random() < 70):
                goto('lab1900')
            gvars[3] = stage.unitAttr(gvars[0], 9)
            if gvars[3] <= 34:
                if gvars[4025] >= 6 and gvars[4025] <= 17:
                    goto('lab1900')
                if gvars[4025] >= 20 and gvars[4025] <= 26:
                    goto('lab1900')
                if gvars[4025] >= 30 and gvars[4025] <= 31:
                    goto('lab1900')
                if gvars[4025] >= 37 and gvars[4025] <= 38:
                    goto('lab1900')
                if gvars[4025] >= 52 and gvars[4025] <= 53:
                    goto('lab1900')
                if gvars[4025] >= 62 and gvars[4025] <= 63:
                    goto('lab1900')
                if gvars[4025] >= 66 and gvars[4025] <= 68:
                    goto('lab1900')
                if gvars[4025] >= 96 and gvars[4025] <= 98:
                    goto('lab1900')
                if gvars[4025] >= 103 and gvars[4025] <= 104:
                    goto('lab1900')
                if gvars[4025] >= 111 and gvars[4025] <= 114:
                    goto('lab1900')
                if gvars[4025] == 44:
                    goto('lab1900')
                if gvars[4025] == 55:
                    goto('lab1900')
                if gvars[4025] == 59:
                    goto('lab1900')
                if gvars[4025] == 72:
                    goto('lab1900')
                if gvars[4025] == 91:
                    goto('lab1900')
                if gvars[4025] == 99:
                    goto('lab1900')
                if gvars[4025] == 117:
                    goto('lab1900')
                if gvars[4025] == 128:
                    goto('lab1900')
                if gvars[4025] == 140:
                    goto('lab1900')
                if gvars[4025] == 145:
                    goto('lab1900')
                if gvars[4025] == 151:
                    goto('lab1900')
            if gvars[3] >= 35 and gvars[4025] == 22:
                goto('lab1900')
            gvars[3] = stage.unitAttr(gvars[0], 11)
            if gvars[3] <= 34:
                if gvars[4025] >= 27 and gvars[4025] <= 28:
                    goto('lab1900')
                if gvars[4025] >= 39 and gvars[4025] <= 40:
                    goto('lab1900')
                if gvars[4025] >= 42 and gvars[4025] <= 43:
                    goto('lab1900')
                if gvars[4025] >= 73 and gvars[4025] <= 80:
                    goto('lab1900')
                if gvars[4025] >= 92 and gvars[4025] <= 95:
                    goto('lab1900')
                if gvars[4025] >= 153 and gvars[4025] <= 156:
                    goto('lab1900')
                if gvars[4025] == 1:
                    goto('lab1900')
                if gvars[4025] == 46:
                    goto('lab1900')
                if gvars[4025] == 58:
                    goto('lab1900')
                if gvars[4025] == 60:
                    goto('lab1900')
                if gvars[4025] == 70:
                    goto('lab1900')
                if gvars[4025] == 86:
                    goto('lab1900')
                if gvars[4025] == 102:
                    goto('lab1900')
                if gvars[4025] == 116:
                    goto('lab1900')
                if gvars[4025] == 130:
                    goto('lab1900')
                if gvars[4025] == 141:
                    goto('lab1900')
                if gvars[4025] == 147:
                    goto('lab1900')
            if gvars[3] >= 40:
                if gvars[4025] == 29 and model.random() < 50:
                    goto('lab1900')
                if gvars[4025] == 41 and model.random() < 50:
                    goto('lab1900')
            if gvars[0] == 3 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] == 7 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] == 9 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] == 13 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] == 17 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] == 23 and gvars[4025] == 70:
                goto('lab1900')
            if gvars[0] >= 26:
                if gvars[4025] >= 3 and gvars[4025] <= 5:
                    goto('lab1900')
                if gvars[4025] == 21:
                    goto('lab1900')
                if gvars[4025] == 69:
                    goto('lab1900')
                if gvars[4025] == 70:
                    goto('lab1900')
                if gvars[4025] == 83:
                    goto('lab1900')
            if gvars[4074] == 0 and gvars[4025] == 69:
                goto('lab1900')
            gvars[1] = gvars[4025]
            gvars[1] *= 8
            gvars[1] += gvars[2]
            gvars[4076] = 2
            pvars[0] = gvars[1]
            stage.varOper(0, 1, 2, 4, 0)
            if stage.varTest(1, 0, 1, 0, 255):
                stage.varOper(0, 0, 2, 1, 1)
                if gvars[0] == 0:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 2:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 3:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 12:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 33:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 34:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 36:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 57:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 77:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 81:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 84:
                    if gvars[4] == 0:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 35:
                    if gvars[4] <= 1:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[0] == 119:
                    if gvars[4] <= 1:
                        gvars[4] += 1
                        goto('lab1900')
                    else:
                        gvars[4] = 0
                if gvars[4025] == 39:
                    stage.infoTransfer(4, '20\n3\n*0\n유혹')
                    stage.infoTransfer(4, '33\n1\n*0\n독성 연기')
                    stage.infoTransfer(4, '35\n4\n*0\n움직이지 못하게')
                if gvars[4025] == 40:
                    stage.infoTransfer(4, '0\n1\n*0\n화재')
                    stage.infoTransfer(4, '5\n2\n*0\n물')
                    stage.infoTransfer(4, '10\n3\n*0\n바람')
                    stage.infoTransfer(4, '15\n4\n*0\n지구')
                gvars[0] += 1
                goto('lab1900')
            else:
                pvars[0] += 2
                if stage.varTest(1, 0, 1, 0, 255):
                    stage.varOper(0, 0, 2, 1, 1)
                    if gvars[0] == 0:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 3:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 12:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 33:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 34:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 36:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 57:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 77:
                        if gvars[4] == 0:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 35:
                        if gvars[4] <= 1:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[0] == 119:
                        if gvars[4] <= 1:
                            gvars[4] += 1
                            goto('lab1900')
                        else:
                            gvars[4] = 0
                    if gvars[4025] == 39:
                        stage.infoTransfer(4, '20\n3\n*0\n유혹')
                        stage.infoTransfer(4, '33\n1\n*0\n독성 연기')
                        stage.infoTransfer(4, '35\n4\n*0\n움직이지 못하게')
                    if gvars[4025] == 40:
                        stage.infoTransfer(4, '0\n1\n*0\n화재')
                        stage.infoTransfer(4, '5\n2\n*0\n물')
                        stage.infoTransfer(4, '10\n3\n*0\n바람')
                        stage.infoTransfer(4, '15\n4\n*0\n지구')
                    gvars[0] += 1
                    goto('lab1900')
                else:
                    pvars[0] += 2
                    if stage.varTest(1, 0, 1, 0, 255):
                        stage.varOper(0, 0, 2, 1, 1)
                        if gvars[0] == 0:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 3:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 12:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 33:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 34:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 36:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 57:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 77:
                            if gvars[4] == 0:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 35:
                            if gvars[4] <= 1:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[0] == 119:
                            if gvars[4] <= 1:
                                gvars[4] += 1
                                goto('lab1900')
                            else:
                                gvars[4] = 0
                        if gvars[4025] == 39:
                            stage.infoTransfer(4, '20\n3\n*0\n유혹')
                            stage.infoTransfer(4, '33\n1\n*0\n독성 연기')
                            stage.infoTransfer(4, '35\n4\n*0\n움직이지 못하게')
                        if gvars[4025] == 40:
                            stage.infoTransfer(4, '0\n1\n*0\n화재')
                            stage.infoTransfer(4, '5\n2\n*0\n물')
                            stage.infoTransfer(4, '10\n3\n*0\n바람')
                            stage.infoTransfer(4, '15\n4\n*0\n지구')
                        gvars[0] += 1
                        goto('lab1900')
            goto('lab1900')
    if vars[1022]:
        gvars[4076] = 0
        gvars[1] = 0
        gvars[2] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[6] = 0
        gvars[7] = 0
        gvars[8] = 0
        gvars[9] = 0
        gvars[10] = 0
        gvars[11] = 0
        gvars[12] = 0
        gvars[13] = 0
        gvars[0] = 30
        gvars[1] = 2
        gvars[4] = 5268264
        gvars[5] = 5268680
        gvars[6] = 5269096
        gvars[8] = 5259976
        gvars[9] = 5260776
        label('lab2831')
        if gvars[0] <= 108:
            gvars[4076] = 0
            pvars[1] = 4217736
            gvars[2] = 4854854
            gvars[3] = gvars[0]
            gvars[3] -= 30
            gvars[3] *= 25
            gvars[3] += gvars[2]
            pvars[0] = gvars[3]
            gvars[4076] = 1
            if stage.varTest(1, 0, 0, 0, 1):
                if gvars[1] <= 103:
                    gvars[4076] = 0
                    label('lab2852')
                    stage.infoTransfer(26, '128')
                    if gvars[4025] == 123:
                        goto('lab2852')
                    if gvars[4025] >= 26:
                        gvars[10] = gvars[4025]
                        gvars[10] -= 26
                        gvars[10] *= 4
                        gvars[10] += gvars[9]
                        pvars[0] = gvars[10]
                        stage.varOper(2, 11, 2, 1, 0)
                        gvars[12] = gvars[4025]
                        if gvars[0] <= 48:
                            gvars[11] %= 2
                            if gvars[11] == 0:
                                stage.varOper(0, 1, 2, 4, 4025)
                            else:
                                goto('lab2852')
                        if gvars[0] >= 49 and gvars[0] <= 53:
                            gvars[11] %= 3
                            if gvars[11] == 0:
                                stage.varOper(0, 1, 2, 4, 4025)
                            else:
                                goto('lab2852')
                        if gvars[0] >= 75:
                            gvars[11] %= 5
                            if gvars[11] == 0:
                                stage.varOper(0, 1, 2, 4, 4025)
                            goto('lab2852')
                    else:
                        goto('lab2852')
                    pvars[1] += 1
                    label('lab2910')
                    stage.infoTransfer(26, '26')
                    if gvars[4025] >= 15:
                        stage.varOper(0, 1, 2, 4, 4025)
                    else:
                        goto('lab2910')
                    pvars[1] += 1
                    gvars[12] -= 26
                    gvars[12] *= 4
                    gvars[12] += gvars[8]
                    pvars[0] = gvars[12]
                    stage.varOper(2, 13, 2, 1, 0)
                    if gvars[13] == 3:
                        stage.varOper(0, 1, 2, 0, 3)
                    if gvars[13] == 4:
                        label('lab2933')
                        stage.infoTransfer(26, '5')
                        if gvars[4025] < 2:
                            goto('lab2933')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 5:
                        label('lab2942')
                        stage.infoTransfer(26, '5')
                        if gvars[4025] < 3:
                            goto('lab2942')
                        stage.varOper(0, 1, 2, 4, 4025)
                        if model.random() < 20:
                            stage.varOper(0, 1, 2, 0, 5)
                    if gvars[13] == 6:
                        label('lab2955')
                        stage.infoTransfer(26, '7')
                        if gvars[4025] < 4:
                            goto('lab2955')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 8:
                        label('lab2964')
                        stage.infoTransfer(26, '9')
                        if gvars[4025] < 4:
                            goto('lab2964')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 10:
                        label('lab2973')
                        stage.infoTransfer(26, '11')
                        if gvars[4025] < 5:
                            goto('lab2973')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 12:
                        label('lab2982')
                        stage.infoTransfer(26, '13')
                        if gvars[4025] < 8:
                            goto('lab2982')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 13:
                        label('lab2991')
                        stage.infoTransfer(26, '14')
                        if gvars[4025] < 11:
                            goto('lab2991')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 15:
                        label('lab3000')
                        stage.infoTransfer(26, '16')
                        if gvars[4025] < 10:
                            goto('lab3000')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 20:
                        label('lab3009')
                        stage.infoTransfer(26, '21')
                        if gvars[4025] < 12:
                            goto('lab3009')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 30:
                        label('lab3018')
                        stage.infoTransfer(26, '31')
                        if gvars[4025] < 18:
                            goto('lab3018')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 40:
                        label('lab3027')
                        stage.infoTransfer(26, '41')
                        if gvars[4025] < 24:
                            goto('lab3027')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 50:
                        label('lab3036')
                        stage.infoTransfer(26, '51')
                        if gvars[4025] < 30:
                            goto('lab3036')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 60:
                        label('lab3045')
                        stage.infoTransfer(26, '61')
                        if gvars[4025] < 35:
                            goto('lab3045')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 70:
                        label('lab3054')
                        stage.infoTransfer(26, '71')
                        if gvars[4025] < 40:
                            goto('lab3054')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 99:
                        label('lab3063')
                        stage.infoTransfer(26, '100')
                        if gvars[4025] < 50:
                            goto('lab3063')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 100:
                        stage.varOper(0, 1, 2, 0, 100)
                    if gvars[13] == 101:
                        label('lab3076')
                        stage.infoTransfer(26, '17')
                        if gvars[4025] == 5:
                            goto('lab3076')
                        if gvars[4025] == 10:
                            goto('lab3076')
                        if gvars[4025] == 11:
                            goto('lab3076')
                        if gvars[4025] < 1:
                            goto('lab3076')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 102:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 9)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 10)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 11)
                    if gvars[13] == 103:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 6)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 52)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 63)
                    if gvars[13] == 104:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 6)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 52)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 63)
                    if gvars[13] == 105:
                        stage.infoTransfer(26, '5')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 8)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 16)
                    if gvars[13] == 107:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 108:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 109:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 110:
                        label('lab3409')
                        stage.infoTransfer(26, '6')
                        if gvars[4025] < 1:
                            goto('lab3409')
                        stage.varOper(0, 1, 2, 4, 4025)
                        if model.random() < 30:
                            stage.varOper(0, 1, 2, 0, 6)
                    if gvars[13] == 111:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 17)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 18)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 36)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 40)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 56)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 47)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 63)
                        if gvars[4025] == 15:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 16:
                            stage.varOper(0, 1, 2, 0, 95)
                    if gvars[13] == 112:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 8)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 16)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 17)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 32)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 40)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 48)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 51)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 95)
                    if gvars[13] == 113:
                        stage.varOper(0, 1, 2, 0, 25)
                    if gvars[13] == 150:
                        stage.varOper(0, 1, 2, 0, 150)
                    pvars[1] += 1
                    label('lab3568')
                    stage.infoTransfer(26, '12')
                    if gvars[4025] >= 9:
                        stage.varOper(0, 1, 2, 4, 4025)
                    else:
                        goto('lab3568')
                    gvars[3] -= 4
                    pvars[1] -= 3
                    gvars[4076] = 0
                    pvars[0] = gvars[3]
                    stage.varOper(2, 7, 2, 1, 0)
                    pvars[0] = gvars[6]
                    stage.varOper(0, 0, 2, 4, 7)
                    pvars[0] = gvars[4]
                    stage.varOper(0, 0, 2, 4, 3)
                    pvars[0] = gvars[5]
                    stage.varOper(0, 0, 2, 1, 1)
                    pvars[0] = gvars[3]
                    stage.varOper(0, 0, 2, 1, 1)
                    gvars[1] += 1
                    gvars[4] += 4
                    gvars[5] += 4
                    gvars[6] += 4
                else:
                    gvars[0] = 108
            gvars[0] += 1
            goto('lab2831')
        label('lab3606')
        if gvars[0] <= 149:
            gvars[4076] = 0
            pvars[1] = 4217736
            gvars[2] = 4854854
            gvars[3] = gvars[0]
            gvars[3] -= 30
            gvars[3] *= 25
            gvars[3] += gvars[2]
            pvars[0] = gvars[3]
            gvars[4076] = 1
            if stage.varTest(1, 0, 0, 0, 1):
                if gvars[1] <= 103:
                    gvars[4076] = 0
                    label('lab3626')
                    stage.infoTransfer(26, '128')
                    if gvars[4025] == 123:
                        goto('lab3626')
                    if gvars[4025] >= 26:
                        gvars[10] = gvars[4025]
                        gvars[10] -= 26
                        gvars[10] *= 4
                        gvars[10] += gvars[9]
                        pvars[0] = gvars[10]
                        stage.varOper(2, 11, 2, 1, 0)
                        gvars[12] = gvars[4025]
                        gvars[11] %= 7
                        if gvars[11] == 0:
                            stage.varOper(0, 1, 2, 4, 4025)
                        goto('lab3626')
                    else:
                        goto('lab3626')
                    gvars[3] -= 7
                    gvars[4076] = 0
                    pvars[0] = gvars[3]
                    stage.varOper(2, 7, 2, 1, 0)
                    pvars[0] = gvars[6]
                    stage.varOper(0, 0, 2, 4, 7)
                    pvars[0] = gvars[4]
                    stage.varOper(0, 0, 2, 4, 3)
                    gvars[4076] = 1
                    pvars[0] = gvars[3]
                    stage.varOper(0, 0, 2, 1, 1)
                    gvars[4076] = 0
                    pvars[0] = gvars[3]
                    stage.varOper(2, 7, 2, 1, 0)
                    pvars[0] = gvars[5]
                    stage.varOper(0, 0, 2, 4, 7)
                    gvars[1] += 1
                    gvars[4] += 4
                    gvars[5] += 4
                    gvars[6] += 4
                    gvars[12] -= 26
                    gvars[12] *= 4
                    gvars[12] += gvars[8]
                    pvars[0] = gvars[12]
                    stage.varOper(2, 13, 2, 1, 0)
                    if gvars[13] == 3:
                        stage.varOper(0, 1, 2, 0, 3)
                    if gvars[13] == 4:
                        label('lab3694')
                        stage.infoTransfer(26, '5')
                        if gvars[4025] < 2:
                            goto('lab3694')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 5:
                        label('lab3703')
                        stage.infoTransfer(26, '5')
                        if gvars[4025] < 3:
                            goto('lab3703')
                        stage.varOper(0, 1, 2, 4, 4025)
                        if model.random() < 20:
                            stage.varOper(0, 1, 2, 0, 5)
                    if gvars[13] == 6:
                        label('lab3716')
                        stage.infoTransfer(26, '7')
                        if gvars[4025] < 4:
                            goto('lab3716')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 8:
                        label('lab3725')
                        stage.infoTransfer(26, '9')
                        if gvars[4025] < 4:
                            goto('lab3725')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 10:
                        label('lab3734')
                        stage.infoTransfer(26, '11')
                        if gvars[4025] < 5:
                            goto('lab3734')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 12:
                        label('lab3743')
                        stage.infoTransfer(26, '13')
                        if gvars[4025] < 8:
                            goto('lab3743')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 13:
                        label('lab3752')
                        stage.infoTransfer(26, '14')
                        if gvars[4025] < 11:
                            goto('lab3752')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 15:
                        label('lab3761')
                        stage.infoTransfer(26, '16')
                        if gvars[4025] < 10:
                            goto('lab3761')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 20:
                        label('lab3770')
                        stage.infoTransfer(26, '21')
                        if gvars[4025] < 12:
                            goto('lab3770')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 30:
                        label('lab3779')
                        stage.infoTransfer(26, '31')
                        if gvars[4025] < 18:
                            goto('lab3779')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 40:
                        label('lab3788')
                        stage.infoTransfer(26, '41')
                        if gvars[4025] < 24:
                            goto('lab3788')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 50:
                        label('lab3797')
                        stage.infoTransfer(26, '51')
                        if gvars[4025] < 30:
                            goto('lab3797')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 60:
                        label('lab3806')
                        stage.infoTransfer(26, '61')
                        if gvars[4025] < 35:
                            goto('lab3806')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 70:
                        label('lab3815')
                        stage.infoTransfer(26, '71')
                        if gvars[4025] < 40:
                            goto('lab3815')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 99:
                        label('lab3824')
                        stage.infoTransfer(26, '100')
                        if gvars[4025] < 50:
                            goto('lab3824')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 100:
                        stage.varOper(0, 1, 2, 0, 100)
                    if gvars[13] == 101:
                        label('lab3837')
                        stage.infoTransfer(26, '17')
                        if gvars[4025] == 5:
                            goto('lab3837')
                        if gvars[4025] == 10:
                            goto('lab3837')
                        if gvars[4025] == 11:
                            goto('lab3837')
                        if gvars[4025] < 1:
                            goto('lab3837')
                        stage.varOper(0, 1, 2, 4, 4025)
                    if gvars[13] == 102:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 9)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 10)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 11)
                    if gvars[13] == 103:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 6)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 52)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 63)
                    if gvars[13] == 104:
                        stage.infoTransfer(26, '7')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 6)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 52)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 5)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 63)
                    if gvars[13] == 105:
                        stage.infoTransfer(26, '5')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 8)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 16)
                    if gvars[13] == 107:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 108:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 109:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 3)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 11)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 12)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 13)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 22)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 35)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 37)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 68)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 80)
                    if gvars[13] == 110:
                        label('lab4170')
                        stage.infoTransfer(26, '6')
                        if gvars[4025] < 1:
                            goto('lab4170')
                        stage.varOper(0, 1, 2, 4, 4025)
                        if model.random() < 30:
                            stage.varOper(0, 1, 2, 0, 6)
                    if gvars[13] == 111:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 1)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 17)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 18)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 36)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 40)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 56)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 31)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 47)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 63)
                        if gvars[4025] == 15:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 16:
                            stage.varOper(0, 1, 2, 0, 95)
                    if gvars[13] == 112:
                        stage.infoTransfer(26, '15')
                        if gvars[4025] == 0:
                            stage.varOper(0, 1, 2, 0, 2)
                        if gvars[4025] == 1:
                            stage.varOper(0, 1, 2, 0, 4)
                        if gvars[4025] == 2:
                            stage.varOper(0, 1, 2, 0, 8)
                        if gvars[4025] == 3:
                            stage.varOper(0, 1, 2, 0, 16)
                        if gvars[4025] == 4:
                            stage.varOper(0, 1, 2, 0, 17)
                        if gvars[4025] == 5:
                            stage.varOper(0, 1, 2, 0, 20)
                        if gvars[4025] == 6:
                            stage.varOper(0, 1, 2, 0, 24)
                        if gvars[4025] == 7:
                            stage.varOper(0, 1, 2, 0, 32)
                        if gvars[4025] == 8:
                            stage.varOper(0, 1, 2, 0, 33)
                        if gvars[4025] == 9:
                            stage.varOper(0, 1, 2, 0, 34)
                        if gvars[4025] == 10:
                            stage.varOper(0, 1, 2, 0, 40)
                        if gvars[4025] == 11:
                            stage.varOper(0, 1, 2, 0, 48)
                        if gvars[4025] == 12:
                            stage.varOper(0, 1, 2, 0, 51)
                        if gvars[4025] == 13:
                            stage.varOper(0, 1, 2, 0, 79)
                        if gvars[4025] == 14:
                            stage.varOper(0, 1, 2, 0, 95)
                    if gvars[13] == 113:
                        stage.varOper(0, 1, 2, 0, 25)
                    if gvars[13] == 150:
                        stage.varOper(0, 1, 2, 0, 150)
                    gvars[3] += 4
                    gvars[4076] = 0
                    pvars[0] = gvars[3]
                    stage.varOper(2, 7, 2, 1, 0)
                    pvars[0] = gvars[6]
                    stage.varOper(0, 0, 2, 4, 7)
                    pvars[0] = gvars[4]
                    stage.varOper(0, 0, 2, 4, 3)
                    gvars[4076] = 1
                    pvars[0] = gvars[3]
                    stage.varOper(0, 0, 2, 1, 1)
                    gvars[4076] = 0
                    pvars[0] = gvars[3]
                    stage.varOper(2, 7, 2, 1, 0)
                    pvars[0] = gvars[5]
                    stage.varOper(0, 0, 2, 4, 7)
                    gvars[1] += 1
                    gvars[4] += 4
                    gvars[5] += 4
                    gvars[6] += 4
                else:
                    gvars[0] = 149
            gvars[0] += 1
            goto('lab3606')
    if vars[1002]:
        if gvars[4074] == 0:
            stage.getItem(161, 4)
            stage.getItem(162, 4)
            stage.getItem(163, 4)
            stage.getItem(164, 4)
            stage.getItem(165, 4)
        stage.getItem(160, 4)
    model.unitJoin(0, 0, 2)
    stage.setJoinEquip(0, 33, 0, 0, 0, 0)
    stage.say('&0\n……응.\n다음에 보자, 장인어른.')
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n출발! 격전지인 영천으로 가자!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(0, 0)
    stage.say('&181\n네!')
    stage.unit(182).setAction(0, 2)
    stage.say('&182\n네!')
    stage.unitsMove([[stage.unit(0), 40, 80, 2], [stage.unit(181), 40, 98, 2], [stage.unit(182), 40, 70, 2], [stage.unit(157), 54, 20, 0]])
    stage.delay(3)
    stage.unit(157).setAction(0, 2)
    if vars[300]:
        stage.say('&157\n그래서 그는 악당이 되고 싶었던 거야?\n알겠습니다, 조 경......\n그저 당신의 이상을 향해 열심히 노력하세요.\n&157\n헤헤, 하!!')
    if not vars[300]:
        stage.say('&157\n젊은 남자의 모습,\n그는 어려운 시기에 영웅이자 평화 시기에는 유능한 장관이다.\n&157\n앞으로 그에게 무슨 일이 일어날지 누가 알겠는가......?\n두고 보자.\n&157\n헤하하.')
    stage.unitsMove([[stage.unit(0), 40, 98, 2], [stage.unit(182), 40, 98, 2], [stage.unit(157), 54, 5, 0]])
    stage.delay(3)
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene2():
    if vars[1001]:
        stage.infoTransfer(4, '14\n29\n19\n사마의 모래폭풍')
        stage.infoTransfer(4, '21\n30\n17\n초선 어지러움')
        stage.infoTransfer(4, '21\n31\n22\n곽가 어지러워')
        stage.infoTransfer(4, '21\n31\n23\n가후 어지럼증')
        gvars[4076] = 0
        gvars[0] = 0
        gvars[1] = 0
        label('lab4439')
        if gvars[0] <= 349:
            gvars[1] = stage.unitAttr(gvars[0], 17)
            if gvars[1] == 27:
                stage.infoTransfer(4, '57\n30\n*0\n풍수 대가가 돌아오다')
            gvars[0] += 1
            goto('lab4439')
        gvars[4076] = 1
        pvars[200] = 4691288
        stage.varOper(0, 200, 2, 0, 100)
        pvars[201] = 4522074
        stage.varOper(0, 201, 2, 0, 100)
        pvars[202] = 4525087
        stage.varOper(0, 202, 2, 0, 100)
        pvars[203] = 4524851
        stage.varOper(0, 203, 2, 0, 100)
        pvars[204] = 4524872
        stage.varOper(0, 204, 2, 0, 100)
        pvars[205] = 4229334
        stage.varOper(0, 205, 2, 0, 100)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[206] = 4325694
        stage.varOper(0, 206, 2, 0, 20)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[207] = 4223753
        stage.varOper(0, 207, 2, 0, 127)
        gvars[4076] = 0
        gvars[4071] = 255
        stage.info('3 S A B C\n합격 기준: 90, 70, 50, 0\n자격적 성장 4 3 2 1\n\n완벽한 상태: 90 70\n퍼펙트 그로스 3 2')
        gvars[4076] = 1
        pvars[297] = 4857851
        stage.varOper(0, 297, 2, 0, 30)
        pvars[298] = 4857876
        stage.varOper(0, 298, 2, 0, 80)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[208] = 4330304
        stage.varOper(0, 208, 2, 0, 1)
        pvars[209] = 4416633
        stage.varOper(0, 209, 2, 0, 1)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[210] = 4341409
        stage.varOper(0, 210, 2, 0, 50)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[211] = 4453911
        pvars[212] = 4453955
        pvars[213] = 4453999
        pvars[214] = 4454043
        pvars[215] = 4454087
        stage.varOper(0, 211, 2, 0, 35)
        stage.varOper(0, 212, 2, 0, 35)
        stage.varOper(0, 213, 2, 0, 35)
        stage.varOper(0, 214, 2, 0, 35)
        stage.varOper(0, 215, 2, 0, 35)
        gvars[4076] = 0
        gvars[4071] = 255
        stage.info('4[C3A [능력 업그레이드 비율]]\n\n  [C28◇ 공격력 20% 상승, 30% 감소]\n  [C3A◇ 방어력 20% 상승 30% 하락]\n  [C277◇ 정신력 20% 상승, 30% 하락]\n  [C25◇ 폭발 20% 상승 30% 하락]\n  [C76◇사기 20% 상승 30% 하락]')
        gvars[4076] = 1
        pvars[216] = 4856953
        stage.varOper(0, 216, 2, 0, 5)
        pvars[217] = 4857078
        stage.varOper(0, 217, 2, 0, 1)
        pvars[218] = 4857253
        stage.varOper(0, 218, 2, 0, 7)
        pvars[219] = 4857653
        stage.varOper(0, 219, 2, 0, 11)
        pvars[220] = 4857678
        stage.varOper(0, 220, 2, 0, 8)
        pvars[221] = 4857703
        stage.varOper(0, 221, 2, 0, 10)
        pvars[222] = 4857728
        stage.varOper(0, 222, 2, 0, 9)
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[229] = 4860456
        stage.varOper(0, 229, 2, 0, 0)
        gvars[4076] = 2
        pvars[223] = 4860462
        pvars[224] = 4860497
        pvars[225] = 4860532
        stage.varOper(0, 223, 2, 0, 261)
        stage.varOper(0, 224, 2, 0, 261)
        stage.varOper(0, 225, 2, 0, 261)
        pvars[245] = 4863255
        stage.varOper(0, 245, 2, 0, 1515875940)
        pvars[226] = 4860566
        pvars[227] = 4860601
        pvars[228] = 4860636
        stage.varOper(0, 226, 2, 0, 1538)
        stage.varOper(0, 227, 2, 0, 1538)
        stage.varOper(0, 228, 2, 0, 1538)
        gvars[4076] = 1
        pvars[230] = 4860595
        stage.varOper(0, 230, 2, 0, 5)
        gvars[4076] = 0
        pvars[231] = 4860670
        pvars[232] = 4860705
        pvars[233] = 4860740
        stage.varOper(0, 231, 2, 0, 17040386)
        stage.varOper(0, 232, 2, 0, 17040386)
        stage.varOper(0, 233, 2, 0, 17040386)
        pvars[234] = 4860775
        pvars[235] = 4860810
        pvars[236] = 4860845
        stage.varOper(0, 234, 2, 0, 17105410)
        stage.varOper(0, 235, 2, 0, 17105410)
        stage.varOper(0, 236, 2, 0, 17105410)
        gvars[4076] = 1
        pvars[237] = 4860806
        stage.varOper(0, 237, 2, 0, 0)
        gvars[4076] = 0
        pvars[238] = 4860880
        pvars[239] = 4860915
        pvars[240] = 4860950
        stage.varOper(0, 238, 2, 0, 17105666)
        stage.varOper(0, 239, 2, 0, 17105666)
        stage.varOper(0, 240, 2, 0, 17105666)
        pvars[241] = 4863495
        stage.varOper(0, 241, 2, 0, 1515875940)
        gvars[4076] = 1
        pvars[242] = 4860987
        pvars[243] = 4861022
        pvars[244] = 4861057
        stage.varOper(0, 242, 2, 0, 4)
        stage.varOper(0, 243, 2, 0, 4)
        stage.varOper(0, 244, 2, 0, 4)
        gvars[4076] = 0
        pvars[246] = 4861089
        pvars[247] = 4861124
        pvars[248] = 4861159
        stage.varOper(0, 246, 2, 0, 67240961)
        stage.varOper(0, 247, 2, 0, 67240961)
        stage.varOper(0, 248, 2, 0, 67240961)
        gvars[4076] = 1
        pvars[249] = 4861086
        stage.varOper(0, 249, 2, 0, 0)
        gvars[4076] = 2
        pvars[250] = 4861196
        pvars[251] = 4861231
        pvars[252] = 4861266
        stage.varOper(0, 250, 2, 0, 1284)
        stage.varOper(0, 251, 2, 0, 1284)
        stage.varOper(0, 252, 2, 0, 1284)
        gvars[4076] = 0
        pvars[253] = 4861299
        pvars[254] = 4861334
        pvars[255] = 4861369
        stage.varOper(0, 253, 2, 0, 67240452)
        stage.varOper(0, 254, 2, 0, 67240452)
        stage.varOper(0, 255, 2, 0, 67240452)
        gvars[4076] = 2
        pvars[256] = 4861407
        pvars[257] = 4861442
        pvars[258] = 4861477
        stage.varOper(0, 256, 2, 0, 515)
        stage.varOper(0, 257, 2, 0, 515)
        stage.varOper(0, 258, 2, 0, 515)
        gvars[4076] = 0
        pvars[259] = 4861510
        pvars[260] = 4861545
        pvars[261] = 4861580
        stage.varOper(0, 259, 2, 0, 33751555)
        stage.varOper(0, 260, 2, 0, 33751555)
        stage.varOper(0, 261, 2, 0, 33751555)
        pvars[262] = 4861613
        pvars[263] = 4861648
        pvars[264] = 4861683
        stage.varOper(0, 262, 2, 0, 16909314)
        stage.varOper(0, 263, 2, 0, 16909314)
        stage.varOper(0, 264, 2, 0, 16909314)
        pvars[265] = 4861617
        pvars[266] = 4861652
        pvars[267] = 4861687
        stage.varOper(0, 265, 2, 0, 517)
        stage.varOper(0, 266, 2, 0, 517)
        stage.varOper(0, 267, 2, 0, 517)
        pvars[268] = 4861719
        pvars[269] = 4861754
        pvars[270] = 4861789
        stage.varOper(0, 268, 2, 0, 50463746)
        stage.varOper(0, 269, 2, 0, 50463746)
        stage.varOper(0, 270, 2, 0, 50463746)
        gvars[4076] = 2
        pvars[270] = 4862561
        stage.varOper(0, 270, 2, 0, 1538)
        gvars[4076] = 0
        pvars[296] = 4864455
        stage.varOper(0, 296, 2, 0, 1850762340)
        pvars[271] = 4862590
        stage.varOper(0, 271, 2, 0, 33685508)
        pvars[272] = 4862595
        stage.varOper(0, 272, 2, 0, 17039618)
        gvars[4076] = 2
        pvars[273] = 4862631
        stage.varOper(0, 273, 2, 0, 1026)
        gvars[4076] = 0
        pvars[274] = 4862665
        stage.varOper(0, 274, 2, 0, 17170946)
        gvars[4076] = 2
        pvars[275] = 4862696
        stage.varOper(0, 275, 2, 0, 768)
        pvars[276] = 4862701
        stage.varOper(0, 276, 2, 0, 1025)
        gvars[4076] = 0
        pvars[277] = 4862731
        stage.varOper(0, 277, 2, 0, 67240704)
        pvars[278] = 4862737
        stage.varOper(0, 278, 2, 0, 516)
        gvars[4076] = 0
        pvars[279] = 4862769
        stage.varOper(0, 279, 2, 0, 50528772)
        gvars[4076] = 0
        pvars[280] = 4862835
        stage.varOper(0, 280, 2, 0, 16845572)
        pvars[281] = 4862842
        stage.varOper(0, 281, 2, 0, 259)
        pvars[282] = 4862893
        stage.varOper(0, 282, 2, 0, 0)
        pvars[283] = 4862871
        stage.varOper(0, 283, 2, 0, 33620235)
        pvars[284] = 4862875
        stage.varOper(0, 284, 2, 0, 16974337)
        pvars[285] = 4862910
        stage.varOper(0, 285, 2, 0, 17039620)
        gvars[4076] = 2
        pvars[286] = 4862946
        stage.varOper(0, 286, 2, 0, 1538)
        gvars[4076] = 0
        pvars[287] = 4862975
        stage.varOper(0, 287, 2, 0, 16845572)
        pvars[288] = 4862979
        stage.varOper(0, 288, 2, 0, 50594049)
        pvars[289] = 4862983
        stage.varOper(0, 289, 2, 0, 1)
        pvars[290] = 4864575
        stage.varOper(0, 290, 2, 0, 1348098650)
        gvars[4076] = 1
        pvars[291] = 4864635
        stage.varOper(0, 291, 2, 0, 90)
        gvars[4076] = 0
        pvars[292] = 4864935
        stage.varOper(0, 292, 2, 0, 1515870810)
        gvars[4076] = 0
        pvars[293] = 4864995
        stage.varOper(0, 293, 2, 0, 1515870810)
        pvars[294] = 4865175
        stage.varOper(0, 294, 2, 0, 1515870810)
        pvars[295] = 4864755
        stage.varOper(0, 295, 2, 0, 1348098660)
        gvars[4076] = 2
        pvars[0] = 5273600
        gvars[0] = 0
        label('lab4755')
        if gvars[0] <= 250:
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 2
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 2
            stage.varOper(0, 0, 2, 0, 1025)
            pvars[0] += 4
            gvars[0] += 1
            goto('lab4755')
        gvars[4076] = 0
        gvars[4076] = 1
        pvars[0] = 5273606
        gvars[0] = 0
        label('lab4773')
        if gvars[0] <= 250:
            stage.varOper(0, 0, 2, 0, 255)
            pvars[0] += 8
            gvars[0] += 1
            goto('lab4773')
        gvars[4076] = 0
        stage.infoTransfer(5, '13\n3\n63\n곰 조련사 - 마비 공격')
        stage.infoTransfer(5, '15\n3\n71\n어스 퍼펫 - 카오스 공격')
        stage.infoTransfer(5, '16\n3\n70\n나무 인간 - 독 공격')
        stage.infoTransfer(5, '100\n3\n36\n댄서 - 주변 상태 회복')
        gvars[4076] = 1
        pvars[0] = 5273711
        stage.varOper(0, 0, 2, 0, 60)
        pvars[0] = 5273719
        stage.varOper(0, 0, 2, 0, 60)
        pvars[0] = 5273735
        stage.varOper(0, 0, 2, 0, 60)
        gvars[4076] = 0
        if model.random() < 50:
            stage.setFAvatar(2, 27)
        if model.random() < 50:
            stage.setFAvatar(34, 29)
        if model.random() < 34:
            stage.setFAvatar(119, 91)
            return False
        if model.random() < 50:
            stage.setFAvatar(119, 92)
    return False


def scene3():
    if vars[1002]:
        if vars[1021]:
            gvars[4076] = 0
            pvars[202] = 4854850
            stage.varOper(0, 202, 2, 0, 167777346)
            pvars[203] = 4854875
            stage.varOper(0, 203, 2, 0, 169088063)
            pvars[204] = 4854900
            stage.varOper(0, 204, 2, 0, 169546805)
            pvars[205] = 4854925
            stage.varOper(0, 205, 2, 0, 168432749)
            gvars[4076] = 1
            pvars[286] = 4854922
            stage.varOper(0, 286, 2, 0, 7)
            gvars[4076] = 0
            pvars[206] = 4854950
            stage.varOper(0, 206, 2, 0, 167973940)
            pvars[236] = 4768002
            stage.varOper(0, 236, 2, 0, 0xDED1E4C0)
            pvars[237] = 4768006
            stage.varOper(0, 237, 2, 0, 58046)
            gvars[4076] = 1
            pvars[238] = 4337228
            stage.varOper(0, 238, 2, 0, 52)
            gvars[4076] = 0
            pvars[207] = 4854975
            stage.varOper(0, 207, 2, 0, 168039475)
            pvars[208] = 4855000
            stage.varOper(0, 208, 2, 0, 167777334)
            pvars[209] = 4855050
            stage.varOper(0, 209, 2, 0, 167973976)
            pvars[210] = 4855075
            stage.varOper(0, 210, 2, 0, 169086756)
            pvars[211] = 4855125
            stage.varOper(0, 211, 2, 0, 168498227)
            pvars[212] = 4855150
            stage.varOper(0, 212, 2, 0, 167907171)
            pvars[213] = 4855300
            stage.varOper(0, 213, 2, 0, 167777374)
            pvars[214] = 4855325
            stage.varOper(0, 214, 2, 0, 33555554)
            gvars[4076] = 1
            pvars[215] = 4440614
            stage.varOper(0, 215, 2, 0, 56)
            pvars[216] = 4440625
            stage.varOper(0, 216, 2, 0, 56)
            pvars[217] = 4440636
            stage.varOper(0, 217, 2, 0, 56)
            gvars[4076] = 0
            pvars[218] = 4768048
            stage.varOper(0, 218, 2, 0, 0xD8CBAAD4)
            pvars[219] = 4855350
            stage.varOper(0, 219, 2, 0, 169088056)
            pvars[220] = 4855375
            stage.varOper(0, 220, 2, 0, 167777363)
            pvars[221] = 4855400
            stage.varOper(0, 221, 2, 0, 170397497)
            pvars[222] = 4855425
            stage.varOper(0, 222, 2, 0, 169545552)
            pvars[223] = 4856075
            stage.varOper(0, 223, 2, 0, 169088078)
            pvars[224] = 4856100
            stage.varOper(0, 224, 2, 0, 167777345)
            gvars[4076] = 1
            pvars[225] = 4218677
            stage.varOper(0, 225, 2, 0, 65)
            pvars[226] = 4454682
            stage.varOper(0, 226, 2, 0, 65)
            gvars[4076] = 0
            pvars[227] = 4768149
            stage.varOper(0, 227, 2, 0, 0xE2CAD8CC)
            pvars[228] = 4768153
            stage.varOper(0, 228, 2, 0, 0xF7BBA5B9)
            pvars[229] = 4856125
            stage.varOper(0, 229, 2, 0, 167777359)
            pvars[235] = 4856150
            stage.varOper(0, 235, 2, 0, 169088115)
            pvars[230] = 4856175
            stage.varOper(0, 230, 2, 0, 167777328)
            pvars[231] = 4856350
            stage.varOper(0, 231, 2, 0, 169807738)
            pvars[232] = 4856375
            stage.varOper(0, 232, 2, 0, 168300393)
            pvars[233] = 4856450
            stage.varOper(0, 233, 2, 0, 170397474)
            pvars[234] = 4856500
            stage.varOper(0, 234, 2, 0, 170004348)
            gvars[4076] = 1
            pvars[239] = 4856847
            stage.varOper(0, 239, 2, 0, 64)
            pvars[240] = 4856872
            stage.varOper(0, 240, 2, 0, 67)
            pvars[241] = 4856876
            stage.varOper(0, 241, 2, 0, 30)
            pvars[242] = 4439641
            stage.varOper(0, 242, 2, 0, 67)
            gvars[4076] = 0
            pvars[243] = 4768171
            stage.varOper(0, 243, 2, 0, 0xBFB2ABC8)
            gvars[4076] = 1
            pvars[244] = 4856897
            stage.varOper(0, 244, 2, 0, 68)
            pvars[245] = 4209280
            stage.varOper(0, 245, 2, 0, 40)
            pvars[246] = 4856997
            stage.varOper(0, 246, 2, 0, 120)
            pvars[247] = 4857001
            stage.varOper(0, 247, 2, 0, 79)
            pvars[248] = 4857072
            stage.varOper(0, 248, 2, 0, 114)
            pvars[249] = 4857076
            stage.varOper(0, 249, 2, 0, 60)
            pvars[250] = 4454503
            stage.varOper(0, 250, 2, 0, 42)
            gvars[4076] = 0
            pvars[251] = 4767904
            stage.varOper(0, 251, 2, 0, 0xA6D3CACA)
            gvars[4076] = 1
            pvars[252] = 4857147
            stage.varOper(0, 252, 2, 0, 104)
            pvars[255] = 4857151
            stage.varOper(0, 255, 2, 0, 25)
            gvars[4076] = 0
            pvars[253] = 4768334
            stage.varOper(0, 253, 2, 0, 0xD6CAC8CF)
            gvars[4076] = 1
            pvars[254] = 4263698
            stage.varOper(0, 254, 2, 0, 84)
            pvars[256] = 4857197
            stage.varOper(0, 256, 2, 0, 90)
            pvars[257] = 4857247
            stage.varOper(0, 257, 2, 0, 127)
            pvars[258] = 4857297
            stage.varOper(0, 258, 2, 0, 110)
            pvars[259] = 4857322
            stage.varOper(0, 259, 2, 0, 32)
            pvars[260] = 4857326
            stage.varOper(0, 260, 2, 0, 20)
            pvars[261] = 4857347
            stage.varOper(0, 261, 2, 0, 33)
            pvars[262] = 4857351
            stage.varOper(0, 262, 2, 0, 20)
            if gvars[4074] == 0:
                gvars[4076] = 0
                pvars[263] = 4767765
                stage.varOper(0, 263, 2, 0, 0xB8B1B0D7)
                gvars[4076] = 1
                pvars[264] = 4857397
                stage.varOper(0, 264, 2, 0, 29)
                pvars[265] = 4444111
                stage.varOper(0, 265, 2, 0, 29)
            if gvars[4074] == 1:
                pvars[263] = 4857397
                stage.varOper(0, 263, 2, 0, 103)
                pvars[264] = 4857401
                stage.varOper(0, 264, 2, 0, 3)
            pvars[266] = 4857422
            stage.varOper(0, 266, 2, 0, 117)
            pvars[267] = 4857472
            stage.varOper(0, 267, 2, 0, 106)
            pvars[268] = 4857547
            stage.varOper(0, 268, 2, 0, 82)
            pvars[269] = 4857572
            stage.varOper(0, 269, 2, 0, 81)
            pvars[270] = 4857576
            stage.varOper(0, 270, 2, 0, 37)
            pvars[271] = 4857601
            stage.varOper(0, 271, 2, 0, 3)
            pvars[285] = 4337246
            stage.varOper(0, 285, 2, 0, 49)
            pvars[272] = 4857647
            stage.varOper(0, 272, 2, 0, 108)
            pvars[273] = 4857672
            stage.varOper(0, 273, 2, 0, 119)
            pvars[274] = 4857697
            stage.varOper(0, 274, 2, 0, 43)
            pvars[275] = 4857722
            stage.varOper(0, 275, 2, 0, 100)
            gvars[4076] = 0
        if not vars[1021] and not vars[1022]:
            gvars[4076] = 1
            pvars[282] = 4325694
            stage.varOper(0, 282, 2, 0, 20)
            gvars[4076] = 0
            gvars[4076] = 1
            pvars[283] = 4330304
            stage.varOper(0, 283, 2, 0, 1)
            gvars[4076] = 0
        if vars[1011]:
            gvars[2000] = 0
            gvars[2001] = 9
            gvars[2002] = 54
            gvars[2003] = 57
            gvars[2004] = 42
            gvars[2005] = 39
            gvars[2006] = 12
            gvars[2007] = 51
            gvars[2008] = 77
            gvars[2009] = 75
            gvars[2010] = 45
            gvars[2011] = 3
            gvars[2012] = 63
            gvars[2013] = 60
            gvars[2014] = 6
            gvars[2015] = 76
            gvars[2016] = 18
            gvars[2017] = 36
            gvars[2018] = 15
            gvars[2019] = 33
            gvars[2020] = 24
            gvars[2021] = 74
            gvars[2022] = 66
            gvars[2023] = 30
            gvars[2024] = 27
            gvars[2025] = 65
            gvars[2026] = 9
            gvars[2027] = 9
            gvars[2028] = 9
            gvars[2029] = 57
            gvars[2030] = 12
            gvars[2031] = 9
            gvars[2032] = 0
            gvars[2033] = 78
            gvars[2034] = 9
            gvars[2035] = 66
            gvars[2036] = 12
            gvars[2037] = 54
            gvars[2038] = 30
            gvars[2039] = 27
            gvars[2040] = 6
            gvars[2041] = 74
            gvars[2042] = 39
            gvars[2043] = 6
            gvars[2044] = 21
            gvars[2045] = 39
            gvars[2046] = 9
            gvars[2047] = 21
            gvars[2048] = 57
            gvars[2049] = 33
            gvars[2050] = 30
            gvars[2051] = 68
            gvars[2052] = 75
            gvars[2053] = 51
            gvars[2054] = 51
            gvars[2055] = 33
            gvars[2056] = 69
            gvars[2057] = 60
            gvars[2058] = 51
            gvars[2059] = 77
            gvars[2060] = 39
            gvars[2061] = 15
            gvars[2062] = 45
            gvars[2063] = 48
            gvars[2064] = 0
            gvars[2065] = 3
            gvars[2066] = 12
            gvars[2067] = 72
            gvars[2068] = 64
            gvars[2069] = 33
            gvars[2070] = 39
            gvars[2071] = 63
            gvars[2072] = 36
            gvars[2073] = 64
            gvars[2074] = 61
            gvars[2075] = 61
            gvars[2076] = 0
            gvars[2077] = 65
            gvars[2078] = 24
            gvars[2079] = 27
            gvars[2080] = 57
            gvars[2081] = 66
            gvars[2082] = 68
            gvars[2083] = 51
            gvars[2084] = 78
            gvars[2085] = 60
            gvars[2086] = 76
            gvars[2087] = 62
            gvars[2088] = 69
            gvars[2089] = 77
            gvars[2090] = 33
            gvars[2091] = 9
            gvars[2092] = 6
            gvars[2093] = 3
            gvars[2094] = 12
            gvars[2095] = 9
            gvars[2096] = 18
            gvars[2097] = 30
            gvars[2098] = 57
            gvars[2099] = 0
            gvars[2100] = 51
            gvars[2101] = 0
            gvars[2102] = 27
            gvars[2103] = 30
            gvars[2104] = 30
            gvars[2105] = 24
            gvars[2106] = 33
            gvars[2107] = 12
            gvars[2108] = 60
            gvars[2109] = 51
            gvars[2110] = 24
            gvars[2111] = 3
            gvars[2112] = 15
            gvars[2113] = 9
            gvars[2114] = 54
            gvars[2115] = 51
            gvars[2116] = 48
            gvars[2117] = 27
            gvars[2118] = 77
            gvars[2119] = 78
            gvars[2120] = 54
            gvars[2121] = 9
            gvars[2122] = 60
            gvars[2123] = 51
            gvars[2124] = 12
            gvars[2125] = 21
            gvars[2126] = 24
            gvars[2127] = 60
            gvars[2128] = 51
            gvars[2129] = 39
            gvars[2130] = 54
            gvars[2131] = 3
            gvars[2132] = 24
            gvars[2133] = 75
            gvars[2134] = 60
            gvars[2135] = 30
            gvars[2136] = 57
            gvars[2137] = 54
            gvars[2138] = 60
            gvars[2139] = 65
            gvars[2140] = 30
            gvars[2141] = 51
            gvars[2142] = 24
            gvars[2143] = 9
            gvars[2144] = 18
            gvars[2145] = 9
            gvars[2146] = 30
            gvars[2147] = 30
            gvars[2148] = 67
            gvars[2149] = 72
            gvars[2150] = 24
            gvars[2151] = 24
            gvars[2152] = 73
            gvars[2153] = 24
            gvars[2154] = 73
            gvars[2155] = 73
            gvars[2156] = 73
            gvars[2157] = 27
            gvars[2158] = 73
            gvars[2159] = 73
            gvars[2160] = 3
            gvars[2161] = 3
            gvars[2162] = 24
            gvars[2163] = 0
            gvars[2164] = 78
            gvars[2165] = 65
            gvars[2166] = 0
            gvars[2167] = 51
            gvars[2168] = 0
            gvars[2169] = 57
            gvars[0] = 56
            stage.infoTransfer(4, '20\n8\n*0\n유혹')
            stage.infoTransfer(4, '46\n5\n*0\n각성')
            stage.infoTransfer(4, '47\n25\n*0\n대각성')
            stage.infoTransfer(4, '39\n1\n*0\n작은 보충 자료')
            stage.infoTransfer(4, '40\n12\n*0\n훌륭한 물자')
            stage.infoTransfer(4, '41\n10\n*0\n증원 병력')
            stage.infoTransfer(4, '42\n20\n*0\n증원 병력')
            stage.infoTransfer(4, '43\n25\n*0\n전달')
            stage.infoTransfer(4, '44\n15\n*0\n제안')
            stage.infoTransfer(4, '45\n22\n*0\n그리고 제안된 전략들')
            stage.infoTransfer(4, '57\n30\n*0\n귀환')
            stage.infoTransfer(4, '71\n18\n*0\n정교하다')
            stage.infoTransfer(4, '74\n28\n*0\n방화')
            gvars[0] = 88
            stage.infoTransfer(4, '20\n8\n*0\n유혹')
            stage.infoTransfer(4, '46\n5\n*0\n각성')
            stage.infoTransfer(4, '47\n25\n*0\n대각성')
            stage.infoTransfer(4, '39\n1\n*0\n작은 보충 자료')
            stage.infoTransfer(4, '40\n12\n*0\n훌륭한 물자')
            stage.infoTransfer(4, '41\n10\n*0\n증원 병력')
            stage.infoTransfer(4, '42\n20\n*0\n증원 병력')
            stage.infoTransfer(4, '43\n25\n*0\n전달')
            stage.infoTransfer(4, '44\n15\n*0\n제안')
            stage.infoTransfer(4, '45\n22\n*0\n그리고 제안된 전략들')
            stage.infoTransfer(4, '57\n30\n*0\n귀환')
            stage.infoTransfer(4, '71\n18\n*0\n정교하다')
            stage.infoTransfer(4, '74\n28\n*0\n방화')
            stage.setFAvatar(4, 40)
            stage.setFAvatar(5, 6)
            stage.setFAvatar(7, 0)
            stage.setFAvatar(8, 0)
            stage.setFAvatar(9, 38)
            stage.setFAvatar(12, 41)
            stage.setFAvatar(13, 45)
            stage.setFAvatar(15, 86)
            stage.setFAvatar(21, 0)
            stage.setFAvatar(22, 51)
            stage.setFAvatar(25, 43)
            stage.setFAvatar(33, 88)
            stage.setFAvatar(66, 84)
            stage.setFAvatar(69, 26)
            stage.setFAvatar(80, 74)
            stage.setFAvatar(84, 81)
            stage.setFAvatar(164, 88)
            stage.setFAvatar(169, 74)
            if model.random() < 50:
                stage.setFAvatar(2, 27)
            if model.random() < 50:
                stage.setFAvatar(34, 29)
            if model.random() < 34:
                stage.setFAvatar(119, 91)
            elif model.random() < 50:
                stage.setFAvatar(119, 92)
        gvars[4076] = 1
        pvars[276] = 4325267
        stage.varOper(0, 276, 2, 0, 235)
        gvars[4076] = 0
        if not vars[1011] and not vars[1012]:
            gvars[4076] = 1
            pvars[277] = 4223753
            stage.varOper(0, 277, 2, 0, 127)
            gvars[4076] = 0
            gvars[4071] = 255
            stage.info('3 S A B C\n합격 기준: 90, 70, 50, 0\n자격적 성장 4 3 2 1\n\n완벽한 상태: 90 70\n퍼펙트 그로스 3 2')
        else:
            gvars[4076] = 0
            pvars[277] = 4604446
            stage.varOper(0, 277, 2, 0, 16843009)
            pvars[278] = 4604450
            stage.varOper(0, 278, 2, 0, 16843009)
            pvars[279] = 4604459
            stage.varOper(0, 279, 2, 0, 16843009)
            pvars[280] = 4604467
            stage.varOper(0, 280, 2, 0, 16843009)
            gvars[4076] = 2
            pvars[281] = 4604471
            stage.varOper(0, 281, 2, 0, 257)
            gvars[4076] = 0
        if gvars[4074] == 0 and gvars[4075] == 1:
            gvars[4076] = 0
            pvars[284] = 4248941
            stage.varOper(0, 284, 2, 0, 0x89909090)
        if gvars[4074] == 1:
            gvars[4076] = 1
            pvars[284] = 4208890
            pvars[287] = 4330344
            pvars[288] = 4209294
            pvars[289] = 4330604
            stage.varOper(0, 284, 2, 0, 2)
            stage.varOper(0, 287, 2, 0, 2)
            stage.varOper(0, 288, 2, 0, 3)
            stage.varOper(0, 289, 2, 0, 3)
        if not vars[1031] and not vars[1032]:
            gvars[4076] = 2
            pvars[0] = 5273600
            gvars[0] = 0
            label('lab5425')
            if gvars[0] <= 250:
                stage.varOper(0, 0, 2, 0, 1025)
                pvars[0] += 2
                stage.varOper(0, 0, 2, 0, 1025)
                pvars[0] += 2
                stage.varOper(0, 0, 2, 0, 1025)
                pvars[0] += 4
                gvars[0] += 1
                goto('lab5425')
            gvars[4076] = 0
        if not vars[1041] and not vars[1042]:
            gvars[4076] = 1
            pvars[0] = 5273606
            gvars[0] = 0
            label('lab5446')
            if gvars[0] <= 250:
                stage.varOper(0, 0, 2, 0, 255)
                pvars[0] += 8
                gvars[0] += 1
                goto('lab5446')
            gvars[4076] = 0
            stage.infoTransfer(5, '13\n3\n63\n곰 조련사 - 마비 공격')
            stage.infoTransfer(5, '15\n3\n71\n어스 퍼펫 - 카오스 공격')
            stage.infoTransfer(5, '16\n3\n70\n나무 인간 - 독 공격')
            stage.infoTransfer(5, '100\n3\n36\n댄서 - 주변 상태 회복')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
