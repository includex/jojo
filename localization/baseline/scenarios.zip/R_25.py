# Source Generated with Decompyle++
# File: R_25.marshal (Python 3.9)


def scene0():
    '''곽가 사망'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.delay(3)
    stage.setMenuVisible(False)
    if not vars[724]:
        stage.bgSound(13)
        stage.delay(3)
        stage.loadBg(2, 5)
        stage.showUnits([
            [
                22,
                55,
                46,
                2,
                10],
            [
                203,
                58,
                43,
                2,
                14],
            [
                0,
                52,
                52],
            [
                1,
                60,
                52],
            [
                2,
                58,
                60]])
        stage.draw()
        stage.setEventName('곽가 사망')
        stage.setStageName('난피 곽가 현')
        stage.say('봉효!')
        stage.unit(1).setAction(0, 3)
        stage.say('&1\n맹덕......')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n원양, 펑샤오 상태는 어때?\n&1\n의사의 진단에 따르면,\n상황을 되돌릴 방법은 없었다.')
        model.setFace(1)
        stage.say('&0\n무슨 ......!?')
        stage.say('&22\n…… 주군......?')
        stage.unit(1).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        model.setFace(0)
        stage.say('아아, 저예요…\n주군… 아무래도 여기서 헤어져야 할 것 같네요……')
        stage.say('&0\n너...... 무슨 소리야?')
        stage.say('&22\n주군, 내가 죽은 후에 중요한 책임을 맡가후 부탁드립니다.\n그는... 패권을 달성하는 데 주군 도울 수 있어......\n&0\n알겠어......\n&22\n그리고 이 사람은요......')
        stage.unit(0).move(52, 48, 0)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.say('&0\n이게 뭐야?\n&22\n이것은 둔자 천서입니다,\n분명히 도움이 될 거예요.\n&0\n펑샤오 ......')
        stage.getItem(133, 0)
        stage.say('&22\n주군... 흠!\n음, 기침!')
        stage.unit(0).setAction(0)
        stage.say('봉효, 그만둬!')
        stage.say('&22\n......주군, 반드시 세상을 장악할 것이다......\n&22\n저는 정말 제 눈으로 주군의 세계를 보고 싶어요......\n기침 ...... 기침 ...... 음음음!!')
        model.setFace(1)
        stage.unit(0).setAction(2)
        stage.say('봉, 봉효!')
        stage.unit(1).setAction(2)
        stage.say('&1\n곽가Sir!')
        stage.unit(2).setAction(6)
        stage.say('&2\n곽가Sir!')
        stage.unit(0).setAction(4)
        model.setFace(0)
        stage.say('봉효 같으니라고!!')
        model.unitJoin(22, 255, 0)
        stage.info('신뢰조조 전략가곽가 죽었어.\n이 사건을 떠올리조조 그는 종종 깊은 한숨을 내쉬었다.\n정말로, 재능 있는 사람이 일찍 세상을 떠났다.')
        model.setFace(0)
        stage.bgSound(-1)
        stage.clsUnit()
    stage.bgSound(-1)
    stage.delay(3)
    if vars[724]:
        stage.loadBg(2, 46)
        stage.showUnits([
            [
                114,
                50,
                69],
            [
                115,
                50,
                55,
                2]])
        stage.draw()
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.setEventName('허베이는 평정되었다')
        stage.setStageName('류청 원상 저택')
        stage.unit(114).setAction(0, 1)
        stage.say('&114\n휴, 조준은 정말 무시무시하다.\n그들은 다시 그를 밀어냈다.')
        stage.unit(115).setAction(6)
        stage.say('&115\n그런데, 형. 앞으로 어떻게 할까?\n이 전투들 이후,\n그들의 병력은 거의 고갈되었다......')
        stage.unit(115).setAction(0)
        stage.delay(3)
        stage.unit(114).setAction(0, 0)
        stage.say('&114\n네, 삼형님. 북쪽이 보이죠?')
        stage.unit(115).setAction(6)
        stage.say('&115\n응?\n유주로 간다는 거야?')
        stage.unit(115).setAction(0)
        stage.say('&114\n네.\n유주에 도착하자마자,\n조의 군대는 아마 그렇게 쉽게 공격하지 않을 것이다.')
        stage.unit(114).setAction(3)
        stage.say('&114\n게다가 이 지역에는 큰 전쟁이 없었고,\n더 많은 병력을 동원할 수 있게 해줍니다.')
        stage.unit(114).setAction(0)
        stage.delay(3)
        stage.unit(115).setAction(3)
        stage.say('&115\n그래서 그런 거야.\n쉬두와 유주는 멀리 떨어져 있다,\n조조 행동하기가 정말 어렵습니다.')
        stage.unit(115).setAction(0)
        stage.delay(3)
        stage.unit(114).setAction(3)
        stage.say('&114\n좋아! 결정됐어.\n바로 출발합시다.')
        stage.unit(114).setAction(0)
        stage.delay(3)
        stage.unit(115).setAction(6)
        stage.say('&115\n좋아!')
        stage.effectSound(200, 255)
        stage.clsUnit()
    stage.loadBg(2, 67)
    stage.draw()
    stage.showUnits([
        [
            186,
            48,
            95],
        [
            185,
            56,
            95]])
    if not vars[724]:
        stage.setEventName('허베이는 평정되었다')
    stage.setStageName('류청 외곽의 산길')
    stage.unitsMove([
        [
            stage.unit(186),
            48,
            46,
            0],
        [
            stage.unit(185),
            56,
            46,
            0]])
    stage.unit(185).setAction(0)
    stage.unit(186).setAction(0)
    stage.say('&186\n진심이야!\n장난해?')
    stage.unit(185).setAction(0, 3)
    stage.say('&185\n이봐, 이봐, 진정해.')
    stage.unit(186).setAction(0, 1)
    stage.say('&186\n그래도 침착할 수 있을까요?\n전쟁을 그냥 할 수는 없어\n그냥 우리 농부들을 전쟁에 끌어들여!\n&186\n이제 우리가 싸움에서 졌으니,\n음식조차 남아 있지 않았다,\n이 문제에 대해 어떻게 해야 할까요?\n&185\n이것은 당연한 일이었다.\n우리는 단지 눈에 띄지 않는 무명인일 뿐이야,\n그는 감독이 어떻게 생겼는지도 몰랐다.\n&186\n요컨대, 허세 부리는 건 통하지 않아요!\n어떤 명문 원가?\n&185\n야, 크게 소리 지르지 마......\n&186\n야, 아무도 안 올 거야.\n누가 여기 올까......')
    stage.unit(186).setAction(0, 2)
    stage.say('&186\n…… 응?')
    stage.say('&185\n뭐라고...... 무슨 일이야?')
    stage.unit(186).setAction(0, 1)
    stage.say('&186\n부유한 집안 출신으로 보이는 두 사람이 왔다......\n이봐, 귀를 좀 더 가까이 가져와......\n&185\n뭐 하는 거야......?')
    stage.unit(185).move(52, 46, 3)
    stage.delay(3)
    stage.unit(185).setAction(0, 2)
    stage.bgSound(12)
    stage.delay(5)
    stage.say('&185\n응?\n죽여...... 그들을 죽여!?\n&186\n멍청한 ...... 바보야!\n그렇게 시끄럽게 굴지 마!')
    stage.unit(185).setAction(0, 3)
    stage.say('&185\n하지만 ...... 그런데 왜 그들을 죽였을까......?\n&186\n어쨌든, 이 두 남자는\n아마도 보통 우리를 괴롭히는 사람들일 거예요.\n&186\n그리고 만약 네가 돈을 얻는다면,\n마을로 돌아가 좋은 삶을 살 수도 있어.\n빨리! 숨어!')
    stage.unit(186).move(32, 49, 1)
    stage.unit(186).setAction(0)
    stage.unit(185).move(66, 66, 3)
    stage.unit(185).setAction(0)
    stage.delay(3)
    stage.showUnits([
        [
            115,
            48,
            95],
        [
            114,
            56,
            95]])
    if not vars[724]:
        stage.unitsMove([
            [
                stage.unit(115),
                48,
                74,
                0],
            [
                stage.unit(114),
                56,
                74,
                0]])
        stage.delay(3)
        stage.unit(114).setAction(0, 3)
        stage.delay(3)
        stage.unit(114).setAction(3)
        stage.say('&114\n이봐, 셋째 형, 빨리 와! 이 시점에서,\n유일한 선택지는 북쪽의 유주로 도망치는 것이었다.')
        stage.unit(114).setAction(0)
        stage.delay(3)
        stage.unit(115).setAction(0, 1)
        stage.delay(3)
        stage.unit(115).setAction(6)
        stage.say('&115\n네.')
        stage.unit(115).setAction(0)
        stage.say('&114\n그곳에서 병사를 모집하고 말을 구입했다,\n컴백할 준비를 해.')
    if vars[724]:
        stage.unitsMove([
            [
                stage.unit(115),
                48,
                74,
                0],
            [
                stage.unit(114),
                56,
                74,
                0]])
        stage.delay(3)
        stage.unit(114).setAction(0, 3)
        stage.delay(3)
        stage.unit(114).setAction(3)
        stage.say('&114\n어서, 삼형, 출발할 거야!')
        stage.unit(114).setAction(0)
        stage.delay(3)
        stage.unit(115).setAction(0, 1)
        stage.delay(3)
        stage.unit(115).setAction(6)
        stage.say('&115\n네.')
        stage.unit(115).setAction(0)
    stage.unitsMove([
        [
            stage.unit(115),
            48,
            49,
            0],
        [
            stage.unit(114),
            56,
            49,
            0]])
    stage.unit(115).setAction(0)
    stage.unit(114).setAction(0)
    stage.bgSound(-1)
    stage.delay(5)
    stage.say('&186\n이봐!')
    stage.unit(115).setAction(0, 3)
    stage.say('&115\n응? 누구야!?\n&186\n꺼져!!')
    stage.unit(186).move(44, 49, 1)
    stage.unit(114).setAction(0, 3)
    stage.delay(3)
    stage.effectSound(34, 1)
    stage.unit(186).setAction(13)
    stage.delay(8)
    stage.effectSound(36, 1)
    stage.unit(186).setAction(14)
    stage.say('&115\n음, 와!')
    stage.delay(5)
    stage.unit(115).setAction(10)
    stage.delay(3)
    stage.unit(114).setAction(3)
    stage.say('&114\n응? 셋째 형!\n젠장, 작은 졸개!\n&185\n음음음음.........\n지금은 그렇습니다......\n너도 나와 함께 죽어야 해!')
    stage.unit(185).move(56, 53, 0)
    stage.delay(3)
    stage.effectSound(34, 1)
    stage.unit(185).setAction(13)
    stage.delay(8)
    stage.effectSound(36, 1)
    stage.unit(185).setAction(14)
    stage.say('&114\n아......!')
    stage.delay(5)
    stage.unit(114).setAction(10)
    stage.say('&114\n나, 어떻게 그럴 수 있.........\n이런 곳에서 죽다니......\n아버지, 아버지......')
    stage.say('&185\n죽었어, 죽었어......\n야, 다 죽었어!\n&186\n당연히 멍청이지!\n어서 귀중품을 치워라,\n가장 좋은 전략은 36가지 전략을 들고 도망치는 것입니다!\n&185\n흠, 흠......\n&186\n이제 마을로 돌아갈 수 있어.')
    stage.clsUnit()
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.delay(5)
    stage.showHead(0, 426, 0)
    stage.showHead(115, 490, 0)
    stage.showHead(114, 554, 0)
    stage.delay(8)
    stage.head(115).hide()
    stage.head(114).hide()
    stage.delay(5)
    stage.bottomTxt('그리하여 한나라의 명문 원씨가 멸망했다,\n과거의 번영과 비교하면, 결말은 너무나도 암울하다.', False, False, True)
    stage.bottomTxt('허베이를 평정한 조조 원가가 몰락한 후,\n그리하여 그는 가장 강력한 군벌이 되기 위해 도약했다.', False, False, True)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.sectionName(3, '삼국지는 균형을 이루고 있었다')
    stage.bgSound(-1)
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            0,
            52,
            28,
            2],
        [
            1,
            38,
            48,
            1],
        [
            15,
            38,
            54,
            1],
        [
            8,
            38,
            60,
            1],
        [
            13,
            38,
            66,
            1],
        [
            2,
            38,
            72,
            1],
        [
            20,
            67,
            48,
            3],
        [
            23,
            67,
            54,
            3],
        [
            24,
            67,
            60,
            3],
        [
            21,
            67,
            66,
            3],
        [
            25,
            67,
            72,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setEventName('제갈공명 나타났다')
    stage.setStageName('예시: 임시 총리 관저')
    stage.say('&0\n문약, 그는 마침내 원씨 가문을 제거했다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n그래! 그렇게 하면 후방에서 걱정할 필요가 없을 거야.')
    stage.unit(20).setAction(0)
    stage.say('&0\n미래의 적은 남부와 서부가 될 것이다......')
    stage.unit(21).setAction(6)
    stage.say('&21\n그 앞에 남은 적은 류뱌오와 징저우 유비뿐이었다.\n그리고 동우의 손권.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n특히 동우 손권,\n그 번영과 번영은 놀랍습니다.')
    stage.unit(23).setAction(0)
    stage.say('&0\n음, 정말손권......?')
    stage.showUnit(159, 52, 92)
    stage.say('&159\n아버지.')
    stage.unit(159).move(52, 48, 0)
    stage.say('&159\n아버지!\n&0\n아, 쯔젠이구나.\n내가 떠나 있는 동안,\n예시는 모두 당신의 통치 덕분입니다. 수고하셨습니다.')
    stage.unit(159).setAction(6)
    stage.say('&159\n감사합니다, 아버지.')
    stage.unit(159).setAction(0)
    stage.say('&159\n아버지, 좋은 징조를 전하러 왔습니다.\n&0\n좋은 징조?')
    stage.unit(159).setAction(6)
    stage.say('&159\n그래! 누군가 시골 밖 들판에 있어,\n거대한 청동 참새 조각상이 발굴되었습니다.\n&0\n거대한 청동 참새 조각상?\n&159\n네.')
    stage.unit(159).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n오! 정말 좋은 징조네.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n네! 틀림없어요.')
    stage.unit(21).setAction(0)
    stage.say('&0\n흠......')
    stage.unit(1).setAction(3)
    stage.say('&1\n이봐, 이봐. 왜 청동 참새가 좋은 징조를 상징하는 거지?')
    stage.unit(1).setAction(0)
    stage.say('&13\n네. 완전히 혼란스러워요.')
    stage.unit(159).setAction(0, 2)
    stage.delay(3)
    stage.say('&8\n이것은 순황제의 이야기입니다.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n순황제의 이야기?\n&8\n네.')
    stage.say('&8\n고대 순황제가 태어났을 때,\n어머니는 꿈을 꾸셨다,\n진주와 옥으로 장식된 참새가 그의 품에 날아들었다.')
    stage.unit(8).setAction(3)
    stage.say('&8\n이제 아버지께서 청동 참새를 얻으셨으니,\n패권의 성취를 기념하는 좋은 징조입니다.')
    stage.unit(8).setAction(0)
    stage.say('&1\n아! 알겠어......')
    stage.unit(1).setAction(0, 1)
    stage.say('&159\n형이 한 말이 전적으로 옳습니다.')
    stage.unit(159).setAction(0, 0)
    stage.say("&159\n아버지, 이 길조의 징조를 기념하기 위해,\n높은 플랫폼을 만들어 '청동 참새 테라스'라고 이름 붙이는 것이 더 나을 것입니다.\n어떻게 생각하세요, 신부님?")
    stage.unit(21).setAction(6)
    stage.say('&21\n오, 조지의 후계자라니, 정말 좋은 생각이야!')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(25).setAction(0, 0)
    stage.delay(3)
    stage.unit(25).setAction(6)
    stage.say('&25\n주군, 이건 전 세계 사람들을 위한 쇼야......\n주군 웨이이에게 좋은 기회야.')
    stage.unit(25).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n주군, 건설에 꼭 동의해 주세요!')
    stage.unit(21).setAction(0)
    stage.say('&0\n흠......')
    stage.effectSound(200, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('청동 참새 테라스 건설\n청동 참새 테라스는 건설하지 않았다', 0)
    if sel == 1:
        vars[309] = 1
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n좋아.\n쯔젠, 네 말대로 이건 정말 좋은 징조야.\n아마도 하늘도 내가 패권을 이루길 원할지도 모른다.')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n쯔젠, 청동 참새 테라스 건설을 감독해라.\n괜찮을까요?')
        stage.unit(159).setAction(6)
        stage.say('&159\n네.\n내가 처리할게.')
        stage.unit(159).setAction(0)
        stage.say('&0\n좋아! 자, 저 청동 참새를 보러 가자.')
        stage.unit(1).setAction(3)
        stage.say('&1\n네.')
        stage.unitsMove([
            [
                stage.unit(1),
                38,
                99,
                2],
            [
                stage.unit(8),
                38,
                99,
                2],
            [
                stage.unit(13),
                38,
                99,
                2],
            [
                stage.unit(15),
                38,
                99,
                2],
            [
                stage.unit(2),
                38,
                99,
                2],
            [
                stage.unit(25),
                67,
                99,
                2],
            [
                stage.unit(24),
                67,
                99,
                2],
            [
                stage.unit(21),
                67,
                99,
                2],
            [
                stage.unit(23),
                67,
                99,
                2],
            [
                stage.unit(159),
                52,
                99,
                2]])
        stage.unit(159).hide()
        stage.unit(1).hide()
        stage.unit(25).hide()
        stage.unit(15).hide()
        stage.unit(24).hide()
        stage.unit(8).hide()
        stage.unit(21).hide()
        stage.unit(13).hide()
        stage.unit(23).hide()
        stage.unit(2).hide()
        stage.say('&0\n……문약.')
        stage.unit(20).setAction(0, 0)
        stage.say('&20\n존재한다.\n&0\n방금 침묵했는데, 왜?\n청동 참새 테라스 건설에 반대하시나요?')
        stage.unit(20).setAction(6)
        stage.say('&20\n아, 그게 아니야.\n부하들은 반대하지 않았다.\n하지만 ......\n&20\n주군에게 묻고 싶은 게 있어.\n&0\n무슨 일이야?\n&20\n…… ...... 청동 참새를 땅속에 묻은 사람,\n혹시 저 주군 걸까요?!\n&0\n…… 정말 그렇게 생각해?')
    elif sel == 2:
        vars[309] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n지을 수 없어!\n&159\n아!?\n&21\n뭐라고?')
        model.setFace(0)
        stage.unit(23).setAction(0, 0)
        stage.delay(3)
        stage.unit(23).setAction(6)
        stage.say('&23\n주군Why 그렇게 말할 수 있겠어!?"\n말씀해 주시겠어요?')
        stage.unit(23).setAction(0)
        stage.say('&0\n이렇게 높은 플랫폼을 짓다니,\n막대한 자금이 필요합니다,\n물론, 그것은 국민으로부터 빼앗아야 합니다.')
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n허베이 지역은 수년간 전쟁에 휩싸여 있었고,\n땅은 척박했고, 사람들은 고난 속에 살았다.')
        stage.unit(0).setAction(0, 2)
        stage.delay(3)
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n도광대를 쌓는다고 해서,\n백성들에게 돈을 더 짜낼 수는 없어!')
        model.setFace(0)
        stage.unit(159).setAction(6)
        stage.say('&159\n이게 어떻게 돈을 착취할 수 있을까요?\n아버지, 이건 길조입니다......\n&0\n닥쳐, 쯔젠!\n이런 것들만 한다면,\n국가 강세를 키우는 방법!\n&159\n…………………\n&0\n모두 밖으로 나가!\n군사 퍼레이드가 시작될 시간이었다.\n&1\n오, 오......')
        stage.unitsMove([
            [
                stage.unit(1),
                38,
                99,
                2],
            [
                stage.unit(25),
                67,
                99,
                2],
            [
                stage.unit(15),
                38,
                99,
                2],
            [
                stage.unit(24),
                67,
                99,
                2],
            [
                stage.unit(8),
                38,
                99,
                2],
            [
                stage.unit(21),
                67,
                99,
                2],
            [
                stage.unit(13),
                38,
                99,
                2],
            [
                stage.unit(23),
                67,
                99,
                2],
            [
                stage.unit(2),
                38,
                99,
                2],
            [
                stage.unit(0),
                52,
                99,
                2]])
        stage.unit(0).hide()
        stage.unit(1).hide()
        stage.unit(25).hide()
        stage.unit(15).hide()
        stage.unit(24).hide()
        stage.unit(8).hide()
        stage.unit(21).hide()
        stage.unit(13).hide()
        stage.unit(23).hide()
        stage.unit(2).hide()
        stage.unit(20).setAction(6)
        stage.say('&20\n조지의 후계자......')
        stage.unit(159).setAction(0)
        stage.delay(3)
        stage.unit(159).setAction(0, 1)
        stage.say('&159\n순욱 씨.\n&159\n모두가 불필요하다고 자책한다,\n이 말에 아버지는 화가 났습니다.\n&20\n이걸 불필요하다고 할 수 있겠어?\n&159\n하지만.........\n&20\n조지의 후계자가 청동 참새의 테라스를 짓는다.\n&159\n어!?\n&20\n자금은 걱정하지 마; 주군 전에 나한테 줬어\n많은 보석들, 그 귀중한 옥 조각들이 돈으로 팔린다면,\n은화만으로도 건설 비용을 충당할 수 있었다.\n&159\n하지만 아버지는 이미 분명히 말씀하셨다,\n아버지의 명령을 어떻게 거역할 수 있겠어......?\n&20\n조지의 후계자,\n주군 청동 참새 테라스를 건설하는 것의 장점도 알고 있었다.\n&20\n하지만......... 그는 사람들을 더 신경 썼다.\n&20\n게다가 이제 내 재산이 사용되고 있으니,\n평민들로부터 뽑아내지 않았다,\nTherefore주군 절대 화내지 않을 거예요.\n&159\n하지만............\n이 모든 것은 순욱 씨의 소유입니다......\n&20\n음, ......, 나는 물질적인 것에는 관심 없어.\n&20\n그리고 이 돈이 무엇을 할 수 있는지 알아내기 위해서는,\n저도 꽤 오랫동안 걱정해왔어요.\n&159\n순욱...... 씨\n&20\n가서 만들어 보세요.\n&20\n주군 정말 화가 난다면,\n모든 책임은 내가 지겠다.\n&159\n순욱...... 씨\n&20\n괜찮을까요?\n&159\n흠!\n&20\n저도 그렇게 생각해요.\n결국 세자 조지는 매우 똑똑했다.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 370, 21)
    stage.bottomTxt('조조는 조식에게 업성의 통치를 맡겼고,', False, False, False)
    stage.delay(5)
    stage.head(0).move(339, 102)
    stage.delay(5)
    stage.bottomTxt('쉬두로 돌아갔다.', True, False, True)
    stage.bottomTxt('이 시점에서,', False, False, False)
    stage.delay(5)
    stage.showHead(32, 244, 166)
    stage.delay(5)
    stage.bottomTxt('유비 류표의 임무를 수락해 신예 방어를 했다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('조조 이 사실을 알게 된 후,', True, True, False)
    stage.head(0).hide()
    stage.delay(5)
    stage.showHead(5, 304, 70)
    stage.delay(5)
    stage.bottomTxt('그는 조인에게 명령했다', True, False, False)
    stage.delay(5)
    stage.showHead(11, 368, 110)
    stage.delay(5)
    stage.bottomTxt('그리고 이전', True, False, False)
    stage.delay(5)
    stage.head(5).move(244, 86)
    stage.head(11).move(308, 126)
    stage.delay(5)
    stage.bottomTxt('신예를 공격하기 위해 진격했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            2,
            64,
            70],
        [
            5,
            52,
            58,
            3,
            11],
        [
            11,
            52,
            52,
            3,
            11]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.info('한 달 후......', 3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n뭐라고? 참담한 패배?\n&5\n네, 제 무능함을 용서해 주세요.')
    stage.unit(21).setAction(6)
    stage.say('&21\n무슨 ......!')
    stage.unit(21).setAction(0)
    stage.say('&0\n왜?\n&0\n비록 관우와 장비는 세계에서 드문 맹렬한 장군이었지만,\n결국 여러분 모두 전투에 단련되어 있으니,\n어떻게 아직도 패배하고 먼지투성이일 수 있지......\n&11\n우리가 실패한 이유는,\n그것은 전략가 산푸아군 유비보다 덜 영리했기 때문이었다.\n&0\n전략가 샨푸?\n이 이름은 들어본 적이 없어요.\n&5\n이 남자는 지적이고 지략이 뛰어나며, 두려움을 불러일으킵니다,\n그는 우리의 진형과 행동을 꿰뚫어봤다.\n&0\n흠......\n&11\n부하 장군은 이미 전투에서 패배했다,\n어떻게 방어할 이유가 있을 수 있겠는가?\n그래도 총장님께 이 일을 맡겨 달라고 요청합니다.\n&0\n잊어버려.\n&5\n응?\n......주군?\n&0\n내가 말했잖아, 그만둬.')
    stage.unit(0).setAction(3)
    stage.say('&0\n전쟁에서 승패는 흔한 문제입니다,\n이것도 피할 수 없는 일입니다.\n모두 수고 많으셨습니다. 이제 쉬세요.')
    stage.unit(0).setAction(0)
    stage.say('&5\n네.\n&11\n네!')
    stage.unitsMove([
        [
            stage.unit(11),
            98,
            52,
            1],
        [
            stage.unit(5),
            98,
            58,
            1]])
    stage.unit(11).hide()
    stage.unit(5).hide()
    stage.say('&0\n산 푸가 누군지 아는 사람 있나요?')
    stage.unit(21).setAction(6)
    stage.say('&21\n주군, 나는 산푸와 같은 고향 출신이야,\n그는 이 사람을 아주 잘 알고 있었다.\n&0\n중더는 어떤 사람이었을까?')
    stage.unit(21).setAction(0)
    stage.say('&21\n사실 단푸의 원래 이름은 쉬쉬였다,\n그는 매우 지적이고 수완이 뛰어난 사람이었다.\n&21\n그는 친구를 위해 일어서고 싶었다,\n살인을 저지른 후 그는 사라졌다,\n그들과 함께할 줄은 전혀 예상하지 못했now유비......')
    stage.unit(21).setAction(6)
    stage.say('&21\n지금은 쉬쉬가 도와주고 있다,\n앞으로 유비을 깨기는 어려울 것입니다.')
    stage.unit(21).setAction(0)
    stage.say('&0\n흠......\n네가 그런 말을 할 줄은 몰랐어......')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n그가 나를 섬기려 한다면,\n나는 반드시 그를 높은 관직과 후한 보상으로 승진시키겠다......\n그럼에도 그는 유비...... 편에 합류하기로 선택했다')
    stage.unit(21).setAction(6)
    stage.say('&21\n주군, 지금은 포기할 때가 아니야.\n쉬쉬를 처리할 계획이 있어......')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n어떤 전략?\n&21\n사실 쉬슈의 어머니도 쉬두에 있었다.')
    stage.unit(21).setAction(0)
    stage.say('&21\n서서는 효자였다,\n만약 어머니를 설득해 자신을 데려오게 할 수 있다면,\n그는 분명히 주군에 합류할 것이다.\n&0\n흠......\n좋아, 바로 끝내.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.\n반드시 당신의 신뢰에 부응하겠습니다.')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(0, 35)
    stage.draw()
    stage.info('Afterwards정욱 쉬의 어머니를 접대했는데,\n그는 그녀에게 쉬슈를 쉬두로 초대하라고 설득하려 했다,\n하지만 쉬의 어머니는 결코 동의하지 않았다.')
    stage.info('그 설득이 실패하는 것을 보고정욱 그는 쉬의 어머니 필체를 따라 했다,\n그는 편지를 위조해 쉬서에게 보냈다.')
    stage.info('쉬쉬는 그것이 사기인지 몰랐지만, 어머니에게 효도를 보이기 위해서였다.\n그는 그 후 떠나유비 조조가 살던 쉬두로 갔다.')
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            21,
            52,
            40,
            2],
        [
            151,
            52,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&151\n그리고 총리에게 경의를 표했다.\n나는 쉬쉬, 쉬위안즈다.\n&0\n저는 조맹덕입니다.\n위안즈, 오랫동안 기다렸어.\n&151\n총리님, 은혜를 베풀어 주셔서 감사합니다.\n&0\n이제부터 아버지와 함께 쉬두에서 살면서,\n나를 섬겨라.\n&151\n네, 총리님.\n지금 어머니가 어디 계신지 모르겠습니다.\n&0\n네 어머니는 도시 외곽 집에 계셔.\n&151\n그래서 그런 거야.\n어머니를 보고 싶어서 자리를 떴습니다.\n&0\n흠. 편하게 있어.\n&151\n총리님께 깊이 감사드립니다.\n그럼 저는 이만 가보겠습니다.')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(151).move(98, 55, 1)
    stage.unit(151).hide()
    stage.say('&0\n중더가 이번에는 정말 대단한 일을 해냈다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n셰 주군.\n&21\n(만약 그 편지가 가짜라는 걸 안다면,\n쉬쉬는 아군를 섬기지 않을 것이다. )\n&21\n(하지만 괜찮아,\n유비 권력은 약해졌다. )')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 36)
    stage.showUnit(152, 53, 42, 2)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('쉬두: 쉬쉬의 어머니 거주지입니다')
    stage.showUnit(151, 53, 90)
    stage.say('&151\n어머니!\n&152\n모토나오!?')
    stage.unitsMove([
        [
            stage.unit(151),
            53,
            85,
            0],
        [
            stage.unit(152),
            58,
            42,
            1]])
    stage.unitsMove([
        [
            stage.unit(151),
            53,
            74,
            0],
        [
            stage.unit(152),
            58,
            53,
            2]])
    stage.unitsMove([
        [
            stage.unit(151),
            53,
            61,
            0],
        [
            stage.unit(152),
            53,
            53,
            2]])
    stage.delay(3)
    stage.unit(151).setAction(6)
    stage.say('&151\n엄마, 너무 보고 싶어요.\n&152\n오, 위안즈, 오랜만이야.\n그런데 어떻게 여기까지 오게 된 거야?\n지금 류 삼촌 모시는 거 아니야?')
    stage.unit(151).setAction(0)
    stage.say('&151\n어머니, 왜 여기 와서 물어보셨어요?\n아이는 어머니로부터 편지를 받았다,\n저는 그냥 쉬안더에게 작별 인사를 하고 주군 돌아왔습니다.\n&152\n내 편지?\n&151\n네, 바로 여기요.')
    stage.unit(151).move(53, 57, 0)
    stage.delay(5)
    stage.unit(151).move(53, 61, 0)
    stage.say('&152\n이게 ......야?\n&152\n위안즈, 너는 어릴 때부터 시와 문학을 공부했지,\n어떻게 이 위조된 편지를 믿을 수 있을까......\n&151\n가짜 편지!?\n&152\n너무 혼란스러워......\n어머니가 어떻게 그런 편지를 쓸 수 있지!\n이거 안 보여?')
    stage.unit(152).setAction(0, 0)
    stage.say('&152\n나 같은 늙은 여자가 이런 걸 할 줄은 몰랐어,\n이렇게 좋은 주군......를 포기하다니\n&151\n아이야, 아이야......')
    stage.unit(152).setAction(0, 2)
    stage.say('&152\n위안즈, 효심이 효보다 낫다는 걸 모르니...?\n너무 혼란스러워... 어떻게 그렇게 혼란스러울 수가 있어......')
    stage.unit(152).move(57, 53, 1)
    stage.say('&152\n이 모든 게 이 노파가 아직 이 세상에 살아 있기 때문이야......')
    stage.unit(152).move(57, 98, 2)
    stage.unit(152).hide()
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n아! 어머니!')
    stage.delay(10)
    stage.effectSound(202, 255)
    stage.bgSound(13)
    stage.delay(3)
    stage.unit(151).setAction(4, 2)
    stage.say('&151\n어머니......')
    stage.delay(10)
    stage.say('&189\n아!!')
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n뭐라고...... 무슨 일이야!?')
    stage.clsUnit()
    stage.loadBg(2, 37)
    stage.showUnits([
        [
            152,
            45,
            54,
            1,
            10],
        [
            189,
            45,
            48,
            2]])
    stage.draw()
    stage.showUnit(151, 20, 54, 1)
    stage.say('&151\n어머니 ...... 어머니!!')
    stage.unit(151).move(39, 54, 1)
    stage.unit(151).setAction(0)
    stage.say('&189\n노부인이 갑자기 ...... 갑자기 칼을 뽑았다\n네 가슴을 찔러라......')
    stage.unit(151).setAction(4)
    stage.say('&151\n...... 왜 이게 ......지?')
    stage.unit(151).setAction(9)
    stage.say('&151\n어머니, 너무 혼란스러워서 다 제 잘못이에요......')
    stage.say('&151\n어머니 ...... 어머니!!\n우우우우우!!')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene5():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.bottomTxt('이 시점에서,', False, False, False)
    stage.delay(8)
    stage.showHead(35, 311, 178)
    stage.delay(5)
    stage.bottomTxt('상양 서쪽의 작은 마을 롱중에는 잠자는 용이라 불리는 현자가 있었다,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('이름은 제갈량야.', True, True, True)
    stage.showHead(32, 233, 142)
    stage.delay(5)
    stage.bottomTxt('신예의 유비', False, False, False)
    stage.delay(5)
    stage.head(32).move(247, 178)
    stage.delay(5)
    stage.bottomTxt('초가지붕 오두막을 세 번 방문한 후, 나는 제갈량에게 내 요청을 맡겼다,', True, False, False)
    stage.delay(5)
    stage.head(32).move(223, 142)
    stage.head(35).move(287, 142)
    stage.delay(5)
    stage.bottomTxt('결국 그는 그를 은퇴에서 복귀시켜 군사 고문으로 임명하는 데 성공했다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            2,
            64,
            70]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('방금 보고를 받았는데, 유비가 또 제갈량이라는 군사를 찾았다고 하더군요. 지금 군무를 정비하며 훈련을 강화하고 있습니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n유비 쉬쉬가 죽은 후 그를 잃었고,\n그는 또 다른 전략가를 데려왔다......\n&20\n이 사람은 훨씬 더 뛰어나야 해.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흠.\n&0\n이렇게 유능한 사람이 유비를 돕는다면,\n지금 그들을 없애지 않으면,\n앞으로는 더 까다로워질 것입니다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n방금 전에 제갈량 말씀하셨죠,\n그냥 젊은 학자 아니야?\n맹덕, 내가 유비 찾아가게 해줘.\n&0\n너는? 원양......')
    stage.unit(1).setAction(0)
    stage.say('&1\n공명 이걸 문제 삼을 만큼 소란을 피울 가치가 있을까요!\n그냥 어린 아이일 뿐이야,\n특별한 일은 아닌 것 같아요.')
    stage.unit(20).setAction(6)
    stage.say('&20\n하후돈General, 너무 부주의해서는 안 돼."')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n순욱 씨, 말씀해 주세요,\n날 믿어도 된다고 하후돈지?\n수많은 전투를 겪어보니 경험이 많아졌어요.\n&20\n장군의 힘은 잘 알고 있어......\n주군, 어떻게 생각해?\n&0\n흠......')
    stage.effectSound(200, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('공격하게 하후돈 동의유비\n공명 소식이 올 때까지 기다려', 0)
    if sel == 1:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.say('&0\n네가 그렇게 말하니까.\n원양, 널 벌주러 보내유비.\n&0\n하지만 이런 큰 말들 후에는,\n만약 우리가 전투에서 지면, 나는 그들을 엄하게 벌할 것이다.\n&1\n좋아! 그때가 되면 내 머리를 넘겨줄게.')
    elif sel == 2:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.say('&0\n원양, 네 정신은 칭찬받을 만하다,\n하지만 공명 정보를 얻은 후에 결정을 내리는 게 낫다.\n&1\n뭐라고...... 뭐라고!?\n맹덕 그렇게 말해도,\n아직도 이해가 안 돼!\n&1\n내가 하후돈하다고 생각하지,\n그가 공명 아이에게 질까!?\n&0\n그게 내가 말하려던 게 아니야,\n요컨대, 조심하는 것이 좋습니다.\n&1\n네가 뭐라 해도,\n내가 처리할게, 알겠지공명?\n&0\n지지 않을 거라고 보장할 수 있어?\n&1\n물론이지! 내 머리에 걸게.\n&0\n좋아.\n네가 그렇게 말했으니, 나는 군대를 보내기로 동의한다,\n하지만 방금 한 말을 잊지 마세요.\n&1\n흠!\n저는 단어가 무게를 지닌 하후돈 있습니다!')
    stage.unit(1).setAction(0)
    stage.say('&0\n좋아! 유진이랑 이전 같이 가자,\n그래서 내가 네 도움의 손길을 내밀 수 있어,\n결정은 당신에게 달렸습니다.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene6():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(32, 245, 172)
    stage.showHead(1, 335, 93)
    stage.delay(5)
    stage.bottomTxt('하후돈,', False, False, False)
    stage.delay(5)
    stage.showHead(14, 271, 83)
    stage.delay(5)
    stage.bottomTxt('유진,', True, False, False)
    stage.delay(5)
    stage.showHead(11, 399, 103)
    stage.delay(5)
    stage.bottomTxt('이전 세 명', True, False, False)
    stage.delay(8)
    stage.head(14).move(211, 92)
    stage.head(1).move(275, 92)
    stage.head(11).move(399, 172)
    stage.head(11).move(309, 172)
    stage.delay(5)
    stage.bottomTxt('그는 신예로 진격해 유비을 공격했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 13)
    stage.showUnit(32, 73, 55, 3)
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('신예 유비 거주지')
    stage.showUnit(35, 5, 55, 1)
    stage.say('&35\n보고해.')
    stage.unit(35).move(55, 55, 1)
    stage.say('&35\n주군, 나 보러 왔어?\n&32\n아, 전략가.\n기다리고 있어.\n&32\n방금 보고서를 받았어요,\n조조 군대가 신예를 향해 진격하고 있었다.\n&35\n정말?\n&32\n그 웅장함이 정말 위압적이라고 들었어요!\n어떻게 해야 할까요?\n우리 작은 도시는 버티지 못할 것 같아.\n&35\n조나라 군대의 총사령관은 누구였나요?\n&32\n이건 하후돈야.')
    stage.say('&35\n그럼 그 사람이었어?\n주군 걱정할 필요 없어.\n모든 걸 내게 맡겨.\n&32\n하지만, 하지만......\n&35\n하후돈 정말로 뛰어난 무술을 가진 장군이었다,\n하지만 전략 없이 용기를 갖는 것은 두려워할 것이 아닙니다.\n&32\n그런데 어떻게 해야 할까요......?')
    stage.unit(35).move(63, 55, 1)
    stage.unit(35).setAction(0)
    stage.say('&35\n멋진 계획이 있어......')
    stage.unit(35).setAction(11)
    stage.say('&35\n등등......')
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n오, 오오!!\n전략가님, 정말 수완이 뛰어나시네요!')
    stage.unit(35).setAction(0)
    stage.say('&35\n이제 주군 안심해도 되겠죠?')
    stage.unit(32).setAction(0, 3)
    stage.say('&32\n그럼 마음이 놓이네.\n조조 군대는 두려워할 게 없어!\n&35\n그러니 침착하게 대답해 주세요,\n조조의 군대가 함정에 걸려들 때까지 기다려라.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene7():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            1,
            54,
            80],
        [
            11,
            44,
            64,
            1],
        [
            14,
            64,
            64,
            3]])
    stage.draw()
    stage.setStageName('보왕포 조조 주 캠프')
    stage.unit(1).setAction(17)
    stage.say('&1\n이번에는 이 어린 아이공명,\n그는 우리 전투 경험이 풍부한 전사들의 힘을 알고 있어!')
    stage.unit(1).setAction(0)
    if vars[1011]:
        model.unit(1).setPosts(78)
        stage.setFAvatar(1, 83)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 9, [
        1,
        14,
        11], [
        0,
        22])
    gvars[4076] = 0
    gvars[4057] = 25
    stage.setBattlePos([
        [
            10,
            11],
        [
            10,
            9],
        [
            11,
            8],
        [
            9,
            10],
        [
            11,
            10],
        [
            9,
            8],
        [
            12,
            9],
        [
            10,
            7],
        [
            12,
            7],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene8():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&1\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(11):
        stage.say('&1\n리 장군님, 좀 우울해 보이시네요.\n무슨 일이야?\n&11\n하후돈 장군, 비록 공명 젊지만,\n하지만 우리는 부주의할 여유가 없습니다.\n&1\n이 사람을 아공명?\n&11\n아니요, 저는 공명에 대해 아무것도 몰라요.\nHowever유비 은퇴에서 복귀하라는 초대를 받은 이후로,\n만약 그가 서서(Xu Shu)를 대신해 전략가가 된다면......\n&1\n리 장군, 용감한 장군이시여,\n왜 그런 낙담시키는 말을 했을까?\n전투에서의 승패는 힘과 경험에 의해 결정됩니다.')
    if stage.unitClickTest(14):
        if not vars[724]:
            stage.say('&14\n보왕 경사면을 지나면 신예시에 도착할 거야.')
        if vars[724]:
            stage.say('&14\n곽가 아직 못 해?\n&1\n음, 그의 상태는 예상보다 심각했어.\n잠시 쉬지 않으면 회복하지 못할 가능성이 큽니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
