# Source Generated with Decompyle++
# File: R_18.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 18)
    stage.showUnits([
        [
            101,
            35,
            56,
            1],
        [
            106,
            50,
            45,
            2],
        [
            103,
            58,
            45,
            2],
        [
            32,
            50,
            67]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setEventName('별도로')
    stage.setStageName('연진: 원소군의 본진')
    stage.say('&101\n음.\n뜻밖에도, 옌량 이후에,\n원초우도 죽었.......')
    stage.unit(103).setAction(6)
    stage.say('&103\n주군, 이전에 쉬두에게 보낸 스파이,\n보고서가 방금 전달됐어.')
    stage.unit(103).setAction(0)
    stage.say('&103\n관우 실제로 조의 군대에 있었다.\n&103\n전장에서, 얼굴이 붉고 수염이 긴 적 장군,\n결국 관우였다.\n&101\n뭐라고?\n&32\n어떻게 ...... 어떻게 ...... 그럴 수 있지?\n둘째 형이 조조의 부하가 되었다고 했지?\n&103\n맞아.\n&32\n설령 그게 사실이라 해도,\n둘째 형은 내가 여기 있다는 걸 분명히 모를 거야,\n그래서 그는 조의 군대에 들어갔다.')
    stage.unit(32).setAction(3)
    stage.say('&32\n둘째 형이 내가 여기 있다는 걸 알면,\n그는 분명히 밤낮으로 달릴 것이다.')
    stage.unit(32).setAction(0)
    stage.say('&101\n흠.......\n그래서, 유비 선생님,\n제발 관우 내 진영에 모집해 주세요.')
    stage.unit(32).setAction(6)
    stage.say('&32\n네. 바로 처리하겠습니다.\n&101\n흠... 이렇게 하자.\n아군 관우 꼭 참여하게 하세요.\n&32\n네. 바로 처리하겠습니다.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(32).move(95, 67, 1)
    stage.unit(32).hide()
    stage.delay(3)
    stage.say('&103\n쳇! 잃는 게 이득이 될 수도 있어.')
    stage.unit(103).setAction(6)
    stage.say('&103\n주군, 이제 어떻게 해야 하지?')
    stage.unit(103).setAction(0)
    stage.delay(3)
    stage.unit(106).setAction(6)
    stage.say('&106\n아군 두 장군, 옌량과 원초우를 잃었다.\nCurrently사기 낮고 사기도 낮습니다.\n&106\n먼저 철수해야 한다고 생각해,\n재정비하고, 미래에 다시 돌아와 다시 돌아와서 다시 일어나세요.')
    stage.unit(106).setAction(0)
    stage.say('&101\n흠.')
    stage.unit(101).setAction(3)
    stage.say('&101\n좋아, 일단 후퇴하자.')
    stage.unit(101).setAction(0)
    stage.say('&101\n궈투.')
    stage.unit(103).setAction(6)
    stage.say('&103\n네.')
    stage.unit(101).setAction(0, 3)
    stage.say('&101\n유비를 면밀히 감시하라,\n저 사람 정말 믿을 수가 없어.\n&103\n네.')
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 1)
    stage.showUnit(32, 53, 74)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('예 @유비 거주지')
    stage.showUnit(40, 53, 21, 2)
    stage.say('&40\n주군, 나한테 전화했어?\n&32\n아, 선첸이구나.\n빨리 들어와.')
    stage.unit(40).move(53, 59, 2)
    stage.delay(3)
    stage.unit(32).setAction(0, 0)
    stage.say('&32\n서저우에서 나와 함께 도망친 손첸,\n너만 남았어.')
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n처음에는 다른 사람들은 이미 죽은 줄 알았어요.\n&32\n뜻밖에도, .......')
    stage.unit(32).setAction(0, 0)
    stage.say('&32\n둘째 형은 다치지 않았다.')
    stage.unit(40).move(53, 61, 2)
    stage.say('&40\n...... 진짜야!?\n&32\n네! 틀림없어요.\n&40\n정말 멋지네요!\n관 장군은 지금 어디에 있습니까?\n&32\n마치 쉬두에 있는 것 같았다.\n&40\n뭐라고! 그래서......\n관장군이 항복한 조조인가?')
    stage.unit(32).setAction(2)
    stage.say('&32\n아니...... 아니, 안 돼!')
    stage.unit(32).setAction(0)
    stage.say('&32\n이렇게 ......지 않을 거야.')
    stage.unit(32).move(44, 74, 3)
    stage.delay(1)
    stage.unit(32).move(44, 61, 0)
    stage.unit(40).setAction(0, 3)
    stage.delay(3)
    stage.unit(32).setAction(0, 1)
    stage.say('&32\n…… 둘째 형에게 편지를 썼어.\n&32\n둘째 동생이 편지를 읽었다,\n그는 분명히 나를 찾으러 올 거야.')
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n원래는 편지를 쓰고 싶지 않아서 바로 그를 찾으러 갔어,\n하지만 원소 감시는 매우 엄격합니다......\n&40\n맞아.\n이해했어.\n제발 날 보내줘.')
    stage.unit(32).setAction(0, 1)
    stage.say('&32\n쉬두조조 보안도 매우 철저합니다,\n들킬 수도 있어.\n&40\n서저우 시가 함락되었을 때,\n나는 그런 큰 재앙을 피했어.\n그러니 안심하세요, 주군.\n&32\n그거 좋겠.......')
    stage.unit(32).move(50, 61, 1)
    stage.say('&32\n그럼 모든 걸 네게 맡길게.')
    stage.unit(32).move(44, 61, 1)
    stage.say('&32\n특히 조심해야 해.')
    stage.delay(3)
    stage.say('&40\n주군.\n&32\n무슨 일이야?\n&40\n지안용과 삼장군은 아직 살아 있을 것이다.\n&32\n흠.')
    stage.unit(40).move(53, 21, 0)
    stage.unit(40).hide()
    stage.delay(3)
    stage.say('&32\n(그래, 모두 아직 살아 있을 거야.) )')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(0, 35)
    stage.draw()
    stage.setStageName('쉬두')
    stage.info('조의 원소 공격군을 두 차례 격파했고,\n쉬두로 돌아온 후, 장군들은 회복의 시간을 보냈다.')
    stage.bgSound(-1)
    stage.loadBg(2, 0)
    stage.showUnit(3, 40, 54, 1)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('쉬관우 주')
    stage.say('&40\n관 장군, 관 장군.\n&3\n응? 누구야?')
    stage.showUnit(40, 90, 54, 3)
    stage.say('&40\n…… 관장군.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(3)
    stage.say('&3\n…… 저 사람 선첸 씨 아니야!?\n그래서 무사했구나!')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(3),
            40,
            60,
            2],
        [
            stage.unit(40),
            80,
            54,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(3),
            52,
            60,
            1],
        [
            stage.unit(40),
            70,
            54,
            3]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(3),
            52,
            54,
            0],
        [
            stage.unit(40),
            60,
            54,
            3]])
    stage.delay(1)
    stage.unit(3).setAction(0, 1)
    stage.delay(3)
    stage.say('&40\n관장군도 ......\n&3\n선첸 씨, 제 형은 안전한가요?\n&40\n네. 원소 주군.\n&3\n정말...?\n알고 보니 형은 무사했다......\n&40\n장군님께 편지를 보냈주군.')
    stage.say('&3\n아, 어디 보자.')
    stage.unit(3).move(56, 54, 1)
    stage.delay(5)
    stage.unit(40).setAction(5)
    stage.delay(5)
    stage.unit(40).setAction(0)
    stage.delay(5)
    stage.unit(3).move(52, 54, 3)
    stage.delay(3)
    stage.unit(3).setAction(5)
    stage.delay(10)
    stage.unit(3).setAction(0)
    stage.say('&3\n…… 그래서 내 동생은 아직도 나를 이렇게 신경 쓰는 거구나!')
    stage.delay(3)
    stage.unit(3).setAction(0, 1)
    stage.say('&3\n알았어, 형수님 바로 데려갈게,\n주군을 찾으러 나섰다.\n&40\n관 장군님, 한 가지 더 있습니다.\n&40\n세 장군, 지안용도 무사했다.')
    stage.unit(3).setAction(3)
    stage.say('&3\n뭐라고!')
    stage.unit(3).setAction(0)
    stage.say('&40\n쉬두로 가는 길에,\n우연히 그는 지안용을 만났다.\n&40\n세 장군과 지안용은 지금 랑산에 있다.\n&40\n그곳에 지역 산적들이 자리 잡았다\n그리고 자신들의 기지,\n주군 맞이하러 갈 준비 중이야.')
    stage.unit(3).setAction(3)
    stage.say('&3\n그래? 셋째 형과 건용은 모두 무사하다!')
    stage.unit(3).setAction(0)
    stage.say('&40\n지안용과 나는 주군 랑산으로 데려갈 거야,\n관장군도 랑산으로 서둘러 가길 바랐다.\n&3\n흠, 관은 이해한다.\n형과 형수들에게 이 소식을 전해 주세요. 그들이 안전하고 무사하다는 것을 전해 주세요.\n&40\n주군 그들이 알게 된다면 매우 기뻐할 것이다.\n&40\n그럼, 저는 이만 가보겠습니다.')
    stage.unit(40).move(98, 54, 1)
    stage.unit(40).hide()
    stage.say('&3\n형과 셋째 형은 아직 살아 있어...\n우리는 반드시 다시 만날 것입니다.')
    stage.delay(5)
    stage.say('&2\n죄송해요, 방금 하신 말씀 다 들었어요.\n&3\n흠!?')
    stage.showUnit(2, 90, 54, 3)
    stage.say('&2\n나야.\n&3\n알고 보니 원위안이었다.......')
    stage.unit(2).move(60, 54, 3)
    stage.say('&3\n…… 숨길 생각은 없어,\n들으시다시피.\n&2\n…… 유현덕 찾아볼 거야?\n&3\n흠.\n내일 나는 총리를 만나러 작별 인사를 할 것이다."')
    stage.delay(5)
    stage.say('&2\n정말......')
    stage.unit(2).setAction(0, 1)
    stage.say('&2\n…… 오늘 일어난 일을 주군에게 보고해야 합니다,\n괜찮을까요?\n&3\n그냥 직설적으로 말해!')
    stage.unit(2).move(90, 54, 1)
    stage.say('&2\n방해해서 미안해.')
    stage.unit(2).move(98, 54, 1)
    stage.unit(2).hide()
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            2,
            49,
            55,
            3],
        [
            21,
            52,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('그날 밤, .......', 3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말...?\n유비 확실히, 그녀는 아직 살아 있어.\n&2\n관우 내일 와서 작별 인사하러 온다고 했어.')
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n솔직히, 난 그를 보고 싶지 않아,\n그를 보는 것만으로도 헤어져야 한다는 뜻이야......')
    stage.unit(21).setAction(6)
    stage.say('&21\n주군, 관우에 대해 아이디어가 있어.')
    stage.unit(2).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say("&0\n무슨 생각이야, 중더?\n&21\n주군가 관우를 놓기 꺼린다면,\n'고객 피하기' 표지판을 걸 수 있습니다.\n&0\n손님 표지판을 피해야 하나요?")
    stage.info('손님 회피 표지판은 호스트가 손님을 맞이하고 싶지 않을 때 사용됩니다.\n닫힌 문 밖에는 간판이 걸려 있다.')
    stage.info('리클라이닝 간판을 걸고 나서, 무슨 일이 있어도,\n손님들은 떠나야 해; 예의야.')
    stage.say('&21\n관우 예절의 가치를 지키는 것,\n만약 손님 피하라는 표지판을 보면,\n그들은 절대 무모하게 무턱대고 들어오지 않을 것이다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(2).setAction(0, 3)
    stage.say('&2\n하지만 이건 아마 .........\n심장이 멈출 수가 관우어......\n&0\n그렇게 말할 ...... 있네요.')
    stage.effectSound(202, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice("'손님 피하기' 표지판을 걸어라.\n회피 표지판은 전혀 표시되어 있지 않습니다", 0)
    if sel == 1:
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(5)
        stage.unit(0).setAction(3)
        stage.say('&0\n무슨 일이 있어도 윤창을 지켜야 했어.')
        stage.unit(0).setAction(0)
        stage.say('피객패를 걸어라.')
        stage.unit(21).setAction(6)
        stage.say('&21\n네.')
        vars[306] = 1
    elif sel == 2:
        stage.addAmbition(-10)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(5)
        stage.unit(0).setAction(0, 3)
        stage.say('...피해서 머무르는 표시는 필요 없어.')
        stage.unit(21).setAction(6)
        stage.say('&21\n하지만 .......')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n정욱, 내 말을 들어보게……')
        stage.unit(0).setAction(3, 1)
        stage.say('&0\n윤창과의 우정을 유지하고 싶어.')
        stage.unit(0).setAction(0, 1)
        stage.say('&21\n…… 말실수 양해 부탁드립니다.')
        stage.unit(21).setAction(0)
        stage.say('&0\n내일은 내가 결코 잊지 못할 날이 될 것이다.')
        vars[306] = 0
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene4():
    if vars[306]:
        stage.loadBg(2, 29)
        stage.draw()
        stage.effectSound(205, 0)
        stage.showUnit(3, 61, 21, 2)
        stage.info('다음 날, .......', 3)
        stage.setStageName('수두, 총리 관저 앞')
        stage.delay(3)
        stage.unit(3).move(61, 65, 2)
        stage.delay(3)
        stage.unit(3).setAction(0, 3)
        stage.say("&3\n응?\n&3\n'손님 피하기' 표지판을 붙여 보세요.......\n&3\n어쩔 수 없었다면 내일 다시 왔을 거야.")
        stage.unit(3).move(61, 21, 0)
        stage.unit(3).hide()
        stage.effectSound(205, 255)
        stage.bgSound(16)
        stage.delay(3)
        stage.info("그때부터 on관우 매일 총리 관저에 찾아갔다,\n하지만 총리 관저는 매일 문을 꽉 닫고 있다,\n'통과 금지' 표지판을 달고 있었다.")
        stage.info('7일 후......', 3)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.showUnit(3, 61, 21, 2)
        stage.unit(3).move(61, 65, 2)
        stage.delay(3)
        stage.unit(3).setAction(0, 3)
        stage.say("&3\n오늘은 '손님 피하기' 문구도 걸었다.......")
        stage.say('&3\n총리님, 그저 작별 인사를 드리고자 합니다,\n하지만 이건 이런 식이야, 알 수 없는 수년과 몇 달 동안,\n그때서야 한 번 만날 수 있어.\n&3\n어쩔 수 없이 여기서 떠나야겠어.')
        stage.unit(3).setAction(6)
        stage.say('&3\n총리님, 관은 내일 즉시 출발할 것입니다,\n요즘 저는 총리님께서 큰 은혜를 받았습니다,\n관은 내 마음에 영원히 새겨질 거야.')
        stage.effectSound(202, 255)
        stage.clsUnit()
        stage.loadBg(2, 8)
        stage.showUnits([
            [
                0,
                34,
                55,
                1],
            [
                1,
                50,
                70],
            [
                15,
                56,
                70],
            [
                2,
                62,
                70],
            [
                13,
                68,
                70],
            [
                20,
                52,
                40,
                2],
            [
                22,
                58,
                40,
                2],
            [
                24,
                64,
                40,
                2],
            [
                21,
                70,
                40,
                2],
            [
                181,
                48,
                55,
                3,
                11]])
        stage.draw()
        stage.effectSound(205, 0)
        stage.delay(3)
        stage.info('다음 날 아침에 .......', 3)
        stage.setStageName('서두, 총리 관저')
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(1)
        stage.say('&0\n뭐라고? 윤창이 사라졌어!\n&181\n네.\n&181\n저택 전체가 안팎으로 깔끔하게 관리되어 있었다,\n총리가 수여한 물품들은 원래 인장이 그대로 남아 있다.')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n정말...?\n구름이 길게 다가올 때, 우아하고 우아하다,\n우아하게 떠나고.')
        stage.unit(22).setAction(6)
        stage.say('&22\n주군, 이렇게 관우 그냥 떠나게 둘 순 없어.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n네, 관우 내부 이야기아군 알고 있습니다,\n그냥 이렇게 유비 보내준다면, .......')
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n바로 그거예요.\n맹덕, 즉시 증원군을 보내라.')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n안 돼! 그때 이미 운장에게 약속했잖아.')
        stage.unit(1).setAction(0)
        stage.say('&1\n하지만 맹덕.......')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n게다가 윤창은 혼자 떠난 게 아니야,\n그냥 보고 싶지 않아서요.')
        stage.unit(0).setAction(0, 3)
        stage.say("&0\n이렇게 될 줄 알았다면, '피하는 패스' 배지를 걸지 않는 게 나았을 텐데,\n그녀는 침착하게 그를 데리고 나갔다.")
        stage.unit(0).setAction(0, 2)
        stage.delay(3)
        stage.say('말씀하실 것 없습니다! 제 마음속에는 이미 답이 있습니다!')
        stage.unit(0).setAction(0, 1)
        stage.delay(3)
        stage.unit(0).setAction(3, 1)
        stage.say('&0\n좋아! 원위안, 금과 은을 준비해!')
        stage.unit(2).setAction(0, 3)
        stage.say('&2\n응?')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n윤창의 여정을 배웅하고 싶어요.')
        stage.unit(2).setAction(6)
        stage.say('&2\n네, 이해합니다.')
        stage.unit(2).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(3, 1)
        stage.say('좋습니다. 바로 장룡을 추격하겠습니다!')
        stage.effectSound(205, 255)
        stage.bgSound(19)
        stage.delay(3)
        stage.clsUnit()
        stage.loadBg(2, 34)
        stage.showUnits([
            [
                154,
                4,
                59,
                1],
            [
                155,
                4,
                49,
                1]])
        stage.draw()
        stage.setStageName('쉬두 외곽 발링 다리')
        stage.unitsMove([
            [
                stage.unit(154),
                14,
                59,
                1],
            [
                stage.unit(155),
                14,
                49,
                1]])
        stage.showUnit(3, 4, 54, 1)
        stage.unitsMove([
            [
                stage.unit(154),
                80,
                59,
                1],
            [
                stage.unit(155),
                80,
                49,
                1],
            [
                stage.unit(3),
                70,
                54,
                1]])
        stage.info('이봐!', 3)
        stage.info('이봐! 관우!', 3)
        stage.unit(3).setAction(0, 3)
        stage.say('&3\n응?')
        stage.unit(154).setAction(0, 3)
        stage.say('&154\n관...... 관장군!')
        stage.unit(155).setAction(0, 3)
        stage.say('&155\n이촌, 저 사람이 조조 쫓는 사람인가요?\n&3\n추격하는 ....... 같지 않았다')
        stage.unit(3).setAction(0, 1)
        stage.say('&3\n걱정 마세요, 그들이 쫓고 있더라도,\n관도 그들을 상대할 수 있어.')
        stage.unit(3).setAction(6)
        stage.say('&3\n형수님들, 먼저 나가세요.\n&154\n장군님께 각별히 조심해 달라고 부탁드립니다.\n&3\n네.')
        stage.unit(3).setAction(0)
        stage.unitsMove([
            [
                stage.unit(154),
                95,
                59,
                1],
            [
                stage.unit(155),
                95,
                49,
                1]])
        stage.unit(154).hide()
        stage.unit(155).hide()
        stage.unit(3).setAction(0, 3)
        stage.showUnit(0, 4, 54, 1)
        stage.unit(0).move(14, 54, 1)
        stage.say('&0\n윤창!')
        stage.showUnits([
            [
                2,
                4,
                59,
                1],
            [
                15,
                4,
                49,
                1]])
        stage.unitsMove([
            [
                stage.unit(0),
                20,
                54,
                1],
            [
                stage.unit(2),
                10,
                59,
                1],
            [
                stage.unit(15),
                10,
                49,
                1]])
        stage.showUnits([
            [
                13,
                4,
                59,
                1],
            [
                14,
                4,
                49,
                1]])
        stage.unitsMove([
            [
                stage.unit(0),
                60,
                54,
                1],
            [
                stage.unit(2),
                50,
                59,
                1],
            [
                stage.unit(15),
                50,
                49,
                1],
            [
                stage.unit(13),
                44,
                59,
                1],
            [
                stage.unit(14),
                44,
                49,
                1]])
        stage.delay(3)
        stage.unit(0).setAction(3)
        stage.say('아, 드디어 따라잡았네.')
        stage.unit(0).setAction(0)
        stage.say('&0\n윤창, 너 유현덕...... 찾을 거야?\n&3\n네.\n관은 이미 형...... 행방을 알게 되었다.')
        stage.unit(3).setAction(6)
        stage.say('&3\n앞선 세 가지 조건을 준수해 주시기 바랍니다.\n&0\n알아.\n약속을 어기지 않을 거야.')
        stage.unit(3).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 2)
        stage.say("&0\n나는 혼란스러워하며 '승객 피하기' 표지판을 걸었다,\n이해해 주세요.")
        stage.unit(0).setAction(0, 1)
        model.setFace(3)
        stage.say('&0\n윤창, 우리가 좋은 관계로 헤어질 수 있길 바란다,\n그래서 급히 가서 배웅했어.')
        stage.unit(0).move(64, 54, 1)
        model.setFace(0)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.say('&0\n이건 내 감사의 작은 표시야. 받아줘.\n&3\n아니, 못 해......\n&0\n이것은 제 진심 어린 제스처입니다. 꼭 받아주세요.\n&3\n하지만 .......')
        model.setFace(3)
        stage.say('&0\n가는 길에 돈이 필요하겠죠?\n여자들을 그냥 바람 속에 살게 둘 수는 없어.\n여자들을 위해 그냥 받아들여.\n&3\n두 형수님을 위해서요?')
        stage.delay(3)
        stage.say('&3\n좋아.')
        stage.unit(3).move(67, 54, 3)
        stage.delay(5)
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(3).move(70, 54, 1)
        stage.delay(3)
        stage.unit(3).setAction(0, 3)
        stage.delay(3)
        stage.unit(3).setAction(6)
        stage.say('&3\n총리님, 정말 감사합니다.')
        stage.unit(3).setAction(0)
        stage.delay(3)
        stage.unit(0).move(60, 54, 3)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n윤창, 몸조심해.')
        stage.unit(3).setAction(6)
        stage.say('&3\n총리께서 .......를 잘 돌봐야 합니다')
        stage.unit(3).setAction(0)
        stage.unit(3).move(95, 54, 1)
        stage.unit(3).hide()
        stage.delay(8)
        model.setFace(0)
        stage.say('&0\n유현덕, 정말 부럽다.')
        stage.bgSound(-1)
        stage.clsUnit()
    if not vars[306]:
        stage.bgSound(19)
        stage.delay(3)
        stage.loadBg(2, 8)
        stage.showUnits([
            [
                0,
                34,
                55,
                1],
            [
                3,
                48,
                55,
                3,
                6],
            [
                154,
                54,
                52,
                3],
            [
                155,
                54,
                58,
                3],
            [
                20,
                52,
                40,
                2],
            [
                22,
                58,
                40,
                2],
            [
                24,
                64,
                40,
                2],
            [
                21,
                70,
                40,
                2],
            [
                1,
                52,
                70],
            [
                15,
                58,
                70],
            [
                2,
                64,
                70],
            [
                13,
                70,
                70]])
        stage.draw()
        stage.info('다음 날, .......', 3)
        stage.setStageName('서두, 총리 관저')
        stage.say('&0\n정말? 드디어 유현덕 찾게 될 거야.\n&3\n네.\n지난 며칠 동안 저는 총리님의 배려에 감사했습니다.')
        stage.unit(3).setAction(0)
        stage.say('&0\n흠.\n&0\n원위안.\n&2\n존재한다.')
        stage.unit(2).move(62, 70, 3)
        stage.delay(1)
        stage.unit(2).move(62, 55, 0)
        stage.delay(1)
        stage.unit(2).setAction(0, 3)
        stage.unit(3).setAction(0, 1)
        stage.unit(154).setAction(0, 2)
        stage.unit(155).setAction(0, 0)
        stage.say('&0\n윤창, 이건 다른 이들에게 작별의 작은 선물이야.\n부디 받아주세요.')
        stage.unit(3).setAction(0, 3)
        stage.say('&3\n안 돼! 받을 수 없어......\n&0\n이것은 제 진심 어린 제스처입니다. 꼭 받아주세요.\n&3\n하지만 .......')
        model.setFace(3)
        stage.say('&0\n가는 길에 돈이 필요하겠죠?\n여자들을 그냥 바람 속에 살게 둘 수는 없어.\n여자들을 위해 그냥 받아들여.\n&3\n두 형수님을 위해서요?\n좋아.')
        stage.unit(3).setAction(0, 1)
        stage.delay(3)
        stage.unit(2).move(51, 55, 3)
        stage.delay(5)
        stage.unit(2).move(62, 55, 3)
        stage.delay(3)
        stage.unit(3).setAction(0, 3)
        stage.delay(3)
        stage.unit(3).setAction(6)
        stage.say('&3\n총리님, 정말 감사합니다.')
        stage.unit(154).setAction(0, 3)
        stage.say('&154\n감사합니다, 조 재상님.')
        stage.unit(155).setAction(0, 3)
        stage.say('&155\n정말 감사합니다.\n&0\n윤창, 여행 조심해......\n&3\n조 재상도 잘 돌보았.......')
        model.setFace(0)
        stage.bgSound(-1)
        stage.clsUnit()
    return False


def scene5():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(3, 291, 92)
    stage.showHead(0, 355, 92)
    stage.bottomTxt('관우와 두 여성', False, False, False)
    stage.delay(5)
    stage.head(3).move(291, 172)
    stage.head(3).move(302, 179)
    stage.delay(5)
    stage.bottomTxt('랑산으로 출발,', True, False, False)
    stage.delay(5)
    stage.showHead(32, 366, 179)
    stage.delay(5)
    stage.bottomTxt('마침내 그는 유비와 장비와 재회했다.', True, False, True)
    stage.bottomTxt('이 시점에서,', False, True, False)
    stage.delay(8)
    stage.showHead(100, 560, 213)
    stage.delay(5)
    stage.bottomTxt("강동성의 '작은 군주'로 알려진 손책가 갑작스러운 병으로 사망했다.", True, False, False)
    stage.delay(5)
    stage.head(100).hide()
    stage.delay(10)
    stage.showHead(76, 560, 213)
    stage.delay(5)
    stage.bottomTxt('그의 남동생이 손권 그 위대한 사업을 물려받았다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('손권 이후 사절을 보내 조조에 계승 문제를 보고했다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            2,
            64,
            70],
        [
            13,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            97,
            48,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말? 손책 죽을 거라고는 전혀 예상 못 했어......\n&97\n네.\n손책 장군은 갑작스러운 병으로 사망했다.\n&0\n흠.......')
    stage.delay(3)
    stage.say('&0\n이제 그의 동생이 손권 위대한 사업을 물려받았다......\n&0\n문학과 무술 손권 들었어.')
    stage.unit(0).setAction(3)
    stage.say('&0\n그런 사람이 왕위를 계승한다면,\n동조는 평화롭고 번영할 것이다.\n&97\n그는 총리에게 감사를 표했다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n흠.\n다른 날에는 누군가를 강둥에 보내 조의를 표할 것이다.\n&0\n앞으로 힘든 여정을 보내셨어요.\n머물 곳은 이미 준비했어요,\n일찍 쉬어.\n&97\n그리고 총리의 친절에 감사를 표했다.\n그럼 이제 물러가겠습니다.\n&0\n흠.')
    stage.unit(97).setAction(0)
    stage.delay(3)
    stage.unit(97).move(95, 55, 1)
    stage.unit(97).hide()
    stage.say('&0\n그래서 손책 죽은 거야......\n원래 이것은 동조를 공격할 좋은 기회였다.')
    stage.unit(22).setAction(6)
    stage.say('&22\n주군, 이건 .......')
    stage.unit(22).setAction(0)
    stage.delay(3)
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('하하하, 알겠습니다. 원소가 해결되기 전까지,\n나는 동주를 공격하지 않을 것입니다.\n저는 아직 그렇게 무지한 사람은 아닙니다.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n문약 그는 즉시 사절단을 동오로 보내 조문했다.\n&0\n우리는 동우와 우호 관계를 유지해야 합니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n네! 알겠습니다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n손권와 좋은 관계를 유지하세요,\n남쪽 면은 걱정 없는 경험을 보장합니다.')
    stage.unit(0).setAction(3)
    stage.say('원소와 일대일로 겨룰 때가 왔어. 출정해라!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n목표는 원소 국경의 주요 황하 건널목인 관두였다!')
    stage.effectSound(202, 255)
    stage.bgSound(0)
    stage.delay(3)
    stage.clsUnit()
    return False


def scene6():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            101,
            52,
            28,
            2],
        [
            106,
            38,
            48,
            1],
        [
            102,
            38,
            54,
            1],
        [
            110,
            67,
            48,
            3],
        [
            105,
            67,
            54,
            3]])
    stage.draw()
    stage.info('조의 행적은 즉시 원소 진영에 보고되었다.')
    stage.setStageName('예 원소 저택')
    stage.delay(3)
    stage.unit(101).setAction(3)
    stage.say('&101\n방금 보고서를 받았어요,\n조조 손권와 동맹을 맺었다고 들었어,\n이제 그들은 관두에 들어가려 하고 있었다.')
    stage.unit(101).setAction(0)
    stage.say('&101\n만약 동우와 조조 군대가 힘을 합친다면,\n조조을 없애는 것은 어려울 것입니다.')
    stage.unit(101).setAction(17)
    stage.say('&101\n아군 곧 관두로 군대를 보내야 할 것 같다,\n그리고 조조와 생사를 건 싸움을 벌였다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(110).setAction(2)
    stage.say('&110\n절대 아니에요.')
    stage.unit(110).setAction(0)
    stage.say('&110\n주군 지난 실패에서 얻은 교훈을 잊었나요?\n조조를 이기려면 서두르지 말아야 한다.\n&101\n천풍, 아군 곧 행동하지 않으면,\n동오는 이후 조조 군대와 전투에서 협력할 예정이었다.')
    stage.unit(110).setAction(6)
    stage.say('&110\n주군, 동오와의 관계조조,\n하지만 잠시만 지속될 수 있다,\n가까운 미래에 균열은 불가피하다.')
    stage.unit(110).setAction(0)
    stage.say('&102\n천풍, 이런 추측을 하려는 거지,\n군사 및 국가 업무를 방해하는 것?')
    stage.unit(110).setAction(2)
    stage.say('&110\n어떻게 그런 말을 할 수 있어! 이건 추측이 아니야,\n이것은 자연스러운 원리입니다.')
    stage.unit(110).setAction(0)
    stage.say('&102\n이 생각은 전혀 근거가 없습니다.')
    stage.unit(102).setAction(0, 0)
    stage.say('&102\n주군, 마지막 전투 중에,\n천풍도 단호히 반대했다.\n&102\n그 결과 병사들은 전투 의지를 잃었다,\n결국 이로 인해 아군 참담한 패배가 이어졌다.\n&101\n흠.......')
    stage.unit(102).setAction(0, 1)
    stage.delay(3)
    stage.unit(101).setAction(0, 0)
    stage.say('&101\n…… 톈펑, 집에 가서 스스로를 돌아봐야 해.')
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n이제부터 다시는 나를 만나러 오지 마.\n&110\n메인 ......주군......!')
    stage.unit(110).setAction(6)
    stage.say('&110\n…… 좋아.')
    stage.unit(110).setAction(0)
    stage.unit(110).move(75, 48, 1)
    stage.delay(1)
    stage.unit(110).move(75, 71, 2)
    stage.unit(110).setAction(0)
    stage.say('&110\n정말 안타깝네요.......')
    stage.unit(110).move(75, 90, 2)
    stage.unit(110).hide()
    stage.delay(3)
    stage.unit(105).setAction(6)
    stage.say('&105\n주군, 저도 천펑의 의견에 동의합니다,\n서두르지 말아 주세요.')
    stage.unit(105).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n뭐라고?')
    stage.unit(101).setAction(3)
    stage.say('&101\n저수, 너도 반대해?\n아군 병력 면에서 압도적으로 우세하며,\n우리는 반드시 이길 거예요.')
    stage.unit(105).setAction(6)
    stage.say('&105\n전투 결과는 병력 규모에만 의존하지 않습니다.\n주군, 무슨 일이 있어도 ...... 신중히 생각해 주세요.')
    stage.unit(105).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0)
    stage.say('&101\n저수 그렇다면 군사력에 대해 이야기하지 맙시다,\n지휘관으로서 내가 조조만큼 잘하지 못하는 거야!?')
    stage.unit(105).setAction(6)
    stage.say('&105\n......주군 주인님께서 그런 의도는 ......하지 않습니다.')
    stage.unit(101).setAction(2)
    stage.say('&101\n닥쳐! 네 설명 듣기 싫어!\n감옥에 가둬!!')
    stage.showUnits([
        [
            181,
            67,
            90],
        [
            182,
            73,
            90]])
    stage.unitsMove([
        [
            stage.unit(181),
            67,
            57,
            0],
        [
            stage.unit(182),
            73,
            51,
            0]])
    stage.unit(105).setAction(0)
    stage.delay(1)
    stage.unit(182).move(67, 51, 3)
    stage.delay(1)
    stage.unit(182).setAction(0, 2)
    stage.delay(3)
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n즉시 관두로 행군하라!')
    stage.say('&105\n주군.......')
    stage.delay(3)
    stage.unit(105).setAction(0, 1)
    stage.say('&105\n(주군 변했어............\n이전에는 이렇지 않았다...... )\n&105\n(어젯밤, 갑자기 악마별이 쉬두 방향으로 나타났다,\n분명 조조 별자리일 거야......\n조조 미치겠주군......? )')
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(101, 349, 4)
    stage.delay(10)
    stage.bottomTxt('Hebei원소의 영웅들', False, False, False)
    stage.delay(5)
    stage.showHead(0, 317, 127)
    stage.delay(10)
    stage.bottomTxt('오랜 적들과 조조', True, False, False)
    stage.delay(10)
    stage.head(0).move(358, 114)
    stage.delay(5)
    stage.head(101).move(358, 34)
    stage.delay(10)
    stage.bottomTxt('두 세력은 공두에서 맞섰다,', True, True, False)
    stage.delay(10)
    stage.bottomTxt('결정적인 전투의 날이 마침내 찾아왔다.', True, True, True)
    return False


def scene7():
    model.initLocalVar()
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            2,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            24,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('관두조조 본진지')
    stage.say('&0\n문약, 원소 군의 상황을 소개해 주시겠습니까?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n네.\n&20\n원소 군대는 절대적인 우위를 점했다,\n이미 황하를 건넜고, 그 추진력은 압도적이었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n역시 원소답군…….')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('하지만 저는 질 수 없습니다. 모두 전력을 다해 싸워야 합니다.')
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 14, [
        15])
    gvars[4076] = 0
    gvars[4057] = 18
    stage.setBattlePos([
        [
            15,
            30],
        [
            11,
            27],
        [
            18,
            27],
        [
            12,
            28],
        [
            17,
            28],
        [
            13,
            28],
        [
            16,
            28],
        [
            12,
            29],
        [
            17,
            29],
        [
            13,
            29],
        [
            16,
            29],
        [
            14,
            30],
        [
            15,
            29],
        [
            14,
            29],
        [
            0,
            0]])
    return False


def scene8():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(24):
        stage.say('공달, 운장은 지금 어떻습니까? 아낭산에서 유비 일행과 합류한 것 같습니다. 현재 그곳에서 사슴 방어벽을 쌓고 있습니다... 오?')
        stage.unit(22).setAction(0, 2)
        stage.say('&22\n주군 윤창 장군은 이미 ......\n&0\n알아.\n이제 그는 내 적일 뿐이야.\n&22\n………….')
        stage.unit(22).setAction(0, 3)
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 관두의 지형은 어떤가요?\n&20\n네.\n&20\n거의 모든 것이 산과 숲이다,\n평지의 길은 매우 좁습니다.\n&20\n기병은 이동에 어려움을 겪을 수 있습니다......\n이번에도 장군이 빛날 기회허저 보입니다.\n&15\n지켜보세요!!\n&20\n하하하.\n&20\n아, 그리고 한 가지 더 중요한 게 있어요......\n&0\n무슨 일이야?\n&20\n주군, 우리 캠프 북동쪽에,\n우차오라는 분지가 있습니다.\n원소의 곡물 창고가 여기 있습니다.\n&0\n뭐라고!? 곡물 창고!\n&20\n네.')
    if stage.unitClickTest(22):
        stage.say('&22\n주군, 위안준 허유 알아?\n&22\n그가 너랑 같은 고향 출신이라고 들었주군.\n&0\n허유? …… 기억이 안 나.\n아마 그런 사람들이 있을 거예요.\n&22\n맞아.\n&22\n이 허유가 편협하다고 들었어,\n그는 원소에게 결코 가치 있게 여겨지지 않았다,\n그래서 그는 이 일에 대해 매우 혐오감을 느꼈다.\n&0\n아? 사실 꽤 흥미롭네요.')
    if stage.unitClickTest(1):
        stage.say('&1\n큰 군대가 있어도,\n승패는 병력 규모에 달려 있지 않습니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n원준에게 매우 강력한 장군이 있었다고 들었어,\n나는 정말로 그와 1:1로 도전하고 싶다.\n&0\n그 장군 이름이 뭐야?\n&15\n생각해보자면, 장료 장군의 이름과 많이 닮아 보이네.\n&2\n아, 그의 이름은 장합입니다, 허저 장군.\n&15\n아! 그래, 그래, 장합, 이름은 장합!')
    if stage.unitClickTest(2):
        stage.say('&2\n군사력은 문제가 아닙니다.\n적어도 자신의 힘에 자신감을 가져야 했다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
