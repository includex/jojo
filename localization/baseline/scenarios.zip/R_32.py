# Source Generated with Decompyle++
# File: R_32.marshal (Python 3.9)


def scene0():
    if model.ambition() < 16:
        model.initLocalVar()
        if vars[1002]:
            stage.infoTransfer(18, '')
        stage.clsUnit()
        stage.setMenuVisible(False)
        stage.jumpScene(91)
    if model.ambition() >= 16:
        model.initLocalVar()
        if vars[1002]:
            stage.infoTransfer(18, '')
        stage.clsUnit()
        stage.setMenuVisible(False)
        stage.loadBg(2, 59)
        stage.showUnit(57, 49, 8, 2)
        stage.draw()
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.setEventName('한중을 공격하기 위해 진격했다')
        stage.setStageName('장안 외곽의 산길')
        stage.unit(57).move(49, 18, 2)
        stage.showUnits([
            [
                58,
                45,
                8,
                2],
            [
                9,
                53,
                8,
                2]])
        stage.unitsMove([
            [
                stage.unit(57),
                49,
                45,
                2],
            [
                stage.unit(58),
                45,
                35,
                2],
            [
                stage.unit(9),
                53,
                35,
                2]])
        stage.unit(57).setAction(0)
        stage.unit(58).setAction(0)
        stage.unit(9).setAction(0)
        stage.delay(3)
        stage.unit(57).setAction(2)
        stage.say('&57\n젠장, 아버지의 복수를 거의 할 뻔했는데!\n&58\n네 기분 이해해,\n하지만 지금은,\n유일한 선택지는 목숨을 걸고 도망치는 것이었다.')
        stage.unit(57).setAction(0)
        stage.delay(3)
        stage.unit(57).setAction(0, 0)
        stage.say('&57\n흠, 흠.........\n하지만?! 어디로 가야 하지?')
        stage.unit(9).setAction(6)
        stage.say('&9\n한중으로 가는 게 좋을 것 같아.')
        stage.unit(9).setAction(0)
        stage.say('&57\n한중 ...... 장루, 저기 있니?\n&58\n네, 저도 그렇게 생각했어요.\n가장 가깝고 영향권 밖조조,\n한중만 남았다.\n&57\n…… 정말? 좋아.\n한중에서 출발합니다.')
        stage.unit(57).setAction(0, 2)
        stage.delay(3)
        stage.unit(57).setAction(2)
        stage.say('&57\n조만간 아버지의 죽음을 복수할 거야!')
        stage.unit(57).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(57),
                49,
                95,
                2],
            [
                stage.unit(58),
                45,
                95,
                2],
            [
                stage.unit(9),
                53,
                95,
                2]])
        stage.unit(57).hide()
        stage.unit(58).hide()
        stage.unit(9).hide()
        stage.effectSound(203, 255)
        stage.bgSound(16)
        stage.delay(3)
        stage.clsUnit()
        stage.loadBg(1, 0)
        stage.draw()
        stage.showHead(0, 242, 61)
        stage.showHead(57, 178, 61)
        stage.bottomTxt('마초와 다른 이들이 패배한 조조', False, False, False)
        stage.delay(5)
        stage.showHead(140, 106, 96)
        stage.delay(5)
        stage.bottomTxt('한중에서 장루에게 피신했다,', True, False, False)
        stage.delay(5)
        stage.head(57).move(170, 96)
        stage.delay(5)
        stage.bottomTxt('그들은 임시 머물 곳이 있었다.', True, False, True)
        stage.bgSound(-1)
        return True


def scene1():
    stage.loadBg(2, 28)
    stage.showUnits([
        [
            19,
            68,
            42,
            1],
        [
            181,
            52,
            79,
            1],
        [
            182,
            54,
            46,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.info('반면 조조 쉬두로 돌아갔다......', 3)
    stage.setStageName('수두, 총리 관저 앞')
    stage.showUnit(0, 68, 94)
    stage.unit(0).move(68, 65, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n수고 많으셨습니다.')
    stage.unit(181).setAction(11)
    stage.say('&181\n아! 그래, 그래, 주군.\n&0\n특별한 점이 있나요?')
    stage.unit(182).setAction(11)
    stage.say('&182\n아니요, 이상은 없습니다.\n&0\n흠.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n……응?\n저기 저 사람이 뭘 하고 있는 거지?\n&181\n저 사람은 두 시 전부터,\n계속 서서 하늘만 보고 있어.\n&0\n오……?')
    stage.unit(0).move(68, 50, 0)
    stage.unit(0).setAction(0)
    stage.unit(181).setAction(0)
    stage.unit(182).setAction(0)
    stage.say('&0\n여기서 뭐 하는 거야?\n&19\n하늘을 보고 있어.\n&0\n하늘을 보고 있었나요?\n&19\n하늘을 바라보고, 바람 소리를 듣고,\n땅의 향기를 들이마시며.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그래서 그런 거구나......\n하루 종일 이러세요?\n&19\n네.\n&0\n명문 가문 출신인 것 같군요,\n이렇게 혼란스러움을 그냥 견뎌낼 생각이야?\n&19\n때가 되면 자연스럽게 행동에 나설 것입니다.\n때가 올 때까지는 이게 유일한 방법이야.\n&0\n이렇게 날씨를 지켜봐,\n그러면 언제 행동해야 할지 알게 되죠.\n&19\n나는 다른 사람들이 모르는 것들도 알고 있다,\n세상의 모든 것이 내 통제 하에 있다.')
    model.setFace(3)
    stage.say('&0\n오...... 흥미롭네.\n그래서, 세상 상황에 대해 여쭤봐도 될까요, 선생님?\n&19\n바람은 사람들의 불만을 실어 나르고,\n땅은 피의 악취로 가득하다,\n혼란은 오랫동안 계속될 것이다.\n&19\n더불어, 밤하늘은 왕국의 삼분을 묘사한다.')
    model.setFace(0)
    stage.say('&0\n그 시대의 혼란을 예견할 수 있겠는가?\n흥미롭네요!\n이른바 삼국지는 정확히 무엇에 관한 것일까요?\n&19\n삼국은 유현덕 슈 왕국을 가리킨다,\n손중모 우와 조맹덕 웨이.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n유비 슈 왕국?\n혹시 유비 서촨을 점령하려는 의도일까?\n&19\n틀림없어.\n곧 소식이 전해질 거야.')
    stage.say('&0\n너...... 이름이 뭐야?\n&19\n제 이름은 사마의이고, 자식은 중달입니다.\n&0\n때가 되면 행동하겠다고 했잖아,\n아직 때가 아니야?')
    stage.effectSound(203, 255)
    stage.bgSound(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.say('&19\n아니요...... 때가 왔습니다.\n총리가 나에게 질문했을 때,\n바로 그때 내가 행동에 나서야 해.')
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n하하하.\n중달, 나랑 같이 들어가.\n당신을 제 전략가로 초대하고 싶습니다.')
    stage.unit(19).setAction(6)
    stage.say('&19\n네!')
    model.unitJoin(19, 0, 0)
    if vars[1013]:
        gvars[0] = 19
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    model.setFace(0)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            50,
            40,
            2],
        [
            23,
            56,
            40,
            2],
        [
            24,
            62,
            40,
            2],
        [
            21,
            68,
            40,
            2],
        [
            19,
            74,
            40,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.info('열흘 후.........', 3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말?\n유비 정말 시촨을 데려갔어?"')
    stage.unit(20).setAction(6)
    stage.say('&20\n네.\n방금 받은 보고서입니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n또한, 청두 공격 당시,\n방통 총에 맞아 사망했다.')
    model.setFace(1)
    stage.say('&0\n뭐라고? 방통 죽었어?\n그게 so......방통 사람이야......\n&24\n응. 바로 그 직후에......\n마초 또한 유비에 합류했다.')
    stage.unit(24).setAction(0)
    model.setFace(2)
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('&0\n뭐, 마초!?\n응......\nUnexpectedly유비 그는 실제로 마초를 받아들였다!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n그렇다면 서천의 전 통치자 류장은 어떻게 되었나요?')
    stage.unit(20).setAction(6)
    stage.say('&20\n그는 징저우로 옮겨져 정착했다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흥! 같은 부족의 유비가 영토를 점령했다,\n징저우까지 보내졌다고?')
    stage.unit(23).setAction(6)
    stage.say('&23\n이 일련의 사건들은,\n아마 유비 사람의 아이디어였을 거예요.')
    stage.unit(23).setAction(0)
    stage.say('&0\n음, 아마 공명 방식일 거야, 맞지?\n유비 그렇게 구분이 안 되는 짓을 할 리가 없어.')
    stage.unit(0).setAction(3)
    stage.say('&0\n좋아요, 모든 전략가들에게 묻고 싶습니다,\n앞으로 어떤 조치를 취해야 할까요?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n손가문은 3대째 강동을 다스려왔어,\n따라서 뿌리는 깊게 박혀 있어 공격하기 매우 어렵습니다.\n&24\n먼저, 얕은 슈 나라를 공격해야 합니다,\n마지막으로 동우를 상대해야 합니다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n하지만,\n한중에는 꽤 까다로운 장루가 있었다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n한중은 슈 왕국으로 가는 관문이었다,\n즉시 공격해야 합니다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n중달 같은 마음이에요,\n이것이 가장 안전한 해결책입니다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 모두의 의견에 동의합니다.')
    stage.unit(20).setAction(0)
    stage.say('네, 지금 진군하여 한중의 장루를 공격하자.')
    stage.unit(0).setAction(17)
    stage.say('&0\n출발 준비해!')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 335, 97)
    stage.showHead(32, 293, 225)
    stage.bottomTxt('유비 왕국을 세 부분으로 나누제갈량 계획을 채택했다,', False, False, False)
    stage.delay(5)
    stage.showHead(160, 26, 172)
    stage.delay(8)
    stage.head(32).move(90, 172)
    stage.delay(5)
    stage.bottomTxt('그는 서천에서 류장을 공격했다,', True, False, False)
    stage.delay(8)
    stage.bottomTxt('가는 길이었지만......', True, True, False)
    stage.delay(5)
    stage.showHead(90, 152, 152)
    stage.delay(8)
    stage.head(90).hide()
    stage.delay(5)
    stage.bottomTxt('부전략가 방통 잃었고,', True, False, False)
    stage.delay(5)
    stage.head(160).hide()
    stage.delay(5)
    stage.head(32).move(26, 172)
    stage.delay(5)
    stage.bottomTxt('마지막에는 결국 서천을 빼앗았다.', True, False, True)
    stage.showHead(76, 572, 238)
    stage.delay(5)
    stage.bottomTxt('손권 측면에 관해서는,', False, True, False)
    stage.delay(8)
    stage.head(76).move(501, 216)
    stage.delay(5)
    stage.bottomTxt('그는 수도를 오에서 건예로 옮겼다,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그리고 조조와 유비에 맞서겠다는 결의를 보여주고 있습니다.', True, True, False)
    stage.delay(10)
    stage.bottomTxt('이 상황을 본 조조은 유비를 먼저 제거하기로 결심했다.', True, True, True)
    stage.delay(5)
    stage.bottomTxt('그의 첫 번째 발걸음,', True, True, False)
    stage.delay(5)
    stage.showHead(140, 129, 87)
    stage.delay(5)
    stage.head(0).move(193, 87)
    stage.delay(8)
    stage.bottomTxt('이 계획은 장루가 다스리는 한중으로 진격하기 위한 것이었다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            7,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('한중: 조조군의 본진')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 13, [
        15], [
        2,
        10,
        11])
    gvars[4076] = 0
    gvars[4057] = 32
    stage.setBattlePos([
        [
            2,
            5],
        [
            3,
            4],
        [
            1,
            6],
        [
            1,
            5],
        [
            2,
            4],
        [
            0,
            5],
        [
            1,
            4],
        [
            2,
            3],
        [
            0,
            5],
        [
            1,
            3],
        [
            0,
            4],
        [
            0,
            3],
        [
            1,
            2],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 지형을 이해하느냐?\n&20\n네! 주군.\n전장 전체가 본질적으로 산악 지형이었다.\n&20\n길을 따라 적의 도시로 이어지는 도로가 있지만,\n하지만 먼저 그 과정에서 체크포인트를 뚫어야 합니다.\n&0\n허가? 그렇구나.')
    if stage.unitClickTest(19):
        stage.say("&19\n'싸우지 않고 적군을 제압하라',\n이것이 가장 정교한 전략입니다.")
    if stage.unitClickTest(15):
        stage.say("&15\n장루의 문파 이름은 아마도 '오두쌀문'일 것이다,\n이게 무슨 뜻일까요?\n&20\n하하하.\n신자들은 기도에 대한 감사의 선물로 쌀 5 주머니를 바쳐야 합니다.\n그래서 '오박 쌀파'라고 불렸다.\n&15\n흠!\n전략가문약 정말로 매우 박식합니다.")
    if stage.unitClickTest(21):
        stage.say('&21\n어려운 시기에 자리를 지킬 수 있도록,\n이것은 장루가 평범한 사람이 아니었다는 것을 보여준다.\n이 사람은 세상을 다루는 데 꽤 능숙한 것 같아요.')
    if stage.unitClickTest(1):
        stage.say('&1\n유비 실제로 서촨을 점령하고 있었다,\n요즘은 이상한 것들이 너무 많아요.')
    if stage.unitClickTest(7):
        stage.say('&7\n주군, 무기점 주인이 방금 들렀어,\n그는 새 무기가 도착했다고 말했다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
