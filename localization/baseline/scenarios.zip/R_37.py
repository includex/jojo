# Source Generated with Decompyle++
# File: R_37.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            13,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setEventName('곡물 창고를 지키기 위해')
    stage.setStageName('한강 근처, 조조군의 본진')
    stage.say('&0\n뜻밖에도 공명의 목표는 사계곡물 창고였다,\n정말 부주의하네.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n이 남자는 군사력을 휘두르며 예측 불가능한 능력을 지녔다......\n그는 아군 가장 두려운 인물이 될 것이다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n곡물창고가 압수된다면,\n장군아군 그는 진격이나 후퇴에 어려움을 겪었다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n흠, 우리는 절대 슈 군대가 곡창고를 점령하게 할 수 없습니다.\n당장 시에구로 서둘러라!')
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 8)
    gvars[4076] = 0
    gvars[4057] = 37
    stage.setBattlePos([
        [
            9,
            23],
        [
            10,
            23],
        [
            8,
            23],
        [
            11,
            23],
        [
            8,
            23],
        [
            11,
            23],
        [
            9,
            23],
        [
            10,
            23],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(13):
        stage.say('&13\n마초군이 곡물 창고를 공격한 것으로 보였다.\n&0\n마초Is 그렇습니까? 그가 한강 근처에 있지 않다는 것을 봤습니다,\n그때 나는 조금 이상한 기분이 들었어,\n뜻밖에도, 그 자리는 셰구에게 가기로 했다.')
    if stage.unitClickTest(20):
        stage.say('&20\n사계곡은 이름 그대로입니다.\n두 산 사이에 위치해 있었다.')
    if stage.unitClickTest(19):
        stage.say('&19\n마초 병력만 언급할 가치가 없다면,\n유비가 직접 주력 부대를 이끌고 셰구로 갈 것 같아 두렵습니다.\n&19\n다만 주력 유비 세력이 언제 도착할지는 불분명하다......\n무슨 일이 있어도...... 힘든 싸움이 될 거야.')
    if stage.unitClickTest(21):
        stage.say("&21\n마초 오호장군 중 한 명이냐?\n&15\n아, 뭐라고?\n오호장군이란 무엇인가?\n&20\n흠......\n관우, 장비, 조운, 황충, 마초,\n이 다섯 장군은 서나라에서 '오호장군'으로 불렸다.\n&21\n정확히 그렇습니다.\n&15\n아......?")
    if stage.unitClickTest(15):
        stage.say('&15\n우리는 곡물 창고를 지켜야 한다!\n조항이 무엇보다 중요합니다.\n&1\n허저, 그 표현이 네 스타일에 정말 잘 어울려.\n&15\n…… 어쩔 수 없어요, 식욕이 엄청 많거든요.')
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 우리는 신속히 행동해야 해,\n만약 곡물창고가 슈군에게 점령된다면,\n결국 그들은 한중을 포기할 수밖에 없었다.\n&0\n흠.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
