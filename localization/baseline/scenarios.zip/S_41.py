# Source Generated with Decompyle++
# File: S_41.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(20,25)',
        '(19,25)',
        '(20,24)',
        '(19,24)'])
    stage.nearEvent([
        1,
        34,
        4,
        53,
        15,
        54,
        9,
        57])
    stage.nearEvent([
        0,
        67], 1)
    stage.initFight()
    stage.setGlobalData(40, -2, 67, 0, 0, 1)
    stage.createEnemy(
        [{'id': 67, 'x': 20, 'y': 25, 'dir': 0, 'lv': 2, 'i': 0},
         {'id': 35, 'x': 20, 'y': 24, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 69, 'x': 19, 'y': 22, 'dir': 0, 'lv': 6, 'i': 2},
         {'id': 50, 'x': 20, 'y': 22, 'dir': 0, 'lv': 6, 'i': 3},
         {'id': 55, 'x': 17, 'y': 24, 'dir': 3, 'lv': 4, 'i': 4},
         {'id': 56, 'x': 22, 'y': 25, 'dir': 1, 'lv': 4, 'i': 5},
         {'id': 210, 'x': 19, 'y': 21, 'dir': 0, 'lv': 0, 'i': 6},
         {'id': 211, 'x': 20, 'y': 21, 'dir': 0, 'lv': 0, 'i': 7},
         {'id': 212, 'x': 16, 'y': 24, 'dir': 3, 'lv': 0, 'i': 8},
         {'id': 213, 'x': 16, 'y': 25, 'dir': 3, 'lv': 0, 'i': 9},
         {'id': 214, 'x': 23, 'y': 24, 'dir': 1, 'lv': 0, 'i': 10},
         {'id': 215, 'x': 23, 'y': 25, 'dir': 1, 'lv': 0, 'i': 11},
         {'id': 234, 'x': 18, 'y': 22, 'dir': 0, 'lv': 0, 'i': 12},
         {'id': 235, 'x': 21, 'y': 22, 'dir': 0, 'lv': 0, 'i': 13},
         {'id': 236, 'x': 17, 'y': 23, 'dir': 3, 'lv': 0, 'i': 14},
         {'id': 237, 'x': 17, 'y': 26, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 238, 'x': 22, 'y': 23, 'dir': 1, 'lv': 0, 'i': 16},
         {'id': 239, 'x': 22, 'y': 26, 'dir': 1, 'lv': 0, 'i': 17},
         {'id': 342, 'x': 17, 'y': 25, 'dir': 3, 'lv': 0, 'i': 18},
         {'id': 334, 'x': 22, 'y': 24, 'dir': 1, 'lv': 0, 'i': 19},
         {'id': 298, 'x': 19, 'y': 24, 'dir': 0, 'lv': 0, 'i': 20},
         {'id': 299, 'x': 19, 'y': 25, 'dir': 0, 'lv': 0, 'i': 21},
         {'id': 68, 'x': 10, 'y': 24, 'dir': 3, 'lv': 4, 'i': 22},
         {'id': 216, 'x': 10, 'y': 25, 'dir': 3, 'lv': 0, 'i': 23},
         {'id': 70, 'x': 29, 'y': 24, 'dir': 1, 'lv': 4, 'i': 24},
         {'id': 217, 'x': 29, 'y': 25, 'dir': 1, 'lv': 0, 'i': 25},
         {'id': 218, 'x': 19, 'y': 15, 'dir': 0, 'lv': 0, 'i': 26},
         {'id': 219, 'x': 20, 'y': 15, 'dir': 0, 'lv': 0, 'i': 27},
         {'id': 220, 'x': 14, 'y': 8, 'dir': 0, 'lv': 0, 'i': 28},
         {'id': 221, 'x': 15, 'y': 8, 'dir': 0, 'lv': 0, 'i': 29},
         {'id': 222, 'x': 24, 'y': 8, 'dir': 0, 'lv': 0, 'i': 30},
         {'id': 223, 'x': 25, 'y': 8, 'dir': 0, 'lv': 0, 'i': 31},
         {'id': 310, 'x': 6, 'y': 19, 'dir': 0, 'lv': 0, 'i': 32},
         {'id': 311, 'x': 7, 'y': 19, 'dir': 0, 'lv': 0, 'i': 33},
         {'id': 312, 'x': 32, 'y': 19, 'dir': 0, 'lv': 0, 'i': 34},
         {'id': 313, 'x': 33, 'y': 19, 'dir': 0, 'lv': 0, 'i': 35},
         {'id': 60, 'hide': 1, 'x': 13, 'y': 11, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 36},
         {'id': 224, 'hide': 1, 'x': 13, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 40, 'hide': 1, 'x': 13, 'y': 13, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 38},
         {'id': 49, 'hide': 1, 'x': 12, 'y': 12, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 39},
         {'id': 44, 'hide': 1, 'x': 16, 'y': 11, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 40},
         {'id': 225, 'hide': 1, 'x': 16, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 244, 'hide': 1, 'x': 16, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 42},
         {'id': 343, 'hide': 1, 'x': 17, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 43},
         {'id': 226, 'hide': 1, 'x': 26, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 44},
         {'id': 227, 'hide': 1, 'x': 26, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 45},
         {'id': 59, 'hide': 1, 'x': 26, 'y': 13, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 46},
         {'id': 335, 'hide': 1, 'x': 27, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 47},
         {'id': 61, 'hide': 1, 'x': 23, 'y': 11, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 48},
         {'id': 228, 'hide': 1, 'x': 23, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 49},
         {'id': 43, 'hide': 1, 'x': 23, 'y': 13, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 50},
         {'id': 39, 'hide': 1, 'x': 22, 'y': 12, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 51},
         {'id': 57, 'hide': 1, 'x': 17, 'y': 18, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 52},
         {'id': 462, 'hide': 1, 'x': 17, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 463, 'hide': 1, 'x': 17, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 301, 'hide': 1, 'x': 16, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 302, 'hide': 1, 'x': 16, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 56},
         {'id': 303, 'hide': 1, 'x': 16, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 34, 'hide': 1, 'x': 22, 'y': 18, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 58},
         {'id': 258, 'hide': 1, 'x': 22, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 59},
         {'id': 259, 'hide': 1, 'x': 22, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 60},
         {'id': 304, 'hide': 1, 'x': 23, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 61},
         {'id': 305, 'hide': 1, 'x': 23, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 62},
         {'id': 306, 'hide': 1, 'x': 23, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 63},
         {'id': 58, 'hide': 1, 'x': 5, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 64},
         {'id': 54, 'hide': 1, 'x': 6, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 65},
         {'id': 37, 'hide': 1, 'x': 7, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 66},
         {'id': 72, 'hide': 1, 'x': 8, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 67},
         {'id': 464, 'hide': 1, 'x': 5, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 68},
         {'id': 240, 'hide': 1, 'x': 6, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 69},
         {'id': 241, 'hide': 1, 'x': 7, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 70},
         {'id': 390, 'hide': 1, 'x': 8, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 71},
         {'id': 71, 'hide': 1, 'x': 31, 'y': 21, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 72},
         {'id': 66, 'hide': 1, 'x': 32, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 73},
         {'id': 53, 'hide': 1, 'x': 33, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 74},
         {'id': 73, 'hide': 1, 'x': 34, 'y': 21, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 75},
         {'id': 382, 'hide': 1, 'x': 31, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 76},
         {'id': 242, 'hide': 1, 'x': 32, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 77},
         {'id': 243, 'hide': 1, 'x': 33, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 78},
         {'id': 391, 'hide': 1, 'x': 34, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 79}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 19,
            'y': 3 },
        {
            'idx': 1,
            'x': 20,
            'y': 3 },
        {
            'idx': 2,
            'x': 18,
            'y': 3 },
        {
            'idx': 3,
            'x': 21,
            'y': 3 },
        {
            'idx': 4,
            'x': 17,
            'y': 3 },
        {
            'idx': 5,
            'x': 19,
            'y': 2 },
        {
            'idx': 6,
            'x': 20,
            'y': 2 },
        {
            'idx': 7,
            'x': 18,
            'y': 2 },
        {
            'idx': 8,
            'x': 21,
            'y': 2 },
        {
            'idx': 9,
            'x': 17,
            'y': 2 },
        {
            'idx': 10,
            'x': 19,
            'y': 1 },
        {
            'idx': 11,
            'x': 20,
            'y': 1 },
        {
            'idx': 12,
            'x': 18,
            'y': 1 },
        {
            'idx': 13,
            'x': 21,
            'y': 1 },
        {
            'idx': 14,
            'x': 17,
            'y': 1 }])
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(41)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(5)
    stage.unit(0).setDir(stage.countDir(0, 67))
    stage.unit(4).setDir(stage.countDir(4, 0))
    stage.say('&4\n아버지, 이 여정은 정말 길어요,\n슈는 마침내 죽음을 맞이할 위기에 처했다.\n&0\n흠! 하지만 도시를 막고 있는 저 녀석들은,\n그들은 결국 끝까지 저항할 것이다.\n우리는 부주의할 여유가 없어!')
    stage.unit(5).setDir(stage.countDir(5, 0))
    stage.say('&5\n주군, 적군 죽기로 결심한 듯했다.\n병사들의 목숨을 헛되이 희생하기보다는,\n왜 그들을 설득해 항복시키지 않았을까?')
    stage.unit(12).setDir(stage.countDir(12, 0))
    stage.say('&12\n항복을 설득하는 것도 좋은 일이라고 생각해요......\n류산은 어리석고 소심한 통치자라고 전해진다,\n어쩌면 그가 받아들일지도 모른다?')
    stage.unit(8).setDir(stage.countDir(8, 0))
    stage.say('&8\n흥! 저 사람들한테 예의를 차릴 필요 없어.\n그들은 반격할 힘이 없을 때까지 맞아야 합니다.\n아버지, 항복을 설득할 필요는 없다고 생각합니다.')
    stage.unit(1).setDir(stage.countDir(1, 0))
    stage.say('&12\n주군, 어떻게 해야 할까요?\n&0\n흠......')
    sel = stage.choice('그리고 류산에게 항복을 권고했다\n그를 두들겨 맞아 두들겨 맞았다', -1)
    if sel == 1:
        stage.say('&0\n류산의 승패는 이미 명확했다.\n순종적으로 항복하면 목숨은 살려주겠다.\n무기를 내려놓고 도시 밖에서 항복하라!')
        stage.unit(67).setDir(stage.countDir(67, 0))
        stage.say('&67\n아, 좀 그만해줄래?\n나라를 준다 해도 가치가 없어!\n그럼 바로 ......할게')
        stage.unit(35).setDir(stage.countDir(35, 67))
        stage.unit(35).setAction(5)
        stage.say('&35\n폐하! 설마 목숨을 부지하려고\n선제께서 세우신 나라까지 버리시려는 겁니까!')
        stage.unit(35).setAction(0)
        stage.unit(67).setDir(stage.countDir(67, 35))
        stage.unit(67).setAction(10)
        stage.say('&67\n아니, 그게 아니야it공명......\n그게 내가 의도한 게 아니야......\n&0\n뭐, 아직 항복 안 하는 거야?\n그럼 공격을 시작할 거야.\n&67\n아! 아직 죽고 싶지 않아!')
        stage.unit(55).setDir(stage.countDir(55, 67))
        stage.unit(56).setDir(stage.countDir(56, 67))
        stage.say('&55\n주군, 조의 군대가 멀리서 와서 빠르게 행군했다,\n지금은 싸울 수 없을 거야.\n&56\n맞아!\n부하인 그는 아군의 방어를 뚫기 어려울 거라 생각했다.')
        stage.unit(67).setDir(stage.countDir(67, 56))
        stage.say('&67\n이게 사실인가요?\n&56\n네, 성급하게 말할 용기가 없습니다.\n&35\n공명 이미 계획을 세워두었다.\n실패할 이유가 있을 수 있을까요?')
        stage.unit(69).setDir(stage.countDir(69, 67))
        stage.say('&69\n지금 나라를 포기한다면,\n어리석은 황제의 명성만 후세에 남길 뿐이다.')
        stage.unit(67).setDir(stage.countDir(67, 69))
        stage.say('&67\n나는 바보가 아니야.\n처음부터 저는 항복할 생각이 전혀 없었습니다.')
        stage.unit(67).setDir(stage.countDir(67, 0))
        stage.unit(67).setAction(5)
        stage.say('&67\n조조Listen!\n슈를 얻고 싶으면 내 신하가 되라.\n고개를 숙일 용의가 있다면, 일자리를 찾아드리겠습니다.')
        stage.unit(67).setAction(0)
        stage.say('&0\n끝까지 저항할 생각이야, 류산!\n그렇다면 더 이상 항복을 받아들이지 않겠습니다.\n군대 전체가 류산의 목을 노렸다!\n&67\n아!\n&50\n흥! 죽음 직전에서 여전히 강한 척하며,\n정말 안타깝네요.')
        stage.showWinCondition('류산을 물리쳐라!')
        stage.unit(67).heightLight()
    elif sel == 2:
        stage.say('&0\n세 형제와의 운명유비,\n이 전쟁은 황터번에 대한 원정에서 시작되었다.\n&0\n지금은 그들을 끊는 게 아직 내 몫이야,\n심지어 고인이 된 유비와 다른 이들을 위한 의식을 치르기 위해서라도.')
        stage.unit(0).setAction(5)
        stage.say('&0\n군대 전체가 공격을 시작했다!\n슈를 파괴하고 혼란의 시대를 진정시켜라!')
        stage.unit(0).setAction(0)
        stage.showWinCondition('류산을 물리쳐라!')
        stage.unit(35).setDir(stage.countDir(35, 67))
        stage.unit(55).setDir(stage.countDir(55, 67))
        stage.unit(56).setDir(stage.countDir(56, 67))
        stage.unit(69).setDir(stage.countDir(69, 67))
        stage.unit(50).setDir(stage.countDir(50, 67))
        stage.unit(67).setAction(8)
        stage.say('&67\n으, 으악!\n어-어떡하지?\n괜찮아, 공명?\n&35\n주군 당황할 필요 없어,\n여기서 전투를 지켜보면 돼.')
        stage.unit(69).setDir(stage.countDir(69, 55))
        stage.say('&69\n준비됐어?')
        stage.unit(55).setDir(stage.countDir(55, 69))
        stage.say('&55\n모든 준비가 끝났고, 적이 도착하기만 기다리고 있었다.')
        stage.unit(56).setDir(stage.countDir(56, 0))
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.say('&56\n그 사람들이 이걸 생각해냈어,\n하지만 쉽지 않은 일이었다.\n&50\n하하하, 내가 마수인 한 여기 있는 한,\n슈는 죽지 않았을 것이다.')
        vars[2] = 1
    stage.unit(68).setDir(stage.countDir(68, 70))
    stage.say('&68\n때가 왔다.\n장이, 정말 조심해야 해!')
    stage.unit(70).setDir(stage.countDir(70, 68))
    stage.say('&70\n하하하.\n조심해야 할 건 너야, 장이!')
    stage.startOper()
    vars[541] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 20, 25):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 19, 25):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 20, 24):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 19, 24):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[6] and stage.totalRectUnit(0, 4, 9, 9, 27) >= 1 and stage.totalRectUnit(2, 6, 19, 7, 19) < 2:
        stage.unit(58).show()
        stage.unit(54).show()
        stage.unit(37).show()
        stage.unit(72).show()
        stage.unit(464).show()
        stage.unit(240).show()
        stage.unit(241).show()
        stage.unit(390).show()
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(54).setDir(stage.countDir(54, 0))
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(58).setAction(5)
        stage.say('&58\n모두 돌격!')
        stage.unit(58).setAction(0)
        stage.say('&54\n나는 너희가 볼 수 있도록 슈 왕국을 지키고 싶다.\n&37\n가자! 한 명도 살아서 돌아오지 못하게 해.\n&72\n하하하!\n그래서 열정이란 그런 느낌이군요.\n끓어라, 끓여라!')
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 58))
            stage.say('&67\n오오, 마다이, 장바오, 위연,\n주융 부인도 참석했다......\n여러분 모두를 믿고 있어요, 죽여조조!')
            if not vars[50]:
                stage.unit(35).setDir(stage.countDir(35, 58))
                stage.say('&35\n(매복 부대는 조조에 별로 쓸모가 없을 수도 있습니다.\n하지만 병사들이 최선을 다한다면...... )')
        stage.unit(0).setDir(stage.countDir(0, 58))
        stage.unit(0).setAction(5)
        stage.say('매복병 따위 무서워할 게 없어! 어쩔 수 없는 전략은 아무 의미가 없어. 매복병 같은 건 신경 쓰지 말고, 부숴버려!')
        stage.unit(0).setAction(0)
        vars[3] = 1
        vars[6] = 1
    if not vars[7] and stage.totalRectUnit(0, 30, 9, 35, 27) >= 1 and stage.totalRectUnit(2, 32, 19, 33, 19) < 2:
        stage.unit(71).show()
        stage.unit(66).show()
        stage.unit(53).show()
        stage.unit(73).show()
        stage.unit(382).show()
        stage.unit(242).show()
        stage.unit(243).show()
        stage.unit(391).show()
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(73).setDir(stage.countDir(73, 0))
        stage.unit(53).setDir(stage.countDir(53, 0))
        stage.unit(66).setDir(stage.countDir(66, 0))
        stage.unit(71).setAction(5)
        stage.say('&71\n몇 번이나 쓰러져도 항상 다시 일어납니다.\n남부 야만인들의 남성성을 직접 보게 하라!\n전면 군대 공격!')
        stage.unit(71).setAction(0)
        stage.say('&73\n아, 제발, 계속해!\n응? 나도 싸우러 가고 싶어, 응?\n&66\n조조, 내 개인적인 인맥이 여기 있는 한,\n그는 서의 몰락을 막았을 것이다.\n좋아! 싸워!\n&53\n이곳은 전 영주이자 아버지가 세운 나라입니다,\n목숨을 희생하는 것이라도 .......')
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 71))
            stage.say('&67\n아, 저 사람 남야인왕 멍화 아니야?\n조조을 막을 방법을 찾아주세요.')
            if not vars[50]:
                stage.unit(35).setDir(stage.countDir(35, 71))
                stage.say('&35\n여러 층의 매복은 시간을 벌 수 있다,\n그들은 지친 조조군이 전투력을 약화시키길 기다렸다......')
        stage.unit(0).setDir(stage.countDir(0, 71))
        stage.say('&0\n음, 또 매복이군요!?\n공명This 녀석!"')
        vars[3] = 1
        vars[7] = 1
    if not vars[8] and stage.totalRectUnit(0, 10, 9, 29, 14) >= 1 and stage.totalRectUnit(2, 19, 15, 20, 15) < 2:
        stage.unit(57).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(302).show()
        stage.unit(303).show()
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.say('&57\n조조 어디 있지?\n조조 목을 가져!')
        stage.unit(34).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(305).show()
        stage.unit(306).show()
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.say('&34\n조조, 우리의 운명이 여기서 끝나게 하자!\n내 목숨을 줘!')
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 34))
            stage.say('&67\n조운, 마초! 그리고 이 두 호랑이 장군들.\n&67\n세상 누구도 그들을 이길 수 없다.\n그렇게 하면 편히 쉴 수 있어.')
            if not vars[50]:
                stage.unit(35).setDir(stage.countDir(35, 34))
                stage.say('&35\n두 분 모두 수고해 주셔서 감사합니다.\n조운, 마초.\n조조 죽여야 해.')
        stage.unit(0).setDir(stage.countDir(0, 34))
        stage.say('&0\n두 명의 호랑이 장군이 이곳에서 매복 중이었고,\n이로 인해 슈 군대의 전투력이 더욱 강화되었다.\n하지만 걱정할 필요 없어요!\n&0\n한 번에 돌진해!')
        vars[3] = 1
        vars[8] = 1
    if not vars[30] and not vars[31] and stage.isInRect(1025, 3, 8, 19, 27) and stage.curCamp() == 2:
        stage.unit(60).show()
        stage.unit(224).show()
        stage.unit(40).show()
        stage.unit(49).show()
        stage.unit(44).show()
        stage.unit(225).show()
        stage.unit(244).show()
        stage.unit(343).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(40).setDir(stage.countDir(40, 0))
        stage.unit(49).setDir(stage.countDir(49, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.unit(60).setAction(5)
        stage.say('&60\n만약 서나라가 무너진다면,\n다시는 일어설 기회가 없을 거야.\n무슨 일이 있어도 그들은 반드시 막아야 조조.')
        stage.unit(60).setAction(0)
        stage.say('&40\n나, 손첸은 전 영주를 복수하고 싶다유비.\n&49\n이 매복 부대는 조조에 위협이 되지 않을 수도 있습니다,\n하지만 그에게는 충분히 까다로웠다. 해봐!\n&44\n가까이 오게 하면 안 돼!\n무슨 일이 있어도 나라를 지켜야 해!')
        stage.unit(226).show()
        stage.unit(227).show()
        stage.unit(59).show()
        stage.unit(335).show()
        stage.unit(61).show()
        stage.unit(228).show()
        stage.unit(43).show()
        stage.unit(39).show()
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.unit(43).setDir(stage.countDir(43, 0))
        stage.unit(39).setDir(stage.countDir(39, 0))
        stage.say('&59\n잊지 마, 우리도 여기 있어!\n&61\n절대 통과시키지 마!\n&43\n어서!\n&39\n무슨 일이 있어도 그들은 ......를 막아야 했다')
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 60))
            stage.say('&67\n여러분을 부탁드립니다, 여러분.\n네가 조조를 이길 수만 있다면,\n원하는 건 뭐든 줄게!')
            if not vars[50]:
                stage.unit(35).setDir(stage.countDir(35, 60))
                stage.say('&35\n조조 병력을 조금 분산시키고,\n이제부터 전쟁은 훨씬 쉬워질 것이다.')
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.unit(0).setAction(5)
        stage.say('&0\n이 매복들은 이미 내 예상 범위 안이었다!\n두려워할 거 없어, 그냥 돌진해!')
        stage.unit(0).setAction(0)
        vars[30] = 1
    if not vars[30] and not vars[31] and stage.isInRect(1025, 20, 8, 36, 27) and stage.curCamp() == 2:
        stage.unit(226).show()
        stage.unit(227).show()
        stage.unit(59).show()
        stage.unit(335).show()
        stage.unit(61).show()
        stage.unit(228).show()
        stage.unit(43).show()
        stage.unit(39).show()
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.unit(43).setDir(stage.countDir(43, 0))
        stage.unit(39).setDir(stage.countDir(39, 0))
        stage.say('&59\n잊지 마, 우리도 여기 있어!\n&61\n절대 통과시키지 마!\n&43\n어서!\n&39\n무슨 일이 있어도 그들은 ......를 막아야 했다')
        stage.unit(60).show()
        stage.unit(224).show()
        stage.unit(40).show()
        stage.unit(49).show()
        stage.unit(44).show()
        stage.unit(225).show()
        stage.unit(244).show()
        stage.unit(343).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(40).setDir(stage.countDir(40, 0))
        stage.unit(49).setDir(stage.countDir(49, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.unit(60).setAction(5)
        stage.say('&60\n만약 서나라가 무너진다면,\n다시는 일어설 기회가 없을 거야.\n무슨 일이 있어도 그들은 반드시 막아야 조조.')
        stage.unit(60).setAction(0)
        stage.say('&40\n나, 손첸은 전 영주를 복수하고 싶다유비.\n&49\n이 매복 부대는 조조에 위협이 되지 않을 수도 있습니다,\n하지만 그에게는 충분히 까다로웠다. 해봐!\n&44\n그들은 절대 도시에 들어오게 해서는 안 된다!\n무슨 일이 있어도 나라를 지켜야 해!')
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 59))
            stage.say('&67\n여러분을 부탁드립니다, 여러분.\n네가 조조를 이길 수만 있다면,\n원하는 건 뭐든 줄게!')
            if not vars[50]:
                stage.unit(35).setDir(stage.countDir(35, 59))
                stage.say('&35\n조조 병력을 조금 분산시키고,\n이제부터 전쟁은 훨씬 쉬워질 것이다.')
        stage.unit(0).setDir(stage.countDir(0, 59))
        stage.unit(0).setAction(5)
        stage.say('&0\n이 매복들은 이미 내 예상 범위 안이었다!\n두려워할 거 없어, 그냥 돌진해!')
        stage.unit(0).setAction(0)
        vars[31] = 1
    if vars[3] and not vars[32] and stage.isInRect(1025, 11, 19, 28, 27) and stage.curCamp() == 1:
        if not vars[8]:
            stage.unit(57).show()
            stage.unit(462).show()
            stage.unit(463).show()
            stage.unit(302).show()
            stage.unit(303).show()
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.say('&57\n쳇, 옆에서 공격당할 줄은 몰랐어!')
            stage.unit(34).show()
            stage.unit(258).show()
            stage.unit(259).show()
            stage.unit(305).show()
            stage.unit(306).show()
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n오, 안 돼!\n그가 조조인 것도 당연하다—정말 다루기 힘든 사람이다.')
            stage.setAI(16, 0, 23, 20, 2, 1)
            vars[8] = 1
        if not vars[7]:
            stage.unit(71).show()
            stage.unit(66).show()
            stage.unit(53).show()
            stage.unit(73).show()
            stage.unit(382).show()
            stage.unit(242).show()
            stage.unit(243).show()
            stage.unit(391).show()
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.unit(73).setDir(stage.countDir(73, 0))
            stage.unit(53).setDir(stage.countDir(53, 0))
            stage.unit(66).setDir(stage.countDir(66, 0))
            stage.unit(71).setAction(5)
            stage.say('&71\n그들은 실제로 우리의 매복을 피했다......\n아니, 방법을 생각해야겠어.\n전 군대가 힘을 합쳐 류산 주군를 지켰다!')
            stage.unit(71).setAction(0)
            stage.say('&73\n응? 응? 응? 응? 응?\n어떻게 해야 할까요?\n&66\n쳇, 발각됐어!\n좋아, 난 매복 같은 거 싫어.\n&53\n서둘러! 관수오!\n주군를 지켜줘!')
            stage.setAI(24, 0, 39, 27, 2, 4, -1, 20, 21)
            vars[7] = 1
        if not vars[6]:
            stage.unit(58).show()
            stage.unit(54).show()
            stage.unit(37).show()
            stage.unit(72).show()
            stage.unit(464).show()
            stage.unit(240).show()
            stage.unit(241).show()
            stage.unit(390).show()
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(54).setDir(stage.countDir(54, 0))
            stage.unit(37).setDir(stage.countDir(37, 0))
            stage.unit(72).setDir(stage.countDir(72, 0))
            stage.say('&58\n큰일이야—조의 군대가 실제로 이곳에 도착했어!\n&54\n응.\n그는 즉시 류산의 주군로 돌아가야 했다.\n&37\n쳇! 젠장, 조조 도둑!\n&72\n흥! 조조 꽤 괜찮네요.\n상대가 강할수록 더 신나!\n돌격!')
            stage.setAI(0, 0, 15, 27, 2, 4, -1, 20, 21)
            vars[6] = 1
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 0))
            stage.say('&67\n으, 으악!\n왜 내가 전에 말한 것과 다른가?\n빨리 뭔가 해결책 찾아!')
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.say('&35\n우리가 버티지 못한다면,\n이 전투는 완전히 절망적이었다.\n도시 안의 군대는 방어를 강화해야 한다!')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n무슨 일이 있어도 버텨.\n조조 선을 넘게 둘 수 없어.')
        if not vars[52]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n흥, 뭐가 당황할 게 있어......\n적이 뚫고 들어올 수 있는 입구는 많지 않습니다.\n입구에 있는 적들을 제거하면 이길 수 있습니다!')
        if not vars[72]:
            stage.unit(55).setDir(stage.countDir(55, 67))
            stage.say('&55\n류산을 지켜주군!\n적이 이 검문소를 통과하면 슈는 끝장이다.\n죽음을 치르더라도 지켜라!')
        if not vars[73]:
            stage.unit(56).setDir(stage.countDir(56, 0))
            stage.say('&56\n조조This 녀석!\n드디어 여기까지 왔네요.')
        stage.setAI(16, 21, 23, 27, 2, 0)
        stage.unit(67).setAI(2)
        stage.unit(35).setAI(2)
        stage.unit(0).setDir(stage.countDir(0, 67))
        stage.unit(0).setAction(5)
        stage.say('여러분, 조금만 더 힘내세요. 곧 촉나라를 멸망시킬 겁니다!')
        stage.unit(0).setAction(0)
        vars[32] = 1
    if not vars[2] and not vars[40] and stage.isNear(0, 67, False):
        stage.resumeCtrl()
        stage.unit(0).setDir(stage.countDir(0, 67))
        stage.unit(67).setDir(stage.countDir(67, 0))
        stage.unit(67).setAction(4)
        stage.say('&0\n류산, 오 류산.........\n그냥 죽을 준비만 해.\n&67\n살려 주세요!\n제발 살려줘!\n으, 우, 와!')
        stage.unit(67).setDir(stage.countDir(67, 0))
        stage.unit(67).setAction(8)
        stage.say('&0\n생각도 하지 마!')
        stage.attackAction(0, 67, 1)
        stage.delay(10)
        stage.say('&67\n와!')
        stage.unit(67).hide(2)
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(4)
            stage.say('&35\n그럴 수도 있...... 슈가 정말 끝난 걸까?\n유비주군, 공명 미안해.\n&35\n지금은 .........\n그래서 저항하기 위해 우와 동맹을 맺을 수밖에 없었다.\n전군이 청두를 버렸다!')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n어떻게 이럴 수 있지?\n그는 조조......에게 칼날을 휘두르기도 전에 죽었다\n&69\n우리 통치자는 정말 쓸모없다,\n그런 군주에게 충성할 필요가 없었다.\n왜 그냥 우에 가입하지 않나요?')
        if not vars[52]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n흥, 이런 통치자는 나를 제대로 활용하는 법을 전혀 모른다.\n그럼 새 군주를 찾아볼게!')
        if not vars[72]:
            stage.unit(55).setDir(stage.countDir(55, 0))
            stage.say('&55\n아...... 류산 주군! 혐오스러운 조 반역자!\n나, 장완, 설령 세상을 떠돌더라도,\n언젠가 이 원한은 반드시 복수될 것이다.')
        if not vars[73]:
            stage.unit(56).setDir(stage.countDir(56, 0))
            stage.say('&56\n정말 안타깝네요......\n더 이상 여기 있을 필요 없어.\n도망쳐!')
        stage.setRectUnitHide(0, 0, 39, 31, 2)
        vars[40] = 1
        stage.say('&0\n슈는 마침내 그의 손에 있었다.\n이 여정은 정말 길다!\n모두 수고 많으셨습니다!')
        stage.reward(0, [
            143,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[641] = 1
        return True
    if not vars[41] and stage.isNear(1, 34, False):
        stage.unit(1).setDir(stage.countDir(1, 34))
        stage.unit(34).setDir(stage.countDir(34, 1))
        stage.say('&1\n이게 우리 마지막 경기야.\n공정하게 해결해, 조운!\n&34\n바로 그 생각이었어요!\n여기서 결과를 정합시다!')
        fight = stage.startFight(1, 34, 5)
        fight.showUnit(True, '온 힘을 다해 싸워라!\n조운!', 9)
        fight.showUnit(False, '그게 내가 전에 계획했던 일이었다.\n방심하지 마!', 8)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 3, True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 4, True)
        fight.setAction(False, 1)
        fight.attack2(True, 1, True)
        fight.setAction(False, 1)
        fight.setAction(True, 1)
        fight.attack1(False, 2, True)
        stage.delay(15)
        fight.setAction(True, 0)
        fight.say(True, '쉭!\n우리 무술이 서로 ...... 것 같아.\n그는 모든 것을 속속들이 알고 있었다.', True)
        fight.setAction(False, 0)
        fight.say(False, '오랫동안 전장에서 싸운 후,\n이건 당연한 일이에요.', True)
        fight.setAction(False, 6)
        fight.say(False, '쉭!\n하지만 생각해보면, 사실 꽤 흥미롭네요,\n우리가 친구와 적을 구분하지 않는다면......', True)
        fight.setAction(True, 9)
        fight.say(True, '우리가 좋은 친구가 될 수 있다는 말인가요?\n정말 네가 내 좋은 조수가 되어줬으면 해!', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '하하하하!', True)
        fight.setAction(True, 0)
        fight.say(True, '와하하하하!', True)
        fight.setAction(False, 8)
        fight.say(False, '직접 경험해봤어요!', True)
        fight.setAction(True, 8)
        fight.say(True, '어서!', True)
        fight.attack2(True, 2, True)
        stage.delay(15)
        fight.say(True, '승리 ......\n드디어 조운을 이겼다!', True)
        stage.delay(10)
        fight.say(False, '그래도 네가 더 나은 ......하후돈야.\n네 총알 아래서 죽을 수 있겠어......\n나도 깊이 느껴...... 광...... 롱......', True)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '안녕, 조운.\n절대 잊지 않을 거야!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 3)
        fight.setAction(True, 13)
        fight.end()
        stage.unit(34).hide(2)
        stage.getItem(81, -1, True, 1)
        vars[51] = 1
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 1))
            stage.say('&67\n아? 조운!\n내가 아직도 살아있는 이유는 전부 조운 덕분이야.\n&67\n조운Ah, 조운, 돌아와......\n조운......')
        vars[41] = 1
    if not vars[43] and stage.isNear(4, 53, False):
        stage.unit(53).setDir(stage.countDir(53, 4))
        stage.unit(4).setDir(stage.countDir(4, 53))
        stage.say('&53\n여기서는 아무도 통과할 수 없어!\n&4\n너 관우 아들, 관싱이구나!\n나는 조조의 둘째 아들 조장이다!\n이 문제를 너와 해결하고 싶어!\n&53\n좋아! 가자!')
        fight = stage.startFight(4, 53, 5)
        fight.showUnit(False, '나는 관싱이다!\n조장, 도망치고 싶으면 아직 늦지 않았어.', 9)
        fight.showUnit(True, '그 말 후회하지 마세요!', 8)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '이걸 받아라!', True)
        fight.setAction(True, 6)
        fight.say(True, '어서!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 3, False)
        fight.say(False, '잠깐!', False)
        fight.setAction(False, 2)
        fight.attack1(True, 2, True)
        fight.setAction(False, 11)
        stage.delay(5)
        fight.say(False, '와!', True)
        fight.setAction(True, 8)
        fight.say(True, '끝났어!', False)
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.say(False, '', False)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        stage.delay(15)
        fight.say(False, '아버지, 아버지......\n이거 너무 싫어!', True)
        fight.death(True)
        fight.setAction(True, 1)
        stage.delay(5)
        fight.setAction(True, 10)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '조조의 아들 조장이 관싱의 목을 가져갔다!\n모두 돌격!', True)
        fight.end()
        stage.unit(53).hide(2)
        vars[61] = 1
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 4))
            stage.say('&67\n관싱!\n아! 관이숙의 아들도 아니야?')
        vars[43] = 1
    if not vars[45] and stage.isNear(15, 54, False):
        stage.unit(54).setDir(stage.countDir(54, 15))
        stage.unit(15).setDir(stage.countDir(15, 54))
        stage.say('&15\n꺼져, 나를 막지 마!\n&54\n흠, 허저?\n나는 장비의 아들 장바오다,\n일대일로 도전하고 싶어.')
        fight = stage.startFight(15, 54, 5)
        fight.showUnit(True, '아, 장비의 아들이야?\n네가 뭘 할 수 있는지 보여줘!\n장비가 정말 대단해. 너는 어떻게 지내고 있을까?"', 8)
        fight.showUnit(False, '아버지를 위해 널 죽여버릴 거야!\n허저, 목숨을 걸어!', 9)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(False, 1, False)
        fight.attack1(False, 1, False)
        fight.say(True, '음음음!', True)
        fight.attack1(True, 2, True)
        fight.say(False, '음!', True)
        fight.setAction(True, 10)
        fight.say(True, '무슨 일이야?\n장비 너랑 다르지?"', True)
        fight.setAction(False, 8)
        fight.say(False, '젠장, 젠장!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(False, 1, False)
        fight.attack1(True, 0, True)
        fight.attack2(True, 1, False)
        stage.delay(15)
        fight.say(False, '거짓말 아니에요......', True)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '아버지만큼 좋지 않은 것 같아요.', True)
        fight.end()
        stage.unit(54).hide(2)
        vars[60] = 1
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 15))
            stage.say('&67\n장바오가 죽었다고?\n어떻게 해야 할까요?\n누가 날 구해줄까!')
        vars[45] = 1
    if not vars[46] and stage.isNear(9, 57, False):
        stage.unit(57).setDir(stage.countDir(57, 9))
        stage.unit(9).setDir(stage.countDir(9, 57))
        stage.say('&57\n방덕, 지금 후회하기에 늦지 않았어,\n아군로 돌아올까?\n&9\n나와 조조는 이미 통치자와 신하 사이에 유대를 맺었어,\n사무라이는 약속을 어길 수 없다.\n&57\n하지만 조조 내 아버지 마텡을 죽였어,\n아버지의 죽음을 복수하지 않을 수 있겠는가?\n다시 생각해, 방덕.\n&9\n미안해, 난 이걸 할 수 없어.\n여전히 위나라와 서나라 장군으로서,\n공정하게 해결합시다.\n&57\n내가 뭐라고 해도 동의 안 할 거야?\n이 유대를 끝내기 위해 너를 죽일 수밖에 없어.\n공정하게 해결합시다.\n&9\n전사로서 어떻게 거절할 수 있겠는가?\n명예롭게 맞서자!')
        fight = stage.startFight(9, 57, 5)
        fight.showUnit(True, '이것이 혼란의 시대의 운명이다.\n용서해 주십시오, 마초 장군님.', 6)
        fight.showUnit(False, '더 이상 말하지 마, 방덕.\n제대로 한 판 붙게 해줘!', 0)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '이걸 받아라!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        stage.delay(10)
        fight.say(True, '너 더 강해졌어......\n하지만 이 정도 실력으로는 내 방덕을 이길 수 없어!', True)
        fight.setAction(True, 0)
        fight.say(True, '이걸 받아라!', True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 3, False)
        stage.delay(15)
        fight.setAction(False, 0)
        fight.say(False, '진정으로 방덕라 불릴 자격이 있다,\n역시 쉽게 이길 수 없어.', True)
        fight.setAction(False, 4)
        fight.setAction(False, 10)
        fight.say(False, '하지만 내 마초은 절대 지지 않을 거야.\n내 궁극 기술을 봐!', True)
        fight.setAction(False, 3)
        fight.setAction(False, 2)
        fight.attack2(False, 1, True)
        fight.setAction(False, 1)
        fight.attack2(False, 1, True)
        fight.setAction(False, 1)
        fight.attack2(False, 1, True)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.say(True, '안녕히 계세요, 마초 장군님!', True)
        fight.setAction(False, 1)
        fight.say(False, '흠, 어떻게 그럴 수 있......', True)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        stage.delay(20)
        fight.say(False, '너—정말 amazing......방덕.\n정말 훌륭합니다......\n……… 와!', True)
        fight.death(True)
        fight.setAction(True, 1)
        stage.delay(10)
        fight.setAction(True, 11)
        stage.delay(20)
        fight.say(True, '마초 제너럴 ......', True)
        fight.end()
        stage.unit(57).hide(2)
        vars[63] = 1
        if not vars[75]:
            stage.unit(67).setDir(stage.countDir(67, 9))
            stage.say('&67\n이 세상에 실제로 마초를 죽일 수 있는 사람이 있다!\n누구 없어! 그 사람 차단해 줘!')
        vars[46] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n음, 지금은 여기서 떠나는 게 낫겠네.')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n유비주군, 관우와 장비 둘 다 떠났어,\n이제 드디어 내 차례야.\n돌이켜보면, 제 인생은 정말 오르내림으로 가득했습니다.\n&34\n하지만 죽음 속에서도 후회는 없어...... 절대 안 돼!')
        stage.unit(34).hide(2)
        stage.getItem(81, -1, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n쳇, 슈가 정말 망한 걸까?\n나를 고마워해줄 통자를 찾아야겠어!')
        stage.unit(50).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(59, 7, 0, 2):
        stage.say('&59\n와! 내 인생은 끝났어...... 말도 안 돼!')
        stage.unit(59).hide(2)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n후퇴, 후퇴.\n그는 시골로 물러나 복수를 추구할 것이다.')
        stage.unit(69).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n아파!\n젠장! 이렇게 그냥 돌아가는 거야?\n꼭 다시 올게요!')
        stage.unit(71).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n아, 이거 큰일이야!\n생각 좀 해볼게...... 지금 내가 뭘 해야 할까?\n좋아, 후퇴!')
        stage.unit(73).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n음, 그래도 조조 못 이길 거야.\n하지만 언젠가는 그가 내 앞에 무릎을 꿇어야 할 것이다.')
        stage.unit(72).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(66, 7, 0, 2):
        stage.say('&66\n혹시 나, 관수오가 여기서 죽을 뻔한 건가?\n돌이켜보면, 제 인생은 정말 후회 없이 살아왔습니다!')
        stage.unit(66).hide(2)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n뭐라고!? 음, 오, 오!')
        stage.unit(37).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(54, 7, 0, 2):
        stage.say('&54\n정말 안타깝네요...... 말도 안 돼!')
        stage.unit(54).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(53, 7, 0, 2):
        stage.say('&53\n아버지, 죄송합니다.\n관싱이 너희 곁에 있어줄 거야, 어!')
        stage.unit(53).hide(2)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(60, 7, 0, 2):
        stage.say('&60\n이런 곳에 영원히 있을 수는 없어.\n도망쳐!')
        stage.unit(60).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n음, 어떻게 그럴 수 있지......\n어떻게 이렇게 죽을 수 있지......\n기침, 기침......')
        stage.unit(57).hide(2)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n이런 상태가 계속되면 상황이 좋지 않을 것입니다.\n다른 곳으로 물러나!')
        stage.unit(58).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(44, 7, 0, 2):
        stage.say('&44\n흠!\n그래도 주군 지키지 못했네, 흠!')
        stage.unit(44).hide(2)
        vars[65] = 1
    if not vars[66] and stage.unitStateTest(61, 7, 0, 2):
        stage.say('&61\n아파! 어떻게 이런 일이 일어날 수 있지!?\n어떻게 이렇게 될 수 있었을까......')
        stage.unit(61).hide(2)
        vars[66] = 1
    if not vars[67] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n유비주군, 미안.\n손자의 힘은 아직 부족해......\n저승에 가서 같이 있어줄게.')
        stage.unit(40).hide(2)
        vars[67] = 1
    if not vars[68] and stage.unitStateTest(68, 7, 0, 2):
        stage.say('&68\n와!')
        stage.unit(68).hide(2)
        vars[68] = 1
    if not vars[69] and stage.unitStateTest(70, 7, 0, 2):
        stage.say('&70\n뭐라고!\n와!')
        stage.unit(70).hide(2)
        vars[69] = 1
    if not vars[70] and stage.unitStateTest(43, 7, 0, 2):
        stage.say('&43\n내 운명은 이렇게 된 거야......\n하하하, 설마!')
        stage.unit(43).hide(2)
        vars[70] = 1
    if not vars[71] and stage.unitStateTest(49, 7, 0, 2):
        stage.say('&49\n음음!\n아니, 치명타를 입었어.\n정말 원하지 않는다는 것......')
        stage.unit(49).hide(2)
        vars[71] = 1
    if not vars[72] and stage.unitStateTest(39, 7, 0, 2):
        stage.say('&39\n나—정말 그렇게 죽는 거야?\n와!')
        stage.unit(39).hide(2)
        vars[72] = 1
    if not vars[73] and stage.unitStateTest(56, 7, 0, 2):
        stage.say('&56\n음.\n아무 이유 없이 죽음에 뛰어드는 건 너무 어리석은 일이야.\n복귀할 기회를 기다리고, 후퇴하세요!')
        stage.unit(56).hide(1)
        vars[73] = 1
    if not vars[74] and stage.unitStateTest(55, 7, 0, 2):
        stage.say('&55\n더 이상 버틸 수 없어.\n전장을 대피시켜라!\n후퇴!')
        stage.unit(55).hide(1)
        vars[74] = 1
    if not vars[75] and stage.unitStateTest(67, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&67\n살려줘—살려줘!\n내 목숨을 살려줘......\n음, 음, 아니, 와우......')
        stage.unit(67).hide(2)
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(4)
            stage.say('&35\n그럴 수도 있...... 슈가 정말 끝난 걸까?\n유비주군, 공명 미안해.\n&35\n지금은 .........\n그래서 저항하기 위해 우와 동맹을 맺을 수밖에 없었다.\n전군이 청두를 버렸다!')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n우리 통치자는 정말 쓸모없다,\n그런 군주에게 충성할 필요가 없었다.\n왜 그냥 우에 가입하지 않나요?')
        if not vars[52]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n흥, 이런 통치자는 나를 제대로 활용하는 법을 전혀 모른다.\n그럼 새 주군 찾으러 갈게!')
        if not vars[72]:
            stage.unit(55).setDir(stage.countDir(55, 0))
            stage.say('&55\n아...... 류산 주군! 혐오스러운 조 반역자!\n나, 장완, 설령 세상을 떠돌더라도,\n언젠가는 자신의 결백도 벗을 것이다.')
        if not vars[73]:
            stage.unit(56).setDir(stage.countDir(56, 0))
            stage.say('&56\n정말 안타깝네요......\n여기 있을 필요 없어.\n가자!')
        stage.setRectUnitHide(0, 0, 39, 31, 2)
        vars[75] = 1
        stage.say('&0\n슈는 마침내 그의 손에 있었다.\n이 여정은 정말 길다!\n모두 수고 많으셨습니다!')
        stage.reward(0, [
            143,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[641] = 1
        return True
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n슈는 마침내 그의 손에 있었다.\n이 여정은 정말 길다!\n모두 수고 많으셨습니다!')
        stage.reward(0, [
            143,
            -1])
        stage.end()
        vars[0] = 1
        vars[641] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 류산의 군대 앞에서 큰 패배를 겪었으나 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
