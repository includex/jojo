# Source Generated with Decompyle++
# File: S_49.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(23,28)',
        '(24,28)',
        '(23,27)',
        '(24,27)',
        '(14,28)',
        '(14,33)',
        '(7,33)',
        '(4,24)'])
    stage.nearEvent([
        0,
        76,
        0,
        77,
        0,
        81], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, 76, 0, 0, 1)
    stage.createEnemy(
        [{'id': 76, 'x': 23, 'y': 28, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 79, 'x': 24, 'y': 28, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 88, 'x': 23, 'y': 27, 'dir': 0, 'lv': 4, 'i': 2},
         {'id': 350, 'x': 24, 'y': 27, 'dir': 0, 'lv': 0, 'i': 3},
         {'id': 210, 'x': 23, 'y': 24, 'dir': 0, 'lv': 0, 'i': 4},
         {'id': 211, 'x': 24, 'y': 24, 'dir': 0, 'lv': 0, 'i': 5},
         {'id': 212, 'x': 27, 'y': 27, 'dir': 1, 'lv': 0, 'i': 6},
         {'id': 213, 'x': 27, 'y': 28, 'dir': 1, 'lv': 0, 'i': 7},
         {'id': 234, 'x': 23, 'y': 25, 'dir': 0, 'lv': 0, 'i': 8},
         {'id': 235, 'x': 24, 'y': 25, 'dir': 0, 'lv': 0, 'i': 9},
         {'id': 236, 'x': 26, 'y': 27, 'dir': 1, 'lv': 0, 'i': 10},
         {'id': 237, 'x': 26, 'y': 28, 'dir': 1, 'lv': 0, 'i': 11},
         {'id': 214, 'x': 6, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 215, 'x': 8, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 216, 'x': 4, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 14},
         {'id': 217, 'x': 6, 'y': 24, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 15},
         {'id': 218, 'x': 4, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 16},
         {'id': 238, 'x': 7, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 17},
         {'id': 239, 'x': 4, 'y': 24, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 18},
         {'id': 78, 'x': 14, 'y': 28, 'dir': 0, 'lv': 6, 'i': 19},
         {'id': 82, 'x': 14, 'y': 27, 'dir': 0, 'lv': 4, 'i': 20},
         {'id': 92, 'x': 15, 'y': 28, 'dir': 0, 'lv': 4, 'i': 21},
         {'id': 219, 'x': 13, 'y': 27, 'dir': 0, 'lv': 0, 'i': 22},
         {'id': 220, 'x': 15, 'y': 27, 'dir': 0, 'lv': 0, 'i': 23},
         {'id': 240, 'x': 13, 'y': 28, 'dir': 0, 'lv': 0, 'i': 24},
         {'id': 80, 'x': 14, 'y': 33, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 25},
         {'id': 85, 'x': 14, 'y': 32, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 26},
         {'id': 83, 'x': 15, 'y': 33, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 27},
         {'id': 258, 'x': 13, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 259, 'x': 15, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 282, 'x': 13, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 81, 'x': 28, 'y': 9, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 31},
         {'id': 87, 'x': 27, 'y': 9, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 32},
         {'id': 358, 'x': 26, 'y': 8, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 359, 'x': 27, 'y': 8, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 360, 'x': 28, 'y': 8, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 361, 'x': 29, 'y': 8, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 362, 'x': 26, 'y': 9, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 363, 'x': 29, 'y': 9, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 364, 'x': 26, 'y': 10, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 365, 'x': 27, 'y': 10, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 366, 'x': 28, 'y': 10, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 367, 'x': 29, 'y': 10, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 42},
         {'id': 77, 'x': 3, 'y': 9, 'dir': 0, 'lv': 6, 'i': 43},
         {'id': 86, 'x': 4, 'y': 9, 'dir': 0, 'lv': 4, 'i': 44},
         {'id': 368, 'x': 2, 'y': 8, 'dir': 0, 'lv': 0, 'i': 45},
         {'id': 369, 'x': 3, 'y': 8, 'dir': 0, 'lv': 0, 'i': 46},
         {'id': 370, 'x': 4, 'y': 8, 'dir': 0, 'lv': 0, 'i': 47},
         {'id': 371, 'x': 5, 'y': 8, 'dir': 0, 'lv': 0, 'i': 48},
         {'id': 372, 'x': 2, 'y': 9, 'dir': 0, 'lv': 0, 'i': 49},
         {'id': 373, 'x': 5, 'y': 9, 'dir': 0, 'lv': 0, 'i': 50},
         {'id': 374, 'x': 2, 'y': 10, 'dir': 0, 'lv': 0, 'i': 51},
         {'id': 375, 'x': 3, 'y': 10, 'dir': 0, 'lv': 0, 'i': 52},
         {'id': 376, 'x': 4, 'y': 10, 'dir': 0, 'lv': 0, 'i': 53},
         {'id': 377, 'x': 5, 'y': 10, 'dir': 0, 'lv': 0, 'i': 54},
         {'id': 84, 'x': 16, 'y': 19, 'dir': 0, 'lv': 6, 'i': 55},
         {'id': 96, 'x': 15, 'y': 19, 'dir': 0, 'lv': 4, 'i': 56},
         {'id': 378, 'x': 14, 'y': 18, 'dir': 0, 'lv': 0, 'i': 57},
         {'id': 379, 'x': 15, 'y': 18, 'dir': 0, 'lv': 0, 'i': 58},
         {'id': 380, 'x': 16, 'y': 18, 'dir': 0, 'lv': 0, 'i': 59},
         {'id': 381, 'x': 17, 'y': 18, 'dir': 0, 'lv': 0, 'i': 60},
         {'id': 310, 'x': 14, 'y': 19, 'dir': 0, 'lv': 0, 'i': 61},
         {'id': 311, 'x': 14, 'y': 20, 'dir': 0, 'lv': 0, 'i': 62},
         {'id': 312, 'x': 17, 'y': 19, 'dir': 0, 'lv': 0, 'i': 63},
         {'id': 313, 'x': 17, 'y': 20, 'dir': 0, 'lv': 0, 'i': 64},
         {'id': 298, 'x': 15, 'y': 20, 'dir': 0, 'lv': 0, 'i': 65},
         {'id': 299, 'x': 16, 'y': 20, 'dir': 0, 'lv': 0, 'i': 66}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 15,
            'y': 4 },
        {
            'idx': 1,
            'x': 16,
            'y': 4 },
        {
            'idx': 2,
            'x': 15,
            'y': 5 },
        {
            'idx': 3,
            'x': 16,
            'y': 5 },
        {
            'idx': 4,
            'x': 14,
            'y': 5 },
        {
            'idx': 5,
            'x': 17,
            'y': 5 },
        {
            'idx': 6,
            'x': 14,
            'y': 4 },
        {
            'idx': 7,
            'x': 17,
            'y': 4 },
        {
            'idx': 8,
            'x': 15,
            'y': 3 },
        {
            'idx': 9,
            'x': 16,
            'y': 3 },
        {
            'idx': 10,
            'x': 14,
            'y': 3 },
        {
            'idx': 11,
            'x': 17,
            'y': 3 },
        {
            'idx': 12,
            'x': 15,
            'y': 2 },
        {
            'idx': 13,
            'x': 16,
            'y': 2 },
        {
            'idx': 14,
            'x': 14,
            'y': 2 }])
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(49)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(1)
    stage.say('&76\n이번에는 이렇게 거대한 병력을 동원하며,\n우리나라 다른 도시들의 방어는 영향을 받지 않았죠?')
    stage.unit(88).setDir(stage.countDir(88, 76))
    stage.say('&88\n현재 대부분의 방어선은 슈 군인들이 지키고 있는 것으로 보입니다.')
    stage.unit(76).setDir(stage.countDir(76, 88))
    stage.unit(76).setAction(10)
    stage.say('&76\n뭐라고 했어?\n우리는 슈의 유비을 죽였다,\n왜 슈군이 여전히 아군에 합류했을까요?!')
    stage.unit(79).setDir(stage.countDir(79, 76))
    stage.say('&79\n주군 알아야 해,\n내 형공명 여기 와서 제단을 만들고 기도하러 오지, 맞지?\n&88\n그는 이 병사들을 지키는 것이 감사의 표시라고 말했다.\n모든 일이 주지사가 처리했으니,\n세부 사항은 불분명하다......')
    stage.unit(76).setDir(stage.countDir(76, 77))
    stage.say('&76\n그러니 지금은 그들을 믿자,\n하지만 주유 마음속에 정확히 무슨 계획을 세우고 있는 걸까?\n&76\n공명와 주유가 몰래 힘을 합쳤다고 들었어,\n소문이 사실인 것 같아; 앞으로 진상을 밝혀야 해.\n&82\n이렇게 거대한 군단은 정말 장관입니다!\n그런 능력은 오직 주지사만이 가지고 있습니다.\n&78\n그래서 그가 주 도지사인 거구나.\n&92\n와서 죽어라, 차오쥔.\n이번에는 반드시 복수해야 해!\n&83\n이처럼 강력한 군사력을 가진 이후,\n참여하지 않아도 상관없어요.')
    stage.unit(85).setDir(stage.countDir(85, 83))
    stage.say("&85\n전장을 지배하고 싶어요!\n군 장군이 어떻게 공로를 쌓고 경력을 쌓지 못할 수 있겠는가?\n&80\n속담에 '소수는 다수를 이길 수 없다'고 하잖아요.\n이번에는 조의 군대가 우리를 절대 이길 수 없을 거야.\n&81\n우리 동오군이 해전으로 어떻게 패배할 수 있겠는가!\n매일 아군 운동의 결과를 보여드리겠습니다.\n&87\n숫자로 싸우는 것은 우리의 이익에 법정.\n&96\n군사력이 워낙 크니까,\n더 이상 전략을 쓸 필요는 없다고 생각해요,\n전력으로 공격하는 것만으로도 충분적군!")
    stage.unit(84).setDir(stage.countDir(84, 0))
    stage.unit(84).setAction(5)
    stage.say('&84\n이봐, 이봐, 이봐, 조조!\n우리 군대가 지금 얼마나 위압적인지 보세요!')
    stage.unit(84).setAction(0)
    stage.unit(86).setDir(stage.countDir(86, 77))
    stage.say('&86\n저우 사령관, 아직 싸우지 않을 거야?\n&77\n(동오가 적절한 시기와 지리적 이점을 확보했기를 바랍니다,\n조조 신중하게 집에 가는 법을 알고 있어. )\n&77\n나는 죽음의 그림자를 지니고 있다,\n조조 죽음의 영혼과 함께 등을 기대며 함께 살아간다.\n누구에게 털어놓아야 할지 모르겠어......\n&86\n지휘관님, 당신은 오랫동안 이야기하고 계시네요,\n그러니까 싸우지 말라는 거지?')
    stage.unit(0).setDir(stage.countDir(0, 84))
    stage.say('&0\n그는 우가 이렇게 강력한 전투력을 가질 줄은 전혀 예상하지 못했다.\n정면 충돌한다면 분명히 자살 행위일 것이다.\n&0\n여기에 도착한 후에도,\n그들은 철수할 수밖에 없었다.')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n동오 군대는 강력했고 해군 전투에 능했다.\n이 때문에 부주의해지기 쉬워집니다.')
    stage.unit(0).setDir(stage.countDir(0, 19))
    stage.say('&0\n좋은 아이디어가 있나요?\n&19\n장군 수에 관해서는 두 군대 간에 큰 차이가 없습니다.\n상대와 일대일 결투를 도전하고 품위 있게 결과를 결정할 수 있다면,\n어쩌면 싸울 수도 있겠지.\n&0\n알겠어. 상대방의 자존심을 이용하고,\n적군을 대등한 전투로 유인하기 위해,\n이렇게 하면 한 명씩 물리칠 수 있습니다.\n&0\n이런 방식으로 직접적인 돌파구가 되었습니다\n어쩌면 그들도 이 상황을 이용할 수 있을지도 모른다.\n시도해볼 만한 가치가 있어 보입니다.')
    sel = stage.choice('한 명씩 물리쳐\n정면 돌파구', -1)
    if sel == 1:
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(0).setAction(5)
        stage.say('&0\n손권, 잘 들어!\n해전이 아군를 이길 수 없다는 걸 드디어 인정하셨죠?\n&0\n만약 누군가가 대규모 병력을 보유하면 승리가 보장된다고 생각한다면,\n그건 큰 실수야.\n&0\n용기가 있다면, 장군들이 이 문제를 최선으로 해결하게 두세요!\n이 대회에서 이기면,\n여러분의 강인함을 인정합니다!')
        stage.unit(0).setAction(0)
        stage.unit(85).setDir(stage.countDir(85, 84))
        stage.say('&85\n감녕, 조조 얘기하고 싶으면 그냥 하게 둬!\n그에게 우 해군의 힘을 보여줘.\n&84\n적에게 모욕당하고 대응할 수 없었다,\n정말 참을 수가 없어요!')
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&77\n(이런 도발은 내 주유에는 통하지 않는다. )\n&77\n(조조 공명 맞서게 하려면,\n그들이 스스로 철수하길 바랍니다. )\n&77\n(하지만 해군 전투력의 격차를 보게 하라,\n일찍 포기하는 게 낫다. )\n&77\n우리 함대가 바람을 타고 파도를 가르는 뛰어난 기술들,\n마치 물 위에서 춤추는 백조처럼.\n내가 제대로 보여줄게!')
        stage.unit(84).setDir(stage.countDir(84, 0))
        stage.say('&84\n이봐, 이봐, 이봐!\n일대일로 도전할게.\n용기 있으면 빨리 와!')
        stage.unit(81).setDir(stage.countDir(81, 0))
        stage.say('&81\n아, 주지사님과 간 장군님이 모두 전투에 나갔다고?\n그럼 나는 조나라 군대와 정면으로 맞서야 육손!\n&81\n간 장군님, 죄송합니다.\n육손 앞장서게 해.\n나 여기 있어, 조조!')
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(79).setDir(stage.countDir(79, 0))
        stage.say('&79\n주군, 정말 이걸 할 거야?\n이건 농담이 아니에요!\n&76\n좋아, 우리 오나라는 항상 해전에서 뛰어나다고 자랑해왔다,\n병사들이 싸우려는 의지는 이해할 만했다.\n(하지만 다시 생각해보면, 왜 공진조차도 ...... )')
        stage.unit(358).move(22, 7, 3)
        stage.unit(362).move(22, 8, 3)
        stage.unit(364).move(22, 9, 3)
        stage.unit(359).move(23, 7, 3)
        stage.unit(87).move(23, 8, 3)
        stage.unit(365).move(23, 9, 3)
        stage.unit(360).move(24, 7, 3)
        stage.unit(81).move(24, 8, 3)
        stage.unit(366).move(24, 9, 3)
        stage.unit(361).move(25, 7, 3)
        stage.unit(363).move(25, 8, 3)
        stage.unit(367).move(25, 9, 3)
    elif sel == 2:
        stage.say('&0\n적군 아군 감히 공격하지 못하고 부주의하다고 생각할지도 모른다,\n적이 우리를 쫓을 때 틈을 이용할 수 있어,\n중앙 구역을 기습으로 돌파해.\n&19\n하지만 중앙 지역을 빠르게 건널 수 없다면,\n너희는 적의 거대한 군대에 포위될 것이다,\n이 전술은 여전히 상당한 위험을 내포하고 있습니다......\n&0\n두려워할 게 아니야.\n필요한 건 빠르게 착륙할 방법을 찾는 것뿐이야.')
        stage.unit(4, 1).move(14, 10, 2)
        stage.unit(2, 1).move(15, 10, 2)
        stage.unit(3, 1).move(16, 10, 2)
        stage.unit(5, 1).move(17, 10, 2)
        stage.unit(6, 1).move(14, 9, 2)
        stage.unit(0, 1).move(15, 9, 2)
        stage.unit(1, 1).move(16, 9, 2)
        stage.unit(7, 1).move(17, 9, 2)
        stage.unit(10, 1).move(14, 8, 2)
        stage.unit(8, 1).move(15, 8, 2)
        stage.unit(9, 1).move(16, 8, 2)
        stage.unit(11, 1).move(17, 8, 2)
        stage.unit(14, 1).move(14, 7, 2)
        stage.unit(12, 1).move(15, 7, 2)
        stage.unit(13, 1).move(16, 7, 2)
        stage.unit(81).setDir(stage.countDir(81, 0))
        stage.unit(87).setDir(stage.countDir(87, 0))
        stage.unit(86).setDir(stage.countDir(86, 0))
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&81\n흠, 조의 군대가 움직이기 시작했나?\n어디로 갈 계획이야?\n&87\n정면으로 돌파할 계획인 것 같다.\n그들이 미친 걸까요?\n&86\n따라잡아!\n&77\n(조조 공명 맞서게 하려면,\n원래는 언제 물러나야 할지 알기를 바랐다.\n하지만 죽을 때까지 싸우조조 건 골치 아플 거야. )\n&77\n(상황을 좀 더 관찰해야 할까?) )\n&77\n끝이 가까워진 것을 아는 야생 늑대,\n그는 묘지를 찾기 위해 방황하고 있었다.\n하늘이 당신에게 긴 생명을 축복하길!')
        stage.unit(4, 1).move(14, 15, 2)
        stage.unit(2, 1).move(15, 15, 2)
        stage.unit(3, 1).move(16, 15, 2)
        stage.unit(5, 1).move(17, 15, 2)
        stage.unit(6, 1).move(14, 14, 2)
        stage.unit(0, 1).move(15, 14, 2)
        stage.unit(1, 1).move(16, 14, 2)
        stage.unit(7, 1).move(17, 14, 2)
        stage.unit(10, 1).move(14, 13, 2)
        stage.unit(8, 1).move(15, 13, 2)
        stage.unit(9, 1).move(16, 13, 2)
        stage.unit(11, 1).move(17, 13, 2)
        stage.unit(14, 1).move(14, 12, 2)
        stage.unit(12, 1).move(15, 12, 2)
        stage.unit(13, 1).move(16, 12, 2)
        stage.unit(84).setDir(stage.countDir(84, 0))
        stage.unit(96).setDir(stage.countDir(96, 0))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&84\n여기 있나?\n군대 전체가 전투 준비 완료!\n&96\n주유, 왜 육손 움직이지 않는 거야?!\n&76\n육손! 주유! 뭐 하는 거야!\n빨리 저 녀석들 막아!\n&0\n이미 늦었어!\n모두 돌격!\n정면으로 돌파해서 저 손권의 목을 가져가라!\n&81\n아-아, 안 돼.\n&77\n이제 나도 모습을 드러낼 때가 됐어.\n나는 조조 붉은 절벽 전투를 다시 경험하고 싶다,\n맹렬한 불길에 타 죽은 군대의 끔찍한 광경.')
        stage.unit(86).setAI(1)
        stage.unit(77).setAI(1)
        stage.unit(96).setAI(1)
        stage.unit(84).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        stage.unit(371).setAI(1)
        stage.unit(372).setAI(1)
        stage.unit(373).setAI(1)
        stage.unit(374).setAI(1)
        stage.unit(375).setAI(1)
        stage.unit(376).setAI(1)
        stage.unit(377).setAI(1)
        stage.unit(378).setAI(1)
        stage.unit(379).setAI(1)
        stage.unit(380).setAI(1)
        stage.unit(381).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(312).setAI(1)
        stage.unit(313).setAI(1)
        stage.unit(298).setAI(1)
        stage.unit(299).setAI(1)
        vars[2] = 1
    stage.bgSound(10)
    stage.setWinCondition('승리 조건\n1. 손권 패배.\n\n패배 조건\n1. 후퇴조조.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('손권를 이겨라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[549] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 23, 28):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 24, 28):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 23, 27):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 24, 27):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 14, 28):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 14, 33):
        stage.getItem(151, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 7, 33):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 4, 24):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if not vars[2] and not vars[6] and stage.totalRectUnit(2, 8, 0, 31, 13) < 4:
        if not vars[52]:
            stage.unit(86).setDir(stage.countDir(86, 0))
            stage.say('&86\n배신자 조, 감히 운을 무리하다니!')
        if not vars[55]:
            stage.unit(77).setDir(stage.countDir(77, 0))
            stage.say('&77\n조조, 물 위에 있는 네 얼굴 좀 봐.\n두려움에 뒤틀린 네 죽음을 봐!')
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 0))
                stage.say('&76\n조조This 녀석 진짜 골칫거리야.\n흠, 공진이 싸우러 나갔나?\n이제 공진의 진심이 보여.')
        stage.unit(77).setAI(1)
        stage.unit(86).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        stage.unit(371).setAI(1)
        stage.unit(372).setAI(1)
        stage.unit(373).setAI(1)
        stage.unit(374).setAI(1)
        stage.unit(375).setAI(1)
        stage.unit(376).setAI(1)
        stage.unit(377).setAI(1)
        vars[6] = 1
    if vars[6] and not vars[2] and not vars[7] and stage.totalRectUnit(2, 0, 0, 31, 13) < 4:
        stage.unit(84).setAI(1)
        stage.unit(96).setAI(1)
        stage.unit(378).setAI(1)
        stage.unit(379).setAI(1)
        stage.unit(380).setAI(1)
        stage.unit(381).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(312).setAI(1)
        stage.unit(313).setAI(1)
        stage.unit(298).setAI(1)
        stage.unit(299).setAI(1)
        if not vars[53]:
            stage.unit(96).setDir(stage.countDir(96, 0))
            stage.say('&96\n음, 제 유료 군대가 실제로 억제당했네요.')
        if not vars[64]:
            stage.unit(84).setDir(stage.countDir(84, 0))
            stage.say('&84\n헤헤,\n나는 그렇게 쉽게 다루지 않아.\n포기하는 게 좋을 거야!')
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 0))
                stage.say('&76\n감녕, 수고 감사합니다!\n동부 오나라 군대가 무엇을 할 수 있는지 보여라!')
        vars[7] = 1
    if not vars[2] and not vars[8] and not vars[50] and stage.totalRectUnit(2, 0, 0, 31, 20) < 3:
        stage.resumeCtrl()
        if not vars[56]:
            stage.unit(79).setDir(stage.countDir(79, 0))
            stage.say('&79\n아군 확실히 조금 부주의했어,\n그러나 해군은 결국 패배하고 한 걸음씩 후퇴했다.\n정말 상상할 수 없는 일입니다.')
        if not vars[61]:
            stage.unit(88).setDir(stage.countDir(88, 76))
            stage.say('&88\n이제 해전이 패배했으니, 육상 전투는 매우 불리할 것이다.\n힘을 보존하기 위해 지금은 철수하는 것이 나았다.')
        if not vars[50]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.unit(76).setAction(5)
            stage.say('&76\n예상치 못하게 트롤들은 패배했다......\n이 시점에서 후퇴만이 유일한 선택지였다.\n공진에게 물어보고 싶은 게 아직 있어!')
            stage.unit(76).setAction(0)
        stage.setRectUnitHide(0, 0, 31, 39, 2)
        vars[8] = 1
        stage.say('&0\n흠, 차분하고 침착하네.\n진정으로 손중모우가 될 자격이 있다.\n아마도 다음 전투를 위해 힘을 아끼기 위한 것일까요?')
        if not vars[65]:
            stage.unit(19).setDir(2)
            stage.say('&19\n주군, 저 주홍색 제단은 뭐야?')
            stage.heightLight(20, 36, 21, 36)
            stage.unit(0).setDir(2)
            stage.say('&0\n이런 건 처음 봤어요......\n중달, 가서 조사해.\n&19\n네!')
        else:
            stage.unit(0).setDir(2)
            stage.say('&0\n응? 저게 뭐야?\n&0\n나는 이전 붉은 절벽 전투를 본 적이 없다,\n제단처럼 보여.\n누군가 빨리 그 제단을 조사해!')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[649] = 1
        return True
    if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 11, 24, 31, 39):
        if not vars[56]:
            stage.unit(79).setDir(stage.countDir(79, 76))
            stage.say('&79\n적이 점차 아군에 접근하고 있습니다.\n명령을 내릴 때가 된 것 같았다.')
        if not vars[50]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.unit(76).setAction(5)
            stage.say('&76\n이것이 결정적인 순간이다.\n적이 가까이 오지 못하게 해!')
            stage.unit(76).setAction(0)
        if not vars[57]:
            stage.say('&88\n방어를 강화하세요!\n주군를 지켜줘!')
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(218).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        stage.unit(78).setAI(1)
        stage.unit(82).setAI(1)
        stage.unit(92).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(220).setAI(1)
        stage.unit(240).setAI(1)
        vars[30] = 1
    if not vars[31] and stage.isInRect(1025, 19, 24, 27, 31):
        stage.setAI(0, 0, 31, 39, 2, 1)
        stage.unit(76).setAI(0)
        stage.unit(79).setAI(0)
        stage.unit(88).setAI(0)
        stage.unit(350).setAI(0)
        vars[2] = 1
        vars[31] = 1
    if not vars[2] and not vars[6] and not vars[32] and stage.isInRect(1025, 0, 0, 7, 15):
        if not vars[52]:
            stage.unit(86).setDir(stage.countDir(86, 0))
            stage.say('&86\n젠장, 조의 군대가 나한테 오는 거야?\n실력에 기반한 일대일 대결을 하자.\n그냥 크게 말하지 마!')
        if not vars[55]:
            stage.unit(77).setDir(stage.countDir(77, 0))
            stage.say('&77\n이제 나는 중대한 죄를 주유,\n조조와 함께 죽을 각오가 되어 있다.\n내 주유 인생의 마지막 빛나는 순간을 보여줘!')
        stage.unit(84).setAI(1)
        stage.unit(96).setAI(1)
        stage.unit(378).setAI(1)
        stage.unit(379).setAI(1)
        stage.unit(380).setAI(1)
        stage.unit(381).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(312).setAI(1)
        stage.unit(313).setAI(1)
        stage.unit(298).setAI(1)
        stage.unit(299).setAI(1)
        if not vars[53]:
            stage.unit(96).setDir(stage.countDir(96, 0))
            stage.say('&96\n경쟁하러 오는 게 무서워?\n그럼 내가 전투에 나가겠다!')
        if not vars[64]:
            stage.unit(84).setDir(stage.countDir(84, 0))
            stage.say('&84\n오 오 오!\n조조 이 늙은 도둑이 약속을 지키지 않으면,\n그는 진짜 남자가 아니야!')
        stage.unit(77).setAI(1)
        stage.unit(86).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        stage.unit(371).setAI(1)
        stage.unit(372).setAI(1)
        stage.unit(373).setAI(1)
        stage.unit(374).setAI(1)
        stage.unit(375).setAI(1)
        stage.unit(376).setAI(1)
        stage.unit(377).setAI(1)
        vars[2] = 1
        vars[32] = 1
    if not vars[2] and not vars[7] and not vars[33] and stage.isInRect(1025, 0, 16, 31, 39):
        if not vars[53]:
            stage.unit(96).setDir(stage.countDir(96, 0))
            stage.say('&96\n경쟁하러 오는 게 무서워?\n그럼 내가 전투에 나가겠다!')
        if not vars[64]:
            stage.unit(84).setDir(stage.countDir(84, 0))
            stage.say('&84\n오 오 오!\n조조 이 늙은 도둑이 약속을 지키지 않으면,\n그는 진짜 남자가 아니야!')
        stage.unit(77).setAI(1)
        stage.unit(86).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        stage.unit(371).setAI(1)
        stage.unit(372).setAI(1)
        stage.unit(373).setAI(1)
        stage.unit(374).setAI(1)
        stage.unit(375).setAI(1)
        stage.unit(376).setAI(1)
        stage.unit(377).setAI(1)
        if not vars[6]:
            if not vars[52]:
                stage.unit(86).setDir(stage.countDir(86, 0))
                stage.say('&86\n거짓말을 가장 좋아해요.\n좋아! 나도 싸울게!')
            if not vars[55]:
                stage.unit(77).setDir(stage.countDir(77, 0))
                stage.say('&77\n그들은 실제로 속임수와 허세로 우리를 배신했다......\n이것은 진정한 남자가 해서는 안 될 행동입니다.')
            stage.unit(84).setAI(1)
            stage.unit(96).setAI(1)
            stage.unit(378).setAI(1)
            stage.unit(379).setAI(1)
            stage.unit(380).setAI(1)
            stage.unit(381).setAI(1)
            stage.unit(310).setAI(1)
            stage.unit(311).setAI(1)
            stage.unit(312).setAI(1)
            stage.unit(313).setAI(1)
            stage.unit(298).setAI(1)
            stage.unit(299).setAI(1)
        vars[2] = 1
        vars[32] = 1
    if not vars[40] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('동오 수군의 군용은 확실히 강하군. 하지만 너를 죽이기만 하면, 수군은 자연스레 와해될 거야. 손권, 네 목숨을 내놓아라!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 77, True):
        stage.unit(0).setDir(stage.countDir(0, 77))
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&0\n저우공진, 네 주군까지 속였잖아,\n공명와 힘을 합치면 무엇을 하고 싶으신가요?\n&77\n도대체 무슨 헛소리를 하는 거야?\n그런 주유 기억이 전혀 없어요.\n&0\n아무리 숨기려 해도 소용없어.\n도대체 무슨 계획공명 거야? 빨리 말해!\n&77\n조언 하나 해줄게.\n눈을 떼지 마공명,\n그렇지 않으면 끔찍한 일이 일어날 거야.\n&0\n도대체 무슨 말을 하려는 거죠!?\n&77\n나머지는 네가 스스로 조사해봐야 해,\n사실 네가 이렇게 그냥 떠나서 집으로 돌아갈 수 있길 바래.\n&0\n오나라 군대를 물리칠 때까지 돌아오지 않을 것이다.\n&77\n그럼 나는 너를 막기 위해 온 힘을 다할 수밖에 없어!')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 81, True):
        stage.unit(81).setDir(stage.countDir(81, 0))
        stage.unit(0).setDir(stage.countDir(0, 81))
        stage.say('&81\n그래서 조조였어! 나는 육손, 보얀이라는 이름이야.\n지금이 정기 훈련 결과를 확인할 완벽한 시기입니다!\n죽을 준비를 해라!\n&0\n흠, 당신의 정신은 칭찬받을 만합니다.\n하지만 정신만으로는 이길 수 없어!')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        if stage.totalUnit(2) >= 20:
            stage.say('&76\n다른 방법은 없었다.\n전군을 후퇴시켜라!')
            stage.unit(76).hide()
            if not vars[57]:
                stage.say('&88\n주님, 주군!\n음, 후퇴, 후퇴!')
                stage.unit(88).hide()
            if not vars[56]:
                stage.say('&79\n부상자를 철수시키고 철수하라!\n여러분, 당황하지 말고 침착하게 후퇴하세요.')
                stage.unit(79).hide()
            stage.setRectUnitHide(0, 0, 31, 39, 2)
            stage.say('&0\n흠, 차분하고 침착하네.\n진정으로 손중모우가 될 자격이 있다.\n아마도 다음 전투를 위해 힘을 아끼기 위한 것일까요?')
        else:
            stage.say('&76\n다른 방법은 없었다.\n전군을 후퇴시켜라!')
            stage.unit(76).hide()
            if not vars[57]:
                stage.say('&88\n주님, 주군!\n음, 후퇴, 후퇴!')
                stage.unit(88).hide()
            if not vars[56]:
                stage.say('&79\n부상자를 철수시키고 철수하라!\n여러분, 당황하지 말고 침착하게 후퇴하세요.')
                stage.unit(79).hide()
            stage.setRectUnitHide(0, 0, 31, 39, 2)
            stage.say('&0\n아니, 도망쳤어!')
        vars[50] = 1
        if not vars[65]:
            stage.unit(19).setDir(2)
            stage.say('&19\n주군, 저 주홍색 제단은 뭐야?')
            stage.heightLight(20, 36, 21, 36)
            stage.unit(0).setDir(2)
            stage.say('&0\n이런 건 처음 봤어요......\n중달, 가서 조사해.\n&19\n네!')
        else:
            stage.unit(0).setDir(2)
            stage.say('&0\n응? 저게 뭐야?\n&0\n나는 이전 붉은 절벽 전투를 본 적이 없다,\n제단처럼 보여.\n누군가 빨리 그 제단을 조사해!')
        if vars[2]:
            stage.reward(0, [
                96,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[649] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n응.\n그들은 조조를 과소평가하고 있습니다.\n아직 나이가 안 된 것 같네, 후퇴!')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n음, 또 어떻게 졌어?\n후퇴!')
        stage.unit(86).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n흠, 왜 우리는 조의 군대를 이길 수 없는 거지?\n후퇴!')
        stage.unit(96).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n흠, 군인이 너무 많네,\n왜 ...... 후퇴!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(77, 7, 0, 2):
        stage.say('&77\n음, 계산 착오, 후퇴!\n원래 공명 싸우고 싶어 했던 이들조조,\nUnexpectedly조조 그들은 우나라를 공격할 것이다......\n&77\n다음번에는 무슨 일이 있어도 반드시 반드시 맞서 싸울 방법을 찾아야 해,\n그렇지 않으면 인간 세계 전체가 어둠에 삼켜질 것이다.')
        stage.unit(77).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n오, 안 돼!\n손권주군, 쯔위가 먼저 떠났다.')
        stage.unit(79).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n그때 경솔하게 징저우를 공격해서는 안 됐다......\n지금은 우나라조차 붕괴 직전이다.\n무슨 일이 있어도 방법을 찾아야 해...... 일단 후퇴하자!')
        stage.unit(88).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n뭐 하는 거야!?\n아파, 물러서!')
        stage.unit(78).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n또 후퇴......\n정말 안타깝네요.')
        stage.unit(85).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n아니야, 정말 비극적이야.\n이제 그는 주군 앞에 물러설 수밖에 없었다.\n분명히 안 좋은 인상을 남길 거예요!')
        stage.unit(83).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n너—너 정말 대단하다!\n흠, 더는 못 참겠어.\n후퇴, 후퇴!')
        stage.unit(92).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n36가지 전략 중에서 도망치는 것이 가장 좋은 전략이다.\n후퇴, 후퇴!')
        stage.unit(87).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(80, 7, 0, 2):
        stage.say('&80\n"어리석은 용기는 진정한 용기가 아니다."\n내가 지금 물러난 게 아니야,\n내 여몽을 과소평가해도 돼!')
        stage.unit(80).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n쳇, 어떻게 그가 패배할 수 있지?\n다른 선택지가 없으니 다시 돌아갈 수밖에 없었다!')
        stage.unit(84).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(19, 7, 0, 2):
        vars[65] = 1
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n흠, 차분하고 침착하네.\n진정으로 손중모우가 될 자격이 있다.\n아마도 다음 전투를 위해 힘을 아끼기 위한 것일까요?')
        if not vars[65]:
            stage.unit(19).setDir(2)
            stage.say('&19\n주군, 저 주홍색 제단은 뭐야?')
            stage.heightLight(20, 36, 21, 36)
            stage.unit(0).setDir(2)
            stage.say('&0\n이런 건 처음 봤어요......\n중달, 가서 조사해.\n&19\n네!')
        else:
            stage.unit(0).setDir(2)
            stage.say('&0\n응? 저게 뭐야?\n&0\n나는 이전 붉은 절벽 전투를 본 적이 없다,\n제단처럼 보여.\n누군가 빨리 그 제단을 조사해!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[649] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
