# Source Generated with Decompyle++
# File: R_02.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            127,
            32,
            55,
            1],
        [
            132,
            50,
            40,
            2],
        [
            119,
            58,
            40,
            2],
        [
            192,
            50,
            70],
        [
            193,
            58,
            70],
        [
            181,
            50,
            55,
            3,
            11]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('호라오 고개에서 결정적인 전투가 벌어졌다')
    stage.setStageName('뤄양, 총리 관저')
    stage.unit(127).setAction(3)
    stage.say('&127\n뭐라고!! 네가 죽었다고 했화웅!?')
    stage.unit(127).setAction(0)
    stage.say('&181\n네, 이제 연합군이 낙양을 향해 진격하기 시작했습니다.')
    stage.say('&127\n흥.......')
    stage.unit(132).setAction(6)
    stage.say('&132\n이런 점을 고려할 때, 현재 계획은 .........\n적을 격파할 수 있는 것은 오직 후라오 관개뿐이었다.')
    stage.unit(132).setAction(0)
    stage.say('&127\n흠.......')
    stage.unit(127).setAction(17)
    stage.say('&127\n여포, 네 차례야.\n호라오 고개를 죽을 때까지 지켜야 해!')
    stage.unit(127).setAction(0)
    stage.delay(5)
    stage.say('&119\n네!')
    stage.unit(127).setAction(3)
    stage.say('&127\n나도 네 무술 실력도 보러 갈게.')
    stage.unit(127).setAction(0)
    stage.say('&119\n안심하세요.')
    stage.unit(119).setAction(17)
    stage.say('&119\n조조, 원소, 너희 둘이 진짜 뭘 할 수 있는지 보고 싶어!')
    stage.unit(119).setAction(0)
    stage.delay(3)
    stage.unit(119).move(61, 40, 1)
    stage.unit(119).move(61, 55, 2)
    stage.unit(119).move(91, 55, 1)
    stage.unit(119).hide()
    stage.delay(5)
    stage.say('&127\n내 동탁들은 모두 내 지휘 아래 용감한 장군들이다.')
    stage.unit(127).setAction(17)
    stage.say('&127\n리루! 출발 준비해!')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(132).setAction(6)
    stage.say('&132\n네!')
    stage.unit(132).setAction(0)
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            101,
            54,
            37,
            2],
        [
            0,
            48,
            45,
            2],
        [
            145,
            42,
            52,
            1],
        [
            136,
            42,
            60,
            1],
        [
            161,
            67,
            52,
            3],
        [
            32,
            67,
            60,
            3]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('뤄양 외곽, 연합군 본진')
    stage.unit(101).setAction(3)
    stage.say('&101\n모두가 뛰어난 성과를 냈습니다,\n기세를 타고 한 번에 낙양을 탈환합시다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(136).setAction(3)
    stage.say('&136\nnow동탁 우리가 얼마나 강한지 알겠지?\n헤헤.')
    stage.unit(136).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n이러한 낙관론은 아직도 너무 이른 시기일 것입니다.')
    stage.unit(0).setAction(0)
    stage.say('&136\n응? 왜?')
    stage.unit(0).setAction(6)
    stage.say('동탁이 여포를 아직 출전시키지 않았어. 여포가 우리 곁에 있으면……')
    stage.unit(0).setAction(0)
    stage.say('&101\n......여포? 네...\n그의 무술 실력은 화웅보다 수백 배는 뛰어났다.')
    stage.unit(136).setAction(3)
    stage.say('&136\n여포 사람들은 산속 평민일 뿐이야,\n정말 그가 그렇게 무서워?')
    stage.unit(136).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n그렇다면 강력한 주님께서 원술하라,\n회의에 가는 것은 문제여포 없습니다.')
    stage.unit(0).setAction(0)
    stage.say('&136\n흥!')
    stage.delay(5)
    stage.unit(136).setAction(2)
    stage.say('&136\n그래도 시골 촌뜨기들을 상대해야 했던 건 시골 촌뜨기였다.')
    stage.unit(136).setAction(0)
    stage.delay(3)
    stage.unit(136).setAction(0, 2)
    stage.say('&136\n그런데 그건 그냥 두손견.......')
    stage.unit(136).setAction(3)
    stage.say('&136\n헤헤.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n……。')
    stage.unit(32).setAction(6)
    if vars[701]:
        stage.say('&32\n그런데 손 장군이 무사히 도망쳤는지 궁금하네요.')
        stage.unit(32).setAction(0)
        stage.delay(3)
        stage.unit(136).setAction(0, 1)
        stage.say('&136\n불가능해.\n이런 때에, 나는 그가 확실히 죽었다고 생각해.')
    if not vars[701]:
        stage.say('&32\n손 장군은 오랫동안 도착하지 않았다,\n무슨 일이 있었던 걸까?')
        stage.unit(32).setAction(0)
        stage.delay(3)
        stage.unit(136).setAction(0, 1)
        stage.say('&136\n아마도 패배를 당했기 때문일 것이다,\n이 사람은 아마 지금쯤 죽었을 거야!')
    stage.unit(136).setAction(3, 1)
    stage.say('&136\n헤헤헤.')
    stage.unit(136).setAction(0, 1)
    stage.say('&99\n아직 살아 있어.')
    stage.unit(136).setAction(3, 1)
    stage.say('&136\n아!')
    stage.unit(136).setAction(0, 2)
    stage.unit(0).setAction(0, 2)
    stage.unit(145).setAction(0, 2)
    stage.unit(143).setAction(0, 2)
    stage.unit(161).setAction(0, 2)
    stage.unit(32).setAction(0, 2)
    stage.showUnit(99, 54, 94)
    stage.unit(99).move(54, 60, 0)
    stage.unit(32).setAction(0, 3)
    stage.unit(136).setAction(0, 1)
    stage.unit(145).setAction(0, 1)
    stage.unit(143).setAction(0, 3)
    stage.unit(161).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n오, 손 장군님!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(3)
    stage.say('&32\n괜찮아?')
    stage.unit(32).setAction(0)
    stage.delay(5)
    stage.unit(99).setAction(0, 2)
    stage.say('&99\n…… 조 공!')
    stage.unit(0).setAction(6)
    stage.say('&0\n어떻게?')
    stage.unit(99).setAction(0, 0)
    stage.say('&99\n곡물을 공급할 책임은 누구인가요?\n혹시 너와 원소님일까?')
    stage.say('&136\n아니야.')
    stage.unit(0).setAction(0)
    stage.say('&0\n이건... 모든 보급품은 고속도로에서 관리해.')
    stage.unit(99).setAction(0, 2)
    stage.say('&99\n예상대로.......')
    stage.unit(99).move(50, 60, 3)
    stage.delay(3)
    stage.unit(99).setAction(2)
    stage.say('&99\n원술! 정말 너구나!\n&99\n지난 군사 회의에서 너는 나를 미워했지,\n그가 나를 해치려는 의도를 품었어!')
    stage.unit(145).setAction(0, 2)
    stage.say('&99\n저는 연합군 소속입니다,\n어떻게 감히 식량 공급을 중단할 수 있어!\n이 자식아!')
    stage.unit(99).setAction(2)
    stage.say('&99\n오늘은 널 죽일 거야!')
    stage.unit(136).move(36, 60, 1)
    stage.unit(136).setAction(3)
    stage.say('&136\n아, 잠깐만요, 오해입니다!')
    stage.unit(136).setAction(0)
    stage.unit(99).move(44, 60, 3)
    stage.delay(3)
    stage.unit(99).setAction(2)
    stage.say('&99\n네 설명은 듣지 않을게, 단지 네 때문에,\n나는 수많은 충성스럽고 용감한 부하들을 잃었다.\n&99\n나는 내 부하들을 네 피로 희생하겠다.')
    stage.unit(136).setAction(9)
    stage.say('&136\n아, 이건 다 내 부하 스스로 결정한 거야.')
    stage.unit(99).setAction(0)
    stage.say('&136\n곧 네 캠프로 데려갈게!\n네가 하고 싶은 대로 해도 돼, 하지만 화내지 마!')
    stage.unit(99).setAction(2)
    stage.say('&99\n그는 실제로 책임을 부하들에게 전가했다!\n당신은 군대의 장군으로 간주되나요!?\n내 목숨을 줘!!')
    stage.unit(32).setAction(6)
    stage.say('&32\n손 장군님, 당신의 기분을 이해합니다,\n하지만 동탁군과의 결정적인 전투가 임박했다,\n지금은 참아주시기 바랍니다.')
    stage.unit(99).setAction(2, 1)
    stage.say('&99\n설득하려 하지 마, 막지 마!')
    stage.unit(32).setAction(0)
    stage.delay(5)
    stage.unit(0).setAction(6)
    stage.say('&0\n손 장군님, 이렇게 하시면......\n쓰러진 부하들도 마음이 아플 것이다.')
    stage.unit(99).setAction(2, 0)
    stage.say('&99\n그게 무슨 뜻이야?')
    stage.unit(0).setAction(0)
    stage.say('&0\n지금 원술를 죽이면 연합군이 무너질 거야,\n네 부하들은 헛되이 죽을 거야.')
    stage.unit(0).setAction(6)
    stage.say('&0\n정말 이걸 할 생각이야!?')
    stage.delay(5)
    stage.unit(99).setAction(0)
    stage.say('&99\n…… 흠!')
    stage.delay(10)
    stage.unit(99).setAction(0, 2)
    stage.say('&99\n…… 알겠어, 일단 참을게.')
    stage.unit(0).setAction(0)
    stage.delay(8)
    stage.unit(99).setAction(0, 3)
    stage.say('&99\n원술, 내가 동탁를 제거하면,\n그럼 와서 네 개 머리를 가져가.')
    stage.unit(136).setAction(1)
    stage.say('&136\n쉭!')
    stage.say('&0\n…….(부하들이 이렇게 분개하는 것을 보니,\n손견은 정말 대단한 인물이로군…….)')
    stage.unit(101).setAction(3)
    stage.say('&101\n좋아, 모두 자리에 앉아.\n대전투가 코앞에 있었다.')
    stage.unit(101).setAction(0)
    stage.delay(5)
    stage.unit(99).setAction(0, 0)
    stage.say('&99\n…… 좋아.')
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(99),
            42,
            68,
            1],
        [
            stage.unit(136),
            42,
            60,
            1]])
    stage.unit(145).setAction(0, 1)
    stage.delay(3)
    stage.unit(101).setAction(3)
    stage.say('&101\n조조, 다가오는 전투를 소개해 주시겠습니까?')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n네.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n……우선 동탁 군대의 움직임을 설명해 드리겠습니다.\n&0\n낙양에는 두 개의 관문이 있어 요충지 역할을 하는데,\n지금 사수관은 우리가 점령했으니,\n동탁은 반드시 호로관에 모든 병력을 집결시킬 겁니다!')
    stage.unit(0).setAction(17)
    stage.say('&0\n훌라오 고개는 아군와 동탁의 전쟁터였다.')
    stage.unit(0).setAction(0)
    stage.say('&101\n적이 워낙 강력하니까......')
    stage.unit(101).setAction(3)
    stage.say('&101\n도군님, 이번에도 전투에 참여하세요.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(145).setAction(6)
    stage.say('&145\n좋아.')
    stage.unit(145).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n좋아, 모두 캠프로 돌아가 출발 준비를 해.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            66],
        [
            1,
            39,
            52,
            1],
        [
            5,
            39,
            46,
            1],
        [
            10,
            39,
            40,
            1],
        [
            6,
            60,
            52,
            3],
        [
            12,
            60,
            46,
            3],
        [
            11,
            60,
            40,
            3]])
    stage.draw()
    stage.delay(3)
    stage.setStageName('시수이 고개조조 본캠프')
    stage.say('동탁은 분명 호로관에 중병을 집결시켰고, 게다가 여포도 반드시 출전할 거야. 이번 전쟁은 틀림없이 참혹할 테니, 모두들 마음을 다해 준비해야 해.')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 7, [
        1])
    gvars[4076] = 0
    gvars[4057] = 2
    stage.setBattlePos([
        [
            17,
            9],
        [
            16,
            8],
        [
            16,
            11],
        [
            16,
            9],
        [
            16,
            10],
        [
            17,
            8],
        [
            17,
            11],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n원술That 녀석 진짜 끔찍해!"')
    if stage.unitClickTest(6):
        stage.say('&6\n기병은 보병보다 강하지만 궁수보다는 약하다,\n보병은 궁수보다 강하지만 기병보다는 약합니다.......\n&0\n하후연, 군사 전략을 검토하는 거야?\n&6\n응, 정말 기억하기 힘들어...... 생각해볼게...\n어떤 궁수가 기병보다 강한가요?\n하지만 보병보다는 약하죠......')
    if stage.unitClickTest(5):
        stage.say('&5\n동탁That 남자는 특별한 게 없어.\n&0\n이봐, 쯔샤오, 부주의하면 안 돼.')
    if stage.unitClickTest(12):
        stage.say("&12\n그리고 곧 싸울 여포,\n아이템 가게에 가서 '회복 콩'을 사는 게 낫다.")
    if stage.unitClickTest(10):
        stage.say('&10\n여포 시량 기병이었던 걸로 기억해요.\n&10\n공격과 수비 모두 정말 훌륭합니다,\n대각선으로도 공격할 수 있어...\n한숨, 정말 강력한 상대군.')
    if stage.unitClickTest(11):
        stage.say("&11\n여포의 탈것이 '붉은 토끼 말'이라고 불린다고 들었어,\n적군 옆에서도 자유롭게 움직일 수 있습니다.\n&11\n그리고 평소의 '팡톈화지'도 들었다\n한 적군을 물리친 후에는 다른 적을 공격할 수 있습니다.\n&1\n이봐, 이봐, 이건 말도 안 돼!\n사실상 파울링의 특권과 같아요!")
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
