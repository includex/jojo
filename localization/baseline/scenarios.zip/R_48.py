# Source Generated with Decompyle++
# File: R_48.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(13)
    stage.delay(3)
    stage.loadBg(2, 67)
    stage.showUnit(33, 44, 37, 3, 10)
    stage.draw()
    stage.setEventName('관우 조나라에게 항복했다')
    stage.setStageName('마이청 외곽의 산길')
    stage.showUnit(3, 48, 95, 1)
    stage.unit(3).move(48, 80, 0)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 3)
    stage.delay(8)
    stage.unit(3).setAction(0, 1)
    stage.say('&3\n셋째 형님!\n관평!\n어디야!?')
    stage.delay(5)
    stage.unit(3).setAction(0, 0)
    stage.say('&3\n…… 아!')
    stage.unit(3).move(48, 41, 0)
    stage.unit(3).move(44, 41, 0)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(3)
    stage.say('&3\n…… 셋째 형님!\n기운 내......!')
    stage.unit(3).setAction(0)
    stage.say('&33\n…… 음, 음?\n둘째, 둘째 형님?\n죄송합니다...... 징저우가 졌......\n&33\n장나라의 병사들은 ......를 배신하고 동오로 망명했다......\n&33\n젠장, 그냥 놔둘 수 없어!\n…… 음-음 ......!')
    stage.unit(3).setAction(3)
    stage.say('&3\n셋째 형, 정신 차려야 해!')
    stage.unit(3).setAction(0)
    stage.say('&33\n…… 형은 어디 있지?\n&3\n…… 아, 아.\n걱정할 필요 없어......\n그들은 이미 안전하게 바이디 시로 후퇴했다.\n&33\n그래?\n…… 좋네요.\n마이청에서 죽을 때까지 버텨낸 것이 마침내 결실을 맺었다......\n&33\n…… 이렇게......\n우리 셋이 다시 같이 술 마시자......\n&33\n………………')
    stage.delay(10)
    stage.unit(3).setAction(9)
    stage.say('&3\n…… 셋째 형님?\n셋째 형제!!\n일어나, 정신 차려!')
    stage.unit(3).setAction(7)
    stage.say('&3\n셋째 형제!!')
    stage.delay(10)
    stage.unit(3).setAction(9)
    stage.showUnit(46, 54, 5, 2)
    stage.unit(46).move(54, 24, 2)
    stage.unit(46).setAction(0)
    stage.delay(8)
    stage.say('&46\n…… 아버지.')
    stage.delay(5)
    stage.effectSound(38, 1)
    stage.unit(46).setAction(10)
    stage.delay(5)
    stage.unit(3).setAction(0)
    stage.say('&3\n핑얼!')
    stage.unit(3).move(48, 41, 1)
    stage.unit(3).move(48, 24, 1)
    stage.say('&46\n음, 음......')
    stage.unit(3).setAction(3)
    stage.say('&3\n핑얼, 버텨!')
    stage.unit(3).setAction(0)
    stage.say('&46\n…… 아버지, 아버지, 괜찮으세요......\n&3\n아버지로서 저는 괜찮고, 동무군도 격퇴되었습니다.\n걱정 마세요!')
    stage.unit(3).setAction(3)
    stage.say('&3\n핑얼, 정확히 무슨 일이 있었던 거야?\n네가 그렇게 쉽게 패배할 거라고는 믿지 않아!')
    stage.unit(3).setAction(0)
    stage.say('&46\n…… 우리는 오군의 접근 소식을 들었습니다,\n소년과 그의 형제들은 장링성을 탈출해 적과 맞섰다.')
    stage.say('&46\n우리가 오나라 선봉대와 싸웠을 때......')
    stage.delay(5)
    stage.say('&46\n장릉의 성문은 활짝 열려 있었고,\n도시 안의 기병대가 뒤에서 공격하고 있어!')
    stage.delay(5)
    stage.say('&46\n게다가...... 우리 징저우 군을 이끄는 자는 주유다!')
    stage.unit(3).setAction(2)
    stage.say('&3\n뭐라고!?\n왜 징저우 군대는 주유......의 명령을 따르는가?\n징저우 군대가 우나라에 배신하고 항복한 것일까?')
    stage.unit(3).setAction(0)
    stage.say('&46\n…… 단순한 배신은 아닌 것 같다,\n아이는 또한 놀라운 소식을 들었습니다.')
    stage.delay(10)
    stage.say('&46\n반군은 전략가의 명령을 따르고 있다고 말했다......')
    stage.unit(3).setAction(2)
    stage.say('&3\n전략가의 명령...... 있나?\n혹시 내 형이 맞는 걸까...... 음!\n&46\n…… 아군 대패하고 포위 공격을 받으며 도망쳤다,\n마침내 그들은 마이청으로 탈출했다.\n&46\n장릉성 안에 남은 유비주군,\n그는 또한 장비 장군의 보호 아래 탈출했다.')
    stage.delay(5)
    stage.say('&46\nFather......주군 괜찮아?"')
    stage.unit(3).setAction(0)
    stage.say('&3\n…… 응? 형은 괜찮아.\n&46\n…… 정말?\n그렇다면 형제들의 죽음은 그만한 가치가 있었다.')
    stage.unit(3).setAction(6)
    stage.say('&3\n뭐라고 했어?\n다 죽었어!?\n&46\n아버지...... 아이는 진심으로 행복해,\n그는 실제로 아버지 곁에서 죽는 데 성공했다......')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.say('&3\n핑얼, 뭐라고 했어?\n헛소리 하지 마,\n우리는 살아남아야 해!!')
    stage.delay(5)
    stage.say('&46\n…………………')
    stage.unit(3).setAction(0)
    stage.delay(5)
    stage.unit(3).setAction(9)
    stage.say('&3\n핑얼, 오 핑얼......\n&3\n나관우...... 꼭 ......\n우리는 이 혈연 원한을 반드시 복수해야 한다!')
    stage.delay(10)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(2)
    stage.say('&3\n주유!!\n공명!!\n내 손으로 널 죽일 거야!!')
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('향양 조조 본군')
    stage.showUnit(181, 54, 22, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 관우 장군이 도착했습니다.\n&0\n흠, 부탁해요.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.delay(10)
    stage.showUnit(3, 54, 22, 2)
    stage.say('&3\n총리님께 경의를 표하러 왔다.')
    stage.unit(3).move(54, 64, 2)
    stage.say('관우, 별일 없었느냐.')
    stage.unit(3).setAction(6)
    stage.say('&3\n네.\n구원에 나와 주신 총리님께 감사드립니다.\n관은 깊이 감사했다.\n&0\n흠.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n……유비가 돌아가셨다고 들었습니다.\n&3\n예. \n&3\n셋째 동생과 나의 세 아들도 모두 오나라 군대의 손에 죽었소.')
    stage.delay(5)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n정말?\n그러니까 슈를 붙잡을 게 아무것도 없겠지?')
    stage.unit(3).setAction(2)
    stage.say('&3\n왜 총리가 이렇게 말하는가?\n&0\n관우Ah, 너는 아군를 섬기네."')
    stage.delay(10)
    stage.unit(3).setAction(0)
    stage.say('&3\n총리 ......\n관의 노숙자 상황을 이용해 몰래 들어갈 생각이야?')
    stage.say('&0\n네.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군!')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n주군, 이 일은 관장군에게 정말 너무 가혹한 일이야!')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n닥쳐!')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('...관우, 내가 생각해 볼 시간을 줄게. 네가 촉나라로 돌아가고 싶어도 좋고,\n내 부하가 되어도 좋아.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n생각해 보세요.')
    stage.unit(3).setAction(6)
    stage.say('&3\n…… 좋아, 나, 관, 이만 가겠다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).move(54, 30, 0)
    stage.say('&3\n(형님...... )')
    stage.unit(3).move(54, 22, 0)
    stage.unit(3).hide()
    stage.delay(5)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 왜 내가 관우에 대해 이렇게 말하냐고?')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(0, 2)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n저도 같은 생각이에요.\n왜 유비 경의 편지를 주군에게 가져가지 않는가,\n관장군에게 넘겨서 검토할까요?')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n물론 저는 이 접근법에 매우 익숙합니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('하지만 만약 관우가 신이 전한 말을 보고, 자신이 해야 할 일을 포기한다면, 비록 우리 편에 가담하더라도 아무 의미가 없습니다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 10)
    stage.showUnits([
        [
            77,
            70,
            55,
            3],
        [
            35,
            52,
            55,
            1]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.info('지금 이 순간에는......', 3)
    stage.setStageName('장링 주유 거주지')
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n......공명, 네 전략은 정말 훌륭해.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 2)
    stage.delay(3)
    stage.unit(77).setAction(17)
    stage.say('&77\n이제 유비와 장비의 생명이 성공적으로 끝났다.')
    stage.unit(77).setAction(0)
    stage.say('&77\n다음으로, 조조 문제를 다룰 차례입니다.')
    stage.unit(77).setAction(0, 3)
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n안타깝게도 그는 관우 생명을 끝낼 수 없었다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 2)
    stage.say('&35\nUnexpectedly조조 마이청을 구하러 달려갔다......')
    stage.unit(77).setAction(3)
    stage.say('&77\n관우 그가 혐오하는 조조 편에 선 걸까?')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n음, 이 문제는 아마도 이미 사실일 것이다.\n이제 우리 행동을 눈치챘을 거야.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 2)
    stage.delay(3)
    stage.unit(77).setAction(11)
    stage.say('&77\n관우Oh 관우, 이 혐오스러운 악당아,\n만약 정말 배신자 조조와 손을 잡으려 한다면,\n함께 동우에 도전할까요?\n&35\n주유, 위나라 군대가 어떤 행동을 하든,\n맹세를 어기면 안 된다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 3)
    stage.say('&77\n오직 완전한 아름다움만이 아름다움이라고 부를 수 있다,\n어떻게 주유 실패할 수 있겠어?\n마음 편하게 맡겨.\n&35\n흠.')
    stage.unit(35).move(5, 55, 3)
    stage.unit(35).hide()
    stage.delay(5)
    stage.say('&77\n흥! 공명.\n네가 날 통제하게 두지 않을 거야.')
    stage.unit(77).setAction(0, 2)
    stage.say('&77\n나는 이 전투에서 위를 이기지 않을 것이다.\n조조 하루라도 살아간다면,\n싸워야 조조.')
    stage.unit(77).setAction(3)
    stage.say('&77\n조만간 너는 모르는 사이에 죽음의 길을 걷게 될 것이다,\n엄숙한 애도 음악 속에서 쉬고 있다.')
    stage.unit(77).setAction(17)
    stage.say('&77\n세상을 정복한 사람은 너도 아니고 공명 조조도 아니야!\n결국 세상은 우리 동우의 손에 넘어갈 것이다.')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 12)
    stage.showUnits([
        [
            0,
            29,
            54,
            1],
        [
            20,
            50,
            41,
            2],
        [
            19,
            56,
            41,
            2],
        [
            23,
            62,
            41,
            2],
        [
            1,
            50,
            68],
        [
            17,
            56,
            68],
        [
            15,
            62,
            68]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('향양: 임시 총리 관저')
    stage.say('&0\n원양, 장링 공격 준비해.')
    stage.unit(1).setAction(0, 3)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n강링을 공격한다고?\n…… 알았어, 바로 준비할게.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(1).move(50, 74, 2)
    stage.unit(1).move(95, 74, 1)
    stage.unit(1).hide()
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군,\n공명와 주유가 힘을 합쳤는지는 아직 불확실하다.\n&20\n이 시기에 장릉에 대한 공격이 다소 성급했나요?')
    stage.unit(20).setAction(0)
    stage.say('&0\n문약, 걱정 마.')
    stage.showUnit(181, 90, 54, 3)
    stage.effectSound(201, 255)
    stage.bgSound(19)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 관우 장군이 도착했습니다.\n&0\n정말...... 그를 들여보내.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.showUnit(3, 95, 54, 3)
    stage.delay(10)
    stage.unit(3).move(48, 54, 3)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n총리님, 이미 고려해 봤습니다.\n결국 관은 아직 슈로 돌아갈 수 없다.\n&0\n슈가 공명 있어서 그런 걸까?')
    stage.unit(3).setAction(0)
    stage.say('&3\n그래, 슈의 진정한 힘은 공명의 손에 넘어갔다.')
    stage.unit(3).setAction(2)
    stage.say('&3\n공명 무정하고 불의롭다,\n그리고 주유와 공모해 형과 세 명의 남동생을 죽이려 했다,\n어떻게 다시 그곳에 갈 수 있겠어!')
    stage.unit(19).setAction(6)
    stage.say('&19\n(며칠 ago주군 나는 관우에게 냉정하게 대답했다,\n그래서 바로 그게 목적이에요! )')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n(공명와 주유은 혼란 속에서 결탁했다,\n이것은 부인할 수 없는 사실입니다. )')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n…… 총리님, 제가 꼭 모시게 해 주세요.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(3)
    stage.say('&3\n관은 죽은 자들의 맹세한 형제애를 완수해야 한다,\n그리고 관의 아들이 미래에 대한 희망을 가지고 있다.')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n……음, 네가 이런 말을 할 줄 알았어.\n관우, 앞으로는 내 휘하에서 마음껏 능력을 펼치거라.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n네, 감사합니다, 총리님.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\\n네, 강릉 공격!\\n서우와 위를 합작으로 무너뜨리겠습니다!')
    stage.bgSound(-1)
    model.unitJoin(3, 0, 3)
    if vars[1013]:
        gvars[0] = 3
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.setJoinEquip(3, 36, 0, 0, 0, 16)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 141, 97)
    stage.showHead(35, 77, 97)
    stage.bottomTxt('딩준산 전투에서,', False, False, False)
    stage.delay(5)
    stage.head(35).move(45, 158)
    stage.head(35).hide()
    stage.delay(5)
    stage.bottomTxt('서군은 이상한 방식으로 후퇴했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('이것이 끔찍한 음모의 시작이었다.', True, True, True)
    stage.delay(5)
    stage.showHead(32, 278, 228)
    stage.delay(5)
    stage.bottomTxt('유비 징저우 주둔군을 지휘했다', False, False, False)
    stage.delay(5)
    stage.showHead(77, 342, 228)
    stage.delay(5)
    stage.bottomTxt('공명와 공모한 주유 공격으로 파괴되었다.', True, False, False)
    stage.delay(10)
    stage.head(32).move(163, 214)
    stage.delay(5)
    stage.bottomTxt('패배한 유비들은 바이디 성으로 도망쳤다,', True, True, False)
    stage.delay(5)
    stage.head(32).hide()
    stage.delay(5)
    stage.bottomTxt('마지막에는 원한을 품은 채 죽었다.', True, False, False)
    stage.delay(10)
    stage.showHead(33, 222, 235)
    stage.delay(5)
    stage.bottomTxt('장비 탈출을 엄호하기 위해 그들은 필사적으로 매청을 방어유비,', True, True, False)
    stage.delay(5)
    stage.head(77).hide()
    stage.showHead(76, 286, 235)
    stage.delay(5)
    stage.bottomTxt('그러나 주력 부대손권 공격받았다,', True, False, False)
    stage.delay(5)
    stage.head(33).hide()
    stage.delay(5)
    stage.bottomTxt('그 결과 그는 전사했다.', True, False, True)
    stage.delay(5)
    stage.showHead(3, 77, 97)
    stage.head(3).move(77, 177)
    stage.delay(5)
    stage.bottomTxt('관우 혼자 타기', False, False, False)
    stage.delay(5)
    stage.head(3).move(222, 235)
    stage.delay(5)
    stage.bottomTxt('그리고 장비를 구하러 갔다,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그 결과 그들은 오나라 군대에 의해 포위되었다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('조의 군대', True, True, False)
    stage.delay(5)
    stage.head(0).move(254, 155)
    stage.delay(5)
    stage.bottomTxt('그는 곧장 구조 관우로 달려갔다,', True, False, False)
    stage.delay(5)
    stage.head(76).hide()
    stage.delay(5)
    stage.bottomTxt('동부 오 군대를 격퇴했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('그가 조조 지휘에 합류했을 Afterwards관우,', True, True, False)
    stage.delay(8)
    stage.bottomTxt('그는 의형제들의 복수를 맹세했다.', True, False, True)
    stage.delay(5)
    stage.head(3).hide()
    stage.delay(5)
    stage.bottomTxt('관우가 조조에 합류하면서,', False, False, False)
    stage.delay(5)
    stage.head(0).move(266, 225)
    stage.delay(5)
    stage.bottomTxt('그는 즉시 군대를 이끌고 장링을 공격했다.', True, False, True)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('장릉 조조 본대')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n윤창, 이 전투의 선봉으로 임명한다. 어때?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 2)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n네, 관우 깊이 감사드립니다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 1)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 12, [
        3])
    gvars[4076] = 0
    gvars[4057] = 48
    stage.setBattlePos([
        [
            6,
            2],
        [
            6,
            3],
        [
            6,
            1],
        [
            6,
            4],
        [
            5,
            2],
        [
            5,
            3],
        [
            5,
            1],
        [
            5,
            4],
        [
            4,
            2],
        [
            4,
            3],
        [
            4,
            1],
        [
            4,
            4],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene5():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n전투에 임하라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n장링 자체는 특별한 것이 없습니다.\n&20\n전장 남쪽에는 양쯔강이 있었다.\n&0\n흠.\n양쯔강은 이미 동오 해군이 통제하고 있을 가능성이 높다.')
    if stage.unitClickTest(17):
        stage.say('&17\n관 장군의 사랑하는 이들을 잃은 슬픔,\n초선 이해할 만합니다.\n&0\n…………')
    if stage.unitClickTest(19):
        stage.say('&19\n하지만 솔직히 이해하기 어렵네요,\n공명Why 그런 반항적인 행동을 할 수 있겠어......?')
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 공명 형은 동우에 있는 것 같지?\n&0\n제갈진?\n&1\n네, 네, 그 사람이에요.\n제갈진이 공명를 반란으로 설득한 건가?\n&0\n믿기 힘들네요,\n제갈진은 훌륭한 인격을 가졌기 때문이다,\n그는 그런 비열한 수법을 쓸 사람 같지 않았다.\n&0\n형이 설득하려 해도,\n이 일로 공명 배신할 것 같지 주군.')
    if stage.unitClickTest(3):
        stage.say('&0\n윤창, 그의 투지는 확실히 칭찬할 만하다,\n하지만 감정이 너무 충동적이면 승리는 불가능하다.\n&3\n네, 관은 당신의 가르침을 엄격히 따를 것입니다.')
    if stage.unitClickTest(23):
        stage.say('&23\n녹룡초승달검과 붉은 토끼 말,\n정말 세상에서 드문 보물입니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
