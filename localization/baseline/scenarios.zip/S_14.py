# Source Generated with Decompyle++
# File: S_14.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,16)',
        '(14,16)',
        '(13,15)',
        '(14,15)'])
    stage.nearEvent([
        0,
        17,
        0,
        123,
        120,
        1,
        121,
        6])
    stage.nearEvent([
        0,
        119,
        32,
        119], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 4, 4)
    stage.createFriend([
        {
            'id': 32,
            'x': 13,
            'y': 26,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 3,
            'x': 13,
            'y': 25,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 1 },
        {
            'id': 33,
            'x': 14,
            'y': 25,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 2 },
        {
            'id': 40,
            'x': 14,
            'y': 26,
            'dir': 0,
            'lv': 4,
            'ai': 1,
            'i': 3 }])
    stage.createEnemy([
        {
            'id': 119,
            'x': 13,
            'y': 16,
            'lv': 6,
            'i': 0 },
        {
            'id': 126,
            'x': 14,
            'y': 15,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 17,
            'x': 14,
            'y': 16,
            'lv': 6,
            'i': 2 },
        {
            'id': 310,
            'x': 13,
            'y': 15,
            'lv': 0,
            'ai': 0,
            'i': 3 },
        {
            'id': 298,
            'x': 12,
            'y': 17,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 299,
            'x': 15,
            'y': 14,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 318,
            'x': 12,
            'y': 14,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 319,
            'x': 15,
            'y': 17,
            'lv': 0,
            'ai': 0,
            'i': 7 },
        {
            'id': 2,
            'x': 8,
            'y': 16,
            'dir': 3,
            'lv': 6,
            'i': 8 },
        {
            'id': 122,
            'x': 8,
            'y': 15,
            'dir': 3,
            'lv': 4,
            'i': 9 },
        {
            'id': 234,
            'x': 8,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'i': 10 },
        {
            'id': 235,
            'x': 8,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'i': 11 },
        {
            'id': 123,
            'x': 13,
            'y': 11,
            'dir': 0,
            'lv': 4,
            'i': 12 },
        {
            'id': 210,
            'x': 14,
            'y': 11,
            'dir': 0,
            'lv': 0,
            'i': 13 },
        {
            'id': 236,
            'x': 12,
            'y': 11,
            'dir': 0,
            'lv': 0,
            'i': 14 },
        {
            'id': 237,
            'x': 15,
            'y': 11,
            'dir': 0,
            'lv': 0,
            'i': 15 },
        {
            'id': 120,
            'x': 19,
            'y': 15,
            'dir': 1,
            'lv': 4,
            'i': 16 },
        {
            'id': 121,
            'x': 19,
            'y': 16,
            'dir': 1,
            'lv': 4,
            'i': 17 },
        {
            'id': 238,
            'x': 19,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'i': 18 },
        {
            'id': 239,
            'x': 19,
            'y': 17,
            'dir': 1,
            'lv': 0,
            'i': 19 },
        {
            'id': 211,
            'x': 13,
            'y': 20,
            'lv': 0,
            'i': 20 },
        {
            'id': 212,
            'x': 14,
            'y': 20,
            'lv': 0,
            'i': 21 },
        {
            'id': 240,
            'x': 12,
            'y': 20,
            'lv': 0,
            'i': 22 },
        {
            'id': 241,
            'x': 15,
            'y': 20,
            'lv': 0,
            'i': 23 },
        {
            'id': 213,
            'x': 13,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 24 },
        {
            'id': 214,
            'x': 14,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 25 },
        {
            'id': 215,
            'x': 22,
            'y': 15,
            'dir': 1,
            'lv': 0,
            'i': 26 },
        {
            'id': 216,
            'x': 22,
            'y': 16,
            'dir': 1,
            'lv': 0,
            'i': 27 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 13,
            'y': 1 },
        {
            'idx': 1,
            'x': 26,
            'y': 15,
            'dir': 3 },
        {
            'idx': 2,
            'x': 1,
            'y': 18,
            'dir': 1 },
        {
            'idx': 3,
            'x': 14,
            'y': 1 },
        {
            'idx': 4,
            'x': 26,
            'y': 16,
            'dir': 3 },
        {
            'idx': 5,
            'x': 1,
            'y': 19,
            'dir': 1 },
        {
            'idx': 6,
            'x': 12,
            'y': 2 },
        {
            'idx': 7,
            'x': 26,
            'y': 14,
            'dir': 3 },
        {
            'idx': 8,
            'x': 1,
            'y': 17,
            'dir': 1 },
        {
            'idx': 9,
            'x': 15,
            'y': 2 },
        {
            'idx': 10,
            'x': 26,
            'y': 17,
            'dir': 3 },
        {
            'idx': 11,
            'x': 1,
            'y': 20,
            'dir': 1 },
        {
            'idx': 12,
            'x': 13,
            'y': 2 },
        {
            'idx': 13,
            'x': 27,
            'y': 15,
            'dir': 3 },
        {
            'idx': 14,
            'y': 18,
            'dir': 1 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(126, -1, 0, -1, 0, 8)
    stage.setEnemyEquip(122, -1, 0, -1, 0, 2)
    stage.setEnemyEquip(123, -1, 0, -1, 0, 13)
    stage.loadBg(14)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab30')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab30')
    stage.draw()
    stage.bgSound(1)
    stage.say('&0\n이제 유비 증원군이 도착했다,\n이 샤피 도시에서 개미 한 마리도 나올 수 없었다.\n&0\n비록 이것이 여포과의 마지막 전투였지만,\n하지만 앞으로 그런 상대를 잃는다면,\n사실 조금 조용한 느낌이었다.......')
    stage.unit(119).setDir(stage.countDir(119, 17))
    stage.unit(17).setDir(stage.countDir(17, 119))
    stage.say('&119\n이곳은 완전히 둘러싸여 있어.........\n초선, 상황이 이 지경에 이르렀다......\n내가 걱정하는 건 네 .......\n&17\n봉선... 아직 진 게 아니야.\n나도 도와줄게.')
    stage.unit(119).setAction(4)
    stage.say('&119\n초선.......')
    stage.unit(126).setDir(stage.countDir(126, 0))
    stage.say('&126\n이 시점에서 더 이상 할 수 있는 일이 없었다.\n나는 내 모든 것을 다할 수밖에 없다,\n조조에 맞서 싸우는 것.')
    stage.unit(126).setAction(2)
    stage.say('&126\n군대 전체에 알린다! 이제 겨울이다,\n장기전은 조조 군대에 매우 불리했다!\n&126\n지금은 도시를 지키는 것이 최선의 전략이다.\n우리는 적을 끝까지 저항하며 낙담하지 않아야 합니다.\n&126\n만약 투지를 잃으면,\n그것이 바로 조조가 바라던 것이었다!')
    stage.unit(32).setDir(stage.countDir(32, 0))
    stage.say('&32\n맹덕Sir, 준비됐어.\n명령만 내리면 바로 공격할 거야.')
    stage.unit(119).move(9, 16, 3)
    stage.unit(119).setDir(stage.countDir(119, 2))
    stage.unit(2).setDir(stage.countDir(2, 119))
    stage.say('&119\n원위안, 너에게 물어볼 게 있어.\n&2\n어떤 지침이 있는지 여쭤봐도 될주군?\n&119\n이 전투에서 지면,\n조조에 제출해 주시길 바랍니다.\n&2\n주군, 왜 그런 말을 해?\n두 통치자를 섬기지 장료.\n&119\n이 전투가 내 마지막일지도 몰라,\n전장에서 죽는 것은 원래 한 장군의 바람이었고,\n하지만 가장 걱정되는 것은 is초선......\n&119\n그러니 네가 그녀를 지켜주길 바란다.\n&2\n주군... 지금은 낙담할 때가 아니야,\n전쟁은 아직 끝나지 않았다.\n&2\n나는 장료 용감하게 적과 싸울 것이다,\n이 전쟁의 승리를 거두세요.\n&119\n…… 정말? 네가 믿고 있어.\n그래서 나, 루 봉선, 정말 낙담스러운 하루를 보냈어!\n하하하.\n&2\n(주군....... )')
    stage.unit(119).move(13, 16, 0)
    stage.unit(2).setDir(3)
    stage.unit(119).setDir(stage.countDir(119, 0))
    stage.say('&119\n도둑 조, 덤벼라!\n내가 어떻게 혼돈의 시대를 헤매는지 보게 하라, 봉선\n무적의 무공!\n&123\n주군, 후청, 네 말이 깊이 감동했어.\n&123\n난 확실히 싸울 거야조조.\n&120\n(여포 아래에 있는 게 지쳤어.\n이제 석사 바꿀 때가 된 거 아니야? )\n&121\n(이대로라면 내 인생이 망가질 것 같아.\n항복할 기회를 찾는 게 낫지...... )\n&0\n흠, 다들 준비됐어?\n군대 전체가 공격을 시작했다.')
    stage.bgSound(3)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[514] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 13, 16):
        stage.getItem(151, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 14, 16):
        stage.getItem(158, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 13, 15):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 14, 15):
        stage.getItem(150, 0, True, 1025)
        vars[23] = 1
    if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 8, 11, 19, 20):
        if not vars[50] and not vars[53]:
            stage.say('&119\n결국 ......은 살해되어 도시로 끌려갔다.')
            stage.unit(17).setDir(stage.countDir(17, 119))
            stage.say('&17\n봉선, 나도 싸우러 갈게.')
            stage.unit(119).setDir(stage.countDir(119, 17))
            stage.say('&119\n너는 여기 있어.\n여기가 더 안전해.\n전 군대를 전투에 동원하라!\n&17\n봉선, 제발!\n제발, 나도 전투에 데려가 줘.\n&119\n……………\n알겠어, 근데 너무 멀리 가지 마.\n&17\n봉선............\n괜찮아, 널 끌어내리지 않을게.\n&119\n초선!\n&17\n봉선!')
        stage.unit(119).setAI(1)
        stage.unit(126).setAI(1)
        stage.unit(17).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(298).setAI(1)
        stage.unit(299).setAI(1)
        stage.unit(318).setAI(1)
        stage.unit(319).setAI(1)
        stage.unit(2).setAI(1)
        stage.unit(122).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(123).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(120).setAI(1)
        stage.unit(121).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(240).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        vars[30] = 1
    if not vars[31] and stage.isInRect(1025, 6, 14, 7, 17):
        stage.unit(2).setAI(1)
        stage.unit(122).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[31] = 1
    if not vars[32] and stage.isInRect(1025, 12, 9, 15, 10):
        stage.unit(210).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(123).setAI(1)
        vars[32] = 1
    if not vars[33] and stage.isInRect(1025, 20, 14, 21, 17):
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        stage.unit(120).setAI(1)
        stage.unit(121).setAI(1)
        vars[33] = 1
    if not vars[34] and stage.isInRect(1025, 12, 21, 15, 22):
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(240).setAI(1)
        stage.unit(241).setAI(1)
        vars[34] = 1
    if not vars[40] and stage.isNear(0, 119, True):
        stage.unit(0).setDir(stage.countDir(0, 119))
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.say('&0\n마침내 그 날이 왔다.\n내 손에 죽은 것에 감사해야 해.\n&119\n흥, 나, 루 봉선은 절대 지지 않을 거야!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 17, False):
        stage.unit(0).setDir(stage.countDir(0, 17))
        stage.unit(17).setDir(stage.countDir(17, 0))
        stage.say('&0\n왜 여기 있는 거야!?\n&17\n모든 것은 운명에 의한 장난이라고밖에 할 수 없다.\n이제 봉선와 나는 서로 사랑해,\n흔들림 없는 서약이 이루어졌다.\n&17\n아버지가 살아계실 때 어른들이 우리 가족을 어떻게 대했는지 잊지 못했습니다\n사람들의 친절. 하지만 이제 우리는 서로 적이야,\n죄송합니다.')
        fight = stage.startFight(0, 17, 5)
        fight.showUnit(True, '(감히 여포를 위해 싸우다니!? 의지가 넘치는군……)', 0)
        fight.showUnit(False, '조 공......... 조심해!', 9)
        fight.showStart()
        fight.setAction(False, 0)
        fight.say(False, '어서!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(False, 1, False)
        stage.delay(5)
        fight.attack1(True, 3, False)
        stage.delay(10)
        fight.setAction(True, 0)
        fight.say(True, '정말 빠르다!\n그래서 무술도 좀 알고 있는 ......??', True)
        fight.setAction(False, 6)
        fight.say(False, '비록 그건 사소한 속임수였지만, .........', True)
        stage.delay(10)
        fight.setAction(False, 8)
        fight.say(False, '조심해! 이번엔 진짜야!', True)
        fight.setAction(True, 4)
        fight.say(True, '잠깐!\n싸우고 싶지 않아!', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '조 공.........\n사랑을 위해 죽는 것은 여자의 운명이야.\n이제는 다른 방법이 없습니다!', True)
        fight.setAction(True, 6)
        fight.say(True, '운명에 굴복할 필요 없어.\n그렇게 죽으면 왕윤 경이 슬퍼할 거야.\n다시 한 번 생각해 보세요!', True)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.say(True, '흠, 도저히 못 하겠어. ...... 안가!', True)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        stage.delay(15)
        fight.setAction(False, 11)
        fight.say(False, '조공............\n어떻게 해야 ......?', True)
        fight.end()
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 123, False):
        stage.unit(0).setDir(stage.countDir(0, 123))
        stage.unit(123).setDir(stage.countDir(123, 0))
        stage.say('&0\n비켜!\n&123\n조조! 오래전부터 보고 싶었어.\n한 번만 베일 수 있다면, 내 죽음은 그만한 가치가 있어.\n목숨을 내놓아!')
        fight = stage.startFight(0, 123, 5)
        fight.showUnit(False, '더 말해도 소용없어!\n이거 받아라, 조조!', 9)
        fight.showUnit(True, '덤벼라!', 8)
        fight.showStart()
        fight.attack2(True, 2, False)
        stage.delay(10)
        fight.setAction(True, 1)
        stage.delay(10)
        fight.setAction(False, 1)
        stage.delay(10)
        fight.setAction(False, 3)
        stage.delay(10)
        fight.setAction(False, 3)
        stage.delay(10)
        fight.say(False, '루, 여포 ...... 장군!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 6)
        fight.say(True, '처음부터 죽기로 결심한 거야?\n그는 정말로 존경할 만한 적 장군이다.\n하지만 아직 여기서 죽을 수는 없어.', True)
        fight.end()
        stage.unit(123).hide(2)
        stage.getItem(120, 0)
        vars[51] = 1
        vars[42] = 1
    if not vars[43] and stage.isNear(32, 119, True):
        stage.unit(32).setDir(stage.countDir(32, 119))
        stage.unit(119).setDir(stage.countDir(119, 32))
        stage.say('&32\n뤼 장군! 내 목숨을 줘!\n&119\n유비, 우리 오랜 친구였잖아!\n아마도 이번이 마지막으로 너를 마주할 거야.\n내 봉선의 무술을 꼭 기억해 줄게!')
        vars[43] = 1
    if not vars[44] and stage.isNear(120, 1, False):
        stage.unit(120).setDir(stage.countDir(120, 1))
        stage.unit(1).setDir(stage.countDir(1, 120))
        stage.say('&120\n(때가 왔다. )\n저기 저기 잘 들어! 나 항복했어.\n나를 데려가 조조!\n&1\n흥, 실제로 전장에서 탈영한다고?\n나도 너 별로인 것 같아.\n차라리 집에 가서 수유하는 게 낫겠다!\n&120\n뭐라고!\n절대 그냥 넘어가지 않을 거야! 내 힘을 보여줄게.\n나랑 비교해봐!')
        fight = stage.startFight(1, 120, 5)
        fight.showUnit(False, '진심으로 항복할 계획이었어!\n나중에 저승에 가면 후회하지 마!', 10)
        fight.showUnit(True, '아군 너 같은 비열한 사람이 필요 없어.\n너를 저승으로 보내줄게!', 8)
        fight.showStart()
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.setAction(False, 4)
        fight.setAction(True, 0)
        fight.say(True, '응?', True)
        fight.setAction(False, 8)
        fight.say(False, '와하하!\n더 이상 도망칠 수 없어!\n내 궁극 기술을 봐!', True)
        fight.attack2(False, 1, True)
        stage.delay(5)
        fight.attack1(True, 2, False)
        stage.delay(10)
        fight.setAction(True, 0)
        fight.say(True, '무슨 일이야?\n전혀 작동하지 않습니다.', True)
        fight.setAction(False, 4)
        fight.say(False, '이-어떻게 이런 일이 가능하지...?\n분명 실수일 거야!\n내 한 방 더 맞아!', True)
        fight.setAction(False, 3)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack1(False, 1, False)
        fight.attack1(False, 4, False)
        fight.setAction(True, 4)
        fight.setAction(True, 4)
        fight.setAction(True, 4)
        fight.setAction(False, 2)
        fight.say(False, '그 사람 어디 있어?\n어디 갔지?', True)
        fight.setAction(True, 8)
        fight.say(True, '끝장이야!\n내 진짜 속임수를 보게 하라,\n저승으로 내려가는 선물이라고 생각해!', True)
        fight.setAction(False, 1)
        fight.say(False, '도와줘, 도와줘!', False)
        fight.attack2(True, 1, False)
        stage.delay(5)
        fight.say(False, '와아......!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 1)
        stage.delay(5)
        fight.setAction(True, 2)
        fight.say(True, '야망 없는 사람!\n흥!', False)
        fight.setAction(True, 9)
        fight.end()
        stage.unit(120).hide(2)
        vars[55] = 1
        vars[44] = 1
    if not vars[45] and stage.isNear(121, 6, False):
        stage.unit(121).setDir(stage.countDir(121, 6))
        stage.say('&121\n(나-나 여기서 죽고 싶지 않아.\n탈당한 거지? 응, 이게 유일한 방법이야. )\n저기 적 장군 저기!')
        stage.unit(6).setDir(stage.countDir(6, 121))
        stage.say('&6\n응?\n나랑 결투하후연 하고 싶어?\n좋아, 시작하자!')
        fight = stage.startFight(6, 121, 5)
        fight.showUnit(True, '나는 하후연, 먀오차이라는 스타일이야.\n자, 누가 더 나은지 보자!', 8)
        fight.showUnit(False, '저는—제 이름은 송셴입니다.\n(…… 아-아니, 그건 아니야!\n내가 무슨 생각을 하는 거지! )', 8)
        fight.showStart()
        fight.setAction(False, 4)
        fight.say(False, '(어, 어쩌다 이렇게 된 거야?\n이, 이제 큰일 났다……)', True)
        fight.setAction(False, 4)
        fight.say(False, '(…… 하후연 궁술 전문가라고 들었어,\n어떻게 그를 이길 수 있겠어......... )', True)
        fight.setAction(True, 0)
        fight.say(True, '무슨 일이야, 송셴!\n왜 아직 나한테 안 다가와?', True)
        stage.delay(5)
        fight.setAction(True, 3)
        fight.say(True, '이 시점에서,\n마지막 순간에 도망칠 생각은 아니지?', True)
        fight.setAction(False, 1)
        fight.say(False, '...... 없이 다시 만날 수 있길!', True)
        fight.setAction(False, 3)
        fight.attack1(True, 0, True)
        fight.say(False, '와아!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 0)
        fight.say(True, '젠장, 1대1 결투로 나를 모욕했어!\n두 군대가 충돌했을 때, 그들은 싸우지 않고 도망쳤다,\n이건 장군에게 정말 수치야!', True)
        fight.setAction(True, 1)
        fight.say(True, '음음,\n화살 하나 헛되이 썼어!', True)
        fight.setAction(True, 3)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.end()
        stage.unit(121).hide(2)
        vars[57] = 1
        vars[45] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n흠!\n움직일 수가 없어. 여기서 죽는 거야......\n초선Ah, ......, 제발 용서해 주세요."')
        stage.unit(119).hide(2)
        stage.getItem(36, 0, True, 1027)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(123, 7, 0, 2):
        stage.say('&123\n와!\n안타깝네, 뤼 ...... 장군님.........')
        stage.unit(123).hide(2)
        stage.getItem(120, 0, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(122, 7, 0, 2):
        stage.say('&122\n내 운명은 ......에 달려 있어!')
        stage.unit(122).hide(2)
        stage.getItem(109, 0, True, 1027)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(17, 7, 0, 2):
        stage.say('&17\nAhh......봉선.\n초선 거기서 끝났다.')
        stage.unit(17).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(2, 7, 0, 2):
        stage.say('&2\n흠, 내 실수였어.\n…………\n빨리 날 죽여!\n&2\n…………\n(주군...... )\n&2\n응? 잠깐!\n나는 조의 군대에 항복하고자 한다,\n나를 만나게 해조조.')
        stage.unit(2).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(120, 7, 0, 2):
        stage.say('&120\n너!\n음............')
        stage.unit(120).hide(2)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(126, 7, 0, 2):
        stage.say('&126\n왜 조조 그렇게 강력한 부하들이 있는 걸까?\n왜!\n&126\n내가 옹호하는 정의가 잘못된 것인가,\n정의조조 진짜인가?\n&126\n그럼 내가 .......')
        stage.unit(126).hide(2)
        stage.getItem(115, 0, True, 1027)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(121, 7, 0, 2):
        stage.say('&121\n내가 그걸 따라가지 않았더라면 좋았을 텐데여포.........\n와!')
        stage.unit(121).hide(2)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n흠, 더 이상 싸울 수 없어......!')
        stage.unit(32).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n후퇴!')
        stage.unit(3).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n이걸 기억하세요!')
        stage.unit(33).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n주군, 선첸이 먼저 물러났다.')
        stage.unit(40).hide(1)
        vars[61] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\nNow여포 마침내 처형되었다......\n생각해보니, 우리 꽤 오랫동안 싸워왔어.')
        stage.unit(0).setDir(2)
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[0] = 1
        vars[614] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 여포에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
