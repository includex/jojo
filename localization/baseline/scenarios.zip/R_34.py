# Source Generated with Decompyle++
# File: R_34.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            2,
            54,
            80],
        [
            10,
            44,
            64,
            1],
        [
            11,
            64,
            64,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    if vars[311]:
        stage.setEventName('신뢰와 의로운 마음')
    if not vars[311]:
        stage.setEventName('정욱 고백')
    stage.setStageName('허페이 조조 본캠프')
    stage.delay(3)
    stage.unit(11).setAction(0, 2)
    stage.say('&11\n동우는 한 달 넘게 침묵했다,\n아마 벌써 허페이를 포기한 걸까?')
    stage.say('&2\n아니, 손권 그렇게 그냥 돌아가지 않을 거야.\n&2\n그런데 주군 아직 한중에 있나요?')
    stage.unit(10).setAction(0, 2)
    stage.say('&10\n설마, 그는 쉬두로 돌아가야 한다.\n&2\n좋아, 즉시 주군에게 도움을 요청해,\n동우의 움직임은 정말 예측 불가능했다.')
    stage.unit(2).setAction(0, 1)
    stage.say('&2\n손권 이 사람이 병력을 모으고 있을지도 모른다면,\n결정적인 전투를 준비했다.\n&10\n그럼 내가 직접 쉬두에 갈게,\n때가 되면 반드시 지원군이 도착할 것이다.')
    stage.unit(2).setAction(0, 0)
    stage.say('&2\n흠, 장군님께 부탁드립니다.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            8,
            58,
            70],
        [
            15,
            64,
            70],
        [
            9,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            19,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            10,
            48,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말?\n동부 오나라 군대가 한 달째 움직이지 않았다고?\n&10\n네.\n아군 침투해 조사하러 사람들을 보냈지만,\n동우의 움직임을 파악하지 못했다.\n&10\n아마도 그들은 힘을 모으고 있을지도 모른다,\n항상 치열한 전투에 대비하며,\n그래서 주군 지원을 요청하러 왔어.\n&0\n좋아, 내가 직접 군대를 이끌고 합페이로 가겠다.\n&10\n네, 감사합니다주군.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(2, 407, 167)
    stage.showHead(76, 471, 187)
    stage.showHead(0, 331, 87)
    stage.delay(5)
    stage.bottomTxt('조조 증원군을 이끌었다', False, False, False)
    stage.delay(5)
    stage.head(0).move(471, 87)
    stage.head(0).move(471, 107)
    stage.delay(5)
    stage.bottomTxt('그는 직접 합비로 가서 전투를 감독했다.', True, False, True)
    stage.delay(3)
    stage.loadBg(2, 53)
    if not vars[311]:
        stage.bgSound(19)
        stage.delay(3)
        stage.showUnit(9, 44, 52, 1)
        stage.draw()
        stage.setStageName('허페이 조조 본캠프')
        stage.showUnit(21, 54, 22, 2)
        stage.say('&21\n방덕General, 여기 너만 있는 거야?"')
        stage.unit(21).move(54, 52, 2)
        stage.delay(3)
        stage.unit(21).setAction(0, 3)
        stage.say('&21\n방덕 장군님께 할 말이 있습니다.\n&9\n무슨 일이야?\n&21\n마텡에 관한 거야......\n내가 마텡을 죽인 사람이야.\n&9\n……!?')
        stage.unit(21).setAction(0, 2)
        stage.say('&21\n그때 마텡은 주군를 해치려 음모를 꾸몄다,\n주군 해칠 의도가 전혀 없었다.')
        stage.unit(21).setAction(0, 3)
        stage.say('&21\n마텡을 죽이자고 한 건 내 아이디어였어,\n모든 책임은 나에게 있다.\n&9\n왜 마텅을 죽였나요?\n&21\n나는 주군의 전략가다,\n전략가의 임무는 .........\n안전을 위협하는 모든 요소를 제거주군.')
        stage.unit(21).setAction(0, 2)
        stage.say('&21\n마텡은 주군를 해치려는 음모에 가담했다,\n물론, 그가 이 세상에 살게 둘 수는 없어,\n이 원칙을 이해하실 거라 확신합니다.\n&9\n수년간 싸운 후에,\n이 점은 이해합니다.')
        stage.unit(9).setAction(0, 3)
        stage.say('&9\n알고 보니 조 공은 마 텅의 죽음을 언급하지 않았주군,\n이 책임을 혼자 짊어지는 것인가?\n&9\n혼란스러운 시대에 생존을 추구하는 통치자가 되기 위해,\n그는 개인적인 원한을 내려놓는 최선의 전략을 채택할 수밖에 없었다.\n&9\n선과 악의 책임을 모두 맡는 이 접근법,\n이게 진짜 조조님의 본모습인가요?\n&9\n의심 없이 내 방덕을 받아줘,\n그것도 부하들을 신뢰한다는 증거 아닌가?\n&9\n그렇다면 앞으로도 최선을 다하겠습니다,\n나는 조 재상을 최대한 충성스럽게 섬기겠다!')
        stage.unit(21).setAction(0, 3)
        stage.say('&21\n일반 방덕......')
        stage.delay(10)
        stage.bgSound(-1)
        stage.unit(21).setAction(0, 0)
        stage.say('&21\n오?\n모두 다 온 것 같아.')
        stage.bgSound(15)
        stage.delay(3)
        stage.unit(21).move(64, 52, 3)
        stage.unit(9).setAction(0, 1)
        stage.showUnit(0, 54, 22, 2)
        stage.unit(0).move(54, 28, 2)
        stage.showUnit(1, 54, 22, 2)
        stage.unitsMove([
            [
                stage.unit(0),
                54,
                34,
                2],
            [
                stage.unit(1),
                54,
                28,
                2]])
        stage.showUnit(15, 54, 22, 2)
        stage.unitsMove([
            [
                stage.unit(0),
                54,
                40,
                2],
            [
                stage.unit(1),
                54,
                34,
                2],
            [
                stage.unit(15),
                54,
                28,
                2]])
        stage.showUnit(20, 54, 22, 2)
        stage.unitsMove([
            [
                stage.unit(0),
                54,
                46,
                2],
            [
                stage.unit(1),
                54,
                40,
                2],
            [
                stage.unit(15),
                54,
                34,
                2],
            [
                stage.unit(20),
                54,
                28,
                2]])
        stage.showUnit(19, 54, 22, 2)
        stage.unitsMove([
            [
                stage.unit(0),
                54,
                52,
                2],
            [
                stage.unit(1),
                54,
                46,
                2],
            [
                stage.unit(15),
                54,
                40,
                2],
            [
                stage.unit(20),
                54,
                34,
                2],
            [
                stage.unit(19),
                54,
                28,
                2]])
        stage.unitsMove([
            [
                stage.unit(0),
                54,
                80,
                0],
            [
                stage.unit(1),
                44,
                64,
                1],
            [
                stage.unit(15),
                44,
                58,
                1],
            [
                stage.unit(20),
                64,
                64,
                3],
            [
                stage.unit(19),
                64,
                58,
                3]])
        stage.delay(10)
    if vars[311]:
        stage.showUnits([
            [
                0,
                54,
                80],
            [
                1,
                44,
                64,
                1],
            [
                15,
                44,
                58,
                1],
            [
                9,
                44,
                52,
                1],
            [
                20,
                64,
                64,
                3],
            [
                19,
                64,
                58,
                3],
            [
                21,
                64,
                52,
                3]])
        stage.draw()
        stage.setStageName('허페이 조조 본캠프')
    stage.bgSound(15)
    stage.delay(3)
    stage.showUnit(181, 54, 22, 2)
    stage.say('&181\n보고해!')
    stage.unit(181).setAction(11)
    stage.say('&181\n주군 그들은 동부 오군의 움직임을 알게 되었다.\n동오군은 루쉬관 반대편에 중장군을 집중시켰다.\n&0\n젖은 수염으로 입을 적시...... 건가요?\n손권 이 어린아이에게,\n그들은 분명히 해상 전투 전문 지식으로 결과를 결정짓고 싶어 했을 것이다.\n&0\n음, 수고하셨습니다.\n내려가서 쉬어.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.say('&0\n모두가 방금 들었듯이,\n시간이 길어질수록 동우의 군사력은 점점 커졌다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n우리는 가능한 한 빨리 공세를 개시해야 합니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.say('&19\n하지만 직접 공격은 너무 위험했다.')
    stage.unit(19).setAction(0)
    stage.say('&0\n음, 방덕.')
    stage.unit(9).setAction(0, 2)
    stage.delay(3)
    stage.unit(9).setAction(6)
    stage.say('&9\n......\n&0\n그리고 전투에 병력을 보내라고 명령했다,\n손권 내가 이끄는 주력 부대에 의해 저지당했을 때,\n그 기회를 이용해 그의 부대에 기습 공격을 감행할 것이다.')
    if vars[311]:
        stage.say('&9\n내가 부대 역할을 하게 해줘!?\n&0\n네, 맞아요.\n이 싸움은 당신에게 달려 있습니다.\n&9\n왜 나를 전투에 보냈어?\n내가 편을 갈까 봐 두렵지 않아?\n&0\n넌 약속을 어기는 사람이 아니잖아.\n&9\n(조조 주님께서 내 성품을 잘 아시네,\n그리고 그는 나를 전혀 의심하지 않았다. )\n&9\n(나는 정말 그만큼 잘하지 못해......\n이 사람은 정말 마음이 넓다. )\n&9\n(마텡의 주군 불운을 생각하며,\n이것은 혼란스러운 시기에도 흔한 관행입니다.\n모든 것이 무력했다. )\n&9\n(마텡주군 용서해 주세요!)\n내 마음은 이미 조조에게 속해 있어. )')
    if not vars[311]:
        stage.say('&9\n네, 명령에 따르겠습니다.')
        stage.unit(0).setAction(17)
        stage.say('좋습니다, 출전합니다!')
    stage.unit(0).setAction(0)
    stage.unit(9).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        19,
        2,
        11,
        10,
        9])
    gvars[4076] = 0
    gvars[4057] = 34
    stage.setBattlePos([
        [
            12,
            8],
        [
            13,
            8],
        [
            11,
            19],
        [
            10,
            18],
        [
            12,
            18],
        [
            0,
            19],
        [
            0,
            20],
        [
            0,
            19],
        [
            0,
            20],
        [
            11,
            18],
        [
            10,
            17],
        [
            12,
            17],
        [
            11,
            17],
        [
            11,
            9],
        [
            14,
            9]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n이제 양군은 양쯔강에서 대치하고 있다고 할 수 있다.\n&20\n만약 그들이 저편에 성공적으로 도달할 수만 있다면,\n하지만 상대방은 ......\n&0\n동우의 트롤들이 걱정되는 거지?')
    if stage.unitClickTest(19):
        stage.say('&19\n이 사람은 손권 매우 안정적이라고 생각해요.\n&19\n이 작전은 철저한 준비가 필요하다.')
    if stage.unitClickTest(21):
        stage.say('&21\n동오의 장군들 중에서,\n여몽. 육손지의 재능은 주유와 견줄 수 있었다.')
    if stage.unitClickTest(9):
        stage.say('&0\n네가 결정해, 방덕.\n&9\n걱정 마세요, 주군.')
    if stage.unitClickTest(15):
        stage.say('&15\n그는 종종 물에서 동오와 싸웠다,\n산속이라면 내가 최고였을 거야.\n&0\n오?\n그러니 이번에는 허저 쉬게 해.\n&15\n아, 주군 제발 그런 말 하지 마세요......')
    if stage.unitClickTest(1):
        stage.say('&1\n손권 이 사람은 전투에서 매우 인내심이 강하다.\n&0\n그게 그를 아버지와 형제와 구분 짓는 점이지.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
