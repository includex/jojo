# Source Generated with Decompyle++
# File: R_44.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 281, 233)
    stage.showHead(76, 345, 233)
    stage.bottomTxt('붉은 절벽에서 패배한 동부 무군', False, False, False)
    stage.delay(5)
    stage.head(76).move(442, 219)
    stage.delay(5)
    stage.bottomTxt('그들은 지안예로 후퇴했다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            7,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3]])
    stage.draw()
    stage.setEventName('마지막 수전')
    stage.setStageName('레드 클리프: 조조군의 주요 진영')
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n손권와 공명는 함께 지안예로 물러난 듯했다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕, 드디어 지안예를 공격하려 했다!\n이 전투에서 이기면 왕국을 통일할 수 있어!')
    stage.unit(20).setAction(6)
    stage.say('&20\n아니요, 하후돈 장군님.\n불행히도, 지안예로 행군하기 전에 그들은 싸워야 했다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n아직도 싸워야 해?\n그게 무슨 뜻이야?')
    stage.unit(23).setAction(6)
    stage.say('&23\n지안예 전방 초소의 루쉬 고개에 위치해 있습니다.\n중무장 경비병들이 필연적으로 방어를 위해 배치될 것입니다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n수염 입을 적시는 거야?\n또 물 싸움이 벌어지는 거야!?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say("&0\n속담에 있듯이, '남쪽 배, 북쪽 말'이라니.\n적은 분명히 이 사실을 잘 알고 있다.")
    stage.unit(0).setAction(0, 0)
    stage.say('좋습니다, 적군의 방어가 얼마나 강하든 상관없습니다.\n우리는 후퇴할 길도 없습니다.')
    stage.unit(0).setAction(17)
    stage.say('여수구를 점령하면 건업에는 방어벽이 없어집니다. 망설일 수 없습니다! 출전 준비를 합시다!')
    stage.unit(0).setAction(0)
    stage.unit(19).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 12)
    gvars[4076] = 0
    gvars[4057] = 44
    stage.setBattlePos([
        [
            12,
            12],
        [
            13,
            12],
        [
            12,
            13],
        [
            13,
            13],
        [
            11,
            13],
        [
            14,
            13],
        [
            11,
            12],
        [
            14,
            12],
        [
            12,
            8],
        [
            13,
            8],
        [
            11,
            8],
        [
            14,
            8],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출격해라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n여기까지 왔으니,\n물론, 우리는 절대 질 수 없습니다.')
    if stage.unitClickTest(20):
        stage.say('&20\n전장은 이전과 크게 변하지 않았다.\n&20\n아니면 강 건너편에서 대치 상태에 빠진 건가요?')
    if stage.unitClickTest(19):
        stage.say('&19\n아군 붉은 절벽에서 흑거북 귀옥을 얻었다,\n이로써 바오위는 완전히 침착해졌다.\n&1\n이 현무옥은 어떤 영향을 주나요?\n&19\n이것은 도교 전사형 부대가 사용하는 귀중한 옥이다.\n&19\n양측 모든 세력의 지위를 바꿀 수 있습니다.\n&15\n주를 바꿀까?\n그게 무슨 뜻이야?\n&23\n적을 중독시키거나 다양한 능력을 줄일 수 있습니다,\n반대로, 때로는 개선될 수도 있습니다.\n&1\n......도 좋아질까요?\n그럼 때로는 적이 되기도 하나요?\n&23\n네.\n이 전략에서 가장 어려운 부분은\n중요한 건 적절한 사용 타이밍을 어떻게 익히느냐에 관한 거예요.\n&1\n이건 너무 어려워!')
    if stage.unitClickTest(7):
        stage.say('&7\n주군, 꼭 한번 시도해 보세요.')
    if stage.unitClickTest(15):
        stage.say('&15\n결국 쓸 수 있는 보물이 없었어,\n저는 분명히 랜드 클래스 전략을 잘 알고 있죠......?\n왜 그런 거죠!')
    if stage.unitClickTest(23):
        stage.say('&23\n루쉬관이 점령되면, 건예만 남는다,\n동오는 이 전투에서 반드시 온 힘을 다해 죽을 때까지 싸울 것이다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
