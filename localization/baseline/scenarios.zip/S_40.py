# Source Generated with Decompyle++
# File: S_40.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(17,19)',
        '(16,19)',
        '(16,9)',
        '(19,9)',
        '(6,19)',
        '(6,22)',
        '(27,19)',
        '(27,22)'])
    stage.nearEvent([
        7,
        61,
        0,
        35,
        19,
        69,
        19,
        53,
        19,
        71,
        17,
        72], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 27, 'y': 20, 'dir': 3, 'lv': 6, 'i': 0},
         {'id': 34, 'x': 27, 'y': 21, 'dir': 3, 'lv': 6, 'i': 1},
         {'id': 210, 'x': 25, 'y': 20, 'dir': 3, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 25, 'y': 21, 'dir': 3, 'lv': 0, 'i': 3},
         {'id': 212, 'x': 26, 'y': 20, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 213, 'x': 26, 'y': 21, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 234, 'x': 26, 'y': 19, 'dir': 3, 'lv': 0, 'i': 6},
         {'id': 235, 'x': 26, 'y': 22, 'dir': 3, 'lv': 0, 'i': 7},
         {'id': 298, 'x': 27, 'y': 19, 'dir': 3, 'lv': 0, 'i': 8},
         {'id': 299, 'x': 27, 'y': 22, 'dir': 3, 'lv': 0, 'i': 9},
         {'id': 258, 'x': 28, 'y': 20, 'dir': 3, 'lv': 0, 'i': 10},
         {'id': 259, 'x': 28, 'y': 21, 'dir': 3, 'lv': 0, 'i': 11},
         {'id': 69, 'x': 6, 'y': 20, 'dir': 1, 'lv': 6, 'i': 12},
         {'id': 54, 'x': 6, 'y': 21, 'dir': 1, 'lv': 6, 'i': 13},
         {'id': 214, 'x': 8, 'y': 20, 'dir': 1, 'lv': 0, 'i': 14},
         {'id': 215, 'x': 8, 'y': 21, 'dir': 1, 'lv': 0, 'i': 15},
         {'id': 216, 'x': 7, 'y': 20, 'dir': 1, 'lv': 0, 'i': 16},
         {'id': 217, 'x': 7, 'y': 21, 'dir': 1, 'lv': 0, 'i': 17},
         {'id': 236, 'x': 7, 'y': 19, 'dir': 1, 'lv': 0, 'i': 18},
         {'id': 237, 'x': 7, 'y': 22, 'dir': 1, 'lv': 0, 'i': 19},
         {'id': 300, 'x': 6, 'y': 19, 'dir': 1, 'lv': 0, 'i': 20},
         {'id': 301, 'x': 6, 'y': 22, 'dir': 1, 'lv': 0, 'i': 21},
         {'id': 260, 'x': 5, 'y': 20, 'dir': 1, 'lv': 0, 'i': 22},
         {'id': 261, 'x': 5, 'y': 21, 'dir': 1, 'lv': 0, 'i': 23},
         {'id': 50, 'x': 17, 'y': 9, 'dir': 0, 'lv': 6, 'i': 24},
         {'id': 37, 'x': 18, 'y': 9, 'dir': 0, 'lv': 6, 'i': 25},
         {'id': 218, 'x': 17, 'y': 7, 'dir': 0, 'lv': 0, 'i': 26},
         {'id': 219, 'x': 18, 'y': 7, 'dir': 0, 'lv': 0, 'i': 27},
         {'id': 238, 'x': 16, 'y': 8, 'dir': 0, 'lv': 0, 'i': 28},
         {'id': 239, 'x': 17, 'y': 8, 'dir': 0, 'lv': 0, 'i': 29},
         {'id': 240, 'x': 18, 'y': 8, 'dir': 0, 'lv': 0, 'i': 30},
         {'id': 241, 'x': 19, 'y': 8, 'dir': 0, 'lv': 0, 'i': 31},
         {'id': 302, 'x': 16, 'y': 9, 'dir': 0, 'lv': 0, 'i': 32},
         {'id': 303, 'x': 19, 'y': 9, 'dir': 0, 'lv': 0, 'i': 33},
         {'id': 53, 'x': 16, 'y': 19, 'dir': 0, 'lv': 6, 'i': 34},
         {'id': 66, 'x': 17, 'y': 19, 'dir': 0, 'lv': 6, 'i': 35},
         {'id': 382, 'x': 16, 'y': 18, 'dir': 0, 'lv': 0, 'i': 36},
         {'id': 383, 'x': 17, 'y': 18, 'dir': 0, 'lv': 0, 'i': 37},
         {'id': 390, 'x': 15, 'y': 19, 'dir': 0, 'lv': 0, 'i': 38},
         {'id': 391, 'x': 18, 'y': 19, 'dir': 0, 'lv': 0, 'i': 39},
         {'id': 71, 'hide': 1, 'x': 17, 'y': 24, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 40},
         {'id': 73, 'hide': 1, 'x': 18, 'y': 24, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 41},
         {'id': 72, 'hide': 1, 'x': 16, 'y': 24, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 42},
         {'id': 392, 'hide': 1, 'x': 19, 'y': 24, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 43},
         {'id': 57, 'hide': 1, 'x': 17, 'y': 25, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 44},
         {'id': 58, 'hide': 1, 'x': 18, 'y': 25, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 45},
         {'id': 462, 'hide': 1, 'x': 16, 'y': 25, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 46},
         {'id': 463, 'hide': 1, 'x': 19, 'y': 25, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 47},
         {'id': 59, 'hide': 1, 'x': 11, 'y': 5, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 48},
         {'id': 318, 'hide': 1, 'x': 10, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 49},
         {'id': 319, 'hide': 1, 'x': 10, 'y': 5, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 50},
         {'id': 320, 'hide': 1, 'x': 11, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 51},
         {'id': 60, 'hide': 1, 'x': 24, 'y': 5, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 52},
         {'id': 321, 'hide': 1, 'x': 25, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 322, 'hide': 1, 'x': 25, 'y': 5, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 323, 'hide': 1, 'x': 24, 'y': 6, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 44, 'hide': 1, 'x': 10, 'y': 13, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 56},
         {'id': 324, 'hide': 1, 'x': 9, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 325, 'hide': 1, 'x': 10, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 58},
         {'id': 326, 'hide': 1, 'x': 11, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 59},
         {'id': 61, 'hide': 1, 'x': 23, 'y': 13, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 60},
         {'id': 327, 'hide': 1, 'x': 22, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 61},
         {'id': 328, 'hide': 1, 'x': 23, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 62},
         {'id': 329, 'hide': 1, 'x': 24, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 63},
         {'id': 304, 'x': 27, 'y': 17, 'dir': 3, 'lv': 0, 'i': 64},
         {'id': 305, 'x': 27, 'y': 24, 'dir': 3, 'lv': 0, 'i': 65}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 18,
            'y': 1 },
        {
            'idx': 1,
            'x': 17,
            'y': 1 },
        {
            'idx': 2,
            'x': 18,
            'y': 2 },
        {
            'idx': 3,
            'x': 17,
            'y': 2 },
        {
            'idx': 4,
            'x': 19,
            'y': 2 },
        {
            'idx': 5,
            'x': 16,
            'y': 2 },
        {
            'idx': 6,
            'x': 19,
            'y': 1 },
        {
            'idx': 7,
            'x': 16,
            'y': 1 },
        {
            'idx': 8,
            'x': 20,
            'y': 1 },
        {
            'idx': 9,
            'x': 15,
            'y': 1 },
        {
            'idx': 10,
            'x': 18 },
        {
            'idx': 11,
            'x': 17 },
        {
            'idx': 12,
            'x': 19 },
        {
            'idx': 13,
            'x': 16 },
        {
            'idx': 14,
            'x': 15 }])
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(40)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(1)
    stage.unit(0).setAction(5)
    stage.say('&0\n그리고 연결고리는 어떤가요?\n…… 이 층을 지나면 바로 청두로 이어집니다.\n전 군대가 이 고개를 점령하기 위해 연합했다!')
    stage.unit(0).setAction(0)
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n주군, 정문 검문소 안에서,\n동문과 서문도 있습니다.\n어느 쪽으로 가야 할까요?')
    stage.unit(0).setDir(stage.countDir(0, 19))
    stage.say('&0\n우리가 빨리 행군하지 않으면,\n슈 군대의 방어는 더욱 강력해질 것이다.\n그래서 청두와 더 가까운 시관을 선택했어요......')
    stage.heightLight(5, 19, 7, 22)
    stage.say('&19\n설령 이 시관을 뚫고 들어간다 해도,\n이런 지형에서는 여전히 보급이 어렵습니다.\n&19\n반면, 동쪽 땅은 비옥하고 광활합니다.\n하지만 그들은 행군을 지연시키지 않고 현장에서 군사 보급품을 모을 수 있었다......\n&0\n네, 장기적으로 생각한다면,\n동부가 여전히 서부보다 낫습니다.')
    stage.heightLight(26, 19, 28, 22)
    stage.say('&19\n하지만 그게 훨씬 나을 거야,\n병력은 따라잡기 위해 빠르게 행군해야 했다.\n&0\n이로 인해 병력이 뒤처질 수 있습니다.')
    stage.unit(0).setDir(2)
    stage.unit(19).setDir(2)
    sel = stage.choice('그리고 시관을 돌파했다\n동관 돌파', -1)
    if sel == 1:
        stage.say('&0\n시관을 돌파한다!\n신속히 청두를 점령하라!')
        stage.setWinCondition('승리 조건\n1. 조조 시관을 돌파한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
        stage.showWinCondition('검정을 돌파한다!')
        stage.heightLight(0, 18, 1, 23)
        vars[740] = 1
    elif sel == 2:
        stage.say('&0\n동관을 돌파하라!\n충분한 보급품을 모으고,\n청두를 공격하라!')
        stage.setWinCondition('승리 조건\n1. 조조 동관을 돌파한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
        stage.showWinCondition('검정을 돌파한다!')
        stage.heightLight(34, 18, 35, 23)
        vars[2] = 1
        vars[740] = 0
    stage.unit(34).setDir(stage.countDir(34, 35))
    stage.say('&34\n총리님, 조의 군대가 도착한 것 같습니다!')
    stage.unit(35).setDir(stage.countDir(35, 34))
    stage.say('&35\n음, 그냥 계획대로 하세요.\n&69\n이곳과 청두는 입술과 이빨로 밀접하게 연결되어 있습니다,\n어떤 상황에서도 우리는 이 문턱을 지켜야 합니다......\n&54\n나한테 맡겨, 장바오!\n조위 병사 한 명도 통과시키지 않을 거야.\n&53\n어서!\n나는 조의 군대가 절대 돌아오지 못하게 하고 싶다.\n&66\n관수에 있는 내 대검은 조나라 군대를 산산조각 내는 것이다.\n&50\n쳇, 쳇, 쳇,\n힘만으로는 이길 수 없다.\n전쟁에서는 머리를 써야 해, 머리를 써.')
    stage.unit(37).setDir(stage.countDir(37, 50))
    stage.say('&37\n난 너랑 공명 정말 싫어.\n그냥 때가 되면 방해하지 마!\n&50\n정말 짜증나네요,\n참 이상한 사람이야......')
    stage.bgSound(2)
    stage.startOper()
    vars[540] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 17, 19):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 16, 19):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 16, 9):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 19, 9):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 6, 19):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 6, 22):
        stage.getItem(151, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 27, 19):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 27, 22):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if not vars[6] and stage.curCamp() == 2 and stage.totalRectUnit(0, 9, 16, 24, 27) >= 4:
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n그냥 조의 군대를 유인해 줘.\n마초, 멍화, 조군을 만나라!')
            stage.unit(35).setAction(0)
        stage.unit(72).show()
        stage.unit(71).show()
        stage.unit(73).show()
        stage.unit(462).show()
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(73).setDir(stage.countDir(73, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(72).setAction(4)
        stage.say('&72\n와, 조조 꽤 잘생겼다.\n그를 취하게 하려고 춤추고 싶어.')
        stage.unit(71).setDir(stage.countDir(71, 72))
        stage.unit(71).setAction(5)
        stage.say('&71\n남편 앞에서 진짜로 작업 걸었어?\n좀 더 자세히 살펴보길 원해,\n난 그보다 더 남자답다!')
        stage.unit(71).setAction(0)
        stage.say('&73\n응? 전투에 나가려는 거야?')
        stage.unit(57).setDir(stage.countDir(57, 58))
        stage.say('&57\n이번에는 조조를 산산조각 내야 해!\n마다이! 가자!')
        stage.unit(58).setDir(stage.countDir(58, 57))
        stage.say('&58\n좋아! 조조Just 두고 봐."')
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(73).setDir(stage.countDir(73, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(0).setDir(stage.countDir(0, 72))
        stage.say('&0\n쳇, 새로운 지원군이 도착했다!\n상황이 좋지 않아 보인다.\n잠시 검문소로 돌아가 몸을 숨길까?')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.unit(69).setAction(5)
            stage.say('&69\n산적 병사들이 뒤에서 공격하게 놔둬!\n탈출로를 차단하고, 포위조조!')
            stage.unit(69).setAction(0)
        stage.unit(59).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(60).show()
        stage.unit(321).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(59).setDir(stage.countDir(59, 0))
        stage.say('&60\n원래는 인력을 더 많이 고용하려고 했는데,\n하지만 아마도 지지 않을 것 같다.\n이번에는 좀 편하게 해도 되겠죠?\n&59\n나, 왕핑은 이곳 지리적 환경에 익숙하다!\n조조도 매복은 찾지 못했다.')
        stage.unit(0).setDir(stage.countDir(0, 59))
        stage.unit(0).setAction(10)
        stage.say('&0\n오, 안 돼!\n탈출로가 막히자 도망칠 곳이 없었다.')
        if not vars[50]:
            stage.say('&35\n도망치지 못하게 해.\n오늘, 조조 이곳에 묻힐 거야!')
        if not vars[54]:
            stage.say('&69\n어서! 죽여조조!')
        stage.setAI(9, 12, 24, 31, 2, 1)
        vars[6] = 1
    if not vars[7] and stage.curCamp() == 2 and stage.totalRectUnit(2, 11, 7, 24, 11) < 10:
        if not vars[59]:
            stage.say('&37\n쳇!\n후퇴!')
            vars[7] = 1
        if not vars[52]:
            stage.say('&50\n나를 따라잡을 수 있겠어?\n쳇, 쳇, 내 마수의 가장 빠른 킥은 세상에서 제일 좋아,\n그들을 쫓아다니는 건 소용없어.')
            vars[7] = 1
        stage.setAI(11, 7, 24, 11, 2, 4, -1, 17, 20)
        stage.unit(50).setAI(6, -1, 16, 20)
        stage.unit(37).setAI(6, -1, 17, 20)
        if vars[7] and stage.unitStateTest(19, 7, 1, 0):
            stage.unit(19).setDir(stage.countDir(19, 0))
            stage.say('&19\n상황은 분명히 너무 이상했다,\n왜 그렇게 빨리 물러났어,\n사기일 수도 있을까요......')
            stage.unit(0).setDir(stage.countDir(0, 19))
            stage.say('&0\n이제 청두가 바로 앞에 있는데, 어떻게 가볍게 물러설 수 있겠습니까?\n속임수가 있다는 걸 알면서도, 앞으로 나아갈 수 있는 유일한 길은 앞으로 나아가는 것뿐이었다.\n조심해서 진행하세요!')
        vars[7] = 1
    if not vars[6] and not vars[8] and stage.totalRectUnit(2, 15, 18, 18, 19) < 6:
        stage.unit(53).setAI(0)
        stage.unit(66).setAI(0)
        stage.unit(382).setAI(0)
        stage.unit(383).setAI(0)
        stage.unit(390).setAI(0)
        stage.unit(391).setAI(0)
        vars[8] = 1
    if vars[6] and not vars[30] and stage.totalRectUnit(2, 9, 12, 24, 27) < 6 and stage.isInRect(1025, 4, 18, 10, 23) and stage.curCamp() == 2:
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n어떻게 내가 나를 공명 태만할 수 있지?\n모든 것이 밀접하게 연결되어 있을 때만 전략이 진정으로 효과를 낼 수 있습니다!\n2단계, 출발!')
            stage.unit(35).setAction(0)
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.unit(69).setAction(5)
            stage.say('&69\n료화! 우이!\n마지막 일격조조 날려라!')
            stage.unit(69).setAction(0)
        stage.unit(44).show()
        stage.unit(324).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(61).show()
        stage.unit(327).show()
        stage.unit(328).show()
        stage.unit(329).show()
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.say('&44\n조조, 네 죽음이 왔다!\n&61\n이 군대들도 아직 이길 수 있지?\n좋아! 먼저 공격조조 해보자!')
        stage.unit(0).setDir(stage.countDir(0, 61))
        stage.unit(0).setAction(5)
        stage.say('&0\n음, 또 매복이 왔어!\n빨리 고개를 점령하고 포위망을 돌파하라!')
        if not vars[50]:
            stage.say('&35\n네가 성공하게 두지 않을 거야.\n조조 꽉 둘러!')
        if not vars[51]:
            stage.say('&34\n나도 싸울 거야!')
        stage.setAI(25, 12, 29, 28, 2, 0)
        stage.unit(34).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        if not vars[54]:
            stage.unit(69).setAction(2)
            stage.say('&69\n계속 가!\n조금만 더 버텨!')
        if not vars[60]:
            stage.say('&54\n승리가 코앞에 있다!\n여러분, 최선을 다해 주세요!')
        stage.setAI(4, 12, 8, 28, 2, 0)
        vars[30] = 1
        vars[31] = 1
    if vars[6] and not vars[31] and stage.totalRectUnit(2, 9, 12, 24, 27) < 6 and stage.isInRect(1025, 23, 18, 29, 23) and stage.curCamp() == 2:
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n어떻게 내가 나를 공명 태만할 수 있지?\n모든 것이 밀접하게 연결되어 있을 때만 전략이 진정으로 효과를 낼 수 있습니다!\n2단계, 출발!')
            stage.unit(35).setAction(0)
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.unit(69).setAction(5)
            stage.say('&69\n료화! 우이!\n마지막 일격조조 날려라!')
            stage.unit(69).setAction(0)
        stage.unit(44).show()
        stage.unit(324).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(61).show()
        stage.unit(327).show()
        stage.unit(328).show()
        stage.unit(329).show()
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.unit(61).setDir(stage.countDir(61, 0))
        stage.say('&44\n조조, 네 죽음이 왔다!\n&61\n이 군대들도 아직 이길 수 있지?\n좋아! 먼저 공격조조 해보자!')
        stage.unit(0).setDir(stage.countDir(0, 61))
        stage.unit(0).setAction(5)
        stage.say('&0\n음, 또 매복이 왔어!\n빨리 고개를 돌파하고 적군 포위망을 돌파하라!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.say('&35\n조조 도망칠 수 없어!\n검문소 방어를 강화해!')
        if not vars[51]:
            stage.unit(34).setAction(2)
            stage.say('&34\n절대 못 지나가게 할 거야!')
        stage.setAI(25, 12, 29, 28, 2, 0)
        if not vars[54]:
            stage.say('&69\n우리도 싸우자!\n모두 더 열심히 나가자!')
        if not vars[60]:
            stage.say('&54\n승리가 코앞에 있다!\n서둘러 돌격해!')
        stage.setAI(4, 12, 8, 28, 2, 0)
        stage.unit(69).setAI(1)
        stage.unit(54).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        vars[30] = 1
        vars[31] = 1
    if not vars[2] and not vars[32] and stage.isInRect(0, 0, 18, 1, 23):
        stage.resumeCtrl()
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(4)
            stage.say('&35\n안 돼! 방어선이 뚫렸어!\n이로 인해 그들은 청두로 후퇴해 그들과 맞설 수밖에 없었다......\n정말 안타깝네요.')
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n물러나야 할까요...... 후회합니다!\n마침내 생사가 걸린 순간이었다.\n청두는 그들에게 빼앗겨서는 안 된다!')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n음, 흠, 이제 청두가 진짜 위험에 처했어!\n즉시 청두로 철수하라!')
        if not vars[60]:
            stage.unit(54).setDir(stage.countDir(54, 0))
            stage.say('&54\n도둑조조Old 있어...... 그가 내 검각을 뚫었어......\n선택의 여지가 없어, 후퇴해!\n청두를 지켜야 해......')
        stage.setRectUnitHide(0, 0, 35, 31, 2)
        vars[32] = 1
        stage.say('좋습니다. 남은 것은 오직 성두뿐입니다!\n전력을 준비하여 성도를 공격합니다!')
        if vars[50]:
            stage.reward(0, [
                142,
                -1,
                49,
                -1])
        else:
            stage.reward(0, [
                142,
                -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[640] = 1
        return True
    if vars[2] and not vars[33] and stage.isInRect(0, 34, 18, 35, 23):
        stage.resumeCtrl()
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(4)
            stage.say('&35\n아니, 방어가 뚫렸어!\n이로 인해 그들은 청두로 후퇴해 그들과 맞설 수밖에 없었다......\n정말 안타깝네요.')
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n물러나야 할까요...... 후회합니다!\n마침내 생사가 걸린 순간이었다.\n청두는 그들에게 빼앗겨서는 안 된다!')
        if not vars[54]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.say('&69\n음, 흠, 이제 청두가 진짜 위험에 처했어!\n즉시 청두로 철수하라!')
        if not vars[60]:
            stage.unit(54).setDir(stage.countDir(54, 0))
            stage.say('&54\n도둑조조Old 있어...... 그가 내 검각을 뚫었어......\n선택의 여지가 없어, 후퇴해!\n청두를 지켜야 해......')
        stage.setRectUnitHide(0, 0, 35, 31, 2)
        vars[33] = 1
        stage.say('&0\n좋아! 이제 청두만 남았어!\n전 군대가 청도를 공격할 준비를 하고 있다!')
        if vars[50]:
            stage.reward(0, [
                142,
                -1,
                49,
                -1])
        else:
            stage.reward(0, [
                142,
                -1])
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[640] = 1
        return True
    if not vars[40] and stage.isNear(7, 61, False):
        stage.unit(7).setDir(stage.countDir(7, 61))
        stage.unit(61).setDir(stage.countDir(61, 7))
        stage.say('&7\n이렇게 비열한 기습 전술을 쓰다니!?\n&61\n흥! 전쟁에 비열한 존재는 없어!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 35, True):
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.say('&35\n결국 적군이 여기까지 쳐들어오게 했군.\n나와 싸우고도 이곳까지 올 줄은 몰랐다……\n&0\n천하를 평정하고 법을 엄격히 시행하는 것이 내 꿈이다.\n누구도 막을 수 없다.\n&35\n나는 선주 유비에게 후사를 부탁받았으니,\n오직 승리할 뿐 패배할 수 없다.')
        vars[41] = 1
    if not vars[42] and stage.isNear(19, 69, True):
        stage.unit(19).setDir(stage.countDir(19, 69))
        stage.unit(69).setDir(stage.countDir(69, 19))
        stage.say('&69\n내 이름은 장웨이니까 잘 기억해 줘.\n&19\n오, 위엄 있는 외모에 위엄 있고 위압적이었다.\n네 계략이 공명만큼 영리하다고 들었어,\n하지만 그가 내 사마의와 맞을지 궁금해요.\n&69\n곧 알게 될 거야.')
        vars[42] = 1
    if not vars[43] and stage.isNear(19, 53, True):
        stage.unit(53).setDir(stage.countDir(53, 19))
        stage.unit(19).setDir(stage.countDir(19, 53))
        stage.say('&53\n넌 조조 전략가 같아 보여,\n만약 나를 만나면, 관싱, 운이 없다고 생각해.\n&19\n아마 관우 아들이지?\n하하하, 아버지는 당신만큼 권위가 있는 편은 아닌 것 같네요.\n&53\n뭐라고 했어!\n&19\n봐, 누군가 그 말을 하면 너는 흥분하지.\n&53\n응......')
        vars[43] = 1
    if not vars[44] and stage.isNear(19, 71, True):
        stage.unit(71).setDir(stage.countDir(71, 19))
        stage.unit(19).setDir(stage.countDir(19, 71))
        stage.say('&71\n너를 괴물의 입으로 만들고 싶어!\n&19\n그럼 남부 야만인이었나요?\n다가오는 슈 왕국과 함께 죽을 필요는 없었다!')
        vars[44] = 1
    if not vars[45] and stage.isNear(17, 72, False):
        stage.unit(72).setDir(stage.countDir(72, 17))
        stage.unit(17).setDir(stage.countDir(17, 72))
        stage.say('&72\n내가 널 어떻게 봐도 넌 역겨워 보여.\n&17\n저도 그렇게 생각해요.\n&72\n흥! 입이 참 좋네요!')
        vars[45] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n그는 더 이상 조조을 견딜 수 없었다.\n안타깝게도, 슈의 운명은......\n&35\n아니, 지금 포기하면 끝이야.\n비록 그들이 후퇴했지만, 희망의 빛이 여전히 남아 있었다.')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n아니야...... 난 정말 쓸모없어.\n후퇴......')
        stage.unit(34).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n흠, 미끼 임무는 완수되었다.\n나도 물러나야겠어!')
        stage.unit(50).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(59, 7, 0, 2):
        stage.say('&59\n더 이상 버틸 수 없어, 후퇴해!')
        stage.unit(59).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n철회가 필요한가요?\n정말 안타깝네요......')
        stage.unit(69).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n아이고!\n후퇴, 후퇴!\n복수하러 올 거야!')
        stage.unit(71).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n아파!\n무슨 일이야!?\n쳇, 우리가 패배했어! 후퇴!')
        stage.unit(73).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n젠장! 어떻게 감히 나한테 무례할 수 있어?\n후회하게 만들 거야.\n이걸 기억해. 후퇴!')
        stage.unit(72).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(66, 7, 0, 2):
        stage.say('&66\n음, 이거 기억조조 있지!\n오늘은 일단 봐줄게,\n다음에 나를 만나면 네 사형선고가 될 거야!')
        stage.unit(66).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n음, 정말 받을 수 없어.\n다음번엔 그렇게 쉽지 않을 거야!')
        stage.unit(37).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(54, 7, 0, 2):
        stage.say('&54\n후퇴! 후퇴!\n다음번이 있을 거야.')
        stage.unit(54).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(53, 7, 0, 2):
        stage.say('&53\n아-아, 안 돼!\n예상치 못하게도 이 중요한 순간에 그들은 후퇴했다......')
        stage.unit(53).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(60, 7, 0, 2):
        stage.say('&60\n최선을 다한 것 같아요.\n왜 이렇게 됐는지 정말 모르겠어요......\n후퇴!')
        stage.unit(60).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n아! 후퇴!\n먼저 청두로 돌아가려고!')
        stage.unit(57).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n쳇, 계산 착오......\n미안, 나 지금 가볼게!')
        stage.unit(58).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(44, 7, 0, 2):
        stage.say('&44\n음, 너무 부주의했어.\n후퇴!')
        stage.unit(44).hide(1)
        vars[65] = 1
    if not vars[66] and stage.unitStateTest(61, 7, 0, 2):
        stage.say('&61\n와아......\n후퇴, 후퇴, 빨리 후퇴!')
        stage.unit(61).hide(1)
        vars[66] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 제거했어!\n아군 이겼어!')
        if vars[50]:
            stage.reward(0, [
                142,
                -1,
                49,
                -1])
        else:
            stage.reward(0, [
                142,
                -1])
        stage.end()
        vars[0] = 1
        vars[640] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 류산의 군대 앞에서 큰 패배를 겪었으나 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
