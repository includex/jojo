# Source Generated with Decompyle++
# File: R_31.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            8,
            58,
            70],
        [
            15,
            64,
            70],
        [
            13,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            159,
            52,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setEventName('시량 브로케이드 마초')
    stage.setStageName('서두, 총리 관저')
    if vars[309]:
        stage.say('&0\n쯔젠, 통궤 테라스는 완성됐어?\n&159\n네! 아버지가 점검하길 기다리고 있어요.\n&0\n정말? 정말 잘했어.\n이번 시간은 정말 칭찬받을 만합니다!\n&159\n감사합니다, 아버지.\n그런데 아버지, 저와 함께 예성에 가실 건가요?\n&0\n음, 예시로 가는 거지...... 맞지?\n순욱, 네가 가서 확인해 봐.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(159).setAction(0)
        stage.say('&159\n응?\n아버지 안 가세요?')
        stage.unit(20).setAction(6)
        stage.say('&20\n상속자가 순욱에 불만이 있나?')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(159).setAction(0, 0)
        stage.say('&159\n아니...... 아니, 그건 사실이 아니야......\n조지는 그런 뜻이 아니었다, 그냥 ......')
        stage.unit(0).setAction(3)
        stage.say('&0\n원허, 각 지역의 영주들에게 알리라,\n예를 들어 통곡 테라스를 보자.\n이번에는 최대한 웅장하게 만들고 싶어 했다.')
        stage.unit(23).setAction(6)
        stage.say('&23\n네.\n알겠습니다.')
        stage.unit(23).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0)
        stage.say('&0\n자젠, 영토가 통일된 후,\n다시 청동 참새 테라스로 올라가게 해줘,\n지금은 그럴 때가 아니야.')
        stage.unit(159).setAction(0, 3)
        stage.say('&159\n알겠습니다.')
        stage.unit(159).setAction(0, 0)
        stage.say('&159\nSo순욱 선생님, 제발요.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        stage.unit(20).setAction(0)
        stage.delay(3)
    if not vars[309]:
        stage.say('&0\n쯔젠, 청동 참새 테라스를 지었다고 들었어?\n청동 참새 테라스 건설 비용,\n이 돈은 정부 자금에서 조달되어야 합니다.')
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('국가의 자금은 사적인 용도로 쓸 수 없어. 이해 못 하는 건가!\n아버지, 화내지 마세요. 제가 관자재를 사용한 게 아니라, 이건 전부 순욱 선생님의……')
        stage.unit(20).setAction(6)
        stage.say('&20\n주군, 청동 참새 테라스 건설 비용,\n이 모든 것은 부하들의 사유 재산에서 나옵니다.\n안심하세요this주군')
        stage.unit(20).setAction(0)
        stage.say('&20\n주군, 법정 상속인은 잘못이 없습니다.\n모든 책임은 문약가 지게 될 거야.')
        stage.delay(10)
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&0\n흠, 그러니까 범죄는 없다는 거야?\n좋아, 뒤로 물러서!\n이번에는 더 이상 추격하지 않을 것이다—다시는 하지 않을 것이다.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네, 감사합니다주군.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(23).setAction(6)
        stage.say('&23\n주군, 청동 참새 플랫폼은 어떻게 다뤄야 할까요?\n철거해야 할까요?')
        stage.unit(23).setAction(0)
        stage.say('&0\n이미 지어진 상태였기에 더 이상 할 수 있는 일이 없었다.\n그냥 그대로 두세요.\n그런데 갑자기 아이디어가 떠올랐습니다.')
        stage.unit(0).setAction(3)
        stage.say('&0\n원허, 각 지역의 영주들에게 알리라,\n예를 들어 통곡 테라스를 보자.\n이번에는 최대한 웅장하게 만들고 싶어 했다.')
        stage.unit(0).setAction(0)
        stage.say('&23\n응?')
        stage.unit(23).setAction(6)
        stage.say('&23\n알겠습니다. 네! 이해했습니다.')
        stage.unit(23).setAction(0)
        stage.delay(3)
        stage.unit(159).setAction(0)
        stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(20),
            52,
            34,
            0],
        [
            stage.unit(23),
            58,
            34,
            0],
        [
            stage.unit(159),
            58,
            55,
            1]])
    stage.unitsMove([
        [
            stage.unit(20),
            80,
            34,
            1],
        [
            stage.unit(23),
            80,
            34,
            1],
        [
            stage.unit(159),
            98,
            55,
            1]])
    stage.unit(159).hide()
    stage.unit(20).hide()
    stage.unit(23).hide()
    stage.say('&0\n중더, 유비가 징저우를 점령했다고 들었어.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n유비Ever 이 사람이 전략가 공명을 가지고 있었으니,\n그 나무는 번성하며 더 강해진 것 같았다.\n공명 정말 실력이 있네요!')
    stage.unit(21).setAction(0)
    stage.say('&21\n주군 유비의 존재를 과소평가해서는 안 됩니다.\n그렇지 않으면 해만 남고 이익은 없을 것입니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n알아.\n그런데 그 후에 주유는 어떻게 됐어?\n아직도 누워 계신가요?')
    stage.unit(21).setAction(6)
    stage.say('&21\n아니, 이미 군대에 복귀한 것 같아.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n좋아, 네 회복을 축하할게, 주유\n그를 징저우에서 장하 주지사로 임명하게 하라.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0)
    stage.say('&21\n주유 ...... 공식 명칭? 아, 그렇군요.\n주유 공식 직책을 부여해 그가 공명를 처리할 수 있게 해!')
    model.setFace(0)
    stage.say('맞습니다. 즉시 조정에 상주해야 합니다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네!')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(21).move(95, 40, 1)
    stage.unit(21).hide()
    stage.say('&0\n주유 그리고 공명......\n이 둘은 너무 위험해.\n먼저 한 명을 제거해야 합니다.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 336, 98)
    stage.showHead(32, 274, 228)
    stage.showHead(76, 567, 217)
    stage.bottomTxt('조조 법원의 승인을 요청합니다,', False, False, False)
    stage.delay(5)
    stage.showHead(77, 338, 228)
    stage.delay(5)
    stage.bottomTxt('주유 강하 행정관으로 임명되었다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('유비와 손권 간의 징저우 다툼이 격화되었다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('양측 간의 투쟁의 결과입니다', True, True, False)
    stage.delay(5)
    stage.head(77).hide()
    stage.delay(5)
    stage.bottomTxt('주유 죽었고,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('유비 징저우를 완전히 통제하고 있었다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            24,
            52,
            40,
            2],
        [
            21,
            58,
            40,
            2]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n공명 영리하고 수완이 뛰어났기 때문에,\n결국 유비 징저우 전투에서 승리했다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n주유 이 기간 동안 피를 토하며 사망하기도 했다.')
    stage.unit(21).setAction(0)
    stage.say('&0\n정말......\n알고 보니 공명 여전히 한 단계 위주유.')
    stage.effectSound(201, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('조금 놀랍네요\n역시 그렇다', 0)
    if sel == 1:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('&0\n조금 놀랍네요.\n&20\n주군 항상 주유가 더 강하다고 생각했지?\n&0\n흠,\n저도 가끔 실수를 한 적이 있어요.')
    elif sel == 2:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('&0\n흠, 예상대로네요.\n가장 무서운 것은 여전히 공명입니다.')
    stage.unit(24).setAction(6)
    stage.say('&24\n방통 유비의 부전략가로도 일했다고 들었어.')
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n뭐라고? 방통!\n&24\n더 이상 유비 방치할 수 없어,\n즉시 처리해야 했다.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n흠.')
    stage.showUnit(181, 90, 55, 3)
    stage.say('&181\n신고됐어.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 시량의 마텅이 주군를 청했다,\n이제 밖에서 기다리고 있어.\n&0\n마텡?\n오, 들여보내.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.unit(21).setAction(0)
    stage.say('&21\n마텡은 시량군의 지휘관이었다.\n왜 수도에 왔지......')
    stage.showUnit(138, 90, 55, 3)
    stage.say('&138\n총리님께 경의를 표하러 왔다.')
    stage.unit(138).move(52, 55, 3)
    stage.delay(3)
    stage.unit(138).setAction(6)
    stage.say('&138\n말에서 내려 말을 타고 떠났다.\n&0\n저는 조맹덕입니다.\n마 텅 장군이 딱 맞는 시기에 나타났다.\n&138\n네.\n재상의 청동 참새 테라스가 완공되었다고 들었어,\n특별히 축하 인사를 전하러 왔습니다.\n&0\n정말?\n장군께서 호의를 보여주셔서 진심으로 감사드립니다.\n장군의 먼지를 씻기 위해 말을 타고 연회를 열 것이다.\n&138\n마텡은 깊이 감사했다.\n하지만 총리의 환대를 받기 전에,\n마텡은 폐하께 경의를 표하러 가길 바랐다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n아, 조가 잠시 부주의했어.\n말을 타고 전하께 장군께 보고하겠습니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n그때 장군이 그를 맞이할 장소가 마련될 것이다,\n잠시만 기다려 주십시오, 장군님.\n&138\n네.\n그럼 저는 이만 가보겠습니다.')
    stage.unit(138).setAction(0)
    stage.delay(3)
    stage.unit(138).move(95, 55, 1)
    stage.unit(138).hide()
    stage.unit(24).setAction(6)
    stage.say('&24\n주군, 마텡이 유비를 공격하게 하는 건 어때?')
    stage.unit(24).setAction(0)
    stage.say('&0\n마텅을 ...... 보내줄까?\n아니, 아직 그를 믿을 수 없어.\n&0\n중더, 마텡의 면담 준비하러 가,\n하지만 그의 행동을 감시할 스파이를 배치해야 했다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.')
    stage.unit(24).setAction(0)
    stage.say('&24\n마튼을 모니터링할 계획이신가요?\n&0\n그가 청동 참새 테라스를 기념하려고 한 건 아니라고 생각해요,\n그는 방금 시리량에서 쉬두까지 먼 길을 왔다.')
    stage.delay(3)
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(12)
    stage.delay(3)
    stage.loadBg(2, 15)
    stage.showUnits([
        [
            149,
            27,
            55,
            1],
        [
            138,
            46,
            55,
            3,
            6],
        [
            192,
            46,
            43,
            2],
        [
            193,
            52,
            43,
            2]])
    stage.draw()
    stage.setStageName('쉬두궁')
    stage.delay(3)
    stage.unit(192).setAction(6)
    stage.say('&192\n폐하, 시량의 마텅이 조문하러 오셨습니다.')
    stage.unit(192).setAction(0)
    stage.say('&149\n오, 마 아이칭!\n드디어 왔구나.\n오랫동안 기다렸어요.\n&138\n예, 폐하.')
    stage.unit(192).setAction(6)
    stage.say('&192\n마 장군님, 쉬두에 도착한 이후로,\n폐하께서는 한 번도 행복하지 않으셨습니다.')
    stage.unit(192).setAction(0)
    stage.say('&149\n류황서는 멀리 징저우에 있어 여기 올 수 없어,\n봉건 영주들은 통치자에 대한 충성도, 나라에 대한 사랑도 없습니다.\n나는 명망 높은 마 가문에만 희망을 걸 수밖에 없다.')
    stage.unit(138).setAction(0)
    stage.say('&138\n폐하께서 왜 그렇게 말씀하시는가? 그럴 수도 있조조......\n&149\n처음에는 나도 그를 믿었어,\n하지만 그가 수년간 해온 일을 보면,\n그는 더 이상 그를 믿지 않았다.\n&149\n나는 조조 군주에 대한 충성심이 없다고 믿는다.')
    stage.unit(138).setAction(6)
    stage.say('&138\n알겠습니다.\n내 마음은 이미 정해졌어.')
    stage.unit(138).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n마 장군님, 무슨 생각이 있으신가요?')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(138).setAction(0, 0)
    stage.say('&138\n네.\n마텡은 황제의 의도를 이해하고 오래전부터 행동할 준비를 해왔다.')
    stage.unit(192).setAction(3)
    stage.say('&192\n오!\n마 장군이 말씀하시길......')
    stage.unit(138).setAction(6)
    stage.say('&138\n네.\n저는 반드시 전하를 제거하고 폐하를 구출할 조조 결심했습니다.')
    stage.unit(138).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(0)
    stage.say('&192\n하지만 ...... 하지만 장군이 정말로 조조를 제거할 수 있을까?\n만약 실패하면.........\n&138\n걱정할 필요 없어.\n아직도 조조 무슨 생각을 했는지 모르겠어요.')
    stage.unit(138).setAction(3)
    stage.say('&138\n그냥 시량을 지키는 군대를 소집해라,\n그때 궁 안팎에서 동시에 군대가 동원되어 양쪽에서 공격할 것이다,\n조조 단순히 맞지 않는다.')
    stage.unit(138).setAction(0)
    stage.say('&193\n그래서 그런 거야.')
    stage.unit(192).setAction(0, 3)
    stage.delay(3)
    stage.unit(192).setAction(6)
    stage.say('&192\n폐하...... 폐하! 우리는 마침내 우리가 바라던 것을 이루었습니다......\n&149\n마텡!\n조조의 손아귀에서 나를 구해줄 수 있길 바래.')
    stage.unit(138).setAction(0, 3)
    stage.delay(3)
    stage.unit(138).setAction(6)
    stage.say('&138\n안심하십시오, 폐하.\n&138\n그럼 즉시 진영으로 돌아가겠습니다,\n병력 모집 준비,\n먼저 가서 죄송합니다.\n&149\n흠, 결국 네가 결정해. 마 아이칭......')
    stage.unit(138).setAction(0)
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(0, 2)
    stage.unit(138).move(95, 55, 1)
    stage.unit(138).hide()
    stage.say('&149\n마텡이 정말 저를 없앨 수 있을조조......\n실패하면 .........')
    stage.unit(192).setAction(6)
    stage.say('&192\n…… 폐하, 안심하십시오.')
    stage.unit(192).setAction(0)
    stage.say('&193\n아, 맞다!\n마 장군은 아직 조나라 군대의 내부 이야기를 모른다......')
    stage.unit(193).setAction(6)
    stage.say('&193\n폐하, 즉시 가서 마 장군께 알리겠습니다,\n다음은 조조 군대에 대한 상세한 배경입니다.\n&149\n흠, 흠. 빨리 가.\n&193\n네.')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(193).move(76, 43, 1)
    stage.say('&193\n(마텡은 정말 악의를 품고 있다......\n즉시 정욱 씨에게 보고해야 합니다. )')
    stage.unit(193).move(90, 43, 1)
    stage.unit(193).hide()
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말? 마텡의 목표가 우리를 제거하는 거야?')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.\n더욱이 그는 시량군을 모집하고자 했다,\n때가 되면 그들은 안팎에서 공격할 것이다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n주군, 즉시 행동해야 합니다.')
    stage.unit(24).setAction(0)
    stage.say('&0\n알아.\n그들은 단지 숨겨진 정치적 적들을 밝혀내고 싶었을 뿐입니다.\n그래서 원허에게 청동 참새 테라스를 널리 홍보하게 했어요.')
    stage.unit(23).setAction(6)
    stage.say('&23\n마 텅은 정말 예상대로였다,\n그는 주군의 함정에 빠졌다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n하지만 적이 안과 밖에서 공격한다면,\n이 문제는 매우 까다로울 것입니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n우리는 즉시 행동해야 합니다.\n주군, 마텡을 잡자.')
    stage.unit(21).setAction(0)
    stage.say('&0\n흠.........')
    stage.effectSound(201, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('그리고 마텅에게 그를 참수하라고 명령했다\n그는 마텡을 감금했다', 0)
    if sel == 1:
        vars[311] = 1
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('&0\n중더는 마텡을 경락문으로 호위하고 참수했다.\n그를 이 세상에 살게 하지 마!\n폐하께서는 당분간 이 문제를 더 이상 추궁하지 마십시오.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n네.\n즉시 처리하러 가겠습니다.')
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(21).move(95, 40, 1)
        stage.unit(21).hide()
        stage.say('&0\n문허, 너는 한때 장안에서 마텡 군대를 물리쳤지,\n그의 부대에 대해 어떻게 생각하십니까?')
        stage.unit(23).setAction(6)
        stage.say("&23\n서량군의 전투력은 과소평가해서는 안 된다,\n특히 마텅의 아들, 마초,\n만 명의 병사가 견줄 수 없는 용기를 지녔다.\n&0\n마초I 이 이름도 들어봤어,\n'서량 비단 마초'이라고 불리는 것 같습니다.\n그는 뛰어난 무술을 가진 젊은 장군이다.\n&23\n네. 저는 대규모 군대를 동원하는 것이,\n마초가 이끄는 시량군과 싸우며,\n이 움직임은 정말 형편없는 전략이었다; 현명하게 행동하는 것이 더 나았다.\n&0\n좋아.\n군대 전체가 대기 태세에 들어갔다.\n마초...... 아! 정말 기대할 만한 일이네.")
    elif sel == 2:
        vars[311] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(201, 0)
        stage.delay(3)
        stage.say('&0\n정욱, 마릉을 대감옥에 가두시오.')
        stage.unit(21).setAction(6)
        stage.say('&21\n응......?')
        stage.delay(5)
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(21).move(76, 40, 1)
        stage.say('&21\n(주군 모르는 듯하다,\n마텅은 위험한 사람이야,\n완전히 근절되어야 합니다! )')
        stage.unit(21).move(95, 40, 1)
        stage.unit(21).hide()
        stage.info('end정욱 마텡은 감옥에 갇히지 않았다,\n대신 그는 마텡을 죽이기로 결심했다.\n조조 이 사실을 알게 된 후 깊이 후회했다,\n그는 엄숙히 마텡의 시신을 시량으로 돌려보냈다.')
        stage.say('&0\n문허, 너는 한때 장안에서 마텡 군대를 물리쳤지,\n그의 부대에 대해 어떻게 생각하십니까?')
        stage.unit(23).setAction(6)
        stage.say("&23\n시량 군대의 전투력은 과소평가해서는 안 된다,\n특히 마텅의 아들, 마초,\n만 명의 병사가 견줄 수 없는 용기를 지녔다.\n&0\n마초I 이 이름도 들어봤어,\n'서량 비단 마초'이라고 불리는 것 같습니다.\n그는 뛰어난 무술을 가진 젊은 장군이다.\n&23\n네. 저는 대규모 군대를 동원하는 것이,\n마초가 이끄는 시량군과 싸우며,\n이 움직임은 정말 형편없는 전략이었다; 현명하게 행동하는 것이 더 나았다.\n&0\n좋아.\n군대 전체가 대기 태세에 들어갔다.\n마초...... 아! 정말 기대할 만한 일이네.")
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('...... 반달 후에.', 3)
    stage.setStageName('서두, 총리 관저')
    stage.showUnit(181, 90, 55, 3)
    stage.say('&181\n보고해!')
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 시량군이 위하를 공격했다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n저기 온다고?\n좋아! 우리도 위수이로 가자.\n시량군을 만나라!')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 330, 129)
    stage.bottomTxt('마텡의 아들', False, False, False)
    stage.showHead(57, 50, 0)
    stage.bottomTxt('마초 시량군을 이끌었고,', True, False, False)
    stage.delay(5)
    stage.head(57).move(176, 83)
    stage.delay(5)
    stage.bottomTxt('남쪽으로 향하며 곧장 쉬두를 겨냥했다.', True, False, False)
    stage.delay(8)
    stage.head(0).move(240, 83)
    stage.delay(5)
    stage.bottomTxt('조조 군대를 위하까지 진격시켜 그들을 차단한다.', True, True, True)
    stage.bgSound(15)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            12,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            23,
            64,
            58,
            3],
        [
            24,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('위수이 @조조군의 본진')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 13, [
        12,
        13,
        23,
        15], [
        2,
        10,
        11])
    gvars[4076] = 0
    gvars[4057] = 31
    stage.setBattlePos([
        [
            8,
            5],
        [
            18,
            29],
        [
            18,
            30],
        [
            8,
            1],
        [
            9,
            1],
        [
            17,
            30],
        [
            8,
            6],
        [
            18,
            28],
        [
            9,
            6],
        [
            19,
            29],
        [
            7,
            6],
        [
            17,
            31],
        [
            9,
            5],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene6():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 지형을 설명해 주세요.\n&20\n네.\n서량군의 사슴 요새는 큰 강으로 둘러싸여 있었다.\n&20\n그 외에는 뚜렷한 특징이 없습니다.\n까다로운 점은 전장이 눈으로 덮여 있었다는 것이다.\n&0\n스노우? 이거 골치 아플 거야.\n&20\n네.\n이로 인해 빠르게 움직이는 것이 불가능해집니다.')
    if stage.unitClickTest(12):
        stage.say('&0\n자샤오, 너와 서황 측면을 포위해 시량군 후방으로 후퇴해야 해.\n알겠어?\n&12\n네.')
    if stage.unitClickTest(15):
        stage.say('&15\n기다리느라 주먹과 발이 근질거리다.\nPlease주군 마초와 멋진 배틀을 하도록 해.')
    if stage.unitClickTest(1):
        stage.say('&1\n"시량 브로케이드 마초"?\n별거 아닌 것 같아.\n정말 그렇게 대단한가요?\n&23\n마초의 대담함은 부인할 수 없습니다.\n&1\n정말......?\n&0\n그가 꽤 잘생기고 잘생겼다고 들었어.\n원양의 모습을 본다면,\n모든 여자들이 도망가는 걸 봤어.\n&1\n맹덕!!\n&0\n하하하.\n농담이야, 농담이야.')
    if stage.unitClickTest(23):
        stage.say('&23\n주군, 마초만이 뛰어난 무술 실력을 가진 것은 아니었다.\n&23\n마초의 사촌 마다이, 그리고 방덕,\n그들은 모두 군대 중 가장 용감한 용맹한 장군들이었다.')
    if stage.unitClickTest(24):
        stage.say('&24\n이 시기에는 날씨가 나빠지는 경향이 있습니다,\n전략을 사용할 때는 신중해야 합니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
