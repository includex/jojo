# Source Generated with Decompyle++
# File: R_54.marshal (Python 3.9)


def scene0():
    '''서군은 북쪽으로 진격했다'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(50, 130, 221)
    stage.showHead(0, 194, 221)
    stage.bottomTxt('조조 슈 군대를 격파했고,', False, False, False)
    stage.delay(5)
    stage.head(50).hide()
    stage.head(0).move(162, 221)
    stage.delay(5)
    stage.bottomTxt('바이디 시티가 등장한다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setEventName('서군은 북쪽으로 진격했다')
    stage.setStageName('바이디 시 조조 본캠프')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n여전히 늦었습니다!\n예상치 못했습니다.공명이가 기도까지 완성하셨다니!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(2)
    stage.say('&1\n쳇, 유후푸에서 지연되지 않았다면,\n이번에는 절대 도망가지 못할 공명!')
    stage.unit(1).setAction(0)
    stage.say('&0\n중달,\n다른 제단들이 어디 있는지 못 찾았어?')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n네, 실례주군 용서해 주세요.\n&19\n하지만 붉은 절벽과 백황제성의 제단이 발견되었으니,\n조금만 더 시간을 줘......\n&0\n흠.\n중달, 수고해 주셔서 감사합니다.\n&19\n네.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n다음으로는 슈 군대의 움직임에 초점을 맞춰야 한다......')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n그들은 곧 첩보 보고서를 받을 예정이다.')
    stage.unit(20).setAction(0)
    stage.delay(5)
    stage.showUnit(181, 54, 22, 2)
    stage.say('&181\n주군!\n스파이들, 긴급 보고!')
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('전해졌다고요! 촉군은 지금 어디에 있습니까?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n서나라 군대는 청두에서 대규모 병력을 동원했다.\n그들은 북쪽으로 향해 검각에 모였다.')
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n젠거문은 산에 기대어 세워졌고,\n방어는 쉽지만 공격하기 어려운 거대한 패스입니다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n문약 이 패스에 대해서도 들어본 적이 있습니다,\n이곳을 공격하는 것은 분명 매우 어려울 것이다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흠......\n하지만 지금 이 순간, 어떻게 공격하지 않을 이유가 있겠는가?')
    stage.unit(0).setAction(17)
    stage.say('좋습니다. 전역에 통보합니다!\n건계를 향해 이동하세요!\n&181\n명령을 받겠습니다.')
    stage.unit(181).hide()
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 54
    stage.setBattlePos([
        [
            35,
            20],
        [
            35,
            21],
        [
            35,
            19],
        [
            35,
            22],
        [
            36,
            20],
        [
            36,
            21],
        [
            36,
            19],
        [
            36,
            22],
        [
            37,
            20],
        [
            37,
            21],
        [
            37,
            19],
        [
            37,
            22],
        [
            38,
            20],
        [
            38,
            21],
        [
            38,
            19]])
    return False


def scene1():
    if stage.battleTest():
        stage.say('&0\n출발!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n지건에는 북쪽, 동쪽, 서쪽의 세 개의 검문소가 있습니다.\n&20\n만약 아군 여기서 공격한다면,\n첫째, 동관의 저항에 직면하게 될 것이다.')
    if stage.unitClickTest(21):
        stage.say('&21\n전략가 유형 유닛만이 주홍색 새 보석을 장착할 수 있습니다.\n&21\n옥에 담긴 주홍새의 신성한 힘\n불꽃을 내뿜어 적군을 태울 수 있다.')
    if stage.unitClickTest(3):
        stage.say('&3\n관에게 선봉대를 이끌라고 명령해 주십시오,\n그는 분명히 총리에게 군사적 공로를 이룰 것이다.')
    if stage.unitClickTest(19):
        stage.say('&19\n(청두에서 북쪽으로 향하는 공명......\n즉, 나머지 두 제단은 북쪽에 위치해 있습니다. )\n&19\n(설두에 정말 다른 곳이 있을까...... )')
    if stage.unitClickTest(1):
        stage.say('&1\n원래 나는 슈가 산에서 매우 추울 줄 알았어,\n생각보다 더 따뜻해 보인다.')
    if stage.unitClickTest(17):
        stage.say('&17\n검각은 산속에 있지?\n장군 허저를 전투에 보내면 분명히 공로를 얻는 데 도움이 될 것이다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
