# Source Generated with Decompyle++
# File: R_49.marshal (Python 3.9)


def scene0():
    '''붉은 제단'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 57)
    stage.showUnits([
        [
            77,
            66,
            52,
            3],
        [
            35,
            52,
            52,
            1]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setEventName('붉은 제단')
    stage.setStageName('붉은 절벽: 오나라 군대의 본진')
    stage.delay(3)
    stage.unit(35).setAction(11)
    stage.say('&35\n…… 이 point조조 장링을 잡을 때가 되었다.\n그렇다면 우리의 진보도 가속화되어야 합니다.')
    stage.unit(35).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 2)
    stage.say('&77\n뜻밖에도, 시간을 벌기 위해,\n동오는 큰 대가를 치렀다,\n정말 한숨이 주유.\n&35\n나는 내 맹세를 이행했다,\n지금이 네가 서약을 지킬 때야.\n&35\n이제 징저우에 있던 대부분의 슈 군대가 당신에게 넘겨졌고,\n우리는 홍벽에서 조조의 군대를 막을 방법을 찾아야 합니다.')
    stage.unit(77).setAction(0, 3)
    stage.say('&77\n즉, 기도가 끝난 후,\n동오는 더 이상 가치가 없는가?\n&35\n그건 나한테 중요하지 않아.\n제단은 준비됐나요?')
    stage.unit(77).setAction(2)
    stage.say('&77\n내 주유 능력을 의심하느냐?\n한 번도 실패한 적 없어요.')
    stage.unit(77).setAction(0)
    stage.say('&35\n아, 그거 정말 무례하네.\n하지만 네가 예상하지 못한 것도 기억해,\n위나라 군대가 오나라를 공격하기 위해 매성으로 병력을 보낼 것인가?\n&77\n너도 똑같지 않아?')
    stage.unit(77).setAction(0, 2)
    stage.say('&77\n동오의 영토는 짐승들에게 짓밟혔고,\n그게 너무 싫어져요......\n하지만 이제 상황이 이렇게까지 왔으니, 그들이 할 수 있는 일은 없었다.')
    stage.unit(77).setAction(11)
    stage.say('&77\n꽃만이 꽃의 생각을 이해할 수 있다,\n하지만 꽃이 어떻게 짐승의 마음을 이해할 수 있겠는가!?\n&35\n음, 나한테는 제단이 장링보다 더 중요해,\n바로 준비를 시작해야 해.')
    stage.unit(35).move(16, 52, 3)
    stage.unit(35).hide()
    stage.delay(5)
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(0, 3)
    stage.say('&77\n흥! 공명 아직도 그가 누군지 몰라......\n그는 동우의 미래 졸개다.')
    stage.unit(77).setAction(0, 2)
    stage.say('&77\n하지만 위는 창을 우리 동무를 겨누고 있다,\n정말 잘 계획된 움직임이었다!\n영리하고 수완이 뛰어난 저조차도 이런 상황을 예상하지 못했습니다.\n&77\n흥! 괜찮아.\n괴물 같은 위나라 군대는 붉은 절벽에서 좌절할 것이다.\n&77\n이렇게 이 바보를 조조,\n그들은 공명 슈 왕국에 관심을 돌릴 것이다.')
    stage.unit(77).setAction(17)
    stage.say('&77\n위와 서는 대립 중이며, 동우는 그저 어부들의 이익을 누릴 수밖에 없습니다.\n이 모든 것은 동우의 미래를 위한 것입니다.')
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('장릉 조조 본대')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n윤창, 이번 연기 정말 뛰어났어.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 2)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n…… 관목의 마음은 아직도 만족하지 못한다.\n만약 주유와 공명가 죽지 않는다면,\n관의 마음속에 쌓인 원한을 떨쳐내기 어렵다.')
    stage.unit(3).setAction(0)
    stage.say('&0\n흠.')
    stage.showUnit(181, 54, 22, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n보고해!\n&181\n주군, 동우로 파견된 첩자가 군사 정보를 가져왔다,\n오나라 전함들이 붉은 절벽을 향해 집결하고 있었다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n뭐라고!?')
    stage.unit(0).setAction(0)
    stage.say('&181\n그 규모는 이전 붉은 절벽 전투를 훨씬 능가했다.')
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n파란 눈으로 아군의 시선을 장링에게 돌렸다,\n알고 보니 이건 치비를 완전히 준비하기 위한 것이었어!')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.delay(3)
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n뜻밖에도 그 규모는 붉은 절벽 전투보다도 더 컸다......\n진정으로 동부 오 해군이라 불릴 만한 존재였다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n그럼에도 우리는 물러서면 안 됩니다.\n레드 클리프스로도 가자.\n군대 전체가 출발 준비를 마쳤다!')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 263, 214)
    stage.bottomTxt('조의 군대', False, False, False)
    stage.delay(5)
    stage.head(0).move(315, 234)
    stage.delay(5)
    stage.bottomTxt('그들은 레드 클리프스를 향해 돌진했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 57)
    stage.showUnits([
        [
            76,
            66,
            52,
            3],
        [
            77,
            52,
            41,
            2],
        [
            78,
            46,
            41,
            2],
        [
            79,
            40,
            41,
            2],
        [
            80,
            52,
            63],
        [
            81,
            46,
            63],
        [
            84,
            40,
            63]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setStageName('붉은 절벽: 오나라 군대의 본진')
    stage.delay(3)
    stage.unit(77).setAction(6)
    stage.say('&77\n주군 위나라 군대와 맞서기 위한 준비가 이미 완료되었다.\n&77\n걱정주군 마세요.\n승리의 찬란한 빛,\n우리 동우를 위해 밝게 빛나고 있어.')
    stage.unit(77).setAction(0)
    stage.say('&76\n흠, 이 붉은 절벽 전투는,\n적군 우리 동오 해군의 힘을 알고 싶다.')
    stage.unit(77).setAction(3)
    stage.say('&77\n주군, 양쯔강의 흐르는 물소리를 들어주세요,\n그들은 또한 우리 동오 해군의 용맹함을 칭찬했다!')
    stage.unit(77).setAction(0)
    stage.say('&77\n(내 목표는 위가 슈를 향해 손가락질을 하게 만드는 것이다,\n그게 내가 바랄 수 있는 전부야. )')
    stage.unit(77).setAction(17)
    stage.say('&77\n(오직 하늘만이 내 뜻을 증인할 수 있다!)\n모두 동우를 위한 것이었다! )')
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 73)
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.showUnit(35, 95, 73, 3)
    stage.setEventName('주유 속았다')
    stage.setStageName('레드 클리프 외곽, 강가에 있습니다')
    stage.unit(35).move(57, 73, 3)
    stage.delay(3)
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n하하하, 레드 클리프에서의 기도는 끝났다.')
    stage.unit(35).setAction(11)
    stage.say('&35\n동부 오 함대는 붉은 절벽에 집결했다,\n이 위대한 전투는 계속될 것이다,\n조조 주유 중 하나가 쓰러질 때까지.\n&35\n모든 것이 이미 제 기대 안에 있었어요.')
    stage.unit(35).setAction(0)
    stage.say('&35\n이 기회를 빌어 다음 기도를 준비하겠습니다.\n&35\n하하하.')
    stage.unit(35).move(5, 73, 3)
    stage.unit(35).hide()
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            17,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            3,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('레드 클리프: 조조군의 주요 진영')
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n우리는 다시 레드 클리프스로 돌아왔다.\n이 전투는 과거의 원한을 갚아야 한다!')
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        19])
    gvars[4076] = 0
    gvars[4057] = 49
    stage.setBattlePos([
        [
            15,
            4],
        [
            16,
            4],
        [
            15,
            5],
        [
            16,
            5],
        [
            14,
            5],
        [
            17,
            5],
        [
            14,
            4],
        [
            17,
            4],
        [
            15,
            3],
        [
            16,
            3],
        [
            14,
            3],
        [
            17,
            3],
        [
            15,
            2],
        [
            16,
            2],
        [
            14,
            2]])
    return False


def scene5():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n전투에 임하라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n전장에는 양쯔강이 북쪽에, 땅이 남쪽에 있었다.\n&20\n오나라 군대는 육지와 수상 양쪽에 병력을 배치했을 것이다,\n이 싸움은 힘들 거야.')
    if stage.unitClickTest(19):
        stage.say('&19\n동오 해군이 주유 주둔하여 군대를 지휘했다.\n그들의 힘은 배가될 것이다,\n우리는 전혀 부주의해서는 안 됩니다.')
    if stage.unitClickTest(3):
        stage.say('&3\n맏형과 셋째 형은 주유에게 살해당했다,\n제주군 제가 주도하도록 해주세요.')
    if stage.unitClickTest(1):
        stage.say('&1\n레드 클리프에 도착하면 하루 종일 텐트에 있으면 안 돼.\n정면으로 부숴버릴 거야!')
    if stage.unitClickTest(15):
        stage.say('&15\n흠, 흠......\n&0\n허저, 무슨 일이야?\n몸이 안 좋으신가요?\n&15\n아니, 아무것도 아니야.\n붉은 절벽 전투 전에, 나는 기념품으로 시를 쓰고 싶었다.\n&1\n시를 쓰는 건가요?\n너!?\n하하하!\n&17\n헤헤헤......\n&15\n뭐가 그렇게 웃겨!?\n다들 뭐가 그렇게 웃겨!\n내가 시를 쓰는 게 뭐가 잘못된 걸까!?\n&0\n아니, 그게 잘못된 건 아니야.\n그리고 정말 큰 관심사입니다.\n알았어, 알았어, 전투 끝나고 가르쳐 줄게.\n&15\n네, 감사합니다주군!\n&0\n흠...... 훗, 하하하하!\n&15\n너무 많아, 너무 많아!\n주군도 나를 비웃어......')
    if stage.unitClickTest(17):
        stage.say('&17\n시마 씨는 아마 붉은 절벽 전투에 대해 모를 거야, 그렇지?\n&19\n사실 저는 이미 순욱 씨에게 전쟁의 전체 이야기를 물어본 적이 있습니다,\n저는 이미 대략적인 이해를 가지고 있습니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
