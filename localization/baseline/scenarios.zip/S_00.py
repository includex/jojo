# Source Generated with Decompyle++
# File: S_00.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,12)',
        '(13,13)',
        '(10,11)',
        '(9,11)'])
    stage.nearEvent([
        0,
        146,
        0,
        147], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 32,
            'hide': 1,
            'x': 14,
            'y': 1,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 3,
            'hide': 1,
            'x': 13,
            'y': 2,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 1 },
        {
            'id': 33,
            'hide': 1,
            'x': 13,
            'y': 1,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 2 },
        {
            'id': 210,
            'x': 10,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 211,
            'x': 9,
            'y': 18,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 234,
            'x': 12,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 258,
            'hide': 1,
            'x': 6,
            'y': 0,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 259,
            'hide': 1,
            'x': 5,
            'y': 0,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 235,
            'x': 7,
            'y': 16,
            'dir': 3,
            'lv': 0,
            'arm_limit': 0,
            'ai': 0,
            'i': 8 },
        {
            'id': 334,
            'x': 12,
            'y': 16,
            'dir': 0,
            'lv': 0,
            'arm_limit': 0,
            'ai': 0,
            'i': 9 },
        {
            'id': 157,
            'hide': 1,
            'x': 9,
            'y': 0,
            'lv': 30,
            'ai': 0,
            'i': 10 }])
    stage.createEnemy([
        {
            'id': 146,
            'x': 9,
            'y': 11,
            'lv': 4,
            'i': 0 },
        {
            'id': 147,
            'x': 10,
            'y': 11,
            'lv': 4,
            'i': 1 },
        {
            'id': 474,
            'x': 6,
            'y': 16,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 475,
            'x': 9,
            'y': 15,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 476,
            'x': 10,
            'y': 15,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 477,
            'x': 12,
            'y': 15,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 478,
            'x': 9,
            'y': 14,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 479,
            'x': 10,
            'y': 14,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 480,
            'x': 5,
            'y': 10,
            'lv': 0,
            'ai': 0,
            'i': 8 },
        {
            'id': 481,
            'x': 5,
            'y': 11,
            'lv': 0,
            'ai': 0,
            'i': 9 },
        {
            'id': 482,
            'x': 7,
            'y': 11,
            'lv': 0,
            'ai': 0,
            'i': 10 },
        {
            'id': 483,
            'x': 8,
            'y': 10,
            'lv': 0,
            'ai': 0,
            'i': 11 },
        {
            'id': 484,
            'x': 12,
            'y': 10,
            'lv': 0,
            'ai': 0,
            'i': 12 },
        {
            'id': 485,
            'x': 12,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 13 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 7,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 1,
            'dir': 1 },
        {
            'idx': 2,
            'dir': 1 },
        {
            'idx': 3,
            'dir': 1 },
        {
            'idx': 4,
            'dir': 1 },
        {
            'idx': 5,
            'dir': 1 },
        {
            'idx': 6,
            'dir': 1 },
        {
            'idx': 7,
            'dir': 1 },
        {
            'idx': 8,
            'dir': 1 },
        {
            'idx': 9,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(146, 0, 0, 0, 0, 25)
    stage.loadBg(0)
    stage.setUnitStatus([
        {
            'hp': -80,
            'unit': stage.unit(234) },
        {
            'hp': -80,
            'unit': stage.unit(235) },
        {
            'hp': -80,
            'unit': stage.unit(334) }])
    stage.delay(5)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(6)
    stage.say('&474\n꺼져!')
    stage.attackAction(474, 235, 1)
    stage.delay(10)
    stage.unit(235).setAction(4)
    stage.say('&235\n하지만, 얼마나 증오스러운 일인가.......')
    stage.unit(235).hide(1)
    stage.say('&477\n아!')
    stage.attackAction(477, 334, 0)
    stage.unit(334).setAction(4)
    stage.say('&334\n아.......')
    stage.unit(334).hide(1)
    stage.unit(234).setAction(9)
    stage.say('&234\n헉, 헉, 하... 더는 못 버티겠어!\n이대로면 완전히 멸망할 거야.')
    stage.say('&210\n젠장, 황번 반역자 수가 계속 늘어났다.')
    stage.unit(210).setDir(stage.countDir(210, 234))
    stage.say('&210\n조만간 기병대가 지원하러 올 것이다,\n무슨 일이 있어도 버텨야 해!')
    stage.unit(211).setDir(stage.countDir(211, 210))
    stage.say('&211\n하지만 제 생각에는 자신의 생명을 지키는 것이 더 중요합니다,\n오늘날 정부군 중 누가 같은 생각을 하지 않는가?')
    stage.unit(211).setDir(stage.countDir(211, 146))
    stage.say('&211\n게다가 여기는 잉촨이고, 전투가 절정에 달하는 곳이다,\n부패한 법원이 군대를 죽음으로 보내지 않을 거라고 믿습니다.')
    stage.unit(210).setDir(stage.countDir(210, 211))
    stage.say('&210\n그렇긴 해도, 증원군의 기병대장은 조조,\n그가 만만치 않은 인물이라고 들었어.')
    stage.unit(210).setDir(stage.countDir(210, 146))
    stage.say('&210\n이번에는 그를 믿어.\n이제 그들이 할 수 있는 건 그가 오기를 기다리는 것뿐이었다.')
    stage.say('&234\n서둘러, 서둘러!')
    stage.unit(146).setDir(1)
    stage.say('&146\n반대편은 정말 끈질깁니다.')
    stage.unit(147).setAction(7)
    stage.say('&147\n흥, 조만간 그들은 패배할 거야!\n"저 증오스러운 정부군이 감히 여기 공격하다니!"\n그들은 반드시 후회하게 만들어야 한다.')
    stage.unit(147).setAction(0)
    stage.unit(146).setDir(2)
    stage.setWinCondition('승리 조건\n1. 장바오와 장량을 죽였다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    vars[500] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[14] and stage.round() >= 1:
        stage.unit(210).setDir(0)
        stage.unit(210).setAction(6)
        stage.say('&210\n조금만 더 버텨!\n정부군이 만만치 않다는 걸 알려줘!')
        stage.unit(210).setAction(0)
        vars[14] = 1
    if not vars[11] and stage.curCamp() == 2 and stage.round() >= 1:
        stage.unit(32).show()
        stage.unit(3).show()
        stage.unit(33).show()
        stage.say('&32\n우리가 따라잡은 것 같아.\n하지만 수적으로 열세인 이 상황에서는,\n이곳 정부군도 치열한 전투에 휘말린 듯 보였다.')
        stage.unit(3).setDir(stage.countDir(3, 32))
        stage.unit(33).setDir(stage.countDir(33, 32))
        stage.say('&3\n우리는 상황을 이용해 안과 외부 모두에서 공격해야 합니다.\nHowever아군 병력은 여전히 부족한 상태였.......\n&33\n둘째 형, 넌 가난하고 걱정할 거야...\n나 혼자서 다 처리할 수 있어.\n&32\n우리는 정부군을 버리고 무시할 수 없습니다,\n뒤에서 몰래 들어가서 루자이로 곧장 향한다.\n돌격!')
        stage.unit(32).move(11, 5, 2)
        stage.unit(3).move(10, 5, 2)
        stage.unit(33).move(12, 5, 2)
        vars[11] = 1
    if not vars[12] and not vars[13] and stage.round() >= 2:
        stage.say('&32\n둘째와 셋째 동생들은 한 랭크로 평가받는다,\n이대로라면 전선의 정부군이 전멸할 것이다,\n여기 불을 질러.\n&3\n맞아! 여기로 관심을 끌자...\n아마도 적은 이 때문에 흔들릴 것이다.\n&33\n그럼 내가 불 질게.\n&32\n양쪽 모두의 무고한 사람들이 너무 많이 목숨을 잃는 걸 원하지 않아요,\n자신의 한계를 알아야 합니다.')
        stage.unit(33).setAction(6)
        stage.delay(1)
        stage.setFire(True, 13, 5)
        stage.unit(33).setAction(0)
        stage.delay(10)
        stage.unit(3).move(8, 5, 2)
        stage.say('&3\n여기서도 불 켜!')
        stage.unit(3).setAction(6)
        stage.delay(1)
        stage.setFire(True, 6, 4)
        stage.setFire(True, 7, 5)
        stage.unit(3).setAction(0)
        stage.delay(10)
        stage.unit(33).setDir(1)
        stage.unit(33).setDir(3)
        stage.unit(33).setDir(2)
        stage.unit(33).setAction(5)
        stage.say('&33\n아니, 아니, 불이 너무 작아!\n루자이를 태울 방법은 없어!')
        stage.unit(33).setAction(0)
        stage.talk(157, 157, '헤헤, 하!\n그럼, 이건 어때?')
        stage.unit(3).setDir(1)
        stage.say('&3\n응?')
        stage.unit(33).setDir(3)
        stage.say('&33\n누구!?')
        stage.playMagicMeff(10, 8, 105)
        stage.setFires(True, [
            [
                14,
                4],
            [
                14,
                5],
            [
                15,
                5],
            [
                15,
                6],
            [
                15,
                7]])
        stage.setFires(True, [
            [
                13,
                6],
            [
                14,
                6],
            [
                14,
                7],
            [
                14,
                8]])
        stage.setFires(True, [
            [
                12,
                6],
            [
                12,
                7],
            [
                13,
                7],
            [
                13,
                8],
            [
                13,
                9]])
        stage.setFires(True, [
            [
                6,
                5],
            [
                6,
                6],
            [
                5,
                6],
            [
                5,
                7],
            [
                5,
                8]])
        stage.setFires(True, [
            [
                7,
                6],
            [
                7,
                7],
            [
                6,
                7],
            [
                6,
                8],
            [
                6,
                9]])
        stage.unit(484).setDir(stage.countDir(484, 33))
        stage.unit(484).setAction(8)
        stage.say('&484\n불이야, 불이야!')
        stage.unit(483).setDir(stage.countDir(483, 3))
        stage.say('&483\n적이 뒤에서 포위하고 있어!')
        stage.unit(147).setDir(stage.countDir(147, 3))
        stage.say('&147\n뭐라고? 누가 ......를 매복했다고 했잖아!')
        stage.unit(146).setDir(stage.countDir(146, 3))
        stage.say('&146\n정부군의 증원군인가요?')
        stage.unit(146).setDir(2)
        stage.unit(146).setAction(5)
        stage.say('&146\n뒤에 있는 적들을 처리하라고 사람들을 보내라!')
        stage.unit(146).setAction(0)
        stage.unit(146).setAction(4)
        stage.say('&146\n아, 안 돼... 아무도 따르지 않았어.......')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 0,
                'y1': 0,
                'x2': 19,
                'y2': 19,
                'camp': 5 }])
        stage.unit(480).setAI(1)
        stage.unit(481).setAI(1)
        stage.unit(482).setAI(1)
        stage.unit(483).setAI(1)
        stage.unit(484).setAI(1)
        stage.unit(485).setAI(1)
        stage.unit(3).setDir(2)
        stage.say('&3\n아!')
        stage.unit(33).setDir(2)
        stage.say('&33\n무슨 일이야!?\n&32\n모르겠어, 하지만 이제는 너무 걱정할 수 없어,\n지금 가장 중요한 것은 무엇인가입니다.')
        stage.unit(32).setAction(6)
        stage.say('&32\n이제 적은 완전한 혼돈에 빠졌다,\n이번이 당첨될 완벽한 기회입니다!\n목표는 적군 주요 장군인 장바오와 장량이었다.\n돌격!')
        stage.unit(32).setAction(0)
        vars[12] = 1
        stage.bgSound(5)
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(0, 1).show()
        stage.unit(0).move(8, 2, 2)
        stage.unit(258).move(7, 2, 2)
        stage.unit(259).move(8, 1, 2)
        stage.say('&0\n여기서 정부군이 치열하게 싸우고 있다고 들었어요,\n...... 불이야!?')
        stage.unit(258).setDir(stage.countDir(258, 0))
        stage.say('&258\n대장님! 저쪽에서 누군가 불을 질렀던 것 같아요,\n하지만 정부군이 ....... 같지는 않았다')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n음, 반란군인 것 같네요.')
        stage.unit(0).setDir(stage.countDir(0, 259))
        stage.say('&0\n너희는 먼저 루자이로 가! 나는 반군 상태를 확인할게.\n&258\n네!\n&259\n네!')
        stage.unit(258).move(9, 7, 2)
        stage.unit(259).move(10, 7, 2)
        stage.unit(0).move(11, 4, 2)
        stage.say('&0\n나는 정부 기병대의 지휘관이다, 성은 조오, 본명은 조, 자식 맹덕,\n황명으로 황번군을 진압하러 파견되었다,\n성씨와 존경받는 성을 여쭤봐도 될까요?')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.say('&32\n저는 유비유현덕입니다. 농사 출신이지만,\n하지만 오늘날 세상의 혼란을 보면서, 사람들을 구하기 위해서,\n그때서야 그는 의로운 군대를 이끌고 군대를 모아 반란을 진압했다.\n&32\n당신과 내가 정부군을 지원해 주길 바랍니다,\n모든 일은 조 공의 명령에 돌려 넘어가야 한다.\n&0\n유비 씨 덕분에 황번군은 혼란에 빠졌다,\n더 이상 지시할 필요 없어.\n&0\n사슴 요새에 있던 두 남자가 죽는 한,\n너희 모두 각자 싸워, 그리고 다시 만날 거야.')
        stage.unit(0).move(10, 6, 2)
        stage.unit(32).move(9, 6, 2)
        stage.unit(3).setDir(stage.countDir(3, 146))
        stage.showWinCondition('장바오와 장량을 죽였다!')
        stage.unit(146).heightLight()
        stage.unit(147).heightLight()
        if vars[1001]:
            stage.unit(157).show()
            stage.guide()
            stage.unit(157).hide()
            stage.unit(0).setDir(2)
        stage.startOper()
        vars[13] = 1
    if not vars[20] and stage.isInPos(1025, 13, 12):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 13, 13):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 10, 11):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 9, 11):
        stage.getItem(150, 0, True, 1025)
        vars[23] = 1
    if not vars[40] and stage.isNear(0, 146, True):
        stage.unit(0).setDir(stage.countDir(0, 146))
        stage.unit(146).setDir(stage.countDir(146, 0))
        stage.say('&0\n이 시점에서도 저항할 생각이야? 장바오!\n&146\n한나라의 운명은 끝났다; 이제부터 황단의 통치가 될 것이다,\n너도 우리랑 같이 가야 해!\n&0\n한나라는 언젠가는 필연적으로 멸망할 것이다,\n하지만 네가 한나라를 물려받지 못할 거라는 걸 알아,\n흥!\n&146\n......!? 한나라를 위해 목숨을 걸 필요 없어!\n&0\n너희 사악하고 비뚤어진 길들이 땅 곳곳에 혼란을 일으키고 있다,\n가만히 있지 않을 거야. 그냥 내 죽음을 받아들일 거야.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 147, True):
        stage.unit(0).setDir(stage.countDir(0, 147))
        stage.unit(147).setDir(stage.countDir(147, 0))
        stage.say('&0\n당신이 장량 맞죠?\n그는 반란군 병사였지만 여전히 군대의 장군이었다,\n차라리 순종적으로 항복하는 게 낫겠다.\n&147\n그만 말해, 내가 먼저 널 죽여 봐!\n&0\n산적군은 그냥 산적군일 뿐이야,\n시사에 대한 이해가 너무 부족하다니,\n장군이 될 자격도 없어, 흥!')
        vars[41] = 1
    if vars[50] and vars[51] and not vars[100]:
        stage.setRectUnitHide(0, 0, 19, 19, 5, 1)
        stage.resumeCtrl()
        if not vars[52] and not vars[53] and not vars[54]:
            stage.unit(0).setDir(stage.countDir(0, 32))
            stage.unit(32).setDir(stage.countDir(32, 0))
            stage.say('&0\n유비 씨는 의군이라는 이름만 가지고 있는데, 정말 안타깝습니다.\n왜 나랑 같이 일하지 않아?\n&32\n지금도 전쟁의 불길이 꺼지지 않은 곳이 많다,\n&32\n그러므로, 당신의 친절로 친절하게 초대받았음에도 불구하고,\n우리는 도둑을 쫓으려면 ......에 가야 해.\n&0\n그래? 그럼 강요할 수 없어.\n다른 할 일이 있어,\n그리고 다시 만날 때까지, 또 다른 날에.')
            stage.unit(210).move(8, 15, 2)
            stage.unit(211).move(8, 16, 2)
            stage.unit(234).move(8, 17, 2)
            stage.unit(258).move(8, 18, 2)
            stage.unit(259).move(8, 19, 2)
            stage.unit(0).move(10, 19, 2)
            stage.unit(32).setDir(stage.countDir(32, 3))
            stage.unit(3).setDir(stage.countDir(3, 32))
            stage.say('&32\n이 남자는 그가 이전에 본 정부군과는 달랐다.\n그거 조조 맞지......?\n&3\n혼돈의 물결은 예측할 수 없으며, 아마도 우리는 미래에 다시 만날 것이다.')
            stage.unit(32).setDir(stage.countDir(32, 33))
            stage.unit(33).setDir(stage.countDir(33, 32))
            stage.say('&32\n좋아, 황번군 잔당을 처리하는 동안,\n한편으로는 공손찬 캠프로 향하면서,\n그 다음에는 미래를 생각하세요.\n&33\n좋아, 뭐든 괜찮아, 충분히 먹기만 하면 그걸로 충분해.\n하하하!')
            stage.unit(0).setDir(stage.countDir(0, 32))
            stage.say('(유현덕… 다시 만나게 될 때 적일지 아군일지… 모든 것은 하늘만이 알겠지.)')
        else:
            stage.say('&0\n좋아, 이제 여기 황번군은 행동을 좀 조심해야 해.\n&0\n(유현덕... 비록 그들은 단지 의로운 군대일 뿐이지만,\n그는 전투에 매우 능숙했어요—기억해야겠어요. )')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[100] = 1
        vars[600] = 1
        return True
    if not vars[50] and stage.unitStateTest(146, 7, 0, 2):
        stage.say('&146\n정말 여기서 죽는 거야? 흠.......')
        stage.unit(146).hide(2)
        stage.getItem(132, 0, True, 1027)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(147, 7, 0, 2):
        stage.say('&147\n정말 증오스럽다, 그는 실제로 이 녀석들에게 졌다......')
        stage.unit(147).hide(2)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n나는 황번군의 공격을 막기로 결심했지만...\n안타깝게도 그의 현재 힘은 .......')
        stage.unit(32).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n계속 싸워봐야 소용없어; 후퇴해.')
        stage.unit(3).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n젠장, 내가 진짜 전투에서 졌어장비?\n뭔가 착오가 있는 것 같아!')
        stage.unit(33).hide(1)
        vars[54] = 1
    if not vars[13] and not vars[55] and stage.unitStateTest(234, 7, 0, 2):
        stage.say('&234\n흠, 증원군... 증원군은 아직 안 오는 거야......?')
        vars[55] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 이제 여기 황번군은 행동을 좀 조심해야 해.\n&0\n(유현덕... 비록 그들은 단지 의로운 군대일 뿐이지만,\n그는 전투에 매우 능숙했어요—기억해야겠어요. )')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[600] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 황번군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
