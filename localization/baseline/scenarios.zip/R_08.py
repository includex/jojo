# Source Generated with Decompyle++
# File: R_08.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    if vars[707] and vars[1001]:
        stage.loadBg(2, 8)
        stage.jumpScene(17)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            119,
            34,
            54,
            1],
        [
            126,
            50,
            54,
            3]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.delay(3)
    stage.setEventName('호랑이와 늑대 같은 장군')
    stage.setStageName('푸양 여포 저택')
    stage.delay(5)
    stage.unit(119).setAction(3)
    stage.say('&119\n하하하!\n조조 지금 아마 매우 내키지 않을 거예요, 공공 역에서요?"\n&126\n네, 하지만 보고하자면 주군 곤란해요.')
    stage.unit(119).setAction(0)
    stage.say('&119\n정확히 무엇이 문제를 일으켰나요?\n&126\n…… 메뚜기 재앙이 발생했습니다.')
    stage.unit(119).setAction(3)
    stage.say('&119\n뭐라고? 메뚜기 역병이야!\n&126\n그래, 푸양 주변의 모든 농작물이 다 먹혔어,\n지금은 쌀알이 한 알도 없어.')
    stage.unit(119).setAction(0)
    stage.delay(3)
    stage.unit(119).setAction(0, 2)
    stage.say('&119\n흠.......\n&126\n주군, 우리 조조군을 공격하라,\n또한 식량이 부족한 심각한 상황에 시달려야 한다,\n그래서 그들이 우리를 공격하지 못하게 하려고.')
    stage.say('&126\n우리는 일시적으로 적대 행위를 중단할 수밖에 없는 것 같습니다,\n다음 시즌 수확을 기다리자.')
    stage.unit(119).setAction(0, 1)
    stage.say('&119\n그것도 피할 수 없는 일이죠.\n그럼 잠시 싸움을 그만두고 적절한 순간을 기다리자.')
    stage.unit(119).setAction(17)
    stage.say('&119\n공개 단상에서는 군 전체에 명령이 내려졌다.\n오늘부터 식량을 아껴야 합니다,\n위반자는 엄중히 처벌받을 것입니다!')
    stage.say('&126\n네.')
    stage.effectSound(205, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(119, 416, 63)
    stage.showHead(0, 480, 63)
    stage.showHead(145, 482, 150)
    stage.bottomTxt('이 시점에서,', False, False, False)
    stage.delay(5)
    stage.bottomTxt('도겸 서주 주지사는 이미 사망했다,', True, False, False)
    stage.delay(5)
    stage.head(145).hide()
    stage.delay(5)
    stage.bottomTxt('임종의 지시에 따르면,', True, True, False)
    stage.delay(5)
    stage.showHead(32, 482, 150)
    stage.bottomTxt('유비 그의 뒤를 이어 서주 주지가 되었다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            16,
            38,
            46,
            1],
        [
            18,
            38,
            38,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            46,
            3],
        [
            21,
            60,
            38,
            3]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.delay(3)
    stage.setStageName('조조군의 주영지인 푸양 외곽')
    stage.say('봉효, 곡식이 얼마나 남았지?')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n한 달 정도 더 갈 수 있어요.')
    stage.unit(1).move(40, 54, 1)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n군사 보급품이 보류되었기 때문에,\n병사들 사이에서 이미 불만이 일어나고 있었다.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군, 잠시 푸양을 떠나,\n루난에 가는 건 어때?\n&0\n루난?\n&20\n네. 거기엔 메뚜기 전염병이 없었어요,\n식량은 풍부하다.\n&0\n하지만 국민에게 곡물을 강제로 요구할 수는 없습니다.\n&20\n현재 루난에는 황번 반군의 잔존 세력이 남아 혼란을 일으키고 있다.\n&20\n이 도적들을 제거하면,\n사람들은 아마도 아군에게 곡물을 공급할 의향이 있을 것입니다.\n&20\n이렇게 하면 궁정의 총애도 얻을 수 있었다,\n주군의 위신을 높이세요.\n주군 어떻게 생각하는지 궁금하네요.')
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n사실, 우리의 군사 보급이 부족하더라도,\n하지만 그 산적들은 아직 우리를 상대할 수 없어.')
    stage.unit(1).setAction(3, 1)
    stage.say('&1\n이것은 정말 일석이조를 위한 훌륭한 계획이었습니다.')
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n그리고 그게 다가 아닙니다, 샤호우 장군님,\n일석이조일지도 모르죠.')
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n뭐라고? 그게 무슨 뜻이야?\n&20\n주군, 루난의 한 마을에 용감하고 건장한 남자가 있다고 들었어,\n그는 호랑이 광신자로 알려져 있었다.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n만약 그가 아군에 합류한다면,\n아군의 힘은 확실히 더 강해질 거야.\n&0\n오, 호랑이 광신자......?')
    stage.unit(0).setAction(17)
    stage.say('&0\n좋아, 전군이 루난으로 행군할 거야.')
    stage.effectSound(205, 255)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(119, 416, 63)
    stage.showHead(0, 480, 63)
    stage.bottomTxt('조조 여포와 잠시 휴전 상태에 있다,', False, False, False)
    stage.delay(5)
    stage.head(0).move(480, 154)
    stage.head(0).move(403, 154)
    stage.bottomTxt('교착 상태를 깨기 위해 그는 루난으로 향했다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene2():
    stage.bgSound(18)
    stage.delay(3)
    stage.loadBg(2, 30)
    stage.showUnits([
        [
            187,
            54,
            4,
            2],
        [
            188,
            46,
            4,
            2]])
    stage.draw()
    stage.setStageName('차오현: 산속의 작은 마을')
    stage.unitsMove([
        [
            stage.unit(187),
            54,
            24,
            2],
        [
            stage.unit(188),
            46,
            24,
            2]])
    stage.say('&187\n와! 도와주세요!!\n&188\n흠, 저 사람은 인간이 아니야! 그는 괴물이야!!')
    stage.showUnit(16, 54, 7, 2)
    stage.unitsMove([
        [
            stage.unit(187),
            54,
            32,
            2],
        [
            stage.unit(188),
            46,
            32,
            2],
        [
            stage.unit(16),
            54,
            15,
            2]])
    stage.showUnit(0, 46, 5, 2)
    stage.unitsMove([
        [
            stage.unit(187),
            54,
            52,
            2],
        [
            stage.unit(188),
            46,
            52,
            2],
        [
            stage.unit(16),
            54,
            35,
            2],
        [
            stage.unit(0),
            46,
            25,
            2]])
    stage.say('&16\n죄 많은 놈들!\n도망가지 마!')
    stage.unit(0).setAction(17)
    stage.say('전위, 저들은 모두 도적 무리 두목들이야. 그냥 둘 수 없어. 나한테 맡겨! 멈춰!!')
    stage.showUnit(15, 50, 98)
    stage.unitsMove([
        [
            stage.unit(187),
            54,
            74,
            2],
        [
            stage.unit(188),
            46,
            74,
            2],
        [
            stage.unit(16),
            54,
            57,
            2],
        [
            stage.unit(0),
            46,
            47,
            2],
        [
            stage.unit(15),
            50,
            78,
            0]])
    stage.delay(5)
    stage.unit(15).move(54, 78, 1)
    stage.delay(3)
    stage.unit(15).setAction(0, 0)
    stage.say('&187\n아, 뭐 하는 거야!?')
    stage.effectSound(38, 1)
    stage.unit(187).setAction(10)
    stage.unit(15).move(46, 78, 3)
    stage.delay(3)
    stage.unit(15).setAction(0, 0)
    stage.say('&188\n놔...... 놔줘, 와!')
    stage.effectSound(38, 1)
    stage.unit(188).setAction(10)
    stage.unit(16).move(54, 59, 2)
    stage.say('&16\n응? 이 사람이 내 신용을 훔쳐가다니?\n이봐! 빨리 넘겨.')
    stage.unit(15).setAction(0, 1)
    stage.say('&15\n이 사람들이 우리 마을 사람들을 죽였어,\n넘길 수 없어.')
    stage.unit(16).move(50, 59, 2)
    stage.say('&16\n뭐라고!')
    stage.unit(15).move(50, 78, 1)
    stage.delay(1)
    stage.unit(15).move(50, 65, 0)
    stage.say('&15\n나는 허저, 네가 사람을 원한다면,\n우리 자신의 능력에 의지하자.')
    stage.unit(16).setAction(14)
    stage.say('&16\n그만 말해, 내 전위를 자극하다니, 배짱 있군!')
    stage.unit(0).setAction(3)
    stage.say('&0\n안 돼! 전위, 지금 당장 멈춰!')
    stage.unit(0).setAction(0)
    stage.say('&16\n음, 오, 오 ......!')
    stage.unit(16).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(16).setAction(14)
    stage.say('&15\n아, ......!')
    stage.unit(15).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(15).setAction(14)
    stage.say('&16\n죽여! 죽여! 죽여!!')
    stage.unit(16).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(16).setAction(14)
    stage.delay(3)
    stage.unit(16).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(16).setAction(14)
    stage.say('&15\n음 오 오 오!!')
    stage.unit(15).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(15).setAction(14)
    stage.delay(3)
    stage.unit(15).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(15).setAction(14)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n오! 전위와 동등하다!')
    stage.unit(0).setAction(0)
    stage.say('맞다. 혹시 이 한나라가 문약이 말했던 호지인가요?')
    stage.say('&16\n이걸 받아라!')
    stage.unit(16).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(16).setAction(14)
    stage.say('&15\n이게 뭐야!')
    stage.unit(15).setAction(13)
    stage.delay(3)
    stage.effectSound(7, 1)
    stage.unit(15).setAction(14)
    stage.say('절, 절대로 그렇지 않습니다! 부디 다시 한번 생각해 주십시오!')
    stage.unit(0).setAction(0, 0)
    stage.say('전위, 빨리 돌아와!')
    stage.unit(16).setAction(0, 2)
    stage.delay(3)
    stage.unit(16).setAction(0, 0)
    stage.say('&16\n응? 무-무슨 일이야?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n내가 다시 전화했어.\n도둑들이 그의 손에 있어!')
    stage.unit(16).setAction(0, 1)
    stage.say('&16\n젠장, 주군 명령인데.\n우리가 할 수 있는 게 없어......')
    stage.unit(16).setAction(0, 2)
    stage.say('&16\n이봐, 이 문제는 다른 날에 해결하자!')
    stage.unit(15).setAction(0)
    stage.say('&15\n그럼 그 사람들도 데리고 갈게.')
    stage.unit(15).setAction(0, 2)
    stage.unitsMove([
        [
            stage.unit(16),
            50,
            15,
            0],
        [
            stage.unit(0),
            46,
            5,
            0]])
    stage.unit(0).hide()
    stage.unit(16).move(50, 5, 0)
    stage.unit(16).hide()
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            16,
            38,
            54,
            1],
        [
            20,
            60,
            54,
            3]])
    stage.draw()
    stage.info('그날 밤, ......,', 3)
    stage.setStageName('교현 조조 본진')
    stage.delay(3)
    stage.unit(16).move(40, 54, 1)
    stage.delay(3)
    stage.unit(16).setAction(0, 2)
    stage.say('&16\n주군, 거의 이길 뻔했어,\n왜 날 막는 거야!?')
    stage.say('전위야. 아?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n정말 조금 짧아진 걸까요?')
    stage.unit(16).setAction(0, 1)
    stage.say('&16\n이건 ...... 이건 ...... 하지만 .......')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n……문약, 허저를 너에게 맡긴다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n걱정 마세요.')
    stage.unit(16).setAction(0, 2)
    stage.say('&16\n전략가문약 어떻게 ......를 이길 수 있겠는가?')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n하하, 전위 장군님, 괜찮아요.')
    stage.unit(16).setAction(0, 1)
    stage.say('&16\n……？？')
    stage.unit(0).setAction(3)
    stage.say('하하하하.')
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 30)
    stage.showUnits([
        [
            181,
            54,
            98],
        [
            182,
            46,
            98]])
    stage.draw()
    stage.info('다음 날, ......,', 3)
    stage.setStageName('차오현: 산속의 작은 마을')
    stage.unitsMove([
        [
            stage.unit(181),
            54,
            83,
            0],
        [
            stage.unit(182),
            46,
            83,
            0]])
    stage.say('&181\n아, 도와줘......!\n&182\n아!')
    stage.showUnit(15, 50, 98)
    stage.unitsMove([
        [
            stage.unit(181),
            54,
            68,
            0],
        [
            stage.unit(182),
            46,
            68,
            0],
        [
            stage.unit(15),
            50,
            83,
            0]])
    stage.delay(3)
    stage.unit(15).setAction(3, 0)
    stage.say('&15\n거기서 멈춰! 내 소를 다치게 하다니!\n절대 그냥 두지 않을 거야!')
    stage.unitsMove([
        [
            stage.unit(181),
            54,
            60,
            0],
        [
            stage.unit(182),
            46,
            60,
            0],
        [
            stage.unit(15),
            50,
            75,
            0]])
    stage.say('&15\n멈춰!')
    stage.unit(15).setAction(3, 0)
    stage.say('&15\n아, 이거 큰일이야!!')
    stage.effectSound(38, 1)
    stage.unit(15).setAction(15)
    stage.unit(181).setAction(0, 2)
    stage.say('&181\n오, 성공했어! 함정에 빠졌어!')
    stage.unit(182).setAction(0, 2)
    stage.say('&182\n알았어! 알았어!\n즉시 순욱 씨에게 보고하세요.')
    stage.say('&15\n음, 젠장!')
    stage.clsUnit()
    return False


def scene5():
    model.unitJoin(15, 0, 0)
    if vars[1013]:
        gvars[0] = 15
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene6():
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1],
        [
            16,
            38,
            46,
            1],
        [
            20,
            60,
            52,
            2],
        [
            22,
            60,
            46,
            3],
        [
            21,
            60,
            40,
            3],
        [
            15,
            49,
            52,
            2]])
    stage.draw()
    stage.setStageName('교현 조조 본진')
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 잡았허저.\n&0\n음. 문약, 빨리 풀어!')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n네.\n&15\n응?')
    stage.say('&16\n어!?')
    stage.unit(20).setAction(0, 3)
    stage.delay(3)
    stage.unit(20).move(52, 52, 3)
    stage.delay(5)
    stage.unit(20).move(60, 52, 3)
    stage.say('&0\n나는 조조조맹덕고, 너는 허저지?\n왜 누군가가 산적과 싸우겠습니까?\n&15\n왜냐하면 더 이상 남은 사람이 없었기 때문이다.\n&0\n당국에 도움을 요청하지 않았나요?')
    stage.unit(15).setAction(0, 1)
    stage.say('&15\n지금은 혼란스러운 시기다...\n그 관리들이 어떻게 우리 평민들을 보호할 수 있겠어?\n&0\n흠.......')
    stage.unit(15).setAction(0, 2)
    stage.say('&15\n아무튼, 더 이상 말하지 마,\n내 목을 빨리 잘라버렸어.')
    model.setFace(3)
    stage.unit(0).setAction(3, 0)
    stage.say('하하하, 내가 너를 죽일 계획은 없습니다.')
    stage.say('&15\n어!?')
    model.setFace(0)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n허저, 나를 섬길 의향이 있나?\n나는 그 관리들과 달라.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n이 혼란스러운 세상을 진정시키러 나와 함께 가자.')
    stage.say('&15\n세상을 진정시키려고? 농부인 나를 찾고 있나?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n신분은 중요하지 않아; 내가 존경하는 건 네 무공 실력이야.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n어때?')
    stage.unit(15).setAction(11, 2)
    stage.say('&15\n네, 네.\n최선을 다하겠습니다.')
    model.setFace(3)
    stage.unit(0).setAction(3, 0)
    stage.say('하하하, 좋습니다. 당신이 크게 활약할 수 있기를 바랍니다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n전위, 허저 맡길게.\n행군과 싸움을 가르쳐라!')
    stage.unit(16).setAction(0, 2)
    stage.say('&16\n네, 네.')
    stage.unit(15).setAction(0, 2)
    stage.delay(3)
    stage.unit(15).move(49, 40, 0)
    stage.delay(1)
    stage.unit(16).setAction(0, 1)
    stage.unit(15).move(38, 40, 1)
    stage.unit(15).setAction(0)
    stage.bgSound(15)
    stage.delay(3)
    stage.say('&0\n문약, 군 식량은 어때?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군 집에서는 이미 음식이 충분했다.')
    stage.unit(0).setAction(17, 0)
    stage.say('&0\n좋아! 그리고 푸양을 공격하기 위해 전진했다,\n이번에는 반드시 여포를 이겨야 해!')
    stage.unit(0).setAction(0, 0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        16,
        15,
        1])
    gvars[4076] = 0
    gvars[4057] = 8
    stage.setBattlePos([
        [
            2,
            21],
        [
            2,
            19],
        [
            3,
            20],
        [
            4,
            21],
        [
            1,
            18],
        [
            5,
            22],
        [
            1,
            19],
        [
            4,
            22],
        [
            2,
            20],
        [
            3,
            21],
        [
            0,
            20],
        [
            2,
            23],
        [
            1,
            21],
        [
            2,
            22],
        [
            1,
            22]])
    return False


def scene7():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(15):
        stage.say('&15\n전위 장군님, 잘 부탁드립니다.\n&16\n아? 아, 그래. 우리 좋은 친구가 되자.')
    if stage.unitClickTest(16):
        stage.say('&16\n순욱 전략가는 여전히 강력하다.\n&20\n하하하.')
    if stage.unitClickTest(1):
        stage.say('&1\n충분한 식사량을 얻자 병사들은 크게 힘을 얻사기.')
    if stage.unitClickTest(20):
        stage.say('&20\n주요 전장은 푸양시 남서쪽에 있었다.\n&0\n흠.')
    if stage.unitClickTest(22):
        stage.say('&22\n허저 장군은 반군 부대입니다,\n황무지와 산악지대에서 뛰어난 성능을 보입니다.')
    if stage.unitClickTest(21):
        stage.say('&21\n산적들은 대지 기반 전략을 사용할 수 있습니다,\n하지만 일반 허저들이 어떤 계획을 쓸지 알 수 없었어요.\n&15\n뭐라고...... 무슨 뜻이야!\n&21\n아, 아무것도 아니.......')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
