# Source Generated with Decompyle++
# File: S_29.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22], [
        '(27,5)',
        '(16,14)',
        '(4,5)'])
    stage.nearEvent([
        33,
        15])
    stage.nearEvent([
        34,
        2,
        34,
        13,
        33,
        2,
        33,
        13], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 3, 0, 2, 2)
    stage.createEnemy(
        [{'id': 80, 'hide': 1, 'x': 33, 'y': 18, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 0},
         {'id': 358, 'hide': 1, 'x': 32, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 1},
         {'id': 359, 'hide': 1, 'x': 34, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 2},
         {'id': 360, 'hide': 1, 'x': 32, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 3},
         {'id': 361, 'hide': 1, 'x': 33, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 4},
         {'id': 362, 'hide': 1, 'x': 34, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 5},
         {'id': 84, 'hide': 1, 'x': 22, 'y': 17, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 6},
         {'id': 363, 'hide': 1, 'x': 21, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 7},
         {'id': 364, 'hide': 1, 'x': 22, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 8},
         {'id': 365, 'hide': 1, 'x': 23, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 9},
         {'id': 366, 'hide': 1, 'x': 24, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 10},
         {'id': 85, 'hide': 1, 'x': 3, 'y': 14, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 11},
         {'id': 367, 'hide': 1, 'x': 1, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 368, 'hide': 1, 'x': 1, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 369, 'hide': 1, 'x': 4, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 370, 'hide': 1, 'x': 4, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 34, 'hide': 1, 'x': 22, 'y': 11, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 16},
         {'id': 310, 'hide': 1, 'x': 22, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 311, 'hide': 1, 'x': 22, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 318, 'hide': 1, 'x': 21, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 319, 'hide': 1, 'x': 22, 'y': 8, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 234, 'hide': 1, 'x': 23, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 235, 'hide': 1, 'x': 23, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 33, 'hide': 1, 'x': 12, 'y': 1, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 23},
         {'id': 312, 'hide': 1, 'x': 11, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 313, 'hide': 1, 'x': 10, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 320, 'hide': 1, 'x': 12, 'y': 3, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 321, 'hide': 1, 'x': 11, 'y': 3, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 236, 'hide': 1, 'x': 9, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 28},
         {'id': 237, 'hide': 1, 'x': 9, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 3, 'hide': 1, 'x': 2, 'y': 2, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 30},
         {'id': 258, 'hide': 1, 'x': 2, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 259, 'hide': 1, 'x': 1, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 260, 'hide': 1, 'x': 0, 'y': 2, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 282, 'hide': 1, 'x': 1, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 283, 'hide': 1, 'x': 0, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 35}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 34,
            'y': 19,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 1,
            'x': 33,
            'y': 20,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 2,
            'x': 34,
            'y': 19,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 3,
            'x': 33,
            'y': 8,
            'hide': 1 },
        {
            'idx': 4,
            'x': 32,
            'y': 8,
            'hide': 1 },
        {
            'idx': 5,
            'dir': 0 },
        {
            'idx': 6,
            'dir': 0 },
        {
            'idx': 7,
            'dir': 0 },
        {
            'idx': 8,
            'dir': 0 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.loadBg(29)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(6)
    stage.unit(0, 1).show()
    stage.unit(0, 1).move(34, 14, 0)
    stage.unit(1, 1).show()
    stage.unit(1, 1).move(33, 15, 0)
    stage.unit(2, 1).show()
    stage.unit(2, 1).move(34, 15, 0)
    stage.unit(21).setDir(stage.countDir(21, 0))
    stage.unit(21).setAction(9)
    stage.say('&21\n아......\n주군, 괜찮아?')
    stage.unit(0).setDir(stage.countDir(0, 21))
    stage.say('&0\n흠, 흠.\n아군 남자들은 혼란 속에 흩어져 있었다.\n다른 사람들은 무사히 도망쳤을까?')
    stage.unit(2).setDir(stage.countDir(2, 0))
    stage.say('&2\n쉬두에서 다시 만나자.\n이제 탈출 방법을 생각할까......')
    stage.unit(80).show()
    stage.unit(358).show()
    stage.unit(359).show()
    stage.unit(360).show()
    stage.unit(361).show()
    stage.unit(362).show()
    stage.unit(0).setDir(stage.countDir(0, 80))
    stage.unit(21).setDir(stage.countDir(21, 80))
    stage.unit(2).setDir(stage.countDir(2, 80))
    stage.unit(0).setAction(10)
    stage.unit(21).setAction(10)
    stage.unit(2).setAction(10)
    stage.say('&21\n!?\n&80\n진짜 대화할 시간 있어?\n병 속 거북이들,\n그는 아직도 자신의 죽음이 문 앞에 있다는 걸 깨닫지 못했다!')
    stage.unit(80).setAction(5)
    stage.say('&80\n어서, 잡아조조!\n그를 놓치지 마!')
    stage.unit(80).setAction(0)
    stage.unit(0).setDir(0)
    stage.say('&0\n흠, 추격자들이 정말 그렇게 빨리 도착했나?\n서둘러! 장료. 정욱, 나를 따라와!')
    stage.unit(0).move(33, 10, 0)
    stage.unit(2).move(32, 11, 0)
    stage.unit(21).move(33, 11, 0)
    stage.unit(3, 1).show()
    stage.unit(4, 1).show()
    stage.unit(2).setAction(6)
    stage.say('&2\n적 요격 신호!?\n피비린내 장료 싸워서 헤쳐 나가게 해줘......')
    stage.unit(2).setAction(0)
    stage.unit(15).setAction(10)
    stage.say('&15\n잠깐, 잠깐! 나 허저.\n주군, 괜찮아?\n&0\n오, 오! 허저?\n좋아, 아직 살아 있구나!\n다른 사람들은 어때?\n&13\n모두 분리되었어.........\n우리는 여기서 탈출하기 위해 산을 넘어야 했어.')
    stage.unit(21).setDir(stage.countDir(21, 0))
    stage.say('&21\n서둘러! 주군!\n적은 이미 따라잡았다.\n서둘러 떠나야 해!\n&0\n흠! 여러분 모두 여기 있으니 군대보다 낫네요!\n앞으로 나아가 곧장 쉬두로 가자!')
    stage.setWinCondition('승리 조건\n1. 북서쪽 끝에 도달조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 25를 초과한다.')
    stage.showWinCondition('조조 도망쳐!')
    stage.heightLight(0, 0, 5, 5)
    stage.startOper()
    vars[529] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[30] and stage.isInRect(1025, 0, 0, 5, 5):
        stage.resumeCtrl()
        stage.say('&0\n마침내 그는 위험에서 벗어났다.\n안타깝게도 레드 클리프 전투는 완전한 패배라고 할 수 있다.\n이걸 통해 배워야 해...... 흠!?')
        stage.unit(3).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(3).setDir(stage.countDir(3, 0))
        stage.say('아! 운장…? 맹상군…! 승상님… 과거의 정이 어떻든 오늘 당신과 나는 물불을 가릴 수 없습니다. 오직 승상의 목만 받들겠습니다!')
        if stage.totalRectUnit(0, 3, 2, 3, 2) == 0:
            stage.say('(으윽, 설마 여기서 목숨을 잃는 건가! 안 돼! 분명 방법이 있을 거야……)')
            sel = stage.choice('관우 진행을 허락해 달라고 간청했다\n챌린지 관우', -1)
            if sel == 1:
                stage.say('&0\n제가 매우 부끄럽습니다.\n지금은 군장의 인의에 도움을 청할 수밖에 없습니다.\n&0\n운장아, 만약 과거의 정을 아직 생각한다면,\n제발 저에게 살 길을 열어주시오.\n&3\n당신의 은혜는 제가 항상 마음에 새기고 있지만... \n이건 모두 전쟁의 숙명입니다. 부디 형님께 더 이상 청하지 마십시오. \n관우는 정말 당신이 애원하는 모습을 보는 것이 차마 못 하겠습니다!\n&0\n모두 제 눈앞의 근시안적인 생각 탓에 이런 화를 자초했으니,\n다만 연루된 장병들이 생각나니,\n제가 슬픔을 금할 수가 없습니다...\n&0\n장병들의 안위를 알 수 없다면,\n저 조조는 결코 이렇게 죽을 수 없습니다.\n&3\n.........\n&0\n미안하다, 운장아.\n내가 아직 정리하지 못한 일들이 많다.\n이제 와서는 당당하게 싸울 뿐이다.\n&0\n자, 운장!')
                if not vars[58]:
                    stage.unit(15).setDir(stage.countDir(15, 0))
                    stage.say('&15\n주군, 직접 개입할 필요 없어!\n그리고 나는 항상 너를 따라허저.')
                    stage.unit(15).setDir(stage.countDir(15, 3))
                    stage.say('&15\n관우, 공을 쌓고 보상을 받고 싶다면,\n내 허저 머리만 가져가!\n내 주군 다치게 하지 마.')
                if not vars[56]:
                    stage.unit(2).setDir(stage.countDir(2, 3))
                    stage.say('&2\n윤창, 제발 그만해.\n나, 장원위안이 내 목을 내놓겠다!\n제발, 총리님을 다치게 하지 마세요......')
                stage.say('&3\n…………\n음음!\n&3\n관은 샤피에서 오랫동안 자발적으로 사형을 저질렀다,\n형의 군사 규율에 당해도,\n관도 죽음에 후회가 없다.\n&3\n누군가에게서 친절의 한 방울을 받으면, 반드시 스프링으로 갚게 될 것입니다.\n총리님, 가셔도 됩니다! 하지만 다음에 다시 만날 때......')
                stage.setRectUnitHide(0, 0, 6, 6, 2)
                stage.say('&0\n고마워, 윤창.')
            elif sel == 2:
                stage.say('&0\n이 시점에서 나는 다른 선택지가 없다.\n상대가 누구든, 유일한 방법은 싸워서 빠져나가는 것이다.\n&0\n윤창, 나, 조맹덕, 네 검술을 직접 경험하러 왔다!\n&3\n총리의 죽음을 결심한 태도는 정말 존경스럽습니다!\n윤창은 분명히 최선을 다할 것이다.')
                stage.unit(0).move(3, 2, 3)
                fight = stage.startFight(0, 3, 5)
                fight.showUnit(True, '어서! 관우!\n저승으로 가는 길에서 너와 함께,\n죽어도 후회는 없어요.', 8)
                fight.showUnit(False, '총리님의 큰 은혜를 결코 잊지 않았습니다.\n하지만 모든 것은 운명에 의해 정해진 것이었다.\n자, 총리님, 조심하세요!', 6)
                fight.showStart()
                fight.setAction(True, 0)
                fight.setAction(False, 2)
                fight.attack1(False, 2, False)
                stage.delay(5)
                fight.setAction(True, 2)
                fight.attack2(True, 0, True)
                fight.attack2(True, 0, True)
                fight.attack2(True, 0, True)
                fight.attack2(True, 0, True)
                fight.attack2(False, 0, True)
                fight.attack2(False, 0, True)
                fight.attack2(False, 0, True)
                fight.attack2(False, 0, True)
                fight.attack1(True, 1, False)
                fight.attack1(False, 1, False)
                fight.attack1(True, 1, False)
                fight.attack1(False, 1, False)
                fight.attack1(True, 2, True)
                stage.delay(15)
                fight.setAction(True, 8)
                fight.say(True, '그만해, 관우.\n이제 승자를 결정할 시간이었다.', True)
                fight.setAction(False, 8)
                fight.say(False, '그럼 주저하지 않겠다!', True)
                stage.delay(10)
                fight.attack2(False, 2, False)
                stage.delay(10)
                fight.setAction(True, 12)
                fight.say(True, '흠...... 아, 안 돼.\n역시나, 그들은 여전히 win관우......\n여기서 죽는 건가요......', True)
                stage.delay(5)
                fight.setAction(False, 1)
                stage.delay(5)
                fight.say(False, '………………', True)
                fight.end()
                if not vars[58]:
                    stage.unit(15).setDir(stage.countDir(15, 3))
                    stage.say('&15\n관 장군, 제발 그만하세요!\n오늘은 두 손으로 머리를 내허저,\n부디 제 말은 살려 주세요family주군......')
                if not vars[56]:
                    stage.unit(2).setDir(stage.countDir(2, 3))
                    stage.say('&2\n주군!\n윤창, 제발 총리님의 생명을 해치지 마세요,\n장료 주군와 맞바꾸는 데 자신의 목숨을 바칠 준비가 되어 있어.')
                if not vars[57]:
                    stage.say('&21\n관 장군님, 자비를 베풀어 주십시오.\n한때 알았던 친절을 잊주군 거니?\n장군께서 아직 자비와 의로움이 있으시다면, 오늘 총리를 풀어주세요!')
                if not vars[59]:
                    stage.say('&13\n주군 혼자 죽게 두지 않을 거야!\n나는 서황 항상 주군와 함께할 것이다.\n관우, 네가 먼저 날 죽여!')
                stage.say('&3\n(배은망덕이라는 이름을 지니는 것보다 더 좋은 것은 없다,\n이 세상에서 살아남는 것은 더욱 부끄러운 일입니다.\n지금 이 순간, 어떻게 그럴 수 있을까...... )\n&3\n안녕히 계세요, 조 총리님!\n다음에 만나면 네 목숨을 빼앗을 거야.')
                stage.setRectUnitHide(0, 0, 6, 6, 2)
                stage.say('&0\n!!\n운장…… 정말 나를 놓아주겠다는 건가……?\n……………')
            else:
                stage.say('(으윽, 설마 여기서 관우와 마주치게 될 줄이야! 내가 여기서 목숨을 잃는 건가…… 아, 아니야! 마음속에 희망의 실낱이라도 남아있다면……) 조모는 매우 부끄럽습니다. 지금은 오직 당신의 인의를 빌릴 뿐입니다.\n관우여, 만약 과거의 정을 아직 생각한다면, 제발 저에게 살 길을 열어주십시오.\n당신의 은혜는 관우가 평생 마음속에 새기고 있습니다만…… 이것은 전쟁의 숙명입니다. 부디 형님께 더 이상 청하지 마십시오. 관우는 정말로 당신이 애원하는 모습을 보는 것이 괴롭습니다!\n모두 조모의 시야가 좁아서 화를 자초했소. 다만 연루된 장사들이 생각나니, 조모도 모르게 슬픔에 잠기오……\n장사들의 안위를 알지 못한다면, 나 조모는 결코 여기서 죽을 수 없소.\n………\n미안하다, 관우야. 나에게 아직 정리하지 못한 일들이 많아.\n이제 와서 나 역시 당당하게 싸워야겠어.\n자, 관우여!')
                if not vars[58]:
                    stage.unit(15).setDir(stage.countDir(15, 0))
                    stage.say('&15\n주군, 직접 개입할 필요 없어!\n그리고 나는 항상 너를 따라허저.')
                    stage.unit(15).setDir(stage.countDir(15, 3))
                    stage.say('&15\n관우, 공을 쌓고 보상을 받고 싶다면,\n내 허저 머리만 가져가!\n내 주군 다치게 하지 마.')
                if not vars[56]:
                    stage.unit(2).setDir(stage.countDir(2, 3))
                    stage.say('&2\n윤창, 제발 그만해.\n나, 장원위안이 내 목을 내놓겠다!\n제발, 총리님을 다치게 하지 마세요......')
                stage.say('&3\n…………\n음음!\n&3\n관은 샤피에서 오랫동안 자발적으로 사형을 저질렀다,\n이제는 형의 군법에 당해도,\n관도 죽음에 후회가 없다.\n&3\n다른 사람에게서 친절을 받으면 반드시 스프링으로 갚아야 합니다.\n총리님, 가셔도 됩니다! 하지만 다음에 다시 만날 때......')
                stage.setRectUnitHide(0, 0, 6, 6, 2)
                stage.say('&0\n고마워, 윤창.')
        vars[30] = 1
        stage.talk(2, 186, '주군, 빨리 가자......')
        stage.say('&0\n흠......')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[629] = 1
        return True
    if not vars[31] and not vars[33] and not vars[35] and stage.isInRect(0, 26, 4, 29, 7):
        stage.say('&0\n음, 포크?\n쉬두에서 가장 가까운 길은 어디인가요......?')
        if not vars[57]:
            stage.unit(21).setDir(stage.countDir(21, 0))
            stage.say('&21\n호숫가 도로는 넓고 안전합니다,\n산 근처 도로가 쉬두와 가깝습니다.\n어느 쪽을 선택해야 할까요? 음......')
        vars[31] = 1
    if not vars[32] and not vars[34] and not vars[36] and stage.isInRect(0, 15, 13, 18, 16):
        stage.say('어느 길로 가야 할까? 북쪽 계곡을 넘는 길이 험하긴 하지만, 그곳에는 매복할 곳이 없다고 들었어.')
        if not vars[57]:
            stage.unit(21).setDir(stage.countDir(21, 0))
            stage.say('&21\n하지만 저 장소를 꼭 봐주세요.\n북쪽에서는 먼지와 연기 구름이 피어올랐다,\n그곳에 매복이 숨어 있는 것 같아.\n&0\n누구라도 그렇게 생각할 거야,\n그래서 매복은 남쪽 도로에서 이루어져야 합니다.\n&21\n주군 말씀이 전적으로 맞습니다!\n속담에 있듯이, 진짜와 환상이 전략의 본질이다.\n정욱 주군 교육을 받았다......\n&0\n(이 시기에는 쉬운 남쪽 주요 도로를 피하세요,\n험난한 북쪽 길을 택하며,\n아마 더 안전할지도 몰라...... )')
        vars[32] = 1
    if not vars[32] and not vars[33] and not vars[35] and stage.isInRect(1025, 21, 15, 26, 19):
        stage.unit(84).show()
        stage.unit(363).show()
        stage.unit(364).show()
        stage.unit(365).show()
        stage.unit(366).show()
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.unit(84).setDir(stage.countDir(84, 0))
        stage.unit(84).setAction(7)
        stage.say('&84\n아, 그래서 여기 숨어 있는 거구나.\n이봐, 이봐, 네 운명을 받아들이는 게 좋을 거야.\n세계적으로 유명한 조조도 그렇게 창피할 수 있어!\n&0\n나는 레드 클리프스의 이름을 깨끗이 해야 한다.\n수치심이 씻겨 내려갈 때까지, 나는 죽지 않을 것이다.')
        stage.unit(84).setAction(0)
        vars[33] = 1
    if not vars[30] and not vars[34] and not vars[36] and stage.isInRect(1025, 0, 12, 5, 17):
        stage.unit(85).show()
        stage.unit(367).show()
        stage.unit(368).show()
        stage.unit(369).show()
        stage.unit(370).show()
        stage.unit(85).setDir(stage.countDir(85, 0))
        stage.unit(0).setDir(stage.countDir(0, 85))
        stage.unit(85).setAction(5)
        stage.say('&85\n하하하.\n벌써 조급해지고 있어.\n자, 내가 처리할게!')
        stage.unit(85).setAction(0)
        stage.say('&0\n응......\n그는 위험에서 벗어날 수 있는 한 걸음 앞에 있었다......')
        vars[34] = 1
    if not vars[32] and not vars[33] and not vars[35] and stage.isInRect(1025, 17, 7, 21, 12):
        stage.say('&0\n휴, 드디어 숨을 돌릴 수 있겠네요.\n이상하게 말하자면,\n주유와 공명가 여기서 매복을 설치한 게 아니야? 하하하!')
        stage.unit(34).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(234).show()
        stage.unit(235).show()
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.unit(0).setDir(stage.countDir(0, 34))
        stage.say('&34\n총리님께 그렇게 애쓰게 할 필요는 없어요.\n공명 씨의 전략은 완벽합니다.\n&0\n그-역시나, 여기서도.........\n&34\n조공.\n순종적으로 머리 위로 손을 내밀어.')
        if not vars[56]:
            stage.unit(2).setDir(stage.countDir(2, 0))
            stage.say('&2\n예상치 못하게 매복이 연달아 이어졌다......')
        if not vars[58]:
            stage.unit(15).setDir(stage.countDir(15, 0))
            stage.say('&15\n주군, 이건 나한테 맡겨.\n빨리 도망쳐!')
        if not vars[59]:
            stage.unit(13).setDir(stage.countDir(13, 34))
            stage.say('&13\n정말 말도 안 돼!\n조운, 이 일은 내가 너랑 해결할게.\n내 신성한 화살의 힘을 보여줄게!')
        vars[35] = 1
    if not vars[30] and not vars[34] and not vars[36] and stage.isInRect(1025, 11, 0, 15, 4):
        stage.say('모두들 버텨내세요. 이제 한 걸음만 더 남았습니다. 응!? 저기 누가 있어!')
        stage.unit(33).show()
        stage.unit(312).show()
        stage.unit(313).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(236).show()
        stage.unit(237).show()
        stage.unit(33).setDir(stage.countDir(33, 0))
        stage.unit(0).setDir(stage.countDir(0, 33))
        stage.say('&33\n하하하.\n조조, 정말 왔구나.\n전략가는 진정으로 뛰어난 전략을 가지고 있습니다.\n&0\n장, 장비......!\n짜증나는 공명은 그저 영리함을 과시하는 것뿐이다......\n&33\n흥! 조조!\n난 오래전부터 널 싫어했어,\n오늘 너는 여기서 죽을 거야!')
        if not vars[56]:
            stage.unit(2).setDir(stage.countDir(2, 33))
            stage.say('&2\n음, 그거 장비!\n우린 그를 이길 수 없어......')
        if not vars[58]:
            stage.unit(15).setDir(stage.countDir(15, 33))
            stage.say('&15\n힘에 관해서는 절대 지지 않을 거야!\n내가 가서 그를 죽일게.')
        if not vars[59]:
            stage.unit(13).setDir(stage.countDir(13, 0))
            stage.say('&13\n주군!\n내가 지킬게, 도망쳐야 해.\n감히 다가오는 자는 전부 쏠 거야!')
        vars[36] = 1
    if not vars[20] and stage.isInPos(1025, 27, 5):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 16, 14):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 4, 5):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[40] and stage.isNear(34, 2, False):
        stage.unit(2).setDir(stage.countDir(2, 34))
        stage.unit(34).setDir(stage.countDir(34, 2))
        stage.say('&2\n내 집 주군 머리카락 한 올도 건드리지 못하게 할 거야.\n&34\n이제 날 막을 수 있을지 보자!')
        vars[40] = 1
    if not vars[41] and stage.isNear(34, 13, False):
        stage.unit(13).setDir(stage.countDir(13, 34))
        stage.unit(34).setDir(stage.countDir(34, 13))
        stage.say('&13\n어서! 조운!\n&34\n너한테 신경 쓸 시간 없어!')
        vars[41] = 1
    if not vars[42] and stage.isNear(33, 2, False):
        stage.unit(33).setDir(stage.countDir(33, 2))
        stage.unit(2).setDir(stage.countDir(2, 33))
        stage.say('&33\n내 길을 막는 자는 누구든 자비를 베풀지 않을 것이다.\n&2\n숨길 필요 없어.\nme장료로 나는 주군 안전을 지킬 것을 맹세한다,\n목숨을 바치더라도 말이다!')
        vars[42] = 1
    if not vars[43] and stage.isNear(33, 13, False):
        stage.unit(13).setDir(stage.countDir(13, 33))
        stage.unit(33).setDir(stage.countDir(33, 13))
        stage.say('&33\n차라리 포기하는 게 낫겠어!\n조조 머리를 가져갈 거야.\n&13\n음, 어떻게 네가 성공하게 놔둘 수 있겠어!')
        vars[43] = 1
    if not vars[44] and stage.isNear(33, 15, False):
        stage.unit(15).setDir(stage.countDir(15, 33))
        stage.unit(33).setDir(stage.countDir(33, 15))
        stage.say('&15\n장비, 누가 더 강한지 결투 해보자!\n&33\n흥미롭네요, 한번 받아보세요!')
        fight = stage.startFight(15, 33, 5)
        fight.showUnit(False, '말해줄게,\n우리 할아버지 장이 제일 강해!', 10)
        fight.showUnit(True, '내 전략가는 한때 이렇게 말했다,\n이를 적을 과소평가하고 부주의하다고 합니다.', 0)
        stage.delay(4)
        fight.setAction(False, 8)
        fight.say(False, '왜 이렇게 횡설수설하지!', True)
        fight.showStart()
        fight.say(True, '내 묘기를 써!', True)
        fight.setAction(False, 0)
        fight.setAction(True, 2)
        fight.attack1(True, 2, True)
        stage.delay(6)
        fight.say(False, '정말 거만하구나!', True)
        fight.setAction(True, 0)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '와!', True)
        fight.setAction(False, 0)
        fight.setAction(True, 2)
        fight.attack1(True, 2, True)
        stage.delay(5)
        fight.setAction(False, 8)
        fight.say(False, '와, 대단하네요!', True)
        fight.setAction(True, 0)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        stage.delay(4)
        fight.say(True, '온 힘을 다해 야만인구나!\n이성적으로 굴어, 빨리 항복해!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 2, True)
        stage.delay(4)
        fight.say(False, '그게 내가 하고 싶은 말이야!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.setAction(True, 11)
        stage.delay(10)
        fight.say(False, '정말 지쳤어요, 정말 지쳤어요.\n왜 이 사람은 이렇게 에너지가 넘치는 거지......', True)
        fight.say(True, '아파!\n아니, 나는 여전히 주군의 안전을 지켜야 해.', True)
        stage.delay(5)
        fight.say(False, '야, 너 꽤 인상적이야!\n하지만 아직 멀리 떨어져 있어요.', True)
        fight.say(True, '당신의 성격과 함께,\n그가 정말 능력 있다고 생각하지 않아!', True)
        fight.end()
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n(총리님...... )\n후퇴, 후퇴.')
        stage.unit(3).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n아, 안 돼......\n좋아.\n나머지는 남에게 맡겨라. 후퇴!')
        stage.unit(34).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n쳇, 내가 진짜 망쳤어......\n후퇴!')
        stage.unit(33).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n아야, 너무 아파, 이 자식아.\n후퇴!')
        stage.unit(84).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n음, 좋지 않네요.\n후퇴!')
        stage.unit(85).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(80, 7, 0, 2):
        stage.say("&80\n음, 정말 오판이네요......\n하지만 속담에 있듯이, '적은 이기는 사람이 많은 사람을 이길 수 없다'는 말이 있습니다.\n어쨌든, 너도 도망칠 수 없어.")
        stage.unit(80).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(2, 7, 0, 2):
        stage.unit(2).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(21, 7, 0, 2):
        stage.unit(21).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(15, 7, 0, 2):
        stage.unit(15).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(13, 7, 0, 2):
        stage.unit(13).hide(1)
        vars[59] = 1
    if vars[30] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n휴, 드디어 위험에서 벗어났네요.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[629] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 쑨과 류의 추격 끝에 완전히 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
