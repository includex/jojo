# Source Generated with Decompyle++
# File: R_43.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 127, 213)
    stage.bottomTxt('조조', False, False, False)
    stage.delay(5)
    stage.bottomTxt('바이디 시티에서 그는 슈군 잔존 세력에 결정적인 패배를 안겼다.', True, False, False)
    stage.delay(8)
    stage.showHead(35, 191, 213)
    stage.delay(5)
    stage.bottomTxt('제갈량', True, True, False)
    stage.delay(5)
    stage.head(35).move(277, 227)
    stage.head(35).hide()
    stage.delay(5)
    stage.bottomTxt('그는 군대를 이끌고 동우로 도망쳤다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 23)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setEventName('그리고 다시 레드 클리프를 보았다')
    stage.setStageName('바이디 시 외곽의 산길')
    stage.showUnit(35, 5, 52, 1)
    stage.unit(35).move(50, 52, 1)
    stage.unit(35).setAction(0)
    stage.say('&35\n마침내 그들은 바이디성에서 위나라 군대를 차단했다.\n&35\n지금 동오군이 붉은 절벽을 방어하고 있을 거야,\n서둘러서 그들과 만나자.')
    stage.unit(35).setAction(0, 3)
    stage.say('&35\n더 큰 선을 위해 죽은 슈 병사들,\n네가 헛되이 죽게 공명 두지 않을 거야.\n&35\n여러분 모두에게 복수해야 합니다......')
    stage.delay(5)
    stage.unit(35).move(95, 52, 1)
    stage.unit(35).hide()
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    model.initLocalVar()
    stage.clsUnit()
    stage.bgSound(0)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            4,
            44,
            52,
            1],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('바이디 시 조조 본캠프')
    stage.say('&0\n공명 아이야, 또 도망가게 놔둬.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n마치 전쟁 전에 계획된 것처럼,\n패배한 후 그는 즉시 도망쳤다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n나도 그렇게 생각해.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n정확히 그렇습니다.\n그의 목표는 아군를 이기는 것이 아니었다,\n하지만 우리를 막으려는 건가요......')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n혹시 동우일까!?\n그는 동부 오 작전을 미리 계획했을 것이다.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n즉, 공명 시간을 벌고 있다는 뜻입니다.\n그래서 동우가 방어를 강화할 기회를 갖게 하려는 거지?')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.say('&0\n네, 틀림없습니다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n전투에 임하라! 적에게 더 이상 시간을 줄 수 없어!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n하지만 맹덕, 전쟁을 원한다고 하면서,\n어디서 공격할 거라 생각하십니까?\n&0\n동우가 우리와 맞서는 곳이 어디든,\n그곳 외에는 다른 곳이 없었다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n어디?')
    stage.delay(5)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n…… 레드 클리프스.')
    stage.delay(3)
    stage.unit(1).setAction(0, 1)
    stage.unit(19).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 43
    stage.setBattlePos([
        [
            9,
            9],
        [
            10,
            8],
        [
            9,
            10],
        [
            10,
            9],
        [
            11,
            8],
        [
            8,
            10],
        [
            8,
            9],
        [
            9,
            8],
        [
            10,
            7],
        [
            7,
            9],
        [
            8,
            8],
        [
            9,
            7],
        [
            7,
            8],
        [
            8,
            7],
        [
            9,
            6]])
    return False


def scene2():
    if stage.battleTest():
        stage.say('&0\n전투에 임하라!')
        stage.clsUnit()
        stage.setMenuVisible(False)
        model.setFace(128)
        stage.loadBg(1, 0)
        stage.draw()
        stage.showHead(0, 157, 212)
        stage.bottomTxt('조의 군대', False, False, False)
        stage.delay(5)
        stage.head(0).move(280, 227)
        stage.delay(5)
        stage.bottomTxt('그는 깊이 연결된 레드 클리프스로 향했다.', True, False, True)
        stage.loadBg(2, 57)
        stage.showUnits([
            [
                76,
                66,
                52,
                3],
            [
                88,
                52,
                41,
                2],
            [
                78,
                46,
                41,
                2],
            [
                79,
                40,
                41,
                2],
            [
                81,
                52,
                63],
            [
                86,
                46,
                63],
            [
                85,
                40,
                63],
            [
                35,
                52,
                52,
                1]])
        stage.draw()
        stage.setStageName('붉은 절벽: 손권군의 본진')
        stage.say('&76\n지 공명Mr, 지시를 따랐습니다,\n그리고 레드 클리프스에 대규모 군대를 배치했다.\n하지만 이것이 정말로 조조를 무너뜨릴 수 있을까?')
        stage.unit(35).setAction(6)
        stage.say('&35\n만약 육손 장군이 도왔다면,\n우리는 반드시 이길 거예요.')
        stage.unit(35).setAction(0)
        stage.delay(3)
        stage.unit(81).setAction(6)
        stage.say('&81\n우리는 완전히 준비되어 있습니다.\n걱정 마.')
        stage.unit(81).setAction(0)
        stage.delay(3)
        stage.unit(78).setAction(6)
        stage.say('&78\n하지만...... 만약 실패하면 어쩌지?')
        stage.unit(78).setAction(0)
        stage.delay(3)
        stage.unit(88).setAction(6)
        stage.say('&88\n네,\n위나라 군대에게 여러 번 패배하지 않았나?')
        stage.say('&88\n바로 이러한 무모한 전투들 때문에\n이는 슈의 몰락을 가속화했다,\n자랑 그만해.')
        stage.unit(35).setAction(0, 0)
        stage.say('&35\n당신이 장조 경 맞죠?\n이 상황에서는,\n어떻게 할 계획이야?')
        stage.unit(88).setAction(0)
        stage.say('&88\n그거 당연하지 않나요!\n물론 우리는 위나라와 평화를 협상했다,\n동오의 평화와 안정을 지키기 위해서였다.')
        stage.unit(35).setAction(11)
        stage.say('&35\n하하하.')
        stage.unit(88).setAction(6)
        stage.say('&88\n뭐가 그렇게 웃겨!')
        stage.unit(88).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(0)
        stage.say('&35\n장조 경, 결국 당신은 단지 문관일 뿐이니,\n현재 상황을 보는 것은 불가능합니다.')
        stage.unit(88).setAction(6)
        stage.say('&88\n뭐라고...... 너무 건방지군!')
        stage.unit(88).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(6)
        stage.say('&35\n묻고 싶어요,\n지금 우리가 위나라와 평화를 협상하고 있다고 생각하십니까,\n정말로 동우가 평화를 누릴 수 있을까?')
        stage.unit(35).setAction(0)
        stage.say('&35\n이제 삼자 체제는 무너졌고,\n평화 협상은 사실상 동부 오를 조조에게 내놓는 배신의 일종이었습니다.')
        stage.say('&35\n만약 평화 협상이 정말 이루어진다면,\n당신은 여전히 장관으로서 자신을 지킬 수 있습니다,\n하지만 어른들은 어떻게 할 손권을까요?')
        stage.say('&35\n분명히 그는 분명히 처형될 것이다.\n그래서 조위와의 평화 회담을 주장하는군요,\n그것은 충성심이나 정의감이 전혀 없다는 것을 보여줍니다.')
        stage.unit(88).setAction(6)
        stage.say('&88\n흥......')
        stage.say('&35\n오나라의 땅은 비옥하고 비옥했으며,\n선 가문은 3대째 통치해왔다,\n이 나라는 꽤 강력합니다.\n&35\n게다가 양쯔강이라는 자연 장벽이 있어 방어는 쉽지만 공격하기는 어렵다.')
        stage.unit(35).setAction(6)
        stage.say('&35\n그런 나라는 단 한 번도 전투를 치르지 않으며,\n그냥 조조 알아서 할 거야?')
        stage.unit(35).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(0, 1)
        stage.say('&35\n과거 슈 산악 지역의 농업은 뒤처져 있었고,\n국가의 건국은 아직 짧았다,\n그리고 이 나라는 신흥국입니다.')
        stage.unit(35).setAction(0, 0)
        stage.say('&35\n그럼에도 불구하고, 마지막 군주 유산과 그의 장군들과 병사들은,\n아니면 끝까지 위나라의 강력한 나라와 맞서야 할까요?')
        stage.unit(35).setAction(2)
        stage.say('&35\n그러니까 네가 그 얘기를 할 권리는 없......\n마지막 황제 유산과 서나라 병사들의 치열한 전투.')
        stage.unit(88).setAction(0)
        stage.say('&88\n음음!')
        stage.unit(76).setAction(3)
        stage.say('&76\n공명Sir, 이해해.\n우리는 끝까지 싸울 수밖에 없습니다.')
        stage.unit(76).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(0, 1)
        stage.say('&35\n네.')
        stage.unit(35).setAction(6)
        stage.say('&35\n그럼 내려가서 전투 준비해.\n이게 내 작별 인사야.\n&76\n흠.')
        stage.unit(35).setAction(0)
        stage.delay(3)
        stage.unit(35).move(40, 52, 3)
        stage.delay(3)
        stage.say('&79\n공명......')
        stage.unit(35).setAction(0, 0)
        stage.delay(3)
        stage.unit(35).setAction(6)
        stage.say('&35\n형, 몸조심해.')
        stage.say('&79\n몸조심하세요.')
        stage.delay(5)
        stage.unit(35).setAction(0)
        stage.delay(3)
        stage.unit(35).move(16, 52, 3)
        stage.unit(35).hide()
        stage.say('&76\n이 사람 공명 있어......\n육손, 그를 믿어야 할까?')
        stage.unit(81).setAction(0, 1)
        stage.delay(3)
        stage.unit(81).setAction(6)
        stage.say('&81\n어떻게 말해야 할까요?')
        stage.unit(81).setAction(0)
        stage.say('&81\n주군, 지금 조조 가장 두려워하는 것은 공명,\n동오를 구할 수 있는 유일한 사람은 공명입니다.\n&76\n흠......')
        stage.bgSound(-1)
        stage.clsUnit()
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n이번 전투는 이전과는 달랐다,\n주요 전장은 동우 강변에 있었다.\n&20\n유감스럽게도 동오와 공명 이미 강가를 따라 대형을 형성한 것 같습니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n백이디 시에서 백호옥을 찾지 못했나요?\n&15\n청룡과 주홍새옥과는 좀 다르지 않나요?\n&21\n네.\n이 귀한 옥 조각은 다른 두 조각과 다릅니다,\n풍수 수련자 부대에서 사용됩니다.\n&15\n아, 그게 바로 백호의 전략이군요,\n회복 클래스 중에서 가장 강한가요?\n&19\n바로 그거예요. 정확히 말하면,\n모든 병력의 체력을 회복시킬 수 있다,\n그리고 비정상적인 상태를 치료합니다.\n&15\n이거 정말 강력해!')
    if stage.unitClickTest(1):
        stage.say('&1\n그래서 다시 레드 클리프에서 싸워야 하는 거야?\n그 시절 그는 동우가 성공하도록 허락했다,\n이번에는 자신의 결백을 밝혀야 한다.')
    if stage.unitClickTest(4):
        stage.say('&4\n그때 붉은 절벽 전투 때 나는 아직 군대에 입대하지 않았다,\n하지만 사람들이 자주 언급하는 걸 듣습니다.\n&4\n이곳은 아군와 깊은 연관이 있습니다.')
    if stage.unitClickTest(19):
        stage.say('&19\n공명, 네가 물 전투에서 어떤 다른 기술을 가지고 있는지 보자.')
    if stage.unitClickTest(21):
        stage.say('&21\n무슨 일이 있어도 상륙할 수만 있다면 이길 가능성이 있어.\n하지만 이번에는 동오 해군이 어떤 전술을 사용할지는 알 수 없다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
