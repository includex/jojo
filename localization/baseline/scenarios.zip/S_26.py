# Source Generated with Decompyle++
# File: S_26.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(2,7)'])
    stage.nearEvent([
        34,
        26,
        33,
        28])
    stage.nearEvent([
        32,
        27,
        1,
        34], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 32, 0, 0, 1)
    stage.createFriend([
        {
            'id': 27,
            'hide': 1,
            'x': 3,
            'y': 0,
            'lv': 2,
            'ai': 1,
            'i': 0 },
        {
            'id': 26,
            'hide': 1,
            'x': 1,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 1 },
        {
            'id': 28,
            'hide': 1,
            'x': 2,
            'y': 1,
            'lv': 4,
            'ai': 1,
            'i': 2 }])
    stage.createEnemy(
        [{'id': 32, 'x': 2, 'y': 10, 'lv': 6, 'ai': 0, 'i': 0},
         {'id': 33, 'x': 1, 'y': 9, 'lv': 6, 'ai': 0, 'i': 1},
         {'id': 42, 'x': 1, 'y': 11, 'lv': 4, 'ai': 0, 'i': 2},
         {'id': 41, 'x': 3, 'y': 11, 'lv': 4, 'ai': 0, 'i': 3},
         {'id': 258, 'x': 0, 'y': 12, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 259, 'x': 2, 'y': 12, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 282, 'x': 0, 'y': 10, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 34, 'x': 2, 'y': 8, 'lv': 6, 'ai': 0, 'i': 7},
         {'id': 43, 'x': 3, 'y': 9, 'lv': 4, 'ai': 0, 'i': 8},
         {'id': 210, 'x': 0, 'y': 8, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 211, 'x': 4, 'y': 8, 'lv': 0, 'ai': 0, 'i': 10},
         {'id': 504, 'x': 1, 'y': 7, 'lv': -15, 'ai': 0, 'i': 11},
         {'id': 505, 'x': 3, 'y': 7, 'lv': -15, 'ai': 0, 'i': 12},
         {'id': 506, 'x': 0, 'y': 6, 'lv': -15, 'ai': 0, 'i': 13},
         {'id': 507, 'x': 2, 'y': 6, 'lv': -15, 'ai': 0, 'i': 14},
         {'id': 508, 'x': 4, 'y': 6, 'lv': -15, 'ai': 0, 'i': 15},
         {'id': 509, 'x': 1, 'y': 5, 'lv': -15, 'ai': 0, 'i': 16},
         {'id': 510, 'x': 3, 'y': 5, 'lv': -15, 'ai': 0, 'i': 17},
         {'id': 511, 'x': 2, 'y': 4, 'lv': -15, 'ai': 0, 'i': 18},
         {'id': 3, 'hide': 1, 'x': 28, 'y': 19, 'dir': 0, 'lv': 6, 'ai': 3, 'targetId': 32, 'i': 19},
         {'id': 260, 'hide': 1, 'x': 27, 'y': 20, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 20},
         {'id': 261, 'hide': 1, 'x': 29, 'y': 20, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 21},
         {'id': 262, 'hide': 1, 'x': 27, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 22},
         {'id': 263, 'hide': 1, 'x': 29, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 23},
         {'id': 283, 'hide': 1, 'x': 28, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 24},
         {'id': 284, 'hide': 1, 'x': 28, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 32, 'i': 25},
         {'id': 35, 'hide': 1, 'x': 31, 'y': 13, 'dir': 0, 'lv': 6, 'ai': 3, 'targetId': 32, 'i': 26},
         {'id': 64, 'hide': 1, 'x': 31, 'y': 15, 'dir': 0, 'lv': 4, 'ai': 3, 'targetId': 32, 'i': 27},
         {'id': 40, 'hide': 1, 'x': 31, 'y': 13, 'dir': 0, 'lv': 4, 'ai': 1, 'targetId': 32, 'i': 28},
         {'id': 212, 'hide': 1, 'x': 31, 'y': 14, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 29},
         {'id': 213, 'hide': 1, 'x': 31, 'y': 14, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 30},
         {'id': 214, 'hide': 1, 'x': 31, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 31},
         {'id': 234, 'hide': 1, 'x': 31, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 32},
         {'id': 235, 'hide': 1, 'x': 31, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 33},
         {'id': 236, 'hide': 1, 'x': 31, 'y': 17, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 34},
         {'id': 237, 'hide': 1, 'x': 31, 'y': 17, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 32, 'i': 35}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 2,
            'y': 2,
            'hide': 1 },
        {
            'idx': 1,
            'y': 1,
            'hide': 1 },
        {
            'idx': 2,
            'x': 1,
            'hide': 1 },
        {
            'idx': 3,
            'x': 2,
            'y': 3,
            'hide': 1 },
        {
            'idx': 4,
            'x': 3,
            'y': 2,
            'hide': 1 },
        {
            'idx': 5,
            'x': 1,
            'y': 3,
            'hide': 1 },
        {
            'idx': 6,
            'x': 3,
            'y': 1,
            'hide': 1 },
        {
            'idx': 7,
            'x': 1,
            'y': 1,
            'hide': 1 },
        {
            'idx': 8,
            'y': 2,
            'hide': 1 },
        {
            'idx': 9,
            'x': 2,
            'hide': 1 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(42, -1, 0, -1, 0, 22)
    stage.setEnemyEquip(41, -1, 0, -1, 0, 23)
    stage.loadBg(26)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab30')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab30')
    stage.draw()
    stage.bgSound(6)
    stage.unit(32).setAction(9)
    stage.say('&32\n쉭......\n드디어 탈출했다......\n공명와 둘째 형의 지원군이 도착했나?')
    stage.unit(42).setDir(stage.countDir(42, 32))
    stage.unit(41).setDir(stage.countDir(41, 32))
    stage.unit(42).setAction(8)
    stage.say('&42\n주군!\n여기서 시간을 낭비할 여유가 없었다.\n적이 언제든 따라잡을 수 있었다......\n&41\n주군, 관장군과 공명의 증원군이 곧 도착할 것으로 예상됩니다.\n그래서 적군와 최대한 멀리 떨어져 있을 수 없다면......')
    stage.unit(41).setDir(stage.countDir(41, 504))
    stage.say('&41\n주군를 따르는 사람들,\n아마도 그냥 ......를 버리는 것일지도 모른다')
    stage.unit(34).setDir(stage.countDir(34, 32))
    stage.say('&34\n주군!\n먼저 공명 씨와의 만남 장소로 도망쳐 주세요.\n&43\n네.\n이건 나한테 맡겨, 지엔용 장군과 자룡 장군!\n우리는 일시적으로 조조를 가로막을 것입니다.')
    stage.unit(33).setDir(stage.countDir(33, 32))
    stage.say('&33\n형님, 이건 쯔롱과 다른 사람들에게 맡겨요,\n이런 곳에서 죽고 싶진 않겠지?')
    stage.unit(32).setDir(stage.countDir(32, 34))
    stage.say('&32\n하지만 저를 따르는 사람들은요......\n&34\n주군If 아직도 그렇게 생각한다면,\n결국 여기 묻힐 뿐이야.\n&32\n………\n&34\n평민들은 걱정하지 마세요.\n조나라 군대는 아마 이런 일들을 처리하지 않았을 것이다\n사람들은 저항하지 않는다.\n&32\n…… 쯔롱, 네가 믿고 있어.\n나머지 줄은 네게 맡길게.\n좋아, 바로 만남 장소로 가자!\n&34\n네! 우리도 곧 도착할 거예요.\n&32\n여기 여자분들과 아두를 남겨둘게,\n내 빠른 말을 따라잡을 수 없어.')
    stage.talk(154, 154, '주군, 몸조심해......')
    stage.talk(155, 155, '우리 걱정하지 마.')
    stage.say('&34\n목숨을 걸더라도 조운,\n그는 또한 주군 부부와 자녀들을 보호해야 했다.\n&43\n이건 우리에게 맡겨.\n주군The 빨리 갈수록 좋아요!')
    stage.unit(259).move(2, 19, 2)
    stage.unit(258).move(0, 19, 2)
    stage.unit(41).move(3, 18, 2)
    stage.unit(42).move(1, 18, 2)
    stage.unit(32).move(2, 17, 2)
    stage.unit(282).move(0, 17, 2)
    stage.unit(33).move(1, 16, 2)
    stage.unit(34).setDir(stage.countDir(34, 506))
    stage.say('&34\n걱정 마.\n천천히 앞으로 나아가세요.')
    stage.unit(43).setDir(stage.countDir(43, 510))
    stage.say('&43\n여러분, 빨리 떠나세요.\n빨리, 서둘러, 조의 군대가 우리를 쫓고 있어!')
    stage.unit(34).move(1, 11, 2)
    stage.unit(43).move(2, 10, 2)
    stage.unit(210).move(0, 9, 2)
    stage.unit(211).move(4, 9, 2)
    stage.unit(504).move(1, 9, 2)
    stage.unit(505).move(3, 9, 2)
    stage.unit(506).move(0, 8, 2)
    stage.unit(507).move(2, 8, 2)
    stage.unit(508).move(4, 8, 2)
    stage.unit(509).move(1, 7, 2)
    stage.unit(510).move(3, 7, 2)
    stage.unit(511).move(2, 6, 2)
    stage.unit(42).setDir(stage.countDir(42, 32))
    stage.say('&42\n주군, 빨리 가.\n&32\n음-음 .........')
    stage.unit(259).move(7, 19, 1)
    stage.unit(258).move(6, 22, 1)
    stage.unit(41).move(7, 21, 1)
    stage.unit(42).move(5, 21, 1)
    stage.unit(32).move(6, 20, 1)
    stage.unit(282).move(4, 20, 1)
    stage.unit(33).move(5, 19, 1)
    stage.say('&34\n거의 다 왔어, 거의 다 왔어!\n&43\n…… 흠!?\n그-그건 ......')
    stage.bgSound(3)
    stage.unit(27).show()
    stage.unit(26).show()
    stage.unit(28).show()
    stage.unit(1, 1).show()
    stage.unit(2, 1).show()
    stage.say('&504\n아, 조준이다!\n&507\n빨리, 목숨을 걸고 도망쳐!')
    stage.unit(504).move(1, 12, 2)
    stage.unit(505).move(3, 12, 2)
    stage.unit(506).move(0, 11, 2)
    stage.unit(507).move(2, 11, 2)
    stage.unit(508).move(3, 9, 2)
    stage.unit(509).move(1, 10, 2)
    stage.unit(510).move(3, 10, 2)
    stage.unit(511).move(2, 9, 2)
    stage.setUnitStatus([
        {
            'hStatus': [
                9],
            'unit': stage.unit(504) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(505) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(506) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(507) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(508) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(509) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(510) },
        {
            'hStatus': [
                9],
            'unit': stage.unit(511) }])
    stage.unit(504).setAI(5, 32, 0, 0)
    stage.unit(505).setAI(5, 32, 0, 0)
    stage.unit(506).setAI(5, 32, 0, 0)
    stage.unit(507).setAI(5, 32, 0, 0)
    stage.unit(508).setAI(5, 32, 0, 0)
    stage.unit(509).setAI(5, 32, 0, 0)
    stage.unit(510).setAI(5, 32, 0, 0)
    stage.unit(511).setAI(5, 32, 0, 0)
    stage.unit(43).setAI(3, 32, 0, 0)
    stage.unit(210).setAI(3, 32, 0, 0)
    stage.unit(211).setAI(3, 32, 0, 0)
    stage.unit(43).setAction(5)
    stage.say('&43\n당황하지 마!\n모두 진정하세요!')
    stage.unit(43).setAction(0)
    stage.unit(34).setAction(4)
    stage.say('&34\n음, 음, ...... 아, 안 돼!\n여성들과 떨어져 있어.\n정말 부끄럽습니다!')
    stage.unit(28).setAction(7)
    stage.say('&28\n하하하.\n유비Kid, 드디어 너를 따라잡았어."')
    stage.unit(28).setAction(0)
    stage.say('&7\n주력 부대주군 도착하기 전에,\n먼저 전력을 다해 합시다!\n&1\n돌격, 샤후우엔!')
    stage.unit(26).setDir(stage.countDir(26, 1))
    stage.say('&26\n그는 장군하후돈 그랬다.\n&27\n저쪽에는 원래 징저우 사람들이 있었다.\n뜻밖에도, 내가 항복한 후에,\n그는 실제로 자신의 동료들을 쫓고 싶어 한다......')
    stage.setWinCondition('승리 조건\n1. 유비 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('유비 격퇴해!')
    stage.unit(32).heightLight()
    stage.unit(34).setAction(8)
    stage.say('&34\n간 부인, 미 부인, 어디 계세요?\n제발 대답해 주세요!')
    stage.talk(154, 154, '아......\n조 장군님, 저 왔습니다......')
    stage.unit(34).setDir(0)
    stage.say('&34\n아, 간 부인, 괜찮으세요......?\n미 부인은 후계자 아두와 함께 있나요?')
    stage.talk(154, 154, '길을 따라 마을을 지날 때,\n그들은 원래 함께 있었다......')
    stage.say('&34\n!! 내가 찾아볼게.\n슈미는 자신의 임무를 완전히 다하지 못했다,\n먼저 가주군 곳으로 가......')
    stage.talk(154, 154, '장군님, 저 걱정하지 마세요.\n너도 특히 조심해야 해......')
    stage.unit(41).setDir(stage.countDir(41, 34))
    stage.say('&41\n오, 오... 이거 큰일이야.........\n조운 조조에게 들킨 것 같았다.')
    stage.unit(42).setAction(4)
    stage.say('&42\n아아...... 어떻게 이럴 수가?\n이제 끝났어......')
    stage.unit(33).setDir(stage.countDir(33, 42))
    stage.say('&33\n포기하지 마세요.')
    stage.unit(33).setDir(stage.countDir(33, 32))
    stage.say('&33\n형, 내가 다리 쪽에 가서 잠시 막을게조조.')
    stage.unit(32).setDir(stage.countDir(32, 33))
    stage.say('&32\n흠, 네가 믿고 있어.\n우리의 현재 상황......\n이미 중요한 순간이었다......')
    stage.unit(33).move(11, 18, 3)
    stage.unit(33).setAI(2)
    stage.unit(32).setAI(6, -1, 18, 18)
    stage.unit(41).setAI(6, -1, 18, 18)
    stage.unit(42).setAI(6, -1, 18, 18)
    stage.unit(258).setAI(6, -1, 18, 18)
    stage.unit(259).setAI(6, -1, 18, 18)
    stage.unit(282).setAI(6, -1, 18, 18)
    stage.unit(34).move(2, 7, 0)
    stage.unit(34).setAction(8)
    stage.say('&34\n미 부인, 어디 계세요!\n제발 대답해 주세요! 저는 조운어요!')
    stage.talk(155, 155, '응? 자오, 자오 장군......\n아두와 내가 여기 있어......')
    stage.say('&34\n어? 괜찮아! 정말 다행이야......\n이봐, 이곳은 위험해.\n말 타는 거 도와줄게!')
    stage.talk(155, 155, '다리가 다쳤어요......\n조운, 제발 아두를 지켜줘!')
    stage.unit(34).setAction(10)
    stage.say('&34\n어!?\n어떻게, 어떻게 이런 일이 일어날 수 있지......\n누가 그 여자가 우물에 몸을 던질 줄 알았겠는가......')
    stage.unit(34).setAction(4)
    stage.say('&34\n미 부인......\n이걸 어떻게 설명해야 하겠주군......')
    stage.unit(34).setDir(2)
    stage.say('&34\n한숨, 먼저 후계자를 주군에게 보내자......\n조운 내 손에 맡기주군 ......')
    stage.unit(34).setAI(6, -1, 1, 9)
    stage.unit(27).setAI(3, 32, 0, 0)
    stage.unit(26).setAI(3, 34, 0, 0)
    stage.startOper()
    vars[526] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 2:
        stage.unit(34).setAI(6, -1, 2, 13)
        vars[11] = 1
    if not vars[12] and stage.round() == 3:
        stage.bgSound(5)
        stage.unit(0, 1).show()
        stage.unit(3, 1).show()
        stage.unit(4, 1).show()
        stage.unit(5, 1).show()
        stage.unit(6, 1).show()
        stage.unit(7, 1).show()
        stage.unit(8, 1).show()
        stage.unit(9, 1).show()
        stage.unit(0).setAction(5)
        stage.say('좋습니다, 전군 부대가 적군을 추월했습니다.\n전군이 돌격합니다! 유비를 생포합시다!')
        stage.unit(0).setAction(0)
        vars[12] = 1
    if not vars[13] and stage.round() == 3:
        stage.unit(34).setAI(5, 32, 0, 0)
        vars[13] = 1
    if not vars[20] and stage.isInPos(1025, 2, 7):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if vars[32] and not vars[6] and stage.totalRectUnit(2, 24, 4, 28, 8) >= 6:
        stage.unit(32).setAction(9)
        stage.say('&32\n드디어......\n마침내 위험에서 벗어났다......\n정말 지쳤어요......')
        stage.unit(32).setAI(6, -1, 28, 23)
        vars[6] = 1
    if not vars[2] and not vars[30] and stage.isInRect(32, 15, 15, 21, 21):
        stage.unit(32).setAction(2)
        stage.say('&32\n휴, 먼저 잠깐 쉬자......\n여러분, 잠시 쉬세요!')
        stage.unit(41).setAI(3, 32, 0, 0)
        stage.unit(42).setAI(3, 32, 0, 0)
        stage.unit(258).setAI(3, 32, 0, 0)
        stage.unit(259).setAI(3, 32, 0, 0)
        stage.unit(282).setAI(3, 32, 0, 0)
        vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(32, 13, 0, 31, 10):
        stage.unit(3).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(262).show()
        stage.unit(263).show()
        stage.unit(283).show()
        stage.unit(284).show()
        stage.unit(3).setAction(5)
        stage.say('&3\n아직 시간이 있을 거야, 그렇지?\n빨리, 구해주군!')
        stage.unit(3).setAction(0)
        vars[31] = 1
    if vars[31] and not vars[32] and stage.isInRect(32, 24, 0, 31, 10) and stage.curCamp() == 0:
        stage.unit(35).show()
        stage.unit(35).move(30, 9, 0)
        stage.unit(40).show()
        stage.unit(40).move(31, 8, 0)
        stage.unit(212).show()
        stage.unit(212).move(30, 10, 0)
        stage.unit(213).show()
        stage.unit(213).move(31, 9, 0)
        stage.unit(214).show()
        stage.unit(214).move(30, 11, 0)
        stage.unit(64).show()
        stage.unit(64).move(31, 10, 0)
        stage.unit(234).show()
        stage.unit(234).move(30, 12, 0)
        stage.unit(235).show()
        stage.unit(235).move(31, 11, 0)
        stage.unit(236).show()
        stage.unit(236).move(30, 13, 0)
        stage.unit(237).show()
        stage.unit(237).move(31, 12, 0)
        stage.unit(40).setDir(stage.countDir(40, 32))
        stage.say('&40\n주군, 무사하니?')
        stage.unit(32).setDir(stage.countDir(32, 40))
        stage.say('&32\n선첸, 공명, 드디어 왔구나!')
        stage.unit(35).setDir(stage.countDir(35, 32))
        stage.say('&35\n주군, 안심해.\n모든 게 계획대로 진행되고 있어,\n이 만남은 예상된 일이었다.')
        stage.unit(32).setDir(stage.countDir(32, 64))
        stage.unit(64).setDir(stage.countDir(64, 32))
        stage.say('&64\n삼촌, 조카가 늦었어요.\n하지만 이제 안심할 수 있어.\n&32\n류치, 진심으로 감사드립니다.')
        stage.unit(35).setAI(3, 32, 0, 0)
        stage.unit(64).setAI(3, 32, 0, 0)
        stage.unit(40).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        vars[32] = 1
    if not vars[33] and stage.isInRect(32, 24, 23, 31, 23):
        stage.resumeCtrl()
        stage.unit(32).setAction(5)
        stage.say('&32\n드디어 위험에서 벗어난 것 같아.\n휴, 정말 아슬아슬했네요.\n전군을 후퇴시켜라!')
        stage.unit(32).setAction(0)
        stage.unit(32).hide()
        vars[53] = 1
        if vars[32] and not vars[50]:
            stage.say('&35\n그래서 저도 ......어요.')
            vars[50] = 1
        if vars[31] and not vars[55]:
            stage.say('&3\n주군 무사히 탈출했어?\n좋아, 후퇴!')
            vars[55] = 1
        if not vars[56]:
            stage.say('&33\n야, 나 두고 가지 마!\n후퇴!')
            vars[56] = 1
        if not vars[54]:
            stage.say('&34\n휴.\n정말 힘든 싸움이었어요!')
            vars[54] = 1
        stage.setRectUnitHide(0, 0, 31, 23, 2)
        stage.say('&0\n흠, 또 도망쳤유비?\n그만둬, 유비군은 이미 큰 피해를 입었어.\n전군을 후퇴시켜라!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[626] = 1
        vars[33] = 1
        return True
    if not vars[2] and not vars[34] and stage.isInRect(34, 12, 15, 21, 21):
        stage.unit(34).setDir(stage.countDir(34, 32))
        stage.unit(32).setDir(stage.countDir(32, 34))
        stage.unit(34).setAction(4)
        stage.say('&34\n주요 및 주군......\n사과드립니다......\n&32\n오, 쯔롱. 괜찮아?\n&34\n쯔롱은 다치지 않았고, 아두 세자는 건강합니다,\n하지만 부인......\n쯔롱은 ......를 지키지 못했다')
        stage.unit(32).setAction(4)
        stage.say('&32\n정말......?\n&32\n좋아, 최선을 다했어.\n아무 일도 일어나지 않는 한 그걸로 충분해.\n&32\n쯔롱, 고마워. 넌 나를 위해 살아야 해.\n&34\n주군.........')
        if not vars[56]:
            stage.unit(32).setDir(stage.countDir(32, 33))
            stage.say('&32\n전군을 후퇴시켜라!\n셋째 형, 그 다리는 네게 맡길게!\n조의 군대를 잠시 막아줘!')
            stage.unit(33).setDir(stage.countDir(33, 32))
            stage.unit(33).setAction(2)
            stage.say('&33\n내게 맡겨!')
            stage.unit(33).setDir(3)
        stage.unit(32).setAI(6, -1, 20, 6)
        stage.unit(34).setAI(3, 32, 0, 0)
        vars[2] = 1
        vars[34] = 1
    if not vars[2] and not vars[35] and stage.isInRect(1025, 13, 5, 21, 14):
        stage.talk(41, 186, '주요 주군......\n적은 뒤에서 공격했다,\n그러면 우리도 포위당할 거야!')
        stage.unit(32).setAction(5)
        stage.say('&32\n어떻게 이럴 수 있지!\n다른 방법은 없었다—적 진형의 중앙으로 돌파하는 것!\n전면 군대 공격!')
        stage.unit(32).setAction(0)
        stage.unit(32).setAI(6, -1, 20, 6)
        stage.unit(34).setAI(3, 32, 0, 0)
        stage.unit(33).setAI(3, 32, 0, 0)
        vars[2] = 1
        vars[35] = 1
    if not vars[36] and stage.isInRect(3, 17, 3, 23, 10):
        stage.unit(3).setDir(stage.countDir(3, 32))
        stage.unit(32).setDir(stage.countDir(32, 3))
        stage.say('&3\n형, 괜찮아?\n&32\n드디어 왔구나.\n이제부터는 당신에게 달려 있습니다.\n&3\n네.')
        stage.unit(32).setAI(6, -1, 26, 6)
        stage.unit(3).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(283).setAI(1)
        stage.unit(284).setAI(1)
        vars[36] = 1
    if not vars[35] and not vars[37] and not vars[56] and stage.isInRect(1, 7, 15, 10, 23):
        stage.unit(1).setDir(stage.countDir(1, 33))
        stage.say('&1\n뭐라고?\n장비 혼자 다리를 지키나요?\n어떻게 이게 ...... 수 있지!?\n&1\n네, 맞아요!\n이건 분명 공명 함정일 거야,\n다리 근처에서 매복이 있을 거야, 맞지!?')
        vars[37] = 1
    if not vars[40] and stage.isNear(34, 26, False):
        stage.unit(34).setDir(stage.countDir(34, 26))
        stage.unit(26).setDir(stage.countDir(26, 34))
        stage.say('&34\n절박하면 비켜.')
        stage.say('&26\n자랑 그만해!\n내가 처리할게.')
        fight = stage.startFight(26, 34, 5)
        fight.showUnit(False, '네가 그렇게 죽고 싶어 한다면,\n아직 늦지 않았어,\n그럼 잠시 보내줄게!', 0)
        fight.showUnit(True, '수다 떨지 마!\n결과는 아직 알려지지 않았습니다!', 8)
        fight.showStart()
        fight.setAction(False, 10)
        fight.say(False, '네가 나를 막으려 한다면,\n저는 최선을 다할 수밖에 없습니다!', True)
        fight.setAction(True, 4)
        fight.say(True, '뭐라고!?', True)
        fight.setAction(True, 8)
        fight.say(True, '나—어떻게 질 수 있겠어!?', True)
        fight.setAction(True, 3)
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack2(True, 0, True)
        fight.attack1(True, 3, False)
        fight.setAction(False, 8)
        fight.say(False, '이런 무술에서 나랑 경쟁하고 싶다니!\n이걸 받아라!', True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, False)
        fight.attack1(False, 0, True)
        stage.delay(10)
        fight.setAction(True, 11)
        fight.say(True, '와, 정말 대단하네요......\n와!', True)
        fight.death(False)
        fight.setAction(False, 0)
        fight.say(False, '이제 날 막을 수 있을지 보자!', True)
        fight.setAction(False, 1)
        fight.setAction(False, 3)
        fight.setAction(False, 1)
        fight.say(False, '흠!?\n...... 이 사람이 무기를 들고 있는 거야!?', True)
        fight.setAction(False, 3)
        stage.delay(10)
        fight.setAction(False, 6)
        fight.say(False, '정말 멋진 검이군요.\n이게 청강검임에 틀림없어!', True)
        fight.setAction(False, 0)
        fight.say(False, '그럼 이 사람이 샤후우엔인가요?\n그가 너무 일찍 죽었다니 안타깝다......', True)
        fight.end()
        stage.unit(26).hide(2)
        vars[40] = 1
    if not vars[42] and stage.isNear(33, 28, False):
        stage.unit(28).setDir(stage.countDir(28, 33))
        stage.unit(33).setDir(stage.countDir(33, 28))
        stage.say('&28\n장비, 나랑 싸워보자!\n&33\n흥!')
        fight = stage.startFight(28, 33, 5)
        fight.showUnit(False, '그리고 실제로 연나라의 장이더에게 도전했다.\n참 뻔뻔하군!\n살아서 돌아올 생각도 하지 마!', 10)
        fight.showUnit(True, '나는 샤후우제야!\n네 자랑스러운 말은 오늘까지밖에 안 돼!\n내가 얼마나 강한지 보여줄게!', 9)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '이걸 받아라!', False)
        fight.setAction(False, 10)
        fight.setAction(False, 10)
        fight.setAction(False, 10)
        fight.setAction(True, 6)
        fight.say(True, '(으윽! \n정말 큰 기세로군. 한 발짝도 움직일 수가 없어!\n…… 으윽, 공격해 온다!)', True)
        fight.setAction(False, 2)
        fight.attack2(False, 1, False)
        fight.say(True, '음, 와......', True)
        stage.delay(10)
        fight.setAction(True, 11)
        fight.death(False)
        fight.setAction(False, 1)
        fight.setAction(False, 10)
        fight.say(False, '뭐라고! 그게 전부야!', True)
        fight.setAction(False, 8)
        fight.say(False, '다음은 누구야!', True)
        fight.end()
        stage.unit(28).hide(2)
        vars[42] = 1
    if not vars[43] and stage.isNear(32, 27, True):
        stage.unit(27).setDir(stage.countDir(27, 32))
        stage.unit(32).setDir(stage.countDir(32, 27))
        stage.say('&27\n유비, 목숨 걸고 와!\n&32\n응? 원핀이야?\n&32\n왜 여기 있어?\n네가 징저우를 배신하고 이제 조조로 망신한 것 같군.\n&27\n뭐라고 했어......!?\n이는 징저우가 전쟁으로 황폐해지는 것을 막기 위한 조치이기도 했다.\n그때서야 그는 마지막 수단을 택할 수밖에 없었다.\n&32\n그렇다면 왜 그들은 징저우 사람들을 쫓아 죽였을까요,\n이게 그냥 널 기쁘게 하려는 거 아니조조?\n&27\n이미 조 재상에게 항복했으니, 그는 내 주군이야,\n총리의 부하로서 명령을 따라야 합니다,\n하지만...... 저도 원하지 않아요......\n&27\n이제는 뭐가 옳은지조차 모르겠어요......\n&27\n유비, 빨리 도망쳐!\n그 후에 나는 직위를 사임하고 은둔할 것이다,\n다시는 전쟁에 가지 마. 안녕!\n&32\n원핑 장군......')
        stage.unit(27).hide()
        vars[43] = 1
    if not vars[44] and stage.isNear(1, 34, True):
        stage.unit(1).setDir(stage.countDir(1, 34))
        stage.unit(34).setDir(stage.countDir(34, 1))
        stage.say('&1\n이번에는 이전 패배를 함께 갚아야 해!\n&34\n좋지 않아! 이런 상대를 마주하다니, 정말 운이 나쁘다!')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n그럼 공명 먼저 후퇴해.')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(41, 7, 0, 2):
        stage.say('&41\n정말 실수였다.\n와!')
        stage.unit(41).hide(2)
        stage.getItem(130, -1, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(42, 7, 0, 2):
        stage.say('&42\n아직 죽고 싶지 않아.\n음음!')
        stage.unit(42).hide(2)
        stage.getItem(129, -1, True, 1027)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(32, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&32\n음, 이렇게 될 줄은 몰랐어요......')
        stage.unit(32).hide()
        if vars[32] and not vars[50]:
            stage.say('&35\n주군 무사히 도망친 것 같아.\n그래서 저도 물러났습니다.')
            vars[50] = 1
        if vars[31] and not vars[55]:
            stage.say('&3\n좋아, 후퇴!')
            vars[55] = 1
        if not vars[56]:
            stage.say('&33\n다른 방법이 없었다. 후퇴!')
            vars[56] = 1
        if not vars[54]:
            stage.say('&34\n주님, 주군!\n후퇴!')
            vars[54] = 1
        stage.setRectUnitHide(0, 0, 31, 23, 2)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n아, 안 돼......')
        if not vars[34]:
            stage.talk(0, 0, '아, 실제로 잡을 줄은 몰랐조운!\n잘했어요!')
            stage.say('&34\n(음, 이거 안 좋네......\n갑옷 안에 숨겨진 후계자를 어떻게 보호할 수 있을까? )')
            stage.talk(0, 0, '조운 장군님, 오래전부터 당신의 무공이 비할 데 없다는 이야기를 들었습니다,\n어떻게 가입아군...... 흠!?\n그가 품에 숨기고 있는 게 뭐지?')
            stage.say('&34\n……')
            stage.talk(0, 0, '(말할 수 없어……? 이 아기는 혹시 유비의 자식인가!\n이걸 어떻게 해야 하지?)')
            sel = stage.choice('그리고 아기 남자아이를 데려갔다\n아기 남자아이를 살려줘', -1)
            if sel == 1:
                stage.talk(0, 0, '경비! 아기를 데려와!')
                stage.say('&34\n잠깐! 이 아기를 어떻게 할 생각이야?\n그는 우물에 빠져 죽은 여자가 남긴 고아였다,\n네게 주는 것보다 죽는 게 낫조운.')
                stage.talk(0, 0, '응, 조운.')
                stage.talk(0, 0, '(조운은 의리가 깊다고 들었는데, 이 아이는 아마 전쟁의 희생양일 거야? 아기를 잔인하게 죽이는 것보다는……)')
                stage.talk(0, 0, '(조운에게 은혜를 베푸는 게 어떨까?\n좋아, 그렇게 하자.)')
                stage.talk(0, 0, '이번엔 널 보내줄게.\n하지만 다음에 널 잡으면,\n난 주저하지 않아, 가자.')
                stage.say('&34\n깊이 감사드립니다......\n전장에서 철수하겠다는 조운 의사를 증명하기 위해,\n이걸 받아주세요, 선생님.\n&34\n이만 가볼게요!')
                stage.unit(34).hide()
                stage.getItem(81, -1)
            elif sel == 2:
                stage.talk(0, 0, '……유비는 당연히 놓칠 수 없지만,\n아기는 무고하니까……')
                stage.say('&34\n조, 조 경......')
                stage.talk(0, 0, '나는 아기가 죽는 걸 가만히 지켜보지 않을 거야.\n이번엔 널 보내줄게.\n서둘러!')
                if vars[40]:
                    stage.say('&34\n깊이 감사드립니다......\n전장에서 철수하겠다는 조운 의사를 증명하기 위해,\n이걸 받아주세요, 선생님.')
                    stage.talk(0, 0, '(이, 이건……\n이건 하후은의 청강검이잖아……\n설마 하후은이 죽은 건가……)')
                    stage.say('&34\n이만 가볼게요!')
                    stage.unit(34).hide()
                    stage.getItem(32, -1)
                else:
                    stage.say('&34\n깊이 감사드립니다......\n전장조운 가지 않으려는 의사를 증명하기 위해,\n이걸 받아주세요, 선생님.\n&34\n이만 가볼게요!')
                    stage.unit(34).hide()
                    stage.getItem(81, -1)
            else:
                stage.unit(34).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n흠, 후퇴하자!')
        stage.unit(3).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n쳇, 더는 못 참겠어.\n후퇴!')
        if not vars[35]:
            stage.say('&33\n아, 그리고 아직 하지 않은 게 있어......\n이렇게 그냥 떠날 수 없어......\n이 다리도 부숴라!')
            stage.unit(33).hide(1)
            stage.setObject(True, 12, 22, 11, 18)
            stage.talk(33, 33, '하하하. 당연하지!')
            if not vars[2]:
                stage.say('&32\n여러분, 빨리 떠나세요!\n전군을 후퇴시켜라!')
                stage.unit(32).setAI(6, -1, 20, 6)
                stage.unit(34).setAI(3, 32, 0, 0)
                vars[2] = 1
            else:
                stage.unit(33).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(43, 7, 0, 2):
        stage.say('&43\n젠장, 실패했어!\n빨리 도망쳐.')
        stage.unit(43).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(64, 7, 0, 2):
        stage.say('&64\n와아아!')
        stage.unit(64).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(504, 7, 0, 2):
        stage.say('&504\n아, 다시 신예로 돌아갔구나.')
        stage.unit(504).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(505, 7, 0, 2):
        stage.say('&505\n"유 삼촌, 우리를 두고 가지 마세요!"')
        stage.unit(505).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(506, 7, 0, 2):
        stage.say('&506\n정말 신예로 돌아가서 다시 조조의 억압을 겪고 싶지 않아요,\n다른 곳으로 도망칠 방법을 찾아.')
        stage.unit(506).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(507, 7, 0, 2):
        stage.say('&507\n도와줘.\n뭐라고? 넌 날 죽이지 않을 거야!\n정말 좋네요!')
        stage.unit(507).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(508, 7, 0, 2):
        stage.say('&508\n너무 아파, 뭐 하는 거야!\n나는 순종적으로 돌아갈 것이다,\n장난치지 마.')
        stage.unit(508).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(509, 7, 0, 2):
        stage.say('&509\n조 경이 우리를 해치지 않을까?\n정말? 그렇다면 돌아가자.')
        stage.unit(509).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(510, 7, 0, 2):
        stage.say('&510\n조조This 사람은 정말 잔인해요......\n그들은 우리도 무고한 민간인들을 용서하지 않을 거야......\n우, 우, 우우, 원하는 곳 어디든 데려가도 돼!')
        stage.unit(510).hide(1)
        vars[65] = 1
    if not vars[66] and stage.unitStateTest(511, 7, 0, 2):
        stage.say('&511\n으, 날 놔줘! 나는 유 삼촌을 따라가고 싶어.\n날 놔줘!')
        stage.unit(511).hide(1)
        vars[66] = 1
    if not vars[67] and stage.unitStateTest(27, 7, 0, 2):
        stage.say('&27\n음, 안녕.')
        stage.unit(27).hide(2)
        vars[67] = 1
    if not vars[68] and stage.unitStateTest(26, 7, 0, 2):
        stage.say('&26\n와......\n주군......')
        stage.unit(26).hide(2)
        vars[68] = 1
    if not vars[69] and stage.unitStateTest(28, 7, 0, 2):
        stage.say('&28\n와!\n실패했어!\n음, 음, ......')
        stage.unit(28).hide(2)
        vars[69] = 1
    if not vars[70] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n주군, 미안해.\n후퇴.')
        stage.unit(40).hide(1)
        vars[70] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 몰아냈어.\n아군 이겼어!')
        if not vars[33]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[626] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
