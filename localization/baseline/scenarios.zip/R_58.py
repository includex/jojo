# Source Generated with Decompyle++
# File: R_58.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    stage.clsUnit()
    stage.setMenuVisible(False)
    return False


def scene1():
    if vars[645]:
        stage.bgSound(13)
        stage.loadBg(2, 16)
        stage.showUnit(76, 53, 82, 0, 9)
        stage.draw()
        stage.setEventName('새로운 시대를 맞이하며')
        stage.setStageName('지안예 컨퍼런스 홀')
        stage.say('&76\n아버지, 형님......\n종목의 무능함을 용서해 주십시오.\n예상치 못하게 결국 그는 조조에게 패배했다.\n&76\n…… 하지만 후회하지 않아요,\n이제 그냥 평화롭게 너를 따라가고 싶어.\n&76\n미래를 조조......에게 맡기세요\n진짜 아니야......')
        stage.effectSound(38, 1)
        stage.unit(76).setAction(10)
        stage.say('&76\n기대하고 있어you......조조......')
        stage.delay(10)
        stage.showUnit(0, 52, 5, 2)
        stage.unit(0).move(52, 20, 2)
        stage.unit(0).setAction(0)
        stage.say('&0\n손권!')
        stage.unit(0).move(52, 60, 2)
        stage.unit(0).setAction(0)
        stage.say('&0\n……손권.')
        stage.showUnit(1, 48, 5, 2)
        stage.unit(1).move(48, 52, 2)
        stage.unit(1).setAction(0)
        stage.say('&1\n맹덕!\n이 사람은 손권Why 사람이야......')
        stage.showUnit(20, 55, 5, 2)
        stage.unit(20).move(55, 52, 2)
        stage.unit(20).setAction(0)
        stage.say('&20\n주군! 어......!?')
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n문약, 손권 손견와 손책의 공동 매장지에 안장될 예정이었다.\n…… 성대한 장례가 필요하다.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네, 이해문약.')
        stage.unit(20).setAction(0)
        stage.say('&0\n원양 그는 전 군대에 약탈이나 약탈을 금지하라고 긴급히 명령했다,\n위반자는 법에 따라 즉시 처형될 것이다!\n&1\n네.')
        stage.unit(1).setAction(3)
        stage.say('&1\n맹덕, 공명 도망쳤다,\n어디서도 찾을 수 없어.')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 2)
        stage.say('공명은 신경 쓰지 마세요. 우리가 할 일이 아직 많이 있어요.')
        stage.unit(1).setAction(3)
        stage.say('&1\n무시하라고......?\n이봐, 이거 괜찮아!?\n&0\n문제 없어.\n&1\n…… 좋아!')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(17)
        stage.say('이 일은 이미 정해진 수순이오. 나를 탓하지 마시오.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n좋아!')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(20),
                55,
                5,
                0],
            [
                stage.unit(1),
                48,
                5,
                0]])
        stage.unit(1).hide()
        stage.unit(20).hide()
        stage.delay(8)
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n……손권.')
        stage.delay(5)
        stage.bgSound(19)
        stage.clsUnit()
        stage.loadBg(2, 73)
        stage.showUnit(35, 49, 73, 0, 11)
        stage.draw()
        stage.setStageName('양쯔강 측선')
        stage.say('&35\n유비주군, 긴 혼돈의 시대가 끝났다,\n평화로운 날들이 마침내 돌아왔습니다.\n아마 이게 바로 당신이 바라는 거겠죠......')
        stage.showUnit(19, 90, 73, 3)
        stage.unit(19).move(57, 73, 3)
        stage.unit(19).setAction(0)
        stage.say('&19\n공명 미스터.')
        stage.unit(35).setAction(11, 1)
        stage.say('&35\n그래서 사마의 씨였다.\n공명 여기까지 따라왔어?')
        stage.unit(19).setAction(6)
        stage.say('&19\n흠, 하지만 널 쫓으러 온 건 아니야.\n제 주군도 그럴 필요 없다고 했어요.')
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(0)
        stage.say('&35\n조 재상은 공명......를 체포할 생각이 없었나요?\n…… 그래서 그런 거야.\n그럼 왜 저를 찾으러 오셨나요, 선생님?')
        stage.unit(19).setAction(6)
        stage.say('&19\n중달 부탁이 있어.\n이제부터 개척자가 될 것입니다\n완전히 새로운 나라 .......\n&19\n공명 미스터.\n부디, 선생님, 우리 주군도 함께 섬기세요.')
        stage.unit(35).setAction(6)
        stage.say('&35\n...... 가야 하나요?\n&19\n흠.\n새로운 나라를 세우려면 네 힘이 필요해.')
        stage.unit(19).setAction(9)
        stage.say('&19\n중달 여기서 절하고 진심으로 부탁드립니다.\n공명 씨도 분명히 동의해 주길 바랍니다.')
        stage.unit(35).setAction(0)
        stage.delay(10)
        stage.unit(35).setAction(0, 0)
        stage.say('&35\n…… 시마 씨.\n이 말들은 나를 깊이 감동시켰다,\n하지만 동의하지 못해 죄송합니다.\n&19\n공명...... 씨')
        stage.delay(5)
        stage.say('&35\n시마 씨.\n총리와 저는 같은 이상을 추구하지만,\n하지만 그들은 다른 길을 걸었다.')
        stage.delay(5)
        stage.unit(35).setAction(11)
        stage.say('&35\n길은 자신에게 달려 있어요......\n이제부터 총리는 자신의 길을 따를 것이다.')
        stage.unit(19).setAction(0)
        stage.say('&19\n…………\n&35\n하지만 나는 총리와 같은 길을 걸을 수 없다.')
        stage.unit(35).setAction(11, 1)
        stage.delay(10)
        stage.unit(35).setAction(0)
        stage.delay(5)
        stage.say('&35\n조 재상도 이 사실을 알아야 합니다.')
        stage.delay(8)
        stage.unit(35).setAction(0, 0)
        stage.say('&35\n나는 롱중의 초가지붕 오두막으로 돌아갈 것이다,\n원래의 삶을 되살려라,\n조 재상께서 그가 창조한 새로운 시대를 기원합니다.')
        stage.unit(19).setAction(6)
        stage.say('&19\n공명...... 씨')
        stage.unit(35).setAction(0, 1)
        stage.delay(3)
        stage.unit(35).setAction(6)
        stage.say('&35\n시마 씨.\n우리가 다시 만날 수 없을지도 모른다,\n부디 몸조심하세요.')
        stage.unit(35).setAction(0)
        stage.delay(5)
        stage.unit(35).move(10, 73, 3)
        stage.unit(35).hide()
        stage.bgSound(16)
        stage.clsUnit()
        stage.loadBg(1, 0)
        stage.draw()
        stage.showHead(0, 501, 208)
        stage.bottomTxt('조조 수와 우를 진정시켰다,', False, False, False)
        stage.delay(5)
        stage.head(0).move(330, 105)
        stage.delay(5)
        stage.bottomTxt('승리의 손으로 쉬두로 돌아갔다.', True, False, True)
        stage.bgSound(-1)
        stage.loadBg(2, 15)
        stage.showUnits([
            [
                149,
                27,
                55,
                1],
            [
                192,
                46,
                43,
                2],
            [
                193,
                52,
                43,
                2],
            [
                194,
                58,
                43,
                2],
            [
                195,
                46,
                67],
            [
                196,
                52,
                67],
            [
                197,
                58,
                67]])
        stage.draw()
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.setStageName('서두 왕궁')
        stage.delay(3)
        stage.unit(192).setAction(6)
        stage.say('&192\n폐하, 재상께서 승리하여 돌아오셨습니다,\n그리고 특별히 승리를 보고하러 왔습니다.\n&149\n흠.')
        stage.unit(192).setAction(0)
        stage.showUnit(0, 95, 55, 3)
        stage.say('&0\n폐하를 뵙습니다.')
        stage.unit(0).move(89, 55, 3)
        stage.showUnits([
            [
                1,
                95,
                51,
                3],
            [
                20,
                95,
                59,
                3]])
        stage.unitsMove([
            [
                stage.unit(0),
                83,
                55,
                3],
            [
                stage.unit(1),
                89,
                51,
                3],
            [
                stage.unit(20),
                89,
                59,
                3]])
        stage.showUnits([
            [
                2,
                95,
                51,
                3],
            [
                8,
                95,
                59,
                3]])
        stage.unitsMove([
            [
                stage.unit(0),
                77,
                55,
                3],
            [
                stage.unit(1),
                83,
                51,
                3],
            [
                stage.unit(20),
                83,
                59,
                3],
            [
                stage.unit(2),
                89,
                51,
                3],
            [
                stage.unit(8),
                89,
                59,
                3]])
        stage.showUnits([
            [
                4,
                95,
                51,
                3],
            [
                19,
                95,
                59,
                3]])
        stage.unitsMove([
            [
                stage.unit(0),
                46,
                55,
                3],
            [
                stage.unit(1),
                52,
                51,
                3],
            [
                stage.unit(20),
                52,
                59,
                3],
            [
                stage.unit(2),
                58,
                51,
                3],
            [
                stage.unit(8),
                58,
                59,
                3],
            [
                stage.unit(4),
                64,
                51,
                3],
            [
                stage.unit(19),
                64,
                59,
                3]])
        stage.unit(0).setAction(0)
        stage.unit(1).setAction(0)
        stage.unit(20).setAction(0)
        stage.unit(2).setAction(0)
        stage.unit(8).setAction(0)
        stage.unit(4).setAction(0)
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('폐하, 조조는 이미 촉과 오를 평정하고, 지금 허도에 본거지를 옮겼습니다.')
        stage.unit(1).setAction(6)
        stage.unit(20).setAction(6)
        stage.unit(2).setAction(6)
        stage.unit(8).setAction(6)
        stage.unit(4).setAction(6)
        stage.unit(19).setAction(6)
        stage.delay(5)
        stage.unit(0).setAction(0)
        stage.unit(1).setAction(0)
        stage.unit(20).setAction(0)
        stage.unit(2).setAction(0)
        stage.unit(8).setAction(0)
        stage.unit(4).setAction(0)
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.say('&149\n흠, 수고해 주셔서 감사합니다.\n궁 안의 백성들의 기쁨 찬 축하 소리를 이미 들었습니다.')
        stage.unit(0).setAction(6)
        stage.say('&0\n네.')
        stage.unit(0).setAction(0)
        stage.say('&149\n친애하는 신하님, 당신이 슈와 오를 대상으로 선거운동을 한 이후로,\n그래서 나는 이 문제를 밤낮으로 곱씹었다.\n&149\n이제 사랑받는 장관의 영웅적인 귀환을 보며,\n평민들의 즐거운 웃음소리를 보며,\n드디어 마음을 정했어.')
        stage.unit(0).setAction(6)
        stage.say('&0\n네.')
        stage.unit(0).setAction(0)
        stage.say('&149\n나는 ...... 나는 조 대신에게 왕위를 양위하고 싶다.')
        stage.unit(20).setAction(6)
        stage.say('&20\n(무-무슨 일이......!) )')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n(폐하께서 이런 생각을 하실 줄은 몰랐습니다...... )')
        stage.unit(19).setAction(0)
        stage.say('&0\n…………')
        stage.unit(192).setAction(6)
        stage.say('&192\n폐하!\n왜 그런 말을 하죠!?')
        stage.unit(192).setAction(0)
        stage.delay(3)
        stage.unit(193).setAction(6)
        stage.say('&193\n이제 이 왕국은 통일의 순간에 있다,\n왜 그래......')
        stage.unit(193).setAction(0)
        stage.say('&149\n모든 장관들은 엄숙하고 조용했다.\n누가 세상을 평정시켰나요?\n&149\n이 모든 게 충성스러운 신하의 공덕 덕분이 아니야?')
        stage.unit(192).setAction(6)
        stage.say('&192\n그-그런데......\n이것이 장관의 의무입니다.')
        stage.unit(192).setAction(0)
        stage.say('&149\n내 조상들, 고조 유방과 광무 유수제,\n모두가 자비와 의를 지니고 있으며, 그들의 공로는 역사상 비할 데 없으며,\n그래야만 혼란이 진정되고 왕좌가 황제로 선포될 수 있다.\n&149\n어떻게 천자가 유씨 가문만이 다스릴 수 있단 말인가?\n군사적 업적과 자비를 모두 갖춘 사람이 그 뒤를 이어야 한다.')
        stage.unit(193).setAction(6)
        stage.say('&193\n폐하, 폐하......')
        stage.unit(193).setAction(0)
        stage.say('&149\n조 대신, 저를 계승해 왕위에 오를 의향이 있습니까?')
        if model.ambition() < 85:
            stage.effectSound(200, 255)
            stage.bgSound(0)
            stage.delay(10)
            stage.unit(0).setAction(0)
            stage.say('&0\n용서해 주십시오, 폐하의 제권을 받아들일 수 없습니다.\n&149\n왜 이런 걸까요?')
            stage.unit(0).setAction(6)
            stage.say('...신이 오늘 폐하를 뵙는 것은,\n단지 난세가 끝났다는 승전보를 올리기 위해서만은 아닙니다.\n또한 폐하께 치세 전권을 내려주시기를 청하기 위해서입니다.')
            stage.unit(0).setAction(0)
            stage.say('&149\n이게 바로 내가 원하는 거 아니야?\n조 대신, 제 퇴위를 받아들이고 세상을 다스리십시오.')
            stage.unit(0).setAction(3)
            stage.say('폐하, 천자는 홍인보애를 실천하는 분이 아니면 될 수 없습니다.')
            stage.unit(0).setAction(0)
            stage.say('&0\n그러나 오직 자비로운 마음만으로 세상을 다스리면서,\n좋은 거버넌스는 달성될 수 없습니다.\n&149\n………')
            stage.unit(0).setAction(6)
            stage.say('&0\n따라서 혼동의 시기를 진정시키기 위해 조는\n그래서 저는 항상 폐하의 권위를 믿어왔습니다.')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(20).setAction(6)
            stage.say('&20\n주님, 주군! 어떻게 그런 말을 할 수 있어!?\n&149\n좋아.\n나는 오래전부터 이 문제를 내 마음속으로 이해해 왔다,\n그래서 그들은 혼란스러운 시기를 특히 잘 헤쳐 나가는 데 능숙합니다.')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(6)
            stage.say('폐하, 앞으로 다가올 새로운 시대를 위해, 부디 황제의 존엄으로 만백성을 자애롭게 대해주시길 바랍니다!')
            stage.unit(0).setAction(0)
            stage.say('&149\n…… 전하, 덕이 부족하다고 생각하십니까?\n&149\n미래의 통치가 그럴까,\n아직도 사람들에게 고통과 두려움을 줄 생각이야?')
            stage.unit(0).setAction(6)
            stage.say('&0\n아마도 미래에 그런 꼭 필요한 순간이 올지도 모른다.\n그렇다면 조는 주저 없이 단호한 결정을 내릴 것이다.')
            stage.unit(0).setAction(0)
            stage.say('&149\n하지만 이렇게 하면 당신은 사람들로부터 멀리 떨어져 있을 것입니다,\n천 년 동안 역사가들의 기록에 수치스러운 표정을 남겼다.')
            stage.unit(0).setAction(3)
            stage.say('폐하, 조맹덕은 이생에서 자리 잡는 것만 바랄 뿐입니다. 후세의 나쁜 평판이 저와 무슨 상관입니까?')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(149).setAction(0, 2)
            stage.say('&149\n(나쁜 평판에는 전혀 개의치 않고, 오직 자신의 지배적인 길을 택한다.)\n정말 ...... 정말 단호한 사람이구나. )\n&149\n(미래에 세상을 다스리기 위해,\n조조 분명히 다시 나를 이용할 거야.\n하지만 나는 그가 진정으로 국민을 위해 봉사한다는 것을 안다. )')
            stage.unit(149).setAction(0, 1)
            stage.say('&149\n…… 좋아.\n&149\n조조, 나는 천자의 품위를 사용해 백성을 친절하게 돌보겠다,\n모든 일을 인간의 편리함으로 다스려야 한다.')
            stage.unit(0).setAction(6)
            stage.say('&0\n네.')
            stage.unit(0).setAction(0)
            stage.delay(5)
            stage.unit(0).setAction(0, 1)
            stage.delay(3)
            stage.say('&0\n원양. 문약, 다들 들었지?')
            stage.unit(0).setAction(3)
            stage.say('&0\n이제 폐하께서 저에게 통치의 최고 권한을 맡기셨습니다,\n앞으로는 더 붐빌 거예요.')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(1).setAction(3)
            stage.say('&1\n네.')
            stage.unit(1).setAction(0)
            stage.delay(3)
            stage.unit(20).setAction(6)
            stage.say('&20\n네.')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(17)
            stage.say('좋습니다. 새로운 시대를 함께 여는 것입니다!')
            stage.bgSound(16)
            stage.clsUnit()
            stage.loadBg(1, 0)
            stage.draw()
            stage.bottomTxt('혼란스러운 시대가 끝나가면서,', False, False, False)
            stage.delay(5)
            stage.showHead(0, 284, 73)
            stage.showHead(1, 188, 153)
            stage.showHead(2, 252, 153)
            stage.showHead(20, 316, 153)
            stage.showHead(24, 380, 153)
            stage.delay(5)
            stage.bottomTxt('새로운 시대가 시작되었습니다.', True, False, False)
            stage.delay(15)
            stage.bottomTxt('조조 평화롭고 번영하는 시대의 토대를 마련했다.', True, True, False)
            stage.delay(5)
            stage.head(0).hide()
            stage.delay(5)
            stage.bottomTxt('얼마 지나지 않아 그는 세상을 떠났다.', True, False, False)
            stage.delay(10)
            stage.bottomTxt('그는 동서 원정에 조조 부하들을 따라갔다.', True, True, False)
            stage.delay(5)
            stage.head(1).hide()
            stage.head(2).hide()
            stage.head(20).hide()
            stage.head(24).hide()
            stage.delay(5)
            stage.bottomTxt('대부분도 세상을 떠났습니다.', True, False, True)
            stage.bottomTxt('시간은 흘러간다......', False, False, False)
            stage.delay(10)
            stage.showHead(8, 320, 101)
            stage.delay(5)
            stage.bottomTxt('조조 정당한 son조비', True, True, False)
            stage.delay(5)
            stage.showHead(149, 256, 101)
            stage.delay(5)
            stage.bottomTxt('결국 헌제를 퇴위시키고,', True, False, False)
            stage.delay(5)
            stage.head(149).hide()
            stage.delay(5)
            stage.head(8).move(288, 101)
            stage.head(8).hide()
            stage.delay(10)
            model.setFace(32)
            stage.showHead(8, 288, 101)
            stage.delay(5)
            stage.bottomTxt('자신이 위나라의 새로운 황제라고 주장했다.', True, False, False)
            stage.delay(10)
            stage.bottomTxt('하늘의 은총과 소환을 받는 조조을 모른 채,', True, True, False)
            stage.delay(5)
            stage.bottomTxt('아들이 한 일에 대해 그는 어떻게 생각하나요......', True, False, True)
            stage.bgSound(-1)
            stage.clsUnit()
            stage.ending(1)
        if model.ambition() >= 85:
            stage.effectSound(200, 255)
            stage.bgSound(0)
            stage.delay(10)
            stage.unit(0).setAction(0)
            stage.say('...제가 받겠습니다.\n오, 아신이 받아들이시겠다고요?\n정말 좋군요. 정말 좋아요.')
            stage.unit(149).setAction(0, 2)
            stage.say('&149\n이제부터 나는 평범한 사람들의 집에 머물겠다,\n네가 만든 새 왕국에서 살아.')
            stage.unit(192).setAction(6)
            stage.say('&192\n폐하, 폐하......\n왜 ......')
            stage.unit(192).setAction(0)
            stage.delay(3)
            stage.unit(193).setAction(6)
            stage.say('&193\n한나라의 400년이 여기서 끝난 걸까요......?\n우우우우......')
            stage.unit(149).setAction(0, 1)
            stage.say('&149\n한탄하지 마.\n평민들을 위해,\n한나라는 이미 잊혀진 과거입니다.')
            stage.unit(193).setAction(0)
            stage.say('&149\n천하의 모든 사람들이 새로운 활력을 찾고 있어.\n친애하는 장관님, 부탁드립니다.')
            stage.unit(0).setAction(6)
            stage.say('&0\n네.')
            stage.unit(0).setAction(0)
            stage.delay(5)
            stage.unit(1).setAction(4)
            stage.say('&1\n으... 맹덕, 드디어 황제가 되었구나.\n정말 기쁨의 눈물을 선사합니다.')
            stage.unit(20).setAction(0, 0)
            stage.delay(3)
            stage.unit(20).setAction(6)
            stage.say('&20\n샤호우 장군님,\n주군 더 이상 그렇게 부를 수 없습니다.')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(1).setAction(0)
            stage.delay(3)
            stage.unit(1).setAction(0, 2)
            stage.say('&1\n오!\n네, 맞아요.\n폐하로 바꿔야 합니다.')
            stage.unit(0).setAction(0, 1)
            stage.say('&0\n상관없어.\n아까처럼 맹덕라고 불려.')
            stage.unit(1).setAction(0, 3)
            stage.unit(20).setAction(0, 3)
            stage.say('&149\n장관님, 이게 무슨 행동입니까?\n즉시 퇴위식을 준비하겠습니다,\n이제부터 천자로서 ......')
            stage.unit(0).setAction(0, 3)
            stage.delay(3)
            stage.unit(0).setAction(6)
            stage.say('폐하, 조모덕은 폐하의 뜻을 받들어 황제의 자리에 오르겠습니다.')
            stage.unit(0).setAction(0)
            stage.say('하지만 조모는 천자가 될 생각이 없습니다....황위에 오르지 않으신다고요...? 이게 무슨 이유입니까?')
            stage.unit(0).setAction(0, 2)
            stage.say('&0\n제가 조맹덕의 평범한 신분으로 등극할 겁니다.\n그러니 황제라 칭해도 하늘이 내린 아들은 아닙니다.')
            stage.unit(20).setAction(6)
            stage.say('&20\n문약, 하지만......')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(0, 1)
            stage.say('&0\n순욱, 국민을 다스리는 것은 국민입니다.')
            stage.unit(20).setAction(6)
            stage.say('&20\n주군......')
            stage.unit(20).setAction(0)
            stage.say('&149\n사람이어야 해......?\n조조, 앞으로 황제를 폐위시킬 생각이냐?')
            stage.unit(0).setAction(0, 3)
            stage.delay(3)
            stage.unit(0).setAction(6)
            stage.say('&0\n새로운 시대에 있다면,\n황제의 말은 필요 없어......\n그럼 반대하지 않겠네요.')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(192).setAction(6)
            stage.say('&192\n뭐라고!?')
            stage.unit(192).setAction(0)
            stage.delay(3)
            stage.unit(193).setAction(6)
            stage.say('&193\n폐하!\n어떻게 이런 사람이 왕위를 계승할 수 있......!?')
            stage.say('&149\n엄숙하고 평온했다.\n&193\n폐하......')
            stage.unit(193).setAction(0)
            stage.say('&149\n(알고 보니 황제는 그를 칭호로만 불렀다,\n조맹덕 정말 돋보인다...... )\n&149\n친애하는 신하님, 이제부터 모든 것은 당신 손에 달려 있습니다!')
            stage.unit(0).setAction(6)
            stage.say('&0\n정말로, 폐하의 명령을 존중하여 따릅니다!')
            stage.unit(0).setAction(0)
            stage.delay(5)
            stage.unit(0).setAction(0, 1)
            stage.delay(3)
            stage.unit(0).setAction(3)
            stage.say('&0\n원양. 다들 들었문약, 맞지?\n앞으로는 더 붐빌 거예요.')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(1).setAction(3)
            stage.say('&1\n네.')
            stage.unit(1).setAction(0)
            stage.delay(3)
            stage.unit(20).setAction(6)
            stage.say('&20\n네.')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(17)
            stage.say('좋습니다. 새로운 시대를 함께 여는 것입니다!')
            stage.clsUnit()
            stage.loadBg(1, 0)
            stage.draw()
            stage.showHead(127, 195, 91)
            stage.showHead(101, 407, 9)
            stage.showHead(119, 471, 121)
            stage.showHead(32, 30, 170)
            stage.showHead(35, 94, 190)
            stage.showHead(76, 536, 215)
            stage.delay(5)
            stage.bottomTxt('영웅들이 혼란의 시대를 질주할 때,', False, False, False)
            stage.delay(8)
            stage.head(127).hide()
            stage.head(119).hide()
            stage.head(101).hide()
            stage.head(32).hide()
            stage.head(35).hide()
            stage.head(76).hide()
            stage.delay(5)
            stage.bottomTxt('점차 역사의 무대를 떠나면서,', True, True, False)
            stage.delay(5)
            stage.bottomTxt('혼란스러운 시대가 마침내 끝났다.', True, False, True)
            stage.delay(5)
            stage.showHead(0, 288, 101)
            stage.delay(5)
            stage.bottomTxt('새 황제의 조맹덕 행정 하에서,', False, False, False)
            stage.delay(5)
            stage.showHead(23, 195, 91)
            stage.showHead(8, 407, 9)
            stage.showHead(20, 471, 121)
            stage.showHead(19, 30, 170)
            stage.showHead(1, 294, 229)
            stage.showHead(2, 536, 215)
            stage.delay(5)
            stage.bottomTxt('새로운 시대가 시작되었습니다.', True, False, False)
            stage.delay(5)
            stage.bottomTxt('사람들이 사람들을 지배하는 시대였다......', True, True, True)
            stage.bgSound(-1)
            stage.clsUnit()
            stage.ending(0)
    if not vars[645]:
        stage.loadBg(2, 24)
        stage.showUnit(35, 54, 43, 2)
        stage.draw()
        stage.setEventName('새로운 시대로 나아가다')
        stage.setStageName('우장평원의 지하 제단')
        stage.delay(3)
        stage.unit(35).setAction(2)
        stage.say('&35\nMmm......조조 늙은 도둑!\n너 때문에 정말 나를 한계까지 몰아넣었어!')
        stage.unit(35).setAction(0)
        stage.say('&35\n나, 난 그냥 그냥 넘어가지 않을 거야......\n나는 어둠 속에 숨어 내 상처가 나을 때까지 기다릴 것이다,\n우린 그를 죽여야 해......')
        stage.showUnit(0, 54, 95)
        stage.unit(0).move(54, 86, 0)
        stage.unit(0).setAction(0)
        stage.say('&0\n공명!!')
        stage.unit(35).setAction(0, 2)
        stage.unit(0).move(54, 53, 0)
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(35).setAction(11)
        stage.say('&35\n조조...... 그래도 나를 따라잡았구나.\n음, 음, ......')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n공명, 오늘이 네가 죽는 날이야!')
        stage.unit(35).setAction(2)
        stage.say('&35\n건방지게 굴지 마, 조조!\n…… 너희 인간들이 정말 나를 죽일 수 있겠느냐?')
        stage.unit(35).setAction(0)
        stage.say('&0\n음...... 네가 ......어!')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(35).setAction(17)
        stage.say('&35\n인간들이여, 나에게는,\n가축처럼.\n음, 하하하!')
        stage.unit(35).setAction(0)
        stage.say('&35\n…… 음음!')
        stage.delay(5)
        stage.say('&35\n아-안 돼!\n온몸이 뜨거워졌어!\n왜 온몸이 뜨거워!?')
        model.setFace(1)
        stage.say('&0\n！？')
        stage.unit(35).setAction(8)
        stage.say('&35\n혹시 공명의 영혼일까!?\n그가 나를 죽이려고 자기 몸을 파괴하려는 거야......?\n&0\n공명!?\n&35\n하지만, 젠장공명!\n알고 보니 그는 적절한 기회를 기다리고 있었다......\n내가 다치고 약해질 때까지 기다렸다가 움직여......\n&35\n나는, 나는 위대한 마왕이다,\n어떻게, 어떻게 내가 인간에게 죽을 수 있지......\n와......!!')
        stage.unit(35).setAction(12)
        stage.say('&35\n음, 너무 뜨거워, 너무 뜨거워!\n&35\n아, 아아아......!!')
        stage.effectSound(38, 1)
        stage.unit(35).setAction(10, 2)
        stage.delay(3)
        stage.unit(0).setAction(3)
        stage.say('&0\n공명!')
        stage.unit(0).setAction(0)
        stage.bgSound(13)
        stage.delay(15)
        model.setFace(255)
        model.setFace(0)
        stage.say('&35\n조조...... 있나?\n&0\n음, 나야.\n공명 있어......\n&35\n조조...... 나—내가 마왕을 죽였어.\n네 덕분에 그를 죽일 수 있었어......\n음! 와......!')
        stage.unit(0).setAction(6)
        model.setFace(1)
        stage.say('&0\n공명, 힘내!')
        stage.unit(0).setAction(0)
        stage.say('&35\n나는—나는 이미 구할 수 없는 상태야.\n힘줄과 정맥이 끊어지고 장기가 갈라졌어요......\n&0\n공명...... 왜 그래......')
        stage.delay(8)
        model.setFace(0)
        stage.say('&35\nI ......\n내 family주군......를 죽였어\n&0\n......공명.')
        stage.delay(5)
        stage.say('&35\n악마들을 막지 못한 내 잘못이야......!')
        stage.delay(5)
        stage.say('&35\n주군.........')
        stage.delay(3)
        stage.say('&35\n……………\n&0\n공명.........')
        stage.showUnit(3, 54, 95)
        stage.unit(3).move(54, 86, 0)
        stage.say('&3\n총리님.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n구름이 길다.')
        stage.unit(3).move(54, 63, 0)
        stage.say('...방금 한 말, 다 들었니?')
        stage.unit(3).setAction(6)
        stage.say('&3\n네.\n관은 원래 와서 공명를 죽이려 했어,\n모두를 위해 복수를 노리고 있어......')
        stage.unit(3).setAction(0)
        stage.say('&0\n정말......')
        stage.unit(3).setAction(6)
        stage.say('&3\n알고 보니 군사 고문공명 있었다......\n임종의 순간에도 그는 형을 생각했다.')
        stage.unit(3).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n흠......\n윤창, 공명 일은 네게 맡길게.')
        stage.unit(3).setAction(6)
        stage.say('&3\n그는 총리에게 감사를 표했다.\n내가 직접 제대로 장례를 치르겠다......\n전략가가 형 곁에서 쉬게 하라.')
        stage.unit(3).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n맞아.\n이렇게 하자.\n그도 그를 기다리고 있었을 것이다.\n&3\n…… 군사 고문.')
        stage.delay(10)
        stage.bgSound(-1)
        stage.clsUnit()
        stage.loadBg(2, 32)
        stage.showUnit(0, 63, 33, 3)
        stage.draw()
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.info('공명가 죽은 지 한 달 후였다......', 3)
        stage.setStageName('고조 평야 산 위')
        stage.delay(10)
        stage.showUnit(151, 90, 41, 3)
        stage.unit(151).move(73, 41, 3)
        stage.say('&151\n총리님.')
        stage.unit(151).move(63, 41, 3)
        stage.unit(151).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n그래서 위안즈였구나.')
        stage.unit(151).setAction(0, 0)
        stage.delay(3)
        stage.unit(151).setAction(6)
        stage.say('&151\n위안즈는 서두에 있는 총리의 관저로 가서 면담을 구했다,\n순욱 씨는 자신이 여기 있다고 총리에게 알렸습니다.')
        stage.unit(151).setAction(0)
        stage.say('&0\n그래서 그런 거야.\n이번에는 나를 찾으러 왔지,\n중요한 일이라도 있나요?')
        stage.unit(151).setAction(6)
        stage.say('&151\n네......\n실례지만, 총리께서 지하 제단을 파괴하셨나요?')
        stage.unit(151).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 3)
        stage.say('&0\n응?\n아, 원래는 제단을 더 일찍 파괴하려고 했는데,\n그 결과 장례 및 관련 사안공명 처리가 지연되었다.\n&151\n제단 파괴를 직접 감독할 생각이신가요?\n&0\n네.\n&151\n……………')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n위안즈, 나한테 뭔가 하러 온 거 아니야?')
        stage.unit(151).setAction(6)
        stage.say('&151\n네, 이 편지는 총리가 검토할 것입니다.')
        stage.unit(151).setAction(0)
        stage.delay(3)
        stage.unit(151).move(63, 37)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.delay(3)
        stage.unit(151).move(63, 41, 0)
        stage.delay(3)
        stage.say('&0\n이게 ......공명 편지인가요?')
        stage.unit(151).setAction(6)
        stage.say('&151\n네.\n편지는 공명가 장샤시에서 머물렀던 방에 그대로 있었다.\n&151\n이 책은 레드 클리프 전투 직후에 쓰였을 것으로 추정된다.')
        stage.unit(151).setAction(0)
        stage.say('&0\n흠.')
        stage.effectSound(203, 255)
        stage.bgSound(19)
        stage.delay(10)
        stage.info('이 편지를 열고 읽은 분들께,\n쉬쉬가 아니라면, 분명 방통일 거야!\n이 편지를 받는 분들께,\n지금쯤이면 내가 이 세상에 더 이상 존재하지 않는 것 같아 두려워요.')
        stage.info('난 죽는 게 두렵지 않아.\n그는 살아가는 것이 큰 재앙을 불러올까 두려워했다.')
        stage.info('여러분 모두 마왕에 대해 들어본 적 있죠?\n3천 년 전, 우리 위대한 조상 황제의 시대에\n세상을 다스릴 때 반란을 일으키는 마왕.')
        stage.info('이제 그것은 3,000년 동안 잠들어 있었다\n마왕이 깨어났다,\n그는 이 혼란스러운 시기를 이용해 세상을 노예로 만들고자 했다.')
        stage.info('마왕의 몸이 사라진 지금,\n재능 있는 사람에게 자신을 붙이면서만 행동할 수 있다,\n결국 그는 내 주인유비를 대리인으로 선택했다.')
        stage.info('붉은 절벽 전투 동안, 그들의 움직임은 이상했다,\n아군에게 승리를 가져다주는 동남풍,\n그것은 마왕이 스탠드를 돕기 위해 그것을 불어넣은 것이었다.')
        stage.info('붉은 절벽 전투 이후, 마왕은 마침내 행동을 시작했다,\n이상한 구름이 밤하늘을 굴러가고, 혜성이 갑자기 나타났다,\n하지만 어떻게 그것이 유비주군를 지배하게 할 수 있겠는가!')
        stage.info('주군 미래 세대에게 수치를 남기지 않기 위해,\n나는 오직 마왕이 내게 매달릴 수밖에 없다,\n그럼 그들은 마왕의 야망과 싸울 거야!')
        stage.info('아마도 미래에, 마왕의 야망 때문에,\n많은 슈 병사들이 목숨을 바칠 것이다,\n나조차도 비극적인 결말을 맞이할 것이다,\n하지만 나는 여전히 진실을 말하고 싶어.')
        stage.info('만약 내가 마왕에게 패배한다면,\n네가 직접 나를 죽일 수 있길 바란다,\n그래야만 마왕을 제거할 수 있다!\n제갈공명@ 장샤에게 편지를 썼다')
        stage.delay(5)
        stage.unit(0).setAction(0)
        stage.say('&0\n알고 보니 공명 쉬안더를 구하려 했던 거였어,\n마왕에게 빙의하게 둘까?')
        stage.unit(0).setAction(0, 3)
        stage.say('&0\n이 전쟁에서 많은 사람들이 죽었고,\n가장 고통스러운 것은 아마도 공명일 것입니다.\n&151\n네.')
        stage.delay(15)
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n위안즈, 항상 묻고 싶었던 게 있어.')
        stage.unit(151).setAction(6)
        stage.say('&151\n무슨 일인지 여쭤봐도 될까요?')
        stage.unit(151).setAction(0)
        stage.say('&0\n너는 쉬두에서 기도하기로 약속했지,\n그는 한때 조건을 제안했다.\n&0\n...... 조건은 어떤가요?')
        stage.unit(151).setAction(0, 3)
        stage.say('&151\n총리는 마왕이 죽은 자를 조종할 수 있다는 것을 알아야 한다.\n&0\n…… 지하에서 싸우는 아군,\n그는 이 때문에 꽤 많은 고통을 겪었다.\n&151\n만약 마왕이 정말로 살아난다면,\n심지어 영혼을 죽음에서 되살릴 수도 있다.\n&0\n…… 위안즈, 정말 ......')
        stage.delay(8)
        stage.say('&151\n관우 장군, 초선, 그리고 공명......\n그들은 모두 사랑하는 이를 잃었다.\n위안즈도 ......')
        stage.delay(8)
        stage.unit(151).setAction(0, 0)
        stage.say('&151\n하지만 이제 그는 그것을 알아냈다.')
        stage.unit(151).setAction(6)
        stage.say('&151\n위안즈는 지금 서로 달려가고 있다,\n그는 서공명 내용에 대해 쑤 장군에게 알렸다.\n그럼, 이만 가볼게요.')
        stage.unit(151).setAction(0)
        stage.delay(3)
        stage.unit(151).move(95, 41, 1)
        stage.unit(151).hide()
        stage.delay(5)
        stage.say('(……내 추측이 역시 맞았군. 서서, 너는 정말로 돌아가신 어머니를 그리워하는 거구나……)')
        stage.bgSound(-1)
        stage.clsUnit()
        stage.loadBg(2, 33)
        stage.showUnit(3, 32, 55, 3, 6)
        stage.draw()
        stage.effectSound(200, 0)
        stage.delay(3)
        stage.setStageName('쉬두 외곽 묘지')
        stage.say('&3\n형이자 군사 고문......')
        stage.delay(5)
        stage.showUnit(0, 95, 55, 3)
        stage.unit(0).move(88, 55, 3)
        stage.unit(0).setAction(0)
        stage.say('&0\n구름이 길다.')
        stage.unit(3).setAction(0, 1)
        stage.unit(0).move(40, 55, 3)
        stage.unit(0).setAction(0)
        stage.say('&0\n너도 무덤 보러 온 거야?\n&3\n네.\n사실, 나는 형과 전략가에게 작별 인사를 하러 왔다.\n&0\n작별 인사?\n…… 정말?')
        stage.unit(3).setAction(6)
        stage.say('&3\n네.\n관은 원래 나중에 총리를 만나러 갈 계획이었다.')
        stage.say('&3\n장군으로서 관의 임무는 완수되었다.\n&3\n관은 이미 재상의 가장 큰 은총을 받았다는 것을 깨달았다.\n총리님께 제 무모한 행동을 용서해 주시길 간청합니다.')
        stage.unit(3).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n윤창은 진지하게 받아들일 필요가 없다.\n앞으로 어디로 갈 계획인가요?')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&3\n관은 아직 결정을 내리지 않았다.\n이제부터는 세상을 떠돌고 싶어요.')
        stage.unit(3).setAction(0, 3)
        stage.say('&3\n형이자 셋째 형, 그리고 전략가가 추구하는 꿈을 위해,\n사람들이 평화롭고 만족스럽게 살고 일할 수 있는 평화롭고 번영하는 시대를 만드는 것이었다......')
        stage.unit(3).setAction(0, 1)
        stage.delay(3)
        stage.say('&3\n무엇을 해야 하고 무엇을 할 수 있는지 깨달을 때까지.\n&0\n이번이 우리가 헤어진 두 번째 순간이야,\n솔직히 말해서, 너랑 헤어지고 싶지 않아,\n…… 건강 조심하세요.')
        stage.unit(3).setAction(6)
        stage.say('&3\n그는 총리에게 감사를 표했다.\n총리께서도 잘 부탁드립니다.\n그럼 저는 이만 가보겠습니다.')
        stage.unit(3).setAction(0)
        stage.say('&0\n흠.')
        stage.unit(3).move(32, 51, 0)
        stage.delay(3)
        stage.unit(3).move(95, 51, 1)
        stage.unit(0).setAction(0, 1)
        stage.unit(3).hide()
        stage.delay(10)
        stage.unit(0).setAction(0, 3)
        stage.delay(10)
        stage.unit(0).move(32, 55, 3)
        stage.delay(10)
        stage.unit(0).setAction(6)
        stage.delay(10)
        stage.unit(0).setAction(0)
        stage.delay(10)
        stage.showUnits([
            [
                1,
                95,
                49,
                3],
            [
                20,
                95,
                55,
                3]])
        stage.unitsMove([
            [
                stage.unit(1),
                83,
                49,
                3],
            [
                stage.unit(20),
                83,
                55,
                3]])
        stage.say('&1\n맹덕!\n&20\n주군.')
        stage.unit(0).setAction(0, 1)
        stage.unitsMove([
            [
                stage.unit(1),
                40,
                49,
                3],
            [
                stage.unit(20),
                40,
                55,
                3]])
        stage.unit(1).setAction(0)
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n그래서 여기 있구나?\n우리가 널 찾고 있어.')
        stage.unit(1).setAction(0)
        stage.say('&0\n그래서 원양 문약 있었다.\n무슨 일이야?')
        stage.unit(1).setAction(3)
        stage.say('&1\n아, 그건 둘에 관한 이야기야......')
        stage.unit(1).setAction(0)
        stage.say('&0\n어느 두 명?')
        stage.showUnits([
            [
                17,
                95,
                49,
                3],
            [
                15,
                95,
                55,
                3]])
        stage.unitsMove([
            [
                stage.unit(17),
                83,
                49,
                3],
            [
                stage.unit(15),
                83,
                55,
                3]])
        stage.say('&15\n주군!\n&17\n우리 일이야.')
        stage.unit(1).setAction(0, 1)
        stage.unit(20).setAction(0, 1)
        stage.unitsMove([
            [
                stage.unit(17),
                48,
                49,
                3],
            [
                stage.unit(15),
                48,
                55,
                3]])
        stage.unit(17).setAction(0)
        stage.unit(15).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        stage.say('&0\n초선 그리고 허저?\n무슨 일이야?')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(6)
        stage.say('&15\n흠...... 솔직히......\n마을로 돌아가고 싶어......')
        stage.unit(15).setAction(0)
        stage.delay(3)
        stage.unit(17).setAction(6)
        stage.say('&17\n초선 너에게도 작별 인사를 하고 싶어.')
        stage.unit(17).setAction(0)
        stage.say('&0\n정말?\n너도 떠나는 거야......')
        stage.unit(1).setAction(0, 3)
        stage.say('&1\n왜 우리는 "너도 하고 싶다"고 말할까?\n그들 말고 누가 작별 인사를 할 수 있을까?\n&0\n윤창이 방금 들렀고, 그는 세상을 떠돌 계획이었다.')
        stage.unit(20).setAction(0, 3)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n알고 보니 장군관우 떠난 상태였다.')
        stage.unit(20).setAction(0)
        stage.say('&0\n허저, 고향에 돌아가고 싶다고 했지?')
        stage.unit(20).setAction(0, 1)
        stage.unit(1).setAction(0, 1)
        stage.delay(3)
        stage.unit(15).setAction(6)
        stage.say('&15\n네.\nI... 나는 여전히 내가 장군에 적합하지 않다고 느낀다......\n&15\n이제 내 고향은 평화를 되찾았어,\n그래서 그는 생계를 위해 농사를 짓기로 계획했다.\n너무 고집허저 거야, 용서해 줘주군.')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n사과할 필요 없습니다.\n전원생활을 하는 것도 좋잖아요.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(6)
        stage.say('&15\n고마워, 고마워, 주군.')
        stage.unit(15).setAction(0)
        stage.say('초선아, 너 무슨 계획이 있니?')
        stage.unit(17).setAction(6)
        stage.say('&17\n나는 황번 교단 친구들과 함께 있고 싶다,\n부모님의 나라를 구하는 꿈을 계속 이루세요.')
        stage.unit(17).setAction(0)
        stage.say('&0\n법정을 떠나는 거야......?\n이 길은 힘들 거야.')
        stage.unit(17).setAction(6)
        stage.say('&17\n초선 두렵지 않아.\n내 양아버지 왕윤허가 나를 축복봉선 때문이야.')
        stage.unit(17).setAction(0)
        stage.say('&0\n흠.')
        stage.say('&0\n요즘 우리는 함께 싸워왔고,\n나는 정말 너와 떨어져 있는 것을 견딜 수 없다,\n모두가 각자의 야망이 있으니, 억지로 붙잡아 둘 수 없어요.')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('몸조심하세요.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(17).setAction(6)
        stage.say('&17\n그는 총리에게 감사를 표했다.')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(3)
        stage.say('&15\n농사를 잘 지을게.')
        stage.unit(15).setAction(0)
        stage.delay(3)
        stage.unit(17).setAction(6)
        stage.say('&17\n샤후우 장군과 순욱 씨도 잘 챙기고 있어.')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(6)
        stage.say('&15\n너희 둘 몸 잘 챙겨.')
        stage.unit(15).setAction(0)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n초선Miss, 허저 장군."\n앞으로도 행복한 삶을 살길 바랍니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n초선 안심해야 한다,\n하지만 사실 저는 허저 때문에 꽤 걱정됩니다.')
        stage.unit(15).setAction(3)
        stage.say('&15\n무-무슨 뜻이야?')
        stage.unit(1).setAction(0)
        stage.say('&1\n화내지 마!\n농담이야, 농담이야!\n하하하.')
        stage.unit(15).setAction(0)
        stage.say('&15\n정말 말도 안 되다, 떠나기 전에 사람들을 놀리다니......')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('하하하.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(17).setAction(6)
        stage.say('&17\n그럼 then초선 가볼게요.')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(6)
        stage.say('&15\n나도 떠날 거야.\n안녕!')
        stage.unit(15).setAction(0)
        stage.say('&0\n흠.')
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(17),
                95,
                49,
                1],
            [
                stage.unit(15),
                95,
                55,
                1]])
        stage.unit(15).hide()
        stage.unit(17).hide()
        stage.delay(15)
        stage.unit(0).setAction(0, 3)
        stage.delay(10)
        stage.unit(1).setAction(0, 3)
        stage.say('&1\n맹덕, 그렇게 외로워 보이지 마.\n이건 너답지 않아!')
        stage.unit(20).setAction(0, 3)
        stage.delay(5)
        stage.unit(1).setAction(3)
        stage.say('&1\n걱정 마! 우린 항상 네 곁에 있을 거야.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네, 주군.')
        stage.unit(20).setAction(0)
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n……맞는 말씀입니다.\n저에게는 새로운 나라를 세워야 할 사명이 있습니다.')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n이제는 슬프지 않아요.\n일은 아직 우리를 기다리고 있어,\n너희 둘도 총리님 관저로 돌아가야 해.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n좋아!')
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        stage.unit(20).setAction(0)
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(0),
                87,
                55,
                1],
            [
                stage.unit(1),
                95,
                49,
                1],
            [
                stage.unit(20),
                95,
                55,
                1]])
        stage.unit(1).hide()
        stage.unit(20).hide()
        stage.unit(0).move(95, 55, 1)
        stage.unit(0).hide()
        stage.delay(20)
        stage.effectSound(200, 255)
        stage.clsUnit()
        stage.ending(2)
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
