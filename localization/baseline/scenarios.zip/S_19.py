# Source Generated with Decompyle++
# File: S_19.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(8,1)'])
    stage.nearEvent([
        15,
        101,
        15,
        114,
        15,
        115,
        15,
        113], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, 0, 0, 1)
    stage.createEnemy([
        {
            'id': 101,
            'x': 8,
            'y': 1,
            'lv': 6,
            'i': 0 },
        {
            'id': 258,
            'x': 8,
            'y': 2,
            'lv': 0,
            'i': 1 },
        {
            'id': 259,
            'x': 7,
            'y': 1,
            'lv': 0,
            'i': 2 },
        {
            'id': 260,
            'x': 9,
            'y': 1,
            'lv': 0,
            'i': 3 },
        {
            'id': 282,
            'x': 7,
            'y': 0,
            'lv': 0,
            'i': 4 },
        {
            'id': 283,
            'x': 9,
            'y': 0,
            'lv': 0,
            'i': 5 },
        {
            'id': 114,
            'x': 10,
            'y': 3,
            'lv': 4,
            'i': 6 },
        {
            'id': 264,
            'x': 10,
            'y': 4,
            'lv': 0,
            'i': 7 },
        {
            'id': 211,
            'x': 9,
            'y': 3,
            'lv': 0,
            'i': 8 },
        {
            'id': 212,
            'x': 11,
            'y': 3,
            'lv': 0,
            'i': 9 },
        {
            'id': 234,
            'x': 9,
            'y': 2,
            'lv': 0,
            'i': 10 },
        {
            'id': 235,
            'x': 11,
            'y': 2,
            'lv': 0,
            'i': 11 },
        {
            'id': 113,
            'x': 7,
            'y': 5,
            'lv': 4,
            'ai': 6,
            'targetX': 9,
            'targetY': 10,
            'i': 12 },
        {
            'id': 261,
            'x': 7,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 262,
            'x': 6,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 14 },
        {
            'id': 263,
            'x': 8,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 284,
            'x': 6,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 285,
            'x': 8,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 115,
            'x': 9,
            'y': 7,
            'lv': 4,
            'ai': 6,
            'targetX': 9,
            'targetY': 10,
            'i': 18 },
        {
            'id': 265,
            'x': 9,
            'y': 8,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 214,
            'x': 8,
            'y': 7,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 215,
            'x': 10,
            'y': 7,
            'lv': 0,
            'ai': 1,
            'i': 21 },
        {
            'id': 236,
            'x': 8,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 22 },
        {
            'id': 237,
            'x': 10,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 23 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 8,
            'y': 32,
            'dir': 0 },
        {
            'idx': 1,
            'x': 9,
            'y': 32,
            'dir': 0 },
        {
            'idx': 2,
            'x': 7,
            'y': 32,
            'dir': 0 },
        {
            'idx': 3,
            'x': 7,
            'y': 10,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 4,
            'x': 12,
            'y': 14,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 5,
            'x': 7,
            'y': 19,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 6,
            'x': 11,
            'y': 24,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 7,
            'x': 6,
            'y': 25,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 8,
            'x': 7,
            'y': 11,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 9,
            'x': 12,
            'y': 15,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 10,
            'x': 7,
            'y': 20,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 11,
            'x': 11,
            'y': 25,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 12,
            'x': 6,
            'y': 26,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(101, -1, 0, -1, 0, 4)
    stage.setEnemyEquip(113, -1, 0, 12, 0, -1)
    stage.loadBg(19)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(1)
    stage.say('&101\n비록 조조 큰 고통을 안겨주었지만,\n하지만 이번에는 마침내 한계에 몰렸다!\n&101\n이번이 조조와의 마지막 싸움이 될 거야.\n모두가 반드시 제거해야 조조.')
    stage.unit(113).setDir(stage.countDir(113, 101))
    stage.say('&113\n하하하.\n아버지, 조조 목을 가져와 뵙겠습니다.')
    stage.unit(113).setDir(2)
    stage.unit(113).setAction(5)
    stage.say('&113\n전면 군대 공격!')
    stage.unit(113).setAction(0)
    stage.say('&114\n형, 잠깐만 기다려 주세요!\n뭔가 이상하다는 느낌이 들었어요.\n&114\n어떻게 이렇게 쉽게 그럴 수 있......\n왜 그냥 조조를 함정에 빠뜨리지 않았을까요?\n매복이 있을 수도 있어!\n&113\n왜 이렇게 겁이 많아!\n그렇다면 저기서 기다리세요!')
    stage.unit(115).setDir(stage.countDir(115, 114))
    stage.say('&115\n형님, 이두 형님 말씀이 정말 일리가 있어요.\n두고 보자......')
    stage.unit(113).setDir(stage.countDir(113, 115))
    stage.unit(113).setAction(6)
    stage.say('&113\n뭐라고!\n닥쳐!')
    stage.unit(113).setAction(0)
    stage.say('&115\n……。')
    stage.unit(101).setDir(stage.countDir(101, 113))
    stage.say('&101\n원담, 진정해.\n원희 생각이 맞았다.\n&101\n조조 매복을 설치했을 거야.')
    stage.unit(113).setDir(stage.countDir(113, 101))
    stage.say('&113\n아버지, 우리가 전혀 진전하지 못한다는 말인가요?\n&101\n완전한 경계를 가지고 전진하라,\n성급하게 앞으로 나아가지 마세요!')
    stage.unit(0).setDir(stage.countDir(0, 21))
    stage.say('&0\n마침내 결정적인 전투가 시작되려 했다.\n정욱, 준비는 어떻게 돼가?')
    stage.unit(21).setDir(stage.countDir(21, 0))
    stage.say('&21\n이미 매복이 설치되어 있습니다,\n그냥 원소을 유인하려고 기다리는 거야.')
    stage.unit(21).setDir(stage.countDir(21, 15))
    stage.say('&21\n성공과 실패는 전적으로 General 허저에 달려 있습니다.\n모든 건 네게 맡길게.')
    stage.unit(15).setDir(stage.countDir(15, 21))
    stage.say('&15\n내게 맡겨.\n&21\n주군 나와 함께 여기 머물러,\n우리가 성급하게 행동하면,\n아군 매복이 사기을 흔들 거야.')
    stage.unit(0).setDir(stage.countDir(0, 101))
    stage.say('&0\n여기서 원소 없애자.\n그는 다시는 세상을 꿈꿀 수 없게 될 것이다.')
    stage.unit(101).setDir(2)
    stage.unit(114).setDir(2)
    stage.unit(113).setDir(2)
    stage.unit(115).setDir(2)
    stage.unit(0).setDir(0)
    stage.unit(21).setDir(0)
    stage.unit(15).setDir(0)
    stage.bgSound(2)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.unit(15).move(8, 25, 0)
    stage.say('&15\n(앞서 있는 기병 부대는 아마도 원상일 것이다.) )')
    stage.unit(15).move(9, 18, 0)
    stage.say('&15\n(원상 소심하고 원담 머리가 없고,\n원담 유혹하기 쉬울 수 있지만...... )')
    stage.unit(15).move(9, 11, 0)
    stage.unit(15).setAction(5)
    stage.say('&15\n어디 있원담!\n무술에 능하다고 들었는데,\nme허저 두렵지 않으면 여기로 데려와.')
    stage.unit(15).setAction(0)
    stage.say('&115\n(그것이 무술허저,\n그는 조나라 군대에서 최고 중 하나로 여겨졌잖아요!? )\n항복하러 왔나요?')
    stage.unit(15).move(9, 10, 3)
    stage.say('&15\n나는 you원상 같은 겁쟁이를 찾고 있지 않다\n원담랑 얘기하고 싶어. 문제 일으키지 마!\n&115\n뭐-뭐라고!\n뭐라고 했어?!')
    stage.unit(15).move(9, 9, 0)
    stage.say('&15\n내가 뭐라고 했지?\n내 생각에 그는 겁쟁이들을 말한 것 같다!')
    stage.say('&115\n용서할 수 없어!\n너를 죽일 거야!\n&15\n뭐-뭐라고!?\n기다려! 난 널 찾으러 왔원담......')
    stage.unit(115).setAction(6)
    stage.say('&115\n폭행!')
    stage.unit(115).setAction(0)
    stage.say('&113\n오! 저 사람은 내 좋은 형이야.\n알았어, 따라갈게!')
    stage.unit(15).setDir(2)
    stage.say('&15\n(와, 훅이 예상보다 빨리 들어왔네요!\n이건 좋은 일이었다—계획의 첫 단계가 성공했다.\n다음은 도망치는 거야! )')
    stage.startOper()
    vars[519] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 2 and stage.round() == 2:
        if not vars[2] and not vars[50] and not vars[51]:
            stage.unit(101).setAction(4)
            stage.say('&101\n안 돼! 전에 경고하지 않았어......\n원희! 빨리 멈춰원상 원담!\n이대로 계속하면 적의 손바닥에 걸릴 거야!\n&114\n네, 아버지.\n알겠습니다!')
        stage.unit(101).setAI(1)
        stage.unit(114).setAI(1)
        stage.unit(113).setAI(1)
        stage.unit(115).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        stage.unit(264).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[11] = 1
    if not vars[2] and not vars[12] and stage.unitStateTest(15, 7, 1, 0) and stage.round() >= 1 and stage.unitStateTest(15, 7, 100, 1):
        stage.unit(15).setAction(4)
        stage.say('&15\n아, 아, 아......\n아니, 뭔가 잘못됐어......')
        if not vars[52]:
            stage.unit(115).setDir(stage.countDir(115, 15))
            stage.unit(115).setAction(5)
            stage.say('&115\n아마도 한 번의 일격으로 허저를 죽일 수도 있겠지,\n그래서 그들은 곧장 조조 본영으로 향했다!')
            stage.unit(115).setAction(0)
        if not vars[53]:
            stage.unit(113).setDir(stage.countDir(113, 15))
            stage.unit(113).setAction(7)
            stage.say('&113\n조조 우리의 죄를 모욕하라,\n너와 조조의 목으로 네 죄를 속죄하겠다!')
            stage.unit(113).setAction(0)
        stage.unit(0).setAction(2)
        stage.say('(허, 허저! 이렇게 가다간 허저가 위험해져. 어떻게 해야 할까……)\n(주군, 그렇게 하는 건 너무 잔인할지도 모르지만, 차라리 허저를 포기하더라도 적의 눈을 자극해서는 안 됩니다.)')
        sel = stage.choice('움직이지 않고 부대를 막았다\n구조 허저', -1)
        if sel == 1:
            stage.unit(0).setDir(2)
            stage.say('&0\n(...허저, 미안해...... )')
            stage.unit(21).setDir(stage.countDir(21, 0))
            stage.unit(21).setAction(2)
            stage.say('&21\n(주군... 참아야 해. )')
            stage.unit(0).setDir(stage.countDir(0, 15))
            stage.unit(15).setDir(stage.countDir(15, 101))
            stage.unit(15).setAction(7)
            stage.say('&15\n이봐! 무슨 일이야? 아직 버틸 수 있어!\n용기 있으면 덤벼!\n아야, 아파!')
            stage.unit(15).setAction(0)
            if not vars[50]:
                stage.unit(101).setDir(stage.countDir(101, 0))
                stage.say('&101\n(조조 늙은 도둑은 그걸 데려갈 생각도 없어허저......\n정말로 ...... 매복이 없는 걸까요? )')
            elif sel == 2:
                stage.unit(0).setAction(5)
                stage.say('&0\n서둘러 구허저!\n가! 모두 공격해!')
                stage.unit(0).setAction(0)
                stage.unit(21).setAction(4)
                stage.say('&21\n아!')
                stage.unit(15).setDir(stage.countDir(15, 0))
                stage.say('&15\n주님, 주군!\n아직 때가 아니야......')
                stage.unit(7, 1).show()
                stage.unit(12, 1).show()
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 6,
                        'y1': 25,
                        'x2': 8,
                        'y2': 27,
                        'camp': 2 }])
                stage.unit(6, 1).show()
                stage.unit(11, 1).show()
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 9,
                        'y1': 23,
                        'x2': 11,
                        'y2': 25,
                        'camp': 2 }])
                stage.unit(5, 1).show()
                stage.unit(10, 1).show()
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 7,
                        'y1': 18,
                        'x2': 9,
                        'y2': 20,
                        'camp': 2 }])
                stage.unit(4, 1).show()
                stage.unit(9, 1).show()
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 10,
                        'y1': 13,
                        'x2': 12,
                        'y2': 15,
                        'camp': 2 }])
                stage.unit(3, 1).show()
                stage.unit(8, 1).show()
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 7,
                        'y1': 9,
                        'x2': 9,
                        'y2': 11,
                        'camp': 2 }])
                stage.unit(1).setDir(stage.countDir(1, 15))
                stage.say('&1\n허저This 아이가 실패했어!"')
                stage.unit(2).setDir(stage.countDir(2, 15))
                stage.say('&2\n적은 완전히 속지 않았다.\n이거 큰일이야!')
                stage.unit(11).setDir(stage.countDir(11, 15))
                stage.say('&11\n우리는 허저 장군을 빨리 구출해야 합니다.\n빨리!')
                stage.unit(10).setDir(stage.countDir(10, 15))
                stage.say('&10\n모두 돌격!\n따라와!')
                stage.unit(6).setDir(stage.countDir(6, 15))
                stage.say('&6\n이 사람에 대해 할 수 있는 게 정말 없어요......')
                stage.unit(7).setDir(stage.countDir(7, 15))
                stage.say('&7\n안 돼!\n이렇게 하면 매복 전술의 효과가 사라집니다......')
                stage.unit(13).setDir(stage.countDir(13, 15))
                stage.say('&13\n이 시점에서 피할 수 없었다......')
                stage.unit(14).setDir(stage.countDir(14, 15))
                stage.say('&14\n간다!\n허저General, 그냥 기다려!"')
                if not vars[50]:
                    stage.unit(101).setDir(stage.countDir(101, 0))
                    stage.say('&101\n정말 매복이 있었던 거야!\n하지만 무섭지 않은 것 같아요......\n전면적인 군대 공격! 놓조조 마!')
                vars[2] = 1
        vars[12] = 1
    if vars[3] and stage.round() >= 1 and stage.curCamp() == 0:
        stage.setAI(0, 0, 19, 39, 2, 1)
    if vars[3] and stage.round() >= 1 and stage.curCamp() == 2:
        stage.setAI(0, 0, 19, 39, 2, 6, -1, 8, 0)
        stage.setRectUnitHide(0, 0, 19, 1, 2)
    if vars[3] and stage.round() >= 1 and stage.isInRect(114, 0, 0, 19, 1):
        stage.unit(114).setDir(2)
        stage.say('&114\n다른 방법은 없었다.\n원희 먼저 후퇴해!')
        stage.unit(114).hide()
    if vars[3] and stage.round() >= 1 and stage.isInRect(113, 0, 0, 19, 1):
        stage.unit(113).setDir(2)
        stage.unit(113).setAction(7)
        stage.say('&113\n젠장, 안타깝다!\n후퇴!')
        stage.unit(113).setAction(0)
        stage.unit(113).hide()
    if vars[3] and stage.round() >= 1 and stage.isInRect(115, 0, 0, 19, 1):
        stage.unit(115).setDir(2)
        stage.unit(115).setAction(4)
        stage.say('&115\n충동적인 순간에 큰 실수를 한 내 잘못이야.\n후퇴, 후퇴!\n진정해야 해......')
        stage.unit(115).hide()
    if vars[3] and stage.round() >= 1 and stage.isInRect(101, 0, 0, 19, 1):
        stage.unit(101).setDir(2)
        stage.unit(101).setAction(9)
        stage.say('&101\n또 길을 잃었어.........\n정말 조조 패배한 걸까?\n그냥 그에게 지고 싶지 않을 뿐이야. 정말 안타깝다!')
        stage.unit(101).hide()
    if not vars[20] and stage.isInPos(1025, 8, 1):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[2] and not vars[6] and stage.totalRectUnit(0, 0, 30, 19, 39) < 2:
        stage.unit(7, 1).show()
        stage.unit(12, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 6,
                'y1': 25,
                'x2': 8,
                'y2': 27,
                'camp': 2 }])
        stage.unit(6, 1).show()
        stage.unit(11, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 9,
                'y1': 23,
                'x2': 11,
                'y2': 25,
                'camp': 2 }])
        stage.unit(5, 1).show()
        stage.unit(10, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 7,
                'y1': 18,
                'x2': 9,
                'y2': 20,
                'camp': 2 }])
        stage.unit(4, 1).show()
        stage.unit(9, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 10,
                'y1': 13,
                'x2': 12,
                'y2': 15,
                'camp': 2 }])
        stage.unit(3, 1).show()
        stage.unit(8, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 7,
                'y1': 9,
                'x2': 9,
                'y2': 11,
                'camp': 2 }])
        stage.say('&1\n적군 지금 주요 행동이야!?\n이건 공격할 좋은 기회 아니야?\n&2\n주군, 아직 너무 이른 것 같아요!\n&11\n적의 본진이 움직이기 시작한 것 같아......\n이제 공격할 때가 아니야......?\n&10\n전면 돌격!\n따라와!\n&6\n흠, 행동할 시간인가?\n전 군대를 전투에 동원하라!\n&7\n절대 안 돼! 그렇게 하면 매복이 효과가 없어.\n&13\n지금 무슨 일이야?\n&14\n그것이 공격을 시작하라는 신호였다!\n돌격!')
        if not vars[50]:
            stage.unit(101).setAction(5)
            stage.say('&101\n정말 매복이 있었던 거야!\n하지만 무섭지 않은 것 같아요......\n전면적인 군대 공격! 놓조조 마!')
            stage.unit(101).setAction(0)
            stage.say('&0\n어, 실패했나?\n이제 상황이 복잡해졌다.')
        vars[2] = 1
        vars[6] = 1
    if not vars[2] and not vars[30] and stage.isInRect(15, 0, 29, 19, 39):
        stage.unit(15).setAction(9)
        stage.say('&15\n헉, 휙.\n마침내 그는 위험에서 벗어났다.\n&0\n허저, 정말 잘했어!')
        stage.unit(0).setAction(5)
        stage.say('&0\n복병을 출동시켜라!\n원소를 포위하라!')
        stage.unit(0).setAction(0)
        stage.unit(3, 1).show()
        stage.unit(8, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 6,
                'y1': 9,
                'x2': 10,
                'y2': 12,
                'camp': 2 }])
        stage.unit(101).setDir(3)
        stage.unit(101).setDir(1)
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.unit(101).setAction(5)
        stage.say('&101\n정말 매복이 있었던 거야!\n그 뒤에 있는 것은 잊어버려!\n한 번에 돌진!')
        stage.unit(101).setAction(0)
        stage.unit(6, 1).show()
        stage.unit(11, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 9,
                'y1': 23,
                'x2': 12,
                'y2': 26,
                'camp': 2 }])
        stage.unit(7, 1).show()
        stage.unit(12, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 5,
                'y1': 24,
                'x2': 8,
                'y2': 27,
                'camp': 2 }])
        stage.unit(115).setAction(10)
        stage.say('&115\n뭐, 앞에 매복이 있나?')
        stage.unit(4, 1).show()
        stage.unit(9, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 9,
                'y1': 13,
                'x2': 13,
                'y2': 16,
                'camp': 2 }])
        stage.unit(114).setAction(8)
        stage.say('&114\n아니, 뭔가 잘못됐어......\n&113\n젠장, 너무 빨리 자만하지 마!')
        stage.unit(5, 1).show()
        stage.unit(10, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 6,
                'y1': 18,
                'x2': 10,
                'y2': 21,
                'camp': 2 }])
        stage.unit(113).setAction(10)
        stage.say('&113\n와!\n여기서도......')
        stage.unit(101).setDir(0)
        stage.unit(101).setAction(6)
        stage.say('&101\n정말 미운 조조!\n어떻게 감히 나를 놀릴 수 있this원소!\n군대 전체를 후퇴시켜! 빨리!')
        stage.unit(101).setAction(0)
        stage.setAI(0, 0, 19, 39, 2, 3, 101, 0, 0)
        stage.unit(101).setAI(4, -1, 8, 0)
        stage.unit(1).setDir(stage.countDir(1, 101))
        stage.say('&1\n속았어!')
        stage.unit(2).setDir(stage.countDir(2, 101))
        stage.unit(2).setAction(5)
        stage.say('&2\n돌격!\n폭행!')
        stage.unit(2).setAction(0)
        stage.unit(11).setDir(stage.countDir(11, 101))
        stage.say('&11\n마침내 그들은 밖에 나가 싸울 수 있었다.\n모두 돌격!')
        stage.unit(10).setDir(stage.countDir(10, 101))
        stage.unit(10).setAction(6)
        stage.say('&10\n원소를 물리쳐라!')
        stage.unit(10).setAction(0)
        stage.unit(6).setDir(stage.countDir(6, 101))
        stage.say('&6\n적군 진형이 혼란에 빠졌다!\n한 번에 쓰러뜨리자!')
        stage.unit(7).setDir(stage.countDir(7, 101))
        stage.unit(7).setAction(5)
        stage.say('&7\n죽여! 죽여! 죽여!\n모두 죽여라!')
        stage.unit(7).setAction(0)
        stage.unit(13).setDir(stage.countDir(13, 101))
        stage.say('&13\n하하하.\n이 승리는 너무 쉬웠다!')
        stage.unit(14).setDir(stage.countDir(14, 101))
        stage.say('&14\n돌격!\n단 한 명도 놓치지 마!')
        vars[2] = 1
        vars[3] = 1
        vars[30] = 1
    if not vars[2] and not vars[31] and stage.isInRect(1026, 0, 29, 19, 39):
        stage.unit(0).setAction(5)
        stage.say('&0\n복병을 출동시켜라!\n원소를 포위하라!')
        stage.unit(0).setAction(0)
        stage.unit(3, 1).show()
        stage.unit(8, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 6,
                'y1': 9,
                'x2': 10,
                'y2': 12,
                'camp': 2 }])
        stage.unit(101).setDir(3)
        stage.unit(101).setDir(1)
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.unit(101).setAction(5)
        stage.say('&101\n정말 매복이 있었던 거야!\n그 뒤에 있는 것은 잊어버려!\n한 번에 돌진!')
        stage.unit(101).setAction(0)
        stage.unit(6, 1).show()
        stage.unit(11, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 9,
                'y1': 23,
                'x2': 12,
                'y2': 26,
                'camp': 2 }])
        stage.unit(7, 1).show()
        stage.unit(12, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 5,
                'y1': 24,
                'x2': 8,
                'y2': 27,
                'camp': 2 }])
        stage.unit(115).setAction(10)
        stage.say('&115\n뭐, 앞에 매복이 있나?')
        stage.unit(4, 1).show()
        stage.unit(9, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 9,
                'y1': 13,
                'x2': 13,
                'y2': 16,
                'camp': 2 }])
        stage.unit(114).setAction(8)
        stage.say('&114\n아니, 뭔가 잘못됐어......\n&113\n젠장, 자만하지 마!')
        stage.unit(5, 1).show()
        stage.unit(10, 1).show()
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 6,
                'y1': 18,
                'x2': 10,
                'y2': 21,
                'camp': 2 }])
        stage.unit(113).setAction(10)
        stage.say('&113\n와!\n여기서도......')
        stage.unit(101).setDir(0)
        stage.unit(101).setAction(6)
        stage.say('&101\n정말 미운 조조!\n어떻게 감히 나를 놀릴 수 있this원소!\n군대 전체를 후퇴시켜! 빨리!')
        stage.unit(101).setAction(0)
        stage.setAI(0, 0, 19, 39, 2, 3, 101, 0, 0)
        stage.unit(101).setAI(4, -1, 8, 0)
        stage.unit(1).setDir(stage.countDir(1, 101))
        stage.say('&1\n속았어!')
        stage.unit(2).setDir(stage.countDir(2, 101))
        stage.unit(2).setAction(5)
        stage.say('&2\n돌격!\n폭행!')
        stage.unit(2).setAction(0)
        stage.unit(11).setDir(stage.countDir(11, 101))
        stage.say('&11\n마침내 그들은 밖에 나가 싸울 수 있었다.\n여러분, 힘내세요!')
        stage.unit(10).setDir(stage.countDir(10, 101))
        stage.unit(10).setAction(6)
        stage.say('&10\n원소 군대를 물리쳐라!')
        stage.unit(10).setAction(0)
        stage.unit(6).setDir(stage.countDir(6, 101))
        stage.say('&6\n적군 진형이 혼란에 빠졌다!\n한 번에 쓰러뜨리자!')
        stage.unit(7).setDir(stage.countDir(7, 101))
        stage.unit(7).setAction(5)
        stage.say('&7\n죽여! 죽여! 죽여!\n모두 죽여라!')
        stage.unit(7).setAction(0)
        stage.unit(13).setDir(stage.countDir(13, 101))
        stage.say('&13\n하하하.\n이 승리는 너무 쉬웠다!')
        stage.unit(14).setDir(stage.countDir(14, 101))
        stage.say('&14\n돌격!\n단 한 명도 놓치지 마!')
        vars[2] = 1
        vars[3] = 1
        vars[31] = 1
    if not vars[40] and stage.isNear(15, 101, True) and stage.unitStateTest(15, 7, 100, 0):
        stage.unit(15).setDir(stage.countDir(15, 101))
        stage.unit(101).setDir(stage.countDir(101, 15))
        stage.say('&15\n원소, 네 목을 원해!\n&101\n오늘 네가 마을 사람인 네가 나를 조롱할 줄은 몰랐어,\n정말 우리 집안의 4대, 3명의 고위 관료가 끝나는 건가요?\n&15\n어려운 시기에는 자신의 배경에 신경 쓰는 것이 무의미합니다.\n목숨을 내놓아!\n&101\n꿈 깨!\n조조 목을 베고 왕국을 차지하겠다,\n중국 전역에 위안 가문의 명성을 알리자!')
        vars[40] = 1
    if not vars[2] and not vars[41] and stage.isNear(15, 114, True) and stage.unitStateTest(15, 7, 100, 0):
        stage.unit(15).setDir(stage.countDir(15, 114))
        stage.unit(114).setDir(stage.countDir(114, 15))
        stage.say('&114\n원숭이 속이는 데 정말 능숙하네!\n&15\n무슨 헛소리를 하는 거야! 흥!')
        vars[41] = 1
    if not vars[2] and not vars[42] and stage.isNear(15, 115, True) and stage.unitStateTest(15, 7, 100, 0):
        stage.unit(15).setDir(stage.countDir(15, 115))
        stage.unit(115).setDir(stage.countDir(115, 15))
        stage.say('&115\n찾았어!\n&15\n참 인내심 많은 사람이네요.\n네 재능으로는 아직 천자가 될 수 없어!\n&115\n뭐라고!?')
        if not vars[2] and not vars[12]:
            if not vars[52]:
                stage.unit(115).setDir(stage.countDir(115, 15))
                stage.unit(115).setAction(5)
                stage.say('&115\n아마도 한 번의 일격으로 허저를 죽일 수도 있겠지,\n그래서 그들은 곧장 조조 본영으로 향했다!')
                stage.unit(115).setAction(0)
            if not vars[53]:
                stage.unit(113).setDir(stage.countDir(113, 15))
                stage.unit(113).setAction(7)
                stage.say('&113\n조조 우리의 죄를 모욕하라,\n너와 조조의 목으로 네 죄를 속죄하겠다!')
                stage.unit(113).setAction(0)
            stage.unit(0).setAction(2)
            stage.say('(허, 허저! 이렇게 가다간 허저가 위험해져. 어떻게 해야 할까……)\n(주군, 그렇게 하는 건 너무 잔인할지도 모르지만, 차라리 허저를 포기하더라도 적의 눈을 자극해서는 안 됩니다.)')
            sel = stage.choice('움직이지 않고 부대를 막았다\n구조 허저', -1)
            if sel == 1:
                stage.unit(0).setDir(2)
                stage.say('&0\n(...허저, 미안해...... )')
                stage.unit(21).setDir(stage.countDir(21, 0))
                stage.unit(21).setAction(2)
                stage.say('&21\n(주군... 참아야 해. )')
                stage.unit(0).setDir(stage.countDir(0, 15))
                stage.unit(15).setDir(stage.countDir(15, 101))
                stage.unit(15).setAction(7)
                stage.say('&15\n이봐, 뭐라고? 아직 버틸 수 있어!\n용기 있으면 덤벼!\n아야, 아파!')
                stage.unit(15).setAction(0)
                if not vars[50]:
                    stage.unit(101).setDir(stage.countDir(101, 0))
                    stage.say('&101\n(조조 늙은 도둑은 그걸 데려갈 생각도 없어허저......\n정말로 ...... 매복이 없는 걸까요? )')
                elif sel == 2:
                    stage.unit(0).setAction(5)
                    stage.say('&0\n서둘러 구허저!\n가자! 전면 군대 공격!')
                    stage.unit(0).setAction(0)
                    stage.unit(21).setAction(4)
                    stage.say('&21\n아!')
                    stage.unit(15).setDir(stage.countDir(15, 0))
                    stage.say('&15\n주님, 주군!\n아직 때가 아니야......')
                    stage.unit(7, 1).show()
                    stage.unit(12, 1).show()
                    stage.setUnitStatus([
                        {
                            'hStatus': [
                                9],
                            'x1': 6,
                            'y1': 25,
                            'x2': 8,
                            'y2': 27,
                            'camp': 2 }])
                    stage.unit(6, 1).show()
                    stage.unit(11, 1).show()
                    stage.setUnitStatus([
                        {
                            'hStatus': [
                                9],
                            'x1': 9,
                            'y1': 23,
                            'x2': 11,
                            'y2': 25,
                            'camp': 2 }])
                    stage.unit(5, 1).show()
                    stage.unit(10, 1).show()
                    stage.setUnitStatus([
                        {
                            'hStatus': [
                                9],
                            'x1': 7,
                            'y1': 18,
                            'x2': 9,
                            'y2': 20,
                            'camp': 2 }])
                    stage.unit(4, 1).show()
                    stage.unit(9, 1).show()
                    stage.setUnitStatus([
                        {
                            'hStatus': [
                                9],
                            'x1': 10,
                            'y1': 13,
                            'x2': 12,
                            'y2': 15,
                            'camp': 2 }])
                    stage.unit(3, 1).show()
                    stage.unit(8, 1).show()
                    stage.setUnitStatus([
                        {
                            'hStatus': [
                                9],
                            'x1': 7,
                            'y1': 9,
                            'x2': 9,
                            'y2': 11,
                            'camp': 2 }])
                    stage.unit(1).setDir(stage.countDir(1, 15))
                    stage.say('&1\n허저This 아이가 실패했어!"')
                    stage.unit(2).setDir(stage.countDir(2, 15))
                    stage.say('&2\n적은 완전히 속지 않았다.\n이거 큰일이야!')
                    stage.unit(11).setDir(stage.countDir(11, 15))
                    stage.say('&11\n우리는 허저 장군을 빨리 구출해야 합니다.\n빨리!')
                    stage.unit(10).setDir(stage.countDir(10, 15))
                    stage.say('&10\n모두 돌격!\n따라와!')
                    stage.unit(6).setDir(stage.countDir(6, 15))
                    stage.say('&6\n이 사람에 대해 할 수 있는 게 정말 없어요......')
                    stage.unit(7).setDir(stage.countDir(7, 15))
                    stage.say('&7\n안 돼!\n이렇게 하면 매복 전술의 효과가 사라집니다......')
                    stage.unit(13).setDir(stage.countDir(13, 15))
                    stage.say('&13\n이 시점에서 피할 수 없었다......')
                    stage.unit(14).setDir(stage.countDir(14, 15))
                    stage.say('&14\n돌격! 허저 장군님, 잠시만 기다려 주세요!')
                    if not vars[50]:
                        stage.unit(101).setDir(stage.countDir(101, 0))
                        stage.say('&101\n정말 매복이 있었던 거야!\n하지만 무섭지 않은 것 같아요......\n전면적인 군대 공격! 놓조조 마!')
                    vars[2] = 1
            vars[12] = 1
        vars[42] = 1
    if not vars[2] and not vars[43] and stage.isNear(15, 113, True) and stage.unitStateTest(15, 7, 100, 0):
        stage.unit(15).setDir(stage.countDir(15, 113))
        stage.unit(113).setDir(stage.countDir(113, 15))
        stage.say('&113\n허저, 뛰지 마!\n나랑 경쟁해.\n&15\n한눈에 알 수 있었다,\n넌 나한테 전혀 상대가 안 돼.\n몇 년간 다시 훈련하고 다시 돌아오세요!\n&113\n음, 음!')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(101, 7, 0, 2):
        stage.say('&101\n또 길을 잃었어.........\n정말 조조 패배한 걸까?\n그냥 그에게 지고 싶지 않을 뿐이야. 정말 안타깝다!')
        stage.unit(101).hide(1)
        stage.getItem(111, 0, True, 1027)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(114, 7, 0, 2):
        stage.say('&114\n아니야.\n원희 먼저 후퇴해.')
        stage.unit(114).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(115, 7, 0, 2):
        stage.say('&115\n아파, 아직 죽고 싶지 않아!\n……? ……? 왜 그럴까요?\n내가 너무 충동적이라서 다 잘못이야......\n&115\n후퇴, 후퇴!\n진정해야 해......')
        stage.unit(115).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(113, 7, 0, 2):
        stage.say('&113\n젠장, 정말 안타깝다.\n후퇴!')
        stage.unit(113).hide(1)
        vars[53] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        if vars[3]:
            stage.say('&0\n아주 좋아, 드디어 적을 물리쳤어!\n아군 이겼어!')
            stage.reward()
        else:
            stage.say('&0\n아주 좋아, 드디어 적을 물리쳤어!\n아군 이겼어!')
            stage.reward(0, [
                160,
                -1])
        stage.end()
        vars[0] = 1
        vars[619] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원소에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
