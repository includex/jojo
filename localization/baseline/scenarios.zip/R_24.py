# Source Generated with Decompyle++
# File: R_24.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 398, 36)
    stage.showHead(113, 462, 36)
    stage.bottomTxt('조조', False, False, False)
    stage.delay(5)
    stage.head(113).hide()
    stage.delay(5)
    stage.bottomTxt('원담 원소의 장남이 탈락하면,', True, False, False)
    stage.delay(5)
    stage.head(0).move(424, 36)
    stage.delay(5)
    stage.bottomTxt('그들은 난피를 점령했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('이 시점에서,', True, True, False)
    stage.delay(5)
    stage.showHead(115, 490, 0)
    stage.delay(5)
    stage.bottomTxt('원상', True, True, False)
    stage.delay(5)
    stage.showHead(114, 554, 0)
    stage.delay(5)
    stage.bottomTxt('그리고 원소의 두 번째 son원희', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그리고 류청으로 도망치고 있었다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 42)
    stage.showUnits([
        [
            0,
            54,
            70],
        [
            1,
            35,
            56,
            1],
        [
            15,
            35,
            50,
            1],
        [
            2,
            35,
            44,
            1],
        [
            23,
            35,
            38,
            1],
        [
            20,
            71,
            56,
            2],
        [
            22,
            71,
            50,
            2],
        [
            24,
            71,
            44,
            2],
        [
            21,
            71,
            38,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setEventName('류청으로 가는 길')
    stage.setStageName('난피 임시 총리 관저')
    stage.say('&0\n그래? 원상와 원희가 류청으로 도망치는 거야?')
    stage.unit(20).setAction(6)
    stage.say('&20\n네.\n&20\n그들은 자연 요새를 이용해 완강히 저항해야 하는 것 같다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흠.\n우리는 어쩔 수 없이 한 번에 전진할 수밖에 없었다.')
    stage.unit(2).setAction(0, 2)
    stage.say('&2\n주군.\n&0\n무슨 일이야, 원위안?\n&2\n원양 장군과 나\n나는 류청에 지형을 보러 갔다.\n&0\n음, 어때?\n&2\n그곳 길은 위험하다,\n대규모 병력은 이동할 수 없습니다.\n&0\n흠......')
    stage.unit(2).setAction(0, 1)
    stage.delay(3)
    stage.unit(22).setAction(6)
    stage.say('&22\n그래서 공격할 소규모 부대를 선택해야 했습니다.')
    stage.unit(22).setAction(0)
    stage.say('하지만 이번 싸움은 매우 위험합니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n원씨 가문이 거의 전멸한 것을 보네,\n쉬두로 돌아가는 게 낫겠어......')
    stage.unit(22).setAction(6)
    stage.say('&22\n주군, 절대 아니에요.')
    stage.unit(22).setAction(0)
    stage.say('&22\n위안 가문은 허베이에 깊은 뿌리를 두고 있었다.\n&22\n지금 원씨를 소탕하지 않으면,\n주군 앞으로 분명히 후회할 거예요!\n&0\n흠......')
    stage.delay(10)
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n흠...... 좋아.\n그리고 군대를 류청으로 진격시켰다.')
    stage.unit(22).setAction(6)
    stage.say('&22\n네.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 424, 36)
    stage.showHead(115, 490, 0)
    stage.showHead(114, 554, 0)
    stage.delay(8)
    stage.head(0).move(426, 0)
    stage.delay(5)
    stage.bottomTxt('조의 군대는 류청으로 도망쳤다.', False, False, True)
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            2,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('류청 교외, 조조군의 본진')
    stage.say('&0\n류청으로 가는 길은 여기보다 더 위험하다,\n여기서 싸울 병력을 선택합시다.')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n주군, 내가 싸울게.\n&0\n곽가......?\n병이 완치되었나요?')
    stage.unit(22).setAction(6)
    stage.say('&22\n걱정하지 마세요,\n그 사소한 사람은 이미 회복했다......\n&0\n정말......... 좋아.\n건강을 잘 관리해야 합니다.\n&22\n네.')
    stage.unit(22).setAction(0)
    stage.say('&22\n(주군 보게 할 수 없어,\n……… 저를 위해서요.........\n이게 마지막 전투일지도 몰라...... )')
    stage.unit(22).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 7, [
        22,
        2])
    gvars[4076] = 0
    gvars[4057] = 24
    stage.setBattlePos([
        [
            6,
            16],
        [
            5,
            15],
        [
            7,
            17],
        [
            7,
            15],
        [
            6,
            14],
        [
            8,
            16],
        [
            5,
            17],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 지형은 어떤가요?\n&20\n강이 전장을 위에서 아래로 나누고 있습니다.\n&20\n류청으로 바로 이어지는 작은 길도 있습니다.\n하지만 이 지형에서 매복 가능성이 매우 높습니다.\n&0\n매복 ......? 맞아.')
    if stage.unitClickTest(2):
        stage.say('&2\n주군... 이 전투에 관해서는,\n그는 불안함을 감출 수 없었다.')
    if stage.unitClickTest(1):
        stage.say('&1\n그런데, 맹덕.\n정찰하다가 뭔가 들었어.\n&0\n무슨 일이야?\n&1\n최근 마을 아이들이 호랑이를 목격했다.\n&0\n타이거?\n&1\n흠.\n하지만 이 말들은 아이에게서 나온 말이었다......\n&0\n그래서 그런 거구나......\n너무 걱정할 필요 없을 것 같아요.\n&0\n호랑이가 정말 나타난다 해도,\n호랑이가 군대를 공격한다는 이야기도 들어본 적이 없었다.\n&1\n네.')
        stage.unit(22).setAction(0, 2)
        stage.say('&22\n…… 타이거 ......?')
        stage.unit(22).setAction(0, 3)
    if stage.unitClickTest(15):
        stage.say('&15\n꼭 나를 전투에 보내 줘.')
    if stage.unitClickTest(22):
        stage.say('곽가.\n이번 전투가 끝나면 넌 좀 쉬는 게 좋겠다.\n아?\n내가 보기엔 네가 쉬는 게 좋을 것 같아. 빨리 몸을 추스르는 게 중요해.\n예… 주군, 감사합니다.\n……주군.\n음? 무슨 일이야?\n아, 아니… 아무것도 아니야. 하하하하.\n응? 너 오늘 정말 이상하다.')
    if stage.unitClickTest(21):
        stage.say('&21\n원씨를 제거하려면 지금이 유일한 기회입니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
