# Source Generated with Decompyle++
# File: S_33.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        10,
        84,
        10,
        80,
        2,
        76,
        2,
        85], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 76, -1, 2, 2)
    stage.createEnemy([
        {
            'id': 76,
            'x': 9,
            'y': 29,
            'dir': 0,
            'lv': 6,
            'ai': 4,
            'targetX': 10,
            'targetY': 23,
            'i': 0 },
        {
            'id': 93,
            'x': 8,
            'y': 29,
            'dir': 0,
            'lv': 4,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 1 },
        {
            'id': 358,
            'x': 7,
            'y': 28,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 2 },
        {
            'id': 359,
            'x': 8,
            'y': 28,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 3 },
        {
            'id': 360,
            'x': 9,
            'y': 28,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 4 },
        {
            'id': 361,
            'x': 10,
            'y': 28,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 5 },
        {
            'id': 234,
            'x': 7,
            'y': 29,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 6 },
        {
            'id': 235,
            'x': 10,
            'y': 29,
            'dir': 0,
            'lv': 0,
            'ai': 4,
            'targetX': 15,
            'targetY': 17,
            'i': 7 },
        {
            'id': 84,
            'x': 10,
            'y': 23,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 8 },
        {
            'id': 80,
            'x': 11,
            'y': 23,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 9 },
        {
            'id': 362,
            'x': 9,
            'y': 23,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 363,
            'x': 9,
            'y': 24,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 364,
            'x': 12,
            'y': 23,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 365,
            'x': 12,
            'y': 24,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 236,
            'x': 10,
            'y': 24,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 14 },
        {
            'id': 237,
            'x': 11,
            'y': 24,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 83,
            'hide': 1,
            'x': 1,
            'y': 29,
            'dir': 1,
            'lv': 4,
            'ai': 1,
            'i': 16 },
        {
            'id': 85,
            'hide': 1,
            'x': 2,
            'y': 30,
            'dir': 1,
            'lv': 6,
            'ai': 1,
            'i': 17 },
        {
            'id': 258,
            'hide': 1,
            'x': 0,
            'y': 29,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 259,
            'hide': 1,
            'x': 1,
            'y': 30,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 260,
            'hide': 1,
            'x': 2,
            'y': 31,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 261,
            'hide': 1,
            'x': 0,
            'y': 30,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 21 },
        {
            'id': 282,
            'hide': 1,
            'x': 1,
            'y': 31,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 22 },
        {
            'id': 283,
            'hide': 1,
            'x': 0,
            'y': 31,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 23 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 14,
            'y': 15,
            'dir': 3 },
        {
            'idx': 1,
            'x': 15,
            'y': 16,
            'dir': 3 },
        {
            'idx': 2,
            'x': 15,
            'y': 17,
            'dir': 3 },
        {
            'idx': 3,
            'x': 14,
            'y': 16,
            'dir': 3 },
        {
            'idx': 6,
            'x': 13,
            'y': 15,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 7,
            'x': 16,
            'y': 16,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 4,
            'x': 14,
            'y': 3 },
        {
            'idx': 5,
            'x': 15,
            'y': 3 },
        {
            'idx': 8,
            'x': 14,
            'y': 2 },
        {
            'idx': 9,
            'x': 15,
            'y': 2 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(33)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab26')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab26')
    stage.draw()
    stage.bgSound(1)
    stage.say('&80\n동오군이 다시 돌아올 줄은 몰랐어!\n이번에는 내가 얼마나 강력한지 보여주고 싶어.\n&84\n왜 아직 전투 명령이 내려지지 않은 거야!\n내 앞에 있는 적군 병사들이 정말 견딜 수 없어,\n그냥 가만히 서 있을 건가요!?')
    stage.unit(93).setDir(stage.countDir(93, 76))
    stage.say('&93\n주군, 선봉군은 이미 배치되어 있다,\n공격 명령은 언제든지 내려질 수 있습니다.')
    stage.unit(76).setDir(stage.countDir(76, 93))
    stage.say('&76\n하지만 후위 부대는 아직 도착하지 않았다.\n모든 병력이 준비되자,\n여몽와 감녕가 다시 행동에 나서게 하자.')
    stage.unit(11).setDir(stage.countDir(11, 2))
    stage.say('&11\n장료General, 어떻게 해야 할까?"\n적이 이미 강 건너편에 도착했어!')
    stage.unit(2).setDir(stage.countDir(2, 11))
    stage.say('&2\n여기 주군 편지들이 있습니다.\n결정을 내리기 전에 지침을 꼭 읽어보세요.')
    stage.unit(10).setDir(stage.countDir(10, 2))
    stage.say('&10\n어때?\n편지에 뭐라고 적혀 있었......?\n&2\n자, 전쟁이 시작된 후 상황을 파악해 봅시다,\n적의 힘을 약화시키고,\n그는 도시로 후퇴해 방어를 굳건히 지켰다.\n&11\n그래서,\n즉, 손권 선봉대와 교전한 후,\n그는 즉시 도시로 후퇴해 도시를 방어했다.\n&10\n하지만 우리 군대가 이를 지킬 수 있을까?\n&2\n아마도 적이 병력을 모기 전에,\n결정적인 전투가 더 낫다.\n응............')
    sel = stage.choice('그리고 도시 성벽을 굳건히 지켰다\n그리고 도시를 벗어나 전투에 나섰다', 2)
    if sel == 1:
        stage.say('&2\n주군의 명령이었으니,\n그가 시키는 대로 하자.\n&2\n먼저 여기서 기습 공격을 위해 매복을 설치했고,\n적의 선봉을 공격하며,\n그리고 추격을 포기하고 도시로 후퇴했다!')
    elif sel == 2:
        stage.say('&2\n전술적 적용의 미묘함은 마음에 달려 있다.\n전력을 다해 승자를 정합시다.\n&2\n먼저 여기서 기습 공격을 위해 매복을 설치했고,\n이는 적의 선봉 부대를 공격하기 위한 것입니다.\n&2\n그리고 적이 혼란에 빠질 때,\n주둔군을 파견대 단위로 배치하고,\n손권의 주 기지를 완전히 공격하세요.')
        vars[2] = 1
    stage.say('&10\n내가 유혹해볼게적군.\n&2\n악진General, 수고해 주셔서 감사합니다."')
    stage.bgSound(4)
    stage.unit(2).move(14, 13, 1)
    stage.unit(11).move(17, 14, 3)
    stage.unit(2).hide()
    stage.unit(11).hide()
    stage.unit(10).move(12, 19, 2)
    stage.unit(3, 1).move(11, 18, 2)
    if vars[2]:
        stage.unit(4, 1).move(12, 6, 3)
        stage.unit(5, 1).move(13, 7, 3)
        stage.unit(8, 1).move(13, 6, 3)
        stage.unit(9, 1).move(14, 7, 3)
    stage.unit(10).setDir(stage.countDir(10, 80))
    stage.say('&10\n이 성가신 파리들,\n몇 번 다시 보내진 후에야 만족감을 느낀다.')
    stage.unit(80).setDir(stage.countDir(80, 10))
    stage.say('&80\n이렇게 작은 병력이 무엇을 할 수 있을까요?\n자랑조차 타이밍에 달려 있어요!\n&10\n흥! 이길 수 없다면, 순수한 숫자를 써라,\n여성스러운 남자들로 가득해.')
    stage.unit(84).setDir(stage.countDir(84, 10))
    stage.say('&84\n이봐, 이봐, 이봐!\n내가 감녕는 큰 깃발 안 보여?\n&84\n노자는 침묵한다,\n너 너무 건방지게 굴고 있어!\n내가 널 베는 거 봐!')
    stage.unit(10).setDir(0)
    stage.say('&10\n난 너랑 싸울 생각도 안 해!\n&84\n너—거기서 멈춰!')
    stage.unit(84).move(11, 19, 1)
    stage.unit(80).setDir(stage.countDir(80, 84))
    stage.unit(84).setDir(stage.countDir(84, 10))
    stage.say('&80\n이봐!? 감녕Come 돌아와!"\n그는 정말 용감했지만 무모함은 없었다.\n하아, 우리가 할 수 있는 게 없어.\n&80\n모든 병사들이 감녕를 따라잡았다!')
    stage.unit(80).move(12, 20, 0)
    stage.unit(362).move(10, 19, 0)
    stage.unit(363).move(10, 20, 0)
    stage.unit(364).move(11, 20, 0)
    stage.unit(365).move(11, 21, 0)
    stage.unit(236).move(10, 21, 0)
    stage.unit(237).move(11, 22, 0)
    if vars[2]:
        stage.unit(4, 1).move(10, 9, 3)
        stage.unit(5, 1).move(11, 10, 3)
        stage.unit(8, 1).move(11, 9, 3)
        stage.unit(9, 1).move(12, 10, 3)
    stage.say('&84\n이봐! 악진Don 도망치지 마!\n그냥 순종적으로 싸워!')
    fight = stage.startFight(10, 84, 5)
    fight.showUnit(False, '이봐, 이봐, 이봐!\n내가 네 눈을 감녕기 전에 도망가고 싶어?\n넌 너무 거만해, 꼬마야!', 9)
    fight.showUnit(True, '(아직 때가 아니야.\n좀 더 유인한 다음에 움직여야지……)', 0)
    fight.showStart()
    fight.setAction(False, 8)
    fight.say(False, '내가 말하는 거야!\n전투에서 도망치는 자들,\n그는 단지 군사 장군이라 불릴 자격이 없었다.', True)
    fight.setAction(False, 1)
    fight.say(False, '사랑하는 사람을 위해 필사적으로 싸우고 있주군......', True)
    fight.setAction(True, 4)
    fight.setAction(False, 6)
    fight.say(False, '적군 포위된 전장을 헤쳐 나가세요......', True)
    fight.setAction(True, 1)
    fight.setAction(True, 3)
    fight.setAction(True, 2)
    fight.setAction(True, 13)
    fight.setAction(False, 9)
    fight.say(False, '적군을 전장에서 죽을 때까지 싸우세요......', True)
    fight.setAction(False, 8)
    fight.say(False, '이게 진정한 장군의 모습이야!', True)
    stage.delay(4)
    fight.setAction(False, 1)
    fight.say(False, '그렇지!? 그렇지 않아?', True)
    fight.setAction(False, 11)
    fight.say(False, '아? 아니, 없어졌어......\n무슨 일이야!', True)
    fight.setAction(False, 9)
    fight.say(False, '음, 아!\n그는 실제로 내 감녕에서 도망치고 싶어 했어!\n너무 오만해요......', False)
    fight.setAction(False, 3)
    fight.setAction(False, 2)
    fight.setAction(False, 2)
    fight.setAction(False, 2)
    fight.setAction(False, 13)
    fight.end()
    stage.unit(10).move(15, 16, 0)
    stage.unit(3, 1).move(14, 15, 0)
    stage.say('&84\n추격! 도망치게 하지 마!\n&80\n어떻게 이렇게 된 거죠?\n그에 대해 내가 할 수 있는 게 정말 없어......')
    stage.unit(84).move(14, 17, 0)
    stage.unit(80).move(15, 18, 0)
    stage.unit(362).move(13, 17, 0)
    stage.unit(363).move(13, 18, 0)
    stage.unit(364).move(14, 18, 0)
    stage.unit(365).move(14, 19, 0)
    stage.unit(236).move(12, 18, 0)
    stage.unit(237).move(13, 19, 0)
    stage.unit(76).setDir(stage.countDir(76, 84))
    stage.unit(76).setAction(5)
    stage.say('&76\n흠, 방금 그렇게 말하지 않았나요?\n다른 방법이 없어, 우리도 공격하자!')
    stage.unit(76).setAction(0)
    stage.unit(358).move(9, 23, 0)
    stage.unit(359).move(10, 24, 0)
    stage.unit(360).move(8, 23, 0)
    stage.unit(361).move(9, 24, 0)
    stage.unit(234).move(9, 25, 0)
    stage.unit(235).move(8, 24, 0)
    stage.unit(93).move(8, 25, 0)
    stage.unit(76).move(9, 26, 0)
    if vars[2]:
        stage.unit(4, 1).move(8, 12, 2)
        stage.unit(5, 1).move(9, 13, 2)
        stage.unit(8, 1).move(8, 11, 2)
        stage.unit(9, 1).move(9, 12, 2)
    stage.say('&10\n아......\n빨리 도망쳐! 하하......')
    stage.unit(10).move(15, 10, 2)
    stage.unit(3, 1).move(16, 11, 2)
    stage.say('&84\n꽤 빨리 달리고 있어!\n&80\n감녕, 너무 깊이 쫓지 마. 빨리 돌아와!\n좀 이상한 기분이에요.')
    stage.unit(84).move(15, 12, 0)
    stage.unit(80).move(16, 13, 0)
    stage.unit(362).move(15, 13, 0)
    stage.unit(364).move(16, 14, 0)
    stage.unit(363).move(15, 14, 0)
    stage.unit(365).move(16, 15, 0)
    stage.unit(236).move(14, 15, 0)
    stage.unit(237).move(15, 16, 0)
    stage.unit(10).setDir(stage.countDir(10, 84))
    stage.unit(10).setAction(5)
    stage.say('&10\n좋아! 지금이 바로 그때야!')
    stage.unit(10).setAction(0)
    stage.unit(2).show(14, 13, 1)
    stage.unit(11).show(17, 14, 3)
    stage.unit(6, 1).show()
    stage.unit(7, 1).show()
    stage.unit(2).setDir(stage.countDir(2, 80))
    stage.unit(11).setDir(stage.countDir(11, 80))
    stage.say('&2\n적이 함정에 빠졌어!\n&11\n모든 것이 계획대로 순조롭게 진행되었다.')
    stage.unit(84).setDir(3)
    stage.unit(84).setDir(1)
    stage.unit(84).setDir(2)
    stage.say('&84\n좋지 않아!\n포위됐어!\n이 자식!\n&80\n감녕, 병사들을 모아라!\n이대로 가면......... 음음!')
    stage.setUnitStatus([
        {
            'hStatus': [
                9],
            'x1': 14,
            'y1': 12,
            'x2': 16,
            'y2': 16,
            'camp': 2 }])
    stage.unit(93).setDir(stage.countDir(93, 84))
    stage.unit(76).setDir(stage.countDir(76, 84))
    stage.say('&93\n안타깝게도 이 감녕은 부결되었다......\n여몽 이 사람이 그를 막지 않았나요?\n&76\n동시, 서둘러 지원해!')
    stage.unit(2).setAction(5)
    if vars[2]:
        stage.say('&2\n좋아! 선봉대를 한 번에 확실히 무너뜨려!\n분견대와 주력 부대가 함께 공격했다!')
    else:
        stage.say('&2\n좋아! 선봉대를 한 번에 확실히 무너뜨려!\n그는 즉시 도시로 후퇴했다,\n적이 도시에 들어오지 못하게 하라!')
    stage.unit(2).setAction(0)
    stage.setWinCondition('승리 조건\n1. 손권 격퇴.\n\n패배 조건\n1. 군대 전체가 전멸했다.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('손권을 막아라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[533] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 2 and stage.round() == 2:
        stage.unit(83).show()
        stage.unit(85).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(83).setDir(stage.countDir(83, 76))
        stage.unit(85).setDir(stage.countDir(85, 76))
        stage.unit(83).setAction(10)
        stage.say('&83\n어머, 이런!? 아직도 그리웠네요!\n뜻밖에도 전투는 이미 시작된 상태였다!\n정말 미안해손권주군!\n&85\n흠, 아직도 기회를 놓쳤어?\n군대 전체가 가속해 전진했다!\n서둘러!')
        stage.unit(76).setAI(4, -1, 11, 23)
        vars[11] = 1
    if not vars[12] and stage.round() == 3:
        stage.unit(76).setAI(1)
        stage.unit(93).setAI(1)
        stage.unit(358).setAI(1)
        stage.unit(359).setAI(1)
        stage.unit(360).setAI(1)
        stage.unit(361).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[12] = 1
    if vars[11] and not vars[2] and not vars[6] and stage.totalUnit(0) >= 4 and stage.totalUnit(2) < 7:
        stage.resumeCtrl()
        stage.say('&76\n음, 이 녀석들 정말 다루기 힘들어!\n아군 전투력 소모가 너무 컸다.\n다른 방법이 없었으니 후퇴해야 해.')
        vars[50] = 1
        if not vars[51]:
            stage.unit(85).setDir(stage.countDir(85, 76))
            stage.say('&85\n후회, 우리가 물러나야 할까......')
            vars[51] = 1
        if not vars[54]:
            stage.unit(83).setDir(stage.countDir(83, 76))
            stage.say('&83\n흠, 내가 일찍 도착해서 전투에 참여할 수만 있다면......\n손권주군, 미안해!')
            vars[54] = 1
        if not vars[55]:
            stage.unit(93).setDir(stage.countDir(93, 76))
            stage.say('&93\n훗! 이거 기억해!\n이걸 받아들일 수가 없어요—아직 배부르지도 않았거든요!')
            vars[55] = 1
        stage.setRectUnitHide(0, 0, 19, 31, 2)
        vars[6] = 1
        stage.say('&2\n좋아, 드디어 적군을 쫓아냈다!\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[633] = 1
        return True
    if not vars[40] and stage.isNear(10, 84, True):
        stage.unit(10).setDir(stage.countDir(10, 84))
        stage.unit(84).setDir(stage.countDir(84, 10))
        stage.say('&10\n이제 우리를 거스른 걸 후회하지?\n&84\n뭐라고 했어!?')
        vars[40] = 1
    if not vars[41] and stage.isNear(10, 80, True):
        stage.unit(10).setDir(stage.countDir(10, 80))
        stage.unit(80).setDir(stage.countDir(80, 10))
        stage.say('&10\n여몽, 내년 오늘이 네 기일이 될 거야!\n저승으로 가서 후회해!\n&80\n학자가 신뢰받는 사람을 위해 죽는다,\n후회 없이 죽여몽 있어.')
        vars[41] = 1
    if not vars[42] and stage.isNear(2, 76, True):
        stage.unit(2).setDir(stage.countDir(2, 76))
        stage.unit(76).setDir(stage.countDir(76, 2))
        stage.say('&2\n손권! 목숨을 내놓아!\n&76\n장료......?\n조조 늙은 도적들이여,\n그는 실제로 여러 유능한 장군들을 지휘하고 있었다.')
        vars[42] = 1
    if not vars[43] and stage.isNear(2, 85, True):
        stage.unit(85).setDir(stage.countDir(85, 2))
        stage.unit(2).setDir(stage.countDir(2, 85))
        stage.say('&85\n네 머리카락 만지게 주군 못 할게.\n장료! 너를 죽일 거야!\n&2\n넌 말만 하고 날 막을 방법이 없어.\n어서!')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&76\n음, 이 녀석들 정말 다루기 힘들어!\n아군 전투력 소모가 너무 컸다.\n다른 방법이 없었으니 후퇴해야 해.')
        vars[50] = 1
        if not vars[51]:
            stage.unit(85).setDir(stage.countDir(85, 76))
            stage.say('&85\n후회, 우리가 물러나야 할까......')
            vars[51] = 1
        if not vars[54]:
            stage.unit(83).setDir(stage.countDir(83, 76))
            stage.say('&83\n흠, 내가 일찍 도착해서 전투에 참여할 수만 있다면......\n손권주군, 미안해!')
            vars[54] = 1
        if not vars[55]:
            stage.unit(93).setDir(stage.countDir(93, 76))
            stage.say('&93\n훗! 이거 기억해!\n이걸 받아들일 수가 없어요—아직 배부르지도 않았거든요!')
            vars[55] = 1
        stage.setRectUnitHide(0, 0, 19, 31, 2)
        stage.say('&2\n좋아, 드디어 적군을 쫓아냈다!\n아군 이겼어!')
        if vars[2]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[633] = 1
        return True
    if not vars[51] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n젠장, 언젠가 이 수치를 반드시 깨끗이 할 거야!')
        stage.unit(85).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n아, 더는 못 참겠어!\n물러나는 게 낫다.')
        stage.unit(84).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(80, 7, 0, 2):
        stage.say('&80\n운과 불운은 네가 결정해; 내가 너무 부주의했어.\n이 교훈을 깊이 기억할 것입니다......\n일단 후퇴하자.')
        stage.unit(80).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n후퇴!\n빨리 후퇴해!')
        stage.unit(83).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(93, 7, 0, 2):
        stage.say('&93\n음 ......\n다른 방법은 없어요—후퇴하는 것!')
        stage.unit(93).hide(1)
        vars[55] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&2\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        if vars[2]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[633] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조의 군대는 손권군 앞에서 참패를 당하고 후퇴했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
