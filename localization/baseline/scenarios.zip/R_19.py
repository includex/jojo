# Source Generated with Decompyle++
# File: R_19.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(18)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            35,
            54,
            1],
        [
            20,
            63,
            54,
            3],
        [
            22,
            63,
            48,
            3],
        [
            21,
            63,
            42,
            3]])
    if not vars[718]:
        stage.showUnits([
            [
                7,
                49,
                54,
                2],
            [
                181,
                45,
                48,
                2],
            [
                182,
                53,
                48,
                2],
            [
                15,
                35,
                48,
                1]])
    stage.draw()
    stage.setEventName('천명')
    stage.setStageName('관두조조 본진지')
    stage.delay(3)
    if not vars[718]:
        stage.info('조조 관두 전투에서 승리를 거두었다.\n장합 원소군의 사나운 장군을 포로로 잡았다.')
        stage.unit(0).setAction(3)
        stage.say('&0\n장 장군, 무공이 뛰어나네요,\n정말 존경조조.')
        stage.unit(0).setAction(0)
        stage.say('&0\n그래서... 같이 해, 알겠지?\n&7\n나는 두 번째 주인으로 봉사할 생각을 해본 적이 없었다......\n&20\n장군이 영주에게 충성을 다하려 한다 해도,\n이제 그는 원소 곁으로 돌아갈 수 없다......')
        stage.unit(7).setAction(0, 1)
        stage.say('&7\n뭐라고! 이게 무슨 뜻이야?\n&20\n방금 원소군에 스파이가 침투했다는 보고를 받았다......\n&20\n전략가 곽투가 이 패배에 책임을 졌다.\n모든 책임이 당신에게 씌워져 있어요.\n&7\n뭐라고! 젠장......\n&20\n제가 하는 말은 모두 사실입니다.')
        stage.unit(7).setAction(0, 2)
        stage.say('&7\n젠장! 궈투는 정말 좁은 사람이야.\n하지만 주군 아마 믿지 않을 거예요......\n&20\n정말 그렇게 생각해?\n&20\n원소의 행동을 잘 기억해 주세요,\n그가 톈펑과 그를 훈계하려던 저수를 어떻게 다룰지 지켜보자.')
        stage.unit(7).setAction(0, 1)
        stage.say('&7\n…………\n&0\n…… 장 장군.\n그런 비방으로 비방당하고 죽고 싶지 않겠지?')
        stage.unit(7).setAction(0, 2)
        stage.say('&0\n나를 섬기소서,\n그리고 실력을 확립하고 경력을 쌓는 것.')
        stage.unit(7).setAction(6)
        stage.say('&7\n…… 좋아.\n저는 조 재상께 최고의 충성을 다해 섬기겠습니다.')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n아, 동의했구나!\n&7\n네.')
        stage.unit(0).setAction(0)
        stage.say('&0\n흠. 장 장군님, 정말 기쁩니다!\n당신 같은 용맹한 장군이 합류해 주신 것을 환영합니다아군......\n잘 해내길 바란다.\n&7\n셰 주군.')
        model.setFace(0)
        stage.unit(7).setAction(0)
        stage.unitsMove([
            [
                stage.unit(181),
                45,
                36,
                0],
            [
                stage.unit(182),
                53,
                36,
                0],
            [
                stage.unit(7),
                49,
                42,
                0]])
        stage.delay(1)
        stage.unitsMove([
            [
                stage.unit(7),
                35,
                42,
                3],
            [
                stage.unit(181),
                45,
                26,
                0],
            [
                stage.unit(182),
                53,
                26,
                0]])
        stage.delay(3)
        stage.unit(7).setAction(0, 1)
        stage.unit(181).move(49, 26, 1)
        stage.delay(1)
        stage.unitsMove([
            [
                stage.unit(181),
                49,
                22,
                0],
            [
                stage.unit(182),
                49,
                26,
                3]])
        stage.delay(1)
        stage.unitsMove([
            [
                stage.unit(181),
                49,
                16,
                0],
            [
                stage.unit(182),
                49,
                20,
                0]])
        stage.unit(181).hide()
        stage.unit(182).move(49, 16, 0)
        stage.unit(182).hide()
        model.unitJoin(7, 0, 0)
        if vars[1013]:
            gvars[0] = 7
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
    if vars[718]:
        stage.showUnit(15, 49, 16, 2)
        stage.say('&15\n주군, 장합가 면담을 요청했어.')
        model.setFace(3)
        stage.unit(0).setAction(3)
        stage.say('&0\n오, 온다!\n그를 기다리고 있어.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(0, 0)
        stage.say('&15\n들어오세요.\n&7\n네.')
        stage.unit(15).move(49, 48, 2)
        stage.showUnit(7, 49, 16, 2)
        stage.say('&7\n경의를 표하겠습니다, 선생님.')
        stage.unitsMove([
            [
                stage.unit(15),
                35,
                48,
                1],
            [
                stage.unit(7),
                49,
                54,
                2]])
        stage.unit(15).setAction(0)
        stage.unit(7).setAction(0)
        stage.say('&0\n장 장군님, 드디어 오셨군요!\n허저 이미 너에 대해 말해줬어.\n&0\n다시 묻겠습니다,\n내 팀에 합류할래?')
        stage.unit(7).setAction(6)
        stage.say('&7\n저는 이미 총리님을 섬기기로 결정했습니다.')
        stage.unit(7).setAction(0)
        stage.delay(3)
        stage.unit(15).setAction(3)
        stage.say('&15\n그럼 우리 동료야!?')
        stage.unit(15).setAction(0)
        stage.delay(3)
        stage.unit(7).setAction(0, 3)
        stage.say('&7\n그때 허저 장군은 공로를 주장하기 위해 나를 죽일 수도 있었다,\n하지만 그는 나를 보내줬어.\n&7\n그의 충성에 보답하기 위해,\n그게 내가 할 수 있는 전부야.')
        stage.unit(7).setAction(0, 2)
        stage.delay(3)
        stage.unit(7).setAction(6)
        stage.say('&7\n재상님, 저는 덕도 능력도 없장합,\n제가 채찍을 잡아주고 계단을 들어 올릴게요.')
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n아, 정말 잘 말씀하셨네요!\n정말 빛나길 바래.')
        stage.unit(0).setAction(0)
        stage.say('&7\n네.')
        stage.unit(7).setAction(0)
        stage.say('&0\n허저, 잘했어.')
        stage.unit(15).setAction(3)
        stage.say('&15\n하하하.')
        stage.unit(15).setAction(0)
        stage.unit(7).move(49, 42, 0)
        stage.unit(7).move(35, 42, 1)
        model.setFace(0)
        model.unitJoin(7, 0, 0)
        if vars[1013]:
            gvars[0] = 7
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
    stage.bgSound(-1)
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.delay(10)
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n보고해!')
    stage.unit(181).move(49, 26, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 원소 전략가가 감옥에서 발견되었다.\n&0\n원소 전략가?\n이름이 뭐야?\n&181\n그의 이름은 저수였다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n저수!?')
    stage.unit(0).setAction(0)
    stage.say('&0\n그가 감옥에 갇혔다고 들었어......\n&0\n좋아! 그를 여기로 데려와... 예의를 지켜.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.delay(10)
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n주군, 저수 씨도 데려와.\n&0\n음, 수고하셨습니다.')
    stage.unit(181).move(49, 22, 2)
    stage.showUnit(105, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            48,
            2],
        [
            stage.unit(105),
            49,
            42,
            2]])
    stage.say('&105\n응?')
    stage.unit(105).setAction(0, 3)
    stage.effectSound(208, 255)
    stage.bgSound(13)
    stage.delay(3)
    stage.say('&7\n저수 미스터 ......\n&105\n장합, 조조 군대에 합류하는 거냐?\n&7\n네......\n&105\n정말......')
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(181),
            49,
            54,
            2],
        [
            stage.unit(105),
            49,
            48,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(181),
            45,
            54,
            3],
        [
            stage.unit(105),
            49,
            54,
            2]])
    stage.delay(1)
    stage.unit(181).setAction(0, 2)
    stage.say('&0\n저수, 네가 자원이 풍부하다고 들었어.')
    stage.unit(0).setAction(3)
    stage.say('&0\n어때? 장 장군과 함께 나를 섬기겠다고?')
    stage.unit(0).setAction(0)
    stage.say('&105\n………。')
    stage.unit(0).setAction(3)
    stage.say('&0\n어때?\n&105\n…… 조 재상께 답변드립니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n응?\n&105\n관두 전투 전에 나는 밤에 천상현상을 관찰했다,\n그들은 쉬두 위에 빛나는 별을 발견했다.\n&105\n그게 네 별이야,\n바로 황제의 별이었다.......')
    stage.unit(105).setAction(3)
    stage.say('&105\n조 총리님, 당신은 세상을 통일할 수 있는 분입니다.')
    stage.unit(105).setAction(0, 2)
    stage.delay(3)
    stage.unit(105).setAction(0, 0)
    stage.delay(3)
    stage.say('&105\n게다가 ...원소주군의 별빛은 점점 약해지고 있다,\n곧이어 그는 세상을 떠나려 했다.\n&0\n저수, 그렇다면,\n당신은 나를 섬기고 있습니다.')
    stage.unit(105).setAction(0, 2)
    stage.say('&105\n아니요, 조 재상님.\n&105\n원소주군의 주인공 옆에,\n내 빛나는 별도 끝나가고 있어.')
    stage.unit(105).setAction(6)
    stage.say('&105\n나는 원소주군와 함께 사라질 것이다,\n이것은 변할 수 없는 운명이다.')
    stage.unit(105).setAction(0)
    stage.delay(3)
    stage.unit(7).move(49, 42, 1)
    stage.delay(1)
    stage.unit(7).setAction(0, 2)
    stage.say('&7\n저수 씨, 당신은 .......')
    stage.delay(3)
    stage.unit(105).setAction(0, 0)
    stage.say('&105\n장 장군님, 당신의 별이 점점 더 밝아지고 있습니다.\n&105\n총리를 섬겨야 합니다,\n당신의 별은 계속 밝게 남을 것입니다.\n&7\n저수 미스터 ......\n&20\n저수 씨, 자신의 지혜를 사용할 의향이 있나요?\n그냥 아무 이유 없이 사라지는 건가요?\n정말 안타깝지 않나요......')
    stage.unit(105).setAction(0, 1)
    stage.say('&105\n당신이 문약 씨 맞죠?\n당신의 위대한 명성은 오래전부터 들었습니다.\n&105\n너는 왕을 도울 재능이 있고, 황제를 도울 수 있다,\n하지만 나는 그런 능력이 없다.\n&20\n저수 미스터 ......\n&0\n저수, 무슨 일이 있어도......\n아직도 나를 섬기려 하지 않아?')
    stage.unit(105).setAction(0, 2)
    stage.say('&105\n조 총리님, 저는 항상 하늘의 명령을 따르는 사람입니다,\n그러므로 나는 원소주군를 위해 죽을 것이다.')
    stage.unit(105).setAction(6)
    stage.say('&105\n어서! 제발 목을 베어줘!\n&0\n…… 좋아.\n나는 네가 원하는 대로야.\n&0\n…… 저수 처형장으로 데려가라.\n&181\n네.')
    stage.unit(181).setAction(0, 1)
    stage.delay(3)
    stage.unit(105).setAction(0)
    stage.say('&0\n저수, 내가 네 가족을 돌볼게.\n&105\n감사합니다, 총장님.')
    stage.unitsMove([
        [
            stage.unit(105),
            49,
            50,
            0],
        [
            stage.unit(181),
            49,
            54,
            1]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(7),
            41,
            42,
            3],
        [
            stage.unit(105),
            49,
            42,
            0],
        [
            stage.unit(181),
            49,
            46,
            0]])
    stage.delay(1)
    stage.unit(7).setAction(0, 1)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(105),
            49,
            16,
            0],
        [
            stage.unit(181),
            49,
            20,
            0]])
    stage.delay(1)
    stage.unit(7).setAction(0, 0)
    stage.delay(3)
    stage.unit(105).hide()
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.delay(10)
    stage.say('&0\n운명일까......?')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 72)
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.showUnits([
        [
            101,
            70,
            98],
        [
            113,
            66,
            98],
        [
            102,
            74,
            98]])
    stage.setStageName('교외 근처의 관두, 강가 해변')
    stage.unitsMove([
        [
            stage.unit(113),
            66,
            88,
            0],
        [
            stage.unit(102),
            74,
            88,
            0]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(101),
            70,
            60,
            0],
        [
            stage.unit(113),
            66,
            50,
            0],
        [
            stage.unit(102),
            74,
            50,
            0]])
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n내 군대......\n그렇게 거대한 군대가 실제로 패배했다!')
    stage.unit(102).setAction(0, 2)
    stage.delay(3)
    stage.unit(113).setAction(0, 2)
    stage.say('&113\n아버지, 과거는 지나갔어요,\n내 리양 시로 가자.\n거기가 더 안전해.')
    stage.unit(101).setAction(0)
    stage.say('&101\n흠, 흠......\n&101\n천펑이 옳았던 것 같다,\n그때 내가 그의 말을 들었더라면,\n오늘의 패배는 없었을 것이다.\n&102\n주군, 천펑도 그렇게 생각했다.\n&101\n무슨 ......?\n&102\n전투에서 졌다는 것을 알주군,\n그는 매우 자랑스러워할 것이다.\n&101\n음, 정말 .......')
    stage.unit(101).setAction(2)
    stage.say('&101\n봉기, 저 사람 좀 내려줘!\n그를 이 세상에 살게 둘 수 없어!\n&102\n네!\n바로 처리할게.')
    stage.unit(113).setAction(3)
    stage.say('&113\n아버지, 제발 빨리 이곳을 떠나 주세요.')
    stage.unit(113).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0)
    stage.say('&101\n흠..........')
    stage.unitsMove([
        [
            stage.unit(101),
            70,
            14,
            0],
        [
            stage.unit(113),
            66,
            14,
            0],
        [
            stage.unit(102),
            74,
            14,
            0]])
    stage.unit(101).hide()
    stage.unit(113).hide()
    stage.unit(102).hide()
    stage.effectSound(208, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 338, 124)
    stage.showHead(101, 338, 44)
    stage.bottomTxt('원소 관두에서 패배했고 조조 패배했다,', False, False, False)
    stage.delay(5)
    stage.head(101).move(306, 30)
    stage.delay(5)
    stage.bottomTxt('그는 잔여 세력을 이끌고 리양으로 후퇴했다.', True, False, False)
    stage.delay(8)
    stage.showHead(110, 370, 12)
    stage.delay(5)
    stage.bottomTxt('처음에 예시에 왔을 때, 그는 조심스럽게 반응했다,', True, True, False)
    stage.delay(5)
    stage.head(110).hide()
    stage.delay(5)
    stage.bottomTxt('원소를 조언했던 전략가 천펑은 참수당했다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene2():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            101,
            53,
            28,
            2],
        [
            113,
            68,
            48,
            3],
        [
            114,
            68,
            54,
            3],
        [
            115,
            68,
            60,
            3],
        [
            106,
            38,
            48,
            1],
        [
            103,
            38,
            54,
            1],
        [
            102,
            38,
            60,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('리양 원소 저택')
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n그는 조조를 그렇게 쉽게 놓아줄 수 없었다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n다시 싸우고 싶조조,\n무슨 일이 있어도 반드시 승리를 거둬야 해!')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(114).setAction(0, 0)
    stage.say('&114\n하지만 아버지...... 우리 병력 규모가 ......\n대부분의 손실은 이미 관두에서 잃었다.')
    stage.unit(113).setAction(0, 2)
    stage.delay(3)
    stage.unit(113).setAction(2, 2)
    stage.say('&113\n무슨 소리야? 둘째 형.\n위대한 적 앞에서 어떻게 그렇게 낙담시키는 말을 할 수 있어!!')
    stage.unit(113).setAction(0, 2)
    stage.delay(3)
    stage.unit(103).setAction(6)
    stage.say('&103\n실제로 승패는 병력 수로 결정되지 않습니다.\n그는 정말 우리 장남이 될 자격이 son원담!')
    stage.unit(103).setAction(0)
    stage.say('&102\n(궈투는 원담를 아부하는 법을 안다!) )\n&106\n(내 주군이 죽으면,\n궈투는 원담의 신뢰받는 신임 측근이었다,\n그는 분명히 큰 권력을 가질 것이다. )')
    stage.unit(114).setAction(0, 3)
    stage.unit(113).setAction(0, 3)
    stage.say('&101\n흠... 하지만......\n소수로 다수를 이기는 것은 진정한 .......의 행동이 아니다')
    stage.unit(113).setAction(3)
    stage.say('&113\n하지만 아버지 ......!')
    stage.unit(113).setAction(0)
    stage.delay(3)
    stage.unit(115).setAction(0, 0)
    stage.say('&115\n아버지, 군사력에 대해 걱정하지 않으셔도 됩니다.\n&101\n무슨 뜻이야?\n&115\n다시 싸우기 위해서조조,\n나는 이미 허베이 군대를 리양에 집결시켰다.\n&115\n병력 면에서는 여전히 상당한 우위를 아군 있었다.')
    stage.unit(113).setAction(0, 2)
    stage.say('&113\n원상, 허락 없이 군대를 모으고 있느냐?\n&115\n형과 ...... 이야기할 시간이 없었기 때문이다.')
    stage.unit(113).setAction(2)
    stage.say('&113\n닥쳐! 넌 나를 진지하게 안 받아들이잖아.\n너무 부주의했어!\n&101\n좋아!\n원담, 좋은 생각이야.')
    stage.unit(113).setAction(0)
    stage.delay(3)
    stage.unit(113).setAction(0, 3)
    stage.unit(115).setAction(0, 3)
    stage.say('&101\n선부, 잘했어.\n그래서 내 아들이구나.\n&102\n네.\n젊은 주인의 지혜와 전략은 정말 존경스럽습니다.\n&106\n네. 이기고 싶다면,\n병력이 너무 적을 수는 없었다.')
    stage.say('&103\n음 음 ..........')
    stage.say('&101\n좋아! 선사, 선의, 선부.\n각자 내려가서 전투 준비를 해야 해!')
    stage.unit(101).setAction(17)
    stage.say('&101\n결정적인 전투는 창팅에서 벌어졌다.\n창팅에서 조조를 이기고 싶다!')
    stage.unit(101).setAction(0)
    stage.say('&113\n네.\n&114\n네.\n&115\n네.')
    stage.unitsMove([
        [
            stage.unit(113),
            68,
            98,
            2],
        [
            stage.unit(114),
            68,
            98,
            2],
        [
            stage.unit(115),
            68,
            98,
            2]])
    stage.unit(113).hide()
    stage.unit(114).hide()
    stage.unit(115).hide()
    stage.say('&101\n흠.........\n&101\n무모하고 용감한 마음가짐과 비교하면,\n선부가 내 .......를 물려받기에 더 적합할지도 몰라요')
    stage.unit(103).setAction(6)
    stage.say('&103\n하지만, 주군......\n장남이 위대한 사업을 물려받는 것은 당연한 일입니다원담......')
    stage.unit(103).setAction(0)
    stage.delay(3)
    stage.unit(106).setAction(0, 2)
    stage.say('&106\n곽투는 위대한 사업을 물려받기 위해 통치자의 자질을 갖추어야 한다.')
    stage.unit(102).setAction(0, 0)
    stage.say('&102\n네, 네.\n용기만이 나라의 지배자가 될 수 없습니다.')
    stage.say('&103\n뭐라고? 뭐라고 했어......!')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 338, 124)
    stage.showHead(101, 306, 30)
    stage.bottomTxt('원소 관두에서의 패배의 수치를 씻어내기 위해,', False, False, False)
    stage.delay(5)
    stage.head(101).move(380, 34)
    stage.delay(8)
    stage.bottomTxt('그는 병력을 재편성하여 창팅에 주둔시켰다.', True, False, False)
    stage.delay(8)
    stage.head(0).move(380, 114)
    stage.delay(8)
    stage.bottomTxt('원의 움직임을 알게 된 조의 군대는 즉시 전투에 돌입했다.', True, True, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            7,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('캉팅 조조 주 진영')
    stage.delay(3)
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n주군, 그는 첩보 장교로부터 보고를 받았다,\n천펑은 원소에게 참수당했다.\n&0\n천풍이 처형당했다고?\n&0\n그는 실제로 지혜로운 사람을 직접 죽였다,\n원소 아이는 정말 눈이 멀었어요.')
    stage.unit(21).setAction(0, 2)
    stage.say('&21\n더불어, 상속권을 위한 싸움에서,\n전략가들은 두 파벌로 나뉘었다.')
    stage.unit(0).setAction(3)
    stage.say('하하하. 매우 어리석습니다!\n원소가 무엇을 생각하고 있는 것인가요?\n시기도 고려하지 않는군요?')
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n보고해.')
    stage.unit(181).move(49, 26, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 위안의 군대가 곧 출발하려 하고 있었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n알겠습니다.\n원소 나랑 죽을 때까지 싸울 계획이야......')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군, 부주의하지 마.\n비록 아군 세 번이나 원소을 이겼지만,\n하지만 상대편은 여전히 어느 정도 힘을 가지고 있었다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n알아.\n걱정할 필요 없어.')
    stage.unit(22).setAction(6)
    stage.say('&22\n원소 이전의 참담한 패배를 부끄러워하며,\n이번에는 죽음을 다짐하며 이기겠다는 결심을 해야 한다.\n적과 정면으로 맞서는 것은 최선의 전략이 아닐 가능성이 큽니다.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('맞아요……. 좋아요, 우리가 그에게 한 번 지는 걸로 합시다!')
    stage.unit(1).setAction(3)
    stage.say('&1\n뭐라고...... 뭐라고!?')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n물론, 그에게 지고 싶지 않아,\n그는 단지 스포트라이트를 피하고 싶었을 뿐이었다.')
    stage.unit(1).setAction(0)
    stage.say('&1\n그래서 일부러 후퇴할 계획이야?\n정말 교활하구나, 전처럼 말이야.\n원소 놀리고 싶으면 you맹덕지 마.\n&0\n맞아.\n그리고 군대 전체에 명령을 내렸다.\n빨리 가!\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).move(49, 16, 0)
    stage.unit(181).hide()
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.unit(22).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 13, [
        21,
        15,
        7])
    gvars[4076] = 0
    gvars[4057] = 19
    stage.setBattlePos([
        [
            8,
            32],
        [
            9,
            32],
        [
            7,
            32],
        [
            7,
            10],
        [
            12,
            14],
        [
            7,
            19],
        [
            11,
            24],
        [
            6,
            25],
        [
            7,
            11],
        [
            12,
            15],
        [
            7,
            20],
        [
            11,
            25],
        [
            6,
            26],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(21):
        stage.say('&21\n주군, 계획이 있어.\n&0\n응? 무슨 전략이야, 중더?\n&21\n네.\n장군허저 이렇게 두세요......\n&0\n하하하.\n좋아, 허저, 네가 결정해!\n&15\n어!? 뭐...... 무슨 일이야?')
    if stage.unitClickTest(7):
        stage.say('&7\n과거의 주군과 싸워야 한다 해도......\n&7\n이 시점에서 나는 더 이상 혼란스럽지 않았다.')
    if stage.unitClickTest(22):
        stage.say('&22\n장 장군은 궁수와 기병 부대 출신이었다......\n우리가 믿을 수 있는 새로운 전투력이다.\n&0\n흠, 장 장군, 훌륭한 성과를 내시길 바랍니다.\n&7\n그래! 지켜봐.')
    if stage.unitClickTest(20):
        stage.say('&20\n창팅 전장은 산악 속의 좁은 계곡이었다.\n여기가 주 전장입니다.')
    if stage.unitClickTest(15):
        stage.say('&0\n허저, 이번 작전에서 네가 주도해야 해.\n&15\n네!\n좋네요.')
    if stage.unitClickTest(1):
        stage.say('&1\n방금 장합 말하는 걸 들었어,\n원소의 장남들과 막내아들이 상속권을 두고 다투었다.\n&0\n장남과 막내아들?\n알고 보니 세 형제였다......\n둘째 아들은 어때?')
        stage.unit(7).setAction(0, 2)
        stage.say('&7\n둘째 아들은 너무 온순원희......\n&0\n정말?\n지나치게 온화한 통치자,\n그들은 이 혼란스러운 시대에 살아남을 수 없다.')
        stage.unit(7).setAction(0, 1)
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
