# Source Generated with Decompyle++
# File: S_36.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22], [
        '(5,19)',
        '(7,16)',
        '(9,21)'])
    stage.nearEvent([
        0,
        35,
        0,
        32], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 5, 'y': 19, 'dir': 1, 'lv': 6, 'i': 0},
         {'id': 210, 'x': 5, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 1},
         {'id': 211, 'x': 6, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 2},
         {'id': 234, 'x': 4, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 3},
         {'id': 235, 'x': 5, 'y': 20, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 32, 'x': 9, 'y': 21, 'dir': 1, 'lv': 6, 'i': 5},
         {'id': 33, 'x': 10, 'y': 22, 'dir': 1, 'lv': 6, 'ai': 0, 'i': 6},
         {'id': 36, 'x': 8, 'y': 21, 'dir': 1, 'lv': 6, 'ai': 0, 'i': 7},
         {'id': 258, 'x': 8, 'y': 20, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 282, 'x': 9, 'y': 22, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 45, 'x': 7, 'y': 16, 'dir': 1, 'lv': 4, 'i': 10},
         {'id': 38, 'x': 7, 'y': 17, 'dir': 1, 'lv': 4, 'ai': 0, 'i': 11},
         {'id': 390, 'x': 6, 'y': 15, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 383, 'x': 8, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 382, 'x': 6, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 14},
         {'id': 70, 'x': 12, 'y': 18, 'dir': 1, 'lv': 4, 'ai': 0, 'i': 15},
         {'id': 212, 'x': 11, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 16},
         {'id': 213, 'x': 13, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 17},
         {'id': 236, 'x': 11, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 18},
         {'id': 237, 'x': 12, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 19},
         {'id': 65, 'x': 9, 'y': 13, 'dir': 1, 'lv': 4, 'ai': 0, 'i': 20},
         {'id': 214, 'x': 8, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 21},
         {'id': 215, 'x': 10, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 22},
         {'id': 238, 'x': 8, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 23},
         {'id': 239, 'x': 9, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 24},
         {'id': 34, 'hide': 1, 'x': 9, 'y': 1, 'lv': 6, 'ai': 1, 'i': 25},
         {'id': 318, 'hide': 1, 'x': 9, 'y': 2, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 319, 'hide': 1, 'x': 10, 'y': 1, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 216, 'x': 9, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 217, 'x': 10, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 218, 'x': 12, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 219, 'x': 13, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 31},
         {'id': 350, 'x': 4, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 32},
         {'id': 334, 'x': 6, 'y': 20, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 33},
         {'id': 391, 'x': 7, 'y': 15, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 34},
         {'id': 392, 'x': 8, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 35},
         {'id': 259, 'x': 9, 'y': 20, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 36},
         {'id': 260, 'x': 10, 'y': 21, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 37}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 26,
            'y': 2,
            'dir': 3 },
        {
            'idx': 1,
            'x': 25,
            'y': 2,
            'dir': 3 },
        {
            'idx': 2,
            'x': 26,
            'y': 3,
            'dir': 3 },
        {
            'idx': 3,
            'x': 23,
            'y': 7,
            'dir': 3 },
        {
            'idx': 4,
            'x': 22,
            'y': 6,
            'dir': 3 },
        {
            'idx': 5,
            'x': 23,
            'y': 6,
            'dir': 3 },
        {
            'idx': 6,
            'x': 24,
            'y': 7,
            'dir': 3 },
        {
            'idx': 7,
            'x': 22,
            'y': 5,
            'dir': 3 },
        {
            'idx': 8,
            'x': 22,
            'y': 3,
            'dir': 3 },
        {
            'idx': 9,
            'x': 21,
            'y': 2,
            'dir': 3 },
        {
            'idx': 10,
            'x': 22,
            'y': 2,
            'dir': 3 },
        {
            'idx': 11,
            'x': 23,
            'y': 3,
            'dir': 3 },
        {
            'idx': 12,
            'x': 21,
            'y': 1,
            'dir': 3 },
        {
            'idx': 13,
            'x': 27,
            'y': 3,
            'dir': 3 },
        {
            'idx': 14,
            'x': 25,
            'y': 1,
            'dir': 3 }])
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(36)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(1)
    stage.unit(0).setDir(stage.countDir(0, 35))
    stage.say('&0\n슈 군대가 강가로 뒤로 진형을 세웠다고!?\n이 사람은 공명What 생각하는 거지?\n함정? 아니, 아마 그냥 confuse아군......')
    stage.unit(15).setDir(stage.countDir(15, 0))
    stage.say('&15\n주군, 아무리 생각해도 소용없어,\n매복에서 두려워할 게 뭐가 있겠어?\n앞으로 나아가자!\n&0\n흠, 매복을 피할 수만 있다면,\n이 진형제갈량 후퇴할 곳이 없고,\n오히려 아군에게 큰 기회를 주었다.')
    stage.unit(0).setAction(5)
    stage.say('좋습니다. 전력을 진격합니다!\n모두가 함정군에 유의해야 합니다,\n절대 소홀히 해서는 안 됩니다!')
    stage.unit(0).setAction(0)
    stage.unit(4, 1).move(20, 8, 3)
    stage.unit(3, 1).move(21, 9, 3)
    stage.unit(7, 1).move(20, 7, 3)
    stage.unit(5, 1).move(21, 8, 3)
    stage.unit(6, 1).move(22, 9, 3)
    stage.unit(9, 1).move(19, 4, 3)
    stage.unit(8, 1).move(20, 5, 3)
    stage.unit(12, 1).move(19, 3, 3)
    stage.unit(10, 1).move(20, 4, 3)
    stage.unit(11, 1).move(21, 5, 3)
    stage.unit(1, 1).move(23, 4, 3)
    stage.unit(2, 1).move(24, 5, 3)
    stage.unit(14, 1).move(23, 3, 3)
    stage.unit(0, 1).move(24, 4, 3)
    stage.unit(13, 1).move(25, 5, 3)
    stage.effectSound(20, 1)
    stage.info('쾅. 쨍.', 3)
    stage.delay(10)
    stage.unit(15).setAction(10)
    stage.say('&15\n와, 무슨 일이야? 기습 공격이야!?\n이-......징 소리가 도대체 뭐야!?\n&0\n모든 병력 대기 중! 경계!\n또 공명 계획이야!?\n이번에는 무슨 생각을 하는 거지?')
    stage.unit(15).setDir(stage.countDir(15, 0))
    stage.say('&15\n어-어떡하지?')
    stage.unit(0).setDir(stage.countDir(0, 15))
    stage.say('적이 북을 울리는 걸 보니 이곳에 분명 매복병이 있다는 뜻이야... 불리한 지형에서 진을 짜는 건, 우리를 유인하려는 거야. 하지만... 왜 일부러 우리가 매복병이 있다는 걸 알게 하는 거지...? 내 생각엔 조심스럽게만 하면 큰 문제는 없을 것 같은데. 공명, 네 작은 계책으로 나를 퇴각시키려고?')
    stage.unit(33).setDir(stage.countDir(33, 0))
    stage.unit(32).setDir(stage.countDir(32, 0))
    stage.unit(38).setDir(stage.countDir(38, 0))
    stage.say('&33\n하하하!\n모두 당황했다......\n정말 흥미롭네요!\n&32\n그래서 훌륭한 공명 전략인 것도 당연합니다,\n적은 이미 함정에 빠져 있었다.\n조운 잘했어요.\n&38\n여기 지형은 끝없이 펼쳐진 언덕들이고,\n징 소리는 자연스럽게 깊게 울려 퍼진다.')
    stage.unit(36).setDir(stage.countDir(36, 35))
    stage.say('&36\n그래서, 공명 선생님.\n이제 어떻게 해야 하지?\n그들은 그냥 기다리지 않을 거예요.')
    stage.unit(35).setDir(stage.countDir(35, 36))
    stage.say('&35\n흠, 장군님, 여기서 관찰하셔도 됩니다,\n모든 게 계획대로 진행되고 있어.\n&36\n!?')
    stage.effectSound(20, 1)
    stage.info('쾅. 쨍.', 3)
    stage.delay(10)
    stage.say('&0\n안 돼! 이대로 가다간,\n병사들의 집중력이 흐트러질 거야.')
    stage.setUnitStatus([
        {
            'status': 1,
            'lift': 0,
            'x1': 0,
            'y1': 0,
            'x2': 27,
            'y2': 27,
            'camp': 0 }])
    stage.say('&0\n징 소리의 출처를 알 수 있다면 정말 좋겠어요......\n하지만 지금, 적의 거대한 군대와 마주하며,\n매복을 찾기 위해 병력을 분산시킬 수 없었다......\n&15\n마치 공명 함정에 빠진 것 같은 기분입니다.\n&0\n젠장공명!')
    stage.unit(65).setDir(stage.countDir(65, 35))
    stage.unit(70).setDir(stage.countDir(70, 35))
    stage.unit(45).setDir(stage.countDir(45, 35))
    stage.say('&65\n공명 씨, 이제 공격해도 되나요?\n이제 적의 사기가 흔들렸다,\n우리가 이길 가능성이 높다고 믿습니다......\n&70\n공명Mr. 나도 그렇게 생각해.\n다른 걱정거리가 있나요?')
    stage.unit(35).setDir(stage.countDir(35, 70))
    stage.unit(35).setAction(5)
    stage.say('&35\n성급하거나 성급하게 행동해서는 안 됩니다,\n무모하게 행동하는 자는 군법에 따라 처벌할 것이다!')
    stage.unit(35).setAction(0)
    stage.say('&45\n공명 씨가 그렇게 말했으니까......\n&65\n(흥!\n이 아이공명What 정확히 무슨 계획을 세우고 있는 거야?" )')
    stage.bgSound(4)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    vars[536] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 12:
        stage.resumeCtrl()
        stage.unit(0).setAction(5)
        stage.say('&0\n어떻게 감히 후퇴할 곳도 없는 절박한 진형을 세울 수 있단 말인가?\n계속 공격해! 전부 전멸시적군!')
        stage.unit(0).setAction(0)
        stage.talk(197, 197, '주군, 끔찍한 일이 일어났어!')
        stage.say('&0\n왜 당황해야 ......!?')
        stage.talk(197, 197, '나, 아군.........\n아군의 곡물 창고가 공격당했어!')
        stage.unit(0).setAction(10)
        stage.say('&0\n뭐-뭐라고!?\n아니, 알고 보니 공명 시간을 벌기 위한 거였어!\n사실 저는 전혀 눈치채지 못했어요......')
        stage.talk(186, 186, '주군, 어떻게 해야 하지?')
        stage.say('물론 즉시 돌아가 구원해야 합니다! 시간이 될지 안 될지는 모르지만, 이곳에 오래 머무는 것은 좋지 않습니다!')
        stage.unit(0).setAction(5)
        stage.say('&0\n전군을 후퇴시켜라!')
        stage.unit(0).setAction(0)
        stage.setRectUnitHide(0, 0, 27, 27, 0)
        if not vars[51]:
            stage.say('&32\n공명 덕분에,\n또 이겼today조조......')
        if not vars[50]:
            stage.say('&35\n하하하!\n예상대로였어요.\n하하하!')
        vars[11] = 1
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[636] = 1
        return True
    if not vars[12] and not vars[30] and stage.round() == 3:
        stage.effectSound(20, 1)
        stage.info('쾅. 쨍.', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('&0\n진정해!\n징 소리에 속지 마!')
        vars[12] = 1
    if not vars[13] and not vars[30] and stage.round() == 5:
        stage.effectSound(20, 1)
        stage.info('맞아, 맞아', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('&0\n메아리가 너무 컸다—매복은 정확히 어디에 있었던 걸까?\n지금은 얼마나 많은 병력을 매복하고 있을지 누가 알겠습니까,\n어떻게 해야 할까요......')
        vars[13] = 1
    if not vars[14] and not vars[30] and stage.round() == 7:
        stage.effectSound(20, 1)
        stage.info('맞아, 맞아', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('매복병은 대체 언제 나타나는 건가요?')
        vars[14] = 1
    if not vars[15] and not vars[30] and stage.round() == 9:
        stage.effectSound(20, 1)
        stage.info('맞아, 맞아', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('적군이 그저 북만 울릴 뿐, 공격할 기미가 없어 보이는데. 혹시 매복 병력이 적은 건가?')
        vars[15] = 1
    if not vars[16] and not vars[30] and stage.round() == 11:
        stage.effectSound(20, 1)
        stage.info('맞아, 맞아', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('&0\n그냥 징 소리 같아,\n공명의 목적은 정확히 무엇일까요?')
        vars[16] = 1
    if not vars[17] and not vars[30] and stage.round() == 13:
        stage.effectSound(20, 1)
        stage.info('맞아, 맞아', 3)
        stage.delay(10)
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'hp': -1,
                'mp': -1,
                'x1': 0,
                'y1': 0,
                'x2': 27,
                'y2': 27,
                'camp': 0 }])
        stage.say('&0\n사기를 꺾기 위한 것일까요?\n음, 공명한테 놀림 당했어!')
        vars[17] = 1
    if not vars[20] and stage.isInPos(1025, 5, 19):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 7, 16):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 9, 21):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[6] and stage.totalUnit(2) >= 8 and stage.totalUnit(0) < 9:
        stage.say("&0\n음음 음 .........\n이 '강으로 돌아가는 대형'만으로도 가능하다.\n이런 상황을 다루기가 매우 어려워집니다......\n&0\n이런 상황이 계속된다면,\n아군 불필요한 희생만 초래할 뿐입니다......\n후퇴해서 재정비해야 할까?")
        sel = stage.choice('전체 군대가 후퇴했다\n계속 싸워', -1)
        if sel == 1:
            stage.resumeCtrl()
            stage.unit(0).setAction(5)
            stage.say('&0\n다른 방법이 없으니 오늘은 여기서 끝내자.\n전군을 후퇴시켜라!')
            stage.unit(0).setAction(0)
            stage.talk(197, 197, '주군, 끔찍한 일이 일어났어!')
            stage.say('&0\n왜 당황해야 ......!?')
            stage.talk(197, 197, '나, 아군.........\n아군의 곡물 창고가 공격당했어!')
            stage.unit(0).setAction(10)
            stage.say('&0\n뭐-뭐라고!?\n아니, 알고 보니 공명 시간을 벌기 위한 거였어!\n사실 저는 전혀 눈치채지 못했어요......')
            stage.talk(186, 186, '주군, 어떻게 해야 하지?')
            stage.say('물론 즉시 돌아가 구원해야 합니다! 시간이 될지 안 될지는 모르지만, 이곳에 오래 머무는 것은 좋지 않습니다!')
            stage.setRectUnitHide(0, 0, 27, 27, 0)
            if not vars[51]:
                stage.say('&32\n공명 덕분에,\n또 이겼today조조......')
            if not vars[50]:
                stage.say('&35\n하하하!\n예상대로였어요.\n하하하!')
            vars[11] = 1
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[636] = 1
            return True
        if sel == 2:
            stage.say('안 돼! 계속 버텨야 해. 이렇게 후퇴할 수는 없어!')
        vars[6] = 1
    if not vars[7] and not vars[50] and not vars[55] and stage.curCamp() == 2 and stage.totalRectUnit(2, 9, 0, 27, 20) < 8:
        stage.unit(35).setDir(stage.countDir(35, 45))
        stage.unit(35).setAction(5)
        stage.say('&35\n류펑, 전투에 나가라!\n조조 군대가 숨 돌릴 틈도 주지 마라!')
        stage.unit(35).setAction(0)
        if not vars[56]:
            stage.unit(38).setDir(stage.countDir(38, 45))
            stage.say('&38\n빨리! 병력을 보내라!')
        stage.unit(45).setDir(stage.countDir(45, 38))
        stage.say('&45\n맞아, 맞아.\n좋아, 군대 전체가 전투 준비 완료.\n조의 군대를 전파하라!')
        stage.unit(45).setAI(1)
        stage.unit(38).setAI(1)
        stage.unit(390).setAI(1)
        stage.unit(391).setAI(1)
        stage.unit(392).setAI(1)
        stage.unit(382).setAI(1)
        stage.unit(383).setAI(1)
        vars[7] = 1
    if not vars[8] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.totalRectUnit(2, 6, 0, 27, 19) < 8:
        stage.unit(35).setDir(stage.countDir(35, 32))
        stage.say('&35\n그럼 함께 싸우주군 합류합시다!')
        stage.unit(32).setDir(stage.countDir(32, 35))
        stage.unit(32).setAction(5)
        stage.say('&32\n물론이죠!\n가자, 조조 목숨을 가져가자!')
        stage.unit(32).setAction(0)
        if not vars[52]:
            stage.unit(33).setDir(stage.countDir(33, 0))
            stage.unit(33).setAction(7)
            stage.say('&33\n좋네요! 오랫동안 가려웠어요!')
            stage.unit(33).setAction(0)
        if not vars[54]:
            stage.unit(36).setDir(stage.countDir(36, 32))
            stage.say('&36\n나도 보여줄게.')
        stage.unit(32).setAI(1)
        stage.unit(33).setAI(1)
        stage.unit(36).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(282).setAI(1)
        vars[8] = 1
    if not vars[9] and not vars[50] and stage.totalUnit(2) < 9 and stage.curCamp() == 2:
        stage.say('&35\n그럼 나도 싸우러 갈게.')
        stage.unit(35).setAI(1)
        stage.unit(350).setAI(1)
        stage.unit(334).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[9] = 1
    if not vars[30] and stage.isInRect(1025, 7, 0, 11, 4):
        stage.unit(34).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.unit(0).setDir(stage.countDir(0, 34))
        stage.say('&34\n흠, 걸렸다고?\n&0\n이 소수의 인력으로,\n나도 겁주고 싶어!?\n정말 말도 안 돼요!\n&34\n조조! 공명 씨의 영리한 계획 이전에,\n넌 그냥 무지한 아이일 뿐이야!')
        vars[30] = 1
    if not vars[31] and not vars[32] and not vars[50] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 9, 13, 27):
        stage.say('&35\n선봉대는 조의 군대를 막았다.\n조운 시간을 벌어!')
        if not vars[58]:
            stage.say('&65\n네! (시간 벌기? 날 과소평가하는 거야. )')
        if not vars[57]:
            stage.say('&70\n내가 무너지는 걸 지켜봐적군!')
        stage.unit(65).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[31] = 1
    if not vars[31] and not vars[32] and not vars[50] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 14, 16, 27):
        stage.say('&35\n알겠습니다! 소규모 부대를 보내 조의 군대를 묶어라!')
        if not vars[58]:
            stage.say('&65\n네! (소규모 그룹? 날 과소평가하는 거야. )')
        if not vars[57]:
            stage.say('&70\n내가 무너지는 걸 지켜봐적군!')
        stage.unit(65).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[32] = 1
    if not vars[40] and stage.isNear(0, 35, True):
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&0\n공명, 네 뛰어난 전략을 정말 존경해,\n비록 네 함정에 빠졌지만,\n화가 난 기분이라기보다는 감탄에 가깝습니다.\n&35\n적과 대화하고 웃을 기분이 전혀 없어요.\n&0\n꽤 위압적이네요, 그렇죠?\n하지만 네 계획은 여기서 끝이야,\n지금도 사용할 수 있는 트릭이 있는지 보고 싶어.\n&35\n정말 그렇게 생각해?')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 32, True):
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&32\n한때 동탁를 비난했던 이들이 함께 모였다,\n이제 남은 건 너랑 나뿐이야.\n&0\n이는 혼돈의 시대가 끝나가고 있음을 증명합니다,\n우리 둘 중 누구일지\n이 혼란스러운 세상에 평화를 가져올 수 있는 사람은 누구일까요?\n&32\n처음 만났을 때부터,\n우리는 어떤 운명을 공유한다고 느껴,\n오늘 여기서 싸울 줄은 몰랐다......\n&0\n하하하!\n전쟁은 아직 끝나지 않았다,\n아직 슬퍼하기엔 너무 이르다.')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n이제 시간을 벌었으니,\n내가 여기 없어도 괜찮을 거야.\n후퇴!')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n이것이 공명의 기발한 계획이니,\n후퇴도 예상되었다.\n이 순간, 싸움이나 후퇴를 강요할 필요가 없었다!')
        stage.unit(32).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n아파, 이 빌어먹을 녀석아!\n쳇! 나 지금 간다!\n이걸 기억하세요!')
        stage.unit(33).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n저는 이미 공명 씨의 지시에 따라 행동했습니다.\n새로운 지시가 다음 단계로 들어오지 않았기 때문에,\n일단 후퇴하자.')
        stage.unit(34).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(36, 7, 0, 2):
        stage.say('&36\n알고 보니 젊은 세대 사이에서,\n그런 사람이라니!\n하지만 오늘은 먼저 후퇴하는 것밖에 선택하지 않는다!')
        stage.unit(36).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(45, 7, 0, 2):
        stage.say('&45\n대부님, 죄송합니다.\n후퇴!')
        stage.unit(45).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(38, 7, 0, 2):
        stage.say('&38\n내가 너무 부주의했어......\n거짓말 아니에요......')
        stage.unit(38).hide(2)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(70, 7, 0, 2):
        stage.say('&70\n공명 씨, 정말 부끄럽습니다......\n장이가 먼저 물러났다.')
        stage.unit(70).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(65, 7, 0, 2):
        stage.say('&65\n정말 어리석은 계획이야!\n차라리 집에 가는 게 낫겠다.\n다시 만날 때까지!')
        stage.unit(65).hide(1)
        vars[58] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.talk(186, 186, '주군, 이미 적군 없애버렸어!')
        stage.say('&0\n자, 아군 이겼어!\n공명의 계획은 결국 무너졌다......\n그래도 좀 걱정됐어, 응......')
        stage.talk(197, 197, '주군, 끔찍한 일이 일어났어!')
        stage.say('&0\n왜 당황해야 ......!?')
        stage.talk(197, 197, '나, 아군.........\n아군의 곡물 창고가 공격당했어!')
        stage.say('&0\n뭐-뭐라고!?\n아니야! 알고 보니 공명 그냥 시간을 벌기 위한 거였어!\n사실 못 봤어...... 젠장, 공명!')
        stage.talk(186, 186, '주군, 어떻게 해야 하지?')
        stage.say('물론 즉시 돌아가 구원해야 합니다! 하지만…… 시간이 부족할 것 같군요. 이번에는 또 저 빌어먹을 공명에게 속았어요!')
        stage.setRectUnitHide(0, 0, 27, 27, 0)
        stage.reward(0, [
            116,
            -1])
        stage.end()
        vars[0] = 1
        vars[636] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비군 앞에서 큰 패배를 당하고 후퇴했다')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
