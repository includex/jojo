# Source Generated with Decompyle++
# File: S_56.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(28,6)',
        '(13,29)'])
    stage.nearEvent([
        0,
        69,
        0,
        57,
        0,
        34], 1)
    stage.initFight()
    stage.setGlobalData(40, -2, -1, 0, 2, 4)
    stage.createEnemy(
        [{'id': 35, 'x': 28, 'y': 5, 'lv': 6, 'i': 0},
         {'id': 69, 'x': 28, 'y': 6, 'lv': 6, 'i': 1},
         {'id': 334, 'x': 27, 'y': 6, 'lv': 0, 'i': 2},
         {'id': 335, 'x': 29, 'y': 6, 'lv': 0, 'i': 3},
         {'id': 298, 'x': 24, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 299, 'x': 24, 'y': 14, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 300, 'x': 24, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 301, 'x': 32, 'y': 12, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 302, 'x': 32, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 303, 'x': 32, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 210, 'x': 27, 'y': 12, 'lv': 0, 'i': 10},
         {'id': 211, 'x': 28, 'y': 12, 'lv': 0, 'i': 11},
         {'id': 212, 'x': 29, 'y': 12, 'lv': 0, 'i': 12},
         {'id': 213, 'x': 27, 'y': 11, 'lv': 0, 'i': 13},
         {'id': 214, 'x': 28, 'y': 11, 'lv': 0, 'i': 14},
         {'id': 215, 'x': 29, 'y': 11, 'lv': 0, 'i': 15},
         {'id': 234, 'x': 27, 'y': 10, 'lv': 0, 'i': 16},
         {'id': 235, 'x': 28, 'y': 10, 'lv': 0, 'i': 17},
         {'id': 236, 'x': 29, 'y': 10, 'lv': 0, 'i': 18},
         {'id': 37, 'x': 28, 'y': 17, 'lv': 6, 'i': 19},
         {'id': 34, 'x': 28, 'y': 16, 'lv': 6, 'i': 20},
         {'id': 36, 'x': 28, 'y': 15, 'lv': 6, 'i': 21},
         {'id': 258, 'x': 27, 'y': 17, 'lv': 0, 'i': 22},
         {'id': 259, 'x': 29, 'y': 17, 'lv': 0, 'i': 23},
         {'id': 260, 'x': 27, 'y': 16, 'lv': 0, 'i': 24},
         {'id': 261, 'x': 29, 'y': 16, 'lv': 0, 'i': 25},
         {'id': 282, 'x': 27, 'y': 15, 'lv': 0, 'i': 26},
         {'id': 283, 'x': 29, 'y': 15, 'lv': 0, 'i': 27},
         {'id': 57, 'x': 28, 'y': 20, 'lv': 6, 'i': 28},
         {'id': 58, 'x': 28, 'y': 21, 'lv': 6, 'i': 29},
         {'id': 462, 'x': 27, 'y': 22, 'lv': 0, 'i': 30},
         {'id': 463, 'x': 28, 'y': 22, 'lv': 0, 'i': 31},
         {'id': 464, 'x': 29, 'y': 22, 'lv': 0, 'i': 32},
         {'id': 465, 'x': 27, 'y': 21, 'lv': 0, 'i': 33},
         {'id': 466, 'x': 29, 'y': 21, 'lv': 0, 'i': 34},
         {'id': 467, 'x': 27, 'y': 20, 'lv': 0, 'i': 35},
         {'id': 468, 'x': 29, 'y': 20, 'lv': 0, 'i': 36},
         {'id': 358, 'x': 21, 'y': 35, 'dir': 3, 'lv': 0, 'i': 37},
         {'id': 359, 'x': 22, 'y': 34, 'dir': 3, 'lv': 0, 'i': 38},
         {'id': 360, 'x': 22, 'y': 36, 'dir': 3, 'lv': 0, 'i': 39},
         {'id': 361, 'x': 23, 'y': 34, 'dir': 3, 'lv': 0, 'i': 40},
         {'id': 362, 'x': 23, 'y': 36, 'dir': 3, 'lv': 0, 'i': 41},
         {'id': 310, 'x': 21, 'y': 34, 'dir': 3, 'lv': 0, 'i': 42},
         {'id': 311, 'x': 21, 'y': 36, 'dir': 3, 'lv': 0, 'i': 43},
         {'id': 342, 'x': 22, 'y': 35, 'dir': 3, 'lv': 0, 'i': 44},
         {'id': 343, 'x': 23, 'y': 35, 'dir': 3, 'lv': 0, 'i': 45},
         {'id': 71, 'hide': 1, 'x': 0, 'y': 18, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 46},
         {'id': 72, 'hide': 1, 'x': 0, 'y': 14, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 47},
         {'id': 390, 'hide': 1, 'x': 1, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 48},
         {'id': 391, 'hide': 1, 'x': 1, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 49},
         {'id': 392, 'hide': 1, 'x': 1, 'y': 15, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 50},
         {'id': 382, 'hide': 1, 'x': 1, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 51},
         {'id': 383, 'hide': 1, 'x': 1, 'y': 18, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 52},
         {'id': 384, 'hide': 1, 'x': 1, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 350, 'hide': 1, 'x': 0, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 73, 'hide': 1, 'x': 12, 'y': 23, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 55},
         {'id': 318, 'hide': 1, 'x': 11, 'y': 22, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 56},
         {'id': 319, 'hide': 1, 'x': 11, 'y': 23, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 320, 'hide': 1, 'x': 12, 'y': 24, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 58},
         {'id': 321, 'hide': 1, 'x': 5, 'y': 24, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 59},
         {'id': 322, 'hide': 1, 'x': 6, 'y': 25, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 60},
         {'id': 323, 'hide': 1, 'x': 7, 'y': 26, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 61},
         {'id': 351, 'hide': 1, 'x': 12, 'y': 22, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 62},
         {'id': 352, 'hide': 1, 'x': 6, 'y': 26, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 63},
         {'id': 414, 'hide': 1, 'x': 27, 'y': 8, 'lv': 0, 'ai': 1, 'i': 64},
         {'id': 415, 'hide': 1, 'x': 28, 'y': 8, 'lv': 0, 'ai': 1, 'i': 65},
         {'id': 416, 'hide': 1, 'x': 29, 'y': 8, 'lv': 0, 'ai': 1, 'i': 66},
         {'id': 417, 'hide': 1, 'x': 28, 'y': 7, 'lv': 0, 'ai': 1, 'i': 67},
         {'id': 216, 'x': 2, 'y': 14, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 68},
         {'id': 217, 'x': 4, 'y': 14, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 69},
         {'id': 218, 'x': 6, 'y': 13, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 70},
         {'id': 237, 'x': 3, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 71},
         {'id': 238, 'x': 5, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 72},
         {'id': 219, 'x': 13, 'y': 29, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 73},
         {'id': 220, 'x': 11, 'y': 30, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 74},
         {'id': 221, 'x': 14, 'y': 27, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 75},
         {'id': 239, 'x': 13, 'y': 31, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 76},
         {'id': 240, 'x': 15, 'y': 29, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 77}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 4,
            'y': 6 },
        {
            'idx': 1,
            'x': 3,
            'y': 6 },
        {
            'idx': 2,
            'x': 5,
            'y': 6 },
        {
            'idx': 3,
            'x': 2,
            'y': 6 },
        {
            'idx': 4,
            'x': 4,
            'y': 5 },
        {
            'idx': 5,
            'x': 3,
            'y': 5 },
        {
            'idx': 6,
            'x': 5,
            'y': 5 },
        {
            'idx': 7,
            'x': 2,
            'y': 5 },
        {
            'idx': 8,
            'x': 4,
            'y': 4 },
        {
            'idx': 9,
            'x': 3,
            'y': 4 },
        {
            'idx': 10,
            'x': 5,
            'y': 4 },
        {
            'idx': 11,
            'x': 2,
            'y': 4 },
        {
            'idx': 12,
            'x': 4,
            'y': 3 },
        {
            'idx': 13,
            'x': 3,
            'y': 3 },
        {
            'idx': 14,
            'x': 5,
            'y': 3 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.loadBg(56)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab24')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab24')
    stage.draw()
    stage.bgSound(10)
    stage.unit(35).setDir(stage.countDir(35, 69))
    stage.unit(69).setDir(stage.countDir(69, 35))
    stage.say('&35\n장웨이, 지하 제단은 이미 지어졌지?\n&69\n그래, 장웨이는 이미 직접 조사했다.\n모든 것은 총리의 지시에 따라 완료되었다.')
    stage.unit(35).move(28, 3, 2)
    stage.unit(69).move(28, 4, 2)
    stage.unit(35).setDir(stage.countDir(35, 69))
    stage.unit(69).setDir(stage.countDir(69, 35))
    stage.say('&35\n그래서 바로 지하로 잠수할게.\n절대 조의 군대가 가까이 오지 못하게 하라.\n&69\n네!\n이제부터는 장웨이가 이 일을 처리할 것이다.')
    stage.unit(35).setDir(0)
    stage.say('&35\n(마왕의 신력이 마침내 깨어나려 한다.)\n하하하! )')
    stage.unit(35).hide()
    stage.unit(69).move(28, 6, 2)
    stage.unit(69).setAction(5)
    stage.say('&69\n전 군대가 조조의 공격을 막기 위해 전투 준비를 했다.\n절대 지하 제단에 접근하지 못하게 해!')
    stage.unit(69).setAction(0)
    stage.unit(0).setDir(stage.countDir(0, 69))
    stage.unit(0).setAction(5)
    stage.say('&0\n마왕은 쉬서의 계략으로 부활할 수 없으니,\n이제 슈 군대는 더 이상 두려워할 존재가 아니야!\n전체 군대가 전진하라!')
    stage.unit(0).setAction(0)
    stage.unit(0).setDir(2)
    stage.say('(……날씨가 지독해서 역겹군. 마왕이 다시 살아나진 않았지만, 공명이 있는 한…… 설마 정말로 속전속결을 할 수 없는 건가?)')
    stage.setWinCondition('승리 조건\n1. 장위를 물리치라.\n\n패배 조건\n1. 조조 죽음.\n2. 40턴을 초과한다.')
    stage.showWinCondition('장웨이를 물리쳐라!')
    stage.unit(69).heightLight()
    stage.startOper()
    vars[556] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[36] and not vars[70] and stage.round() == 4:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[70] = 1
    if vars[36] and not vars[71] and stage.round() == 7:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[71] = 1
    if vars[36] and not vars[72] and stage.round() == 10:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[72] = 1
    if vars[36] and not vars[73] and stage.round() == 13:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[73] = 1
    if vars[36] and not vars[74] and stage.round() == 16:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[74] = 1
    if vars[36] and not vars[75] and stage.round() == 19:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[75] = 1
    if vars[36] and not vars[76] and stage.round() == 22:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[76] = 1
    if vars[36] and not vars[77] and stage.round() == 25:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[77] = 1
    if vars[36] and not vars[78] and stage.round() == 28:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[78] = 1
    if vars[36] and not vars[79] and stage.round() == 31:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[79] = 1
    if vars[36] and not vars[80] and stage.round() == 34:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[80] = 1
    if vars[36] and not vars[81] and stage.round() == 37:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[81] = 1
    if vars[36] and not vars[82] and stage.round() == 40:
        if not vars[51]:
            stage.unit(414).show(27, 8, 2)
            stage.unit(415).show(28, 8, 2)
            stage.unit(416).show(29, 8, 2)
            stage.unit(417).show(28, 7, 2)
        vars[82] = 1
    if not vars[20] and stage.isInPos(1025, 28, 6):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 13, 29):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[31] and not vars[32] and stage.isInRect(1025, 5, 20, 15, 32) and stage.curCamp() == 2:
        stage.unit(73).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(351).show()
        stage.unit(321).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(352).show()
        stage.say('&73\n어서! 충전해!\n잠깐, 이렇게 돌진해도 괜찮은 거야?\n&73\n아, 다들 어디 갔지?\n장웨이가 여기서 기다리면 그를 만날 수 있다고 하지 않았나?\n&0\n흥, 이 매복 부대를 두려워할 게 뭐가 있겠어!')
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(384).show()
        stage.unit(72).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(392).show()
        stage.unit(350).show()
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.say('&71\n전에 말하지 않았나? 길을 안내할 인도자가 없다,\n북쪽으로 산길을 어떻게 걷는지 전혀 모르겠어요!\n우리가 어디에 왔는지 누가 알겠어?\n&72\n이거 조조 아니야?\n여기서 만나는 것은 정말 행운입니다.\n아주머니, 잠깐만 그와 놀아줘요!\n&71\n뭐라고?\n어떻게 여기까지 오게 된 거지?\n왜 그렇게 기뻐?\n&72\n뭘 두려워하는 거야!\n여러분, 힘내세요!\n&0\n이로 인해 사방에서 포위당하지 않을까?\n이 녀석들은 정말 타이밍이 안 좋았어!')
        vars[31] = 1
    if not vars[31] and not vars[32] and stage.isInRect(1025, 13, 9, 23, 17) and stage.curCamp() == 2:
        stage.unit(73).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(351).show()
        stage.unit(321).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(352).show()
        stage.say('&73\n한숨, 모두와 떨어지는 건 한 가지 문제야,\n지금은 조조의 군대조차 보이지 않았다.\n내가 뭘 해야 하지?')
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(384).show()
        stage.unit(72).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(392).show()
        stage.unit(350).show()
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.say('&71\n전에 말하지 않았나? 길을 안내할 인도자가 없다,\n북쪽으로 산길을 어떻게 걷는지 전혀 모르겠어요!\n우리가 어디에 왔는지 누가 알겠어?\n&72\n조금 이상하게 느껴지긴 하네요.\n빨리 따라와!')
        vars[32] = 1
    if not vars[33] and stage.curCamp() == 2 and stage.isInRect(1025, 17, 25, 39, 39):
        if not vars[51] and stage.totalRectUnit(2, 21, 34, 23, 36) >= 5:
            stage.unit(69).setDir(stage.countDir(69, 342))
            stage.unit(69).setAction(5)
            stage.say('&69\n조의 군대가 가까이 오지 못하게 해!\n해군이 조의 군대를 가로막았다.')
            stage.unit(69).setAction(0)
        stage.setAI(21, 34, 23, 36, 2, 1)
        vars[33] = 1
    if not vars[34] and stage.curCamp() == 2 and stage.isInRect(1025, 22, 25, 34, 31):
        if not vars[56]:
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(57).setAction(5)
            stage.say('&57\n이번에는 조조 늙은 도둑을 처리해야 해.\n마초 가서 싸워!')
            stage.unit(57).setAction(0)
        stage.setAI(27, 20, 29, 22, 2, 1)
        vars[34] = 1
    if not vars[35] and stage.curCamp() == 2 and stage.isInRect(1025, 25, 19, 31, 24):
        if not vars[58]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.unit(34).setAction(5)
            stage.say('&34\n나도 싸움에 합류할게!')
            stage.unit(34).setAction(0)
        stage.setAI(27, 15, 29, 17, 2, 1)
        vars[35] = 1
    if not vars[36] and stage.totalRectUnit(0, 27, 13, 29, 23) >= 1 and stage.curCamp() == 2 and stage.totalRectUnit(2, 27, 13, 29, 23) < 4:
        if not vars[51]:
            stage.unit(69).setDir(stage.countDir(69, 0))
            stage.unit(69).setAction(5)
            stage.say('&69\n응, 응,\n다른 방법이 없어......\n나무 조각상에서 나와서 나를 위해 조조를 죽여라!')
            stage.unit(69).setAction(0)
            stage.unit(414).show()
            stage.unit(415).show()
            stage.unit(416).show()
            stage.unit(417).show()
        stage.setAI(0, 0, 39, 39, 2, 1)
        stage.unit(69).setAI(2)
        vars[36] = 1
    if not vars[40] and stage.isNear(0, 69, True):
        stage.unit(0).setDir(stage.countDir(0, 69))
        stage.unit(69).setDir(stage.countDir(69, 0))
        stage.say('&0\n장웨이, 빨리 공명 위치를 말해.\n&69\n두 군대가 서로 맞서면서 어떻게 지휘관을 배신할 수 있겠는가?\n알고 싶으면 나를 죽여라, 장웨이부터 죽여!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&57\n이번에는...... 이번에는 널 죽일 거야.\n&0\n마초Oh, 마초, 넌 여전히 충동적이구나.\n마텅, 네가 이렇게 된 걸 보니, 걱정돼.\n그들은 사후 세계에서도 상심할 것이다.\n&57\n헛소리 그만해!\n만약 마멍기가 아버지의 적을 직접 죽일 수 있다면,\n돌아가신 아버지는 기쁨만을 알았다. 어떻게 슬픔이 있을 수 있겠는가!\n&0\n마텡과 나는 무슨 일이 일어나고 있는지 알고 있었다,\n이 믿음으로 그는 혼란스러운 시기를 헤쳐 나갔다,\n그는 개인적인 원한과 패권을 혼동하지 않았다.\n&57\n음......\n&0\n만약 당신이 슈의 장군으로서 혼란스러운 세상을 염두에 두는 법을 안다면,\n세상을 먼저 생각한다면, 다시 나를 찾아와.\n그때가 오면, 나는 자연스럽게 너와 마주할 것이다.\n&57\n…………')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 34, True):
        stage.unit(0).setDir(stage.countDir(0, 34))
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.say('&0\n자룡, 너도 점점 눈치채기 시작했겠지......\n공명의 행동은 슈의 관심사와 맞지 않는가?\n&34\n군 장군으로서 나는 전장에서만 싸울 줄 안다,\n그는 몇 가지 아이디어가 떠올랐다.\n&0\n이제 상황은 이미 끝났고, 슈에게는 미래가 없었다.\n&34\n아마도 슈는 왕국을 통일할 수 없을지도 모른다,\n하지만 나는 슈와 함께 살고 죽을 각오가 되어 조운.\n&0\n쯔롱 ......')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n지하 제단으로 급히 가야 해......')
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(69, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&69\n와아! 내 인생은 끝났어......\n&69\n그리고 전 군대에 명령을 내렸다......\n모두 슈 영토로 후퇴했다.\n방어를 강화하고 무적으로 만들며, 국가 전력을 회복하라......\n&69\n누구든 간에, 나를 지켜줘... 슈... 국가 ......')
        stage.unit(69).hide(2)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[51] = 1
        if not vars[52]:
            stage.say('&71\n음, 더 이상 싸울 수 없어.\n나는 진심으로 슈에게 자비를 베풀었어!\n차라리 남쪽 나라로 돌아가는 게 낫겠어.')
        if not vars[56]:
            stage.say('&57\n다 끝난 거야?\n이제는 개인적인 원한에 집착할 때가 아닌 것 같습니다.\n&57\n지금은 슈로 돌아가 추가 계획을 세우는 게 낫다.\n후퇴!')
        if not vars[58]:
            stage.say('&34\n장웨이 장군도 전사했나요?\n어떻게 마지막 군주 류산을 외면할 수 있겠는가?\n청두로 철수해 방어를 강화하라.')
        if not vars[59]:
            stage.say('&36\n혼란스러운 시대가 끝나가는 것 같습니다.\n더 이상 노인이 자신의 기술을 쓸 자리가 없었다.\n왜 은퇴하고 집으로 돌아가지 않나요!')
        stage.setRectUnitHide(0, 0, 39, 39, 5)
        stage.say('&0\n슈 군대는 저항할 의사가 전혀 없었던 것 같다.\n빨리 찾아공명!\n호랑이가 산으로 돌아오지 못하게 하라.')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[656] = 1
        return True
    if not vars[52] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n너무 아파요!\n정말 이 저주받은 곳에서 죽고 싶지 않아,\n내 남쪽 나라로 돌아가는 게 낫겠어!')
        stage.unit(71).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n더는 못 참겠어.\n나 먼저 갈게!')
        stage.unit(73).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n그럼 여기서 멈추자.\n오늘은 정말 즐거웠어요,\n이모가 정말 만족하셔. 안녕!')
        stage.unit(72).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n한계에 다다랐어!\n공명, 네가 만든 난장판은 네가 직접 치워야 해!\n나 이제 슈로 돌아갈게.')
        stage.unit(37).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n후회!\n내 힘이 아직 부족한 걸까?\n슈로 돌아온 후 계획을 세우기에 늦지 않았다. 후퇴!')
        stage.unit(57).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n나는 무력했다.\n서군 병사들은 거의 고갈되어 있었다.\n더 이상 쓸데없는 희생을 할 수 없습니다. 후퇴!')
        stage.unit(58).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n이제 위나라에 대한 승리는 손에 닿지 않는 듯하다,\n하지만 나는 반드시 슈를 지킬 거야.\n슈로 철수하라!')
        stage.unit(34).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(36, 7, 0, 2):
        stage.say('&36\n내가 정말 나이 든 걸까?\n차라리 사임하고 은퇴하는 게 낫다.')
        stage.unit(36).hide(1)
        vars[59] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n슈 군대는 저항할 의사가 전혀 없었던 것 같다.\n빨리 찾아공명!\n호랑이가 산으로 돌아오지 못하게 하라.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[656] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 패배하고 후퇴했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
