# Source Generated with Decompyle++
# File: S_47.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        0,
        76,
        3,
        83,
        3,
        76,
        3,
        0,
        3,
        87], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 33,
            'x': 12,
            'y': 16,
            'dir': 3,
            'lv': 6,
            'i': 0 },
        {
            'id': 46,
            'x': 12,
            'y': 15,
            'dir': 3,
            'lv': 6,
            'i': 1 },
        {
            'id': 53,
            'x': 15,
            'y': 12,
            'dir': 0,
            'lv': 6,
            'i': 2 },
        {
            'id': 66,
            'x': 16,
            'y': 12,
            'dir': 0,
            'lv': 6,
            'i': 3 },
        {
            'id': 47,
            'x': 15,
            'y': 19,
            'lv': 6,
            'i': 4 },
        {
            'id': 44,
            'x': 19,
            'y': 15,
            'dir': 1,
            'lv': 4,
            'i': 5 },
        {
            'id': 51,
            'x': 16,
            'y': 16,
            'lv': 4,
            'i': 6 },
        {
            'id': 210,
            'x': 15,
            'y': 15,
            'lv': 0,
            'i': 7 },
        {
            'id': 242,
            'x': 15,
            'y': 16,
            'lv': 0,
            'i': 8 },
        {
            'id': 342,
            'x': 16,
            'y': 15,
            'lv': 0,
            'i': 9 },
        {
            'id': 3,
            'hide': 1,
            'x': 1,
            'y': 5,
            'dir': 1,
            'lv': 6,
            'ai': 4,
            'targetX': 16,
            'targetY': 16,
            'i': 10 },
        {
            'id': 211,
            'x': 19,
            'y': 16,
            'dir': 1,
            'lv': 0,
            'i': 11 },
        {
            'id': 212,
            'x': 16,
            'y': 19,
            'lv': 0,
            'i': 12 }])
    stage.createEnemy(
        [{'id': 76, 'x': 15, 'y': 22, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 80, 'x': 16, 'y': 22, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 358, 'x': 14, 'y': 22, 'dir': 0, 'lv': 0, 'i': 2},
         {'id': 359, 'x': 17, 'y': 22, 'dir': 0, 'lv': 0, 'i': 3},
         {'id': 360, 'x': 14, 'y': 23, 'dir': 0, 'lv': 0, 'i': 4},
         {'id': 361, 'x': 17, 'y': 23, 'dir': 0, 'lv': 0, 'i': 5},
         {'id': 234, 'x': 15, 'y': 23, 'dir': 0, 'lv': 0, 'i': 6},
         {'id': 235, 'x': 16, 'y': 23, 'dir': 0, 'lv': 0, 'i': 7},
         {'id': 79, 'x': 22, 'y': 15, 'dir': 3, 'lv': 6, 'i': 8},
         {'id': 86, 'x': 22, 'y': 16, 'dir': 3, 'lv': 6, 'i': 9},
         {'id': 362, 'x': 22, 'y': 14, 'dir': 3, 'lv': 0, 'i': 10},
         {'id': 363, 'x': 22, 'y': 17, 'dir': 3, 'lv': 0, 'i': 11},
         {'id': 364, 'x': 23, 'y': 14, 'dir': 3, 'lv': 0, 'i': 12},
         {'id': 365, 'x': 23, 'y': 17, 'dir': 3, 'lv': 0, 'i': 13},
         {'id': 236, 'x': 23, 'y': 15, 'dir': 3, 'lv': 0, 'i': 14},
         {'id': 237, 'x': 23, 'y': 16, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 82, 'x': 15, 'y': 9, 'lv': 4, 'i': 16},
         {'id': 87, 'x': 16, 'y': 9, 'lv': 4, 'i': 17},
         {'id': 366, 'x': 14, 'y': 9, 'lv': 0, 'i': 18},
         {'id': 367, 'x': 17, 'y': 9, 'lv': 0, 'i': 19},
         {'id': 368, 'x': 14, 'y': 8, 'lv': 0, 'i': 20},
         {'id': 369, 'x': 17, 'y': 8, 'lv': 0, 'i': 21},
         {'id': 238, 'x': 15, 'y': 8, 'lv': 0, 'i': 22},
         {'id': 239, 'x': 16, 'y': 8, 'lv': 0, 'i': 23},
         {'id': 83, 'x': 9, 'y': 15, 'dir': 1, 'lv': 4, 'i': 24},
         {'id': 96, 'x': 9, 'y': 16, 'dir': 1, 'lv': 4, 'i': 25},
         {'id': 370, 'x': 9, 'y': 14, 'dir': 1, 'lv': 0, 'i': 26},
         {'id': 371, 'x': 9, 'y': 17, 'dir': 1, 'lv': 0, 'i': 27},
         {'id': 372, 'x': 8, 'y': 14, 'dir': 1, 'lv': 0, 'i': 28},
         {'id': 373, 'x': 8, 'y': 17, 'dir': 1, 'lv': 0, 'i': 29},
         {'id': 240, 'x': 8, 'y': 15, 'dir': 1, 'lv': 0, 'i': 30},
         {'id': 241, 'x': 8, 'y': 16, 'dir': 1, 'lv': 0, 'i': 31}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 20,
            'y': 2,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 1,
            'x': 21,
            'y': 3,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 2,
            'x': 19,
            'y': 1,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 3,
            'x': 21,
            'y': 2,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 4,
            'x': 20,
            'y': 1,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 5,
            'x': 21,
            'y': 1,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 6,
            'x': 22,
            'y': 2,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 7,
            'x': 20,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 8,
            'x': 22,
            'y': 1,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 9,
            'x': 21,
            'dir': 3,
            'hide': 1 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(51, -1, 0, -1, 0, 11)
    stage.loadBg(47)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab29')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab29')
    stage.draw()
    stage.bgSound(6)
    stage.unit(47).setDir(stage.countDir(47, 44))
    stage.say('&47\n우리는 심하게 포위당했습니다.')
    stage.unit(44).setDir(stage.countDir(44, 47))
    stage.say('&44\n하아, 회복이 불가능한 걸까?')
    stage.unit(51).setDir(stage.countDir(51, 44))
    stage.say('&51\n그러나 우리는 헛된 희생을 할 수 없다,\n우리는 그들에게 우리의 결의를 보여줘야 합니다!')
    stage.unit(33).setDir(stage.countDir(33, 51))
    stage.unit(33).setAction(5)
    stage.say('&33\n개자식!\n어떻게 죽을 수 있지?\n살아남아야 해!')
    stage.unit(33).setAction(0)
    stage.unit(76).setDir(stage.countDir(76, 80))
    stage.say('&76\n완전히 포위된 것 같아.')
    stage.unit(80).setDir(stage.countDir(80, 76))
    stage.say('&80\n적군 이미 병에 갇힌 거북이였다.\n하지만 속담에 있듯이, "개가 궁지에 몰리면 벽을 뛰어넘는다."\n절대 부주의하지 마세요!')
    stage.unit(79).setDir(stage.countDir(79, 33))
    stage.say('&79\n도대체 무슨 생각공명 거야?\n왜 우리는 위험에 처한 주군 가만히 지켜보며 돕지 않는 걸까요?')
    stage.unit(86).setDir(stage.countDir(86, 79))
    stage.say('&86\n아마도 권력에 대한 욕망이 작용하는 것일지도 모릅니다!\n하하하.')
    stage.unit(79).setDir(stage.countDir(79, 86))
    stage.unit(79).setAction(5)
    stage.say('&35\n공명 그런 사람이 절대 아니에요!\n하지만 지금 이데는 절박한 상황에 갇혀 있다,\n그럼에도 그는 무관심했는데, 그것이 정말 의아했다.')
    stage.unit(79).setAction(0)
    stage.unit(3).show()
    stage.unit(3).setDir(stage.countDir(3, 33))
    stage.say('&3\n이데!\n괜찮아?\n바로 구하러 갈게!')
    stage.unit(33).setDir(stage.countDir(33, 3))
    stage.unit(46).setDir(stage.countDir(46, 3))
    stage.say('&33\n2. 둘째 형님!?\n어떻게 ...... 알게 됐어?\n&3\n바로 갈게!\n이렇게 작은 진형은 금방 처리할 수 있어!')
    stage.unit(3).move(3, 5, 1)
    stage.unit(33).setAction(10)
    stage.say('&33\n둘째 형, 소용없어!')
    stage.unit(76).setDir(stage.countDir(76, 3))
    stage.unit(76).setAction(5)
    stage.say('&76\n응? 관우?\n혼자 도우러 가는 것은 전략 없이 정말 대담한 행동입니다!\n관우 죽여줘, 여기 오지 못하게 해!')
    stage.unit(76).setAction(0)
    stage.unit(53).move(14, 11, 3)
    stage.unit(53).setDir(stage.countDir(53, 3))
    stage.say('&53\n아버지가 아무리 용감해도 이건 안 될 거야!\n적군 행동하기 전에,\n안전한 곳으로 탈출하라......')
    stage.unit(82).move(14, 10, 2)
    stage.say('&82\n기회다!')
    stage.attackAction(82, 53, 1)
    stage.delay(10)
    stage.unit(53).setAction(4)
    stage.setUnitStatus([
        {
            'hp': -500,
            'unit': stage.unit(53) }])
    stage.say('&53\n오, 안 돼!')
    stage.unit(66).setDir(stage.countDir(66, 53))
    stage.unit(66).setAction(10)
    stage.unit(66).move(15, 11, 3)
    stage.say('&66\n관, 관성!\n힘내세요!')
    stage.unit(87).move(16, 11, 3)
    stage.unit(87).setDir(stage.countDir(87, 66))
    stage.say('&87\n너도 결점이 많아!\n칼 조심해!')
    stage.attackAction(87, 66, 1)
    stage.delay(10)
    stage.setUnitStatus([
        {
            'hp': -500,
            'unit': stage.unit(66) }])
    stage.unit(66).setAction(4)
    stage.say('&66\n음!\n계산 착오!')
    stage.say('&53\n관수오, 여기서 탈출할 방법을 찾아.\n&66\n그래서 다른 선택지가 없었다......')
    stage.unit(53).hide(1)
    stage.unit(66).hide(1)
    stage.unit(3).setDir(stage.countDir(3, 87))
    stage.unit(3).setAction(4)
    stage.say('&3\n아, 관싱! 관소오!\n혐오스러운 동우!')
    stage.unit(3).move(5, 6, 1)
    stage.say('&46\n아-더 가까이 오지 마!\n아버지, 충동적으로 굴지 마세요.\n우리 생각은 잊어버려......')
    stage.unit(83).move(10, 15, 1)
    stage.unit(83).setDir(stage.countDir(83, 46))
    stage.say('&83\n어디 보고 있어!\n내 화살을 받아라!')
    stage.attackAction(83, 46, 1)
    stage.delay(10)
    stage.setUnitStatus([
        {
            'hp': -500,
            'unit': stage.unit(46) }])
    stage.unit(46).setAction(4)
    stage.say('&46\n와!')
    stage.unit(33).setDir(stage.countDir(33, 46))
    stage.say('&33\n관평!\n이 짐승아!')
    stage.unit(33).move(10, 16, 0)
    stage.unit(96).setDir(stage.countDir(96, 33))
    stage.say('&96\n싸움은 단 한 사람과 싸우는 것이 아닙니다.\n네 쪽은 결점투성이야!\n이걸 받아라!')
    stage.attackAction(96, 33, 1)
    stage.delay(10)
    stage.setUnitStatus([
        {
            'hp': -500,
            'unit': stage.unit(33) }])
    stage.unit(33).setAction(4)
    stage.say('&33\n아니, 그럴 줄은 몰랐어......\n숨을 곳만 찾으면 돼...... 음음!')
    stage.unit(46).hide(1)
    stage.unit(33).hide(1)
    stage.unit(3).setDir(stage.countDir(3, 96))
    stage.unit(3).setAction(4)
    stage.say('&3\n장비!\n관평!')
    stage.bgSound(5)
    stage.unit(0, 1).show()
    stage.unit(1, 1).show()
    stage.unit(2, 1).show()
    stage.unit(3, 1).show()
    stage.unit(4, 1).show()
    stage.unit(5, 1).show()
    stage.unit(6, 1).show()
    stage.unit(7, 1).show()
    stage.unit(8, 1).show()
    stage.unit(9, 1).show()
    stage.unit(0).setDir(stage.countDir(0, 3))
    stage.say('&0\n관우 안전한 것 같아,\n우리는 그를 빨리 데리고 나가야 했어요.\n&0\n하지만 그렇게 되면 아군 마이청을 잃게 될 거야.\n어떻게 공명와 결탁한 오나라 군대가 이곳을 점령하도록 내버려 둘 수 있겠는가?\n&0\n관우와 마이청.........\n어느 쪽을 먼저 저장해야 할까요......')
    sel = stage.choice('구조 관우\n마이청을 구출하러', -1)
    if sel == 1:
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(0).setAction(5)
        stage.say('&0\n먼저 관우 구해!\n우리는 유비의 마지막 말을 지켜야 해.\n전 군대를 전투에 동원하라!')
        stage.unit(0).setAction(0)
        stage.unit(0).setDir(stage.countDir(0, 47))
        stage.say('&0\n유비Ah, 나는 먼저 마이청을 포기할 수밖에 없어!\n지금 가장 중요한 것은 어떻게 살아남느냐입니다.\n조조 마지막 말을 따라 유비 구조를 시작할 거야!')
        stage.unit(47).setDir(stage.countDir(47, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&47\n마지막 말이라고?! 도대체 무슨 일이 있었던 거야?\n왜 조조의 군대가 우리를 구하러 왔을까?\n&44\n불분명하지만, 아마 주군 조조와 비밀 협약이 있었던 것 같다,\n힘을 합쳐서 손권군을 당분간 무찌르자!')
        stage.unit(51).setDir(stage.countDir(51, 3))
        stage.unit(51).setAction(5)
        stage.say('&51\n마이청을 빼앗기게 둘 수 없어!\n우리는 장군 관우을 보호해야 한다,\n앞으로의 도전을 극복하세요.')
        stage.unit(51).setAction(0)
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(76).setAction(5)
        stage.say('&76\n뭐라고!? 왜 조나라 군대가 서 군대를 돕러 왔을까?\n응, 전 군대가 조의 군대와 맞설 준비가 됐어!\n다 부숴버려!')
        stage.unit(76).setAction(0)
        stage.setAI(8, 8, 23, 19, 2, 3, 3, 0, 0)
        stage.setAI(8, 20, 23, 23, 2, 6, -1, 6, 15)
        stage.setAI(12, 12, 19, 19, 1, 6, -1, 12, 15)
        stage.unit(3).setAI(4, -1, 7, 10)
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 또는 관우 사망.\n2. 턴 수가 25명을 초과한다.')
        stage.showWinCondition('구조 관우!')
        stage.unit(3).heightLight()
    elif sel == 2:
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(0).setAction(5)
        stage.say('&0\n관우 무술 면에서는,\n이 적들은 두려워할 수 없습니다.\n먼저 마이청을 붙잡아야 해!')
        stage.unit(0).setAction(0)
        stage.unit(47).setDir(stage.countDir(47, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&47\n뭐라고?\n조나라 군대가 실제로 우리를 구하러 왔다고?\n&44\n잘 모르겠지만, 어쨌든 하늘에 감사해야 해요!\n첫째, 손권군을 격퇴하기 위해 힘을 합친 후,\n분명히 물어보유비주군.')
        stage.unit(51).setDir(stage.countDir(51, 76))
        stage.unit(51).setAction(5)
        stage.say('&51\n좋아, 손권 군대를 전력으로 공격해라.')
        stage.unit(51).setAction(0)
        stage.unit(47).setDir(2)
        stage.unit(44).setDir(1)
        stage.unit(76).setDir(stage.countDir(76, 96))
        stage.say('&76\n왜 조나라 군대가 슈 군대를 돕기 위해 왔나요?\n딩펑, 쉬셩, 판장!\n가서 죽여관우!')
        stage.unit(76).setDir(stage.countDir(76, 87))
        stage.say('&76\n장친, 가서 조조 막아!\n이 기회를 잡아 마이청을 잡아라!')
        stage.setAI(8, 8, 23, 23, 2, 3, 3, 0, 0)
        stage.setAI(12, 12, 19, 19, 1, 2)
        stage.unit(3).setAI(4, -1, 7, 10)
        stage.unit(87).setAI(3, 0, 0, 0)
        stage.unit(367).setAI(3, 0, 0, 0)
        stage.unit(369).setAI(3, 0, 0, 0)
        stage.unit(239).setAI(3, 0, 0, 0)
        stage.unit(82).setAI(6, -1, 6, 11)
        stage.unit(366).setAI(6, -1, 6, 11)
        stage.unit(368).setAI(6, -1, 6, 11)
        stage.unit(238).setAI(6, -1, 6, 11)
        stage.unit(76).setAI(4, -1, 16, 16)
        stage.unit(80).setAI(4, -1, 16, 16)
        stage.unit(79).setAI(4, -1, 16, 16)
        stage.unit(86).setAI(4, -1, 16, 16)
        stage.unit(358).setAI(4, -1, 16, 16)
        stage.unit(359).setAI(4, -1, 16, 16)
        stage.unit(360).setAI(4, -1, 16, 16)
        stage.unit(361).setAI(4, -1, 16, 16)
        stage.unit(362).setAI(4, -1, 16, 16)
        stage.unit(363).setAI(4, -1, 16, 16)
        stage.unit(364).setAI(4, -1, 16, 16)
        stage.unit(365).setAI(4, -1, 16, 16)
        stage.unit(234).setAI(4, -1, 16, 16)
        stage.unit(235).setAI(4, -1, 16, 16)
        stage.unit(236).setAI(4, -1, 16, 16)
        stage.unit(237).setAI(4, -1, 16, 16)
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 또는 관우 사망.\n2. 마이청이 점령되었다.\n3. 턴 수가 25명을 초과한다.')
        stage.showWinCondition('마이청을 붙잡고 관우를 구해!')
        stage.heightLight(16, 16, 16, 16)
        stage.unit(3).heightLight()
        vars[2] = 1
    stage.startOper()
    vars[547] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[2] and not vars[11] and stage.round() == 2:
        stage.unit(47).setAI(3, 3, 0, 0)
        stage.unit(44).setAI(3, 3, 0, 0)
        stage.unit(51).setAI(3, 3, 0, 0)
        stage.unit(210).setAI(3, 3, 0, 0)
        stage.unit(211).setAI(3, 3, 0, 0)
        stage.unit(212).setAI(3, 3, 0, 0)
        stage.unit(242).setAI(3, 3, 0, 0)
        stage.unit(342).setAI(3, 3, 0, 0)
        stage.unit(3).setAI(4, -1, 16, 16)
        vars[11] = 1
    if vars[2] and not vars[12] and stage.round() == 2:
        stage.unit(82).setAI(3, 3, 0, 0)
        stage.unit(366).setAI(3, 3, 0, 0)
        stage.unit(368).setAI(3, 3, 0, 0)
        stage.unit(238).setAI(3, 3, 0, 0)
        stage.unit(47).setAI(0)
        stage.unit(44).setAI(0)
        stage.unit(51).setAI(2)
        stage.unit(210).setAI(0)
        stage.unit(211).setAI(0)
        stage.unit(212).setAI(0)
        stage.unit(242).setAI(0)
        stage.unit(342).setAI(0)
        stage.unit(3).setAI(4, -1, 16, 16)
        vars[12] = 1
    if not vars[2] and not vars[13] and stage.round() == 3:
        stage.unit(76).setAI(3, 3, 0, 0)
        stage.unit(80).setAI(3, 3, 0, 0)
        stage.unit(358).setAI(3, 3, 0, 0)
        stage.unit(359).setAI(3, 3, 0, 0)
        stage.unit(360).setAI(3, 3, 0, 0)
        stage.unit(361).setAI(3, 3, 0, 0)
        stage.unit(234).setAI(3, 3, 0, 0)
        stage.unit(235).setAI(3, 3, 0, 0)
        vars[13] = 1
    if vars[2] and not vars[20] and stage.isInPos(1026, 16, 16):
        stage.resumeCtrl()
        stage.say('&0\n안 돼, 안 돼......')
        if not vars[50]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.say('&76\n하하하!\n마이청은 이미 내 손에 넘어갔어!')
        if not vars[51]:
            stage.unit(80).setDir(stage.countDir(80, 0))
            stage.say("&80\n속담에 있듯이, '물고기와 곰발을 동시에 가질 수는 없다.'\n두 가지 목표를 동시에 달성하고 싶다면,\n너무 어리석은 일이야, 조조!")
        if not vars[52]:
            stage.unit(79).setDir(stage.countDir(79, 0))
            stage.say('&79\n조 재상님, 매성이 이미 함락되었으니,\n싸움을 계속하는 것은 무의미하다.\n빨리 철회하는 게 낫다.')
        vars[20] = 1
        vars[101] = 1
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[30] and stage.isInRect(3, 13, 13, 18, 18):
        stage.unit(3).setAI(1)
        vars[30] = 1
    if not vars[40] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n손권.\n매청을 공격한 것은 공명 전략 아니었나?\n&76\n왜 그렇게 말씀하시나요?\n이것이 내 동우 전략가가 제시한 전략이다,\n너무 무턱대고 추측하지 않는 게 좋을 거야.\n&0\n그럼 이게 주유 자체의 계획이야?\n주유가 공명와 공모할 거라고 생각하지 않는가,\n이번에는 네가 음모를 꾸미는 사람이야?\n&76\n오, 진정으로 조조 받을 자격이 있는가,\n그는 실제로 주유가 아직 살아 있다는 것을 알고 있었다.\n&76\n주유 내 고인이 된 형 손책의 매형이었다,\n그는 항상 우나라에 충성해 왔다,\n우리 동우를 음모할 이유가 없어.\n&76\nMoreover공명 서의 전략가로서,\n어떻게 다른 나라를 선동해 슈를 공격할 이유가 있겠는가?\n&0\n그래서 저는 그것이 더 이상하게 느껴졌습니다.\n손권, 잘 지켜봐야 해,\n앞으로 더 많은 일이 연달아 일어날 가능성이 매우 높습니다.\n&76\n흥, 이해하기 힘들다......\n그만!\n말은 그만하고, 시작해!\n&0\n아니...... 아직도 설득하지 못했어......')
        vars[40] = 1
    if not vars[41] and stage.isNear(3, 83, True):
        stage.unit(3).setDir(stage.countDir(3, 83))
        stage.unit(83).setDir(stage.countDir(83, 3))
        stage.say('&3\n관평을 쏜 사람이 너겠지!\n&83\n나—정말 나 자신을 제어할 수가 없어!\n전장에서는 칼날과 창이 보이지 않습니다.\n게다가 그들은 죽지 않았다!\n&83\n그는 이미 장비와 함께 숨었다,\n아직도 나를 이렇게 원망하는 건 잘못된 거야.\n&3\n아, 아직 살아 있어?\n그 말에 마음이 놓여 있네요.\n빨리 찾아야 해...... 다시 만날 때까지!\n&83\n휴, 정말 깜짝 놀랐어요.')
        vars[41] = 1
    if not vars[42] and stage.isNear(3, 76, True):
        stage.unit(3).setDir(stage.countDir(3, 76))
        stage.unit(76).setDir(stage.countDir(76, 3))
        stage.say('&3\n손권, 목숨 걸고 와!\n죽은 brother유비의 복수를 원해.\n&76\n아, 그러니까 유비 이미 죽은 거야?\n그렇긴 해도, 이 혼란스러운 시대에는,\n유비 죽음이 피할 수 없다는 걸 오래전부터 알고 있었겠지, 그렇지?\n&76\n이건 완전히 운명유비 편한 거야,\n손중모우에 대한 원한은 큰 실수입니다.\n&3\n형이 깨어나는지, 복수를 추구하는지는 또 다른 문제다.\n관의 복수심은 변함이 없다!\n명예롭게 죽을 때까지 싸워라!\n&76\n나는 한 나라의 통치자다,\n어떻게 네 수준에 떨어질 수 있겠어!')
        vars[42] = 1
    if not vars[43] and stage.isNear(3, 0, True):
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(3).setDir(stage.countDir(3, 0))
        stage.say('&0\n윤창, 현덕의 마지막 말에 따라 도우러 왔다.\n&3\n왜 총리가 형의 마지막 말을 알았을까......?\n이제 관이 내 동생을 돕고 싶어 한다brother장비\n관의 무례함을 용서해 주십시오.')
        vars[43] = 1
    if not vars[44] and stage.isNear(3, 87, True):
        stage.unit(3).setDir(stage.countDir(3, 87))
        stage.unit(87).setDir(stage.countDir(87, 3))
        stage.say('&3\n내 아들 관싱을 죽이면, 네가 찾아야 할 사람이야!?\n&87\n하하하!\n그 둘은 어딘가 알 수 없는 곳에 숨어 있었다,\n정말 수치스러운 겁쟁이야.\n&3\n관싱과 관수가 아직 살아 있다는 말인가요!?\n&87\n어쨌든 저 둘은 곧 죽을 거야,\n너도 저승으로 보내서 그들을 만나게 해주겠다!\n&3\n싸울 시간이 없어.\n다시 만날 때까지!')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n흠, 조의 군대가 지원하러 오지 않았다면......\n후퇴!')
        stage.unit(76).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(80, 7, 0, 2):
        stage.say("&80\n쳇, 패배.\n속담에 있듯이, '노인은 영리하고 계산적이다.'\n먼저 후퇴하자!")
        stage.unit(80).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n너무 부주의하게, 후퇴해!\n뜻밖에도 조조 군대를 보내 지원했다......\n공명 정말 다양한 기술로 가득합니다.')
        stage.unit(79).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n쳇, 일단 여기서 나가자.\n가자, 후퇴!')
        stage.unit(86).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n아-아니, 이거 큰일이야!\n목숨을 걸고 도망쳐!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n너—네가 감히 그랬...... 아파......\n더는 못 참겠어.\n후퇴, 후퇴!')
        stage.unit(87).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n후퇴!\n서둘러!\n이번에는 너무 크게 졌다.')
        stage.unit(83).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n다른 방법은 없었다.\n일단 후퇴하자!')
        stage.unit(96).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(47, 7, 0, 2):
        stage.say('&47\n와......\n아-아, 안 돼......\n후회...... 음!')
        stage.unit(47).hide(2)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(44, 7, 0, 2):
        stage.say('&44\n음......\n여기서 죽는 건가요......\n…… 절대 안 돼.')
        stage.unit(44).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(51, 7, 0, 2):
        stage.say('&51\n아......\n하지만, 얼마나 증오스러운가.........\n거짓말 아니에요......')
        stage.unit(51).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(3, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&3\n후회와 후회......\n형...... 셋째 동생......\n미안해......')
        stage.unit(3).hide(2)
        vars[61] = 1
        stage.say('&0\n아-아, 안 돼!\nUnexpectedly관우 ......')
        vars[101] = 1
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n마침내 그들은 손권군을 격퇴했다,\n하지만 이곳은 이미 위험해.')
        stage.unit(0).setDir(stage.countDir(0, 3))
        stage.unit(3).setDir(stage.countDir(3, 0))
        stage.say('관우야, 나와 함께 상양으로 가자. 나 너에게 할 말이 있어.\n조조는 이견이 없지만, 지금 삼제를 아직 찾지 못했으니, 잠시만 더 찾아보게 해다오.\n빨리 가자. 주유가 필시 계략을 펼칠 것이니, 이곳에 오래 머물 수는 없어!')
        if vars[2]:
            stage.reward(0, [
                35,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[647] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
