# Source Generated with Decompyle++
# File: R_33.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(18)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 44)
    stage.showUnits([
        [
            0,
            52,
            34,
            2],
        [
            1,
            69,
            52,
            3],
        [
            8,
            69,
            58,
            3],
        [
            15,
            69,
            64,
            3],
        [
            13,
            69,
            70,
            3],
        [
            20,
            39,
            52,
            1],
        [
            19,
            39,
            58,
            1],
        [
            23,
            39,
            64,
            1],
        [
            24,
            39,
            70,
            1],
        [
            9,
            52,
            52]])
    stage.draw()
    stage.setEventName('공명 전략')
    stage.setStageName('한중: 임시 총리실')
    stage.say('&0\n방덕, 용감한 장군이시여,\n여기서 죽는다면 너무 안타까울 거야,\n왜 나한테 안 해주지 않아?\n&9\n장루 공은 어디 있지?\n&0\n그와 그의 가족을 보호하라고 명령했습니다.\n&9\n그래? 감사합니다, 조 공.\n하지만 내 감정은 변하지 않았어,\n제발 날 죽여줘.')
    stage.say('&0\n방덕, 나 싫어해?\n내가 네 전 스승 마텡을 죽였다고 해서?')
    stage.unit(9).setAction(6)
    stage.say('&9\n나는 무정하거나 감사할 줄 모르는 사람이 아니방덕,\n하지만 장군으로서,\n그리고 충성과 의로움으로 전 주님을 섬기세요.')
    stage.unit(9).setAction(0)
    stage.say('&0\n정말......?\n&9\n더 이상 말할 필요 없어,\n빨리 날 죽여!')
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n닥쳐!\n네 생사는 내가 결정한다,\n선택의 여지가 없어.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n널 죽이지 않을게.\n나는 네가 내 진영의 장군이 되길 원해,\n내 패권에 기여해.\n&9\n내가 네 곁에 있는 게 두렵지 않아?\n너를 죽일 거야!\n&0\n오? 방덕 매우 숙련된 장군이라고 들었어,\n그는 아마도 암살 같은 비열한 방법을 쓰지 않을 것이다.\n&9\n………\n좋아! 내가 네 부하가 되겠다,\n네가 어떤 사람인지 보조조 보자.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n하하하.\n원양, 방덕 숙소를 마련해.')
    stage.unit(1).setAction(0, 0)
    stage.say('&1\n아, 알겠어.')
    stage.unit(1).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n방덕여, 나를 부지런히 섬기소서,\n내 야망을 이해하게 될 거야.')
    model.unitJoin(9, 0, 0)
    if vars[1013]:
        gvars[0] = 9
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.setJoinEquip(9, -1, 0, -1, 0, 12)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            32,
            32,
            54,
            1],
        [
            35,
            50,
            41,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('청두 유비 거주지')
    stage.showUnit(182, 90, 54, 3)
    stage.say('&182\n신고됐어.')
    stage.unit(182).move(52, 54, 3)
    stage.delay(3)
    stage.unit(182).setAction(11)
    stage.say('&182\n그는 주군에 보고하고 한중을 공격하기 위해 진격조조,\n한중은 이미 이미 점령당한 상태였다.')
    stage.unit(32).setAction(3)
    stage.say('&32\n뭐라고...... 뭐라고!?\n한중을 잡조조 거야?\n아, 이거 안 좋네.')
    stage.unit(32).setAction(0)
    stage.say('&35\n장루는 어떻게 됐어?\n장루를 죽였조조 건가요?')
    stage.say('&182\n아니, 장루 가문은 관대하게 대우받았다,\n더불어 그는 공식 계급을 부여받았다.\n&35\n그래? 장루를 잘 대조조 있나?\n그가 마음을 얻는 기술을 깊이 이해하는 조조인 것도 당연하다.')
    stage.unit(32).setAction(3)
    stage.say('&32\n공명, 지금은 그를 감탄할 때가 아니야,\n한중은 서나라의 목이라고 할 수 있다,\n그게 사실상 우리의 약점이죠.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(6)
    stage.say('&35\n주군 걱정할 필요 없어,\n비록 조조 한중을 차지했지만,\n하지만 그들은 우리 슈나라를 공격하지 않을 것이다.\n&32\n왜 그럴까요?\n조조 다음 목표,\n우리가 맞아야 해.')
    stage.unit(35).setAction(0)
    stage.effectSound(200, 255)
    stage.say('&35\n네.')
    stage.delay(5)
    stage.bgSound(12)
    stage.delay(3)
    stage.say('&35\n그래서 조조 마음을 바꿔야 해.')
    stage.say('&32\n...... 바꾸나요?\n동우를 공격해야 할까?\n&35\n그래, 손권 아직도 허페이를 포기하지 않았어.\n&35\n만약 동오가 합비를 공격하기 위해 군대를 보낸다면,\n조조 아마 우리나라를 공격하지 않을 거야.\n&32\n하지만 동조 무국이 군대를 보냈을까?')
    stage.unit(35).setAction(11)
    stage.say('&35\n징저우 네 군 중 세 군을 손권에 반환하라,\n그는 분명히 군대를 보낼 것이다.\n&32\n경주로 돌아가는 거지.........')
    stage.unit(35).setAction(0)
    stage.say('&35\n주군, 제발 결정을 내려주세요!\n경주 점령을 고집하지 마십시오,\n우리 슈 국가를 멸망 직전까지 몰아넣었어!\n&32\n좋아.\n공명, 이 일은 당신에게 맡길게요.\n결정은 당신에게 달렸습니다.')
    stage.unit(35).setAction(6)
    stage.say('&35\n안심하세요, 주군.\n공명 즉시 동우로 사절을 보냈다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 51)
    stage.showUnits([
        [
            76,
            53,
            29,
            2],
        [
            193,
            53,
            48,
            0,
            6],
        [
            88,
            41,
            48,
            1],
        [
            78,
            41,
            54,
            1],
        [
            192,
            65,
            48,
            3],
        [
            194,
            65,
            54,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('지안예 손권 저택')
    stage.say('&76\n오, 우가 허페이를 공격하길 바라는 거야?\n&193\n네.\n&193\n주님께서 동의하신다면,\n우리 소박한 나라는 즉시 징저우 세 군을 돌려주겠다.\n&76\n좋아.\n하지만 병력은 돌려보내고 나서만 보냈습니다.\n&76\n내가 당신나라의 징저우 주둔군을 확인하면,\n완전 대피 후,\n허페이를 공격할 아군, 어떻게 생각해?\n&193\n네.\n어른들의 뜻을 따르세요.')
    stage.effectSound(200, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 162, 73)
    stage.showHead(140, 98, 73)
    stage.bottomTxt('조조 장루를 물리쳤다,', False, False, False)
    stage.delay(5)
    stage.head(140).hide()
    stage.delay(5)
    stage.head(0).move(130, 73)
    stage.delay(5)
    stage.bottomTxt('그는 한중을 점령했다.', True, False, False)
    stage.delay(8)
    stage.showHead(32, 25, 171)
    stage.delay(5)
    stage.bottomTxt('유비 도사리고 있는 위기를 느꼈다,', True, True, False)
    stage.delay(5)
    stage.showHead(3, 302, 235)
    stage.delay(5)
    stage.head(3).move(263, 193)
    stage.delay(5)
    stage.bottomTxt('그는 징저우의 세 개 현을 양도하는 조건을 제안하고 동오에 합비를 공격해 달라고 요청했다.', True, False, False)
    stage.delay(10)
    stage.showHead(78, 327, 238)
    stage.showHead(76, 511, 212)
    stage.delay(5)
    stage.bottomTxt('손권 징저우의 세 현이 점령되었음을 확인했다.', True, True, False)
    stage.delay(10)
    stage.showHead(2, 422, 142)
    stage.delay(5)
    stage.bottomTxt('다시 공격', True, False, False)
    stage.delay(5)
    stage.head(76).move(486, 183)
    stage.delay(5)
    stage.bottomTxt('장료 허페이를 지켰다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene3():
    stage.loadBg(2, 44)
    stage.showUnits([
        [
            0,
            52,
            34,
            2],
        [
            1,
            69,
            52,
            3],
        [
            8,
            69,
            58,
            3],
        [
            15,
            69,
            64,
            3],
        [
            13,
            69,
            70,
            3],
        [
            20,
            39,
            52,
            1],
        [
            19,
            39,
            58,
            1],
        [
            23,
            39,
            64,
            1],
        [
            21,
            39,
            70,
            1],
        [
            181,
            52,
            52,
            0,
            11]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('한중: 임시 총리실')
    stage.say('동오가 합비로 공격했나요?')
    stage.unit(21).setAction(6)
    stage.say('&21\n손권 한중 공격을 이용한 거야......')
    stage.unit(21).setAction(0)
    stage.say('&0\n이건 손권 생각이 아니야,\n아마도 공명가 동오에 군대를 보내도록 선동한 인물일 것이다.\n&0\n그들의 목표는 우리를 통제하는 것이다,\n서나라의 안보를 보장하기 위해,\n이것도 아마 또 다른 제갈량 계획일 거예요.\n&19\n공명Is 그래......?')
    stage.unit(1).setAction(3)
    stage.say('&1\nHowever장료 한때 동우의 공격을 격퇴했다,\n이번에는 그들이 버틸 수 있어야 하지 않을까?')
    stage.unit(1).setAction(0)
    stage.say('아니요. 손권은 지난번의 교훈을 잊지 않을 것이니, 문원도 쉽게 승리하기 어려울 겁니다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n지금 증원군을 보내고 싶어도,\n군대도 움직일 수 없었다.')
    stage.unit(1).setAction(0)
    stage.say('&0\n이런 일이 생길까 봐 걱정돼요,\n그래서 그들은 미리 증원군을 준비했다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n증원군?\n어디 있지?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(5)
    stage.say('&0\n여기.\n이 편지는 백만 명의 증원군이었어.')
    stage.unit(1).setAction(3)
    stage.say('&1\n이봐, 이봐, 맹덕.\n편지가 어떻게 보조가 될 수 있지?\n&0\n그는 즉시 이 편지를 원원에게 건넸다,\n무슨 일이 있어도 전투 시작 전에 전달해!\n&181\n네.')
    stage.unit(1).setAction(0)
    stage.say('&1\n맹덕, 도대체 무슨 생각을 하고 있는 거야?')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            2,
            54,
            80],
        [
            10,
            44,
            64,
            1],
        [
            11,
            64,
            64,
            3]])
    stage.draw()
    stage.setStageName('허페이 조조 본캠프')
    stage.unit(10).setAction(0, 2)
    stage.say('&10\n장 장군, 동무군이 말을 타고 도착할 것이다,\n즉시 싸워야 합니다.\n&2\n하지만...... 한중으로 파견된 사절단은 아직 돌아오지 않았다.')
    stage.unit(11).setAction(0, 2)
    stage.say('&11\n장군님, 포기하시는 게 좋겠습니다!\n&2\n그건 어쩔 수 없이 하는 일이야.')
    stage.showUnit(181, 54, 22, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n보고해. ...... 소유 돌아왔어, 한숨......')
    stage.unit(10).setAction(0, 0)
    stage.unit(11).setAction(0, 0)
    stage.say('&11\n아, 그냥 기다리고 있었어!\n&10\n지원군이 도착했나!?')
    stage.say('&181\n이것은 주군가 장 장군에게 보낸 편지입니다.\n주군 이 편지가 백만 명의 증원군 같다고 했어......\n&10\n그게 백만 명의 증원군에 해당하는 거야?\n이 편지만요?\n&2\n좋아, 내가 한번 볼게.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(10).setAction(0, 1)
    stage.unit(11).setAction(0, 3)
    stage.unit(181).move(54, 76, 2)
    stage.delay(5)
    stage.unit(181).move(54, 64, 2)
    stage.delay(3)
    stage.unit(11).setAction(0, 2)
    stage.say('&11\n거기에 뭐라고 적혀 있어?\n&2\n전투에 나가기 전에 적과 마주하기 전에 봉인을 열지 마라.')
    stage.unit(10).setAction(0, 2)
    stage.say('&10\n뭐라고?\n이토록 중요한 순간에,\n도대체 무슨 생각주군 거야!\n&2\n지금은 .........\n내가 할 수 있는 건 주군의 명령을 따르는 것뿐이야.')
    stage.unit(2).setAction(17)
    stage.say('&2\n병력을 보내라!')
    stage.unit(2).setAction(0)
    stage.unit(11).setAction(0, 3)
    stage.unit(10).setAction(0, 1)
    stage.unit(181).move(54, 22, 0)
    stage.unit(181).hide()
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        2,
        11,
        10], [
        0])
    gvars[4076] = 0
    gvars[4057] = 33
    stage.setBattlePos([
        [
            14,
            15],
        [
            15,
            16],
        [
            15,
            17],
        [
            14,
            16],
        [
            13,
            15],
        [
            16,
            16],
        [
            14,
            3],
        [
            15,
            3],
        [
            14,
            2],
        [
            15,
            2],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene5():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&2\n가자!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(11):
        stage.say('&11\n그런데 장군이 방덕......\n잘 만들어진 헬멧도 있었다.')
    if stage.unitClickTest(10):
        stage.say('&10\n도시는 많은 습지와 작은 강들로 둘러싸여 있습니다.\n동부 오나라 군대와 물가에서 싸우는 것은 매우 어려웠다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
