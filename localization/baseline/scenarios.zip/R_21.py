# Source Generated with Decompyle++
# File: R_21.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.bgSound(-1)
    stage.loadBg(2, 67)
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('원소 아들')
    stage.setStageName('랑산: 산길')
    stage.showUnits([
        [
            32,
            57,
            5,
            2],
        [
            33,
            47,
            5,
            2],
        [
            3,
            52,
            5,
            2]])
    stage.unitsMove([
        [
            stage.unit(32),
            57,
            17,
            2],
        [
            stage.unit(33),
            47,
            17,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(32),
            57,
            47,
            2],
        [
            stage.unit(33),
            47,
            47,
            2],
        [
            stage.unit(3),
            52,
            35,
            2]])
    stage.say('&32\n서둘러, 조의 군대가 곧 따라잡을 거야.')
    stage.unit(33).setAction(2)
    stage.say('&33\n흥, 이 배신자를 조조어!')
    stage.unit(33).setAction(0)
    stage.say('&3\n형, 앞으로 어떻게 할까?')
    stage.unit(33).setAction(0, 0)
    stage.delay(3)
    stage.unit(32).setAction(0, 0)
    stage.say('&32\n다른 방법이 없었다; 우리는 양주에서 류뱌오에게 피신하러 갔다.\n&3\n...... 징저우?\n&32\n흠. 징저우 땅은 비옥하다,\n류뱌오와 나는 같은 가문 출신이야,\n분명히 우리에게 도움이 될 거예요.')
    stage.unit(3).setAction(6)
    stage.say('&3\n좋아.\n그럼 제 형과 셋째 형을 먼저 징저우로 보내 주세요.')
    stage.unit(3).setAction(0)
    stage.say('&3\n내가 그만할게조조.')
    stage.unit(33).setAction(3)
    stage.say('&33\n둘째 형, 나도 도와줄게!\n&3\n셋째 형, 형을 지켜야 해!')
    stage.unit(33).setAction(0)
    stage.say('&33\n하지만.........\n&32\n윤창, 혼자 ...... 있니?')
    stage.unit(3).setAction(6)
    stage.say('&3\n걱정 마, 형.')
    stage.say('&32\n…… 좋아! 네게 맡길게.\n특히 조심해야 해.\n&3\n네.')
    stage.unit(3).setAction(0)
    stage.say('&3\n가자!')
    stage.unit(32).setAction(0, 3)
    stage.say('&32\n흠. 가자, 셋째 형!')
    stage.unit(33).setAction(0, 1)
    stage.delay(3)
    stage.unit(33).setAction(17)
    stage.say('&33\n오!')
    stage.unit(33).setAction(0)
    stage.unitsMove([
        [
            stage.unit(32),
            57,
            98,
            2],
        [
            stage.unit(33),
            47,
            95,
            2],
        [
            stage.unit(3),
            52,
            80,
            2]])
    stage.unit(3).setAction(0)
    stage.unit(32).hide()
    stage.unit(33).hide()
    stage.effectSound(203, 255)
    stage.effectSound(207, 0)
    stage.delay(3)
    stage.showUnits([
        [
            0,
            56,
            5,
            2],
        [
            22,
            48,
            5,
            2],
        [
            181,
            57,
            5,
            2],
        [
            182,
            52,
            5,
            2],
        [
            183,
            47,
            5,
            2]])
    stage.say('&0\n빨리! 도망가지 못하게 유비!')
    stage.unit(3).setAction(0, 0)
    stage.say('&3\n…… 저기 온다고?')
    stage.unitsMove([
        [
            stage.unit(0),
            56,
            13,
            2],
        [
            stage.unit(22),
            48,
            13,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(0),
            56,
            66,
            2],
        [
            stage.unit(22),
            48,
            66,
            2],
        [
            stage.unit(181),
            57,
            58,
            2],
        [
            stage.unit(182),
            52,
            58,
            2],
        [
            stage.unit(183),
            47,
            58,
            2]])
    stage.unit(0).setAction(0)
    stage.unit(22).setAction(0)
    stage.unit(181).setAction(0)
    stage.unit(182).setAction(0)
    stage.unit(183).setAction(0)
    model.setFace(1)
    stage.say('&0\n윤창?')
    stage.unit(3).setAction(6)
    stage.say('&3\n총리는 며칠 동안 그를 못했다.')
    stage.unit(3).setAction(0)
    model.setFace(0)
    stage.say('&0\n……네가 후방을 맡을 건가?\n&3\n예요.')
    stage.unit(3).setAction(3)
    stage.say('&3\n절대 지나가지 못하게 할 거야.\n무기를 보여주세요.')
    stage.unit(3).setAction(0)
    stage.say('&0\n……….(관우가 아무리 용맹해도,\n혼자서는 살아남을 수 없을 거야. 어떻게 해야 할까……)')
    stage.effectSound(207, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('공격 관우\n공격 멈춰', 0)
    if sel == 1:
        stage.addAmbition(5)
        vars[307] = 1
        stage.bgSound(-1)
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.say('&0\n윤창, 앞으로 나아가자.\n&3\n내가 관목이 여기 있는 한,\n반 걸음 넘으려는 생각도 하지 마!')
        stage.unit(0).setAction(17)
        stage.say('상대방은 한 명뿐이야. 공격하자!')
        stage.unit(0).setAction(0)
        stage.say('&181\n이게 ......관우......인가요!?\n&182\n안 돼...... 절대 안 돼......\n이길 수 없어.')
        stage.unit(22).setAction(0, 0)
        stage.say('&22\n뭘 무서워하는 거야!? 빨리 가.\n&181\n군대, 전략가, 상대편은 관우, 그렇지,\n우리 소규모 그룹은 그를 감당할 수 없었다......\n&183\n안 돼...... 더는 못 참겠어.\n생존이 더 중요하다......\n&22\n음, 음, ......')
        stage.unit(22).setAction(0, 1)
        stage.say('&22\n주군, 더는 못 참겠어.\n병사들은 모두 관우을 두려워했다.')
        stage.unit(22).setAction(6)
        stage.say('&22\n더 이상 관우 감당할 수 없는 것 같아.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(181),
                57,
                54,
                0],
            [
                stage.unit(182),
                52,
                54,
                0],
            [
                stage.unit(183),
                47,
                54,
                0]])
        stage.delay(3)
        stage.unit(181).setAction(0, 2)
        stage.unit(182).setAction(0, 2)
        stage.unit(183).setAction(0, 2)
        stage.delay(10)
        stage.unit(0).setAction(2)
        stage.say('&0\n어떻게 이런 일이 일어날 수 있지!')
        stage.unit(0).setAction(0)
        stage.say('&0\n짜증나......\n다른 방법은 없었다.')
        stage.delay(3)
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n윤창, 다시 만날 때까지.')
        stage.unitsMove([
            [
                stage.unit(0),
                56,
                5,
                0],
            [
                stage.unit(22),
                48,
                5,
                0],
            [
                stage.unit(181),
                57,
                5,
                0],
            [
                stage.unit(182),
                52,
                5,
                0],
            [
                stage.unit(183),
                47,
                5,
                0]])
        stage.unit(0).hide()
        stage.unit(22).hide()
        stage.unit(181).hide()
        stage.unit(182).hide()
        stage.unit(183).hide()
        stage.unit(3).setAction(0, 2)
        stage.say('&3\n………… (나도 징저우로 갈 거야)')
        stage.unit(3).move(52, 98, 2)
        stage.unit(3).hide()
    elif sel == 2:
        vars[307] = 0
        stage.addAmbition(-10)
        stage.bgSound(19)
        stage.say('...곽가.\n후퇴해!')
        stage.unit(22).setAction(0, 1)
        stage.say('&22\n뭐라고...... 뭐라고! 왜!?\n이건 일생에 한 번 있는 기회야!\n&0\n…… 잊어버려.')
        stage.unit(22).setAction(6)
        stage.say('&22\n과거와 관우 기억나주군?\n주군, 너무 마음이 약해!')
        stage.unit(0).setAction(0, 3)
        stage.say('봉효.')
        stage.unit(22).setAction(0)
        stage.say('&22\n네.\n&0\n그런 상황에서 관우를 죽이고 싶지 않아.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n이런 작은 전장이 영웅들이 헛되이 죽을 곳이 되어서는 안 된다.')
        stage.unit(22).setAction(6)
        stage.say('&22\n주군, 전쟁은 크기가 없다!')
        stage.unit(0).setAction(0, 0)
        stage.delay(3)
        stage.unit(0).setAction(17, 0)
        stage.say('&0\n퇴각! 이것이 명령이다.')
        stage.unit(22).setAction(0)
        stage.say('&22\n주군.........')
        stage.unit(0).setAction(0, 0)
        stage.unitsMove([
            [
                stage.unit(0),
                56,
                5,
                0],
            [
                stage.unit(22),
                48,
                5,
                0],
            [
                stage.unit(181),
                57,
                5,
                0],
            [
                stage.unit(182),
                52,
                5,
                0],
            [
                stage.unit(183),
                47,
                5,
                0]])
        stage.unit(0).hide()
        stage.unit(22).hide()
        stage.unit(181).hide()
        stage.unit(182).hide()
        stage.unit(183).hide()
        stage.say('&3\n………\n(이 상호 감사,\n관은 깊이 감사했다. )')
    stage.effectSound(203, 255)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 398, 119)
    stage.showHead(32, 368, 199)
    stage.bottomTxt('유비가 랑산에서 패배한 후,', False, False, False)
    stage.delay(5)
    stage.showHead(150, 282, 222)
    stage.delay(5)
    stage.bottomTxt('그는 추종자들을 이끌고 자신과 함께하게 했다', True, False, False)
    stage.delay(5)
    stage.head(32).move(346, 222)
    stage.delay(5)
    stage.bottomTxt('징저우의 류뱌오.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('조조 주력 군대', True, True, False)
    stage.delay(5)
    stage.head(0).move(333, 95)
    stage.delay(5)
    stage.bottomTxt('승리하여 쉬두로 돌아온 후,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 이후 병력 훈련을 강화하고 허베이 평정을 준비했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            2,
            64,
            70],
        [
            23,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n문약, 군마 준비는 어떻습니까?')
    stage.unit(20).setAction(6)
    stage.say('&20\n모든 준비가 끝났습니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(22).setAction(6)
    stage.say('&22\n주군 군수품은 이미 완전히 비축되어 있었다,\n이제 우리는 허베이를 진압하기 위해 군대를 보낼 수 있습니다.')
    stage.unit(22).setAction(0)
    stage.say('&0\n흠.........')
    stage.unit(24).setAction(6)
    stage.say('&24\n세 아들이 원상 큰 사업을 물려받았지만,\n그러나 그는 구 원씨 가문 세력을 통합하지 못했다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n더불어, 장남은 자신의 파벌원담,\n이미 원상에게 등을 돌리고 적이 되었다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n정말 좋은 기회입니다!')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('좋습니다! 병사를 파병합니다. 북해를 평정합시다!')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 334, 133)
    stage.showHead(115, 353, 30)
    stage.bottomTxt('조조 군대', False, False, False)
    stage.delay(5)
    stage.head(0).move(289, 133)
    stage.head(0).move(289, 84)
    stage.delay(5)
    stage.bottomTxt('황강 북쪽을 건너며,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그리고 리양 근처에서 진격했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            115,
            53,
            28,
            2],
        [
            106,
            38,
            48,
            1],
        [
            102,
            38,
            54,
            1],
        [
            103,
            38,
            60,
            1],
        [
            113,
            68,
            48,
            3],
        [
            114,
            68,
            54,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('예 @원상 관저')
    stage.say('&115\n방금 보고를 받았어요,\n조의 군대는 이미 리양 인근까지 진격한 상태였다.\n&115\n나는 절대 가만히 서 있을 수 없조조,\n아버지가 허베이에서 쌓아준 토대를 짓밟으며,\n즉시 전투 준비해.')
    stage.unit(106).setAction(6)
    stage.say('&106\n상대가 조조어서 우리가 그들을 능가해야 해.')
    stage.unit(106).setAction(0)
    stage.delay(3)
    stage.unit(113).setAction(0, 1)
    stage.say('&113\n흥! 군대 전체가 함께 조조 처리하면 돼,\n전략에 대해 이야기할 필요 없어.\n&115\n형, 네가 이러면,\n아마 조조와 맞설 수 없을 거야.')
    stage.unit(113).setAction(0, 3)
    stage.delay(3)
    stage.unit(113).setAction(2, 3)
    stage.say('&113\n뭐라고!?\n&102\n저도 그렇게 생각해요.')
    stage.unit(113).setAction(0)
    stage.say('&113\n음음 음 .........\n&115\n먼저, 장남을 환영해 주세요, 둘째 형제,\n궈투와 봉기 그리고 세 명이 더 있었다,\n군대를 이끌고 조의 군대와 싸우라.')
    stage.unit(102).setAction(0, 0)
    stage.say('&102\n나도 갈까?\n&115\n흠.')
    stage.unit(102).setAction(0, 1)
    stage.say('&102\n…… 좋아.\n&113\n원상, 그럼 뭐 하는 거야?\n&115\n내 형제들과 심배들이 나를 기다리고 있었다.')
    stage.unit(113).setAction(0, 1)
    stage.say('&113\n흥!\n(너무 지루해! 젠장, 원상,\n어떻게 그런 짓을 할 수 있지? )')
    stage.unit(113).setAction(0, 3)
    stage.delay(3)
    stage.unit(103).setAction(6)
    stage.say('&103\n(위안 장군, 지금은 참아주시기 바랍니다. )')
    stage.unit(103).setAction(0)
    stage.say('&113\n(좋아! )\n&115\n둘째 형은 괜찮아.\n&114\n네.\n&115\n좋아! 너희 넷은 즉시 전투에 나가라.\n반드시 조조를 이겨야 해!')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            24,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('리양 외곽, 조조군의 본진')
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n주군 허베이군은 리양에서 아군을 기다렸다.\n&0\n좋아.\n나는 원소의 아들들을 보고 싶다,\n그들은 얼마나 유능한가요?')
    stage.unit(0).setAction(17)
    stage.say('&0\n출발!')
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 11, [
        22])
    gvars[4076] = 0
    gvars[4057] = 21
    stage.setBattlePos([
        [
            2,
            36],
        [
            1,
            37],
        [
            3,
            37],
        [
            3,
            35],
        [
            4,
            36],
        [
            1,
            35],
        [
            4,
            38],
        [
            3,
            39],
        [
            0,
            36],
        [
            2,
            38],
        [
            0,
            38],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n리양의 지형은 특별할 것 없어,\n하지만 많은 곳에서 울타리가 설치되어 있습니다.\n&0\n오?\n그래서 위안 가문의 소년도 어느 정도 재능이 있었던 거군요.')
    if stage.unitClickTest(22):
        stage.say('&22\n원담 그들이 입지를 공고히 하려는 것처럼 보인다면,\n방어가 꽤 강력합니다.\n&0\n그거 참 원소.')
    if stage.unitClickTest(21):
        stage.say('&21\n이제 원소 죽었어,\n허베이에는 아직 몇 명의 병력이 남아 있었나요?')
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 그 작은 녀석들은 창팅으로 갔다.\n&0\n흠.\n&1\n아직도 많이 뒤처져 있다고 생각원소......')
    if stage.unitClickTest(24):
        stage.say('&24\n원담와 원희는 현재 최전선에 있습니다.\n원상 아직도 뒤에 갇혀 있는 것 같아.\n&0\n오?')
    if stage.unitClickTest(15):
        stage.say('&15\n솔직히 말해서, 나는 살인을 좋아하지 않는다.\n&15\n아! 너 ...... 괜찮아.\n용감하게 싸울 거야.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
