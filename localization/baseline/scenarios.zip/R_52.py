# Source Generated with Decompyle++
# File: R_52.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(13)
    stage.delay(3)
    stage.loadBg(2, 16)
    stage.showUnit(77, 52, 82)
    stage.draw()
    stage.setEventName('네 개의 제단')
    stage.setStageName('지안예 컨퍼런스 홀')
    stage.showUnit(0, 52, 5, 2)
    stage.unit(0).move(52, 18, 2)
    stage.unit(0).setAction(0)
    stage.say('&0\n주유!')
    stage.unit(0).move(52, 60, 2)
    stage.unit(0).setAction(0)
    stage.say('&0\n주유, 드디어 찾았어!')
    stage.unit(77).setAction(0, 1)
    stage.say('&77\n흥! 조조......\n아니면 이곳을 찾으셨나요......\n&0\n주유, 그가 지휘하는 주요 장군들 손권,\n이제 모두 전투에서 죽었고, 동오는 멸망했다!\n&77\n………\n&0\n마지막으로 한 가지 더 묻고 싶어요.\n&77\n패배한 장군이라니, 나한테 뭘 묻겠어?')
    stage.unit(0).setAction(3)
    stage.say('&0\n공명에 관한 거야.\n왜 갑자기 반란을 일으켰을까?\n그들의 진짜 목적은 무엇일까요!?')
    stage.unit(0).setAction(0)
    stage.delay(10)
    stage.unit(77).setAction(0, 0)
    stage.say('&77\n인류 전체를 지배하기 위해서.\n공명 이미 고대 마왕에게 빙의된 상태였다.')
    model.setFace(1)
    stage.say('&0\n！？')
    stage.unit(77).setAction(0, 2)
    stage.say('&77\n마왕의 힘이 아직 완전히 발휘되지 않았지만,\n그러나 네 제단에서 기도를 마치공명 때,\n실질적인 권력을 얻게 될 것입니다.')
    stage.say('&77\n제단은 특정 위치에 설치되어야 합니다,\n그중 두 곳은 붉은 절벽과 쉬두입니다,\n서부에는 두 곳이 더 있습니다.')
    stage.unit(77).setAction(0, 0)
    stage.say('&77\n쉬두를 붙잡을 수 있다면,\n마왕의 부활을 막을 수 있다,\n전력을 다해 주세요!\n&0\n이런 일이 일어날 수 있다니 믿을 수가 없어.')
    model.setFace(0)
    stage.unit(77).setAction(9)
    stage.say('&77\n음!!\n음, 기침......!\n&0\n주유, 병이라니......')
    stage.say('&77\n이제 오나라가 무너졌고,\n내 병은 더 이상 중요하지 않다.\n그냥 ......')
    stage.say('&77\n하늘이 나에게 조금만 더 시간을 준다면,\n저는 그냥 팀을 이루지 않을 거예요공명......')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(17)
    stage.say('&77\n......조조, 네 손에 죽지 않을 거야.\n…… 기침, 기침, 기침!')
    stage.unit(0).setAction(3)
    stage.say('&0\n주유!\n&77\n더 가까이 오지 마!!\n&77\n내 인생은 나 스스로 끝나야 해!!')
    stage.unit(77).setAction(0)
    stage.delay(5)
    stage.effectSound(38, 1)
    stage.unit(77).setAction(10)
    stage.say('&0\n주유!!')
    stage.delay(10)
    stage.unit(0).setAction(0)
    stage.say('&0\n주유.\n죽을 때까지 여전히 그렇게 오만하다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.sectionName(4, '마왕이 부활하다')
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('슈로 향한다!')
    stage.setStageName('지안예 조조군이 본군입니다')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n마왕에게 빙의된 공명 문제는,\n정말 상상할 수 없는 일입니다,\n하지만 .........')
    stage.unit(19).setAction(0)
    stage.say('&0\n나도 그렇게 생각해.\n하지만 공명의 이러한 비정상적인 행동들은,\n사실, 오직 악마만이 그것을 해낼 수 있었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n주유 그가 죽기 전에 한 말은 믿기 어렵습니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n그분은 said공명 땅 곳곳에 네 개의 제단을 세우실 것이다,\n마왕의 힘을 깨우기 위해 기도해.\n&0\n네 개의 제단 모두를 위해 기도하면,\n마왕의 원래 마력을 회복시킬 거야.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n공명... 아니, 마왕이라고 할 수 있어,\n이것이 바로 그가 원하던 것이었다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n네 개의 제단......\n그중 하나가 레드 클리프에서 발견된 제단입니다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n그렇다면 나머지 세 개의 제단은 어디에 있을까요?')
    stage.unit(21).setAction(0)
    stage.say('또한 허도는 한 명입니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n뭐라고, 쉬두!?\n우리 기지 바로 안에서?')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n그리고 즉시 쉬두에게 알렸다,\n모든 의심스러운 인물은 출입이 금지됩니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n서두는 서서에 주둔하며 주둔 사령관을 맡았다.\n즉시 그를 고도의 경계 태세에 넣으세요.')
    stage.unit(21).setAction(0)
    stage.say('서쪽에는 두 명이 더 있습니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n저는 그것이 슈 영토 내에 있어야 한다고 생각합니다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흠...... 하지만 아직 확실하지 않아.\n그나저나, 중달.')
    stage.unit(19).setAction(6)
    stage.say('&19\n존재한다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n조사하라고 명령한다.\n고대 문헌과 고전을 참고하고 제단의 위치를 조사하세요.')
    stage.unit(0).setAction(0)
    stage.say('&19\n네.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('다들 잘 들으세요! 마왕이 부활하는 것을 절대로 허용해서는 안 됩니다!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n전 군대가 즉시 행군했다,\n슈에 대한 캠페인!\n우리는 반드시 공명를 제거해야 한다!')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 471, 198)
    stage.showHead(76, 535, 198)
    stage.bottomTxt('조조 건예(지안예)를 공격하기 위해 진격했다.', False, False, False)
    stage.delay(5)
    stage.head(76).hide()
    stage.delay(5)
    stage.bottomTxt('마침내 동오가 멸망했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('주유 죽기 전에 그렇게 말했어', True, True, False)
    stage.delay(5)
    stage.bottomTxt('네 개의 제단의 신비.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('조조 마왕의 부활을 막기 위해,', True, True, False)
    stage.delay(5)
    stage.head(0).move(240, 220)
    stage.delay(5)
    stage.bottomTxt('그는 군대를 이끌고 슈로 향했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 46)
    stage.showUnit(35, 53, 71)
    stage.draw()
    stage.effectSound(204, 0)
    stage.delay(3)
    stage.setStageName('바이디 시 공명 저택')
    stage.delay(3)
    stage.unit(35).setAction(0, 1)
    stage.delay(3)
    stage.unit(35).setAction(11)
    stage.say('&35\n주유 동쪽 하늘의 장군의 별은 이미 지고 있다.\n흥, 주유 주니어가 드디어 죽었네.\n&35\n어쨌든, 그는 내 졸개일 뿐이야.')
    stage.unit(35).setAction(0)
    stage.say('&35\n…… 으으!!')
    stage.unit(35).setAction(8)
    stage.say('&35\n와아!\n그건 ...... 콩과 공명의 영혼 ......!\n와아아!')
    stage.unit(35).setAction(12)
    stage.say('&35\n콩과 공명......\n돌아서서 나를 지배하고 싶어!?\n날 과소평가하는 거야!')
    stage.showUnit(69, 53, 5, 2)
    stage.say('&69\n전략가?')
    stage.unit(35).setAction(8)
    stage.say('&35\n장—장웨이......? 아, 큰일이야!')
    stage.unit(35).setAction(12)
    stage.say('&35\n와!')
    stage.unit(35).setAction(8)
    stage.say('&35\n… 아, 아, 아......\n흥, 젠장it공명......\n아직도 힘들어하려고!?')
    stage.unit(35).setAction(0)
    stage.say('&35\n비록 내가 마왕으로서 아직 부활하지 않았지만,\n하지만 결코 필멸자의 영혼에 의해 조종당하지 않을 것이다......\n&69\n전략가, 나는 장웨이다.\n들어가도 될까요?')
    stage.unit(35).setAction(0, 0)
    stage.say('&35\n어, 어, 장웨이야?\n빨리 들어와.\n&69\n방해해서 미안해.')
    stage.unit(69).move(53, 55, 2)
    stage.delay(3)
    stage.unit(69).setAction(6)
    stage.say('&69\n공명Mr. 쯔, 방금 무슨 일이 있었던 거야?"\n신음 소리가 들린 것 같아.')
    stage.unit(69).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n아, 아무것도 아니야.\n걱정할 필요 없어.\n하지만 너는...... 무슨 일이야?')
    stage.unit(69).setAction(6)
    stage.say('&69\n아, 맞다.\n방금 군사 정보 보고서를 받았어요,\n조조 이미 동오를 파괴했다.')
    stage.unit(35).setAction(0, 0)
    stage.say('&35\n정말......\n동오가 멸망했나?\n&69\n손권 주유과 다른 주요 장군들은 모두 전투에서 전사했다.\n&35\n흠.\n&69\n게다가 조의 군대는 현재 그 흐름을 이용해 추격하고 있다,\n그들은 이미 우리 슈나라를 공격하러 왔다.')
    stage.unit(69).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n그래서 그런 거구나......\n그래서 우리도 행동에 나서야 합니다.')
    stage.unit(35).setAction(0, 0)
    stage.say('&35\n즉시 유후우라에게 가겠습니다.\n&35\n기도 준비를 계속할 수 있도록 여기 머물러.\n실수는 절대 없어야 합니다.')
    stage.unit(69).setAction(6)
    stage.say('&69\n네.')
    stage.unit(35).setAction(0, 1)
    stage.delay(3)
    stage.unit(35).setAction(11)
    stage.say('&35\n선주께서 남기신 한실 부흥의 뜻을 잇기 위해,\n이제는 기도를 통해 비술을 익히는 수밖에 없다.\n&69\n강유, 잘 알겠습니다.\n안심하십시오.')
    stage.effectSound(204, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('주영조조 슈우 국경')
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n적진에 진입하려던 참이었고,\n모두가 부주의해서는 안 됩니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n네.')
    stage.unit(1).setAction(0)
    stage.delay(5)
    stage.showUnit(181, 54, 22, 2)
    stage.say('&181\n보고해!\n&0\n무슨 일이야?')
    stage.unit(181).setAction(11)
    stage.say('&181\n주군 보고합니다, 방금 정찰병들이 보고하러 왔습니다,\n백디성에서 슈 군대를 발견했다.')
    stage.unit(1).setAction(0, 1)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n아, 찾았적군?\n맹덕, 바로 공격하자.')
    stage.unit(1).setAction(0)
    stage.say('&0\n물론이지.\n하지만 더 이상 바이디 시는 아닙니다......\n윤창, 현덕은 바이디 시에서 죽었지......')
    stage.unit(3).setAction(0, 2)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n네.\n내 형이 그곳에서 죽었어.')
    stage.unit(3).setAction(0)
    stage.say('&0\n음, 그건 절대 잊지 못할 일이겠지.')
    stage.unit(20).setAction(6)
    stage.say('&20\n관우 장군님.\n여기서 그들은 바이디 시를 공격했다,\n어떤 길을 택해야 할까요?')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 1)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n바이디 시로 이어지는 많은 도로가 있습니다.\n그중 유후푸로 가는 길이 가장 가깝습니다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n유후푸? 좋아, 이 길로 가자.\n마왕의 부활을 막기 위해,\n더 이상 미룰 여유가 없어.')
    stage.unit(0).setAction(0)
    stage.unit(181).hide()
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 12)
    gvars[4076] = 0
    gvars[4057] = 52
    stage.setBattlePos([
        [
            4,
            20],
        [
            5,
            20],
        [
            3,
            20],
        [
            6,
            20],
        [
            4,
            21],
        [
            5,
            21],
        [
            3,
            21],
        [
            6,
            21],
        [
            4,
            22],
        [
            5,
            22],
        [
            3,
            22],
        [
            6,
            22],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n바이디 성의 성벽은 3층 구조를 가지고 있습니다.\n&1\n건예보다 약간 작다.\n&20\n네, 하지만 지안예에서의 우리 상황은,\n서나라 군대도 매우 명확했다.\n&20\n따라서 결코 가볍게 여겨서는 안 됩니다.')
    if stage.unitClickTest(3):
        stage.say('관우, 어복포가 어디인가?')
    if stage.unitClickTest(19):
        stage.say('&19\n주군, 마왕이 어떤 힘을 가진 것 같아,\n자연물에 생명을 불어넣을 수 있어,\n그리고 그것을 조작하는 거죠.\n&0\n지안예가 본 나무 인형처럼, 맞지?\n&19\n네, 안타깝지만 그렇습니다.')
    if stage.unitClickTest(17):
        stage.say('&17\n불길한 예감이 감돌고 있다,\n여기 다른 길로 가는 게 어때?\n&0\n지금 가장 중요한 것은 시간을 벌는 것입니다,\n절대 우회로는 가지 마세요.')
    if stage.unitClickTest(23):
        stage.say('&23\n상대가 공명이니,\n가는 길에 적의 매복을 조심해야 합니다.')
    if stage.unitClickTest(1):
        stage.say('&1\n저도 예전에는 그 남자주유 싫어했어요.\n하지만 그는 공명에 의해 해를 입었다,\n그를 위해서가 아니더라도, 그는 공명의 야망을 짓밟아야 한다!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
