# Source Generated with Decompyle++
# File: R_46.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 59)
    stage.showUnit(57, 49, 8, 2)
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('죽음의 징조별의 빛')
    stage.setStageName('장안 외곽의 산길')
    stage.unit(57).move(49, 18, 2)
    stage.showUnits([
        [
            58,
            45,
            8,
            2],
        [
            9,
            53,
            8,
            2]])
    stage.unitsMove([
        [
            stage.unit(57),
            49,
            45,
            2],
        [
            stage.unit(58),
            45,
            35,
            2],
        [
            stage.unit(9),
            53,
            35,
            2]])
    stage.unit(57).setAction(0)
    stage.unit(58).setAction(0)
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(57).setAction(2)
    stage.say('&57\n젠장, 아버지의 복수를 거의 할 뻔했는데!\n&58\n네 기분 이해해,\n하지만 지금은,\n유일한 선택지는 목숨을 걸고 도망치는 것이었다.')
    stage.unit(57).setAction(0)
    stage.delay(3)
    stage.unit(57).setAction(0, 0)
    stage.say('&57\n흠, 흠.........\n그런데 어디로 가야 하지?')
    stage.unit(9).setAction(6)
    stage.say('&9\n한중으로 가는 게 좋을 것 같아.')
    stage.unit(9).setAction(0)
    stage.say('&57\n한중 ...... 장루, 저기 있니?\n&58\n네, 저도 그렇게 생각했어요.\n가장 가깝고 영향권 밖조조,\n한중만 남았다.\n&57\n…… 정말? 음.\n한중에서 출발합니다.')
    stage.unit(57).setAction(0, 2)
    stage.delay(3)
    stage.unit(57).setAction(2)
    stage.say('&57\n조만간 아버지의 죽음을 복수할 거야!')
    stage.unit(57).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(57),
            49,
            95,
            2],
        [
            stage.unit(58),
            45,
            95,
            2],
        [
            stage.unit(9),
            53,
            95,
            2]])
    stage.unit(57).hide()
    stage.unit(58).hide()
    stage.unit(9).hide()
    stage.effectSound(203, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 242, 61)
    stage.showHead(57, 178, 61)
    stage.bottomTxt('마초와 다른 이들이 패배조조', False, False, False)
    stage.delay(5)
    stage.showHead(140, 106, 96)
    stage.delay(5)
    stage.bottomTxt('한중에서 장루에게 피신했다,', True, False, False)
    stage.delay(5)
    stage.head(57).move(170, 96)
    stage.delay(5)
    stage.bottomTxt('그들은 임시 머물 곳이 있었다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene1():
    stage.loadBg(2, 28)
    stage.showUnits([
        [
            19,
            68,
            42,
            1],
        [
            181,
            52,
            79,
            1],
        [
            182,
            54,
            46,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.info('반면 조조 쉬두로 돌아갔다......', 3)
    stage.setStageName('수두, 총리 관저 앞')
    stage.showUnit(0, 68, 94)
    stage.unit(0).move(68, 65, 0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n수고 많으셨습니다.')
    stage.unit(181).setAction(11)
    stage.say('&181\n아! 그래, 그래, 주군.\n&0\n특별한 점이 있나요?')
    stage.unit(182).setAction(11)
    stage.say('&182\n아니요, 이상은 없습니다.\n&0\n흠.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n……응?\n저기 저 사람이 뭘 하고 있는 거지?\n&181\n저 사람은 두 시 전부터,\n계속 서서 하늘만 보고 있어.\n&0\n오……?')
    stage.unit(0).move(68, 50, 0)
    stage.unit(0).setAction(0)
    stage.unit(181).setAction(0)
    stage.unit(182).setAction(0)
    stage.say('&0\n여기서 뭐 하는 거야?\n&19\n하늘을 보고 있어.\n&0\n하늘을 보고 있었나요?\n&19\n하늘을 바라보고, 바람 소리를 듣고,\n땅의 향기를 들이마시며.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그래서 그런 거구나......\n하루 종일 이러세요?\n&19\n네.\n&0\n명문 가문 출신인 것 같군요,\n이렇게 혼란스러움을 그냥 견뎌낼 생각이야?\n&19\n때가 되면 자연스럽게 행동에 나설 것입니다.\n때가 올 때까지는 이게 유일한 방법이야.\n&0\n타이밍을 이렇게 봐,\n그러면 언제 행동해야 할지 알게 되죠.\n&19\n나는 다른 사람들이 모르는 것들도 알고 있다,\n세상의 모든 것이 내 통제 아래 있는 것 같아.')
    model.setFace(3)
    stage.say('&0\n오...... 흥미롭네.\n그래서, 세계 상황에 대해 여쭤봐도 될까요, 선생님?\n&19\n바람은 사람들의 불만을 실어 나르고,\n땅은 피의 악취로 가득하다,\n혼란은 오랫동안 계속될 것이다.\n&19\n더불어, 밤하늘은 왕국의 삼분을 묘사한다.')
    model.setFace(0)
    stage.say('&0\n그 시대의 혼란을 예견할 수 있겠는가?\n흥미롭네요!\n이른바 삼국시대란 정확히 무엇인가요?\n&19\n삼국은 유현덕 슈 왕국을 가리킨다,\n손중모 우와 조맹덕 웨이.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n유비 슈 왕국?\n혹시 유비 서촨을 점령하려는 의도일까?\n&19\n틀림없어.\n곧 소식이 전해질 거야.')
    stage.say('&0\n너...... 이름이 뭐야?\n&19\n제 이름은 사마의이고, 자식은 중달입니다.\n&0\n때가 되면 행동하겠다고 했잖아,\n아직 때가 아니야?')
    stage.effectSound(203, 255)
    stage.bgSound(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.say('&19\n아니요...... 때가 왔습니다.\n총리가 나에게 질문했을 때,\n바로 그때 내가 행동에 나서야 해.')
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n하하하.\n중달, 나랑 같이 들어가.\n당신을 제 전략가로 초대하고 싶습니다.')
    stage.unit(19).setAction(6)
    stage.say('&19\n네!')
    model.unitJoin(19, 0, 0)
    if vars[1013]:
        gvars[0] = 19
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    model.setFace(0)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 329, 99)
    stage.bottomTxt('이 시점에서,', False, False, False)
    stage.delay(8)
    stage.showHead(32, 278, 207)
    stage.delay(5)
    stage.bottomTxt('징저우 유비', True, False, False)
    stage.delay(5)
    stage.bottomTxt('삼자 분할의 비전을 실현하기 위해, 제갈량', True, False, False)
    stage.delay(5)
    stage.showHead(160, 9, 172)
    stage.delay(5)
    stage.bottomTxt('그들은 공격적으로 나서고 있습니다', True, True, False)
    stage.delay(5)
    stage.head(32).move(154, 177)
    stage.delay(5)
    stage.bottomTxt('류장의 통치 하에 있는 슈 왕국.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('유비군의 진격은 비교적 순조롭게 진행되었다.', True, False, False)
    stage.delay(5)
    stage.head(32).move(73, 135)
    stage.delay(5)
    stage.bottomTxt('그곳은 류장의 청두 기지에서 단 한 걸음 떨어진 곳이었다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            32,
            53,
            37,
            2],
        [
            90,
            42,
            52,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('청두 교외, 유비군 본진')
    stage.say('&32\n휴, 정말 힘든 일이네요......\n&32\n청두에서 단 한 걸음 떨어져 있지만,\n그러나 류장의 군대는 여전히 끈질기게 저항했다.')
    stage.unit(32).setAction(0, 1)
    stage.say('&32\n이제 병사들이 피로의 징후를 보이기 시작했다,\n하지만 상황은 진전되지 않았다......')
    stage.unit(32).setAction(0, 2)
    stage.delay(3)
    stage.unit(32).setAction(3)
    stage.say('&32\n시위안, 징저우 공명에게 도움을 청해야 해.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(90).setAction(6)
    stage.say('&90\n주군 말씀이 전적으로 맞습니다.\n힘에 의존하고 억지로 나아가기보다는,\n완전한 안보를 위해 지원을 구하는 것이 더 나을 것입니다.')
    stage.delay(3)
    stage.unit(32).setAction(3)
    stage.say('&32\n알겠어, 바로 공명에게 편지 쓸게.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(90).setAction(0)
    stage.say('&90\n......')
    stage.unit(90).setAction(0, 2)
    stage.say('&90\n(어젯밤, 내 장군성 옆에는 빛나는 마귀 별이 있었다. )\n&90\n(저건 데스 오멘 스타, 데스 스타로 알려진 곳이야!)\n이 전투에서 죽게 되는 걸까......? )\n&32\n무슨 일이야, 방통?\n그의 표정은 좋지 않았다.')
    stage.unit(90).setAction(0, 1)
    stage.delay(3)
    stage.unit(90).setAction(6)
    stage.say('&90\n응? 아무것도 아니야, 제발 주군 걱정하지 마.\n&32\n정말?\n좋네요.\n…… 시위안, 너무 강하게 굴지 마.\n&90\n네.')
    stage.unit(90).setAction(0)
    stage.say('&90\n(주군 진정으로 공감 능력이 뛰어난 사람입니다.\n…… 주군 아직 죽을 수 없어. )')
    stage.unit(90).setAction(0, 2)
    stage.say('&90\n(공명 죽음의 징조 별도 눈치챘을 거야. )\n&90\n(증원군이 도착하고 상황이 바뀔 때마다,\n어쩌면 이 재앙에서 벗어날 수 있을지도 몰라. )')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(160, 11, 177)
    stage.showHead(32, 75, 138)
    stage.bottomTxt('유비 증원 요청 편지,', False, False, False)
    stage.delay(5)
    stage.bottomTxt('곧이어 그는 징저우 주둔지로 보내졌다', True, True, False)
    stage.delay(5)
    stage.showHead(35, 279, 208)
    stage.delay(5)
    stage.bottomTxt('제갈량 역.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 49)
    stage.showUnit(35, 54, 74)
    stage.draw()
    stage.effectSound(204, 0)
    stage.delay(3)
    stage.setStageName('장링 유비 거주지')
    stage.say('&35\n흠, 흠......')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n이 편지의 내용을 보면,\n비록 주군의 군대가 치열한 전투에 몰두했지만,\n시위안의 힘으로 보면 지원군은 필요 없을 것이다.\n&35\n하지만 시위안의 일반 별 옆에는 죽음의 징조 별이 있었다,\n시위안도 이를 눈치챘을 것이다.')
    stage.unit(35).setAction(11)
    stage.say('&35\n그는 절대 시위안이 조금이라도 고통받는 것을 절대 허락할 수 없었다,\n즉시 증원군을 보내야 합니다......')
    stage.unit(35).setAction(0)
    stage.say('&35\n으으!!')
    stage.unit(35).setAction(8)
    stage.say('&35\n음...... 아, 이거 큰일이야......\n마침내 도착했다......\n&35\n하지만 바로 지금 이 순간만큼은......')
    stage.unit(35).setAction(12)
    stage.say('&35\n와!')
    stage.delay(10)
    gvars[0] = 207
    stage.setUnitAttr(35, 1, gvars[0])
    gvars[2035] = 79
    stage.setFAvatar(35, 89)
    if vars[1002]:
        gvars[4076] = 1
        pvars[290] = 4225232
        stage.varOper(0, 290, 2, 0, 10)
        gvars[4076] = 0
    stage.unit(35).setAction(8)
    stage.say('&35\n…… 흥.')
    stage.unit(35).setAction(0)
    stage.say('&35\n먼저 방통 내보내자.')
    stage.unit(35).setAction(17)
    stage.say('&35\n하하하!')
    stage.effectSound(204, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 3)
    stage.showUnit(19, 56, 69, 2)
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('쉬사마의 주')
    stage.say('&19\n방통 서쪽 밤하늘의 제너럴 스타 옆에 위치해 있습니다.\n어젯밤, 실제로 죽음의 징조별이 나타났다.\n&19\n방통 청두를 공격하러 유비를 따라갔다는 소문을 들었습니다.\n&19\n죽음 자오싱은 방통 이 전투에서 죽을 것이라고 말했다.')
    stage.unit(19).setAction(0, 1)
    stage.say('&19\nHowever공명 죽음의 징조도 감지했어야 했다,\n그는 결코 가만히 앉아 방통가 곤경에 처해 죽는 것을 지켜보지 않을 것이다.\n&19\n그 결과.........\n유비 곧 슈에 들어가려 한다고 말하며,\n삼자 체제가 곧 도래하고 있었다.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            32,
            53,
            37,
            2],
        [
            90,
            42,
            52,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('청두 교외, 유비군 본진')
    stage.say('&32\n시위안, 공명 답장이 도착했다.')
    stage.unit(90).setAction(6)
    stage.say('&90\n아, 그게 사실이야?\n그럼 증원군은 언제 도착하나요?\n&32\n이 ......\n&32\n편지에는 현재 징저우 방어가 약하다고 적혀 있었다,\n그들은 아직 위급한 상황에 처해 있어 증원군을 보내는 것은 적절하지 않다.')
    stage.unit(90).setAction(0)
    stage.say('&90\n뭐라고!\n어떻게 그럴 수 있......\n&32\n흠......\n하지만 이해할 만합니다,\n현재 병력으로 공격합시다.')
    stage.unit(90).setAction(6)
    stage.say('&90\n......')
    stage.unit(90).setAction(0)
    stage.say('&90\n(공명 내 인생이 위태로운 상황임을 알 수 없었다...... )\n&90\n(게다가 이 시기에 위와 우는 징저우를 공격하지 않을 것이다...... )')
    stage.unit(90).setAction(0, 2)
    stage.say('&90\n(그렇다면 왜 공명 지원군을 보내지 않는 거지!? )')
    stage.unit(90).setAction(0, 1)
    stage.delay(3)
    stage.unit(90).setAction(6)
    stage.say('&90\n주군......\n내일 전투를 위해 시위안이 진형을 지휘하게 하라,\n상황에 따라 후방을 주군해 주세요.\n&32\n좋아.')
    stage.unit(90).setAction(0)
    stage.say('&90\n(그걸 주군 못 참겠어,\n전장에서 내 목숨을 걸 거야. )')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene6():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(160, 11, 177)
    stage.showHead(32, 139, 138)
    stage.bottomTxt('다음 날,', False, False, False)
    stage.delay(8)
    stage.showHead(90, 75, 138)
    stage.delay(5)
    stage.bottomTxt('유비 Army방통 부전략가', True, True, False)
    stage.delay(5)
    stage.bottomTxt('그는 선봉군을 이끌고 청두를 공격했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('그러나 뤄펑 경사면에서 적군군의 매복 공격을 받았다.', True, True, False)
    stage.delay(5)
    stage.head(90).hide()
    stage.delay(5)
    stage.bottomTxt('펑추는 그 자리에서 죽었다.', True, False, True)
    stage.bgSound(13)
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            32,
            53,
            37,
            2],
        [
            36,
            42,
            52,
            1],
        [
            37,
            42,
            58,
            1],
        [
            46,
            67,
            52,
            3]])
    stage.draw()
    stage.setStageName('청두 외곽 근처의 @유비군 본진지')
    stage.unit(32).setAction(3)
    stage.say('&32\n뭐라고!?\n시겐이 죽였다!!')
    stage.unit(37).setAction(0, 0)
    stage.say('&37\n그래, 전략가는 화살투성이에 피투성이였다,\n도착했을 때 이미 숨이 차고 있었어요.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(9)
    stage.say('&32\n시위안 ......\n내 시위안이 죽었어......')
    stage.unit(36).setAction(6)
    stage.say('&36\n전략가는 전투에서 전사했고, 아군는 패배해 도망쳤다.\n주 진영은 전면과 후방 모두에서 포위되어 붕괴 직전이었다.')
    stage.unit(36).setAction(0)
    stage.say('&32\n무슨 ......?')
    stage.unit(46).setAction(0, 0)
    stage.say('&46\n주군, 유일한 방법은 징저우에 지원을 요청하는 것뿐이다!\n&32\n흠.\n관평, 즉시 외교 임무로 징저우로 가야 합니다.\n&46\n네.\n&32\n왜 그럴까요......\n방통 아......')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene7():
    stage.loadBg(2, 49)
    stage.showUnits([
        [
            35,
            53,
            74],
        [
            3,
            40,
            55,
            1],
        [
            33,
            40,
            49,
            1],
        [
            34,
            67,
            55,
            3],
        [
            46,
            53,
            55,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('장링 유비 거주지')
    stage.say('&35\n그래...... 시위안은 전투에서 죽었어......\n비범한 재능이 있어도 여전히 ......')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n(하하하.\n내가 너무 쉽게 처리했어. )\n&46\n전략가, 아군 현재 위험한 상황에 처해 있다,\n즉시 증원군을 보내 주십시오.')
    stage.unit(35).setAction(0, 0)
    stage.say('&35\n이해했어.\n즉시 증원군을 이끌겠습니다.\n이데와 쯔롱은 즉시 출발할 준비를 했다.')
    stage.unit(33).setAction(0, 2)
    stage.delay(3)
    stage.unit(33).setAction(3)
    stage.say('&33\n오!\n형이 곤경에 처했으니 바로 갈게!')
    stage.unit(33).setAction(0)
    stage.delay(3)
    stage.unit(34).setAction(0, 2)
    stage.delay(3)
    stage.unit(34).setAction(6)
    stage.say('&34\n네.')
    stage.unit(34).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 2)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n…… 전략가, 내 동생도 구하러 가게 해줘.\n&35\n관장군이 징저우에 남아 그 자리를 지키길 원합니다.\n&35\n위와 우는 징저우의 준비 부족을 틈타 공세를 개시할 수도 있다.\n&3\n…… 좋아.\n그렇다면 저는 머무를 수밖에 없습니다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n(앞으로는 관우가 징저우를 지키도록 남겨야 한다.\n흠...... )')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene8():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(160, 11, 177)
    stage.showHead(32, 75, 138)
    stage.showHead(35, 279, 208)
    stage.delay(5)
    stage.bottomTxt('제갈량', False, False, False)
    stage.delay(5)
    stage.head(35).move(75, 218)
    stage.delay(5)
    stage.bottomTxt('그리고 병력을 이끌고 유비를 지원했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('유비군은 증원군 도착으로 위험을 피했고,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('북소리 한 번에 사기가 방어에서 공격으로 바뀐다,', True, False, False)
    stage.delay(5)
    stage.head(160).hide()
    stage.delay(5)
    stage.head(32).move(11, 138)
    stage.delay(3)
    stage.head(32).move(11, 177)
    stage.delay(5)
    stage.bottomTxt('결국 그들은 청두를 성공적으로 점령했다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            50,
            41,
            2],
        [
            23,
            56,
            41,
            2],
        [
            24,
            62,
            41,
            2],
        [
            21,
            68,
            41,
            2],
        [
            19,
            74,
            41,
            2]])
    stage.draw()
    stage.effectSound(204, 0)
    stage.delay(3)
    stage.info('며칠 후에......', 3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n그렇습니까? 유현덕 정말로 슈 지역을 점령했습니까?')
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 방금 보고서를 받았습니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n게다가 군대의 혼란 속에서 방통 죽었다는 이야기도 전해진다.')
    stage.unit(24).setAction(0)
    model.setFace(1)
    stage.say('&0\n뭐라고?\n방통 펑추가 죽었어?')
    stage.unit(19).setAction(6)
    model.setFace(0)
    stage.say('&19\n이 일은 수상해 보입니다.\n&0\n오, 중달, 뭐가 이상하다고 생각해?\n&19\n나는 한때 천체 현상을 관찰했다,\n만약 네가 방통가 위험에 처했다는 걸 더 일찍 알았다면,')
    stage.unit(19).setAction(0)
    stage.say('&19\n나는 공명와 방통 같은 대가들이 있다고 믿는다,\n그가 이 사실을 몰랐을 리가 없다.')
    stage.unit(19).setAction(0, 3)
    stage.say('&19\n그들은 필연적으로 어떤 수단도 쓸 것이다,\n재앙이 닥치지 않도록 하기 위해서......\n&0\n무슨 말을 하고 싶어?')
    stage.unit(19).setAction(6)
    stage.say('&19\n그의 부하들은 방통의 죽음을 믿었다,\n아마도 누군가의 걸작에서 나온 것일 것이다.')
    stage.unit(19).setAction(0)
    stage.say('&19\n방통 자신의 위험을 깨닫고,\n위험을 피하기 위해 가능한 모든 것을 다한 후,\n하지만 누군가에게 방해가 있었다......')
    stage.say('&0\n음, 이 추측은 꽤 흥미롭네요,\n제 생각에는 아마도 너무 깊게 생각하는 것 같아요.\n&0\n방통 곧 천막 아래로 보내졌유비,\n유비의 신뢰는 공명만큼 깊지 않다,\n그의 죽음은 아마도 조급함과 조급함의 결과였을 것이다.')
    stage.unit(19).setAction(6)
    stage.say('&19\n아마도......')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.say('&19\n(내 마음은 큰 슬픔으로 가득 차 있다,\n끔찍한 일이 곧 일어날 것 같았다...... )')
    stage.effectSound(204, 255)
    stage.clsUnit()
    return False


def scene9():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 332, 98)
    stage.showHead(32, 23, 170)
    stage.delay(5)
    stage.bottomTxt('유비', False, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 서나라로부터 광대한 영토를 획득했다.', True, False, False)
    stage.delay(10)
    stage.showHead(76, 569, 231)
    stage.delay(5)
    stage.bottomTxt('손권 측면에 관해서는,', True, True, False)
    stage.delay(5)
    stage.head(76).move(497, 212)
    stage.delay(5)
    stage.bottomTxt('그는 수도를 오에서 건예로 옮겼다,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그리고 조조와 유비에 맞서겠다는 결의를 보여주고 있습니다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('따라서 위나라의 조조 상태는,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('유비 슈 왕국,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('손권 우는 삼자 대치 상황을 형성했다.', True, False, True)
    stage.bgSound(-1)
    stage.delay(3)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            20,
            50,
            41,
            2],
        [
            23,
            56,
            41,
            2],
        [
            24,
            62,
            41,
            2],
        [
            21,
            68,
            41,
            2],
        [
            19,
            74,
            41,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n최신 유비 동향을 알고 계신가요?')
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 주군.\n청두를 점령하기 직전,\n마초와 다른 이들은 유비에 복종했다.')
    stage.unit(20).setAction(0)
    model.setFace(2)
    stage.say('&0\n길들여진 마초......? 저 귀 큰 도둑!\n다른 사람들은 어때?')
    model.setFace(0)
    stage.unit(19).setAction(6)
    stage.say('&19\n전 서나라 통치자 류장은 징저우로 이주하여 정착했다.')
    stage.say('&0\n흥, 심지어 자신의 가문 구성원들조차 자비를 베풀지 않았다,\n유비 정말 조심스럽습니다.\n&19\n아마 공명 아이디어일 거야.')
    stage.unit(19).setAction(0)
    stage.say('&0\nNow유비 그들은 서나라로부터 광대한 영토를 얻었고,\n그리고 마초 무적의 영웅을 얻었다,\n우리는 더 이상 이를 무시할 수 없습니다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n즉시 군대를 보내 유비 처벌하라!\n아무도 반대하지 않는 것 같아요, 맞죠?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n아군 동우를 공격하지 않는 한,\n손권 아군에 대해 조치를 취해서는 안 됩니다.\n현재 우리에게 위협이 되는 유일한 것은 유비입니다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n유비 슈에 온 지 얼마 되지 않았다,\n백성들의 마음이 아직 달래지지 않은 것 같다,\n지금이 바로 공격할 완벽한 타이밍입니다!')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n하지만 만약 유비를 공격하고 싶다면,\n그는 먼저 한중의 장루를 상대로 원정을 벌여야 한다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n저도 그렇게 생각해요.\n유비 한중을 탐욕스럽게 바라보는 것으로 여겨진다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('좋습니다, 먼저 장루를 토벌하겠습니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.showUnit(17, 90, 55, 3)
    stage.effectSound(200, 255)
    stage.bgSound(17)
    stage.delay(3)
    stage.say('&17\n총리님, 이 젊은 여성의 말씀을 한 번 들려주시겠습니까?')
    stage.unit(17).move(46, 55, 3)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n장루 영주는 세상을 지배하려는 사람이 아니었다.\n&17\n그가 평화를 추구하는 것은 오직 믿음을 통해서였다.\n&17\n총리께 양국 간 전쟁을 촉발하지 말 것을 촉구합니다.\n장루 공초선 항복할 기회를 줘.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n정말 힘들겠네요.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(0, 1)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n저도 신앙을 추구하는 황번 신자 어머니에서 태어났습니다.\n&17\n종파마다 다르지만,\n하지만 사람을 돌보는 철학도 다르지 않습니다.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n왕윤 공의 딸 아니었나요......\n정확히 무슨 일이 있었던 거야?')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n아니요, 대부님, 왕윤 경,\n내 친아버지가 아니라,\n부모님 두 분 다 태평도의 황번파 신자셨습니다.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n무슨 ......?')
    stage.unit(23).setAction(0)
    stage.say('&17\n부모님은 황단의 백성 구원이라는 이상에 감동받으셨습니다,\n그래서 그들은 국민을 박해하는 정부군과 귀족들과 싸웠다.')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n그러나 얼마 지나지 않아 황번당은 폭력적인 세력으로 변모했다.\n원래의 이상을 완전히 잃는 것.\n&17\n이 무의미한 싸움 속에서, 내 부모님은,\n그는 반란을 진압하러 온 정부군에 의해 살해되었다.\n&17\n그때 나는 어렸고 부모님의 유해 옆에서 울 수밖에 없었다.')
    stage.unit(17).setAction(0, 1)
    stage.say('&17\n나중에 정부군을 이끈 왕윤 공이 초선 목격했다,\n그때서야 그들은 그들을 받아들이고 초선 성인으로 키웠다.')
    stage.unit(17).setAction(6)
    stage.say('&17\n부모님은 모든 사람을 구하는 이상에 대해 이야기해 주셨다,\n나는 지금도 그 순간을 마음속에 새겨 기억한다.\n&17\n오두미파의 수장님, 장루 경께서,\n그의 이상은 모든 사람을 구하는 것입니다.\n&17\n장루 경이 진심으로 백성을 아낀다면,\n왜 전쟁을 일으켜 사람들에게 고통을 주는가?')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n그래서 그런 거구나......\n황번교를 계승한 초선이 떠난다면,\n아마 장루가 경계를 늦출지도 몰랐다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n장루의 반응을 지켜보고 군대를 보내는 것도 늦지 않았다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n좋아.\n초선, 네가 처리하길 바라.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(0, 3)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n네, 시에 재상님.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(17).move(98, 55, 1)
    stage.unit(17).hide()
    stage.say('&0\n…… 초선 그런 불행한 경험을 할 줄은 전혀 예상하지 못했습니다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene10():
    stage.loadBg(2, 31)
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('한중 외곽의 산길')
    stage.showUnits([
        [
            181,
            95,
            56,
            3],
        [
            17,
            95,
            48,
            3]])
    stage.unitsMove([
        [
            stage.unit(181),
            50,
            56,
            3],
        [
            stage.unit(17),
            50,
            48,
            3]])
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n장루 영주의 영지에 도착한 후에야 깨달았다\n알고 보니 사람들은 진정으로 풍요로운 삶을 살고 있었습니다.')
    stage.unit(17).setAction(6)
    stage.say('&17\n장루 공은 정말 명성에 걸맞은 사람이야.\n무슨 일이 있어도 그를 설득해야 해,\n한중이 전쟁의 재앙에서 벗어나게 하라.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(181).setAction(0, 0)
    stage.say('&181\n응?')
    stage.showUnits([
        [
            187,
            95,
            48,
            3],
        [
            188,
            95,
            56,
            3]])
    stage.unitsMove([
        [
            stage.unit(187),
            85,
            48,
            3],
        [
            stage.unit(188),
            85,
            56,
            3]])
    stage.say('&187\n잠시만 기다려 주세요!')
    stage.unit(181).setAction(0, 1)
    stage.say('&181\n응?')
    stage.unit(17).setAction(0, 1)
    stage.say('&17\n(응? )')
    stage.unitsMove([
        [
            stage.unit(187),
            60,
            48,
            3],
        [
            stage.unit(188),
            60,
            56,
            3]])
    stage.unit(187).setAction(0)
    stage.unit(188).setAction(0)
    stage.say('&188\n아, 아, 드디어 따라잡았네.')
    stage.unit(17).setAction(6)
    stage.say('&17\n필요한 게 있나요?')
    stage.unit(17).setAction(0)
    stage.say('&187\n초선 여자야?')
    stage.unit(17).setAction(6)
    stage.say('&17\n내 이름 알아?\n두 분이 누구시죠......')
    stage.unit(17).setAction(0)
    stage.say('&188\n우리는 전에 네 부모님이 돌봐줬어.\n&187\n정부군과의 전투 이후로,\n실종된 당신을 찾고 있었습니다.')
    stage.unit(17).setAction(3)
    stage.say('&17\n그래서, 너희 둘 부모님 알아?')
    stage.unit(17).setAction(0)
    stage.say('&188\n네, 며칠 전에야 당신이 조 진영에 있다는 걸 알게 됐어요.\n&187\n한중이 전쟁의 참상을 겪지 않도록 하기 위해,\n그래서 그는 장루 공을 설득하러 가기로 했다.\n&188\n당신은 진심으로 형과 형수의 좋은 딸이 될 자격이 있어요.\n&187\n앞으로는 저희가 도와드리겠습니다 초선 아가씨,\n어떻게 생각하세요?')
    stage.unit(17).setAction(6)
    stage.say('&17\n그래서 그런 거구나......\n이제 두 용감한 분께 감사드립니다.')
    stage.unit(17).setAction(0)
    stage.say('&188\n이 기회를 주셔서 감사합니다!\n그러니까 바로 한중으로 가자.\n&187\n좋아, 가자.')
    stage.unitsMove([
        [
            stage.unit(181),
            5,
            56,
            3],
        [
            stage.unit(17),
            5,
            48,
            3],
        [
            stage.unit(187),
            15,
            48,
            3],
        [
            stage.unit(188),
            15,
            56,
            3]])
    stage.unit(181).hide()
    stage.unit(17).hide()
    stage.unitsMove([
        [
            stage.unit(187),
            5,
            48,
            3],
        [
            stage.unit(188),
            5,
            56,
            3]])
    stage.unit(181).hide()
    stage.unit(181).hide()
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene11():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 334, 98)
    stage.showHead(140, 97, 78)
    stage.showHead(17, 161, 78)
    stage.bottomTxt('며칠 후,', False, False, False)
    stage.delay(8)
    stage.bottomTxt('초선 장루를 성공적으로 설득했다.', True, True, False)
    stage.delay(5)
    stage.head(140).hide()
    stage.delay(5)
    stage.bottomTxt('장루는 성문을 열고 항복했다,', True, False, False)
    stage.delay(8)
    stage.head(17).move(97, 78)
    stage.head(0).move(161, 78)
    stage.delay(5)
    stage.bottomTxt('조조 한중성에 들어갔다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 44)
    stage.showUnits([
        [
            0,
            53,
            35,
            2],
        [
            20,
            39,
            52,
            1],
        [
            23,
            39,
            58,
            1],
        [
            24,
            39,
            64,
            1],
        [
            21,
            39,
            70,
            1],
        [
            19,
            39,
            76,
            1],
        [
            1,
            69,
            52,
            3],
        [
            6,
            69,
            58,
            3],
        [
            17,
            69,
            64,
            3],
        [
            140,
            53,
            52]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('한중: 임시 총리실')
    stage.say('&0\n장루 공, 당신의 결정은 옳았습니다.')
    stage.unit(140).setAction(6)
    stage.say('&140\n정말로, 초선 아가씨께서 위대한 원칙들로 저를 깨우쳐 주셨습니다,\n저는 재상께서 분명히 한중을 지켜줄 수 있을 거라 믿습니다.')
    stage.unit(140).setAction(0)
    stage.say('&0\n음, 삶의 안정과 신앙의 자유에 관해서는,\n조조가 보증을 제공할 수 있습니다.\n당신은 당신의 컬트 활동에 집중할 수 있습니다.')
    stage.unit(140).setAction(6)
    stage.say('&140\n그는 총리에게 감사를 표했다.')
    stage.unit(140).setAction(0)
    stage.say('&140\n총리님.\n&0\n응? 무슨 일이야?\n&140\n최근에는 세상이 세상에 스며드는 것을 느꼈습니다......\n전례 없는 악마의 기운이었다.')
    stage.unit(140).setAction(6)
    stage.say('&140\n특히 조심하세요.\n그럼 저는 이만 가보겠습니다.')
    stage.unit(140).setAction(0)
    stage.delay(3)
    stage.unit(140).move(53, 95, 2)
    stage.unit(140).hide()
    stage.showUnit(181, 53, 95)
    stage.delay(8)
    stage.unit(181).move(53, 90, 0)
    stage.unit(181).setAction(0)
    stage.say('&181\n주군, 한중의 방덕 장군이 도착했다.\n&0\n흠, 부탁해요.')
    stage.unit(181).move(53, 95, 2)
    stage.unit(181).hide()
    stage.delay(10)
    stage.showUnits([
        [
            9,
            53,
            90],
        [
            181,
            50,
            96],
        [
            182,
            56,
            96]])
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(9),
            53,
            48,
            0],
        [
            stage.unit(181),
            50,
            54,
            0],
        [
            stage.unit(182),
            56,
            54,
            0]])
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n방덕, 마지막으로 본 지 며칠이 지났어.')
    stage.unit(0).setAction(0)
    stage.say('&0\n난 너에 대해 다 알고 있어.\n병으로 한중에 남겨졌고,\n그럼 마초 원정대에 같이 가지 않았지?\n&9\n내 목을 원하겠지?\n그만 말하고 빨리 죽여!\n&0\n왜 내가 널 죽여야 하지?\n&9\n나는 한때 당신의 적이었고,\n내 목을 베는 건 당연한 일이야.\n&0\n널 죽일 생각은 없어.\n방덕, 너는 나를 섬기기 위해 살아야 해.\n&9\n…… 그럴 리 없어.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n내가 네 전 스승 마텡을 죽였기 때문이냐?\n&9\n사실, 지금도 나는 네 목숨을 원해!\n빨리 날 죽여버려!')
    stage.unit(0).setAction(0, 2)
    stage.say('아니, 이렇게 죽게 놔두지 않을 거야. 내가 너를 내 근위대 장수로 임명해서, 항상 나를 지키게 할 거야. 네가 날 우롱하는 거냐!? 내가 기회를 봐서 너를 죽일지도 몰라!')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n날 죽일 기회를 찾고 있는 거야?\n&9\n맞아요, 이게 바로 어려운 시대의 방식입니다.')
    model.setFace(3)
    stage.say('&0\n아, 어려운 시대의 방식이구나, 그렇지?\n이 말은 꽤 쉽게 들립니다.\n&9\n뭐라고!')
    model.setFace(0)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n그게 내가 할 말의 전부야.\n네가 어떻게 생각하든,\n이제 선택의 여지가 없어.')
    stage.unit(0).setAction(17)
    stage.say('방덕을 근위대 막사로 데려가세요.')
    stage.unit(0).setAction(0)
    stage.say('&181\n네.')
    stage.unitsMove([
        [
            stage.unit(181),
            50,
            48,
            1],
        [
            stage.unit(182),
            56,
            48,
            3]])
    stage.delay(3)
    stage.unit(9).setAction(0, 2)
    stage.say('&9\n음......')
    stage.unit(9).move(53, 51, 2)
    stage.unit(9).setAction(0)
    model.unitJoin(9, 0, 0)
    if vars[1013]:
        gvars[0] = 9
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.setJoinEquip(9, -1, 0, -1, 0, 12)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(9),
            53,
            98,
            2],
        [
            stage.unit(181),
            50,
            95,
            2],
        [
            stage.unit(182),
            56,
            95,
            2]])
    stage.unit(181).hide()
    stage.unit(182).hide()
    stage.unit(9).hide()
    stage.delay(10)
    stage.showUnit(183, 53, 95)
    stage.unit(183).move(53, 90, 0)
    stage.unit(183).setAction(0)
    stage.say('&183\n주군, 쑤 국경에서 조홍 장군이 보고하러 왔다,\n유비군은 딩준산을 공격하기 시작했다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n유비군이 딩준산을 공격하고 있나?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n분명 공명 생각일 거야,\n쑤 군대가 너무 빠르게 움직였다......')
    stage.unit(19).setAction(0)
    stage.say('&0\n조홍 혼자서는 이기기 어려우니,\n당장 군대를 보내 구원해야 합니다.\n&0\n하후연!')
    stage.unit(6).setAction(0, 0)
    stage.say('&6\n오!\n&0\n선봉을 맡아 즉시 딩준산으로 달려가라,\n장합...... 방덕 부장군으로 활동했다.')
    stage.unit(6).setAction(6)
    stage.say('&6\n방덕? 이봐, 이봐, 괜찮아, 장합\n하지만 나는 방덕을 믿을 수 없다.\n그게 바로 슈 군 진영 안에 있다는 걸 forget마초하지 마라!')
    stage.unit(6).setAction(0)
    stage.say('&0\n방덕은 걱정 마. \n&6\n……알겠어.\n그럼 내가 먼저 준비할게. 미련을 두고 물러가겠다!')
    stage.unit(0).setAction(17)
    stage.say('&0\n흠, 주력 부대가 재편성되면 나도 출발할 거야.\n내가 도착하기 전에, 무슨 일이 있어도 참아!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(6).move(75, 58, 1)
    stage.delay(3)
    stage.unit(6).move(75, 95, 2)
    stage.unit(6).hide()
    stage.unit(183).move(53, 95, 2)
    stage.unit(183).hide()
    stage.delay(10)
    stage.effectSound(200, 255)
    stage.bgSound(18)
    stage.delay(3)
    stage.showUnit(181, 53, 95)
    stage.unit(181).move(53, 90, 0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군! 조장의 후계자가 도착했다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n조창? \n그가 북방의 이민족 반란 진압에 가지 않았나...?')
    stage.unit(0).setAction(0)
    stage.say('좋습니다. 그를 들어오게 하십시오.\n&181\n네입니다.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).move(53, 95, 2)
    stage.unit(181).hide()
    stage.delay(3)
    stage.showUnit(4, 53, 95)
    stage.unit(4).move(53, 52, 0)
    stage.unit(4).setAction(0)
    stage.delay(3)
    stage.unit(4).setAction(6)
    stage.say('&4\n아버지, 건강하시길 바랍니다.')
    stage.unit(4).setAction(0)
    stage.say('&0\n조창, 네가 왜 한중에 왔느냐?\n반란 진압은 어떻게 되어가고 있느냐?')
    stage.unit(4).setAction(6)
    stage.say('&4\n이미 지역 반란을 진압했으며,\n그래서 아버지께 보고하러 왔습니다.\n&0\n정말......? 좋아, 조장.\n반군이 그렇게 강한 전투력을 가지고 있다고 생각하지 않아요,\n이제부터 내 정규군에 들어가야 해.\n&4\n네, 아버지.')
    model.unitJoin(4, 0, 0)
    if vars[1013]:
        gvars[0] = 4
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene12():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 153, 63)
    stage.bottomTxt('조홍', False, False, False)
    stage.delay(5)
    stage.showHead(12, 83, 74)
    stage.delay(5)
    stage.bottomTxt('딩준산, 위-서 국경을 지키고 있어.', True, False, False)
    stage.delay(8)
    stage.showHead(32, 8, 178)
    stage.delay(5)
    stage.bottomTxt('유비군에 대해 알게 되었다', True, True, False)
    stage.delay(5)
    stage.head(32).move(83, 154)
    stage.delay(5)
    stage.bottomTxt('딩준산 공격 작전 이후,', True, False, False)
    stage.delay(10)
    stage.bottomTxt('조조', True, True, False)
    stage.delay(5)
    stage.head(0).hide()
    stage.showHead(6, 153, 63)
    stage.delay(5)
    stage.bottomTxt('디스패치 immediately하후연', True, False, False)
    stage.delay(5)
    stage.head(6).move(147, 114)
    stage.delay(5)
    stage.bottomTxt('지원군.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            32,
            53,
            37,
            2],
        [
            35,
            42,
            52,
            1],
        [
            33,
            42,
            58,
            1],
        [
            34,
            42,
            64,
            1],
        [
            36,
            67,
            52,
            3],
        [
            57,
            67,
            58,
            3],
        [
            37,
            67,
            64,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.info('그 순간에......', 3)
    stage.setStageName('딩준산, 유비군 본진지')
    stage.say('&32\n공명, 편지가 도착했관우.')
    stage.unit(35).setAction(6)
    stage.say('&35\n윤창 장군의 편지?\n편지 내용은?')
    stage.unit(35).setAction(0)
    stage.say('&32\n그는 징저우를 방어하고 싶지 않았다,\n전선 전투를 생각하고 있습니다.')
    stage.unit(35).setAction(6)
    stage.say('&35\n그러나 정주에 주둔한 것은 윤창 장군뿐이었다,\n그래야만 마음의 평화를 가지고 진전할 수 있습니다.')
    stage.unit(35).setAction(0)
    stage.say('&32\n나도 그걸 알아,\n윤창전이 나를 곤란한 상황에 빠뜨렸어.')
    stage.unit(32).setAction(0, 0)
    stage.say('&32\n하지만 윤창의 마음을 이해해요,\n그는 정말로 둘째 형의 소원을 이루고 싶었다.')
    stage.unit(35).setAction(6)
    stage.say('&35\n하지만......')
    stage.unit(32).setAction(0, 2)
    stage.say('&32\n그래서 차라리 그를 위해 경주를 지키러 돌아가야겠다,\n윤창이 조의 군대와 싸우게 하라고?')
    stage.unit(35).setAction(0)
    stage.say('&35\n…… 좋아.\n주군 표현했으니,\n윤창 장군을 오게 하세요.')
    stage.unit(32).setAction(3)
    stage.say('&32\n고마워요, 공명.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(6)
    stage.say('&35\nHowever공명 조건이 있습니다.\n징저우는 위와 오와 접경한 위험한 지역이다,\n전략적으로 절대 잃어서는 안 되는 위치입니다.')
    stage.unit(35).setAction(0)
    stage.say('&35\n그러니 이데 장군님, 동행해 주십시오.\n&32\n좋아.\n그 덕분에 훨씬 안심이 되었습니다.\n셋째 형님, 어떻게 생각하세요?')
    stage.unit(33).setAction(3)
    stage.say('&33\n물론 할 수 있죠!\n둘째 형은 싸울 전투가 없었다,\n아마도 그들은 오랫동안 그 노래를 갈망해왔을 거예요!')
    stage.unit(33).setAction(0)
    stage.say('&32\n그럼 바로 출발합시다.\n공명, 이건 네게 맡길게.')
    stage.unit(35).setAction(6)
    stage.say('&35\n네, 안심하세요, 주군.')
    stage.unit(35).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(11)
    stage.say('&35\n(음, 그만...... )')
    stage.effectSound(200, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(12, 83, 74)
    stage.showHead(6, 147, 114)
    stage.showHead(32, 83, 154)
    stage.showHead(3, 277, 238)
    stage.bottomTxt('유비', False, False, False)
    stage.delay(5)
    stage.head(32).move(83, 234)
    stage.showHead(35, 83, 154)
    stage.delay(5)
    stage.bottomTxt('한중 전투를 제갈량에게 맡기며,', True, False, False)
    stage.delay(5)
    stage.head(32).move(213, 238)
    stage.delay(5)
    stage.bottomTxt('그는 장비와 함께 징저우로 돌아왔다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene13():
    stage.loadBg(2, 37)
    if vars[311]:
        stage.bgSound(19)
        stage.delay(3)
        stage.showUnit(9, 63, 54, 1)
        stage.draw()
        stage.setStageName('Hanzhong방덕 거주지')
        stage.delay(5)
        stage.say('&9\n내가 너를 배신할 수도 있다는 걸 잘 알면서도,\n그는 나에게 전투에 나가라고 명령하기도 했다......\n정말 조조 생각이 이해가 안 돼......')
        stage.delay(5)
        stage.showUnit(23, 20, 54, 1)
        stage.delay(5)
        stage.say('&23\n방덕 장군님, 잠시 방해 드려도 될까요?')
        stage.unit(9).setAction(0, 3)
        stage.say('&9\n응?')
        stage.unit(9).move(50, 54, 3)
        stage.unit(9).setAction(0)
        stage.delay(3)
        stage.say('&9\n당신이 가후 씨군요.\n조언이 있으신가요?')
        stage.unit(23).move(40, 54, 1)
        stage.unit(23).setAction(0)
        stage.delay(3)
        stage.unit(23).setAction(6)
        stage.say('&23\n장군 방덕, 할 말이 있습니다,\n무슨 일이 있어도 전투에 나가기 전에 장군에게 알려야 해.')
        stage.unit(23).setAction(0)
        stage.say('&9\n도대체 무슨 일이 벌어지고 있는 거죠?')
        stage.unit(23).setAction(6)
        stage.say('&23\n이건 내 일이야.\n장군들이 도착하기 전에,\n시간 보내기 위해 이야기 나누자.')
        stage.unit(23).setAction(0)
        stage.say('&23\n나는 조나라 군대의 전략가다,\n주군의 신뢰와 신뢰를 얻으며,\n하지만 나도 원래 주군의 적이었어.\n&9\n나는 이 일에 대해 오래전부터 알고 있었다,\n원래장수 완 도지사를 맡으셨죠?\n&23\n정확히 그렇습니다.\n나는 조나라 군대와 두 번이나 싸웠다......\n그리고도......\n&23\n그 사건은 주군의 사랑하는 이들의 죽음을 초래했다.')
        stage.unit(9).setAction(6)
        stage.say('&9\n뭐!? 너 그런 과거가 있잖아,\n조조 실제로 너를 전략가로 만들었어,\n그리고 그가 당신을 깊이 신뢰한다고요!?')
        stage.unit(9).setAction(0)
        stage.say('&23\n흠.\n주군 이 일에 대해 나를 탓한 적이 없다.')
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n아마도 왕국을 평정하는 위대한 대의를 위해서였을 것이다,\n그래서 개인적인 원한에 집착하지 않는 거겠지?\n&9\n알고 보니 조조 영주는 개인적인 편견 때문에 싸우는 게 아니야,\n하지만 그는 진심으로 제국의 패권을 위해 태어난 것일까?')
        stage.unit(23).setAction(0, 1)
        stage.say('&23\n흠, 주군의 마음은 광활한 하늘만큼이나 광활하다,\n우리가 이해할 수 있는 범위를 훨씬 넘어서.')
        stage.unit(9).setAction(6)
        stage.say('&9\n…… 그래서 그런 거야.\n정말 깊이 부끄럽습니다!')
        stage.unit(9).setAction(0)
        stage.say('&9\n가후Mr. , 내 마음은 정해졌어."\n이제부터 나는 위대한 대의를 위해 충성스럽게 싸울 것이다!')
        stage.unit(9).setAction(0, 2)
        stage.say('&9\n(마Teng주군 용서해 주세요.\n조조 이 사람이 진정으로 특별한 자질을 가지고 있다면,\n수링밍은 너를 복수할 수 없어. )')
        stage.say('&23\n일반 방덕......')
        stage.delay(10)
        stage.bgSound(-1)
        stage.clsUnit()
    if not vars[311]:
        stage.bgSound(19)
        stage.delay(3)
        stage.showUnit(9, 63, 54, 1)
        stage.draw()
        stage.setStageName('Hanzhong방덕 거주지')
        stage.say('&9\n내가 너를 배신할 수도 있다는 걸 잘 알면서도,\n그는 나에게 전투에 나가라고 명령하기도 했다......\n정말 조조 생각이 이해가 안 돼......')
        stage.delay(5)
        stage.showUnit(21, 20, 54, 1)
        stage.delay(5)
        stage.say('&21\n방덕 장군님, 잠시 방해 드려도 될까요?')
        stage.unit(9).setAction(0, 3)
        stage.say('&9\n응?')
        stage.unit(9).move(50, 54, 3)
        stage.unit(9).setAction(0)
        stage.delay(3)
        stage.say('&9\n당신이 정욱 씨 맞죠?\n조언이 있으신가요?')
        stage.unit(21).move(40, 54, 1)
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n장군 방덕, 할 말이 있습니다,\n무슨 일이 있어도 전투에 나가기 전에 장군에게 알려야 해.')
        stage.unit(21).setAction(0)
        stage.say('&9\n도대체 무슨 일이 벌어지고 있는 거죠?')
        stage.unit(21).setAction(6)
        stage.say('&21\n마텡 장군에 관한 거였어......\n내가 마텡을 죽인 사람이야.')
        stage.unit(21).setAction(0)
        stage.say('&9\n……!?\n&21\n그 time주군 생명이 위협받더라도,\n그는 마텅 장군을 죽일 생각을 한 적이 없었다.')
        stage.unit(21).setAction(6)
        stage.say('&21\n마텡 장군의 죽음은 전적으로 내 결정이었다,\n모든 책임은 정욱에게 있습니다.\n&9\n왜 마 Teng주군를 죽였어?')
        stage.unit(21).setAction(0)
        stage.say('&21\n내가 주군의 전략가이니까,\n당연히 주군를 위협하는 요인을 제거하는 것은 우리의 책임입니다.\n&21\n마텡은 주군를 해치려는 음모에 가담했다,\n물론, 나는 그가 이 세상에 살게 둘 수 없다,\n장군도 이 원칙을 이해하고 있을 것이다.\n&9\n수년간 싸운 후에,\n이 점은 이해합니다.\n&9\n알고 보니 조 재상은 마텅의 죽음을 언급하지 않았주군,\n이 책임을 혼자 짊어지는 것인가?')
        stage.unit(9).setAction(0, 2)
        stage.say('&9\n혼란스러운 시대에 생존을 추구하는 통치자가 되기 위해,\n이것이 개인적인 원한을 놓아주는 가장 좋은 전략입니다.\n&9\n선과 악의 책임을 모두 맡는 이 접근법,\n이게 진짜 조 재상인가?\n&9\n그때 총리는 의심 없이 내 방덕을 받아들였다,\n그것도 부하들을 신뢰한다는 증거 아닌가?\n&9\n그렇다면 앞으로도 최선을 다하겠습니다,\n위대한 대의를 위해 싸웠다.')
        stage.unit(21).setAction(6)
        stage.say('&21\n일반 방덕......')
        stage.delay(10)
        stage.bgSound(-1)
        stage.clsUnit()
    return False


def scene14():
    stage.bgSound(15)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            6,
            54,
            80],
        [
            7,
            44,
            64,
            1],
        [
            9,
            44,
            58,
            1]])
    stage.draw()
    stage.setStageName('한중 @조조군의 본군 진영')
    stage.say('&6\n주력 부대가 도착하기 전에,\n우리는 서군의 공격을 막기 위해 최선을 다할 수밖에 없습니다.\n모두가 끝까지 인내해야 한다!')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        6,
        7,
        12,
        9], [
        0])
    gvars[4076] = 0
    gvars[4057] = 46
    stage.setBattlePos([
        [
            23,
            16],
        [
            22,
            17],
        [
            6,
            4],
        [
            4,
            6],
        [
            12,
            16],
        [
            19,
            26],
        [
            21,
            16],
        [
            23,
            18],
        [
            12,
            15],
        [
            19,
            25],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene15():
    if stage.battleTest():
        stage.say('&6\n싸워!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(7):
        stage.say('&7\n방덕 장군의 헬멧은 정말 뛰어납니다.')
    if stage.unitClickTest(9):
        stage.say('&9\n전장은 온통 산들이고,\n지형이 꽤 복잡합니다,\n이동할 때는 매우 조심하세요.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
