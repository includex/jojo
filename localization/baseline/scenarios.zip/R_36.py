# Source Generated with Decompyle++
# File: R_36.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            12,
            44,
            58,
            1],
        [
            20,
            64,
            64,
            3]])
    if vars[835]:
        stage.showUnit(15, 44, 52, 1)
    else:
        stage.showUnit(6, 44, 52, 1)
    stage.showUnits([
        [
            23,
            64,
            52,
            3],
        [
            19,
            64,
            58,
            3]])
    stage.draw()
    if vars[735] and vars[835]:
        stage.bgSound(13)
        stage.delay(3)
        stage.setStageName('한중: 조조군의 본진')
        stage.setEventName('하후연 유물')
        stage.delay(3)
        model.setFace(1)
        stage.say('&0\n뭐라고...... 무슨 ......?\n하후연 죽었어......?')
        stage.unit(12).setAction(0, 2)
        stage.delay(3)
        stage.unit(12).setAction(6)
        stage.say('&12\n......\n서군의 맹렬한 공격을 견디지 못하고,\n수적으로 열세였던 그는 전투에서 전사했다......')
        stage.unit(12).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n묘차이, 내 묘차이.........')
        stage.unit(1).setAction(4)
        stage.say('&1\n와아...... ......\n먀오차이 ......!!')
        stage.unit(0).setAction(0, 0)
        model.setFace(0)
        stage.say('&0\n질리안, 묘오차이의 유산은 어디에 있을까?')
        stage.unit(12).setAction(6)
        stage.say('&12\n혼란 속에서 당분간 그것을 찾는 것은 불가능했다.')
        stage.unit(0).setAction(2)
        stage.say('&0\n무슨 일이 있어도, 반드시 찾아야 해,\n그를 제대로 장례 치러줘.........\n알고 계셨나요!\n&12\n네.')
        stage.unit(12).setAction(0)
        stage.delay(3)
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n......주군.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(2)
        stage.say('&0\n중달, 즉시 서군을 공격하라!\n젠장, 유비......공명!\n나는 묘차이의 복수를 원한다!')
        stage.unit(19).setAction(0)
        stage.say('&19\n부하가 복종해!')
        stage.unit(0).setAction(17)
        stage.say('대귀한 도적아, 네가 내 비상한 재능을 죽였으니, 내가 너에게 후회할 줄 모르게 해 주마. 출발하자!')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.showUnit(181, 55, 22, 2)
        stage.say('&181\n신고됐어.\n&0\n무슨 일이야?')
        stage.unit(181).setAction(11)
        stage.say("&181\n주군, 샤후우 장군은 진영에 말 한 마리를 남겨두었다.\n&0\n말?\n&181\n그래, 좋은 말이야.\n&0\n말... 아, '발톱 노란 날개 번개'인가?\n그게 전에 먀오차이에게 타게 했던 거였어......\n왜 캠프에 남아 있었을까?")
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n그래서......\n나는 샤후우 장군이 전에 그렇게 말하는 것을 들은 적이 있다.\n&20\n그는 내게 주어진 훌륭한 말들을 said주군,\n전장에서 가볍게 사용하지 마세요.')
        stage.unit(20).setAction(0)
        stage.delay(5)
        stage.say('&0\n묘차이, 너 정말 어리석구나......\n걱정이 안 된다면,\n어쩌면 구원받을 수도 있겠네......')
        stage.say('이걸 제 말에 묶어 두세요. 네, 분부대로 하겠습니다.')
        stage.getItem(124, 0)
        stage.unit(181).setAction(0)
        stage.unit(181).hide()
        model.unitJoin(6, 255, 0)
        stage.bgSound(15)
        stage.delay(3)
    if vars[835] and not vars[735]:
        stage.bgSound(13)
        stage.delay(3)
        stage.setStageName('한중: 조조군의 본진')
        stage.setEventName('하후연 유물')
        model.setFace(1)
        stage.say('&0\n뭐라고...... 무슨 ......?\n하후연 죽었어......?')
        stage.unit(12).setAction(0, 2)
        stage.delay(3)
        stage.unit(12).setAction(6)
        stage.say('&12\n......\n서군의 맹렬한 공격을 견디지 못하고,\n수적으로 열세였던 그는 전투에서 전사했다......')
        stage.unit(12).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n묘차이, 내 묘차이.........')
        stage.unit(1).setAction(4)
        stage.say('&1\n와아...... ......\n먀오차이 ......!!')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n젠장, 유비......공명!\n즉시 슈 군대를 공격하라!\n나는 묘차이의 복수를 원한다!')
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n주군 기다려.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        model.setFace(0)
        stage.say('&0\n왜 날 막아, 중달?\n&19\n주군, 이 전투에서의 손실아군 매우 컸다 —\n이제 그는 더 이상 싸울 수 없었다.')
        stage.unit(19).setAction(0)
        stage.say('&0\n흠......')
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n중달 말씀이 전적으로 맞습니다.\n&20\n한중은 잠시 포기할 수밖에 없어,\n쉬두로 돌아와 재편성했다.')
        stage.unit(20).setAction(0)
        stage.say('&0\n……뛰어난 재능을 잃고,\n게다가 한중까지 잃다니……에휴……\n좋아, 어쩔 수 없겠지.')
        stage.unit(20).setAction(6)
        stage.say('&20\n우리는 당신의 기분을 이해합니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('대귀한 도적아, 네가 내 비상한 재능을 죽였으니, 내가 너에게 후회할 줄 모르게 해 주마.')
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n질리안, 묘오차이의 유산은 어디에 있을까?')
        stage.unit(12).setAction(6)
        stage.say('&12\n혼란 속에서 당분간 그것을 찾는 것은 불가능했다.')
        stage.unit(0).setAction(2)
        stage.say('&0\n무슨 일이 있어도, 반드시 찾아야 해,\n그를 제대로 장례 치러줘.........\n알고 계셨나요!')
        stage.unit(0).setAction(0)
        stage.say('&12\n네.')
        stage.unit(12).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.delay(5)
        stage.say('...묘한 재주로구나...')
        stage.delay(5)
        stage.showUnit(181, 54, 22, 2)
        stage.say('&181\n신고됐어.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n무슨 일이야?')
        stage.unit(181).setAction(11)
        stage.say("&181\n주군, 샤후우 장군은 진영에 말 한 마리를 남겨두었다.\n&0\n말?\n&181\n그래, 좋은 말이야.\n&0\n말... 아, '발톱 노란 날개 번개'인가?\n그게 전에 먀오차이에게 타게 했던 거였어......\n왜 캠프에 남아 있었을까?")
        stage.unit(20).setAction(6)
        stage.say('&20\n그래서......\n나는 샤후우 장군이 전에 그렇게 말하는 것을 들은 적이 있다.\n&20\n그는 내게 주어진 훌륭한 말들을 said주군,\n전장에서 가볍게 사용하지 마세요.')
        stage.unit(20).setAction(0)
        stage.delay(5)
        stage.say('&0\n묘차이, 너 정말 어리석구나......\n걱정이 안 된다면,\n어쩌면 구원받을 수도 있겠네......')
        stage.say('이걸 제 말에 묶어 두세요. 네, 분부대로 하겠습니다.')
        stage.getItem(124, 0)
        stage.unit(181).setAction(0)
        stage.unit(181).hide()
        model.unitJoin(6, 255, 0)
        if vars[1001]:
            stage.bgSound(16)
            stage.delay(3)
            stage.clsUnit()
            stage.loadBg(1, 0)
            stage.draw()
            stage.showHead(0, 157, 86)
            stage.showHead(32, 93, 86)
            stage.bottomTxt('조조 한중을 버렸고,', False, False, False)
            stage.delay(5)
            stage.head(0).move(332, 101)
            stage.delay(5)
            stage.bottomTxt('군대를 쉬두로 철수시켜라.', True, False, True)
            stage.bgSound(-1)
            stage.jumpScene(75)
    if vars[735] and not vars[835]:
        stage.bgSound(15)
        stage.delay(3)
        stage.setStageName('한중: 조조군의 본진')
        stage.setEventName('한중을 탈환했다')
        stage.say('&0\n하후연, 수고하셨습니다.')
        stage.unit(6).setAction(0, 2)
        stage.delay(3)
        stage.unit(6).setAction(6)
        stage.say('&6\n용서해 주세요, 하지만 한중을 붙잡지 못했어요,\n나는 네 신뢰를 깨뜨렸어.')
        stage.unit(6).setAction(0)
        stage.say('&0\n슈 군대가 공격 중이고, 너희는 수적으로 열세다,\n당신이 할 수 있는 게 없어요—그게 무슨 죄인가요?\n&6\n하지만... 한중......\n&0\n잃어버리면 되찾을 수 있습니다.')
        stage.unit(0).setAction(17)
        stage.say('&0\n즉시 군대를 보내 슈군을 공격하라!\n우리는 한중을 붙잡을 것이다!\n가자!')
        stage.unit(0).setAction(0)
        stage.unit(6).setAction(0, 1)
    if not vars[735] and not vars[835]:
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.setStageName('한중: 조조군의 본진')
        stage.setEventName('무의미한 행군')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('대귀한 도적…… 생각보다 군마가 많네.')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.delay(3)
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n주군, 아군들의 손실은 매우 컸다.\n이 싸움은 더 이상 계속될 수 없다.')
        stage.unit(19).setAction(0)
        stage.say('&0\n흠......')
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n중달 말씀이 전적으로 맞습니다.\n&20\n한중은 잠시 포기할 수밖에 없어,\n쉬두로 돌아와 재편성했다.')
        stage.unit(20).setAction(0)
        stage.say('...좋다. 이제 어쩔 도리가 없군. 본거지로 돌아가자! 허도로!')
        if vars[1001]:
            stage.effectSound(203, 255)
            stage.bgSound(16)
            stage.delay(3)
            stage.clsUnit()
            stage.loadBg(1, 0)
            stage.draw()
            stage.showHead(0, 157, 86)
            stage.showHead(32, 93, 86)
            stage.bottomTxt('조조 한중을 버렸고,', False, False, False)
            stage.delay(5)
            stage.head(0).move(332, 101)
            stage.delay(5)
            stage.bottomTxt('군대를 쉬두로 철수시켜라.', True, False, True)
            stage.bgSound(-1)
            stage.jumpScene(75)
    stage.unit(0).setAction(0, 0)
    stage.unit(1).setAction(0, 1)
    stage.unit(12).setAction(0, 1)
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        15])
    gvars[4076] = 0
    gvars[4057] = 36
    stage.setBattlePos([
        [
            26,
            2],
        [
            25,
            2],
        [
            26,
            3],
        [
            23,
            7],
        [
            22,
            6],
        [
            23,
            6],
        [
            24,
            7],
        [
            22,
            5],
        [
            22,
            3],
        [
            21,
            2],
        [
            22,
            2],
        [
            23,
            3],
        [
            21,
            1],
        [
            27,
            3],
        [
            25,
            1]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출격해라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n양쪽은 평지가 산으로 둘러싸여 있다,\n이번에는 이곳이 주요 전장이다.\n&20\n게다가 유비군은 강을 등지고 배치되어 있었다.\n&0\n흠.')
    if stage.unitClickTest(19):
        stage.say('&19\n무기 가게에 다녀왔어,\n새 보호 장비가 도착했습니다.')
    if stage.unitClickTest(6):
        stage.say('&6\n한중의 몰락에 대한 책임은 나에게 있다,\n이번에는 제발 출전하게 해주세요.')
    if stage.unitClickTest(15):
        stage.say('&15\n샤후우 장군은 좋은 분이야......\n젠장!')
    if stage.unitClickTest(1):
        if vars[835]:
            stage.say('&1\n맹덕, 제발 먀오차이의 복수를 하게 해줘!')
        if not vars[835]:
            stage.say('&1\n먀오차이, 너무 자책하지 마.')
    if stage.unitClickTest(12):
        if vars[835]:
            stage.say('&12\n즉시 내 부하들에게 시신을 수색하라고 명령하겠습니다.\n&0\n그래도 꼭 찾아야 해.')
        if not vars[835]:
            stage.say('&12\n누가 상상이나 쑤 군대가 이렇게 강할 줄 알았겠는가...\n정말 안타깝다.\n&0\n잊어버려.\n이건 내 잘못이야,\n자책하지 마세요.')
    if stage.unitClickTest(23):
        stage.say('&23\n지형을 보면,\n이것은 우리 기병 부대에 이익이 됩니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
