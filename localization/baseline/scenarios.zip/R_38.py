# Source Generated with Decompyle++
# File: R_38.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            19,
            52,
            40,
            2]])
    if vars[735]:
        stage.showUnit(4, 52, 70)
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setEventName('위와 우는 비밀리에 동맹을 맺었다')
    stage.setStageName('서두, 총리 관저')
    if vars[735]:
        stage.effectSound(200, 255)
        stage.bgSound(18)
        stage.delay(3)
        model.setFace(3)
        stage.unit(0).setAction(3)
        stage.say('&0\n조장, 당신은 이 전투를 용감하게 싸웠습니다.\n그래서 내 조조의 아들이구나!')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.delay(3)
        stage.unit(4).setAction(6)
        stage.say('&4\n칭찬해 주셔서 감사합니다, 아버지.\n&0\n이제부터 그는 공식적으로 아군 장군으로 복무할 것이다,\n잘 해내길 바란다.\n&4\n네!')
        stage.unit(4).setAction(0)
        model.unitJoin(4, 0, 0)
        if vars[1013]:
            gvars[0] = 4
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
        stage.bgSound(-1)
        stage.effectSound(200, 0)
        stage.delay(3)
    stage.say('맞다, 중달. 우리는 여기서 한중을 포기할 수 없어. 그래서……')
    stage.unit(0).setAction(3)
    stage.say('&0\n저는 동우를 사용할 생각입니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n이제 서의 군사력은 더 이상 과소평가할 수 없다,\n정면아군 전투에서 이긴다 해도,\n그건 정말 최선의 전략은 아니었어요.')
    stage.unit(19).setAction(6)
    stage.say('&19\n그래서 그런 거구나......\n그렇다면 서나라는 동우로 초점을 옮겨야 할까요?')
    stage.unit(19).setAction(0)
    stage.say('&0\n바로 그거예요.\n동오가 경주에서 슈군을 공격하게 하라!\n&0\n비록 손권가 징저우 세 군을 차지했지만,\n하지만 그는 아직 다른 카운티들을 포기하지 않았습니다.\n&0\n그래서 나는 동우와 비밀리에 동맹을 맺고자 한다.')
    stage.unit(19).setAction(6)
    stage.say('&19\n저도 동의합니다.\n&0\n하지만 .........\n문제는, 누가 전령으로 적합한가 하는 것이다.\n&19\n만총 씨가 적임자라고 생각합니다.\n&0\n버닝?\n&19\n네.\n버닝 씨는 청렴한 사람이었고,\n그런 인물은 외교에 유리하다.')
    stage.unit(19).setAction(0)
    stage.say('&0\n좋아.\n버닝!\n버닝이 여기 있어!?')
    stage.showUnit(25, 90, 55, 3)
    stage.say('&25\n그리고 내 은혜는 여기 있어.')
    stage.unit(25).move(48, 55, 3)
    stage.unit(25).setAction(0)
    stage.say('&0\n오, 버닝.\n동우에 사신으로 가서 동맹을 맺으길 원한다.')
    stage.unit(25).setAction(6)
    stage.say('&25\n동우로 가는 중이신가요?\n&0\n흠, 동우와 동맹을 맺으세요,\n또한 그는 그들에게 징저우를 공격할 것을 촉구했다.\n괜찮을까요?\n&25\n네, 저는 제 사명을 다할 것입니다.\n&0\n음, 네게 맡길게.')
    stage.unit(25).setAction(0)
    stage.unit(25).move(95, 55, 1)
    stage.unit(25).hide()
    stage.say('&0\n중달, 경주를 지키기 위해 떠난 쑤 장군이 관우 맞지?')
    stage.unit(19).setAction(6)
    stage.say('&19\n네.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('...관우라고요? 설마 또 그와 싸워야 하다니...')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 334, 102)
    stage.bottomTxt('징저우를 지키는 슈 장군이,', False, False, False)
    stage.delay(5)
    stage.showHead(3, 278, 236)
    stage.delay(5)
    stage.bottomTxt('그는 지혜와 용기를 모두 갖춘 관우입니다.', True, False, False)
    stage.delay(8)
    stage.showHead(76, 500, 217)
    stage.delay(5)
    stage.bottomTxt('손권', True, True, False)
    stage.delay(5)
    stage.bottomTxt('위가 먼저 징저우를 공격하는 조건으로,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 비밀리에 위와 동맹을 맺었다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('조조 이 조건을 받아들였다,', True, True, False)
    stage.delay(5)
    stage.head(0).hide()
    stage.delay(5)
    stage.showHead(5, 300, 76)
    stage.delay(5)
    stage.bottomTxt('조인 디스패치,', True, False, False)
    stage.delay(5)
    stage.showHead(25, 364, 109)
    stage.delay(5)
    stage.bottomTxt('만총', True, False, False)
    stage.delay(5)
    stage.head(5).move(278, 156)
    stage.head(25).move(342, 202)
    stage.delay(5)
    stage.bottomTxt('그리고 징저우를 공격하기 위해 진격했다.', True, False, True)
    stage.bottomTxt('However조인와 만총은 관우 반격을 받았다.', False, False, False)
    stage.delay(5)
    stage.head(5).move(255, 140)
    stage.head(25).move(342, 140)
    stage.head(25).move(319, 140)
    stage.head(3).move(288, 220)
    stage.delay(5)
    stage.bottomTxt('대신 그들은 판성에서 포위당했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            9,
            48,
            58,
            3],
        [
            14,
            48,
            52,
            3]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n웬제, 들어봤을 거야,\n조인과 만충은 판청에서 관우군에게 포위당했다.\n&0\n그들은 여전히 관우을 이기지 못한다,\n그러니 즉시 팽청으로 증원군을 이끌어야 합니다.')
    stage.unit(14).setAction(6)
    stage.say('&14\n네.')
    stage.unit(14).setAction(0)
    stage.say('&0\n링밍, 네가 원쩌를 보좌하는 부총장으로 봉사해.')
    stage.unit(9).setAction(6)
    stage.say('&9\n네.')
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(14).setAction(0, 2)
    stage.say('&14\n장군방덕 보내라고?\n&0\n음, 무슨 일이야?')
    stage.unit(14).setAction(0, 3)
    stage.say('&14\n아니요...... 아무것도 아니에요.\n그럼 바로 준비할게.\n실수해서 죄송합니다.')
    stage.unit(14).move(95, 52, 1)
    stage.unit(14).hide()
    stage.delay(3)
    stage.unit(9).setAction(0, 1)
    stage.say('&9\n유 장군이 아직도 나를 완전히 신뢰하지 않는 것 같아.')
    stage.unit(9).setAction(0, 3)
    stage.say('&9\n내 과거를 잘 아시니,\n이것도 어쩔 수 없는 문제입니다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n링밍, 나도 그런 소문을 들었어,\n하지만 나는 여전히 너를 매우 신뢰해,\n그래서 내가 네게 판청을 지원하라고 명령한 거야.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(9).setAction(6)
    stage.say('&9\n총리님께 깊이 감사드립니다.\n그럼 병력 배치도 준비하겠습니다.')
    stage.unit(9).setAction(0)
    stage.unit(9).move(85, 58, 1)
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(9).setAction(0, 3)
    stage.say('&9\n주군.\n&0\n무슨 일이야?')
    stage.unit(9).setAction(6)
    stage.say('&9\n주군 나에게 이렇게 중요한 임무를 맡겼다,\n정말 감사하게 생각합니다.\n&9\n내 목숨을 걸더라도,\n그는 또한 판청을 구출하는 임무를 완수해야 했다.\n&9\n…… 꼭 해볼게요!\n&0\n링밍, 공을 서두르지 마라.\n&9\n…… 그럼 저는 이만 가보겠습니다.')
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(9).move(95, 58, 1)
    stage.unit(9).hide()
    stage.say('&0\n이미 충동적으로 행동하는 것 같다—이게 어떻게 용납될 수 있지?\n전투는 침착함을 필요로 한다,\n그렇지 않으면 목숨을 잃을 수도 있어.\n&0\n이대로라면 링밍이 위험해질 거야,\n관우 지혜와 용기를 모두 갖춘 사나운 장군이었다,\n침착함을 유지할 수 없으니 그를 이길 수 없어.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n하지만 지금, 방덕 이렇게 하면,\n더 이상 내 말을 듣지 않을까 봐 두려워,\n그는 유진이 방덕 있게 내버려 둘 수밖에 없었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n……방덕아, 제발 경솔하게 굴지 마라.\n너를 잃고 싶지 않아……')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(5, 271, 145)
    stage.showHead(3, 271, 225)
    stage.showHead(14, 283, 47)
    stage.delay(5)
    stage.bottomTxt('유진허', False, False, False)
    stage.delay(5)
    stage.showHead(9, 347, 89)
    stage.delay(5)
    stage.bottomTxt('방덕', True, False, False)
    stage.delay(5)
    stage.head(14).move(207, 47)
    stage.head(14).move(207, 145)
    stage.head(9).move(335, 145)
    stage.delay(5)
    stage.bottomTxt('그는 증원군을 이끌고 편성조인 포위되었다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 51)
    stage.showUnits([
        [
            76,
            53,
            29,
            2],
        [
            88,
            41,
            48,
            1],
        [
            78,
            41,
            54,
            1],
        [
            80,
            65,
            48,
            3],
        [
            194,
            65,
            54,
            3]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('지안예 손권 저택')
    stage.say('&76\n쯔밍, 너도 이미 알고 있잖아......\n위나라 장군 조인이 판성에서 관우에게 포위당한 거 맞지?')
    stage.unit(80).setAction(6)
    stage.say('&80\n네.\n이건 바로 일생에 한 번 있는 기회야.')
    stage.unit(80).setAction(0)
    stage.say('&76\n맞아.\n우리는 이 기회를 잡아 징저우 전체를 점령해야 합니다.\n&76\n자밍, 징저우를 점령하라 명령한다.\n모든 것은 여러분에게 달려 있습니다!')
    stage.unit(80).setAction(6)
    stage.say('&80\n네. 안심하세요, 주군.')
    stage.unit(80).setAction(0)
    stage.delay(3)
    stage.unit(80).setAction(0, 2)
    stage.say("&80\n이 사람은 관우 것 같......\n그들은 '앞서 그만둔다'는 것이 무엇을 의미하는지 이해하지 못하는 것 같습니다.\n&80\n이 승리는 동우의 것이 될 것이다.")
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(5, 325, 145)
    stage.showHead(3, 261, 145)
    stage.bottomTxt('조인허관우 판성에서 치열하게 싸우고 있다.', False, False, False)
    stage.delay(8)
    stage.showHead(80, 498, 210)
    stage.delay(5)
    stage.bottomTxt('여몽 이 기회를 잡아,', True, True, False)
    stage.delay(5)
    stage.head(80).move(307, 238)
    stage.delay(5)
    stage.bottomTxt('그는 성공적으로 징저우를 점령했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            8,
            58,
            70],
        [
            15,
            64,
            70],
        [
            10,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            19,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('번성에서는 아직 소식이 오지 않았나요?')
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 지금까지 아무 소식도 없습니다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n유진의 증원군도 한동안 떠나고 있었다,\n너무 늦게 가지 않길 바래.')
    stage.showUnit(181, 90, 55, 3)
    stage.say('&181\n신고됐어.')
    stage.say('번성에서 소식이 왔나요?')
    stage.unit(181).setAction(11)
    stage.say('&181\n아니요, 동우에서 온 사신이었습니다.\n&0\n동우에서 온 사절인가?\n좋아, 들여보내.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.unit(181).hide()
    stage.say('동오의 사신들... 분명 형주를 공격하는 것을 보고하러 왔겠지. 이렇게 하면 번성 쪽의 상황을 알 수 있겠어.')
    stage.showUnit(193, 90, 55, 3)
    stage.say('&193\n총리님께 경의를 표하러 왔다.')
    stage.unit(193).move(48, 55, 3)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n나는 주군가 보낸 전령이다.\n&0\n음, 징저우 얘기지?\n&193\n그래, 며칠 전에 아군가 징저우를 공격했어,\n이미 완전히 점유된 상태입니다.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n정말? 정말 기쁜 날이야!\n이 내용을 손 장군께 전해 주십시오.\n진심으로 기뻐조조.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&193\n그는 총리에게 감사를 표했다.\n판청 문제도 있었다......\n&0\n음, 판청......?\n&193\n현재 관우군이 여전히 우위를 점하고 있습니다.\n주군 즉시 증원군을 보내 주세요.\n&0\n그래? 조는 깊이 감사했다.\n아군 증원군 파견 문제도 논의하고 있었다,\n걱정해 주셔서 감사합니다, 쑨 장군님.\n&193\n네.\n그럼 저는 이만 가보겠습니다.')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(193).move(95, 55, 1)
    stage.unit(193).hide()
    if vars[735]:
        stage.unit(19).setAction(6)
        stage.say('&19\n동오가 이미 징저우 전역을 점령한 건가요?')
        stage.unit(19).setAction(0)
        stage.say('관우가 없어서 그들이 이룬 것일 뿐이야. 하지만 손권도 꽤 능하군.')
        stage.unit(1).setAction(0, 3)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n맹덕, 판청 상황이 좋지 않아.')
        stage.unit(1).setAction(0)
        stage.say('&0\n흠, 뜻밖에도 유진과 방덕을 지원군으로 보냈다,\n하지만 결국 그들은 win관우......\n관우 진정으로 뛰어난 장군이 될 자격이 있다."')
        stage.unit(1).setAction(2)
        stage.say('&1\n지금은 그를 감탄할 때가 아니야!')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(17)
        stage.say('&0\n흠.\n좋아, 당장 판청을 구하러 가자.\n가자!')
        stage.unit(0).setAction(0)
        stage.say('(나는 방덕이 걱정된다. 혹시 그가……)')
    if not vars[735]:
        stage.unit(19).setAction(6)
        stage.say('&19\n동오가 이미 징저우 전역을 점령한 건가요?')
        stage.unit(19).setAction(0)
        stage.say('관우가 없어서 그들이 이룬 것일 뿐이야. 하지만 손권도 꽤 능하군.')
        stage.unit(1).setAction(0, 3)
        stage.say('&1\n맹덕, 판청 상황이 좋지 않아.\n&0\n흠, 뜻밖에도 유진과 방덕을 지원군으로 보냈다,\n하지만 결국 그들은 win관우......\n관우 정말 뛰어난 장군입니다."')
        stage.unit(1).setAction(2)
        stage.say('&1\n지금은 그를 감탄할 때가 아니야!')
        stage.unit(1).setAction(0)
        stage.say('&0\n흠.\n좋아, 당장 판청을 구하러 가자.')
        stage.effectSound(201, 255)
        stage.bgSound(18)
        stage.delay(3)
        stage.showUnit(4, 90, 55, 3)
        stage.say('&4\n아버지!')
        stage.unit(1).setAction(0, 0)
        stage.unit(4).move(48, 55, 3)
        stage.unit(4).setAction(0)
        stage.say('&0\n그래서 조장이구나? 여기 무슨 일로 왔어?\n아직 총리 관저에 드나드는 것을 허락하지 않았다.')
        stage.unit(4).setAction(6)
        stage.say('&4\n아이를 용서해 주세요,\n동오의 사신이 방금 한 말은,\n다 들었어.\n&4\n아버지, 저는 이제 무술에 능숙해졌습니다,\n제발 내 아이를 당신 군대에 합류하게 해주세요.\n&0\n조장 ......\n네 실력이 전쟁에 나갈 만큼 충분하다고 생각한다면,\n그건 큰 실수야.\n&4\n이건 알아요,\n하지만 지금은 유능한 인재를 고용해야 하는 매우 중요한 시기입니다.\n어떻게 아이가 가만히 있을 수 있겠는가?')
        stage.unit(0).setAction(3)
        stage.say('에휴, 막을 수가 없겠구나. 좋아, 네가 군대에 합류하는 것을 허락하겠다.')
        stage.unit(0).setAction(0)
        stage.say('&4\n감사합니다, 신부님!')
        stage.unit(4).setAction(0)
        stage.delay(3)
        model.unitJoin(4, 0, 0)
        if vars[1013]:
            gvars[0] = 4
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
        stage.unit(0).setAction(17)
        stage.say('좋습니다, 출전합니다!')
        stage.unit(0).setAction(0)
        stage.say('(나는 방덕이 걱정된다. 혹시 그가……)')
    stage.effectSound(201, 255)
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 333, 93)
    stage.showHead(3, 259, 189)
    stage.showHead(5, 323, 189)
    stage.bottomTxt('조조', False, False, False)
    stage.delay(5)
    stage.head(0).move(291, 109)
    stage.delay(5)
    stage.bottomTxt('구조를 위해 판청으로 급히 달려갔다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            14,
            54,
            80],
        [
            9,
            44,
            64,
            1]])
    stage.draw()
    stage.setStageName('판청 조조 본진')
    stage.say('&14\n관우 수도 계량기를 이용해 강 범람을 일으키는 것,\n요즘은 도시에 접근하기가 어렵습니다.')
    stage.unit(14).setAction(0, 1)
    stage.say('&14\n그래서 그들은 주군 증원군을 기다릴 수밖에 없었다,\n그 외에는 이길 가능성이 전혀 없었다.')
    stage.unit(9).setAction(0, 2)
    stage.delay(3)
    stage.unit(9).setAction(6)
    stage.say('&9\n그렇게 쉽게 포기할 수 없습니다.\n숨이 있는 한 적과 싸워야 했다.')
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(14).setAction(0, 0)
    stage.say('&14\n팡 장군, 너무 성급하지 마세요......')
    stage.unit(9).setAction(6)
    stage.say('&9\n장군님, 왜 그런 말씀을 하시나요!\n죽음에 대한 두려움 속에서 어떻게 공덕을 얻고 성공할 수 있을까?')
    stage.unit(9).setAction(0)
    stage.say('&14\n그건 사실이지만......\n(번거롭게 해서 죄송합니다. 총리께서 저를 제지하라고 하방덕,\n하지만 너무 신이 났다...... )\n&14\n…… 네가 그렇게 말하니,\n저도 무력했어요.\n병력을 보내라!')
    stage.unit(9).setAction(0, 1)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        5,
        25,
        9,
        14])
    gvars[4076] = 0
    gvars[4057] = 38
    stage.setBattlePos([
        [
            0,
            14],
        [
            17,
            13],
        [
            17,
            14],
        [
            10,
            2],
        [
            18,
            1],
        [
            19,
            0],
        [
            11,
            1],
        [
            17,
            1],
        [
            9,
            1],
        [
            1,
            15],
        [
            1,
            13],
        [
            1,
            14],
        [
            1,
            12],
        [
            0,
            13],
        [
            0,
            15]])
    return False


def scene5():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&14\n가자!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(9):
        stage.say('&9\n아무리 힘든 싸움이라도, 상관없다,\n나, 팡링밍, 이 절박한 전투에서 목숨을 걸고 있다!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
