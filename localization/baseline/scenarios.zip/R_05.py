# Source Generated with Decompyle++
# File: R_05.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(18)
    stage.delay(3)
    stage.loadBg(2, 12)
    stage.showUnits([
        [
            0,
            29,
            54,
            1],
        [
            20,
            48,
            41,
            2],
        [
            24,
            54,
            41,
            2],
        [
            1,
            48,
            68],
        [
            22,
            46,
            52,
            3],
        [
            21,
            46,
            58,
            3]])
    stage.draw()
    stage.setEventName('아버지의 죽음')
    stage.setStageName('푸양 조조 저택')
    stage.delay(5)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n오늘은 두 명의 은둔 위대한 현자를 주군 데려왔다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(22).setAction(6)
    stage.say('&22\n처음으로 조 경께 경의를 표합니다. 저는 곽가, 자명은 펑샤오입니다.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n저도 처음 뵙는 거예요. 저는 정욱, 성씨 중더입니다.')
    stage.unit(21).setAction(0)
    stage.say('&0\n당신의 위대한 명성에 대해 오래전부터 들었습니다,\n원소와 류비아오의 초대를 거절했다고 들었는데,\n왜 그런지 잘 모르겠어요?')
    stage.unit(22).setAction(6)
    stage.say('&22\n원소 오만하고 의심 많아 그를 섬기려 하지 않았다.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n류비아오도 원소와 다르지 않았다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(22).setAction(6)
    stage.say('&22\n조 공은 혼란의 시대를 진정시킬 수 있는 진정한 영웅이다,\n우리는 당신의 부하가 될 준비가 되어 있습니다.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('하하, 두 분 다 과찬이십니다…….')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n좋아!\n너는 문약와 공다와 함께 내 전략가가 될 것이다.')
    stage.unit(21).setAction(6, 3)
    stage.say('&21\n셰 주군.')
    stage.unit(21).setAction(0, 3)
    stage.delay(3)
    stage.unit(22).setAction(6, 3)
    stage.say('&22\n저희가 꼭 조언을 드리겠습니다.')
    stage.unit(22).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하, 문약.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n아버지를 만나러 보내세요.')
    stage.unit(0).setAction(5, 1)
    stage.say('그리고 이 편지를 전달하세요.')
    stage.say('&20\n어른의 아버지?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠...... 집에 계신 아버지가 좀 걱정돼요.\n이제 내가 연주 주지사가 되었으니, 그를 이곳으로 데려오고 싶다.\n&20\n아, 정말 멋지네요.')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n알았어, 바로 처리할게.')
    stage.unit(20).setAction(0, 2)
    stage.say('&0\n흠...... 네게 맡길게.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 1)
    stage.showUnits([
        [
            158,
            52,
            74,
            0,
            1],
        [
            192,
            52,
            60,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('천류에 있는 조송의 집')
    stage.unit(158).setAction(3)
    stage.say('&158\n뭐라고? 맹덕 날 데려가고 싶어!\n&192\n네, 주군 할아버지를 데려와 함께 살고 싶어요.')
    stage.unit(158).setAction(0)
    stage.say('&158\n아, 정말요? 맹덕 그렇게 말하는 거예요?')
    stage.unit(158).setAction(0, 1)
    stage.say('&158\n한숨! 모두가 맹덕를 험담하곤 했어,\n이제 그는 정말 밝은 미래를 갖게 되었습니다.')
    stage.unit(158).setAction(0, 0)
    stage.say('&158\n알았어, 말해맹덕, 바로 갈게.')
    stage.unit(192).setAction(6, 2)
    stage.say('&192\n네.')
    stage.unit(192).setAction(0, 2)
    stage.delay(3)
    stage.unit(192).move(52, 20, 0)
    stage.unit(192).hide()
    stage.unit(158).move(48, 74, 3)
    stage.delay(5)
    stage.unit(158).setAction(0, 2)
    stage.say('&158\n맹덕Now 정말 이름을 알리고 있네요!\n정말 행복해요.')
    stage.delay(5)
    stage.effectSound(202, 255)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.delay(5)
    stage.showHead(0, 458, 62)
    stage.showHead(158, 362, 115)
    stage.bottomTxt('조송은 조조 눈에 띄어 매우 기뻐했다,\n그래서 그는 즉시 일어나 푸양으로 떠났다.', False, True, False)
    stage.delay(5)
    stage.head(158).move(394, 86)
    stage.delay(5)
    stage.bottomTxt('안타깝게도,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('쉬저우를 지나가던 중 정체불명의 사람들에게 공격당했다,', True, False, False)
    stage.head(158).hide()
    stage.delay(5)
    stage.bottomTxt('조송은 실제로 현장에서 살해당했다.', True, False, True)
    stage.bgSound(-1)
    return False


def scene2():
    stage.loadBg(2, 12)
    stage.showUnits([
        [
            0,
            29,
            54,
            1],
        [
            192,
            46,
            54,
            3],
        [
            20,
            50,
            41,
            2],
        [
            22,
            56,
            41,
            2],
        [
            24,
            62,
            41,
            2],
        [
            21,
            68,
            41,
            2],
        [
            1,
            50,
            68],
        [
            6,
            56,
            68],
        [
            5,
            62,
            68]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('며칠 후, .......', 3)
    stage.setStageName('푸양 조조 저택')
    stage.delay(3)
    stage.unit(1).setAction(2)
    stage.say('&1\n뭐라고! 노인이 죽었다고!?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(0, 2)
    stage.say('&192\n네, 그는 쉬저우 도겸 부하들에게 ......되었습니다.')
    stage.unit(6).setAction(6)
    stage.say('&6\n그게 어떻게 가능하지?\n도겸Why 이걸 할 거야!?')
    stage.unit(6).setAction(0)
    stage.delay(3)
    stage.say('&5\n음 .......')
    stage.delay(5)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n알겠습니다... 수고하셨습니다.')
    stage.unit(192).setAction(0, 3)
    stage.delay(3)
    stage.unit(192).setAction(6, 3)
    stage.say('&192\n네.')
    stage.unit(192).setAction(0)
    stage.delay(5)
    stage.unit(1).setAction(0, 3)
    stage.say('&1\n맹덕.......')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n원양! 즉시 병력을 동원하라; 나는 쉬저우를 공격하겠다.')
    stage.unit(22).setAction(6)
    stage.say('&22\n잠깐!')
    stage.unit(22).setAction(0)
    stage.say('……무슨 일이야, 봉효?')
    stage.unit(22).setAction(6)
    stage.say('&22\n아버지의 복수를 위해 군대를 모은 것은 단지 효도의 행위였다,\n하지만 그것은 군주에게 기대되는 미덕은 아니었다.\n&22\n당분간은 그냥 참아야겠다고 생각했어요.')
    stage.unit(22).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n안 돼! 내가 출병해야 해!')
    stage.unit(0).setAction(0)
    stage.say('&22\n……。')
    stage.unit(21).setAction(6)
    stage.say('&21\n아군 아직 이곳에 자리 잡지 못했습니다.\n&21\n이제는 전쟁보다 내정 관리가 더 중요해.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    stage.say('&0\n네 생각은 너무 구식이야,\n그들은 싸울 적절한 순간을 모를 뿐이다!\n지금 군대를 보내지 않으면 언제?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n하지만, 하지만 .......')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n주군 군대를 보내면 안 된다!\n&24\n개인적인 원한으로 큰 힘을 일으킨다면,\n이 사건은 미래 세대를 위해 세상에 혼란을 가져온다는 악명 높은 평판을 남길 것입니다.')
    stage.unit(24).setAction(0)
    stage.say('&0\n저는 미래 세대가 그것을 어떻게 볼지 전혀 생각하지 않습니다.')
    stage.unit(24).setAction(6)
    stage.say('&24\n응? 네 명예를 잃고 싶기나 해?')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(0)
    stage.say('&0\n이제 나는 내 눈앞에만 조조,\n그는 미래 세대가 본받아야 할 인물이 아니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n무-무슨 ......?')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n그렇다면 법원은 우리를 어떻게 볼까요?\n황건에 맞서 얻은 신뢰는 헛수고가 될 거야!')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n문약!\n&0\n법정은 약하고 자비로운 남자가 필요하지 않다,\n오히려 유능한 장군들이었다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n그래서 나는 쉬저우를 세계를 지배하는 출발점으로 삼고 싶어!')
    stage.unit(0).setAction(0)
    stage.say('&20\n…………………。')
    stage.unit(0).setAction(17)
    stage.say('&0\n출격해라!!')
    stage.delay(5)
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 6)
    stage.showUnit(161, 70, 55, 3)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('북평 공손찬 관저')
    stage.showUnits([
        [
            32,
            10,
            55,
            1],
        [
            33,
            2,
            52,
            1],
        [
            3,
            2,
            58,
            1]])
    stage.say('&32\n보귀!')
    stage.delay(5)
    stage.unitsMove([
        [
            stage.unit(32),
            54,
            55,
            1],
        [
            stage.unit(33),
            46,
            52,
            1],
        [
            stage.unit(3),
            46,
            58,
            1]])
    stage.say('&161\n오, 유비, 무슨 일이야?\n&32\n보귀,\n쉬저우 도겸은 지원을 요청하기 위해 사람들을 보냈다.')
    stage.unit(161).setAction(3)
    stage.say('&161\n정말?')
    stage.unit(161).setAction(0)
    stage.say('&161\nHowever아군 원소군과 대치 상태에 있었다,\n그들은 정말로 증원군을 보낼 수 없었다.\n&32\n보귀, 내가 지원하러 갈게!')
    stage.unit(161).setAction(3)
    stage.say('&161\n뭐라고?! 지원하러 갔다고? 왜?\n&32\n도겸 사람들을 아끼는 사람이야,\n누군가가 죽는 걸 가만히 볼 수 없어.')
    stage.unit(161).setAction(0)
    stage.say('&161\n보강하러 갈지는 네 선택이야.\n하지만 네 병력 규모로는 .......')
    stage.unit(161).setAction(3)
    stage.say('&161\n그런데 며칠 전에 조자룡 장군이 저에게 배신했어요,\n그를 너와 함께 보내.')
    stage.unit(161).setAction(0)
    stage.say('&161\n그가 분명히 도와줄 거라고 믿어요.')
    stage.unit(32).setAction(6)
    stage.say('&32\n정말 고마워. 그럼 출발할 준비 됐어.')
    stage.unit(32).setAction(0, 1)
    stage.delay(3)
    stage.unit(32).setAction(0, 3)
    stage.say('&32\n둘째 형, 셋째 형, 가자!')
    stage.unit(33).setAction(3)
    stage.say('&33\n네!')
    stage.unit(33).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n우리가 얼마나 강력한지 알려조조.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(32),
            18,
            55,
            3],
        [
            stage.unit(33),
            10,
            52,
            3],
        [
            stage.unit(3),
            10,
            58,
            3]])
    stage.unit(33).hide()
    stage.unit(3).hide()
    stage.unit(32).move(5, 55, 3)
    stage.unit(32).hide()
    stage.delay(5)
    stage.effectSound(202, 255)
    stage.delay(3)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 387, 72)
    stage.showHead(145, 507, 135)
    stage.bottomTxt('아버지 조송의 복수를 위해서,', False, False, False)
    stage.delay(5)
    stage.head(0).move(387, 135)
    stage.delay(5)
    stage.bottomTxt('조조 쉬저우를 공격했고, 도겸 그곳에서 주지사로 복무했다.', True, False, False)
    stage.delay(8)
    stage.showHead(32, 467, 0)
    stage.delay(5)
    stage.bottomTxt('유비 세 형제가 이 상황을 보았을 때,', True, True, False)
    stage.delay(5)
    stage.head(32).move(467, 15)
    stage.delay(5)
    stage.bottomTxt('그는 도겸를 보강하러 갔다.', True, False, True)
    stage.bottomTxt('이 시점에서,', False, True, False)
    stage.delay(5)
    stage.showHead(119, 354, 15)
    stage.delay(5)
    stage.bottomTxt('천류의 여포 앞에서 고통에 빠졌고,\n한 남자가 나타났다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene4():
    stage.loadBg(2, 0)
    stage.showUnits([
        [
            119,
            40,
            54,
            1],
        [
            126,
            50,
            54,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('천류 여포 현')
    stage.say('&119\n내 전략가가 되고 싶어?\n&126\n네, 제 이름은 진궁, 공타이입니다.')
    stage.unit(119).move(38, 54, 3)
    stage.say('&119\n정말? 지금 머물 곳도 없어.\n&126\n곧 이용할 수 있을 거예요.')
    stage.unit(119).setAction(0, 1)
    stage.say('&119\n뭐라고!?')
    stage.unit(126).setAction(0, 1)
    stage.say('&126\n푸양 조조가 그의 아버지를 죽였는데, 이는 서주 도겸가 그의 아버지를 죽였기 때문이다,\n그래서 그는 전 군대를 동원해 쉬저우를 공격했다,\n아버지의 복수를 위해서.')
    stage.say('&126\n이 기회를 이용해 푸양을 공격한다면......')
    stage.unit(119).setAction(2)
    stage.say('&119\n그거 너무 비열하지 않나요?')
    stage.unit(126).setAction(0, 3)
    stage.say('&126\n정의는 우리 편입니다.')
    stage.unit(119).setAction(0)
    stage.say('&119\n왜 ......?')
    stage.say('&126\n개인적인 원한을 갚기 위해 조조 그는 쉬저우를 공격했다.\n&126\n푸양을 포획한 것은 바로 그의 잔혹 행위를 막기 위한 것이었다,\n더불어, 혼란스러운 시대에 살아남기 위해,\n기지는 필수적입니다.\n&119\n정말......?')
    stage.delay(10)
    stage.unit(119).setAction(0, 2)
    stage.say('&119\n네 말이 맞아... 살아남아야 해.\n&126\n정확히 그렇습니다.\n&119\n초선.......\n&126\n응?')
    stage.unit(119).setAction(0, 1)
    stage.say('&119\n아니, 아무것도 아니야.\n좋아! 네가 내 전략가가 되어도 돼.')
    stage.unit(119).setAction(17, 1)
    stage.say('&119\n푸양을 공격해라!')
    stage.delay(5)
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene5():
    model.unitJoin(22, 0, 0)
    model.unitJoin(21, 0, 0)
    if vars[1013]:
        gvars[0] = 21
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 22
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene6():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1],
        [
            6,
            38,
            46,
            1],
        [
            16,
            38,
            40,
            1],
        [
            20,
            60,
            52,
            3],
        [
            22,
            60,
            46,
            3],
        [
            21,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('서저우 외곽에 있는 조조군 본진')
    stage.say('&0\n이제 쉬저우를 공격하라!')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        22,
        21])
    gvars[4076] = 0
    gvars[4057] = 5
    stage.setBattlePos([
        [
            0,
            12],
        [
            0,
            11],
        [
            0,
            13],
        [
            1,
            12],
        [
            1,
            11],
        [
            1,
            13],
        [
            1,
            10],
        [
            1,
            14],
        [
            0,
            10],
        [
            0,
            14],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene7():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출격.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n맹덕, 네 기분은 이해하지만......\n&0\n원양, 더 이상 말하지 마.')
    if stage.unitClickTest(6):
        stage.say('&6\n방금 무기 가게 사람이 말했어,\n가죽 방패와 기타 보조 장비가 도착했습니다.\n&6\n그는 또한 앞으로 더 좋은 일이 있을 거라고도 말했다.\n&0\n정말?')
    if stage.unitClickTest(16):
        stage.say('&16\n나는 오직 주군 말의 머리만 본다.')
    if stage.unitClickTest(22):
        stage.say('&22\n나는 도사 승려다; 내 전략만 쓰면,\n적의 상황을 악화시킬 수 있다,\n이로 인해 전투는 아군에게 유리하게 진행됩니다.')
    if stage.unitClickTest(21):
        stage.say('&21\n모든 공격 전략은 전략가인 저에게 맡기세요......\n아, 문약 씨도 여기 계시네요. 하하, 죄송합니다.')
    if stage.unitClickTest(20):
        stage.say('&20\n쉬저우 시 서쪽에는 광활한 초원과 평야가 펼쳐져 있다,\n아군 여기서 공격할 수 있어.\n&20\n또한......,\n유비의 군대가 도겸를 지원하러 왔다는 소문을 들었다.\n&0\n유비......?\n&20\n군대도겸 도시를 죽을 때까지 방어할 준비를 했다.\n&0\n그는 분명 유비를 기다리고 있을 거야,\n그 늙은 여우는 좀 똑똑한 사람한테만 장난칠 줄 알아.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
