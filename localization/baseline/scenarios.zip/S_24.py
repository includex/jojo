# Source Generated with Decompyle++
# File: S_24.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(22,1)',
        '(10,8)'])
    stage.nearEvent([
        0,
        115,
        0,
        114], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 115, 0, 2, 2)
    stage.createEnemy(
        [{'id': 115, 'x': 22, 'y': 1, 'lv': 4, 'i': 0},
         {'id': 114, 'x': 22, 'y': 2, 'lv': 4, 'ai': 0, 'i': 1},
         {'id': 298, 'x': 21, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 2},
         {'id': 210, 'x': 20, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 3},
         {'id': 211, 'x': 22, 'y': 3, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 212, 'x': 10, 'y': 8, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 213, 'x': 9, 'y': 8, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 214, 'x': 10, 'y': 9, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 234, 'x': 10, 'y': 7, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 235, 'x': 11, 'y': 8, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 310, 'hide': 1, 'x': 3, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 10},
         {'id': 311, 'hide': 1, 'x': 12, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 11},
         {'id': 390, 'hide': 1, 'x': 3, 'y': 9, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 391, 'hide': 1, 'x': 4, 'y': 7, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 392, 'hide': 1, 'x': 11, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 393, 'hide': 1, 'x': 13, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 318, 'hide': 1, 'x': 6, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 319, 'hide': 1, 'x': 7, 'y': 3, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 320, 'hide': 1, 'x': 15, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 321, 'hide': 1, 'x': 16, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 322, 'hide': 1, 'x': 14, 'y': 17, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 323, 'hide': 1, 'x': 16, 'y': 17, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 324, 'hide': 1, 'x': 19, 'y': 18, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 325, 'hide': 1, 'x': 21, 'y': 19, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 326, 'hide': 1, 'x': 12, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 327, 'hide': 1, 'x': 14, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 328, 'hide': 1, 'x': 18, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 329, 'hide': 1, 'x': 20, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 312, 'hide': 1, 'x': 15, 'y': 17, 'lv': 0, 'ai': 1, 'i': 28},
         {'id': 313, 'hide': 1, 'x': 20, 'y': 19, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 314, 'hide': 1, 'x': 13, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 315, 'hide': 1, 'x': 19, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 236, 'x': 22, 'y': 0, 'lv': 0, 'ai': 0, 'i': 32},
         {'id': 237, 'x': 23, 'y': 1, 'lv': 0, 'ai': 0, 'i': 33}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 6,
            'y': 16,
            'dir': 0 },
        {
            'idx': 1,
            'x': 5,
            'y': 15,
            'dir': 0 },
        {
            'idx': 2,
            'x': 7,
            'y': 17,
            'dir': 0 },
        {
            'idx': 3,
            'x': 7,
            'y': 15,
            'dir': 0 },
        {
            'idx': 4,
            'x': 6,
            'y': 14,
            'dir': 0 },
        {
            'idx': 5,
            'x': 8,
            'y': 16,
            'dir': 0 },
        {
            'idx': 6,
            'x': 5,
            'y': 17,
            'dir': 0 },
        {
            'idx': 7,
            'dir': 0 },
        {
            'idx': 8,
            'dir': 0 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.loadBg(24)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab21')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab21')
    stage.draw()
    stage.bgSound(2)
    stage.say('&115\n여기까지 쫓아올 줄은 몰랐어......\n적은 여전히 포기하지 않았다......\n&114\n이건 조조를 물리칠 좋은 기회야,\n우리 비밀 부대에 합류하세요.\n&115\n모든 것은 원희 형에게 달려 있습니다.\n&0\n여기가 국경 지역이야,\n행진은 정말 지치게 만듭니다.')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n주군, 원상 바로 네 앞에 있어,\n한 번에 전멸시키자.')
    stage.unit(22).setAction(9)
    stage.say('&22\n기침, 기침, 기침......')
    stage.setUnitStatus([
        {
            'hp': -50,
            'unit': stage.unit(22) }])
    stage.unit(2).move(5, 16, 0)
    stage.say('&2\n곽가Mr. 안녕하세요, 무슨 일이에요!"\n&22\n아... 걱정 마,\n가자.......\n&2\n어떻게 그럴 수 있지!\n이대로 가면 치명적일 거야!')
    stage.unit(2).setDir(stage.countDir(2, 0))
    stage.say('&2\n주군, 원정을 중단하고 쉬두로 돌아가라!\n병사들은 밤낮으로 이동하느라 지쳐 있었다,\n그리고 만약 이게 ...... 씨continues곽가 거라면!\n&22\n이건 일생에 한 번뿐인 기회야...\n절대 놓칠 수 없어요!\n&22\n주군 후회하기보단 차라리 죽겠어,\n기침, 기침......\n&0\n(이번 원정은 정말 큰 기회였다...\n하지만 이런 상황이 계속된다면, 곽가...... )')
    sel = stage.choice('계속 행진하세요\n그리고 원정을 중단시키기 위해', -1)
    if sel == 1:
        stage.say('미안하다, 곽가…… 네 목숨은 조모에게 맡긴다!')
        stage.unit(2).setAction(10)
        stage.unit(2).setDir(stage.countDir(2, 0))
        stage.say('&2\n뭐-뭐라고!\n주군 정말로 마음을 정했어!\n&22\n원위안 장군. 걱정하지 마세요!\n펑샤오가 모두를 연루시킨다면,\n평생 치욕이 될 거야. 흠, 음......\n&0\n흠......, 우리는 원상를 제거하기 위한 원정을 떠나려 합니다,\n문제가 해결된 후, 곽가 편히 쉴 수 있었다.')
        stage.unit(0).setAction(5)
        stage.say('&0\n전면 군대 공격!\n한 번의 결정적인 움직임으로 적군를 짓밟아라!')
        stage.unit(0).setAction(0)
        stage.setWinCondition('승리 조건\n1. 원상 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
        stage.showWinCondition('원상를 물리쳐라!')
        stage.unit(115).heightLight()
    elif sel == 2:
        stage.say('&0\n………….\n이 원정을 멈춰라!\n후퇴!\n&22\n주님, 주군 걱정하지 마세요...\n기침, 기침, 기침......\n&0\n앞으로 원상...... 사냥할 기회가 더 많아질 것입니다.\n하지만 만약 나쁜 일이 생기면,\n이 손실은 돌이킬 수 없습니다......\n&2\n주군Clear 심판......!')
        stage.unit(2).setDir(stage.countDir(2, 22))
        stage.say('&2\n곽가Mr. 주군, 이것도 좋은 의도야!"\n&22\n고마워요, thanks주군......\n음, 음, ......\n&0\n그렇다면 철수합시다!\n적은 반드시 군대를 보내 추격할 것이다,\n그들을 없앨 방법을 찾아야 해......')
        stage.unit(0).setDir(1)
        stage.unit(22).setDir(1)
        stage.unit(2).setDir(1)
        stage.unit(0).move(7, 17, 1)
        stage.unit(22).move(6, 16, 1)
        stage.unit(2).move(8, 18, 1)
        stage.unit(5, 1).move(9, 17, 1)
        stage.unit(3, 1).move(8, 16, 1)
        stage.unit(6, 1).move(6, 18, 1)
        stage.unit(4, 1).move(7, 15, 1)
        stage.setWinCondition('승리 조건\n1. 곽가 남동쪽 끝에 도달합니다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
        stage.showWinCondition('곽가 도망쳐!')
        stage.unit(22).heightLight()
        stage.heightLight(22, 20, 23, 23)
        stage.say('&114\n적의 행동이 좀 이상해,\n철수를 준비하는 것 같아요.\n&115\n여기까지 왔네,\n왜 철회하는가?\n조의 군대는 정확히 무슨 일이 있었나요?\n&114\n어쨌든, 이건 좋은 기회야.\n&115\n네, 그렇다면.........\n그들 뒤의 매복으로 돌아가라,\n행동을 시작할 수 있습니다!\n&115\n매복 명령을 보내 적의 퇴로를 차단하라!')
        stage.unit(114).setAction(6)
        stage.say('&114\n매복 공격!\n조조의 도주로를 차단해!')
        stage.unit(114).setAction(0)
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(324).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(327).show()
        stage.unit(328).show()
        stage.unit(329).show()
        stage.unit(312).show()
        stage.unit(313).show()
        stage.unit(314).show()
        stage.unit(315).show()
        vars[2] = 1
    stage.startOper()
    vars[524] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[11] and not vars[12] and not vars[50] and not vars[51] and stage.round() >= 3:
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.say('&115\n좋아요...... 한 걸음 차이입니다.\n이번에는 조조의 군대를 용서해서는 안 된다,\n타이거즈에 합류해.')
        stage.unit(114).setDir(stage.countDir(114, 0))
        stage.unit(114).setAction(6)
        stage.say('&114\n돌격!\n놓지 마조조!')
        stage.unit(114).setAction(0)
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(392).show()
        stage.unit(393).show()
        stage.unit(0).setDir(stage.countDir(0, 390))
        stage.unit(0).setAction(10)
        stage.say('&0\n저-저게 뭐야!\n호랑이야?\n적이 호랑이를 조종할 수 있을까!?')
        if not vars[52]:
            stage.unit(22).setDir(stage.countDir(22, 0))
            stage.say('&22\n주군 걱정할 필요 없어,\n그냥 침착해......\n절대 이적도 안 돼아군...... 기침, 기침......')
        vars[11] = 1
    if vars[30] and not vars[2] and not vars[11] and not vars[12] and not vars[50] and not vars[51] and stage.round() >= 3:
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.say('&115\n하하하...!\n타이거 부대에 합류하라!')
        stage.unit(114).setDir(stage.countDir(114, 0))
        stage.unit(114).setAction(6)
        stage.say('&114\n돌격!\n놓지 마조조!')
        stage.unit(114).setAction(0)
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(392).show()
        stage.unit(393).show()
        stage.unit(0).setDir(stage.countDir(0, 390))
        stage.unit(0).setAction(10)
        stage.say('&0\n저-저게 뭐야!\n호랑이야?\n적이 호랑이를 조종할 수 있을까!?')
        if not vars[52]:
            stage.unit(22).setDir(stage.countDir(22, 0))
            stage.say('&22\n주군 걱정할 필요 없어,\n그냥 침착해......\n절대 이적도 안 돼아군...... 기침, 기침......')
        vars[12] = 1
    if not vars[13] and not vars[52] and stage.round() == 5:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침......\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[13] = 1
    if not vars[14] and not vars[52] and stage.round() == 10:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침......\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[14] = 1
    if not vars[15] and not vars[52] and stage.round() == 15:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침, 기침.........\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[15] = 1
    if not vars[16] and not vars[52] and stage.round() == 20:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침......\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[16] = 1
    if not vars[17] and not vars[52] and stage.round() == 25:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침......\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[17] = 1
    if not vars[18] and not vars[52] and stage.round() == 30:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침, 기침.........\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[18] = 1
    if not vars[19] and not vars[52] and stage.round() == 35:
        stage.unit(22).setAction(3)
        stage.say('&22\n기침, 기침......\n음음 음 .........')
        stage.setUnitStatus([
            {
                'hp': -50,
                'unit': stage.unit(22) }])
        vars[19] = 1
    if not vars[20] and stage.isInPos(1025, 22, 1):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 10, 8):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[2] and not vars[6] and not vars[50] and not vars[51] and stage.totalRectUnit(2, 5, 0, 23, 13) < 7:
        stage.unit(115).setDir(stage.countDir(115, 114))
        stage.unit(114).setDir(stage.countDir(114, 115))
        stage.say('&115\n응? 어떻게 아군 멸망할 수 있지?\n이런 상태가 계속되면 생명을 위협할 수 있습니다......\n&115\n그런데!\n적의 매복 퇴로를 차단하며,\n모두 다시 불러!\n&114\n…………\n&115\n둘째 형, 무슨 일이야?\n&114\n그 병사들은 상황이 절박하다는 것을 아군 보았다,\n모두가 도망치려고 달려갔다......\n급히 만든 유닛은 정말 이걸 해낼 수 없어요!')
        stage.unit(115).setAction(10)
        stage.say('&115\n뭐-뭐라고!?\n농담하지 마!\n그럼, 우리는 무엇을 해야 할까요!?')
        vars[6] = 1
    if not vars[30] and stage.isInRect(1025, 5, 0, 23, 13):
        vars[30] = 1
    if vars[2] and not vars[31] and stage.isInRect(22, 22, 20, 23, 23):
        stage.resumeCtrl()
        stage.say('&22\n쉭......\n드디어 탈출했다......')
        stage.unit(22).hide()
        vars[31] = 1
        stage.talk(1, 186, '주군, 곽가 씨가 무사히 도망쳤어!')
        stage.say('&0\n흠, 우리도 후퇴하자!\n전군을 후퇴시켜라!')
        stage.reward(0, [
            160,
            -1])
        vars[100] = 1
        stage.end()
        vars[0] = 1
        vars[624] = 1
        vars[724] = 1
        return True
    if not vars[40] and stage.isNear(0, 115, True):
        stage.unit(0).setDir(stage.countDir(0, 115))
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.say('&0\n원상! 지금 널 죽이면 원가의 가문이 끊긴다.\n원씨 가문의 마지막 남은 향로서,\n여러분 생각은 어떠신가요?\n&115\n무슨 헛소리를 하는 거야!\n실패하지 않을 거야.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 114, True):
        stage.unit(0).setDir(stage.countDir(0, 114))
        stage.unit(114).setDir(stage.countDir(114, 0))
        stage.say('&0\n당신은 원담와 원상의 분쟁 사이에 끼어 있습니다,\n꽤 괴로워하시겠죠.\n이런 적은 정말 불쌍하다!\n&114\n무슨 헛소리를 하는 거야! 형제들이여, 너희가 아니었다면,\n지금의 상태에 이르지도 않았을 것이다......\n절대 용서하지 않을 거야.')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(115, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&115\n젠장, 젠장......\n오직 일시적인 후퇴만이 가능했다,\n후퇴! 빨리 후퇴해!')
        stage.unit(115).hide(1)
        if not vars[51]:
            stage.say('&114\n(우리는 더 이상 싸울 능력이 없조조,\n세계 정복의 꿈도 허황된 꿈이 되었다...... )')
            vars[51] = 1
        stage.setRectUnitHide(0, 0, 23, 23, 2)
        vars[50] = 1
        stage.say('&0\n좋아, 드디어 적을 물리쳤어!\n아군 이겼어!')
        stage.talk(22, 22, '빅토리, 그게 ...주군?\n기침...... 기침, 기침, 기침, 기침!\n기침, 기침...... 음음 음......')
        stage.say('곽가, 이건 다 네 덕분이야…… 정말 잘했어……')
        stage.reward()
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[624] = 1
        return True
    if not vars[51] and stage.unitStateTest(114, 7, 0, 2):
        stage.say('&114\n하지만, 젠장...... 더는 못 버티겠어!\n후퇴!')
        stage.unit(115).setDir(stage.countDir(115, 114))
        stage.unit(114).hide(1)
        stage.say('&115\n2. 둘째 형.\n음음 흠 흠흠 ......\n빨리 도망가야겠어.')
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(22, 7, 0, 2):
        if vars[2]:
            stage.unit(22).setDir(stage.countDir(22, 0))
            stage.say('&22\n음... 음......\n주군... 먼저 물러나겠습니다......\n음, 음......')
            stage.unit(0).setDir(stage.countDir(0, 22))
            stage.say('&0\n흠......\n너는 뒤에서 쉬는 게 좋겠어,\n여기 적들은 바로 처리할게.')
            stage.unit(22).retreatTxt(False)
            stage.unit(22).hide(1)
            stage.setWinCondition('승리 조건\n1. 원상 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
            stage.showWinCondition('원상를 물리쳐라!')
            stage.unit(115).heightLight()
        else:
            stage.unit(22).setDir(stage.countDir(22, 0))
            stage.say('&22\n음... 음......\n주군... 먼저 물러나겠습니다......\n음, 음......')
            stage.unit(0).setDir(stage.countDir(0, 22))
            stage.say('곽, 곽가! 곽가! 아아, 정말이지…… 너무 방심했어… 괜찮아…… 뒤에서 좀 쉬면 돼…… 콜록, 콜록……')
            stage.unit(22).retreatTxt(False)
            stage.unit(22).hide(1)
            stage.unit(0).setDir(stage.countDir(0, 115))
            stage.say('(곽가는 아마 곧 세상을 떠날 것 같군…… 전부 원상 이 녀석 탓이야!) 전군 돌격! 원상의 목을 베어라! 자신까지 아끼지 않는 곽가 때문에, 우리 더는 물러서지 않는다!')
        vars[52] = 1
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 물리쳤어.\n아군 이겼어!')
        stage.talk(22, 22, '빅토리, 그게 ...주군?\n기침...... 기침, 기침, 기침, 기침!\n기침, 기침...... 음음 음......')
        stage.say('곽가, 이건 다 네 덕분이야…… 정말 잘했어……')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[624] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원상에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
