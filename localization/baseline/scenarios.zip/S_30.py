# Source Generated with Decompyle++
# File: S_30.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(15,18)'])
    stage.nearEvent([
        11,
        95,
        2,
        95,
        2,
        76], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, -1, 1, 1)
    stage.createEnemy([
        {
            'id': 76,
            'x': 14,
            'y': 17,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 0 },
        {
            'id': 98,
            'x': 15,
            'y': 17,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 78,
            'x': 15,
            'y': 18,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 2 },
        {
            'id': 97,
            'x': 14,
            'y': 18,
            'dir': 0,
            'lv': 6,
            'ai': 0,
            'i': 3 },
        {
            'id': 358,
            'x': 13,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 359,
            'x': 16,
            'y': 17,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 234,
            'x': 13,
            'y': 18,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 235,
            'x': 16,
            'y': 18,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 7 },
        {
            'id': 95,
            'x': 3,
            'y': 4,
            'dir': 1,
            'lv': 6,
            'ai': 0,
            'i': 8 },
        {
            'id': 258,
            'x': 3,
            'y': 5,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 9 },
        {
            'id': 282,
            'x': 2,
            'y': 4,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 10 },
        {
            'id': 283,
            'x': 2,
            'y': 5,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 11 },
        {
            'id': 360,
            'x': 3,
            'y': 3,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 12 },
        {
            'id': 361,
            'x': 3,
            'y': 6,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 13 },
        {
            'id': 362,
            'x': 3,
            'y': 2,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 14 },
        {
            'id': 363,
            'x': 3,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 15 },
        {
            'id': 318,
            'hide': 1,
            'x': 9,
            'y': 1,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 319,
            'hide': 1,
            'x': 9,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 236,
            'x': 2,
            'y': 3,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 18 },
        {
            'id': 237,
            'x': 2,
            'y': 6,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 19 },
        {
            'id': 238,
            'x': 2,
            'y': 2,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 20 },
        {
            'id': 239,
            'x': 2,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 21 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 14,
            'y': 5 },
        {
            'idx': 1,
            'x': 13,
            'y': 4 },
        {
            'idx': 2,
            'x': 11,
            'y': 5 },
        {
            'idx': 3,
            'x': 8,
            'y': 2,
            'dir': 3 },
        {
            'idx': 4,
            'x': 8,
            'y': 7,
            'dir': 3 },
        {
            'idx': 5,
            'x': 12,
            'y': 11 },
        {
            'idx': 6,
            'x': 16,
            'y': 11 },
        {
            'idx': 7,
            'dir': 0 },
        {
            'idx': 8,
            'dir': 0 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(95, -1, 0, 11, 0, -1)
    stage.setEnemyEquip(97, -1, 0, -1, 0, 28)
    stage.setEnemyEquip(98, -1, 0, -1, 0, 13)
    stage.loadBg(30)
    stage.setObjects(True, 17, [
        [
            23,
            7,
            4],
        [
            24,
            7,
            5]])
    stage.setObjects(True, 17, [
        [
            25,
            14,
            12],
        [
            26,
            15,
            12]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(1)
    stage.say('&78\n주군 적은 도시 안에서 굳건히 버텼고,\n안 나올 것 같아.\n어떻게 해야 할까요?\n&76\n응.\n젠장it장료...... 정말 다루기 힘들었어!\n이 대치 상태를 계속하는 것은 시간 낭비뿐이었다.\n&98\n적을 도시 밖으로 유인할 수 있다면,\n적의 적은 병력은 단 한 번의 공격에도 상대가 되지 못했다......')
    stage.unit(76).setDir(2)
    stage.say('&76\n이 순간, 공진이 바로 근처에 있었다.\n누가 기발한 계획을 가지고 있을까요?')
    stage.unit(95).setDir(stage.countDir(95, 76))
    stage.say('&95\n주군 걱정할 필요 없어; 좋은 계획이 있어."\n나는 오랫동안 도시 안에 매복 부대를 배치해 왔다,\n&95\n때가 되면, 그들은 불을 지르고,\n그리고 서문을 열 기회를 기다렸다.')
    stage.unit(76).setDir(stage.countDir(76, 95))
    stage.say('&76\n아, 정말 타이시 치에게 어울리는구나!\n그는 정말 내 손권의 오른팔이야.\n&97\n주군, 그거 정말 좋은 생각이야.\n하지만 실패하면 타이시 장군이 위험에 처할 것이다.\n&95\n위험이 기다리는 것보다 항상 낫다.\n&95\n어쨌든 가도 된다고 허락을 구합니다.\n나는 내 목숨을 걸 준비가 되어 있으며, 성공은 빠르게 올 것이다.\n&76\n응!\n결정은 여러분에게 달렸습니다!\n특히 조심해야 해.')
    stage.unit(10).setDir(stage.countDir(10, 2))
    stage.say('&10\n장 장군님, 우리는 적군를 여러 번 격퇴했습니다,\n병사들에게 보상을 주기 위해 성대한 연회를 여는 것이 더 낫다......')
    stage.unit(2).setDir(stage.countDir(2, 10))
    stage.say('&2\n악진General, 네 기분 이해해.\n하지만 군대가 후퇴하지 않았now손권,\n아직 쉬고 쉴 때가 아니야......')
    stage.bgSound(4)
    stage.unit(318).show()
    stage.unit(319).show()
    stage.setFire(True, 9, 0)
    stage.setFire(True, 10, 1)
    stage.setFire(True, 9, 2)
    stage.setFires(True, [
        [
            9,
            7],
        [
            10,
            7],
        [
            9,
            9]])
    stage.setFire(True, 10, 10)
    stage.unit(318).setAction(8)
    stage.say('&318\n"불이야!" "적군가 도시를 포위하고 있어!"\n적들이 도시 안에 나타났어!')
    stage.unit(319).setDir(3)
    stage.unit(319).setAction(5)
    stage.say('&319\n도시 안에 스파이가 있어!\n빨리 도시 밖으로 도망쳐라!')
    stage.unit(319).setAction(0)
    stage.unit(11).setAction(10)
    stage.say('&11\n무슨 일이야!\n적군 기습 공격?')
    stage.unit(2).setDir(stage.countDir(2, 11))
    stage.say('&2\n리 장군, 진정하고 불안해하지 마세요.\n좀 이상하지 않나요?')
    stage.unit(11).setDir(stage.countDir(11, 319))
    stage.say('&11\n음...... 정말 좀 이상하네요!\n마치 누군가가 혼란을 일으키는 것 같았다.')
    stage.unit(10).setDir(3)
    stage.say('&10\n불길은 서문에도 집중된 듯 보였다.')
    stage.unit(2).setDir(3)
    stage.say('&2\n서문을 열어 적을 유인손권 것이다,\n그렇다면 적과 역전하는 게 낫겠네요.')
    sel = stage.choice('서문을 열어라\n남문을 열어라', 2)
    if sel == 1:
        stage.unit(2).setDir(stage.countDir(2, 10))
        stage.say('&2\n후방 측면에서 적군을 포위하고,\n그는 서문 양쪽에 병력을 집결시켰다.')
        stage.unit(10).setDir(stage.countDir(10, 2))
        stage.say('&10\n시먼에 모여라...... 왜?\n&2\n도시 내에 불안을 일으키며 서문을 열어 기습 공격을 감행했다,\n이것이 그들의 계획이지만, 만약 ......\n&10\n아, 그렇군요.\n적군를 도시로 이끈 후,\n한 번에 쓸어버릴 거야?')
        stage.unit(2).setDir(stage.countDir(2, 11))
        stage.say('&2\n리 장군님, 이 일로 폐를 끼치겠습니다.')
        stage.unit(11).setDir(stage.countDir(11, 2))
        stage.unit(11).setAction(5)
        stage.say('&11\n분명히 이해하겠습니다.\n전 군대가 서문에 집결했다!')
        stage.unit(11).setAction(0)
        stage.unit(3, 1).move(9, 3, 2)
        stage.unit(4, 1).move(9, 6, 0)
        stage.unit(5, 1).move(10, 3, 2)
        stage.unit(6, 1).move(10, 6, 0)
        stage.unit(11).setDir(3)
        stage.say('&11\n준비됐어!\n문 열어!')
        stage.setObjects(False, 16, [
            [
                23,
                7,
                4],
            [
                24,
                7,
                5]])
        stage.unit(95).setAction(5)
        stage.say('&95\n좋아! 지금.\n군대 전체를 이끌고 돌진하라!\n조의 군대를 물리쳐라!')
        stage.unit(95).setAction(0)
        stage.unit(95).move(9, 4, 1)
        stage.unit(258).move(9, 5, 1)
        stage.unit(282).move(8, 4, 1)
        stage.unit(283).move(8, 5, 1)
        stage.unit(360).move(7, 4, 1)
        stage.unit(361).move(7, 5, 1)
        stage.unit(362).move(6, 4, 1)
        stage.unit(363).move(6, 5, 1)
        stage.unit(236).move(5, 4, 1)
        stage.unit(237).move(5, 5, 1)
        stage.unit(238).move(5, 3, 1)
        stage.unit(239).move(5, 6, 1)
        stage.say('&11\n속았구나, 타이시 치!\n정말 바보 같아!\n군대 전체가 함께 공격했다!\n&95\n뭐-뭐라고!?\n좋지 않아!\n계획이 드러났어!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 8,
                'y1': 4,
                'x2': 9,
                'y2': 5,
                'camp': 2 }])
        vars[2] = 1
    elif sel == 2:
        stage.unit(2).setDir(stage.countDir(2, 10))
        stage.say('&2\n적의 후퇴를 포위하라,\n군대는 남문에 집결했다.')
        stage.unit(10).setDir(stage.countDir(10, 2))
        stage.say("&10\n남문에 집합하라...... 왜?\n&2\n서문을 열어 기습 공격을 준비하라,\n이것이 그들의 계획입니다,\n그 결과 주 진영의 방어는 필연적으로 약해졌다.\n&10\n그래서 그런 거야.\n이건 적의 본진을 공격할 좋은 기회가 될 거야.\n&2\n서문을 뚫으려는 결심이 확고하니,\n꿈속에서도 상상도 못 했을 것이다,\n남문에서 공격할 거야.\n&10\n이게 바로 '강한 자를 피하고 약한 사람을 때린다'는 것이다!")
        stage.unit(2).setDir(stage.countDir(2, 11))
        stage.say('&2\n리 장군, 성 안의 적군은 당신 손에 달려 있습니다.')
        stage.unit(11).setDir(stage.countDir(11, 2))
        stage.say('&11\n장 장군, 저에게 맡기세요.\n도시 밖의 적들을 상대하는 데 집중하세요.')
        stage.unit(2).move(14, 11, 2)
        stage.unit(10).move(15, 11, 2)
        stage.unit(3, 1).move(14, 10, 2)
        stage.unit(4, 1).move(15, 10, 2)
        stage.unit(5, 1).move(14, 9, 2)
        stage.unit(6, 1).move(15, 9, 2)
        stage.unit(2).setDir(2)
        stage.unit(2).setAction(5)
        stage.say('&2\n좋아! 성문을 열어라!\n모두 나와 함께 돌진해!')
        stage.unit(2).setAction(0)
        stage.setObjects(False, 16, [
            [
                25,
                14,
                12],
            [
                26,
                15,
                12]])
        stage.unit(2).move(14, 15, 2)
        stage.unit(10).move(15, 15, 2)
        stage.unit(3, 1).move(14, 14, 2)
        stage.unit(4, 1).move(15, 14, 2)
        stage.unit(5, 1).move(14, 13, 2)
        stage.unit(6, 1).move(15, 13, 2)
        stage.unit(76).setDir(stage.countDir(76, 2))
        stage.unit(78).setDir(stage.countDir(78, 2))
        stage.unit(97).setDir(stage.countDir(97, 2))
        stage.unit(98).setDir(stage.countDir(98, 2))
        stage.unit(76).setAction(10)
        stage.say('&76\n뭐라고! 적이 공격하고 있다고!?\n어떻게 이런 일이 일어날 수 있지...... 시먼에게 무슨 일이야!?\n&98\n적이 공격하고 있다고!?\n&78\n빨리! 적이 주군 가까이 오게 할 수 없어!\n&97\n오, 안 돼!\n뜻밖에도 그는 적군에게 공격당했다......')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 13,
                'y1': 17,
                'x2': 16,
                'y2': 17,
                'camp': 2 }])
        stage.say('&95\n왜 서문이 열리지 않나요!\n뭐라고!? 주군의 본부가 공격당했다고!?\n도대체 무슨 일이야!')
        stage.unit(95).setDir(stage.countDir(95, 76))
        stage.unit(95).setAction(5)
        stage.say('&95\n음, 서둘러!\n본격적인 구조 작업으로 돌아가라!')
        stage.unit(95).setAction(0)
        stage.unit(95).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        stage.unit(360).setAI(1)
        stage.unit(361).setAI(1)
        stage.unit(362).setAI(1)
        stage.unit(363).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 전면적인 군대 후퇴.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[530] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[20] and stage.isInPos(1025, 15, 18):
        stage.getItem(151, -1, True, 1025)
        vars[20] = 1
    if not vars[40] and stage.isNear(11, 95, True):
        stage.unit(11).setDir(stage.countDir(11, 95))
        stage.unit(95).setDir(stage.countDir(95, 11))
        stage.say('&11\n유명한 동무 장군 태시치는 여기서 죽을 운명이었을 가능성이 높았다!\n내가 배웅이전게.\n&95\n말도 안 돼!\n전투는 이제 막 시작됐어!')
        vars[40] = 1
    if not vars[41] and stage.isNear(2, 95, True):
        stage.unit(95).setDir(stage.countDir(95, 2))
        stage.unit(2).setDir(stage.countDir(2, 95))
        stage.say('&95\n이 대결에서 장군은 영리했다,\n그가 유능한 장군인 것도 당연하다.\n&2\n당신은 또한 널리 알려진 저명한 장군입니다,\n장군과 마주할 수 있다는 것은 장료에게 영광이었다.')
        vars[41] = 1
    if vars[629] and not vars[42] and stage.isNear(2, 76, True):
        stage.unit(2).setDir(stage.countDir(2, 76))
        stage.unit(76).setDir(stage.countDir(76, 2))
        stage.say('&2\n손권, 오늘 레드 클리프의 증오를 반드시 복수해야 한다!\n&76\n흥! 이 승리는 동오의 것이다.')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n어떻게, 어떻게 이런 일이 일어날 수 있지......\n이 탐험이 정말 그렇게 끝날 수 있을까......\n음, 그게 실수였던 것 같손권......')
        if not vars[2]:
            if not vars[51]:
                stage.unit(78).setDir(stage.countDir(78, 76))
                stage.unit(140).setAction(5)
                stage.say('&78\n주님, 주군!\n적군이 가까이 오지 못하게 주군!\n모두, 와서 지켜주군!\n&78\n서둘러! 주군, 지금이 ......')
                stage.unit(140).setAction(0)
                vars[51] = 1
            if not vars[53]:
                stage.unit(97).setDir(stage.countDir(97, 76))
                stage.say('&97\n주군, 여긴 안전하지 않아.\n빨리 여기서 나가주세요!')
                vars[53] = 1
            stage.unit(76).hide()
            stage.unit(78).hide()
            stage.unit(97).hide()
        else:
            stage.unit(76).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n세상에! 빨리 도망쳐야 해......\n싸움은 내 전문 분야가 아니야......')
        stage.unit(78).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(98, 7, 0, 2):
        stage.say('&98\n뭐라고!?\n음, 너무 부주의한 것 같아......\n내 인생은 끝났어...... 훗!')
        stage.unit(98).hide(2)
        stage.getItem(120, -1, True, 1027)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(97, 7, 0, 2):
        stage.say('&97\n좋지 않아!\n음...... 상황을 되돌릴 방법은 없어......')
        if not vars[50]:
            stage.unit(97).setDir(stage.countDir(97, 76))
            stage.say('&97\n주군, 제 마지막 조언을 들어주세요......\n여기서 안전하게 후퇴할 수 있다면,\n그럼 수도를 몰링으로 옮겨 주세요......\n&97\n그곳에는 황제의 기운이 감돌고 있다,\n동오에 매우 적합했다.\n나, 나 가야 해...... 음.')
            stage.unit(76).setDir(stage.countDir(76, 97))
            stage.say('&76\n장홍!')
        stage.unit(97).hide(2)
        stage.getItem(135, -1, True, 1027)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(95, 7, 0, 2):
        stage.say('&95\n내 거대한 야망은 이루지 못했고, 후회만 남았다......\n이게 정말 내 운명일까...... 흠!')
        stage.unit(95).hide(2)
        stage.getItem(79, -1, True, 1027)
        if vars[2] and not vars[50] and not vars[51] and not vars[52] and not vars[53]:
            stage.say('&76\n뭐-뭐라고!\n타이시 츠 장군이 죽었다고!?\n&97\n타이시 츠 장군......\n&78\n타이시 츠 장군은 .........\n우리는 실제로 장군을 잃었는데, 그중 가장 용감한 장군이었다......\n이는 동우에 있어 정말 엄청난 손실이다.\n&98\n서둘러 병력을 보내 구출하라!\n그 병사들은 아직도 고생 중일 거야!\n&76\n음, 음!\n젠장조조!\n이 빚은 이렇게 쉽게 해결되지 않을 거야!')
        stage.unit(76).setAI(1)
        stage.unit(78).setAI(1)
        stage.unit(97).setAI(1)
        stage.unit(98).setAI(1)
        stage.unit(358).setAI(1)
        stage.unit(359).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[54] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&2\n좋아, 드디어 적군를 이겼어!\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[630] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조의 군대는 손권군에게 패배했다')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
