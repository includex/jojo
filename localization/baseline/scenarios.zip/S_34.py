# Source Generated with Decompyle++
# File: S_34.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        21,
        22,
        23,
        24], [
        '(10,33)',
        '(11,33)',
        '(10,32)',
        '(11,32)'])
    stage.nearEvent([
        9,
        89])
    stage.nearEvent([
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 76, 0, 0, 1)
    stage.createEnemy(
        [{'id': 76, 'x': 10, 'y': 33, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 86, 'x': 11, 'y': 33, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 1},
         {'id': 87, 'x': 10, 'y': 32, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 2},
         {'id': 82, 'x': 11, 'y': 32, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 3},
         {'id': 358, 'x': 9, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 359, 'x': 12, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 298, 'x': 9, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 299, 'x': 12, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 89, 'x': 10, 'y': 26, 'dir': 0, 'lv': 4, 'i': 8},
         {'id': 83, 'x': 11, 'y': 26, 'dir': 0, 'lv': 4, 'i': 9},
         {'id': 80, 'x': 12, 'y': 26, 'dir': 0, 'lv': 6, 'i': 10},
         {'id': 93, 'x': 13, 'y': 26, 'dir': 0, 'lv': 4, 'i': 11},
         {'id': 360, 'x': 10, 'y': 25, 'dir': 0, 'lv': 0, 'i': 12},
         {'id': 361, 'x': 11, 'y': 25, 'dir': 0, 'lv': 0, 'i': 13},
         {'id': 362, 'x': 12, 'y': 25, 'dir': 0, 'lv': 0, 'i': 14},
         {'id': 363, 'x': 13, 'y': 25, 'dir': 0, 'lv': 0, 'i': 15},
         {'id': 85, 'x': 11, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 16},
         {'id': 364, 'x': 9, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 365, 'x': 10, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 366, 'x': 12, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 367, 'x': 13, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 234, 'x': 10, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 235, 'x': 11, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 236, 'x': 12, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 84,
          'hide': 1,
          'x': 18,
          'y': 0,
          'dir': 3,
          'lv': 6,
          'ai': 4,
          'targetX': 12,
          'targetY': 8,
          'i': 24},
         {'id': 310,
          'hide': 1,
          'x': 17,
          'y': 0,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 12,
          'targetY': 8,
          'i': 25},
         {'id': 311,
          'hide': 1,
          'x': 18,
          'y': 1,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 12,
          'targetY': 8,
          'i': 26},
         {'id': 318,
          'hide': 1,
          'x': 17,
          'y': 1,
          'dir': 3,
          'lv': 0,
          'ai': 4,
          'targetX': 12,
          'targetY': 8,
          'i': 27},
         {'id': 88, 'x': 11, 'y': 34, 'dir': 1, 'lv': 4, 'i': 28},
         {'id': 258, 'hide': 1, 'x': 2, 'y': 37, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 259, 'hide': 1, 'x': 3, 'y': 37, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 260, 'hide': 1, 'x': 4, 'y': 38, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 261, 'hide': 1, 'x': 5, 'y': 39, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 282, 'hide': 1, 'x': 2, 'y': 38, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 283, 'hide': 1, 'x': 3, 'y': 39, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 284, 'hide': 1, 'x': 4, 'y': 39, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 81, 'hide': 1, 'x': 22, 'y': 18, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 36},
         {'id': 368, 'hide': 1, 'x': 22, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 369, 'hide': 1, 'x': 22, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 370, 'hide': 1, 'x': 22, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 371, 'hide': 1, 'x': 23, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 372, 'hide': 1, 'x': 23, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 373, 'hide': 1, 'x': 23, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 42},
         {'id': 374, 'hide': 1, 'x': 23, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 43}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 12,
            'y': 8 },
        {
            'idx': 1,
            'x': 13,
            'y': 8 },
        {
            'idx': 2,
            'x': 11,
            'y': 19 },
        {
            'idx': 3,
            'x': 10,
            'y': 18 },
        {
            'idx': 4,
            'x': 12,
            'y': 18 },
        {
            'idx': 5,
            'y': 19,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 6,
            'y': 20,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 7,
            'y': 19,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 8,
            'y': 20,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 9,
            'x': 11,
            'y': 18 },
        {
            'idx': 10,
            'x': 10,
            'y': 17 },
        {
            'idx': 11,
            'x': 12,
            'y': 17 },
        {
            'idx': 12,
            'x': 11,
            'y': 17 },
        {
            'idx': 13,
            'x': 11,
            'y': 9 },
        {
            'idx': 14,
            'x': 14,
            'y': 9 }])
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(34)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(2)
    stage.say('&76\n전투가 어떻게 진행되고 있는지는 모르겠습니다......\n조조의 현재 움직임은 어떠한가?')
    stage.unit(87).setDir(stage.countDir(87, 76))
    stage.say('&87\n장료와 링통이 허중에서 맞섰다,\n전투가 곧 시작될지도 몰라.')
    stage.unit(86).setDir(stage.countDir(86, 76))
    stage.say('&86\nUnexpectedly조조 이 늙은 도둑에게,\n이번에는 많은 사람들과 말들이 함께,\n이 일에 대해 불길한 예감이 들었어요.')
    stage.unit(82).setDir(stage.countDir(82, 76))
    stage.say('&82\n감녕와 육손 장군의 부대가 곧 도착할 것이다,\n그때쯤이면 조조의 군대는 단 한 번의 타격에도 상대가 되지 못할 것이다.')
    stage.unit(88).setDir(stage.countDir(88, 76))
    stage.say('&88\n주군 지금도 나는 전쟁에 반대한다.\n현재는 원정이나 전투가 없어야 하며, 대신 도시를 지켜야 합니다,\n힘을 모으는 것이 중요합니다.\n&88\n지금 마음을 바꿀 수 있는 게 아직 늦지 않았어.\n방어를 강화하기 위해 루쉬 고개로 복귀,\n휴전과 평화조조 이야기해 봅시다.')
    stage.unit(76).setDir(stage.countDir(76, 88))
    stage.say('&76\n곧 전투가 시작될 예정이었다,\n이것은 변할 수 없는 사실입니다.\n제발 이런 말 그만해, 장자오.\n&88\n이 전투가 끝난 후,\n제 말을 좀 더 신중히 생각해 주세요.\n전쟁이 끝날 때까지 내가 널 지킬 거야.\n&76\n하하하. 그럼 너한테 의지해야겠네, 장조.')
    stage.unit(76).setDir(stage.countDir(76, 0))
    stage.unit(76).setAction(5)
    stage.say('&76\n좋아! 오늘은 반드시 조조를 이겨야 해!\n내 동무 해군의 힘을 보여라!')
    stage.unit(76).setAction(0)
    stage.unit(0).setDir(stage.countDir(0, 19))
    stage.say('&0\n적의 선봉은 영통이었지?\n아군 진형을 어떻게 세우나요?')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n방덕 분리된 부대만 걱정했다,\n아마도 그들은 전장에 제때 도착하지 못할지도 모른다,\n나머지는 모두 준비됐어.\n&0\n그래? 장료에게 선제적으로 공격하지 말라고 명령한다,\n전쟁을 시작하는 데 조금 더 기다리면,\n네가 해야 할 일은 손권 처리하는 데 집중하는 것뿐이야.\n&19\n전투에서 적을 과소평가하는 것은 군사 전략에서 매우 금기시되는 일이다!\n만약 수용소가 점령되고 식량이 압수된다면,\n그럼 우리의 유일한 선택은 후퇴뿐이야.')
    stage.heightLight(12, 8, 12, 8)
    stage.say('&0\n그건 알고 있어.\n적이 진영에 가까이 오지 못하게 해!\n&19\n주군 현명하네요.\n제가 너무 깊게 생각했어요.\n&89\n원래는 이 전투의 선봉이 되려고 했는데,\n정말 링통 장군이 부럽다.\n&93\n나도 그래.\n젠장, 수영할 수 있으면 좋겠어.')
    stage.unit(89).setDir(stage.countDir(89, 93))
    stage.say('&89\n당신은 동무의 장군이시군요,\n사실 그는 수영을 못했다.')
    stage.unit(93).setAction(5)
    stage.say('&93\n우리가 사람들을 물속에서 자르는 것도 아니잖아!\n하지만 솔직히 말하면, 아직도 정말 후회하고 있어요.\n이봐, 링통! 빨리 전투 시작해줄래!')
    stage.unit(93).setAction(0)
    stage.unit(80).setDir(stage.countDir(80, 93))
    stage.say('&80\n하하하.\n속담에 있듯이: "좋은 수영 선수는 익사한다."\n수영을 못하는 사람들은 사실 조심하는 법을 알고 있습니다.')
    stage.unit(83).setAction(5)
    stage.say('&83\n이 대면은 너무 숨 막히게 해요.\n영통 장군님, 아직 공격하지 않나요?')
    stage.unit(83).setAction(0)
    stage.unit(85).setAction(5)
    stage.say('&85\n네 끝없는 잔소리는 못 참겠어.\n좋아, 군대 전체가 이동 중이다!\n조의 군대를 박살내라!')
    stage.unit(85).setAction(0)
    stage.unit(2).setAction(2)
    stage.say('&2\n흠, 나한테 공격하는 거야?')
    stage.unit(11).setAction(5)
    stage.say('&11\n전쟁이 시작된 이후로...... 우리가 할 수 있는 게 없어.\n싸워!')
    stage.unit(11).setAction(0)
    stage.unit(10).setAction(5)
    stage.say('&10\n좋아, 반격을 시작하자!')
    stage.unit(10).setAction(0)
    stage.setWinCondition('승리 조건\n1. 손권 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 적군 캠프 진입.\n3. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('손권을 막아라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[534] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 3:
        stage.unit(9).show()
        stage.unit(9).move(3, 19, 1)
        stage.unit(6, 1).show()
        stage.unit(6, 1).move(3, 20, 1)
        stage.unit(7, 1).show()
        stage.unit(7, 1).move(2, 19, 1)
        stage.unit(8, 1).show()
        stage.unit(8, 1).move(2, 20, 1)
        stage.unit(9).setDir(stage.countDir(9, 0))
        stage.say('&9\n주군, 늦어서 용서방덕 줘.\n방덕 이미 전장에 도착했어!')
        stage.unit(0).setDir(stage.countDir(0, 9))
        stage.say('&0\n오, 방덕!\n딱 좋은 때에 왔네!\nflank적군에서 공격!\n&9\n알겠습니다!')
        vars[11] = 1
    if not vars[20] and stage.isInPos(1026, 12, 8):
        stage.resumeCtrl()
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(76).setAction(5)
        stage.say('&76\n오! 본조조 진영을 점령했나?\n잘했어! 잘했어!\n도둑조조Old 내가 얼마나 강한지 보여줄게!"')
        stage.unit(76).setAction(0)
        stage.unit(0).setAction(4)
        stage.unit(0).setAction(5)
        stage.say('&0\n아-아, 안 돼......\n다른 선택지가 없어서 철회할 수밖에 없었다.\n전군을 후퇴시켜라...... 후퇴!')
        stage.unit(0).setAction(0)
        stage.setRectUnitHide(0, 0, 23, 39, 0)
        vars[20] = 1
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[21] and stage.isInPos(1025, 10, 33):
        stage.getItem(151, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 11, 33):
        stage.getItem(154, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 10, 32):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 11, 32):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[6] and stage.curCamp() == 2 and stage.totalUnit(2) < 20:
        stage.unit(76).setAction(5)
        stage.say('&76\n음흠흠... 전선 병력은 완전히 패배했다!\n다시 그 증오스러운 놈들을 공격하러 군대를 보내라!')
        stage.unit(76).setAction(0)
        if not vars[57]:
            stage.unit(80).setAction(5)
            stage.say('&80\n네!\n명령을 내려라: 전 군대를 동원하라!')
            stage.unit(80).setAction(0)
        if not vars[55]:
            stage.say('&89\n빨리!')
        if not vars[52]:
            stage.say('&83\n네! 주군.\n쉬셩은 싸우러 나갔다.')
        if not vars[59]:
            stage.say('&93\n이제는 수영할 수 있는지조차 신경 쓸 수 없어요.\n동시가 전투에 나간다!')
        stage.unit(89).setAI(1)
        stage.unit(83).setAI(1)
        stage.unit(80).setAI(1)
        stage.unit(93).setAI(1)
        stage.unit(360).setAI(1)
        stage.unit(361).setAI(1)
        stage.unit(362).setAI(1)
        stage.unit(363).setAI(1)
        vars[6] = 1
    if vars[6] and not vars[7] and stage.totalUnit(2) < 14 and stage.curCamp() == 2:
        stage.unit(84).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(318).show()
        stage.say("&84\n흥, 속담에 있듯이, '서두르면 낭비가 생긴다'고 하죠.\n하지만 저는 특히 인내심이 많습니다.\n가자! 전면 공격!")
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.say('&0\n으, 이거 큰일이야, 적 부대야!\n방어를 강화하고 본진을 지켜라!')
        vars[7] = 1
    if vars[7] and not vars[8] and not vars[61] and stage.totalRectUnit(0, 0, 26, 23, 39) >= 1 and stage.totalRectUnit(0, 7, 35, 14, 39) == 0 and stage.curCamp() == 2:
        stage.unit(88).setDir(stage.countDir(88, 76))
        stage.say('&88\n주군 적이 마침내 상륙했다.\n여기서 방어를 강화해야 합니다!')
        stage.unit(76).setDir(stage.countDir(76, 88))
        stage.say('&76\n흠, 장자오!\n서둘러 루쉬관으로 돌아가라,\n병력이 상황을 지원하기 위해 파견되었다.\n&88\n루쉬관에서 주둔군을 이동시키는 것은 부적절했지만,\n하지만 이 시점에서 그는 할 수 있는 게 없었다.\n&88\n알겠습니다.\n바로 증원군을 보내겠습니다!')
        stage.unit(88).move(11, 39, 2)
        stage.unit(88).hide()
        if not vars[53]:
            stage.say('&86\n주군를 지켜라! 방어를 강화하라!')
        if not vars[60]:
            stage.say('&82\n도둑조조Old, 여기 통과할 생각도 하지 마!"\n주군, 나는 판장이 너를 죽을 때까지 지킬 거야.')
        if not vars[54]:
            stage.say('&87\n이봐! 전투는 이제 막 시작됐어!')
        vars[8] = 1
        if stage.totalRectUnit(0, 0, 28, 23, 39) >= 5:
            vars[9] = 1
    if vars[8] and not vars[9] and stage.totalRectUnit(0, 0, 28, 23, 39) >= 5 and stage.curCamp() == 2:
        stage.unit(88).show(3, 38, 1)
        stage.unit(88).setAI(1)
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(284).show()
        stage.unit(88).setDir(stage.countDir(88, 76))
        stage.say('&88\n주군, 괜찮으세요!?\n나, 장조가 돌아왔다!')
        stage.unit(76).setDir(stage.countDir(76, 88))
        stage.say('&76\n아, 장자오, 너 때문에 너무 기다리게 됐어!')
        stage.unit(0).setDir(stage.countDir(0, 88))
        stage.say('&0\n뭐, 지원군이 도착했다고!?\n이제 병사들이 너무 지쳐 있다,\n지금 병력을 철수시켜야 할까요?')
        sel = stage.choice('전체 군대가 후퇴했다\n계속 싸워', -1)
        if sel == 1:
            stage.resumeCtrl()
            stage.unit(0).setAction(5)
            stage.say('&0\n다른 방법이 없으니 오늘은 여기서 끝내자.\n전군 후퇴! 후퇴!')
            stage.unit(0).setAction(0)
            stage.setRectUnitHide(0, 0, 23, 39, 0)
            stage.say('&76\n아, 적군 후퇴했어!\n이번에는 마침내 힘든 시기를 넘겼다......')
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[634] = 1
            vars[734] = 1
            return True
        if sel == 2:
            stage.say('&0\n그저 보강일 뿐이야,\n아군 정도면 충분히 감당할 수 있어요!')
        vars[9] = 1
    if vars[9] and not vars[10] and stage.totalUnit(2) < 11 and stage.curCamp() == 2:
        stage.unit(81).show()
        stage.unit(368).show()
        stage.unit(369).show()
        stage.unit(370).show()
        stage.unit(371).show()
        stage.unit(372).show()
        stage.unit(373).show()
        stage.unit(374).show()
        stage.unit(81).setDir(stage.countDir(81, 76))
        stage.say('&81\n주군, 낙담하지 마.\n우리가 죽을 때까지 싸우는 한, 반드시 이길 것이다.\n계속 가세요!')
        stage.unit(76).setDir(stage.countDir(76, 81))
        stage.say('&76\n아, 그러니까 육손구나,\n딱 맞는 타이밍에 왔네.')
        stage.unit(0).setDir(stage.countDir(0, 81))
        stage.say('&0\n뭐, 육손!?\n음, 손권 군대가 내가 생각했던 것보다 전투 준비가 더 잘 되어 있네.\n이로 인해 누가 우월한지 판단하기 어렵습니다—우리는 후퇴해야 할까요?')
        sel = stage.choice('전체 군대가 후퇴했다\n계속 싸워', -1)
        if sel == 1:
            stage.resumeCtrl()
            stage.unit(0).setAction(5)
            stage.say('&0\n내가 할 수 있는 게 없으니 오늘은 여기서 마치자.\n전군 후퇴! 후퇴!')
            stage.unit(0).setAction(0)
            stage.setRectUnitHide(0, 0, 23, 39, 0)
            stage.say('&76\n아, 적군 후퇴했어!\n이번에는 마침내 힘든 시기를 넘겼다......')
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[634] = 1
            vars[734] = 1
            return True
        if sel == 2:
            stage.say('&0\n지금 어떻게 후퇴할 수 있겠어!\n무슨 일이 있어도 이곳을 반드시 점령해야 해!')
        vars[10] = 1
    if not vars[42] and stage.isNear(9, 89, False):
        stage.unit(89).setDir(stage.countDir(89, 9))
        stage.unit(9).setDir(stage.countDir(9, 89))
        stage.say('&89\n당신은 유명한 장군인 것 같군요,\n감히 나에게 끝까지 도전할 수 있겠느냐?\n&9\n좋아!\n끝까지 함께할게!')
        fight = stage.startFight(9, 89, 5)
        fight.showUnit(True, '나는 방덕, 링밍이라는 스타일이야.\n직접 경험해봤어요!', 6)
        fight.showUnit(False, '아, 그러니까 방덕?\n너 같은 상대가 있으면,\n내 마음은 만족해!', 0)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '한 방에 죽인다!\n내 강력한 활을 봐!', True)
        fight.attack1(False, 2, True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '아-아가씨!?', True)
        stage.delay(5)
        fight.setAction(True, 10)
        fight.setAction(True, 0)
        stage.delay(5)
        fight.say(True, '이걸 받아라!', True)
        fight.setAction(True, 3)
        fight.attack1(False, 1, False)
        fight.say(False, '음음!', True)
        fight.setAction(True, 3)
        fight.attack1(False, 1, False)
        fight.say(False, '더 이상 다가오지 마!', True)
        fight.setAction(True, 3)
        fight.say(False, '더 이상 다가오지 마!', True)
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.say(False, '아-아, 안 돼!\n와아아!', True)
        fight.death(True)
        fight.setAction(True, 10)
        fight.setAction(True, 6)
        stage.delay(10)
        fight.say(True, '적군 장군 첸우는 이미 내가 죽였다!', True)
        fight.end()
        stage.unit(89).hide(2)
        vars[55] = 1
        if vars[706]:
            stage.getItem(39, -1, True, 9)
        else:
            stage.getItem(38, -1, True, 9)
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n오늘은 너랑 정리해야 해!\n&76\n그게 바로 내가 말하고 싶었던 거야.')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&76\n아-아, 안 돼!\n젠장, 후퇴해.\n후퇴!')
        if not vars[51]:
            stage.unit(81).setDir(stage.countDir(81, 76))
            stage.unit(81).setAction(4)
            stage.say('&81\n주군! 육손가 실제로 ...... 줄 몰랐어\n흠, 내 힘이 부족한 것 같아.\n동우로 돌아오면 더 열심히 수련하세요!')
            vars[51] = 1
        if not vars[61]:
            stage.unit(88).setDir(stage.countDir(88, 76))
            stage.say('&88\n응.........\n지금 싸우기에는 정말 이르조조.\n귀국하면 국가 방위주군 강화할 것을 조언해야 합니다.')
            vars[61] = 1
        if not vars[53]:
            stage.unit(86).setDir(stage.countDir(86, 76))
            stage.say('&86\n쳇, 우리가 패배한 이후로 주군,\n내가 또 싸울 이유가 뭐가 있겠어?\n후퇴!')
            vars[53] = 1
        stage.setRectUnitHide(0, 0, 23, 39, 2)
        vars[50] = 1
        stage.say('&0\n아주 좋아, 드디어 쫓아냈적군!\n아군 이겼어!')
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[634] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n음음 음...... 나, 루보얀은 공부에 능숙하지 않아!\n앞으로도 계속 열심히 해야 한다.......\n후퇴!')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n주군 내가 부끄러워서 물러나는 걸 봤어,\n너무 창피해요......')
        stage.unit(83).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n생존이 최우선입니다.\n후퇴, 빨리 후퇴!')
        stage.unit(86).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n후퇴, 후퇴.\n흥, 여기서 죽고 싶지 않아!')
        stage.unit(87).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(89, 7, 0, 2):
        stage.say('&89\n와우...... 후회와 후회......')
        stage.unit(89).hide(2)
        if vars[706]:
            stage.getItem(39, -1, True, 1027)
        else:
            stage.getItem(38, -1, True, 1027)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n와! 이게 내 운명인가......\n저도 후회하지 않아요!')
        stage.unit(84).hide(2)
        stage.getItem(91, -1, True, 1027)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(80, 7, 0, 2):
        stage.say("&80\n물러날 때가 된 걸까......?\n가까운 미래에 그들은 우나라에서 입지를 지키며 상황을 관찰할 수밖에 없을 것 같습니다.\n언젠가는 '고난을 견디고 맛보는' 것이죠......")
        stage.unit(80).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n내가 정말 큰 실수를 했어!\n후퇴.')
        stage.unit(85).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(93, 7, 0, 2):
        stage.say('&93\n말도 안 돼!\n정말 미운 짓이야...... 받아들일 수 없어.')
        stage.unit(93).hide(2)
        stage.getItem(83, -1, True, 1027)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n정말 부끄러워요.\n후퇴만이 유일한 선택지입니다!')
        stage.unit(82).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n오, 안 돼!\n주군, 내가 먼저 갈게!')
        stage.unit(88).hide(1)
        vars[61] = 1
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 몰아냈어!\n아군 이겼어!')
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[0] = 1
        vars[634] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
