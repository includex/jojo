# Source Generated with Decompyle++
# File: S_09.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22], [
        '(7,13)',
        '(15,15)',
        '(18,6)'])
    stage.nearEvent([
        0,
        149,
        0,
        129,
        0,
        131,
        0,
        13], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 149,
            'x': 5,
            'y': 8,
            'lv': 0,
            'ai': 6,
            'targetX': 7,
            'targetY': 13,
            'i': 0 },
        {
            'id': 210,
            'x': 4,
            'y': 7,
            'lv': 0,
            'ai': 6,
            'targetX': 7,
            'targetY': 13,
            'i': 1 },
        {
            'id': 211,
            'x': 5,
            'y': 6,
            'lv': 0,
            'ai': 6,
            'targetX': 7,
            'targetY': 13,
            'i': 2 }])
    stage.createEnemy([
        {
            'id': 129,
            'x': 1,
            'y': 1,
            'lv': 4,
            'ai': 1,
            'i': 0 },
        {
            'id': 258,
            'x': 0,
            'y': 1,
            'lv': 0,
            'ai': 1,
            'i': 1 },
        {
            'id': 259,
            'x': 2,
            'y': 0,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 282,
            'x': 0,
            'y': 0,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 283,
            'x': 1,
            'y': 0,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 131,
            'x': 1,
            'y': 4,
            'lv': 4,
            'ai': 1,
            'i': 5 },
        {
            'id': 260,
            'x': 0,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 261,
            'x': 2,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 284,
            'x': 0,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 285,
            'x': 1,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 13,
            'x': 4,
            'y': 2,
            'lv': 4,
            'ai': 1,
            'i': 10 },
        {
            'id': 262,
            'x': 3,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 263,
            'x': 5,
            'y': 1,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 286,
            'x': 3,
            'y': 1,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 287,
            'x': 4,
            'y': 1,
            'lv': 0,
            'ai': 1,
            'i': 14 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 17,
            'y': 11 },
        {
            'idx': 1,
            'x': 16,
            'y': 11 },
        {
            'idx': 2,
            'x': 18,
            'y': 12 },
        {
            'idx': 3,
            'x': 17,
            'y': 9 },
        {
            'idx': 4,
            'x': 19,
            'y': 9 },
        {
            'idx': 5,
            'x': 18,
            'y': 7 },
        {
            'idx': 6,
            'x': 17,
            'y': 4 },
        {
            'idx': 7,
            'x': 17,
            'y': 2 },
        {
            'idx': 8,
            'x': 19,
            'y': 3 },
        {
            'idx': 9,
            'x': 19,
            'y': 2 },
        {
            'idx': 10,
            'x': 18,
            'y': 1 },
        {
            'idx': 11,
            'x': 17 },
        {
            'idx': 12,
            'x': 18,
            'y': 2 },
        {
            'idx': 13,
            'x': 16,
            'y': 1 },
        {
            'idx': 14,
            'x': 19 }])
    stage.loadBg(9)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab21')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab21')
    stage.draw()
    stage.bgSound(5)
    stage.unit(131).setAction(5)
    stage.say('&131\n참파는 하늘이 말씀하신 것을 들었다,\n그는 왕국을 이기기 위해 황제의 지원이 이각 필요하다고 말했다.\n&131\n쫓아, 쫓아! 현제를 도망치지 마!')
    stage.unit(131).setAction(0)
    stage.say('&149\n나는 그들에게 붙잡힐 수 없어,\n꼭두각시가 되어 미래 세대에게 조롱당하기보다는,\n차라리 죽는 게 나을 거야.\n&129\n천명을 이해하는 자들은 하늘이나 타인을 탓하지 않습니다.\n그러니까 제발 조용히 있고 도망가지 마, 알겠지?\n&129\n아, 그건 황제에게 예의를 갖추지 않는 것 같군요.\n하하하.\n&13\n(비록 천황을 체포하는 것이 도덕적 원칙상 정당화되지 않을 수 있지만,\n하지만 황제를 풀어주면 배신자로 낙인찍힐 뿐이야! )\n안타까워도 놓을 수가 없어!')
    stage.unit(5).setDir(stage.countDir(5, 149))
    stage.unit(0).setDir(stage.countDir(0, 149))
    stage.say('&5\n그들은 헌제의 군대를 추격했다,\n이각와 곽사 동탁의 오래된 부하들인 것 같았다.\n&0\n흠, 진격을 서둘러라! 우리는 현제를 구출해야 한다!\n적에게 빼앗기지 말아야 해, 빨리 말이야!')
    stage.setWinCondition('승리 조건\n1. 헌제가 북동쪽 끝에 도착했다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 헌제가 적에게 포로로 잡혔다.\n2. 조조 죽음.\n3. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('헌제가 도망쳤다!')
    stage.unit(149).heightLight()
    stage.heightLight(16, 0, 19, 0)
    stage.startOper()
    vars[509] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[1002] and not vars[60] and not vars[11] and stage.round() < 3 and stage.curCamp() == 2 and stage.isInPos(149, 7, 13):
        stage.unit(149).setAI(2, -1, 15, 15)
        vars[60] = 1
    if vars[1002] and not vars[61] and not vars[12] and stage.round() < 5 and stage.curCamp() == 2 and stage.isInPos(149, 15, 15):
        stage.unit(149).setAI(2, -1, 15, 15)
        vars[61] = 1
    if vars[1002] and not vars[62] and not vars[13] and stage.round() < 7 and stage.curCamp() == 2 and stage.isInPos(149, 18, 6):
        stage.unit(149).setAI(2, -1, 15, 15)
        vars[62] = 1
    if not vars[11] and stage.round() == 3:
        stage.unit(149).setAI(6, -1, 15, 15)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        vars[11] = 1
    if not vars[12] and stage.round() == 5:
        stage.unit(149).setAI(6, -1, 18, 6)
        vars[12] = 1
    if not vars[13] and stage.round() == 7:
        stage.unit(149).setAI(6, -1, 18, 0)
        vars[13] = 1
    if not vars[20] and stage.isInPos(1025, 7, 13):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 15, 15):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 18, 6):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[30] and stage.isInRect(149, 16, 0, 19, 0):
        stage.say('&149\n마침내 위험에서 벗어났다.......')
        stage.unit(149).setDir(stage.countDir(149, 0))
        if vars[2]:
            stage.say('&149\n조조 이 싸움을 멋지게 이겨냈습니다!\n그는 사실상 싸우기 위해 태어난 사람이었다!\n&149\n아마도 나를 구한 건 그가 전투에 나가기 위한 핑계였을지도 몰라......\n&149\n하지만 그가 나를 구했다는 것도 사실이야...\n그에게 감사해야 해......\n그냥 성인의 검을 줘.')
            stage.unit(0).setDir(stage.countDir(0, 149))
            stage.getItem(52, 0)
            stage.setRectUnitHide(0, 0, 19, 19, 1)
            stage.say('&0\n헌제는 무사히 도망쳤다,\n이제 그는 싸움에 집중할 수 있었다.')
        if not vars[2]:
            stage.resumeCtrl()
            stage.say('&149\n이 모든 것은 조조 덕분입니다...\n행동하기 전에 그들에게 후하게 보상해줘야 해.\n그냥 그에게 황금 갑옷 한 조각을 보상으로 주면 됩니다.')
            stage.getItem(80, 0)
            stage.setRectUnitHide(0, 0, 19, 19, 1)
            stage.unit(0).setAction(5)
            stage.say('&0\n헌제가 무사히 탈출했습니다...\n좋아, 적의 남은 병사들은 걱정할 필요 없어.\n전군을 후퇴시켜라!')
            stage.unit(0).setAction(0)
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[609] = 1
            return True
        vars[30] = 1
    if not vars[40] and stage.isNear(0, 149, True):
        stage.unit(0).setDir(stage.countDir(0, 149))
        stage.unit(149).setDir(stage.countDir(149, 0))
        stage.say('폐하, 폐하의 몸은 괜찮으십니까? 앞으로 신이 폐하를 지킬 테니 안심하십시오. 아, 당신이 조조로군요? 위급할 때 짐을 구해준 공신에게 깊이 감사드립니다. (음, 이제 어떻게 해야 할까…….)')
        sel = stage.choice('헌제와 수행원을 호위하기 위해\n전부 전멸시켜적군', -1)
        if sel == 1:
            stage.say('&0\n이제부터 폐하를 지킬 거야.\n이쪽으로 오세요!\n&149\n수고해 주셔서 감사합니다, 친애하는 장관님.\n&0\n이것이 제 영광입니다.')
        elif sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이제 모든 적을 제거해야 합니다.\n전면 군대 공격!')
            stage.unit(0).setAction(0)
            stage.say('&149\nI ...... 어떻게 해야 할까요?\n&0\n안심하세요, 나는 단 한 명의 적도 도망치게 하지 않을 것입니다,\n폐하께서 조심해 주시길 간청합니다.\n&149\n…….')
            stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 헌제가 적군에 포로로 잡혔다.\n2. 조조 죽음.\n3. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('전부 전멸시적군!')
            vars[2] = 1
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 129, True):
        stage.unit(129).setDir(stage.countDir(129, 0))
        stage.unit(0).setDir(stage.countDir(0, 129))
        stage.say('&129\n드디어 다시 만났구나!\n사수관에서의 원수를 갚겠다!\n&0\n나는 황명을 받들어 천자를 구하러 온 관군이다.\n진정한 역적은 바로 너희다!\n순순히 항복하면 목숨만은 살려주겠다.\n&129\n헛소리 마라! 너나 나나 똑같은 족속이다.')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 131, True):
        stage.unit(131).setDir(stage.countDir(131, 0))
        stage.unit(0).setDir(stage.countDir(0, 131))
        stage.say('&131\n나의 천상의 아들이여...... 내 세상은 ......!\n조조! 정직히 황제를 넘기라,\n목숨은 살려줄게.\n&0\n천자를 빼앗아 혼자 세상을 지배할 수 있다고 생각하느냐?\n네 근시안이 목숨을 잃을 수도 있어.\n&131\n젠장!')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 13, True):
        stage.unit(0).setDir(stage.countDir(0, 13))
        stage.unit(13).setDir(stage.countDir(13, 0))
        stage.say('&0\n황제를 호위하는 일은 힘든 일이야.\n하하하!\n&13\n수다 떨지 마!\n어떻게 황제를 당신 같은 사람에게 맡길 수 있죠......\n악의를 가진 사람들.\n&0\n이기적인 이익만 신경 쓰는 너희들,\n그는 천자를 어떻게 사용하는지 몰라!\n&0\n내가 천자의 아들을 맞이할 수 있다면, 모든 백성에게 축복을 전할 수 있다.\n순종적으로 물러나는 게 좋을 거야!\n&13\n네 헛소리 믿지 않아.')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(149, 7, 0, 2):
        stage.say('&149\n아...... 또 문제에 빠지려는 건가......?')
        vars[50] = 1
        stage.info('조조 헌제를 구출하는 데 실패했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[51] and stage.unitStateTest(13, 7, 0, 2):
        stage.say('&13\n그냥 조조 이각 같지 않길 바랄 뿐이에요,\n곽사 황제를 그렇게 경멸하.......\n후퇴!')
        stage.unit(13).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(131, 7, 0, 2):
        stage.say('&131\n후퇴, 후퇴!\n참으로 미운 일이야! 천자가 도망치면 나는 더 이상 영주들을 통제할 수 없어.\n이게 정말 내 끝일까?')
        stage.unit(131).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(129, 7, 0, 2):
        stage.say('&129\n서른여섯 가지 계략 중에서 도망치는 것이 최선의 전략이다,\n장안으로 돌아가 재정비하라.')
        stage.unit(129).hide(1)
        vars[53] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        if not vars[30]:
            stage.say('&149\n마침내 그는 위험을 벗어났다.......')
            if vars[2]:
                stage.say('&149\n조조 이 싸움을 멋지게 이겨냈습니다!\n그는 사실상 싸우기 위해 태어난 사람이었다!\n&149\n아마도 나를 구한 건 그가 전투에 나가기 위한 핑계였을지도 몰라......\n&149\n하지만 그가 나를 구했다는 것도 사실이야...\n그에게 후하게 보상해줘야 해......\n그냥 성인의 검을 줘.')
                stage.getItem(52, 0)
            if not vars[2]:
                stage.say('&149\n이 모든 것은 조조 덕분입니다...\n행동하기 전에 그들에게 후하게 보상해줘야 해.\n그냥 그에게 황금 갑옷 한 조각을 보상으로 주면 됩니다.')
                stage.getItem(80, 0)
            vars[30] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[609] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 옛 부하들에게 패배동탁 했습니다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
