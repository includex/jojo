# Source Generated with Decompyle++
# File: S_53.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,4)',
        '(14,3)',
        '(13,3)',
        '(14,4)'])
    stage.nearEvent([
        0,
        70])
    stage.nearEvent([
        0,
        50,
        3,
        37,
        9,
        58], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 13, 'y': 3, 'lv': 6, 'i': 0},
         {'id': 69, 'x': 14, 'y': 3, 'lv': 6, 'i': 1},
         {'id': 50, 'x': 13, 'y': 4, 'lv': 6, 'i': 2},
         {'id': 49, 'x': 14, 'y': 4, 'lv': 6, 'i': 3},
         {'id': 298, 'x': 11, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 299, 'x': 11, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 300, 'x': 13, 'y': 10, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 301, 'x': 14, 'y': 10, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 302, 'x': 7, 'y': 9, 'lv': 0, 'i': 8},
         {'id': 303, 'x': 7, 'y': 10, 'lv': 0, 'i': 9},
         {'id': 304, 'x': 8, 'y': 10, 'lv': 0, 'i': 10},
         {'id': 70, 'x': 4, 'y': 9, 'lv': 4, 'i': 11},
         {'id': 211, 'x': 4, 'y': 10, 'lv': 0, 'i': 12},
         {'id': 212, 'x': 6, 'y': 13, 'dir': 1, 'lv': 0, 'i': 13},
         {'id': 213, 'x': 7, 'y': 13, 'dir': 1, 'lv': 0, 'i': 14},
         {'id': 234, 'x': 3, 'y': 9, 'lv': 0, 'i': 15},
         {'id': 235, 'x': 5, 'y': 9, 'lv': 0, 'i': 16},
         {'id': 236, 'x': 6, 'y': 12, 'dir': 1, 'lv': 0, 'i': 17},
         {'id': 237, 'x': 6, 'y': 14, 'dir': 1, 'lv': 0, 'i': 18},
         {'id': 210, 'x': 13, 'y': 14, 'lv': 0, 'i': 19},
         {'id': 214, 'x': 14, 'y': 14, 'lv': 0, 'i': 20},
         {'id': 215, 'x': 13, 'y': 15, 'lv': 0, 'i': 21},
         {'id': 216, 'x': 14, 'y': 15, 'lv': 0, 'i': 22},
         {'id': 238, 'x': 12, 'y': 14, 'lv': 0, 'i': 23},
         {'id': 239, 'x': 15, 'y': 14, 'lv': 0, 'i': 24},
         {'id': 37, 'x': 14, 'y': 5, 'lv': 6, 'ai': 0, 'i': 25},
         {'id': 68, 'x': 13, 'y': 5, 'lv': 4, 'ai': 0, 'i': 26},
         {'id': 258, 'x': 14, 'y': 6, 'lv': 0, 'ai': 0, 'i': 27},
         {'id': 259, 'x': 15, 'y': 6, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 310, 'x': 12, 'y': 6, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 311, 'x': 13, 'y': 6, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 58, 'x': 7, 'y': 3, 'dir': 3, 'lv': 6, 'i': 31},
         {'id': 462, 'x': 7, 'y': 4, 'dir': 3, 'lv': 0, 'i': 32},
         {'id': 463, 'x': 7, 'y': 2, 'dir': 3, 'lv': 0, 'i': 33},
         {'id': 464, 'x': 7, 'y': 5, 'dir': 3, 'lv': 0, 'i': 34},
         {'id': 465, 'x': 6, 'y': 3, 'dir': 3, 'lv': 0, 'i': 35},
         {'id': 466, 'x': 6, 'y': 4, 'dir': 3, 'lv': 0, 'i': 36},
         {'id': 414, 'hide': 1, 'x': 12, 'y': 5, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 415, 'hide': 1, 'x': 12, 'y': 4, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 416, 'hide': 1, 'x': 15, 'y': 4, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 417, 'hide': 1, 'x': 15, 'y': 5, 'lv': 0, 'ai': 1, 'i': 40}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 13,
            'y': 20,
            'dir': 0 },
        {
            'idx': 1,
            'x': 14,
            'y': 20,
            'dir': 0 },
        {
            'idx': 2,
            'x': 12,
            'y': 20,
            'dir': 0 },
        {
            'idx': 3,
            'x': 15,
            'y': 20,
            'dir': 0 },
        {
            'idx': 4,
            'x': 13,
            'y': 21,
            'dir': 0 },
        {
            'idx': 5,
            'x': 14,
            'y': 21,
            'dir': 0 },
        {
            'idx': 6,
            'x': 12,
            'y': 21,
            'dir': 0 },
        {
            'idx': 7,
            'x': 15,
            'y': 21,
            'dir': 0 },
        {
            'idx': 8,
            'x': 13,
            'y': 22,
            'dir': 0 },
        {
            'idx': 9,
            'x': 14,
            'y': 22,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(53)
    stage.setObjects(True, 17, [
        [
            77,
            17,
            3],
        [
            78,
            17,
            4]])
    stage.setObjects(True, 17, [
        [
            75,
            21,
            3],
        [
            76,
            21,
            4]])
    stage.setObjects(True, 17, [
        [
            79,
            13,
            11],
        [
            80,
            14,
            11]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(1)
    stage.unit(0).setDir(stage.countDir(0, 35))
    stage.say('&0\n공명 바이디 도시를 지배했고,\n정확히 어떤 조치가 이루어지고 있습니까?')
    stage.unit(35).setDir(0)
    stage.say('&35\n…………')
    stage.unit(69).setDir(stage.countDir(69, 50))
    stage.say('&69\n마수, 조조 가까이 가지 못하게 해!\n시간을 좀 더 벌어줘.')
    stage.unit(50).setDir(stage.countDir(50, 69))
    stage.say('&50\n걱정 마, 괜찮아.\n나랑 마수랑 있으면 아무도 가까이 못 가.\n하하하!')
    stage.unit(49).setDir(stage.countDir(49, 0))
    stage.say('&49\n유비주군, 장비 장군이 연이어 세상을 떠났다,\n관우 전장에서 배신하고 서나라를 배신하고 위나라로 돌아갔다.\n이제 내가 할 수 있는 건 공명 씨의 마법에 의지하는 것뿐이야.')
    stage.unit(49).setAction(2)
    stage.say('&49\n위나라 군대에 맞서 새로운 기술을 습득하기 위해,\n이 기도 의식이 성공하도록 하세요.\n설령 슈를 위해 희생해야 한다 해도, 그만한 가치가 있을 거야!')
    stage.unit(37).setDir(stage.countDir(37, 49))
    stage.say('&37\n그런 마법과 마법은 인간 세계에 혼돈만 가져올 뿐이다.\n전쟁은 전략과 힘을 사용해 싸우는 것입니다!')
    stage.unit(68).setDir(stage.countDir(68, 37))
    stage.say('&68\n포기하세요, 위연 장군, 조금만 더 참으세요!\n오나라를 합병한 위나라 군대에 저항하기 위해,\n이 주문들은 분명히 유용할 거예요.\n&58\n(방덕 이후, 관우 장군도 위나라에 항복했다......\n왜 이 두 충성스러운 남자가 위나라에 항복했을까? )')
    stage.unit(70).setDir(stage.countDir(70, 0))
    stage.unit(70).setAction(2)
    stage.say('&70\n흥, 조조 군대가 오고 싶으면 마음대로 오라!\n나, 장이는 이곳을 어떤 대가를 치르더라도 지킬 것을 맹세한다.')
    stage.bgSound(2)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[553] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[57] and not vars[70] and stage.round() == 4:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[70] = 1
    if vars[2] and not vars[57] and not vars[71] and stage.round() == 7:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[71] = 1
    if vars[2] and not vars[57] and not vars[72] and stage.round() == 10:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[72] = 1
    if vars[2] and not vars[57] and not vars[73] and stage.round() == 13:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[73] = 1
    if vars[2] and not vars[57] and not vars[74] and stage.round() == 16:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[74] = 1
    if vars[2] and not vars[57] and not vars[75] and stage.round() == 19:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[75] = 1
    if vars[2] and not vars[57] and not vars[76] and stage.round() == 22:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[76] = 1
    if vars[2] and not vars[57] and not vars[77] and stage.round() == 25:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[77] = 1
    if vars[2] and not vars[57] and not vars[78] and stage.round() == 28:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[78] = 1
    if vars[2] and not vars[57] and not vars[79] and stage.round() == 31:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[79] = 1
    if vars[2] and not vars[57] and not vars[80] and stage.round() == 34:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[80] = 1
    if vars[2] and not vars[57] and not vars[81] and stage.round() == 37:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[81] = 1
    if vars[2] and not vars[57] and not vars[82] and stage.round() == 40:
        stage.unit(414).show(12, 5, 2)
        stage.unit(415).show(12, 4, 2)
        stage.unit(416).show(15, 4, 2)
        stage.unit(417).show(15, 5, 2)
        vars[82] = 1
    if not vars[20] and stage.isInPos(1025, 13, 4):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 14, 3):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 13, 3):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 14, 4):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[30] and stage.isInRect(1025, 12, 13, 15, 17):
        stage.setAI(12, 13, 15, 16, 2, 1)
        vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 3, 2, 8, 7):
        if not vars[53]:
            stage.unit(58).setAction(2)
            stage.say('&58\n여기서는 통과할 수 없을 거야!')
        stage.setAI(5, 2, 8, 5, 2, 1)
        vars[31] = 1
    if not vars[32] and stage.isInRect(1025, 2, 7, 10, 15):
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        stage.unit(304).setAI(0)
        vars[32] = 1
    if not vars[33] and stage.curCamp() == 2 and stage.isInRect(1025, 6, 0, 21, 10):
        if not vars[3] and not vars[50] and not vars[51] and not vars[52]:
            if stage.totalRectUnit(0, 10, 0, 23, 7) == 0:
                stage.unit(35).setDir(stage.countDir(35, 69))
                stage.say('&35\n.........\n모든 게 계획대로 진행되고 있어.\n장웨이, 가자.')
                stage.unit(69).setDir(stage.countDir(69, 35))
                stage.say('&69\n네, 바로 출발합시다.')
                stage.unit(35).setDir(stage.countDir(35, 50))
                stage.say('&35\n마수, 나머지는 네가 알아서 할게!\n검각과 양평관을 이용해 적군를 막아라!')
                stage.unit(50).setDir(stage.countDir(50, 35))
                stage.say('&50\n내게 맡겨.\n나, 마수는 절대 실패하지 않을 거야.')
                stage.setObjects(False, 16, [
                    [
                        77,
                        17,
                        3],
                    [
                        78,
                        17,
                        4]])
                stage.setObjects(False, 16, [
                    [
                        75,
                        21,
                        3],
                    [
                        76,
                        21,
                        4]])
                stage.unit(35).move(23, 3, 1)
                stage.unit(69).move(23, 4, 1)
                stage.unit(35).hide()
                stage.unit(69).hide()
                stage.unit(0).setDir(1)
                stage.say('&0\n아-아, 안 돼.\n도망공명게 해!')
            vars[3] = 1
        if not vars[2] and not vars[57]:
            stage.unit(49).setDir(stage.countDir(49, 0))
            stage.say('&49\n공명 씨가 부여한 마법,\n지금이 완벽한 시기입니다.')
            stage.unit(49).setAction(5)
            stage.say('&49\n나와라, 나무 인형아!\n조조를 이겨라!')
            stage.unit(49).setAction(0)
            stage.unit(414).show()
            stage.unit(415).show()
            stage.unit(416).show()
            stage.unit(417).show()
            vars[2] = 1
        if not vars[31]:
            if not vars[53]:
                stage.unit(58).setDir(stage.countDir(58, 0))
                stage.say('&58\n우리는 그들의 길을 막아야 한다!\n더 이상 그들이 무작정 움직이게 둘 수 없어!')
            stage.setAI(5, 2, 8, 5, 2, 4, -1, 13, 4)
            vars[31] = 1
        vars[33] = 1
    if not vars[34] and stage.curCamp() == 2 and stage.isInRect(1025, 2, 11, 6, 15):
        stage.unit(70).setDir(stage.countDir(70, 0))
        stage.unit(70).setAction(5)
        stage.say('&70\n여기 있나?\n돌격!')
        stage.unit(70).setAction(0)
        stage.unit(70).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[34] = 1
    if not vars[40] and stage.isNear(0, 50, True):
        stage.unit(0).setDir(stage.countDir(0, 50))
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.say('&0\n간섭할 생각도 하지 마!\n이제 공명 악마가 나를 지배하고 있다,\n공명이 제거되지 않으면 세상은 결코 평화를 누리지 못할 것입니다.\n&50\n쳇, 쳇, 쳇.\n거짓말할 때 좀 더 영리해져야지!\n&50\n공명 주인은 매일 수많은 일을 관리했다,\n너랑 미팅 좀 하게 해줘!\n흥.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 70, False):
        stage.unit(70).setDir(stage.countDir(70, 0))
        stage.unit(0).setDir(stage.countDir(0, 70))
        stage.say('&70\n조조!\n&0\n흠!')
        fight = stage.startFight(0, 70, 5)
        fight.showUnit(False, '목숨을 내놓아!', 9)
        fight.showUnit(True, '생각도 하지 마!', 6)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack2(True, 1, False)
        stage.delay(15)
        fight.say(False, '와!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.end()
        vars[56] = 1
        stage.unit(70).hide(2)
        if not vars[33] and not vars[54] and not vars[55]:
            sel = stage.choice('정말 생사가 걸린 상황이었다.\n익명, 꺼져!', -1)
            if sel == 1:
                stage.say('&0\n그만공명.\n우리는 절대 이곳에서 죽을 수 없습니다.')
                stage.unit(68).setDir(stage.countDir(68, 0))
                stage.say('&68\n장이.........\n반드시 복수하겠습니다......')
            elif sel == 2:
                stage.say('&0\n공명 외에는 너희들에게 폐를 끼치고 싶지 않다!\n감히 내 대군을 방해한다면, 가차 없이 베어 죽일 것이다!')
                stage.unit(37).setDir(stage.countDir(37, 0))
                stage.say('&37\n내 위연을 죽일 수 있다고 생각해?\n너무 오만해!')
                stage.unit(68).setDir(stage.countDir(68, 0))
                stage.unit(68).setAction(5)
                stage.say('&68\n장이, 내가 복수할게!\n성문을 열어라!')
                stage.unit(68).setAction(0)
                stage.unit(37).setDir(stage.countDir(37, 68))
                stage.unit(37).setAction(10)
                stage.say('&37\n이봐!?\n빨리 돌아와!')
                stage.setObjects(False, 16, [
                    [
                        79,
                        13,
                        11],
                    [
                        80,
                        14,
                        11]])
                stage.unit(37).setDir(stage.countDir(37, 0))
                stage.say('&37\n다른 방법은 없었다.\n저 조조 죽일 거야!')
                stage.unit(298).setAI(1)
                stage.unit(299).setAI(1)
                stage.unit(300).setAI(1)
                stage.unit(301).setAI(1)
                stage.unit(302).setAI(1)
                stage.unit(303).setAI(1)
                stage.unit(304).setAI(1)
                stage.unit(37).setAI(1)
                stage.unit(258).setAI(1)
                stage.unit(259).setAI(1)
                stage.unit(68).setAI(1)
                stage.unit(310).setAI(1)
                stage.unit(311).setAI(1)
                stage.unit(234).setAI(1)
                stage.unit(235).setAI(1)
                stage.unit(236).setAI(1)
                stage.unit(237).setAI(1)
                stage.unit(211).setAI(1)
                stage.unit(212).setAI(1)
                stage.unit(213).setAI(1)
                if not vars[53]:
                    stage.unit(58).setDir(stage.countDir(58, 68))
                    stage.say('&58\n왜 그들은 전투를 받아들이기 위해 성문을 열었는가!\n정말 어리석었어......')
        vars[41] = 1
    if not vars[42] and stage.isNear(3, 37, True):
        stage.unit(37).setDir(stage.countDir(37, 3))
        stage.unit(3).setDir(stage.countDir(3, 37))
        stage.say('&37\n관우, 이미 서나라에서 탈퇴해 위나라에 항복한 것 같군요.\n품위 있는 관우은 실제로 흐름에 몸을 맡기는 사람입니다!\n&3\n관은 필요에 의해 위나라로 배신했다.\n공명 이제 마왕에게 빙의되었고,\n관은 무슨 일이 있어도 공명를 제거하겠다고 결심했다.\n&37\n진실을 숨기기 위해 거짓말을 꾸며내고 있겠지,\n하지만 이제는 더 설명할 필요가 없습니다.\n한 번에 너를 둘로 갈라버릴게!\n&3\n이건 잘 안 될 것 같아요......')
        vars[42] = 1
    if not vars[43] and stage.isNear(9, 58, True):
        stage.unit(58).setDir(stage.countDir(58, 9))
        stage.unit(9).setDir(stage.countDir(9, 58))
        stage.say('&58\n방덕, 왜 위나라에 피신했느냐?\n주인을 죽인 조조 증오를 잊었니?\n&9\n마다이 장군님,\n조재상은 개인적인 이익 때문이 아니었다,\n전적으로 세상을 위한 것이었다.\n&9\n인간 세계에 재앙을 가져오려는 마왕 공명를 물리치기 위해,\n총리는 이제 일어나 어떤 대가를 치르더라도 싸우고 있습니다,\n야망 있는 사람은 총리를 따라야 한다.\n&58\n다른 좋은 이유가 있을 줄 알았는데,\n누가 네가 아이들의 거짓말을 믿고 위나라에 항복할 줄 알았겠어,\n방덕Oh, 방덕, 정말 부끄러워해야 해.\n&58\n이미 인연을 끊었으니,\n오늘부터는 너랑 아무 상관없어.\n서나라 장군으로서 나는 위나라 장군인 너를 죽일 수밖에 없다!')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n음! 진짜로 이곳을 공격했어!?\n하지만 이제 위대한 임무가 완수되었으니,\n조조 아직 한 걸음 늦었다.')
        if not vars[52]:
            stage.unit(35).setDir(stage.countDir(35, 50))
            stage.say('&35\n마수, 나머지는 네가 알아서 할게!\n검각과 양평관을 이용해 적군를 막아라!')
            stage.unit(50).setDir(stage.countDir(50, 35))
            stage.say('&50\n내게 맡겨.\n나, 마수는 절대 실패하지 않을 거야.')
        if not vars[51]:
            stage.unit(35).setDir(stage.countDir(35, 69))
            stage.say('&35\n가자, 장웨이.\n더 이상 여기 머물 필요가 없었다.')
            stage.unit(69).setDir(stage.countDir(69, 35))
            stage.say('&69\n네, 공명 씨!')
            stage.unit(69).hide()
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n아직 처리해야 할 일이 남아 있어.\n먼저 후퇴하자.')
        stage.unit(69).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n만약 공명 경의 지시가 없었다면,\n조금 더 죽일 생각이었어.\n다른 선택지가 없어 그들은 후퇴할 수밖에 없었다.')
        stage.unit(50).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n쳇, 이건 오판이야!\n미안, 먼저 철회해야 해.')
        stage.unit(58).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n이건 좋지 않아.\n일단 후퇴해!')
        stage.unit(37).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(68, 7, 0, 2):
        if vars[56]:
            stage.say('&68\n미-미안... 장이......\n복수하기 전에 난 이미 죽을 거야......\n용서해 주세요...... 절대 안 돼!')
        else:
            stage.say('&68\n와!\n조, 조조......\n먼저 저승에서 기다릴게.........')
        stage.unit(68).hide(2)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(70, 7, 0, 2):
        stage.say('&70\n조, 조조!\n진짜 아니야......')
        stage.unit(0).setDir(stage.countDir(0, 70))
        stage.unit(70).hide(2)
        if not vars[33] and not vars[54] and not vars[55]:
            sel = stage.choice('…………\n저 졸개들은 신경 쓰지 마!', -1)
            if sel == 1:
                stage.say('&0\n역시 촉나라의 장수답군.\n모두 죽음을 두려워하지 않아!')
                stage.unit(68).setDir(stage.countDir(68, 0))
                stage.say('&68\n장이.........\n반드시 복수하겠습니다......')
            elif sel == 2:
                stage.say('&0\n공명 외에는 너희들에게 폐를 끼치고 싶지 않다!\n감히 내 대군을 방해한다면, 가차 없이 베어 죽일 것이다!')
                stage.unit(37).setDir(stage.countDir(37, 0))
                stage.say('&37\n내 위연을 죽일 수 있다고 생각해?\n너무 오만해!')
                stage.unit(68).setDir(stage.countDir(68, 0))
                stage.unit(68).setAction(5)
                stage.say('&68\n장이, 내가 복수할게!\n성문을 열어라!')
                stage.unit(68).setAction(0)
                stage.unit(37).setDir(stage.countDir(37, 68))
                stage.unit(37).setAction(10)
                stage.say('&37\n이봐!?\n빨리 돌아와!')
                stage.setObjects(False, 16, [
                    [
                        79,
                        13,
                        11],
                    [
                        80,
                        14,
                        11]])
                stage.unit(37).setDir(stage.countDir(37, 0))
                stage.say('&37\n다른 방법은 없었다.\n내가 죽일 거조조!')
                stage.unit(298).setAI(1)
                stage.unit(299).setAI(1)
                stage.unit(300).setAI(1)
                stage.unit(301).setAI(1)
                stage.unit(302).setAI(1)
                stage.unit(303).setAI(1)
                stage.unit(304).setAI(1)
                stage.unit(37).setAI(1)
                stage.unit(258).setAI(1)
                stage.unit(259).setAI(1)
                stage.unit(68).setAI(1)
                stage.unit(310).setAI(1)
                stage.unit(311).setAI(1)
                stage.unit(234).setAI(1)
                stage.unit(235).setAI(1)
                stage.unit(236).setAI(1)
                stage.unit(237).setAI(1)
                stage.unit(211).setAI(1)
                stage.unit(212).setAI(1)
                stage.unit(213).setAI(1)
                if not vars[53]:
                    stage.unit(58).setDir(stage.countDir(58, 68))
                    stage.say('&58\n왜 그들은 전투를 받아들이기 위해 성문을 열었는가!\n정말 어리석었어......')
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(49, 7, 0, 2):
        stage.say('&49\n와!')
        stage.unit(49).hide(2)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[57] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n그럼 공명 여기서 기도한 적 있나요?\n뜻밖에도 바이디 시 안에 제단이 세워졌다......\n아직 제단이 두 개 남아 있어, 그들을 막을 방법을 찾아야 해!')
        if vars[50]:
            stage.reward(0, [
                143,
                -1,
                49,
                -1])
        else:
            stage.reward(0, [
                143,
                -1])
        stage.end()
        vars[0] = 1
        vars[642] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 슈 군대에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
