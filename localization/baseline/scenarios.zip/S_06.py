# Source Generated with Decompyle++
# File: S_06.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25], [
        '(18,17)',
        '(18,16)',
        '(19,16)',
        '(20,16)',
        '(4,16)',
        '(19,17)'])
    stage.nearEvent([
        16,
        2])
    stage.nearEvent([
        0,
        119,
        16,
        125,
        0,
        126], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 1, 1)
    stage.createEnemy(
        [{'id': 119, 'x': 19, 'y': 17, 'lv': 6, 'i': 0},
         {'id': 126, 'x': 18, 'y': 16, 'lv': 6, 'i': 1},
         {'id': 290, 'x': 19, 'y': 16, 'lv': 0, 'i': 2},
         {'id': 291, 'x': 20, 'y': 16, 'lv': 0, 'i': 3},
         {'id': 268, 'x': 17, 'y': 16, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 269, 'x': 17, 'y': 17, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 270, 'x': 19, 'y': 15, 'dir': 0, 'lv': 0, 'i': 6},
         {'id': 271, 'x': 20, 'y': 15, 'dir': 0, 'lv': 0, 'i': 7},
         {'id': 272, 'x': 22, 'y': 16, 'dir': 1, 'lv': 0, 'i': 8},
         {'id': 273, 'x': 22, 'y': 17, 'dir': 1, 'lv': 0, 'i': 9},
         {'id': 274, 'x': 19, 'y': 18, 'lv': 0, 'i': 10},
         {'id': 275, 'x': 20, 'y': 18, 'lv': 0, 'i': 11},
         {'id': 258, 'x': 11, 'y': 16, 'dir': 3, 'lv': 0, 'i': 12},
         {'id': 259, 'x': 11, 'y': 17, 'dir': 3, 'lv': 0, 'i': 13},
         {'id': 260, 'x': 19, 'y': 9, 'dir': 0, 'lv': 0, 'i': 14},
         {'id': 261, 'x': 20, 'y': 9, 'dir': 0, 'lv': 0, 'i': 15},
         {'id': 282, 'x': 12, 'y': 16, 'dir': 3, 'lv': 0, 'i': 16},
         {'id': 283, 'x': 12, 'y': 17, 'dir': 3, 'lv': 0, 'i': 17},
         {'id': 284, 'x': 19, 'y': 10, 'dir': 0, 'lv': 0, 'i': 18},
         {'id': 285, 'x': 20, 'y': 10, 'dir': 0, 'lv': 0, 'i': 19},
         {'id': 218, 'x': 9, 'y': 16, 'dir': 3, 'lv': 0, 'i': 20},
         {'id': 219, 'x': 9, 'y': 17, 'dir': 3, 'lv': 0, 'i': 21},
         {'id': 220, 'x': 19, 'y': 7, 'dir': 0, 'lv': 0, 'i': 22},
         {'id': 221, 'x': 20, 'y': 7, 'dir': 0, 'lv': 0, 'i': 23},
         {'id': 236, 'x': 9, 'y': 15, 'dir': 3, 'lv': 0, 'i': 24},
         {'id': 237, 'x': 9, 'y': 18, 'dir': 3, 'lv': 0, 'i': 25},
         {'id': 238, 'x': 18, 'y': 7, 'dir': 0, 'lv': 0, 'i': 26},
         {'id': 239, 'x': 21, 'y': 7, 'dir': 0, 'lv': 0, 'i': 27},
         {'id': 2, 'x': 4, 'y': 16, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 28},
         {'id': 262, 'x': 3, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 263, 'x': 4, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 264, 'x': 5, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 31},
         {'id': 286, 'x': 3, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 32},
         {'id': 287, 'x': 5, 'y': 16, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 33},
         {'id': 125, 'x': 17, 'y': 3, 'dir': 3, 'lv': 4, 'ai': 0, 'i': 34},
         {'id': 265, 'x': 16, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 35},
         {'id': 266, 'x': 16, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 36},
         {'id': 267, 'x': 16, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 37},
         {'id': 288, 'x': 17, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 38},
         {'id': 289, 'x': 17, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 39}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 3,
            'y': 1,
            'dir': 1 },
        {
            'idx': 1,
            'x': 4,
            'y': 1,
            'dir': 1 },
        {
            'idx': 2,
            'x': 3,
            'y': 2,
            'dir': 1 },
        {
            'idx': 3,
            'x': 4,
            'y': 2,
            'dir': 1 },
        {
            'idx': 4,
            'x': 5,
            'y': 1,
            'dir': 1 },
        {
            'idx': 5,
            'x': 3,
            'y': 3,
            'dir': 1 },
        {
            'idx': 6,
            'x': 4,
            'dir': 1 },
        {
            'idx': 7,
            'x': 2,
            'y': 2,
            'dir': 1 },
        {
            'idx': 8,
            'x': 3,
            'dir': 1 },
        {
            'idx': 9,
            'x': 2,
            'y': 1,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(125, -1, 0, -1, 0, 19)
    stage.setEnemyEquip(126, -1, 0, -1, 0, 8)
    stage.loadBg(6)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab26')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab26')
    stage.draw()
    stage.bgSound(3)
    stage.unit(119).setDir(stage.countDir(119, 0))
    stage.say('&119\n조조, 마지막으로 본 지 며칠이 지났네.\n이것은 혼란스러운 시기에도 흔한 일입니다.\n기분 나쁘게 생각하지 마세요!')
    stage.unit(16).setAction(7)
    stage.say('&16\n도망가지 마!\n내가 네 목숨을 빼앗는 걸 지켜봐.')
    stage.unit(16).setAction(0)
    stage.say('(여포가 군대를 일으킬 줄은 몰랐는데… 혹시 서주로 가지 말았어야 했을까…?)\n(전쟁에 사적인 원한을 섞어서는 안 되는데… 이 일은 마음에 새겨야겠어.)')
    stage.unit(0).setAction(5)
    stage.say('좋습니다. 전력을 공격하겠습니다.')
    stage.unit(0).setAction(0)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[506] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[10] and stage.curCamp() == 2 and stage.round() == 3:
        if not vars[6] and not vars[7] and not vars[52] and not vars[53]:
            stage.unit(2).setDir(stage.countDir(2, 0))
            stage.unit(2).setAction(6)
            stage.say('&2\n장바! 포위공격을 시작해 조의 군대를 무너뜨려라!')
            stage.unit(2).setAction(0)
            stage.unit(125).setDir(stage.countDir(125, 0))
            stage.unit(125).setAction(6)
            stage.say('&125\n좋아! 전면적인 군대 공격!\n내가 장바가 행동하는 한, 아군 반드시 이길 거야!\n이제 조의 군대는 끝났네, 하하하.')
            stage.unit(125).setAction(0)
        stage.unit(2).setAI(1)
        stage.unit(125).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(264).setAI(1)
        stage.unit(265).setAI(1)
        stage.unit(266).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(286).setAI(1)
        stage.unit(287).setAI(1)
        stage.unit(288).setAI(1)
        stage.unit(289).setAI(1)
        vars[6] = 1
        vars[7] = 1
        vars[10] = 1
    if not vars[2] and not vars[11] and not vars[30] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.round() == 4:
        stage.unit(126).setDir(stage.countDir(126, 119))
        stage.say('&126\n루 장군, 때가 됐습니다.\n첫 번째 선에 공격 명령을 내라.')
        stage.unit(119).setDir(stage.countDir(119, 126))
        stage.say('&119\n흠. 나도 전투에 나가야 할 것 같지?\n&126\n루 장군은 여기 남아 그 자리만 지키면 돼.\n이 전투는 반드시 조조.........\n그는 아군의 용기와 지성에 깊은 감명을 받았다.\n&119\n왜?\n&126\n오늘날의 혼란스러운 시대에 봉건 영주들이 땅을 나누는 패턴이 뚜렷하게 드러난다,\n한 나라와만 싸울 수 있다면 생존은 불가능합니다.\n&126\n강력한 전투력을 보여줄 수 있다면,\n또한 향후 외교적 진전에도 도움이 될 것입니다.\n그게 바로 제 목표입니다.\n&119\n알겠어요!\n그럼 이곳은 당신에게 맡깁니다,\n당신의 재능을 최대한 활용하세요.')
        stage.unit(126).setDir(stage.countDir(126, 0))
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.unit(126).setAction(5)
        stage.say('&126\n첫 번째 대형: 공격을 전환하라!')
        stage.unit(126).setAction(0)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        stage.unit(284).setAI(1)
        stage.unit(285).setAI(1)
        vars[11] = 1
    if not vars[2] and not vars[12] and not vars[30] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.round() == 6:
        stage.say('&126\n두 번째 파도가 공격을 시작했다.')
        stage.unit(119).setAction(6)
        stage.say('&119\n훌륭해! 주둔군도 조조 추격과 제거에 합류하라.\n보병과 궁수, 공격!')
        stage.unit(119).setAction(0)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(220).setAI(1)
        stage.unit(221).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[12] = 1
    if not vars[2] and not vars[13] and not vars[30] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.round() == 8:
        stage.unit(126).setDir(stage.countDir(126, 119))
        stage.say('&126\n루 장군, 제발 공격해 주십시오.\n지친 조군에 마지막 일격을 가하라!')
        stage.unit(119).setAction(7)
        stage.unit(119).setAction(5)
        stage.say('&119\n흠! 꼭 조조 머리를 가져갈 거야.\n모든 병사들, 들어라, 전면 돌격!\n&126\n루 장군, 당신은 이미 한 나라의 통치자임을 잊지 마십시오,\n절대 무모하게 행동하지 마라.\n&119\n나는 초선 때문에 죽을 수 없다는 걸 알았다.\n이 혼란스러운 세상에서 살아남아야 해!')
        stage.unit(119).setAction(0)
        stage.unit(126).setDir(stage.countDir(126, 0))
        stage.setAI(16, 14, 23, 19, 2, 1)
        vars[13] = 1
    if not vars[14] and not vars[50] and not vars[51] and stage.totalUnit(2) >= 9 and stage.round() >= 7 and stage.round() < 10 and stage.totalUnit(0) < 10:
        if not vars[54]:
            stage.unit(16).setAction(4)
            stage.unit(16).setDir(stage.countDir(16, 0))
            stage.unit(14).setDir(stage.countDir(14, 0))
            stage.say('&16\n음, 상황이 좋지 않네, 주군,\n일단 철수합시다; 더 이상 버틸 수 없습니다.\n&14\n주군, 저도 전위 장군님의 의견에 동의합니다,\n이 도시를 점령하려면 더 큰 준비가 필요하다.')
        else:
            stage.say('&0\n이게 정말 아군에게 나쁜 걸까요?\n잠시 후퇴할까? 아니면 계속 공격할까......?')
        sel = stage.choice('후퇴\n계속해서 푸양을 공격하라', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n전군을 후퇴시켜라!\n후퇴 후 재집결!')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(0, 0, 5, 0)
            vars[2] = 1
            stage.unit(126).setDir(stage.countDir(126, 119))
            stage.say('&126\n적을 쉽게 도망치게 해서는 안 되며,\n군대 전체가 조조를 추격했다.')
            stage.unit(126).setDir(stage.countDir(126, 0))
            stage.unit(119).setDir(stage.countDir(119, 0))
            stage.unit(119).setAction(6)
            stage.say('&119\n흠! 조조를 쫓아라,\n절대 그를 놓칠 수 없어!')
            stage.unit(119).setAction(0)
            stage.setAI(0, 0, 27, 23, 2, 3, 0, 0, 0)
        elif sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이 병력을 여포 아이들과 맞서며,\n충분합니다!\n여러분, 기운 내세요!')
            stage.unit(0).setAction(0)
        vars[14] = 1
    if vars[13] and not vars[14] and not vars[15] and not vars[50] and not vars[51] and stage.round() == 10:
        if not vars[54]:
            stage.unit(16).setAction(4)
            stage.unit(16).setDir(stage.countDir(16, 0))
            stage.unit(14).setDir(stage.countDir(14, 0))
            stage.say('&16\n음, 상황이 좋지 않네, 주군,\n일단 철수합시다; 더 이상 버틸 수 없습니다.\n&14\n주군, 저도 전위 장군님의 의견에 동의합니다,\n이 도시를 점령하려면 더 큰 준비가 필요하다.')
        else:
            stage.say('&0\n이게 정말 아군에게 나쁜 걸까요?\n잠시 후퇴해야 할까요? 아니면 계속 공격해야 할까요......?')
        sel = stage.choice('후퇴\n계속해서 푸양을 공격하라', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n전군을 후퇴시켜라!\n후퇴 후 재집결!')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(0, 0, 5, 0)
            vars[2] = 1
            stage.unit(126).setDir(stage.countDir(126, 119))
            stage.say('&126\n적을 쉽게 도망치게 해서는 안 되며,\n군대 전체가 조조를 추격했다.')
            stage.unit(126).setDir(stage.countDir(126, 0))
            stage.unit(119).setDir(stage.countDir(119, 0))
            stage.unit(119).setAction(6)
            stage.say('&119\n흠! 조조를 쫓아라,\n절대 그를 놓칠 수 없어!')
            stage.unit(119).setAction(0)
            stage.setAI(0, 0, 27, 23, 2, 3, 0, 0, 0)
        elif sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이 병력을 여포 아이들과 맞서며,\n충분합니다!\n여러분, 기운 내세요!')
            stage.unit(0).setAction(0)
        vars[15] = 1
    if not vars[2] and not vars[16] and stage.totalUnit(2) >= 7 and stage.round() >= 12 and stage.totalUnit(0) < 8:
        if not vars[54]:
            stage.unit(16).setAction(4)
            stage.unit(16).setDir(stage.countDir(16, 0))
            stage.say('&16\n음, 상황이 좋지 않네, 주군,\n일단 철수합시다; 더 이상 버틸 수 없습니다.')
        else:
            stage.say('&0\n상황은 긴장감이 감돌았다,\n잠시 후퇴할까? 아니면 계속 공격할까......?')
        sel = stage.choice('후퇴\n계속해서 푸양을 공격하라', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n군대 전체를 후퇴시켜! 재정비!')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(0, 0, 5, 0)
            vars[2] = 1
            if not vars[50] and not vars[51]:
                stage.unit(126).setDir(stage.countDir(126, 119))
                stage.say('&126\n적을 쉽게 도망치게 해서는 안 되며,\n군대 전체가 조조를 추격했다.')
                stage.unit(126).setDir(stage.countDir(126, 0))
                stage.unit(119).setDir(stage.countDir(119, 0))
                stage.unit(119).setAction(6)
                stage.say('&119\n흠! 조조를 쫓아라,\n절대 그를 놓칠 수 없어!')
                stage.unit(119).setAction(0)
            stage.setAI(0, 0, 27, 23, 2, 3, 0, 0, 0)
        elif sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이 병력을 여포 아이들과 맞서며,\n충분합니다!\n여러분, 기운 내세요!')
            stage.unit(0).setAction(0)
        vars[16] = 1
    if not vars[20] and stage.isInPos(1025, 18, 17):
        stage.getItem(157, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 18, 16):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 19, 16):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 20, 16):
        stage.getItem(150, 0, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 4, 16):
        stage.getItem(150, 0, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 19, 17):
        stage.getItem(151, 0, True, 1025)
        vars[25] = 1
    if not vars[6] and stage.totalRectUnit(2, 3, 15, 5, 16) == 6 and stage.curCamp() == 2 and stage.totalRectUnit(0, 8, 0, 27, 5) >= 6:
        stage.unit(2).setAction(5)
        stage.say('&2\n내 목표는 조의 군대를 교란시키는 것이다,\n조의 군대에 빠르게 접근해 전투력을 약화시켜라!\n모두 돌격!')
        stage.unit(2).setAction(0)
        stage.unit(2).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(264).setAI(1)
        stage.unit(286).setAI(1)
        stage.unit(287).setAI(1)
        stage.unit(125).setAI(1)
        stage.unit(265).setAI(1)
        stage.unit(266).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(288).setAI(1)
        stage.unit(289).setAI(1)
        vars[6] = 1
    if not vars[7] and stage.totalRectUnit(2, 16, 2, 17, 4) == 6 and stage.curCamp() == 2 and stage.totalRectUnit(0, 0, 7, 7, 23) >= 6:
        stage.unit(125).setAction(5)
        stage.say('&125\n좋은 기회야. 싸울 시간이야!\n내가 조조를 죽이면, 나, 장바는 큰 공을 이룰 것이다!\n하하하.')
        stage.unit(125).setAction(0)
        stage.unit(125).setAI(1)
        stage.unit(265).setAI(1)
        stage.unit(266).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(288).setAI(1)
        stage.unit(289).setAI(1)
        stage.unit(2).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(264).setAI(1)
        stage.unit(286).setAI(1)
        stage.unit(287).setAI(1)
        vars[7] = 1
    if not vars[12] and not vars[30] and stage.isInRect(1025, 8, 6, 27, 23) and stage.curCamp() == 2:
        stage.unit(126).setAction(10)
        stage.unit(126).setAction(5)
        stage.say('&126\n성문이 무너지면 관리하기 어려울 것이다,\n도시 문 방어를 강화하고,\n다른 문들은 방어를 강화해야 해!')
        stage.unit(126).setAction(0)
        stage.unit(2).setAI(1)
        stage.unit(125).setAI(1)
        stage.unit(262).setAI(1)
        stage.unit(263).setAI(1)
        stage.unit(264).setAI(1)
        stage.unit(265).setAI(1)
        stage.unit(266).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(286).setAI(1)
        stage.unit(287).setAI(1)
        stage.unit(288).setAI(1)
        stage.unit(289).setAI(1)
        if not vars[11]:
            stage.unit(258).setAI(0)
            stage.unit(259).setAI(0)
            stage.unit(260).setAI(0)
            stage.unit(261).setAI(0)
            stage.unit(282).setAI(0)
            stage.unit(283).setAI(0)
            stage.unit(284).setAI(0)
            stage.unit(285).setAI(0)
        if not vars[12]:
            stage.unit(218).setAI(0)
            stage.unit(219).setAI(0)
            stage.unit(220).setAI(0)
            stage.unit(221).setAI(0)
            stage.unit(236).setAI(0)
            stage.unit(237).setAI(0)
            stage.unit(238).setAI(0)
            stage.unit(239).setAI(0)
        vars[30] = 1
    if not vars[2] and not vars[13] and not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 13, 11, 26, 22):
        stage.unit(119).setAction(5)
        stage.say('&119\n정말 쓸모없어......!\n적이 이미 우리 바로 앞에 있어!\n난 싸워서 빠져나갈 거야.')
        stage.unit(119).setAction(0)
        stage.setAI(16, 14, 23, 19, 2, 0)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(261).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        stage.unit(284).setAI(1)
        stage.unit(285).setAI(1)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(220).setAI(1)
        stage.unit(221).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[31] = 1
    if vars[2] and not vars[32] and stage.isInRect(0, 0, 0, 5, 0):
        stage.resumeCtrl()
        stage.say('&0\n휴, 드디어 위험에서 벗어났네요!')
        stage.reward()
        stage.end()
        vars[32] = 1
        vars[0] = 1
        vars[100] = 1
        vars[606] = 1
        vars[706] = 0
        return True
    if not vars[40] and stage.isNear(0, 119, True):
        stage.unit(0).setDir(stage.countDir(0, 119))
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.say('&0\n뜻밖에도 여포는 변화하는 상황에 적응할 수 있는 능력도 가지고 있습니다.\n정말 칭찬할 만합니다.\n&119\n너만 어려운 시기에 서 있는 게 아니야!\n너무 거만하게 굴지 마!')
        vars[40] = 1
    if not vars[41] and stage.isNear(16, 2, False):
        stage.unit(2).setDir(stage.countDir(2, 16))
        stage.unit(16).setDir(stage.countDir(16, 2))
        stage.say('&2\n너랑 놀 시간 없어! 비켜.\n&16\n그만 말해! 내가 여기 있으면,\n내 머리카락 만질 생각도 하지 마주군!')
        fight = stage.startFight(16, 2, 5)
        fight.showUnit(True, '전위.\n이 자식아, 우리 집안이 얼마나 강한지 몰라주군,\n빨리 이름을 발표해!', 9)
        fight.showUnit(False, '내 이름을 밝히면 너희가 깜짝 놀랄까 봐 걱정돼!\n나는 장원위안, 장료 사람이야!\n다시 말해, 비켜!', 8)
        fight.setAction(True, 6)
        fight.say(True, '나는 내 목숨을 걸고 주군을 지키려 한다,\n통과하고 싶으면 먼저 나를 이겨야 해!', True)
        fight.setAction(False, 9)
        fight.say(False, '응! 그럼 내가 먼저 널 죽일 거야!', True)
        fight.showStart()
        fight.setAction(True, 0)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack2(False, 0, True)
        fight.attack2(False, 1, True)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.say(True, '뭐라고?! 안 될 거야!', True)
        fight.setAction(False, 1)
        fight.say(False, '응!', True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack1(False, 3, True)
        fight.setAction(False, 2)
        fight.attack1(False, 1, False)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, True)
        fight.setAction(True, 1)
        fight.attack1(False, 3, True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 2, True)
        stage.delay(10)
        fight.setAction(True, 8)
        stage.delay(10)
        fight.setAction(False, 8)
        stage.delay(10)
        fight.say(True, '(세상에 이렇게 큰 곳이 있다니! 이렇게 강한 상대가 있다니!)', True)
        fight.say(False, '(알고 보니……이게 조군의 전투력이로군.\n이 악랄한 전위는 소문보다 더 용맹하구나.)', True)
        fight.end()
        vars[41] = 1
    if not vars[42] and stage.isNear(16, 125, False):
        stage.unit(125).setDir(stage.countDir(125, 16))
        stage.unit(16).setDir(stage.countDir(16, 125))
        stage.say('&125\n야, 너구나. 어디 있조조?\n&16\n네가 누구라고 생각해?\n그는 실제로 거만하게 행동했어요!\n알고 싶으면 먼저 나를 이겨야 해.')
        stage.attackAction(16, 125, 0)
        stage.unit(125).setAction(8)
        stage.unit(125).setAction(4)
        stage.say('&16\n어떻게...... 너는 말만 크게 해?\n&125\n뭐라고 했어? 너무 아파......!\n이제 내가 우위를 점했어...... 아이고!\n나는 모든 면에서 너보다 분명히 낫다...... 아파.\n&125\n하지만 두 장군 모두 존재하기 위해,\n이번엔 무승부로 하자.\n아야, 너무 아파......')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 126, True):
        stage.unit(0).setDir(stage.countDir(0, 126))
        stage.unit(126).setDir(stage.countDir(126, 0))
        stage.say('&0\n여포의 전략가인가요?\n이름이 뭐야?\n&126\n위대한 전투 한가운데서 어떻게 장기와 짧은 것을 논쟁할 수 있겠는가!\n저는 진궁, 공타이입니다. 저를 기억해야 합니다!\n&0\n진궁, 네 연기는 뛰어나다,\n내 진영에 함께하지 않을까?\n&126\n충성스러운 신하가 두 명의 통치자를 섬기지 않으며, 게다가.........\n마지막 순간에 이탈하는 사람을 고용하고 싶지 않더라도,\n&0\n그렇게 말할수록 널 더 이용하고 싶어져.\n&126\n정말 위험한 사람이야, 하지만 나한테는 안타까워\n내 마음속에는............ 나는 내 주군의 형상으로 가득 차 있다.\n포기하는 게 좋겠어.')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n죽을 수 없어. 먼저 후퇴해서 또 기회를 기다릴 거야.\n후퇴!')
        stage.unit(119).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(126, 7, 0, 2):
        stage.say('&126\n상황은 암울했고, 후퇴하는 것이 현명해 보였다.\n후퇴!')
        stage.unit(126).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(2, 7, 0, 2):
        stage.say('&2\n이번에는 너무 부주의장료. 후퇴!')
        stage.unit(2).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(125, 7, 0, 2):
        stage.say('&125\n젠장, 할아버지, 때리려고 했어요,\n갑작스러운 긴급 상황이 아니었다면!\n이번엔 봐줄게. 다음에 봐.')
        stage.unit(125).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(16, 7, 0, 2):
        stage.say('&16\n소수와 다수를 괴롭히는 것은 정말 비열한 일입니다!\n진짜 남자라면 나랑 해결해!\n겁쟁이!')
        stage.unit(16).retreatTxt(False)
        stage.unit(16).hide(1)
        vars[54] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        stage.reward(0, [
            38,
            -1])
        stage.end()
        vars[0] = 1
        vars[606] = 1
        vars[706] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 여포군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
