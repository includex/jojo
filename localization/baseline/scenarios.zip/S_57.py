# Source Generated with Decompyle++
# File: S_57.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        0,
        35,
        0,
        163,
        3,
        164,
        1,
        166,
        4,
        167,
        2,
        168,
        22,
        165,
        17,
        162,
        21,
        169], 1)
    stage.initFight()
    stage.setGlobalData(40, -2, -1, 0, 1, 2)
    stage.createEnemy(
        [{'id': 35, 'hide': 1, 'x': 20, 'y': 3, 'lv': 6, 'i': 0},
         {'id': 163, 'hide': 1, 'x': 3, 'y': 19, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 1},
         {'id': 164, 'hide': 1, 'x': 3, 'y': 20, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 2},
         {'id': 168, 'hide': 1, 'x': 20, 'y': 36, 'dir': 0, 'lv': 6, 'i': 3},
         {'id': 167, 'hide': 1, 'x': 22, 'y': 32, 'dir': 0, 'lv': 6, 'i': 4},
         {'id': 166, 'hide': 1, 'x': 17, 'y': 34, 'dir': 0, 'lv': 6, 'i': 5},
         {'id': 165, 'x': 36, 'y': 19, 'dir': 3, 'lv': 6, 'i': 6},
         {'id': 162, 'x': 34, 'y': 17, 'dir': 3, 'lv': 6, 'i': 7},
         {'id': 169, 'x': 35, 'y': 22, 'dir': 3, 'lv': 6, 'i': 8},
         {'id': 414, 'x': 33, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 9},
         {'id': 415, 'x': 35, 'y': 19, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 10},
         {'id': 416, 'x': 34, 'y': 20, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 11},
         {'id': 417, 'x': 36, 'y': 20, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 418, 'x': 31, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 419, 'x': 32, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 420, 'x': 32, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 421, 'x': 34, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 422, 'x': 32, 'y': 22, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 423, 'x': 33, 'y': 21, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 424, 'x': 33, 'y': 23, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 425, 'x': 35, 'y': 21, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 438, 'hide': 1, 'x': 20, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 439, 'hide': 1, 'x': 21, 'y': 36, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 440, 'hide': 1, 'x': 19, 'y': 36, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 441, 'hide': 1, 'x': 20, 'y': 37, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 442, 'hide': 1, 'x': 22, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 443, 'hide': 1, 'x': 23, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 444, 'hide': 1, 'x': 21, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 445, 'hide': 1, 'x': 22, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 28},
         {'id': 446, 'hide': 1, 'x': 17, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 447, 'hide': 1, 'x': 18, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 448, 'hide': 1, 'x': 16, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 449, 'hide': 1, 'x': 17, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 32}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 21,
            'y': 19,
            'dir': 1 },
        {
            'idx': 1,
            'x': 18,
            'y': 18,
            'dir': 1 },
        {
            'idx': 2,
            'x': 18,
            'y': 21,
            'dir': 1 },
        {
            'idx': 3,
            'x': 21,
            'y': 20,
            'dir': 1 },
        {
            'idx': 4,
            'x': 21,
            'y': 18,
            'dir': 1 },
        {
            'idx': 5,
            'x': 21,
            'y': 21,
            'dir': 1 },
        {
            'idx': 6,
            'x': 20,
            'y': 19,
            'dir': 1 },
        {
            'idx': 7,
            'x': 20,
            'y': 20,
            'dir': 1 },
        {
            'idx': 8,
            'x': 20,
            'y': 18,
            'dir': 1 },
        {
            'idx': 9,
            'x': 20,
            'y': 21,
            'dir': 1 },
        {
            'idx': 10,
            'x': 19,
            'y': 19,
            'dir': 1 },
        {
            'idx': 11,
            'x': 19,
            'y': 20,
            'dir': 1 },
        {
            'idx': 12,
            'x': 19,
            'y': 18,
            'dir': 1 },
        {
            'idx': 13,
            'x': 19,
            'y': 21,
            'dir': 1 },
        {
            'idx': 14,
            'x': 18,
            'y': 19,
            'dir': 1 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(163, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(164, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(166, 35, 0, -1, 0, -1)
    stage.setEnemyEquip(165, -1, 0, -1, 0, 5)
    stage.loadBg(57)
    stage.setObjects(True, 17, [
        [
            93,
            19,
            23],
        [
            94,
            20,
            23]])
    stage.setObjects(True, 17, [
        [
            85,
            19,
            27],
        [
            86,
            20,
            27]])
    stage.setObjects(True, 17, [
        [
            91,
            16,
            19],
        [
            92,
            16,
            20]])
    stage.setObjects(True, 17, [
        [
            83,
            12,
            19],
        [
            84,
            12,
            20]])
    stage.setObjects(True, 17, [
        [
            95,
            19,
            16],
        [
            96,
            20,
            16]])
    stage.setObjects(True, 17, [
        [
            87,
            19,
            12],
        [
            88,
            20,
            12]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab37')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab37')
    stage.draw()
    stage.bgSound(9)
    stage.unit(0).setDir(0)
    stage.unit(0).setDir(3)
    stage.unit(0).setDir(2)
    stage.unit(0).setDir(1)
    stage.say('&0\n이 지하 통로는 좀 이상해,\n유부푸와 비슷한 분위기가 있었다.')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n여기 방이 네 개 있는 것 같아,\n모든 방의 문은 꽉 닫혀 있었다.\n도대체 어디에 숨공명 거야?')
    stage.unit(6).setDir(1)
    stage.say('&6\n오른쪽 통로의 문은 잠기지 않은 듯했다.')
    stage.unit(0).setAction(5)
    stage.say('좋습니다. 먼저 이 방을 확인해 보겠습니다.\n여러분, 저와 함께 들어오세요.')
    stage.unit(0).setAction(0)
    stage.unit(0, 1).move(27, 19, 1)
    stage.unit(3, 1).move(27, 20, 1)
    stage.unit(4, 1).move(26, 19, 1)
    stage.unit(5, 1).move(26, 20, 1)
    stage.unit(6, 1).move(25, 19, 1)
    stage.unit(7, 1).move(25, 20, 1)
    stage.say('&13\n지형으로 보면 습지처럼 보입니다.\n항상 좀 이상하게 느껴져요......\n&15\n누군가 안에 있는 것 같아.\n&16\n그거 주유하지 않나요!?\n&0\n왜 주유 사람들이 여기 있지?\n이미 죽은 거 아니야?\n&0\n지하 제단이 영혼을 부활시키는 힘을 가질 수 있을까요?\n&162\n음, 머리가 너무 아프고 온몸도 아파요.\n여기가 어디야?\n내가 어떻게 여기 있지?\n&169\n저기 서 있는 사람 조조 아니야?\n여기가 전장인가요?\n&165\n조조Who 그거야?" 조조...... 이제 기억났어,\n기억났어, 이 사람은 죽어 마땅해!\n우를 위해서라면 조조 죽여야 해.\n&165\n나무 인간을 공격해! 조조 죽여라!')
    stage.setWinCondition('승리 조건\n1. 제갈량를 죽인다.\n\n패배 조건\n1. 조조 죽음.\n2. 40턴을 초과한다.')
    stage.showWinCondition('죽여제갈량!')
    stage.startOper()
    vars[70] = 0
    vars[71] = 0
    vars[72] = 1
    vars[73] = 1
    vars[557] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[56] and vars[57] and vars[58] and not vars[2] and not vars[11] and stage.round() >= 1:
        stage.say('&0\n결국 모두 전멸했다.\n이 방에는 공명 없는 것 같아.')
        stage.unit(17).setDir(stage.countDir(17, 0))
        stage.say('&17\n다른 방을 살펴보자.')
        stage.unit(23).setDir(stage.countDir(23, 0))
        stage.say('&23\n공명 어딘가에 숨어 있을 거야.')
        stage.unit(0).setAction(5)
        stage.say('&0\n제단 중앙으로 돌아가라.')
        stage.unit(0).setAction(0)
        stage.setObjects(False, 16, [
            [
                93,
                19,
                23],
            [
                94,
                20,
                23]])
        stage.setObjects(False, 16, [
            [
                85,
                19,
                27],
            [
                86,
                20,
                27]])
        stage.unit(1).setAction(10)
        stage.say('&1\n흠! 무슨 일이야?')
        stage.unit(20).setDir(stage.countDir(20, 1))
        stage.say('&20\n아래 문이 열린 것 같았다.')
        stage.unit(0).setDir(stage.countDir(0, 20))
        stage.say('&0\n문이 열려 있었다고?\n방 안의 적을 죽여야만 죽일 수 있는 것 같아요,\n그때서야 다른 문들이 자동으로 열립니다.')
        stage.unit(166).show()
        stage.unit(167).show()
        stage.unit(168).show()
        stage.say('&166\n나는 누구지......\n왜 모든 것이 이렇게 잡히지 않는 것처럼 느껴질까요......\n아무것도 기억이 안 나!')
        stage.unit(167).setDir(stage.countDir(167, 166))
        stage.say('&167\n아버지! 종모!\n이곳이 정확히 어디죠......')
        stage.unit(168).setDir(stage.countDir(168, 166))
        stage.say('&168\n저도 혼란스러워요.\n하지만...... 나는 항상 여기서 조조 느껴,\n죽여야 him조조......')
        stage.unit(166).setDir(stage.countDir(166, 0))
        stage.say('&166\n생각났다……\n조조를 죽이는 것이 우리 부자의 사명이다.\n조조는 어디 있느냐? 어서 나와라……')
        stage.unit(167).setDir(0)
        stage.unit(168).setDir(0)
        stage.unit(166).setDir(0)
        stage.unit(438).show()
        stage.unit(439).show()
        stage.unit(440).show()
        stage.unit(441).show()
        stage.unit(442).show()
        stage.unit(443).show()
        stage.unit(444).show()
        stage.unit(445).show()
        stage.unit(446).show()
        stage.unit(447).show()
        stage.unit(448).show()
        stage.unit(449).show()
        stage.unit(8).setDir(stage.countDir(8, 166))
        stage.say('&8\n이번에는 부활한 자들이 손권 부자인 것 같아?\n이번에는 조가와 손가가 대단한 쇼를 보여줄 거야!')
        stage.unit(0).setDir(stage.countDir(0, 166))
        stage.say('좋습니다. 손씨 일가를 처치하겠습니다!\n저희를 매장시키세요!')
        stage.unit(4).setDir(stage.countDir(4, 167))
        stage.say('&4\n손책 타이시 치와 싸웠다고 들었어.\n나, 조장이 막 그와 이 문제를 해결하려 한다.')
        stage.bgSound(10)
        vars[2] = 1
        vars[11] = 1
    if vars[2] and vars[3] and not vars[4] and not vars[15] and stage.curCamp() == 0 and stage.round() >= 1:
        if stage.isInRect(1026, 1, 15, 11, 24):
            if stage.isInRect(1025, 1, 15, 11, 24):
                if stage.totalRectUnit(6, 12, 19, 12, 20) == 0:
                    if not vars[60]:
                        stage.setObjects(True, 17, [
                            [
                                83,
                                12,
                                19],
                            [
                                84,
                                12,
                                20]])
                        vars[60] = 1
                    if not vars[16] and vars[17]:
                        stage.say('&0\n젠장! 통로에도 함정이 있는 것 같아.\n&20\n음, 또 공명가 만든 함정에 빠진 걸까?')
                        vars[16] = 1
                    elif vars[60]:
                        stage.setObjects(False, 16, [
                            [
                                83,
                                12,
                                19],
                            [
                                84,
                                12,
                                20]])
                        vars[60] = 0
                    elif vars[60]:
                        stage.setObjects(False, 16, [
                            [
                                83,
                                12,
                                19],
                            [
                                84,
                                12,
                                20]])
                        vars[60] = 0
        if stage.isInRect(1026, 1, 15, 15, 24):
            if stage.isInRect(1025, 1, 15, 15, 24):
                if stage.totalRectUnit(6, 16, 19, 16, 20) == 0:
                    if not vars[61]:
                        stage.setObjects(True, 17, [
                            [
                                91,
                                16,
                                19],
                            [
                                92,
                                16,
                                20]])
                        vars[61] = 1
                    if not vars[16] and vars[17]:
                        stage.say('&0\n젠장! 통로에도 함정이 있는 것 같아.\n&20\n음, 또 공명가 만든 함정에 빠진 걸까?')
                        vars[16] = 1
                    elif vars[61]:
                        stage.setObjects(False, 16, [
                            [
                                91,
                                16,
                                19],
                            [
                                92,
                                16,
                                20]])
                        vars[61] = 0
                    elif vars[61]:
                        stage.setObjects(False, 16, [
                            [
                                91,
                                16,
                                19],
                            [
                                92,
                                16,
                                20]])
                        vars[61] = 0
        vars[15] = 1
    if vars[2] and vars[3] and not vars[4] and vars[15] and stage.curCamp() == 2 and stage.round() >= 1:
        vars[15] = 0
        vars[17] = 1
    if vars[2] and not vars[3] and stage.round() >= 1:
        if stage.totalUnit(0) < 2:
            if stage.totalRectUnit(0, 2, 16, 11, 23) == 1:
                stage.center(5, 20)
                stage.delay(5)
                stage.say('&0\n여기 아무도 없나?\n&5\n좀 이상하네요!')
                stage.unit(9).setDir(stage.countDir(9, 0))
                stage.say('&9\n절대 가볍게 여기지 마세요!')
                stage.unit(22).setDir(stage.countDir(22, 0))
                stage.say('&22\n아마 공명가 준비한 것 같아, 맞지?\n뭔가 속임수가 있을 거야.')
                stage.unit(163).show()
                stage.unit(164).show()
                stage.unit(32).setAction(4)
                stage.say('&163\n두통이 터질 것 같았다......\n정확히 무슨 일이 있었던 거야?')
                stage.unit(164).setDir(stage.countDir(164, 0))
                stage.say('&164\n여기 군대가 조조 있어.\n맞아, 다 너희 덕분이야.\n그냥 죽조조면 충분해!')
                stage.unit(3).setDir(stage.countDir(3, 32))
                stage.say('&3\n형님! 셋째 형님!\n그 녀석공명 감히 형의 영혼을 가지고 놀다니!\n이걸 쉽게 넘어가지 않을 거야!\n&33\n조조 어디 있지......!?')
                stage.center(11, 20)
                stage.delay(5)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(5)
                stage.info('어디 있조조...... 어디 있지......\n어디 있지? 아...... 어디 있지......')
                stage.say('&0\n저렇게 큰 포효는 어디서 나온 거지!\n그 소리는 정말 귀가 멍멍해질 정도였다.\n그 메아리는 지하 통로에 너무 강하게 울려 퍼져서 견딜 수 없을 정도였다!\n&11\n무-무슨 일이야?\n&25\n무슨 일이 있었나요?\n또 다른 공명 속임수인가요?\n&18\n이-이게 사람이 내는 소리인가요?\n&0\n여러분, 당황하지 마세요...... 젠장!\n이제 모든 게 혼란에 빠졌어!')
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 0,
                        'y1': 12,
                        'x2': 39,
                        'y2': 39,
                        'camp': 0 }])
                stage.setAI(2, 16, 11, 23, 2, 1)
                vars[3] = 1
                vars[15] = 1
            elif stage.totalRectUnit(0, 2, 16, 11, 23) == 2:
                stage.center(5, 20)
                stage.delay(5)
                stage.say('&0\n여기 아무도 없나?\n&5\n좀 이상하네요!')
                stage.unit(9).setDir(stage.countDir(9, 0))
                stage.say('&9\n절대 가볍게 여기지 마세요!')
                stage.unit(22).setDir(stage.countDir(22, 0))
                stage.say('&22\n아마 공명가 준비한 것 같아, 맞지?\n뭔가 속임수가 있을 거야.')
                stage.unit(163).show()
                stage.unit(164).show()
                stage.unit(32).setAction(4)
                stage.say('&163\n두통이 터질 것 같았다......\n정확히 무슨 일이 있었던 거야?')
                stage.unit(164).setDir(stage.countDir(164, 0))
                stage.say('&164\n여기 군대가 조조 있어.\n맞아, 다 너희 덕분이야.\n그냥 죽조조면 충분해!')
                stage.unit(3).setDir(stage.countDir(3, 163))
                stage.say('&3\n형님! 셋째 형님!\n그 녀석공명 감히 형의 영혼을 가지고 놀다니!\n이걸 쉽게 넘어가지 않을 거야!\n&33\n조조 어디 있지......!?')
                stage.center(11, 20)
                stage.delay(5)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(1)
                stage.center(11, 20)
                stage.delay(1)
                stage.center(13, 20)
                stage.delay(5)
                stage.info('어디 있조조...... 어디 있지......\n어디 있지? 아...... 어디 있지......')
                stage.say('&0\n왜 소음이 이렇게 시끄러운 거지?\n그 소리는 정말 귀가 멍멍해질 정도였다.\n이 지하 통로에서 울려 퍼지는 메아리가 있습니다.\n&11\n뭐, 뭐!\n&25\n뭐야, 이게 공명의 함정이야?\n&18\n이게 사람의 목소리인가요?\n&0\n숨 참아...... 젠장! 완전 엉망이야!')
                stage.setUnitStatus([
                    {
                        'hStatus': [
                            9],
                        'x1': 12,
                        'y1': 0,
                        'x2': 39,
                        'y2': 39,
                        'camp': 0 }])
                stage.setAI(2, 16, 11, 23, 2, 1)
                vars[3] = 1
                vars[15] = 1
    if vars[53] and vars[54] and vars[55] and not vars[12] and stage.round() >= 1:
        stage.setObjects(False, 16, [
            [
                91,
                16,
                19],
            [
                92,
                16,
                20]])
        stage.setObjects(False, 16, [
            [
                83,
                12,
                19],
            [
                84,
                12,
                20]])
        stage.say('&0\n다음 문은 이미 열린 것 같다.\n&5\n옆방에 누가 기다리고 있을까?\n&12\n방 두 개 남았어.\n반항공명, 기다려 봐.')
        stage.unit(10).setDir(stage.countDir(10, 0))
        stage.say('&10\n주군, 계속 앞으로 나아가!\n우리는 공명을 찾아야 해.')
        stage.unit(14).setDir(stage.countDir(14, 0))
        stage.say('&14\n안에 뭐가 있는지 아무도 몰라.\n여전히 주의가 중요합니다.')
        vars[12] = 1
    if vars[4] and vars[21] and vars[22] and stage.round() >= 1:
        stage.unit(35).setDir(2)
        stage.unit(35).setAction(1)
        stage.say('&35\n하하하!\n끝났다……\n마지막 기도까지 마침내 끝났다!\n&35\n천년의 세월을 지나, 마왕이 이곳에서 곧 부활한다!\n보아라, 마왕이 부활할 때가 왔다!\n&35\n사방의 힘이여, 어서 나를 도와라!\n마계에 봉인된 나의 힘을 해방하라!\n&35\n청룡, 주작, 백호, 현무여.\n마계에서 인간계로 건너오는 길잡이가 되어,\n마왕을 이 세상에 강림시켜라!\n&35\n……?@왜지?@왜 이렇게 된 거지?\n어째서 청룡이 응답하지 않는 거냐!?')
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.say('하하하, 아쉽습니다.\n허도의 제단과 기도는 모두 가짜입니다.')
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&35\n하지만 실제로 청룡의 악마 기운은 동쪽에서 왔다......\n&0\n그 마기운은 쉬서의 작품이었다,\n그는 봉인을 깨기 위해 제단을 세우지 않았다.\n&35\n그 미운 서슈가 감히 나한테 거짓말을 하다니......\n음, 그럼 널 죽일 거야,\n그 후 쉬두로 진격하세요.')
        stage.unit(35).setAction(5)
        stage.say('&35\n영혼이여, 오 영혼이여, 나를 위해 조조 죽여줘!\n그가 여기서 살아서 나가지 못하게 해!')
        stage.unit(35).setAction(0)
        stage.unit(2).setDir(stage.countDir(2, 35))
        stage.say('&2\n성공할 생각조차 하지 마!\n이 세상에서 네가 무모하게 행동하도록 내버려 둘 수 있겠어?\n널 죽일 장료 있어!')
        stage.unit(2).setDir(stage.countDir(2, 35))
        stage.say('&7\n나는 너를 쉬두로 보내지 않을 거야.\n모든 국민의 소원을 이루기 위해,\n널 죽여버릴 거야, 이 자식아!')
        stage.unit(24).setDir(stage.countDir(24, 35))
        stage.say('&24\n위, 우, 서의 병사들과 민간인들,\n모두가 평화를 위해 목숨을 바쳤다.\n우리는 절대 그들이 의미 없이 죽게 내버려 둘 수 없습니다!')
        vars[22] = 0
    if vars[4] and not vars[21] and not vars[22] and not vars[19] and stage.round() >= 1 and stage.curCamp() == 0:
        vars[19] = 1
        vars[22] = 1
    if vars[4] and not vars[21] and not vars[22] and vars[19] and not vars[20] and stage.curCamp() == 0 and stage.round() >= 1:
        vars[20] = 1
        vars[22] = 1
    if vars[4] and not vars[21] and not vars[22] and vars[20] and not vars[21] and stage.curCamp() == 0 and stage.round() >= 1:
        vars[21] = 1
        vars[22] = 1
    if vars[4] and not vars[21] and vars[22] and stage.curCamp() == 2 and stage.round() >= 1:
        vars[22] = 0
    if vars[51] and vars[52] and not vars[4] and not vars[13] and stage.round() >= 1:
        if vars[60]:
            stage.setObjects(False, 16, [
                [
                    83,
                    12,
                    19],
                [
                    84,
                    12,
                    20]])
            if vars[61]:
                stage.setObjects(False, 16, [
                    [
                        91,
                        16,
                        19],
                    [
                        92,
                        16,
                        20]])
            elif vars[61]:
                stage.setObjects(False, 16, [
                    [
                        91,
                        16,
                        19],
                    [
                        92,
                        16,
                        20]])
        stage.setObjects(False, 16, [
            [
                95,
                19,
                16],
            [
                96,
                20,
                16]])
        stage.setObjects(False, 16, [
            [
                87,
                19,
                12],
            [
                88,
                20,
                12]])
        stage.unit(0).setAction(5)
        stage.say('&0\n마지막 문은 이미 열린 것 같다.\n좋아, 군대 전체가 공격한다!\n공명 없애!')
        stage.unit(0).setAction(0)
        stage.unit(21).setDir(stage.countDir(21, 0))
        stage.say('&21\n그다음에는 공명 제거하면 임무가 완료됩니다.')
        stage.unit(35).show()
        stage.say('&35\n마침내 그들이 왔다,\n흠, 난 한 걸음 남았어......\n영혼들이여, 다시 한 번 저를 막아줘!')
        stage.unit(163).show(20, 4, 2)
        stage.say('&163\n음...... 아아아......')
        stage.unit(164).show(19, 4, 2)
        stage.say('&164\n...... 우우 오, 오......')
        stage.unit(35).setDir(stage.countDir(35, 164))
        stage.say('&35\n알고 보니, 한 번 두 번째로 죽으면,\n심지어 인간이라는 의식조차도 사라졌습니다.\n하지만 이렇게 하면 조종하기가 더 쉬워요.')
        stage.unit(168).show(20, 5, 2)
        stage.unit(167).show(19, 5, 2)
        stage.unit(166).show(18, 5, 2)
        stage.unit(165).show(21, 5, 2)
        stage.unit(162).show(18, 4, 2)
        stage.unit(169).show(21, 4, 2)
        stage.setAI(18, 4, 21, 5, 2, 1)
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.unit(35).setAction(5)
        stage.say('&35\n네가 조조를 죽일 수만 있다면,\n내가 너희 영혼을 풀어주겠다.\n가서 막아!')
        stage.unit(35).setAction(0)
        vars[19] = 0
        vars[20] = 0
        vars[21] = 0
        vars[22] = 0
        vars[4] = 1
        vars[13] = 1
    if not vars[70] and not vars[70] and not vars[71] and stage.curCamp() == 0 and stage.round() >= 4:
        if not vars[2]:
            if not vars[56]:
                stage.unit(414).show(35, 19, 3)
                stage.unit(415).show(36, 18, 3)
                stage.unit(416).show(36, 20, 3)
                stage.unit(417).show(37, 19, 3)
            if not vars[57]:
                stage.unit(418).show(33, 17, 3)
                stage.unit(419).show(34, 16, 3)
                stage.unit(420).show(34, 18, 3)
                stage.unit(421).show(35, 17, 3)
            if not vars[58]:
                stage.unit(422).show(34, 22, 3)
                stage.unit(423).show(35, 21, 3)
                stage.unit(424).show(35, 23, 3)
                stage.unit(425).show(36, 22, 3)
        if vars[2] and not vars[3]:
            if not vars[53]:
                stage.unit(438).show(20, 35, 0)
                stage.unit(439).show(21, 36, 0)
                stage.unit(440).show(19, 36, 0)
                stage.unit(441).show(20, 37, 0)
            if not vars[54]:
                stage.unit(442).show(22, 31, 0)
                stage.unit(443).show(23, 32, 0)
                stage.unit(444).show(21, 32, 0)
                stage.unit(445).show(22, 33, 0)
            if not vars[55]:
                stage.unit(446).show(17, 33, 0)
                stage.unit(447).show(18, 34, 0)
                stage.unit(448).show(16, 34, 0)
                stage.unit(449).show(17, 35, 0)
        if vars[4]:
            stage.unit(163).show(20, 4, 2)
            stage.unit(164).show(19, 4, 2)
            stage.unit(168).show(20, 5, 2)
            stage.unit(167).show(19, 5, 2)
            stage.unit(166).show(18, 5, 2)
            stage.unit(165).show(21, 5, 2)
            stage.unit(162).show(18, 4, 2)
            stage.unit(169).show(21, 4, 2)
            stage.unit(163).setAI(1)
            stage.unit(164).setAI(1)
            stage.unit(168).setAI(1)
            stage.unit(167).setAI(1)
            stage.unit(166).setAI(1)
            stage.unit(165).setAI(1)
            stage.unit(162).setAI(1)
            stage.unit(169).setAI(1)
        vars[71] = 1
        vars[72] = 0
        vars[73] = 1
        vars[70] = 1
    if not vars[70] and not vars[70] and not vars[72] and stage.curCamp() == 0 and stage.round() >= 4:
        vars[71] = 1
        vars[72] = 1
        vars[73] = 0
        vars[70] = 1
    if not vars[70] and not vars[70] and not vars[73] and stage.curCamp() == 0 and stage.round() >= 4:
        vars[71] = 0
        vars[72] = 1
        vars[73] = 1
        vars[70] = 1
    if vars[70] and stage.curCamp() == 2 and stage.round() >= 4:
        vars[70] = 0
    if not vars[40] and stage.isNear(0, 35, True):
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&0\n도망칠 곳 없이 이 지하 장소에 도착한 것,\n거기서 계산을 잘못 했어.\n넌 이미 죽음의 문턱에 있어!\n&35\n당신 상황도 마찬가지입니다.\n네가 죽는 한, 위, 슈, 우 삼국은 완전히 무너질 것이다,\n세상 모든 것을 쉽게 이해할 수 있을 거예요.')
        vars[40] = 1
    if not vars[4] and not vars[41] and stage.isNear(0, 163, True):
        stage.unit(0).setDir(stage.countDir(0, 163))
        stage.unit(163).setDir(stage.countDir(163, 0))
        stage.say('&0\n쉬안더, 일어나!\n&163\n아무 소리도 들리지 않고, 아무 느낌도 안 들어요......\n난 너만 봐, 조조!')
        vars[41] = 1
    if not vars[4] and not vars[42] and stage.isNear(3, 164, True):
        stage.unit(3).setDir(stage.countDir(3, 164))
        stage.unit(164).setDir(stage.countDir(164, 3))
        stage.say('&3\n셋째 형, 내 말 들었어?\n아직 깨어 있니, 셋째 형님!\n&164\n그건 내 둘째 형의 목소리였어......\n내가 지금 뭘 하고 있는 거지?\n둘째 형님, 어떻게 해야 할지 말씀해 주세요.\n&3\n셋째 형......\n내가 직접 평화를 가져다줄게.')
        vars[42] = 1
    if not vars[4] and not vars[43] and stage.isNear(1, 166, True):
        stage.unit(1).setDir(stage.countDir(1, 166))
        stage.unit(166).setDir(stage.countDir(166, 1))
        stage.say('&1\n나 하후돈, 기억나?\n우리는 한 번 시수이 고개에서 만났습니다.\n&166\n아무것도 기억나지 않아.\n누구세요? 왜 저를 귀찮게 하세요?\n&1\n정말 슬픈 일이에요.\n다시 저승으로 보내주겠다!')
        vars[43] = 1
    if not vars[4] and not vars[44] and stage.isNear(4, 167, True):
        stage.unit(4).setDir(stage.countDir(4, 167))
        stage.unit(167).setDir(stage.countDir(167, 4))
        stage.say('&4\n손책General, 나랑 이걸 해결해!"\n&167\n조조 어디 있지?\n누가 감히 나를 막으려 한다면, 나는 절대 용서하지 않을 것이다.\n조조! 어디야!?\n&4\n흠, 내 말 안 들려?')
        vars[44] = 1
    if not vars[4] and not vars[45] and stage.isNear(2, 168, True):
        stage.unit(2).setDir(stage.countDir(2, 168))
        stage.unit(168).setDir(stage.countDir(168, 2))
        stage.say('&2\n손권, 나 기억나?\n&168\n음, 물론 기억해요!\n허페이의 패배에 대한 굴욕은 평생 잊지 못할 것이다!\n&2\n손권, 너는 공명에게 조종당했어.\n순종적으로 저승으로 돌아가는 게 낫다!\n&168\n...... 내가 조종당하고 있는 걸까?\n지금은 아무 생각도 안 해,\n내가 생각하는 건 너를 죽이는 것뿐이야!\n&2\n손권 선생님......\n바로 풀어줄게.')
        vars[45] = 1
    if not vars[4] and not vars[46] and stage.isNear(22, 165, True):
        stage.unit(22).setDir(stage.countDir(22, 165))
        stage.unit(165).setDir(stage.countDir(165, 22))
        stage.say('&22\n주유Ah 시대의 천재로서\n이렇게 된 것은 정말 슬픈 일입니다.\n&165\n오가 왕국을 장악할 것이다,\n누구도 내 길을 막게 두지 않을 거야!\n&22\n오나라는 이미 멸망했다.\n주유, 다시 생각해 봐.\n&165\n아, 머리가 너무 아파요......\n눈앞에 펼쳐진 모든 것이 칠흑같이 어두웠다......\n차가운 바람이 내 귀를 스치고 지나간다...... 아아아!\n&22\n하아, 네가 이렇게 되는 모습 정말 보고 싶지 않아.')
        vars[46] = 1
    if not vars[4] and not vars[47] and stage.isNear(17, 162, True):
        stage.unit(17).setDir(stage.countDir(17, 162))
        stage.unit(162).setDir(stage.countDir(162, 17))
        stage.say('&162\n와아, 더 가까이 오지 마! 더 가까이 오지 마.\n왜 아무것도 보이지 않는 거지?\n너무 불편해, 누가 와서 좀 구해줘!\n&17\n참 불쌍하네요......\n공명 너무 잔인해......\n바로 네 고통을 덜어줄게.')
        vars[47] = 1
    if not vars[4] and not vars[48] and stage.isNear(21, 169, True):
        stage.unit(21).setDir(stage.countDir(21, 169))
        stage.unit(169).setDir(stage.countDir(169, 21))
        stage.say("&169\n권 ...... 권 ...... 헤비 어스 ...... 헤비 ......\n음, 마지막 단어가 기억나지 않네요.\n&21\n그들은 '컴백하라'고 말하고 싶어 하는 것 같아요.\n알고 보니 그는 자신이 아직 살아 있다고 생각했다......\n정말 sad......공명 용서받을 수 없는 일이에요!")
        vars[48] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n어떻게 너희 같은 인간들에게 죽을 수 있지......\n와아!')
        stage.unit(165).hide()
        stage.unit(162).hide()
        stage.unit(169).hide()
        stage.unit(168).hide()
        stage.unit(167).hide()
        stage.unit(166).hide()
        stage.unit(163).hide()
        stage.unit(164).hide()
        vars[50] = 1
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[657] = 1
        return True
    if not vars[51] and stage.unitStateTest(163, 7, 0, 2):
        stage.say('&163\n비록 내가 곧 죽을 것이지만,\n하지만 내 마음은 평화로 가득 차 있어......\n안녕히 계세요.')
        stage.unit(163).hide(2)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(164, 7, 0, 2):
        stage.say('&164\n벌써 매우 만족합니다.')
        stage.unit(164).hide(2)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(168, 7, 0, 2):
        stage.say('&168\n세상에 대한 내 그리움은 사라졌고,\n이제 편히 쉴 수 있어.')
        stage.unit(168).hide(2)
        stage.unit(438).hide()
        stage.unit(439).hide()
        stage.unit(440).hide()
        stage.unit(441).hide()
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(167, 7, 0, 2):
        stage.say('&167\n한숨...... 안녕.')
        stage.unit(167).hide(2)
        stage.unit(442).hide()
        stage.unit(443).hide()
        stage.unit(444).hide()
        stage.unit(445).hide()
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(166, 7, 0, 2):
        stage.say('&166\n나에게 무슨 일이 일어날지 모르겠어......\n미래를 생각하는 건 정말 힘들어.\n자러 가는 게 낫겠어......')
        stage.unit(166).hide(2)
        stage.unit(446).hide()
        stage.unit(447).hide()
        stage.unit(448).hide()
        stage.unit(449).hide()
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(165, 7, 0, 2):
        stage.say('&165\n내 의식은 때로는 맑고, 때로는 흐릿하다,\n이상한 느낌이..........\n그나저나, 너는 반드시 공명......')
        stage.unit(165).hide(2)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(162, 7, 0, 2):
        stage.say('&162\n흠, 드디어 잠을 좀 잘 수 있겠네.\n진심으로 감사드립니다.')
        stage.unit(162).hide(2)
        stage.unit(418).hide()
        stage.unit(419).hide()
        stage.unit(420).hide()
        stage.unit(421).hide()
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(169, 7, 0, 2):
        stage.say('&169\n모든 것이 너무나도 명확해졌다......\n나는 이미 죽어 있었던 것을 기억한다,\n하지만 두 번 죽을 수 있다는 건 꽤 흥미롭습니다.')
        stage.unit(169).hide(2)
        stage.unit(422).hide()
        stage.unit(423).hide()
        stage.unit(424).hide()
        stage.unit(425).hide()
        vars[58] = 1
    if vars[50] and vars[100] and not vars[0] and stage.winTest():
        stage.end()
        vars[0] = 1
        vars[657] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 공명에게 패배했다!')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
