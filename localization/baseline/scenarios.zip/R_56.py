# Source Generated with Decompyle++
# File: R_56.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 68, 135)
    stage.showHead(50, 144, 95)
    stage.bottomTxt('조의 군대', False, False, False)
    stage.delay(5)
    stage.head(0).move(80, 95)
    stage.delay(5)
    stage.bottomTxt('양평관을 공격했고,', True, False, False)
    stage.delay(5)
    stage.head(50).hide()
    stage.delay(5)
    stage.bottomTxt('그리고 관개를 지키던 쑤군을 결정적으로 격파했다.', True, False, True)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            21,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            15,
            44,
            52,
            1]])
    stage.draw()
    stage.setEventName('적은 우장평원에 있었다')
    stage.setStageName('양평관조조 본진지')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n마침내 양평관을 점령했다,\n모두가 뛰어나다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n가후 이미 장안에 도착했어야 했는데,\n서나라 군대는 도망칠 곳이 없다고 여겨졌다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흠.')
    stage.delay(5)
    stage.showUnit(19, 54, 22, 2)
    stage.say('&19\n주군!')
    stage.unit(19).move(54, 58, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n쉬두의 초선에서 긴급 보고가 들어왔다!\n&0\n음, 그게 뭐야?\n&19\n쉬두의 쉬슈는 이제 행방불명되었다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n뭐라고!?')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(0, 2)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n쉬쉬!')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n또한 보고서는 서서부에서\n나는 마왕의 부활에 관한 많은 기도를 발견했다,\n그리고 쉬쉬에게 공명 손글씨 편지.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 3)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n…… 알고 보니 쉬쉬가 내내 공모하고 있었던 along공명......')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n쉬쉬는 아마도 어머니의 죽음에 원망을 품고 있었을 것이다,\n그래서 우리에게 복수할 계획colluded공명 있는 거구나!')
    stage.unit(21).setAction(0)
    stage.say('&21\n내가 정확히 뭘 한 거지......\n그는 실제로 쉬쉬의 노모를 죽게 만들었다......\n그때 생각을 안 한 내 잘못이야......')
    stage.unit(0).setAction(3)
    stage.say('&0\n정욱, 자신을 탓하지 마세요.')
    stage.unit(0).setAction(0)
    stage.say('&0\n이제 유일한 방법은 먼저 쉬슈를 찾는 것이다,\n그러다 그 사건에 대해 물었어요.')
    stage.unit(19).setAction(6)
    stage.say('&19\n초선 쉬쉬의 행방을 찾고 있었어,\n결과가 나오면 연락할 것입니다.')
    stage.unit(19).setAction(0)
    stage.say('&0\n좋아.\n그는 초선에게 희망을 걸 수밖에 없었다.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n이제 서쪽과 남쪽의 제단들은 이미 기도가 끝났습니다,\n서서가 동쪽 제단에서 기도하고 있었다면......')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n나쁘지 않네요.\n남은 북쪽 제단도 기도된다면,\n마왕의 원래의 힘이 깨어날 것이다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n무슨 일이 있어도 우리는 그들을 막아야 해,\n북쪽 제단을 빨리 찾아라!')
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.showUnit(182, 54, 22, 2)
    stage.delay(3)
    stage.unit(182).setAction(11)
    stage.say('&182\n주군, 찾았공명!')
    stage.unit(0).setAction(3)
    stage.say('&0\n드디어 찾았네요!?\n지금 공명 어디에 있지?')
    stage.unit(0).setAction(0)
    stage.say('&182\n서군 잔존 병력을 모아 우장평원으로 향하는 길에 있었다.')
    stage.unit(0).setAction(17)
    stage.say('네, 알겠습니다.\n우리는 곧 오장원으로 향하겠습니다.')
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(1, 0)
    stage.showHead(0, 94, 99)
    stage.draw()
    stage.bottomTxt('조의 군대,', False, False, False)
    stage.delay(5)
    stage.showHead(35, 169, 32)
    stage.delay(5)
    stage.bottomTxt('우장 평원으로 급히 이동하다', True, False, False)
    stage.delay(5)
    stage.head(0).move(105, 32)
    stage.delay(5)
    stage.bottomTxt('그리고 제갈량를 추격했다.', True, False, True)
    stage.bgSound(12)
    stage.delay(3)
    stage.loadBg(2, 66)
    stage.draw()
    stage.showUnits([
        [
            187,
            5,
            56,
            1],
        [
            17,
            5,
            48,
            1]])
    stage.info('초선 첩자와 황번 첩자들이 함께 쉬두를 수색했다.')
    stage.setStageName('쉬두 거리 모퉁이')
    stage.unitsMove([
        [
            stage.unit(187),
            48,
            56,
            1],
        [
            stage.unit(17),
            48,
            48,
            1]])
    stage.unit(187).setAction(0)
    stage.delay(5)
    stage.unit(187).setAction(0, 0)
    stage.say('&187\n뜻밖에도, 쉬두를 지키는 책임자였던 쉬쉬는,\n그는 실제로 공명......와 공모했다')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n쉬쉬 씨가 반란을 저질렀는지는 아직 불분명하다.')
    stage.unit(187).setAction(0, 1)
    stage.say('&187\n쉬두는 이상 징후가 없었지만,\n하지만 쉬쉬의 집은 텅 비어 있었다.\n그 편지를 추가하세요......\n&17\n어쨌든 먼저 쉬쉬 씨를 찾아봅시다.')
    stage.unit(17).setAction(0, 1)
    stage.say('&17\n저택 상황을 보면,\n쉬쉬 씨는 멀리 가지 않은 것 같아요,\n그는 아직 쉬두 어딘가에 있을 것이다.')
    stage.showUnit(188, 5, 48, 1)
    stage.unit(188).move(40, 48, 1)
    stage.unit(188).setAction(0)
    stage.delay(3)
    stage.unit(187).setAction(0, 3)
    stage.unit(17).setAction(0, 3)
    stage.say('&188\n초선Miss, 쉬쉬를 못 찾겠어."\n그가 어디로 갔을까?')
    stage.delay(10)
    stage.showUnit(151, 95, 52, 3)
    stage.unit(151).move(76, 52, 3)
    stage.unit(151).setAction(0)
    stage.delay(5)
    stage.unit(187).setAction(0, 1)
    stage.say('&187\n아!\n&188\n저기 있는 사람...... 쉬쉬야!')
    stage.unitsMove([
        [
            stage.unit(17),
            66,
            48,
            1],
        [
            stage.unit(187),
            66,
            56,
            1],
        [
            stage.unit(188),
            58,
            48,
            1]])
    stage.unit(187).setAction(0)
    stage.unit(188).setAction(0)
    stage.say('&187\n쉬쉬!\n그래서 여기 숨어 있었구나.\n&188\n도망칠 수 없어!\n빨리 항복해!')
    stage.unit(151).setAction(6)
    stage.say('&151\n초선 아가씨가 쉬두에 있다고 들었어,\n그래서 여기 왔어.\n&151\n총리도 공명 눈치챘을 거야.')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n그 신사분이 진실을 아는 것 같아.\n쉬슈 씨, 진실을 말씀해 주시겠어요?')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(151).setAction(6)
    stage.say('&151\n좋아.\n초선Miss, 나는 그걸 숨겨서 공명을 속였어."')
    stage.unit(151).setAction(0)
    stage.say('&187\n뭐라고 했어!\n&188\n누가 그런 걸 믿겠어!')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n조급해하지 마세요.\n먼저 들어봅시다.')
    stage.unit(17).setAction(0, 1)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n쉬쉬 씨, 계속 말씀해 주세요!')
    stage.unit(17).setAction(0)
    stage.delay(5)
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n내 소박한 집에서 공명 편지를 읽어봤겠지?\n&151\n맞아요, 공명 제 조건에 동의했을 때,\n모토지는 마왕의 부활을 공명돕기로 동의했다.')
    stage.unit(17).setAction(6)
    stage.say('&17\n신사분이 그의 요청에 동의했나요!?\n왜 쉬쉬 씨 같은 사람이 ......지?\n이 상태가 정확히 무엇인가요......?')
    stage.unit(151).setAction(0, 3)
    stage.say('&151\n이 상태는......')
    stage.delay(5)
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n됐어, 지금 말할 필요 없어.')
    stage.unit(151).setAction(0, 3)
    stage.delay(3)
    stage.unit(151).setAction(6)
    stage.say('&151\n비록 잠시 공명의 요청에 동의했지만,\n하지만 결국 그는 그런 일을 할 수 없었다.\n어떻게 마왕을 부활시키는 걸 도울 수 있겠어?\n&17\n쉬슈 씨......\n&151\n초선 미스.\n쉬쉬는 이미 마왕의 부활을 막기 위한 계획을 세워두었다.\n&151\n그리고 이미 쉬두 동쪽에서,\n그는 제단을 세우고 기도하는 척했다.')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n...... 말하는 거야?')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n이제 악마의 기운이 쉬두 위 하늘을 가득 채웠다,\n바로 내가 기도하는 척하기 때문이야.\n&151\n공명 이 악마의 기운을 감지했다,\n자연은 기도가 완성되었음을 인식할 것입니다.\n&151\n사실, 나는 이 악마의 기운만 원한다\n마왕이 부활했을 때와 똑같은 마기였다.')
    stage.unit(17).setAction(6)
    stage.say('&17\n마왕의 부활을 위한 기도가 아직 안 드렸다는 말인가요?')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(151).setAction(0, 3)
    stage.say('&151\n네.\n&188\n그래서 그런 거야.\n다른 words공명 지금 집중하세요,\n이 성은 완전히 북쪽 제단에 놓였다.')
    stage.unit(151).setAction(6)
    stage.say('&151\n북쪽 제단은 무장 평원에 있습니다.')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(151).setAction(0, 2)
    stage.say('&151\n유감이지만 공명 이미 우장평원에 도착했어.\n&188\n그게 사실인가요!?')
    stage.unit(151).setAction(0, 3)
    stage.say('&151\n편지공명 말했듯이......\n제단은 우장원 아래에 세워져야 한다.')
    stage.unit(151).setAction(6)
    stage.say('&151\n지금 우장 평원으로 향하고 있어,\n제단 위치를 확인하세요.\n즉, 공명의 최종 목적지입니다.')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n이해했어.\n감사합니다, 쉬슈 씨.')
    stage.unit(17).setAction(0)
    stage.say('&187\n초선Miss, 그럼 바로 장안으로 가자,\n가후 씨께 이 사실을 알려주세요.\n&188\n좋아, 가자.')
    stage.unit(17).setAction(0, 2)
    stage.say('&17\n두 분 모두 수고해 주셔서 감사합니다.\n그럼 즉시 총리께 답변하겠습니다.')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setStageName('우장평원 조조 본진')
    stage.delay(3)
    stage.showUnit(23, 54, 22, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n주군, 가후가 돌아왔어.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(23).move(54, 52, 2)
    stage.delay(3)
    stage.unit(23).setAction(0, 3)
    stage.say('&23\n…… 오, 초선 여자야!\n돌아왔구나?')
    stage.unit(17).setAction(6)
    stage.say('&17\n네.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n아, 가후 수고 많으셨어요.\n이미 초선 모든 설명을 들었어요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n네. 그럼 즉시 군대를 보내 공명......를 전멸시켜야 합니까?')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n흠.\n이제 마왕이 부활하지 않을 것임을 알게 되었으니,\n공명 두려워할 게 없어!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n주군 여전히 부주의할 여유가 없다.\n&23\n사실 저는 이미 장안에서 몇 가지 문서를 찾았습니다,\n이 문서는 마왕이 부활하기 전 그의 능력을 기록하고 있다.\n&23\n문헌에 따르면 나무 조각상과 점토 인형 외에도,\n마왕은 특정 장소에서 죽은 자들을 조종할 수 있습니다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n마왕이 아무리 대단해도,\n우리는 그를 소멸시켜야 해. 장병들은 출발 준비해!')
    stage.unit(0).setAction(0)
    stage.unit(23).move(64, 52, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 56
    stage.setBattlePos([
        [
            4,
            6],
        [
            3,
            6],
        [
            5,
            6],
        [
            2,
            6],
        [
            4,
            5],
        [
            3,
            5],
        [
            5,
            5],
        [
            2,
            5],
        [
            4,
            4],
        [
            3,
            4],
        [
            5,
            4],
        [
            2,
            4],
        [
            4,
            3],
        [
            3,
            3],
        [
            5,
            3]])
    return False


def scene3():
    if stage.battleTest():
        stage.say('&0\n출발!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n제 잘못을 용서주군 부탁드립니다.\n공명장 평원의 경비병들이 매우 단단했지만,\n문약 전장의 상세한 지형을 알 수 없었다.\n&0\n그건 어쩔 수 없이 하는 일이야.\n&20\n지금까지 알려진 것은 전장이 강에 의해 두 부분으로 나뉘어 있다는 것뿐입니다.\n&0\n...... 강?\n그럼 물 싸움을 벌일지도 몰라?\n&20\n네.')
    if stage.unitClickTest(19):
        stage.say('&19\n쉬쉬는 제단이 지하에 있다고 지적했다,\n이곳으로 이어지는 비밀 통로가 분명 있을 거야.')
    if stage.unitClickTest(17):
        stage.say('&17\n쉬쉬 씨가 한 번 교환 조건을 요청한 적이 공명,\n그래서 나는 마왕의 부활을 위해 기도하기로 동의공명.\n&1\n뭐라고? 조건이 정확히 뭐야?\n&17\n쉬슈 씨는 ...... 공개가 불편하다고만 말했다\n&1\n흠.\n이 시점에서 걱정할 것은 아무것도 없었다.\n&0\n…… 쉬쉬의 조건은?')
    if stage.unitClickTest(3):
        stage.say('관우, 오장원을 가본 적이 있나? 죄송하지만, 관우는 가본 적이 없습니다. 왜냐하면 관우가 이전에는 계속 형주를 지키고 있었기 때문입니다. 아, 그런 거였군요. 하, 내가 물어보지 말았어야 했는데.')
    if stage.unitClickTest(1):
        stage.say('&1\n하늘이 이상하게 변하기 시작했다,\n아마도 폭풍이 다가오고 있을지도 모른다.')
    if stage.unitClickTest(23):
        stage.say('&23\n양평관에서 백호옥을 얻었다고 들었어!\n&0\n흠.\n이로써 네 개의 신옥석이 모두 모였다.\n&23\n백호옥은 풍수 수련자들이 사용합니다.\n&23\n기억하라, 그 신성한 힘은 모든 병력의 체력을 회복시킬 수 있다,\n또한 병사들의 비정상적인 상태 이상을 치유할 수도 있습니다.\n&1\n생각해보니, 이 기기가 꽤 잘 작동하네요!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
