# Source Generated with Decompyle++
# File: S_50.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(10,33)',
        '(11,33)',
        '(10,32)',
        '(11,32)'])
    stage.nearEvent([
        3,
        83,
        3,
        87])
    stage.nearEvent([
        0,
        76,
        19,
        77], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, 76, 0, 0, 1)
    stage.createEnemy(
        [{'id': 76, 'x': 10, 'y': 33, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 88, 'x': 11, 'y': 33, 'dir': 0, 'lv': 4, 'i': 1},
         {'id': 210, 'x': 10, 'y': 29, 'dir': 0, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 11, 'y': 29, 'dir': 0, 'lv': 0, 'i': 3},
         {'id': 212, 'x': 7, 'y': 32, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 213, 'x': 7, 'y': 33, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 214, 'x': 14, 'y': 32, 'dir': 1, 'lv': 0, 'i': 6},
         {'id': 215, 'x': 14, 'y': 33, 'dir': 1, 'lv': 0, 'i': 7},
         {'id': 234, 'x': 10, 'y': 30, 'dir': 0, 'lv': 0, 'i': 8},
         {'id': 235, 'x': 11, 'y': 30, 'dir': 0, 'lv': 0, 'i': 9},
         {'id': 236, 'x': 8, 'y': 32, 'dir': 3, 'lv': 0, 'i': 10},
         {'id': 237, 'x': 8, 'y': 33, 'dir': 3, 'lv': 0, 'i': 11},
         {'id': 238, 'x': 13, 'y': 32, 'dir': 1, 'lv': 0, 'i': 12},
         {'id': 239, 'x': 13, 'y': 33, 'dir': 1, 'lv': 0, 'i': 13},
         {'id': 298, 'x': 10, 'y': 32, 'dir': 0, 'lv': 0, 'i': 14},
         {'id': 299, 'x': 11, 'y': 32, 'dir': 0, 'lv': 0, 'i': 15},
         {'id': 85, 'x': 11, 'y': 25, 'dir': 0, 'lv': 6, 'i': 16},
         {'id': 82, 'x': 12, 'y': 25, 'dir': 0, 'lv': 4, 'i': 17},
         {'id': 83, 'x': 11, 'y': 26, 'dir': 0, 'lv': 4, 'i': 18},
         {'id': 92, 'x': 12, 'y': 26, 'dir': 0, 'lv': 4, 'i': 19},
         {'id': 79, 'x': 11, 'y': 27, 'dir': 0, 'lv': 6, 'i': 20},
         {'id': 78, 'x': 12, 'y': 27, 'dir': 0, 'lv': 6, 'i': 21},
         {'id': 258, 'x': 10, 'y': 25, 'dir': 0, 'lv': 0, 'i': 22},
         {'id': 216, 'x': 13, 'y': 25, 'dir': 0, 'lv': 0, 'i': 23},
         {'id': 282, 'x': 10, 'y': 26, 'dir': 0, 'lv': 0, 'i': 24},
         {'id': 240, 'x': 13, 'y': 26, 'dir': 0, 'lv': 0, 'i': 25},
         {'id': 84, 'x': 11, 'y': 22, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 26},
         {'id': 358, 'x': 10, 'y': 22, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 27},
         {'id': 359, 'x': 12, 'y': 22, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 28},
         {'id': 360, 'x': 13, 'y': 22, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 29},
         {'id': 361, 'x': 10, 'y': 23, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 30},
         {'id': 362, 'x': 11, 'y': 23, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 31},
         {'id': 363, 'x': 12, 'y': 23, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 32},
         {'id': 364, 'x': 13, 'y': 23, 'dir': 0, 'lv': -5, 'ai': 1, 'i': 33},
         {'id': 77, 'hide': 1, 'x': 2, 'y': 17, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 34},
         {'id': 86, 'hide': 1, 'x': 2, 'y': 18, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 35},
         {'id': 365, 'hide': 1, 'x': 2, 'y': 16, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 36},
         {'id': 366, 'hide': 1, 'x': 2, 'y': 19, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 37},
         {'id': 367, 'hide': 1, 'x': 1, 'y': 16, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 38},
         {'id': 368, 'hide': 1, 'x': 1, 'y': 17, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 39},
         {'id': 369, 'hide': 1, 'x': 1, 'y': 18, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 40},
         {'id': 370, 'hide': 1, 'x': 1, 'y': 19, 'dir': 1, 'lv': -5, 'ai': 1, 'i': 41},
         {'id': 81, 'hide': 1, 'x': 21, 'y': 17, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 42},
         {'id': 87, 'hide': 1, 'x': 21, 'y': 18, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 43},
         {'id': 371, 'hide': 1, 'x': 21, 'y': 16, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 44},
         {'id': 372, 'hide': 1, 'x': 21, 'y': 19, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 45},
         {'id': 373, 'hide': 1, 'x': 22, 'y': 16, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 46},
         {'id': 374, 'hide': 1, 'x': 22, 'y': 17, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 47},
         {'id': 375, 'hide': 1, 'x': 22, 'y': 18, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 48},
         {'id': 376, 'hide': 1, 'x': 22, 'y': 19, 'dir': 3, 'lv': -5, 'ai': 1, 'i': 49},
         {'id': 96, 'hide': 1, 'x': 1, 'y': 29, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 50},
         {'id': 318, 'hide': 1, 'x': 2, 'y': 28, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 51},
         {'id': 319, 'hide': 1, 'x': 2, 'y': 29, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 52},
         {'id': 320, 'hide': 1, 'x': 2, 'y': 30, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 310, 'hide': 1, 'x': 1, 'y': 28, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 311, 'hide': 1, 'x': 1, 'y': 30, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 80, 'hide': 1, 'x': 19, 'y': 27, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 56},
         {'id': 382, 'hide': 1, 'x': 18, 'y': 26, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 383, 'hide': 1, 'x': 18, 'y': 27, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 58},
         {'id': 384, 'hide': 1, 'x': 18, 'y': 28, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 59},
         {'id': 390, 'hide': 1, 'x': 19, 'y': 26, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 60},
         {'id': 391, 'hide': 1, 'x': 19, 'y': 28, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 61}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 12,
            'y': 12 },
        {
            'idx': 1,
            'x': 13,
            'y': 12 },
        {
            'idx': 2,
            'x': 11,
            'y': 12 },
        {
            'idx': 3,
            'x': 14,
            'y': 12 },
        {
            'idx': 4,
            'x': 10,
            'y': 12 },
        {
            'idx': 5,
            'x': 15,
            'y': 12 },
        {
            'idx': 6,
            'x': 12,
            'y': 11 },
        {
            'idx': 7,
            'x': 13,
            'y': 11 },
        {
            'idx': 8,
            'x': 11,
            'y': 11 },
        {
            'idx': 9,
            'x': 14,
            'y': 11 },
        {
            'idx': 10,
            'x': 10,
            'y': 11 },
        {
            'idx': 11,
            'x': 15,
            'y': 11 },
        {
            'idx': 12,
            'x': 12,
            'y': 8 },
        {
            'idx': 13,
            'x': 13,
            'y': 8 },
        {
            'idx': 14,
            'x': 12,
            'y': 7 }])
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(84, -1, 0, 23, 0, -1)
    stage.loadBg(50)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(6)
    stage.unit(79).setDir(stage.countDir(79, 76))
    stage.unit(78).setDir(stage.countDir(78, 76))
    stage.say('&79\n적은 맞은편 강둑에 배치되는 듯했다.\n&78\n치열한 전투가 될 거야.')
    stage.unit(76).setDir(stage.countDir(76, 88))
    stage.say('&76\n주유와 육손에 대한 소식 있나요?')
    stage.unit(88).setDir(stage.countDir(88, 76))
    stage.say('&88\n아니요, 지금까지는 아무 소식도 없어요.\n해군을 재건하는 데는 꽤 오랜 시간이 걸릴 가능성이 큽니다......')
    stage.unit(0).setDir(stage.countDir(0, 84))
    stage.say('&0\n우 나라 해군은 그렇게 강하지 않지?')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n아마도 대부분의 피해는 레드 클리프에서 일찍 잃었을 것이다.')
    stage.unit(19).setDir(3)
    stage.say('&19\n흠!?\n적의 증원군이 도착한 것 같았다.')
    stage.unit(365).show()
    stage.unit(77).show()
    stage.unit(86).show()
    stage.unit(366).show()
    stage.unit(367).show()
    stage.unit(368).show()
    stage.unit(369).show()
    stage.unit(370).show()
    stage.say('&86\n드디어 따라잡았어.')
    stage.unit(77).setDir(stage.countDir(77, 76))
    stage.say('&77\n주군, 방금 돌아왔어.')
    stage.unit(76).setDir(stage.countDir(76, 77))
    stage.say('&76\n공진아, 드디어 왔구나.\n즉시 방어 병력을 배치하세요.')
    stage.unit(83).setDir(stage.countDir(83, 77))
    stage.unit(92).setDir(stage.countDir(92, 77))
    stage.say('&83\n좋아, 이제 좀 더 안심할 수 있어.\n&92\n결국 해군은 우나라 군대의 핵심 세력이었다.\n해군이 있든 없든 전투력에 큰 차이를 만듭니다.')
    stage.unit(0).setDir(stage.countDir(0, 77))
    stage.say('&0\n손권 지원군이 도착한 것 같아.\n이제 어떻게 해야 하지? 계속 공격해야 할까?\n아니면 방어를 강화할까? 흠......')
    sel = stage.choice('그리고 일시적으로 변화를 관찰하는 것이다\n전력으로 공격하라', -1)
    if sel == 1:
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.say('&0\n일단 지켜보자.\n다시 적의 움직임을 관찰하고 싶습니다.')
        stage.unit(19).setDir(stage.countDir(19, 0))
        stage.say('&19\n주군 결단력이야!')
        stage.unit(84).setDir(stage.countDir(84, 0))
        stage.unit(85).setDir(stage.countDir(85, 0))
        stage.unit(82).setDir(stage.countDir(82, 0))
        stage.say('&84\n무슨 일이야? 왜 안 오는 거야?\n&85\n이것은 아군에게 매우 유익합니다.\n이 기회를 이용해 방어력을 강화하세요.\n&82\n그냥 육손가 돌아오길 기다리고 있어......')
        stage.unit(84).setAI(0)
        stage.unit(358).setAI(0)
        stage.unit(359).setAI(0)
        stage.unit(360).setAI(0)
        stage.unit(361).setAI(0)
        stage.unit(362).setAI(0)
        stage.unit(363).setAI(0)
        stage.unit(364).setAI(0)
        stage.unit(86).setAI(6, -1, 3, 24)
        stage.unit(77).setAI(6, -1, 3, 24)
        stage.unit(365).setAI(6, -1, 3, 24)
        stage.unit(366).setAI(6, -1, 3, 24)
        stage.unit(367).setAI(6, -1, 3, 24)
        stage.unit(368).setAI(6, -1, 3, 24)
        stage.unit(369).setAI(6, -1, 3, 24)
        stage.unit(370).setAI(6, -1, 3, 24)
        vars[6] = 1
    elif sel == 2:
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.unit(0).setAction(5)
        stage.say('&0\n군대 전체가 공격을 시작했다!\n사슴 울타리를 방어할 필요 없다,\n적의 주진지를 압박하고 점령했다!')
        stage.unit(0).setAction(0)
        stage.unit(19).setDir(stage.countDir(19, 0))
        stage.say('&19\n주군 적을 과소평가해서는 안 된다.\n전략 없이 용기를 갖는 게 위험하지 않나요?')
        stage.unit(0).setDir(stage.countDir(0, 19))
        stage.say('&0\n한눈에 그들이 전투에 돌진하고 있다는 것을 알 수 있었다.\n원래 해군은 오나라 군대의 주력이었다.\n현재 해군은 두려워할 것이 없습니다.\n&19\n네가 이렇게 말한 후에,\n적군 배를 조종하는 것이 확실히 조금 서툴렀다.\n주군 밍젠은 정말 존경스러워!')
        stage.unit(4, 1).move(9, 15, 2)
        stage.unit(2, 1).move(10, 15, 2)
        stage.unit(0, 1).move(11, 15, 2)
        stage.unit(1, 1).move(12, 15, 2)
        stage.unit(3, 1).move(13, 15, 2)
        stage.unit(5, 1).move(14, 15, 2)
        stage.unit(10, 1).move(9, 14, 2)
        stage.unit(8, 1).move(10, 14, 2)
        stage.unit(6, 1).move(11, 14, 2)
        stage.unit(7, 1).move(12, 14, 2)
        stage.unit(9, 1).move(13, 14, 2)
        stage.unit(11, 1).move(14, 14, 2)
        stage.unit(12, 1).move(12, 13, 2)
        stage.unit(13, 1).move(13, 13, 2)
        stage.unit(14, 1).move(12, 12, 2)
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&77\n(응? 조조 들켰어?\n결국 서군은 원래 산악군이었고,\n갑자기 유료 트롤이 되진 않을 거예요. )')
        stage.unit(77).setDir(stage.countDir(77, 84))
        stage.say('&77\n간 장군의 용기는 마치 날개를 펼치는 불사조 같았다.\n반역자 조는 분명 장군의 보호 아래 있을 것이다,\n맹렬한 불길이 그의 몸을 태웠고, 피가 흘러 수염과 입을 적셨다.')
        stage.unit(84).setDir(stage.countDir(84, 0))
        stage.unit(84).setAction(2)
        stage.say('&84\n주지사가 나를 죽이라고 하조조?\n네가 말하지 않아도, 그게 바로 내가 하려는 거야!')
        stage.unit(85).setDir(stage.countDir(85, 84))
        stage.unit(82).setDir(stage.countDir(82, 84))
        stage.say('&82\n간 장군, 모든 걸 믿고 있어.\n&85\n누군가 빠져나가면 나, 링통이 처리하겠다.\n간(General Gan)은 저격에만 집중하면 조조.')
        stage.unit(0).setDir(stage.countDir(0, 84))
        stage.say('&0\n그 시간이 가까워졌다.\n조심하세요.')
        stage.unit(4, 1).move(9, 18, 2)
        stage.unit(2, 1).move(10, 18, 2)
        stage.unit(0, 1).move(11, 18, 2)
        stage.unit(1, 1).move(12, 18, 2)
        stage.unit(3, 1).move(13, 18, 2)
        stage.unit(5, 1).move(14, 18, 2)
        stage.unit(10, 1).move(9, 17, 2)
        stage.unit(8, 1).move(10, 17, 2)
        stage.unit(6, 1).move(11, 17, 2)
        stage.unit(7, 1).move(12, 17, 2)
        stage.unit(9, 1).move(13, 17, 2)
        stage.unit(11, 1).move(14, 17, 2)
        stage.unit(12, 1).move(11, 16, 2)
        stage.unit(13, 1).move(12, 16, 2)
        stage.unit(14, 1).move(11, 15, 2)
        stage.unit(84).setAI(1)
        stage.unit(77).setAI(1)
        stage.unit(86).setAI(1)
        stage.unit(358).setAI(1)
        stage.unit(359).setAI(1)
        stage.unit(360).setAI(1)
        stage.unit(361).setAI(1)
        stage.unit(362).setAI(1)
        stage.unit(363).setAI(1)
        stage.unit(364).setAI(1)
        stage.unit(365).setAI(1)
        stage.unit(366).setAI(1)
        stage.unit(367).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        vars[7] = 1
        vars[2] = 1
    stage.bgSound(4)
    stage.setWinCondition('승리 조건\n1. 손권 패배.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('손권를 이겨라!')
    stage.unit(76).heightLight()
    stage.startOper()
    vars[550] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 2 and stage.round() == 2:
        stage.unit(371).show()
        stage.unit(81).show()
        stage.unit(87).show()
        stage.unit(372).show()
        stage.unit(373).show()
        stage.unit(374).show()
        stage.unit(375).show()
        stage.unit(376).show()
        stage.unit(81).setDir(stage.countDir(81, 76))
        stage.unit(87).setDir(stage.countDir(87, 0))
        stage.say('&81\n주군, 육손 도착했어!\n새로운 수자원 부대가 재편성되었습니다.\n&87\n흠, 조조 어디 있지?')
        if stage.totalRectUnit(0, 0, 15, 23, 39) == 0:
            stage.unit(81).setAI(6, -1, 14, 24)
            stage.unit(87).setAI(6, -1, 14, 24)
            stage.unit(371).setAI(6, -1, 14, 24)
            stage.unit(372).setAI(6, -1, 14, 24)
            stage.unit(373).setAI(6, -1, 14, 24)
            stage.unit(374).setAI(6, -1, 14, 24)
            stage.unit(375).setAI(6, -1, 14, 24)
            stage.unit(376).setAI(6, -1, 14, 24)
            stage.unit(86).setAI(6, -1, 10, 24)
            stage.unit(77).setAI(6, -1, 10, 24)
            stage.unit(365).setAI(6, -1, 10, 24)
            stage.unit(366).setAI(6, -1, 10, 24)
            stage.unit(367).setAI(6, -1, 10, 24)
            stage.unit(368).setAI(6, -1, 10, 24)
            stage.unit(369).setAI(6, -1, 10, 24)
            stage.unit(370).setAI(6, -1, 10, 24)
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 81))
                stage.say('&76\n육손, 장친, 드디어 왔구나!\n그는 즉시 방어를 강화해 조의 군대를 차단했다.')
            vars[6] = 0
        else:
            stage.unit(81).setAI(1)
            stage.unit(87).setAI(1)
            stage.unit(371).setAI(1)
            stage.unit(372).setAI(1)
            stage.unit(373).setAI(1)
            stage.unit(374).setAI(1)
            stage.unit(375).setAI(1)
            stage.unit(376).setAI(1)
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 81))
                stage.say('&76\n육손 장친은 즉시 조의 군대를 쓸어냈다.')
            vars[7] = 0
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 10, 33):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 11, 33):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 10, 32):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 11, 32):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[6] and stage.totalRectUnit(0, 0, 15, 23, 39) == 0:
        stage.unit(84).setAI(6, -1, 11, 24)
        stage.unit(358).setAI(6, -1, 11, 24)
        stage.unit(359).setAI(6, -1, 11, 24)
        stage.unit(360).setAI(6, -1, 11, 24)
        stage.unit(361).setAI(6, -1, 11, 24)
        stage.unit(362).setAI(6, -1, 11, 24)
        stage.unit(363).setAI(6, -1, 11, 24)
        stage.unit(364).setAI(6, -1, 11, 24)
        stage.unit(77).setAI(6, -1, 10, 24)
        stage.unit(86).setAI(6, -1, 10, 24)
        stage.unit(365).setAI(6, -1, 10, 24)
        stage.unit(366).setAI(6, -1, 10, 24)
        stage.unit(367).setAI(6, -1, 10, 24)
        stage.unit(368).setAI(6, -1, 10, 24)
        stage.unit(369).setAI(6, -1, 10, 24)
        stage.unit(370).setAI(6, -1, 10, 24)
        stage.unit(81).setAI(6, -1, 14, 24)
        stage.unit(87).setAI(6, -1, 14, 24)
        stage.unit(371).setAI(6, -1, 14, 24)
        stage.unit(372).setAI(6, -1, 14, 24)
        stage.unit(373).setAI(6, -1, 14, 24)
        stage.unit(374).setAI(6, -1, 14, 24)
        stage.unit(375).setAI(6, -1, 14, 24)
        stage.unit(376).setAI(6, -1, 14, 24)
        vars[7] = 0
        vars[6] = 1
    if not vars[7] and stage.totalRectUnit(0, 0, 15, 23, 39) >= 1:
        stage.unit(84).setAI(1)
        stage.unit(77).setAI(1)
        stage.unit(86).setAI(1)
        stage.unit(81).setAI(1)
        stage.unit(87).setAI(1)
        stage.unit(358).setAI(1)
        stage.unit(359).setAI(1)
        stage.unit(360).setAI(1)
        stage.unit(361).setAI(1)
        stage.unit(362).setAI(1)
        stage.unit(363).setAI(1)
        stage.unit(364).setAI(1)
        stage.unit(365).setAI(1)
        stage.unit(366).setAI(1)
        stage.unit(367).setAI(1)
        stage.unit(368).setAI(1)
        stage.unit(369).setAI(1)
        stage.unit(370).setAI(1)
        stage.unit(371).setAI(1)
        stage.unit(372).setAI(1)
        stage.unit(373).setAI(1)
        stage.unit(374).setAI(1)
        stage.unit(375).setAI(1)
        stage.unit(376).setAI(1)
        vars[6] = 0
        vars[7] = 1
    if vars[7] and not vars[8] and stage.totalRectUnit(2, 0, 0, 23, 24) < 4 and stage.curCamp() == 2:
        stage.say('&76\n우리 유료 트롤들에게 도대체 무슨 일이 벌어지고 있는 걸까요?\n오나라는 해전에서 우위를 잃었는가?')
        vars[8] = 1
        if not vars[2]:
            stage.resumeCtrl()
            stage.unit(76).setAction(5)
            stage.say('&76\n육상전은 조조의 군대에 대해 더욱 효과적이지 못한 것으로 보였다.\n전군을 후퇴시켜라!\n건예로 돌아가 재정비하라!')
            stage.unit(76).setAction(0)
            stage.unit(76).hide()
            if not vars[56]:
                stage.say('&79\n즉시 주군!\n즉시 건예로 후퇴하라!')
                stage.unit(79).hide()
            stage.setRectUnitHide(0, 0, 31, 39, 2)
            stage.say('&0\n자, 아군 이겼어!\n하지만 저는 공명이 걱정됩니다.\n지금 이 순간에도 경계를 늦출 수 없어!\n&0\n잠시 휴식을 취한 후, 군대는 즉시 건예로 진격했다.\n우리는 건예를 잡아 한 번에 오나라를 전멸시켜야 한다!')
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[650] = 1
            return True
        if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 9, 24, 14, 27):
            if not vars[59]:
                stage.unit(85).setDir(stage.countDir(85, 0))
                stage.unit(85).setAction(5)
                stage.say('&85\n절대 그들이 착륙하게 할 수 없어!\n여기서 막아야 해!')
                stage.unit(85).setAction(0)
            stage.unit(85).setAI(0)
            stage.unit(82).setAI(0)
            stage.unit(83).setAI(0)
            stage.unit(92).setAI(0)
            stage.unit(79).setAI(0)
            stage.unit(78).setAI(0)
            stage.unit(258).setAI(0)
            stage.unit(216).setAI(0)
            stage.unit(282).setAI(0)
            stage.unit(240).setAI(0)
            vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 27, 23, 39):
        stage.unit(76).setAction(5)
        stage.say('&76\n해군이 급히 출항했지만, 그들이 육지에 도착하자마자,\n원래는 서나라 산군 병력이 투입될 수 있었다.\n딩펑, 여몽, 빨리 와!')
        stage.unit(76).setAction(0)
        if not vars[57]:
            stage.unit(88).setDir(stage.countDir(88, 0))
            stage.say('&88\n우리는 조조의 공격을 막아야 한다.\n우린 더 이상 도망칠 곳이 없어.')
        stage.unit(96).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(310).show()
        stage.unit(311).show()
        stage.unit(96).setDir(stage.countDir(96, 0))
        stage.unit(96).setAction(5)
        stage.say('&96\n조조, 목숨을 걸어!')
        stage.unit(96).setAction(0)
        stage.unit(80).show()
        stage.unit(382).show()
        stage.unit(383).show()
        stage.unit(384).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(80).setDir(stage.countDir(80, 0))
        stage.unit(80).setAction(5)
        stage.say("&80\n야수 부대, 공격조조!\n내가 지휘하는 야수 부대는 평범한 군대가 아니다.\n정말 '호랑이에게 날개를 달아주는 것'과 같아요!")
        stage.unit(80).setAction(0)
        stage.setAI(0, 0, 23, 39, 2, 1)
        stage.unit(76).setAI(0)
        stage.unit(88).setAI(0)
        vars[6] = 1
        vars[7] = 1
        vars[8] = 1
        vars[31] = 1
    if not vars[40] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&76\n조조, 이렇게 병력을 철수시킬 수 있겠습니까?\n이전에 동오가 서 나라를 공격했는데,\n나는 웨이를 공격한 적이 없다.\n&0\n오나라 군대와 공명 불화를 꾸몄다,\n따라서 이 미스터리가 풀릴 때까지 나는 내 병력을 철수시킬 수 없다.\n&0\n게다가 너도 나도 혼란스러운 시대를 지배하고 싶어 하니까,\n조만간 싸워야 할 거야. 이제 알겠지!\n&76\n음, 지금은 내가 할 수 있는 게 없어.\n하지만 내 오국은 쉽게 당신에게 지지 않을 것입니다!')
        vars[40] = 1
    if not vars[41] and stage.isNear(19, 77, True):
        stage.unit(19).setDir(stage.countDir(19, 77))
        stage.unit(77).setDir(stage.countDir(77, 19))
        stage.say('&19\n주유,\n레드 클리프에 제단이 세워진 이유를 알아야 하지?\n&77\n네가 상황을 조사하고 싶어 하는 만큼 열심이니,\n더 일찍 공격조조 조언을 해주면 어공명 없을까요?\n&77\n제단은 공명에 의해 세워졌습니다.\n난 아무것도 몰라.\n&19\n이 시점에서 어떻게 그런 거짓말을 믿을 수 있겠는가?\nMoreover아군 곧 동우를 정복할 수 있을 것이다,\n승리의 앞에서 어떻게 병력을 후퇴시킬 이유가 있겠는가?\n&77\n정말 어리석었어......\n웨이우-우 라이벌 관계는 공명 손에 있었다!\n각하께서 어떻게 모를 수 있겠습니까?')
        vars[41] = 1
    if not vars[42] and stage.isNear(3, 83, False):
        stage.unit(3).setDir(stage.countDir(3, 83))
        stage.unit(83).setDir(stage.countDir(83, 3))
        stage.say('&3\n목숨을 내놓아!\n이번에는 도망칠 생각도 하지 마!\n&83\n아슬아슬했어, 관우!?')
        fight = stage.startFight(3, 83, 5)
        fight.showUnit(False, '(지금은 주저할 때가 아니야.\n관우를 죽이기만 하면 나도 영웅이 될 거야!)좋아, 결전이다!', 6)
        fight.showUnit(True, '응응응!', 9)
        fight.showStart()
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        stage.delay(20)
        fight.say(False, '와!\n역시나, 그들은 여전히 이기지 못했다......', True)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        fight.death(True)
        fight.setAction(True, 3)
        stage.delay(5)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '관평, 나는 네 아버지로서 복수했다!', True)
        fight.end()
        stage.unit(83).hide(2)
        stage.getItem(83, -1, True, 3)
        vars[60] = 1
        vars[42] = 1
    if not vars[43] and stage.isNear(3, 87, False):
        stage.unit(3).setDir(stage.countDir(3, 87))
        stage.unit(87).setDir(stage.countDir(87, 3))
        stage.say('&3\n장친, 드디어 찾았어!')
        fight = stage.startFight(3, 87, 5)
        fight.showUnit(True, '오늘은 관수오의 죽음을 복수하러 왔다!', 9)
        fight.showUnit(False, '정말 웃기네!\n싸우고 싶지 않아!', 4)
        fight.setAction(False, 4)
        fight.setAction(False, 1)
        fight.say(False, '다시 만날 때까지!', True)
        fight.setAction(False, 3)
        fight.attack2(True, 1, False)
        fight.say(False, '와!', True)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 1)
        fight.setAction(True, 3)
        stage.delay(5)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '관수오, 네 아버지가 너를 복수했어!', True)
        fight.setAction(True, 3)
        fight.setAction(True, 2)
        fight.setAction(True, 2)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.end()
        stage.unit(87).hide(2)
        vars[62] = 1
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.resumeCtrl()
        stage.unit(76).setAction(5)
        stage.say('&76\n음, 끝에 다다랐어!\n전군을 후퇴시켜라!\n재정비하기 위해 지안예로 돌아간다!')
        stage.unit(76).setAction(0)
        stage.unit(76).hide()
        if not vars[56]:
            stage.say('&79\n즉시 주군!\n즉시 건업으로 후퇴해 전투 준비를 하라!')
            stage.unit(79).hide()
        stage.setRectUnitHide(0, 0, 31, 39, 2)
        vars[50] = 1
        stage.say('&0\n자, 아군 이겼어!\n하지만 저는 공명이 걱정됩니다.\n지금 이 순간에도 경계를 늦출 수 없어!\n&0\n잠시 휴식을 취한 후, 군대는 즉시 건예로 진격했다.\n우리는 건예를 잡아 한 번에 오나라를 전멸시켜야 한다!')
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[650] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n새로운 수상 군대 훈련이 아직도 충분히 수행되지 않은 걸까요?\n그는 조나라 군대에게 패배할 줄은 전혀 예상하지 못했다......\n후퇴.')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n아-아, 안 돼!\n도망쳐!\n후퇴, 후퇴, 철수!')
        stage.unit(86).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n흠, 조나라 군대의 공세는 막을 수 없군.\n후퇴!')
        stage.unit(96).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n음음음음음!\n후퇴!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(77, 7, 0, 2):
        stage.say('&77\n뜻밖에도 위는 진심으로 동우를 파괴하려 했다,\nthis공명 자신에게 꽤 만족스러웠다.\n아, 정말 미운 참!\n&77\n하늘을 미워하고 내 운명을 저주할 수밖에 없어!\n왜 하늘은 사람들에게 이렇게 잔인한 장난을 치는 걸까......\n이 시점에서 그들이 할 수 있는 것은 최선을 다하고 운명에 맡기는 것뿐이었다. 후퇴!')
        stage.unit(77).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n좋지 않아!\n후퇴!')
        stage.unit(79).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n우린 더 이상 싸울 수 없어.\n건예로 후퇴하라!')
        stage.unit(88).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n나는 이미 무력했어......\n전투에서 정말 서투른 것 같아요.\n후퇴!')
        stage.unit(78).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n후회, 아직도 버티지 못했어.\n후퇴!')
        stage.unit(85).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n와!')
        stage.unit(83).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n쳇, 너무 창피해.\n후퇴!')
        stage.unit(92).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n여기서 죽게 되는 건가요?\n…… 말도 안 돼!')
        stage.unit(87).hide(2)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(80, 7, 0, 2):
        stage.say("&80\n조조의 군대는 마치 '초원의 불길'처럼 막을 수 없었다.\n후퇴!")
        stage.unit(80).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n쳇, 너무 부주의해!\n선택의 여지가 없어, 후퇴해!')
        stage.unit(84).hide(1)
        vars[64] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n자, 아군 이겼어!\n하지만 저는 공명이 걱정됩니다.\n지금 이 순간에도 경계를 늦출 수 없어!\n&0\n잠시 휴식을 취한 후, 군대는 즉시 건예로 진격했다.\n우리는 건예를 잡아 한 번에 오나라를 전멸시켜야 한다!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[650] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권군 앞에서 참패를 당하고 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
