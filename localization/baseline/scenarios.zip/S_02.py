# Source Generated with Decompyle++
# File: S_02.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(8,9)'])
    stage.nearEvent([
        3,
        119,
        33,
        119,
        32,
        119])
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 32,
            'x': 17,
            'y': 14,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 0 },
        {
            'id': 33,
            'x': 17,
            'y': 13,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 3,
            'x': 17,
            'y': 15,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 2 },
        {
            'id': 145,
            'x': 17,
            'y': 5,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 3 },
        {
            'id': 214,
            'x': 17,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 215,
            'x': 17,
            'y': 6,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 101,
            'x': 19,
            'y': 9,
            'dir': 3,
            'lv': 6,
            'i': 6 },
        {
            'id': 216,
            'x': 19,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'i': 7 },
        {
            'id': 217,
            'x': 19,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'i': 8 }])
    stage.createEnemy([
        {
            'id': 119,
            'x': 8,
            'y': 9,
            'dir': 1,
            'lv': 6,
            'i': 0 },
        {
            'id': 210,
            'x': 7,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'i': 1 },
        {
            'id': 211,
            'x': 7,
            'y': 9,
            'dir': 1,
            'lv': 0,
            'i': 2 },
        {
            'id': 212,
            'x': 7,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'i': 3 },
        {
            'id': 213,
            'x': 7,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 4 },
        {
            'id': 258,
            'x': 9,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'i': 5 },
        {
            'id': 259,
            'x': 9,
            'y': 9,
            'dir': 1,
            'lv': 0,
            'i': 6 },
        {
            'id': 260,
            'x': 9,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'i': 7 },
        {
            'id': 261,
            'x': 9,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 8 },
        {
            'id': 234,
            'x': 8,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'i': 9 },
        {
            'id': 235,
            'x': 8,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'i': 10 },
        {
            'id': 236,
            'x': 8,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'i': 11 },
        {
            'id': 237,
            'x': 8,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 12 },
        {
            'id': 238,
            'x': 8,
            'y': 12,
            'dir': 1,
            'lv': 0,
            'i': 13 },
        {
            'id': 127,
            'x': 2,
            'y': 9,
            'dir': 1,
            'lv': 4,
            'i': 14 },
        {
            'id': 132,
            'x': 2,
            'y': 10,
            'dir': 1,
            'lv': 4,
            'i': 15 },
        {
            'id': 128,
            'x': 4,
            'y': 9,
            'dir': 1,
            'lv': 4,
            'ai': 0,
            'i': 16 },
        {
            'id': 133,
            'x': 4,
            'y': 10,
            'dir': 1,
            'lv': 4,
            'ai': 0,
            'i': 17 },
        {
            'id': 239,
            'x': 5,
            'y': 6,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 18 },
        {
            'id': 240,
            'x': 5,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 19 },
        {
            'id': 241,
            'x': 5,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 20 },
        {
            'id': 242,
            'x': 5,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 21 },
        {
            'id': 243,
            'x': 5,
            'y': 13,
            'dir': 1,
            'lv': 0,
            'ai': 0,
            'i': 22 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 17,
            'y': 9,
            'dir': 3 },
        {
            'idx': 1,
            'x': 16,
            'y': 8,
            'dir': 3 },
        {
            'idx': 2,
            'x': 16,
            'y': 11,
            'dir': 3 },
        {
            'idx': 3,
            'x': 16,
            'y': 9,
            'dir': 3 },
        {
            'idx': 4,
            'x': 16,
            'y': 10,
            'dir': 3 },
        {
            'idx': 5,
            'x': 17,
            'y': 8,
            'dir': 3 },
        {
            'idx': 6,
            'x': 17,
            'y': 11,
            'dir': 3 },
        {
            'idx': 7,
            'dir': 1 },
        {
            'idx': 8,
            'dir': 1 },
        {
            'idx': 9,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(101, -1, 0, -1, 0, 4)
    stage.loadBg(2)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(3)
    stage.unit(119).setAction(5)
    stage.say('&119\n그는 전 군대에게 연합군을 깊숙이 유인한 뒤 공격하라고 명령했다.\n명령 없이는 허락 없이 공격할 수 없다.')
    stage.unit(119).setAction(0)
    stage.unit(133).setDir(stage.countDir(133, 127))
    stage.unit(132).setDir(stage.countDir(132, 127))
    stage.unit(128).setDir(stage.countDir(128, 127))
    stage.say('&133\n주군, 루 장군이 정말 혼자서 괜찮은가?\n우리도 싸움에 뛰어들까?\n&127\n세상에 아무도 봉선를 이긴 적이 없다.\n&132\n주군 심도 있는 계획과 광범위한 계획,\n리루는 그를 매우 존경했다.\n&128\n(흥, 정말 멍청하네! )')
    stage.unit(133).setDir(1)
    stage.unit(132).setDir(1)
    stage.unit(128).setDir(1)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[502] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 1:
        stage.say('&32\n동탁 바로 눈앞에 있습니다, 모든 생명을 위해서,\n우리는 동탁를 제거해야 합니다.\n&3\n형제여, 하지만 먼저 여포를 물리쳐야 해.')
        stage.unit(33).setAction(6)
        stage.say('&33\n내게 맡겨, 한 번에 끝내는 걸 봐.')
        stage.unit(33).setAction(0)
        stage.unit(3).setDir(stage.countDir(3, 33))
        stage.say('&3\n셋째 형은 다루기 쉽지 않아.\n&32\nHowever여포 분명히 적군의 주력 세력이다,\n그를 물리친다면,\n승리는 우리 동맹군의 몫이다.\n&3\n알겠습니다, 그러니 힘을 집중해 여포 공격하겠습니다.\n&33\n흥, 막 도전하려던 참이었어.\n&32\n어쨌든, 먼저 여포 찾아보자.')
        stage.unit(3).setDir(3)
        vars[11] = 1
    if not vars[12] and not vars[50] and not vars[58] and stage.curCamp() == 0 and stage.round() >= 4 and stage.totalUnit(0) < 7 and stage.totalRectUnit(1, 19, 8, 19, 10) == 3:
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.say('&101\n상황이 좋지 않아 보여. 나도 전투에 나갈까......?')
        stage.unit(0).setDir(stage.countDir(0, 101))
        stage.say('&0\n흠!? 원소 끼어들래?\n&0\n우리 조군이 전장에서 이름을 알리지 못한다면,\n그게 무슨 의미가 있지?\n그가 원소를 속여 자신의 자리를 지키게 해야 할까?')
        sel = stage.choice('원소와 함께 싸우세요\n원소 만류하세요', -1)
        if sel == 1:
            stage.say('(어쩔 수 없어. 만약 지면 모든 게 끝장이야.) 원소, 너는 뒤에서 지원해라.\n응, 너는 눈앞의 적들에게만 집중하고, 빠져나가는 자들은 내가 처리하겠다.')
            stage.setAI(19, 8, 19, 10, 4, 1)
            vars[33] = 1
        elif sel == 2:
            stage.say('&0\n위안 장군, 직접 군대를 이끌어서는 안 됩니다!\n지휘관은 전체 군대를 지휘할 수 있도록 대형을 갖추고 배치되어야 합니다.\n&101\n맞아. 좋아, 이건 네게 맡길게,\n멋진 싸움을 해야 해.')
        vars[12] = 1
    if not vars[20] and stage.isInPos(1025, 8, 9):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[6] and stage.curCamp() == 2 and stage.totalRectUnit(4, 7, 0, 13, 19) >= 5:
        stage.unit(119).setAction(6)
        stage.say('&119\n좋아, 전면 공격—단 한 명도 도망치지 마라!')
        stage.unit(119).setAction(0)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(261).setAI(1)
        vars[6] = 1
    if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 7, 0, 10, 19):
        stage.say('&119\n나도 공격해야겠어.\n&119\n연합군 중 누가 감히 나와 싸우려 한다면,\n먼저 저를 만날 수 있다면,\n평생의 영광이 될 거예요!')
        stage.unit(119).setAI(1)
        vars[30] = 1
    if not vars[31] and not vars[50] and not vars[51] and not vars[52] and stage.isInRect(1025, 7, 0, 7, 19):
        stage.unit(0).setDir(stage.countDir(0, 127))
        stage.unit(127).setDir(stage.countDir(127, 0))
        stage.say('&0\n내 말 들려? 동탁!\n군대를 이끌 수도 없고,\n어떻게 감히 재상 칭호를 거짓으로 주장할 수 있지? 말도 안 돼!\n&0\n빨리 나와, 겁쟁이처럼 굴지 마.\n하하하!\n&127\n젠장조조! 내가 직접 널 이기게 해줘,\n아직도 무례하게 말할 용기가 있는지 보자!')
        stage.unit(132).setDir(stage.countDir(132, 127))
        stage.unit(127).setDir(stage.countDir(127, 132))
        stage.say('&132\n절대 아니야, 귀족 신분주군,\n도적 군대를 위해 손을 더럽히지 않겠어?\n&127\n맞아. 명령을 내려라: 저 사람의 목을 가져가야 한다.\n&132\n복종해.')
        stage.unit(132).setDir(1)
        stage.unit(127).setDir(1)
        vars[31] = 1
    if not vars[32] and stage.curCamp() == 1 and stage.isInRect(1025, 7, 0, 13, 19):
        stage.unit(32).setAction(6)
        stage.say('&32\n때가 됐어. 우리도 공격하자.')
        stage.unit(32).setAction(0)
        stage.unit(32).setAI(3, 119, 0, 0)
        stage.unit(33).setAI(3, 119, 0, 0)
        stage.unit(3).setAI(3, 119, 0, 0)
        stage.unit(145).setAction(6)
        stage.say('&145\n우리도 앞으로 나아가자,\n젊은이들보다 뒤처져서는 안 됩니다.')
        stage.unit(145).setAction(0)
        stage.unit(145).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        vars[32] = 1
    if not vars[33] and stage.isInRect(1026, 16, 0, 19, 19):
        stage.say('&101\n적이 오고 있고, 나는 지휘관으로서 명령할 것이다.\n어서, 저 유닛과 맞서.')
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        vars[33] = 1
    if not vars[40] and stage.isNear(3, 119, True):
        stage.unit(3).setDir(stage.countDir(3, 119))
        stage.unit(119).setDir(stage.countDir(119, 3))
        stage.say('&3\n너 루 봉선 맞지? 잘 보여줘.\n&119\n흥, 꽤 실력이 있네.\n좋아, 내가 한 방 가르쳐 줄게!')
        fight = stage.startFight(3, 119, 5)
        fight.showUnit(True, '나는 유비의 남동생, 관운장, 여포,\n네 무술이 세상에서 독보적이라고 들었어,\n도전하러 왔관우.', 9)
        fight.showUnit(False, '흥미롭네요, 저도 주저하지 않겠습니다. 덤벼라!', 8)
        fight.showStart()
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        stage.delay(5)
        fight.setAction(False, 8)
        fight.say(False, '용감하네, 내 움직임을 정말 견딜 수 있겠어? 이거 봐!', True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.say(True, '죽여라...!', False)
        fight.attack1(True, 2, True)
        fight.say(False, '이봐!', True)
        stage.delay(10)
        fight.setAction(False, 8)
        fight.say(False, '뭐라고! 정말 흥미롭네!\n이런 영웅을 예상하지 못했어요—정말 짜릿해요!', True)
        fight.setAction(True, 0)
        fight.say(True, '(역시 대단해. 여봉선은 정말 신귀 같은 용맹함이야.)', True)
        fight.end()
        vars[40] = 1
    if not vars[41] and stage.isNear(33, 119, True):
        stage.unit(33).setDir(stage.countDir(33, 119))
        stage.unit(119).setDir(stage.countDir(119, 33))
        stage.say('&33\n장이이드장비, 저 여포!\n죽을 때까지 싸워라!\n&119\n참 대담하군! 싸우자!')
        fight = stage.startFight(33, 119, 5)
        fight.showUnit(True, '연의 장이더가 왔다! 여포,\n오늘부터 나는 무적이다!', 10)
        fight.showUnit(False, '지금 이 말 하면 후회할 거야!', 8)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '죽여라...!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 4, False)
        stage.delay(10)
        fight.setAction(True, 2)
        stage.delay(5)
        fight.say(True, '아니, 사라졌어......!?', True)
        fight.setAction(False, 8)
        fight.say(False, '하하하! 너무 느려! 너무 느려!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 9)
        fight.say(True, '으악! 이 자식아! 배짱 있으면 도망가지 마!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 4, False)
        stage.delay(5)
        fight.setAction(True, 2)
        fight.say(True, '뭐라고!? 또 사라졌어, 어떻게 ...... 거지?', False)
        fight.setAction(False, 8)
        fight.say(False, '정말 가능해. 꺼져!', False)
        fight.setAction(False, 2)
        fight.setAction(True, 1)
        fight.attack1(False, 1, False)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '음, 아!\n화났어!\n정말 화가 나요!', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 2, True)
        fight.say(False, '(음, 엄청난 괴력이다!\n내 팔이 다 저릿저릿해!)', True)
        fight.setAction(True, 10)
        fight.say(True, '무슨 일이야, 여포! 결과는 아직 알 수 없어!', True)
        fight.setAction(False, 0)
        fight.say(False, '나 바쁘지 않아!\n더 이상 너랑 놀지 않을 거야!', True)
        fight.setAction(False, 1)
        fight.say(False, '걱정 마, 아직 우리와 해결할 기회가 있어!\n너도 그렇게 대단하진 않지만, 입술이 꽤 날카롭네.', True)
        fight.setAction(False, 2)
        fight.setAction(False, 13)
        fight.setAction(True, 2)
        fight.say(True, '뭐라고!? 여포!\n이봐! 멈춰! 돌아와!', True)
        fight.setAction(True, 9)
        fight.say(True, '젠장, 이 건방진 녀석!\n그가 아는 건 말뿐이었고, 실제로 도망쳤다.', True)
        fight.end()
        vars[41] = 1
    if not vars[42] and stage.isNear(32, 119, True):
        stage.unit(32).setDir(stage.countDir(32, 119))
        stage.unit(119).setDir(stage.countDir(119, 32))
        stage.say('&32\n당신은 전국에 명성이 높은 장군입니다,\n그런데도 너는 동탁 같은 사람을 섬기고 있어,\n수치심을 모르겠어?\n&119\n여포Since 나는 장군이니 주인의 일에 간섭하지 않을 것이다."\n난 내 무대에서만 싸우고 싶어!\n유비, 그게 우리가 다른 점이야.\n&32\n……. (장군도 사람이다......\n하지만 이 사람은 더 큰 선을 이해하지 못해. )\n&119\n말 다 했어? 그럼 너랑 해결하자!')
        fight = stage.startFight(32, 119, 5)
        fight.showUnit(True, '여포, 너는 그런 실력을 가졌어,\n왜 전 세계 사람들을 위해 좋은 일을 하지 않겠습니까!', 9)
        fight.showUnit(False, '유비, 그만 말해!\n장군으로서 자신의 가치를 실현할 수 있는 것은 전투를 통해서뿐이다.', 8)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '다른 방법이 없었다, 싸워야 했다!', True)
        fight.setAction(False, 0)
        fight.say(False, '아, 제발!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 2, True)
        fight.say(True, '젠장!', False)
        fight.setAction(False, 2)
        fight.attack1(True, 2, True)
        stage.delay(10)
        fight.setAction(True, 12)
        fight.say(True, '아, 전화해.......', True)
        fight.setAction(False, 0)
        fight.say(False, '(음음! 이 친구, 생각보다 훨씬 강해! 만만하게 볼 수 없어!)', True)
        stage.delay(10)
        fight.setAction(True, 6)
        fight.say(True, '자, 어서 여포! 몇 번 더 기술 교환하자!', True)
        fight.setAction(False, 6)
        fight.say(False, '유비, 나는 이미 네 실력을 경험했다,\n다음엔 너랑 경쟁할게.', True)
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        fight.setAction(False, 2)
        fight.setAction(False, 13)
        stage.delay(10)
        fight.setAction(True, 0)
        stage.delay(5)
        fight.say(True, '이 녀석은 자기 무술로만 ......는 법을 알고 있어.', True)
        fight.end()
        vars[42] = 1
    if not vars[40] and stage.isNear(3, 119, False):
        stage.unit(3).setDir(stage.countDir(3, 119))
        stage.unit(119).setDir(stage.countDir(119, 3))
        stage.say('&3\n너 루 봉선 맞지? 잘 보여줘.\n&119\n흥, 꽤 실력이 있네.\n좋아, 내가 한 방 가르쳐 줄게!')
        fight = stage.startFight(3, 119, 5)
        fight.showUnit(True, '나는 유비의 남동생, 관운장, 여포,\n네 무술이 세상에서 독보적이라고 들었어,\n도전하러 왔관우.', 9)
        fight.showUnit(False, '흥미롭네요, 저도 주저하지 않겠습니다. 덤벼라!', 8)
        fight.showStart()
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(False, 1, False)
        stage.delay(5)
        fight.setAction(False, 8)
        fight.say(False, '용감하네, 내 움직임을 정말 견딜 수 있겠어? 이거 봐!', True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.say(True, '죽여라...!', False)
        fight.attack1(True, 2, True)
        fight.say(False, '이봐!', True)
        stage.delay(10)
        fight.setAction(False, 8)
        fight.say(False, '뭐라고! 정말 흥미롭네!\n이런 영웅을 예상하지 못했어요—정말 짜릿해요!', True)
        fight.setAction(True, 0)
        fight.say(True, '(역시 대단해. 여봉선은 정말 신귀 같은 용맹함이야.)', True)
        fight.end()
        vars[40] = 1
    if not vars[41] and stage.isNear(33, 119, False):
        stage.unit(33).setDir(stage.countDir(33, 119))
        stage.unit(119).setDir(stage.countDir(119, 33))
        stage.say('&33\n장이이드장비, 저 여포!\n죽을 때까지 싸워라!\n&119\n참 대담하군! 싸우자!')
        fight = stage.startFight(33, 119, 5)
        fight.showUnit(True, '연의 장이더가 왔다! 여포,\n오늘부터 나는 무적이다!', 10)
        fight.showUnit(False, '지금 이 말 하면 후회할 거야!', 8)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '죽여라...!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 4, False)
        stage.delay(10)
        fight.setAction(True, 2)
        stage.delay(5)
        fight.say(True, '아니, 사라졌어......!?', True)
        fight.setAction(False, 8)
        fight.say(False, '하하하! 너무 느려! 너무 느려!', True)
        fight.setAction(True, 1)
        fight.setAction(True, 9)
        fight.say(True, '으악! 이 자식아! 배짱 있으면 도망가지 마!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 4, False)
        stage.delay(5)
        fight.setAction(True, 2)
        fight.say(True, '뭐라고!? 또 사라졌어, 어떻게 ...... 거지?', False)
        fight.setAction(False, 8)
        fight.say(False, '정말 가능해. 꺼져!', False)
        fight.setAction(False, 2)
        fight.setAction(True, 1)
        fight.attack1(False, 1, False)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '음, 아!\n화났어!\n정말 화가 나요!', True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 2, True)
        fight.say(False, '(음, 엄청난 괴력이다!\n내 팔이 다 저릿저릿해!)', True)
        fight.setAction(True, 10)
        fight.say(True, '무슨 일이야, 여포! 결과는 아직 알 수 없어!', True)
        fight.setAction(False, 0)
        fight.say(False, '나 바쁘지 않아!\n더 이상 너랑 놀지 않을 거야!', True)
        fight.setAction(False, 1)
        fight.say(False, '걱정 마, 아직 우리와 해결할 기회가 있어!\n너도 그렇게 대단하진 않지만, 입술이 꽤 날카롭네.', True)
        fight.setAction(False, 2)
        fight.setAction(False, 13)
        fight.setAction(True, 2)
        fight.say(True, '뭐라고!? 여포!\n이봐! 멈춰! 돌아와!', True)
        fight.setAction(True, 9)
        fight.say(True, '젠장, 이 건방진 녀석!\n그가 아는 건 말뿐이었고, 실제로 도망쳤다.', True)
        fight.end()
        vars[41] = 1
    if not vars[42] and stage.isNear(32, 119, False):
        stage.unit(32).setDir(stage.countDir(32, 119))
        stage.unit(119).setDir(stage.countDir(119, 32))
        stage.say('&32\n당신은 전국에 명성이 높은 장군입니다,\n그런데도 너는 동탁 같은 사람을 섬기고 있어,\n수치심을 모르겠어?\n&119\n여포Since 나는 장군이니 주인의 일에 간섭하지 않을 것이다."\n난 내 무대에서만 싸우고 싶어!\n유비, 그게 우리가 다른 점이야.\n&32\n……. (장군도 사람이다......\n하지만 이 사람은 더 큰 선을 이해하지 못해. )\n&119\n말 다 했어? 그럼 너랑 해결하자!')
        fight = stage.startFight(32, 119, 5)
        fight.showUnit(True, '여포, 너는 그런 실력을 가졌어,\n왜 전 세계 사람들을 위해 좋은 일을 하지 않겠습니까!', 9)
        fight.showUnit(False, '유비, 그만 말해!\n장군으로서 자신의 가치를 실현할 수 있는 것은 전투를 통해서뿐이다.', 8)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '다른 방법이 없었다, 싸워야 했다!', True)
        fight.setAction(False, 0)
        fight.say(False, '아, 제발!', True)
        fight.setAction(True, 2)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 2, True)
        fight.say(True, '젠장!', False)
        fight.setAction(False, 2)
        fight.attack1(True, 2, True)
        stage.delay(10)
        fight.setAction(True, 12)
        fight.say(True, '아, 전화해.......', True)
        fight.setAction(False, 0)
        fight.say(False, '(음음! 이 친구, 생각보다 훨씬 강해! 만만하게 볼 수 없어!)', True)
        stage.delay(10)
        fight.setAction(True, 6)
        fight.say(True, '자, 어서 여포! 몇 번 더 기술 교환하자!', True)
        fight.setAction(False, 6)
        fight.say(False, '유비, 나는 이미 네 실력을 경험했다,\n다음엔 너랑 경쟁할게.', True)
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        fight.setAction(False, 2)
        fight.setAction(False, 13)
        stage.delay(10)
        fight.setAction(True, 0)
        stage.delay(5)
        fight.say(True, '이 녀석은 자기 무술로만 ......는 법을 알고 있어.', True)
        fight.end()
        vars[42] = 1
    if vars[40] and vars[41] and vars[42] and vars[1002] and not vars[70]:
        stage.unit(119).setAction(9)
        stage.say('&119\n이 세 사람은 약간의 능력을 가졌지만 무력했다......')
        stage.setUnitStatus([
            {
                'status': 0,
                'lift': 0,
                'unit': stage.unit(119) },
            {
                'status': 1,
                'lift': 0,
                'hStatus': [
                    9],
                'unit': stage.unit(119) }])
        vars[70] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n젠장... 진짜로 질 줄은 몰랐어...\n후퇴, 후퇴.')
        stage.unit(119).hide(1)
        if not vars[51]:
            stage.say('&127\n뭐, 도망여포 거야?\n연합군이 정말 그렇게 강력해!\n&127\n이 시점에서 그는 할 수 있는 것이 없었다,\n그들은 연합군이 포기하기를 기다리며 호라오 고개를 죽음까지 지킬 수밖에 없었.......')
            stage.setRectUnitHide(0, 0, 6, 19, 5)
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 7,
                'y1': 0,
                'x2': 19,
                'y2': 19,
                'camp': 5 }])
        if stage.totalRectUnit(2, 7, 0, 19, 19) == 0:
            stage.resumeCtrl()
            stage.say('&0\n우리는 이미 도시 밖의 적을 전멸시켰다!')
            stage.info('연합군이 동탁를 격파했다,\n하지만 동탁 후라오 고개를 죽을 때까지 지키려 합니다.\n연합군은 당분간 버티지 못했다,\n그들은 일시적으로 후퇴하고 다시 싸울 힘을 모을 수밖에 없었다.')
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[602] = 1
            return True
        stage.unit(32).setAI(1)
        stage.unit(33).setAI(1)
        stage.unit(3).setAI(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(127, 7, 0, 2):
        stage.say('&127\n젠장, 이 연합군 놈들!\n이 원한은 반드시 복수해야 한다.\n후퇴! 후퇴!')
        stage.setRectUnitHide(0, 0, 6, 19, 5)
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 7,
                'y1': 0,
                'x2': 19,
                'y2': 19,
                'camp': 5 }])
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(132, 7, 0, 2):
        stage.say('&132\n이건 희망이 없어, 빨리 도망쳐야 해!')
        stage.unit(132).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(128, 7, 0, 2):
        stage.say('&128\n어떻게, 어떻게 그럴 수 있......\n와!')
        stage.unit(128).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(133, 7, 0, 2):
        stage.say('&133\n잘못된 주인에게 가면 이런 일이 생기는 건가요?\n음.')
        stage.unit(133).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n젠장, 곧 죽동탁 ......!\n지금 죽을 수 없어—후퇴해!')
        stage.unit(32).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n두고 보자—조만간 이 원한은 반드시 복수될 것이다!')
        stage.unit(33).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n동탁 바로 앞에 있어...... 정말 받을 수 없어.\n후퇴!')
        stage.unit(3).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(101, 7, 0, 2):
        stage.say('&101\n난 죽을 수 없어.\n안타깝지만, 그들은 주된 사업을 철회해야 합니다.\n조조, 나머지는 네게 맡길게.')
        stage.unit(101).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(145, 7, 0, 2):
        stage.say('&145\n음, 정말 안타깝네요...\n내가 10살만 더 젊었더라면 ....... 잃지 않았을 거야')
        stage.unit(145).hide(1)
        vars[59] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n우리는 이미 도시 밖의 적을 전멸시켰다!')
        stage.info('연합군은 동탁을 격파했지만 동탁 버텨냈다\n후라오 고개는 연합군이 즉시 점령하지 못한 실패였다.\n그들은 일시적으로 후퇴하고 또 다른 전투를 준비할 수밖에 없었다.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[602] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 동탁에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
