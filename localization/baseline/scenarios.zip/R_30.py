# Source Generated with Decompyle++
# File: R_30.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            0,
            53,
            29,
            2],
        [
            1,
            68,
            48,
            3],
        [
            2,
            68,
            54,
            3],
        [
            15,
            68,
            60,
            3],
        [
            5,
            68,
            66,
            3],
        [
            20,
            38,
            48,
            1],
        [
            23,
            38,
            54,
            1],
        [
            24,
            38,
            60,
            1],
        [
            21,
            38,
            66,
            1]])
    if vars[724]:
        stage.showUnit(22, 38, 72, 1)
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('적을 무찌르는 장료')
    stage.setStageName('난 카운티 조조 관저')
    if vars[724] and vars[727]:
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('&0\n젠장, 그들은 동우를 심각하게 과소평가했다!')
        stage.unit(20).setAction(6)
        stage.say('&20\n아군 손실은 상상보다 더 심각해 보입니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(22).setAction(6)
        stage.say('&22\n우리는 쉬두로 돌아가 재정비해야 합니다.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&0\n다른 방법이 없는 것 같아요.')
        stage.say('&0\n원원!')
        stage.unit(2).setAction(6)
        stage.say('&2\n존재한다.\n&0\n너는 악진와 이전를 합페이에 머무르게 할 것이다.\n&0\n허페이는 동우와 쉬두를 연결하는 핵심 허브입니다.\n무슨 일이 있어도 버텨야 해.\n&2\n네.\n분명히 이해하겠습니다.')
        stage.unit(2).setAction(0)
        stage.say('&0\n다른 장군들은 나와 함께 쉬두로 돌아갔다.')
    if vars[728] and not vars[724]:
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('&0\n젠장, 주유 녀석!\n그가 아니었다면,\n이제 동우는 이미 내 땅이다.')
        stage.unit(20).setAction(6)
        stage.say('&20\n아군 손실은 상상보다 더 심각해 보입니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n우리는 쉬두로 돌아가 재정비해야 합니다.')
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n다른 방법이 없는 것 같아요.')
        stage.say('&0\n원원!')
        stage.unit(2).setAction(6)
        stage.say('&2\n존재한다.\n&0\n너는 악진와 이전를 합페이에 머무르게 할 것이다.\n&0\n허페이는 동우와 쉬두를 연결하는 핵심 허브입니다.\n무슨 일이 있어도 버텨야 해.\n&2\n네.\n분명히 이해하겠습니다.')
        stage.unit(2).setAction(0)
        stage.say('&0\n다른 장군들은 나와 함께 쉬두로 돌아갔다.')
    if vars[724] and not vars[727]:
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('&0\n젠장! 그들은 동우를 과소평가했어.\n그렇지 않았다면 이런 참담한 패배를 겪지 않았을 것이다!')
        stage.unit(20).setAction(6)
        stage.say('&20\n아군 손실은 상상보다 더 심각해 보입니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(22).setAction(6)
        stage.say('&22\n우리는 쉬두로 돌아가 재정비해야 합니다.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('&0\n다른 방법이 없는 것 같아요.')
        stage.say('&0\n원원!')
        stage.unit(2).setAction(6)
        stage.say('&2\n존재한다.\n&0\n너는 악진와 이전를 합페이에 머무르게 할 것이다.\n&0\n허페이는 동우와 쉬두를 연결하는 핵심 허브입니다.\n무슨 일이 있어도 버텨야 해.\n&2\n네.\n분명히 이해하겠습니다.')
        stage.unit(2).setAction(0)
        stage.say('&0\n다른 장군들은 나와 함께 쉬두로 돌아갔다.')
    if not vars[724] and not vars[728]:
        model.setFace(2)
        stage.unit(0).setAction(2)
        stage.say('&0\n얼마나 증오스러운가—펑샤오가 아직 살아 있다면,\n어떻게 나, 조가 이런 참담한 패배를 겪을 수 있겠는가?')
        stage.unit(20).setAction(6)
        stage.say('&20\n아군 손실은 상상보다 더 심각해 보입니다.')
        stage.unit(20).setAction(0)
        stage.delay(3)
        stage.unit(21).setAction(6)
        stage.say('&21\n우리는 쉬두로 돌아가 재정비해야 합니다.')
        stage.unit(21).setAction(0)
        stage.delay(3)
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&0\n다른 방법이 없는 것 같아요.')
        stage.say('&0\n원원!')
        stage.unit(2).setAction(6)
        stage.say('&2\n존재한다.\n&0\n너는 악진와 이전를 합페이에 머무르게 할 것이다.\n&0\n허페이는 동우와 쉬두를 연결하는 핵심 허브입니다.\n무슨 일이 있어도 버텨야 해.\n&2\n네.\n분명히 이해하겠습니다.')
        stage.unit(2).setAction(0)
        stage.say('&0\n다른 장군들은 나와 함께 쉬두로 돌아갔다.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 264, 238)
    stage.showHead(32, 328, 238)
    stage.showHead(76, 392, 238)
    stage.bottomTxt('붉은 절벽 전투 이후,', False, False, False)
    stage.delay(5)
    stage.showHead(2, 443, 129)
    stage.delay(5)
    stage.bottomTxt('조조 장료에게 허페이를 방어하라고 명령했다,', True, False, False)
    stage.delay(5)
    stage.head(0).move(264, 158)
    stage.head(0).move(330, 111)
    stage.delay(5)
    stage.bottomTxt('그는 직접 쉬두로 돌아갔다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('유비 공명의 영리한 계획을 귀 기울여라,', True, True, False)
    stage.delay(5)
    stage.head(32).move(290, 223)
    stage.delay(5)
    stage.bottomTxt('그리고 징저우를 점령했다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('반면에', True, True, False)
    stage.delay(5)
    stage.head(76).move(472, 209)
    stage.delay(5)
    stage.bottomTxt('손권 장료 주둔지인 합비를 공격하기 위해 대규모 군대를 동원했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(0, 35)
    stage.loadBg(2, 57)
    stage.showUnits([
        [
            76,
            65,
            52,
            3],
        [
            78,
            52,
            42,
            2],
        [
            88,
            52,
            62]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('허페이 교외: 오나라 군대의 주요 진영')
    stage.say('&76\n공진이 아팠다고?')
    stage.unit(78).setAction(0, 1)
    stage.delay(3)
    stage.unit(78).setAction(6)
    stage.say('&78\n네, 의사 선생님이 신체적, 정신적 피로 때문이라고 하셨어요.\n하아, 다 내 쓸모없는 내 잘못이야......')
    stage.unit(76).setAction(2)
    stage.say('&76\n음, 왜 이렇게 중요한 순간에 그런 거지......')
    stage.unit(76).setAction(0)
    stage.say('&76\n노숙, 공진을 잃을 수 없어,\n가서 최고의 의사에게 전화해 치료를 받으세요.\n&78\n네.')
    stage.unit(78).setAction(0)
    stage.say('&78\n주군, 허페이에서 뭘 해야 할까?\n만약 저우 주지사가 아니었다면......\n&76\n흠......')
    stage.showUnit(182, 16, 52, 1)
    stage.say('&182\n보고해!')
    stage.unit(182).move(52, 52, 1)
    stage.say('&182\n허페이가 누군가를 보내 편지를 전달하게 했어.\n&76\n편지? 한번 볼게.\n&182\n네.')
    stage.unit(182).move(57, 52, 1)
    stage.unit(182).setAction(0)
    stage.delay(3)
    stage.unit(76).setAction(5)
    stage.delay(5)
    stage.unit(182).move(52, 52, 1)
    stage.unit(182).setAction(0)
    stage.delay(10)
    stage.unit(76).setAction(2)
    stage.say('&76\n정말 말도 안 돼!')
    stage.unit(88).setAction(0, 1)
    stage.delay(3)
    stage.unit(88).setAction(6)
    stage.say('&88\n편지에는 뭐라고 적혀 있어?')
    stage.unit(76).setAction(2, 2)
    stage.say('&76\n직접 봐!')
    stage.unit(88).setAction(0)
    stage.delay(3)
    stage.unit(88).move(57, 62, 1)
    stage.unit(88).move(57, 52, 0)
    stage.delay(3)
    stage.unit(88).setAction(0, 1)
    stage.delay(3)
    stage.say('&88\n멀리서 도시를 마주하며 감히 전투에 나서지 못했다,\n오나라 군대는 정말 겁쟁이 쥐처럼 보였다,\n싸울 의지가 없으니 일찍 항복하는 게 낫겠어.\n&88\n…… 어떻게 그렇게 무례하게 말할 수 있지!')
    stage.unit(76).setAction(2)
    stage.say('&76\n젠장장료!\n어떻게 감히 나를 악당이라고 부르다니!')
    stage.unit(76).setAction(2, 3)
    stage.delay(3)
    stage.unit(76).setAction(17)
    stage.say('&76\n좋아! 내일 전투를 부르자!\n내가 공진을 대신해 군대를 직접 지휘하겠다!')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            13,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            23,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.unit(1).setAction(2)
    stage.say('&1\n뭐라고!?\n허페이는 동오군에게 포위당했다!')
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 방금 보고서를 받았습니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 3)
    stage.say('&1\n맹덕, 상황이 안 좋아지고 있어.\n즉시 증원군을 보내야 합니다!\n&0\n등등.\n문약, 동주유 군대를 지휘했던 사람이 누구였나요?')
    stage.unit(20).setAction(6)
    stage.say('&20\n아니, 주유 병에 걸렸다고 들었어,\n따라서 손권 직접 군대를 이끌었다.')
    stage.unit(20).setAction(0)
    model.setFace(3)
    stage.say('&0\n주유 아팠어?\n흠, 알겠어요.\n그럼 걱정할 필요 없어.')
    stage.unit(1).setAction(2)
    stage.say('&1\n맹덕, 지금 몇 시야,\n그리고 아직도 표정을 바꾸지 않아?')
    stage.unit(1).setAction(0)
    model.setFace(0)
    stage.say('&0\n원양, 내가 아무렇지 않게 ......\n그냥 허페이를 원위안에게 넘겨줄까?')
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n손권 젊고 성급해.\n주유가 없는 한,\n손권 원원을 이길 수 없어.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n이전에는 남쪽으로의 먼 원정으로 인해\n그는 오랫동안 쉬두를 통치하지 않았다,\n그래서 나는 여전히 쉬두를 떠날 수 없어.')
    stage.unit(0).setAction(17)
    stage.say('&0\n증원군이 허페이로 파견되었다.\n전체 군대가 원원의 지휘 하에 있었다,\n그가 있으면 아무 일도 일어나지 않을 거야.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            2,
            54,
            80],
        [
            10,
            44,
            64,
            1],
        [
            11,
            64,
            64,
            3]])
    stage.draw()
    stage.setStageName('허페이 조조 본캠프')
    stage.say('&2\n내 도발적인 편지를 읽고 나서,\n손권 분노할 거야.')
    stage.unit(2).setAction(17)
    stage.say('&2\n우리는 조심스럽게 처리해야 해,\n확실히 손권을 밀어낼 거예요.')
    stage.unit(2).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 7, [
        2,
        10,
        11], [
        0])
    gvars[4076] = 0
    gvars[4057] = 30
    stage.setBattlePos([
        [
            14,
            5],
        [
            13,
            4],
        [
            11,
            5],
        [
            8,
            2],
        [
            8,
            7],
        [
            12,
            11],
        [
            16,
            11],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&2\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(10):
        stage.say('&10\n하지만 그 편지는 정말 놀라웠다.\n장군이 그런 속임수를 쓸 줄은 전혀 예상하지 못했다.\n&2\n어떻게 감히 그럴 수 있겠어? 그냥 주군 전술을 따라 한 거야.')
    if stage.unitClickTest(11):
        stage.say('&11\n동오군의 위치를 보면,\n그들은 아마도 서문이나 남문을 공격할 것입니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
