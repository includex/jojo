# Source Generated with Decompyle++
# File: S_13.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(11,5)'])
    stage.nearEvent([
        0,
        124,
        0,
        122,
        0,
        119,
        0,
        123,
        0,
        125,
        0,
        126,
        0,
        2,
        0,
        32], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 32,
            'x': 10,
            'y': 25,
            'dir': 1,
            'lv': 6,
            'i': 0 },
        {
            'id': 3,
            'x': 9,
            'y': 25,
            'dir': 1,
            'lv': 6,
            'i': 1 },
        {
            'id': 33,
            'x': 10,
            'y': 26,
            'dir': 1,
            'lv': 6,
            'i': 2 },
        {
            'id': 41,
            'hide': 1,
            'x': 18,
            'y': 23,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 3 },
        {
            'id': 42,
            'hide': 1,
            'x': 18,
            'y': 25,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 4 },
        {
            'id': 40,
            'hide': 1,
            'x': 18,
            'y': 21,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 5 },
        {
            'id': 40,
            'hide': 1,
            'x': 0,
            'y': 0,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 6 }])
    stage.createEnemy([
        {
            'id': 119,
            'x': 13,
            'y': 22,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 123,
            'x': 15,
            'y': 22,
            'dir': 3,
            'lv': 4,
            'ai': 1,
            'i': 1 },
        {
            'id': 258,
            'x': 11,
            'y': 22,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 259,
            'x': 12,
            'y': 23,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 283,
            'x': 13,
            'y': 24,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 261,
            'x': 12,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 334,
            'x': 14,
            'y': 23,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 282,
            'x': 13,
            'y': 20,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 350,
            'x': 14,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 122,
            'x': 7,
            'y': 18,
            'dir': 3,
            'lv': 4,
            'ai': 1,
            'i': 9 },
        {
            'id': 124,
            'x': 6,
            'y': 19,
            'dir': 3,
            'lv': 4,
            'ai': 1,
            'i': 10 },
        {
            'id': 210,
            'x': 7,
            'y': 20,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 234,
            'x': 6,
            'y': 21,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 235,
            'x': 8,
            'y': 19,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 2,
            'x': 15,
            'y': 11,
            'dir': 3,
            'lv': 6,
            'ai': 0,
            'i': 14 },
        {
            'id': 121,
            'x': 15,
            'y': 13,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 15 },
        {
            'id': 120,
            'x': 16,
            'y': 12,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 16 },
        {
            'id': 310,
            'x': 14,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 17 },
        {
            'id': 311,
            'x': 16,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 18 },
        {
            'id': 126,
            'x': 11,
            'y': 5,
            'dir': 3,
            'lv': 6,
            'i': 19 },
        {
            'id': 125,
            'x': 11,
            'y': 6,
            'dir': 3,
            'lv': 4,
            'i': 20 },
        {
            'id': 236,
            'x': 10,
            'y': 6,
            'dir': 3,
            'lv': 0,
            'i': 21 },
        {
            'id': 237,
            'x': 12,
            'y': 6,
            'dir': 3,
            'lv': 0,
            'i': 22 },
        {
            'id': 318,
            'x': 11,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'i': 23 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 1,
            'y': 1,
            'dir': 1 },
        {
            'idx': 1,
            'x': 4,
            'y': 16,
            'dir': 1 },
        {
            'idx': 2,
            'x': 3,
            'y': 15,
            'dir': 1 },
        {
            'idx': 3,
            'x': 2,
            'y': 16,
            'dir': 1 },
        {
            'idx': 4,
            'x': 2,
            'y': 14,
            'dir': 1 },
        {
            'idx': 5,
            'x': 3,
            'y': 1,
            'dir': 1 },
        {
            'idx': 6,
            'x': 1,
            'y': 3,
            'dir': 1 },
        {
            'idx': 7,
            'x': 2,
            'y': 2,
            'dir': 1 },
        {
            'idx': 8,
            'x': 2,
            'dir': 1 },
        {
            'idx': 9,
            'y': 2,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(126, -1, 0, -1, 0, 8)
    stage.setEnemyEquip(125, -1, 0, -1, 0, 19)
    stage.setEnemyEquip(122, -1, 0, -1, 0, 2)
    stage.setEnemyEquip(123, -1, 0, -1, 0, 13)
    stage.setEnemyEquip(42, -1, 0, -1, 0, 22)
    stage.setEnemyEquip(41, -1, 0, -1, 0, 23)
    stage.loadBg(13)
    stage.setObjects(True, 17, [
        [
            8,
            17,
            23],
        [
            9,
            17,
            24]])
    stage.setUnitStatus([
        {
            'hp': -50,
            'unit': stage.unit(32) },
        {
            'hp': -80,
            'unit': stage.unit(3) },
        {
            'hp': -80,
            'unit': stage.unit(33) }])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab35')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab35')
    stage.draw()
    stage.bgSound(5)
    stage.unit(0).setDir(stage.countDir(0, 1))
    stage.say('&0\n이제 따라잡은 것 같네.\n원양, 주력 부대가 도착할 때까지 기다려야 합니다,\n샤오페이를 죽도록 붙잡아라!')
    stage.unit(1).setDir(stage.countDir(1, 0))
    stage.say('&1\n내게 맡겨, 맹덕.')
    stage.unit(1).setDir(stage.countDir(1, 32))
    stage.unit(32).setDir(stage.countDir(32, 0))
    stage.say('&32\n오? 조조 지원군이야!\n정말 멋지네요.\n둘째 형, 셋째 형, 조금만 더 버텨!')
    stage.unit(119).setDir(stage.countDir(119, 0))
    stage.say('&119\n음, 그게 조조......?\n우리가 유비를 빨리 물리치지 않으면,\n그게 ...... 문제야.')
    stage.unit(119).setDir(stage.countDir(119, 124))
    stage.unit(119).setAction(6)
    stage.say('&119\n차오싱, 고순, 적이 가까이 오지 못하게 해!')
    stage.unit(119).setAction(0)
    stage.unit(122).setDir(stage.countDir(122, 1))
    stage.unit(124).setDir(stage.countDir(124, 1))
    stage.unit(122).setAction(5)
    stage.say('&122\n네, 알겠습니다! 걱정 마십시오, 루 장군님!')
    stage.unit(122).setAction(0)
    stage.unit(124).setAction(5)
    stage.say('&124\n가오순, 하후돈 붙잡아.\n나머지는 다 내게 할게.\n가자!')
    stage.unit(124).setAction(0)
    stage.unit(210).move(5, 17, 3)
    stage.unit(234).move(5, 18, 3)
    stage.unit(235).move(6, 17, 3)
    stage.unit(122).move(5, 16, 3)
    stage.unit(122).setDir(stage.countDir(122, 1))
    stage.unit(1).setDir(stage.countDir(1, 122))
    stage.attackAction(122, 1, 2)
    stage.delay(10)
    stage.say('&122\n하후돈, 죽을 준비를 해!\n&1\n흥, 말 잘난 척 그만해!\n&124\n(좋아, 가오순! 이렇게 그냥 잘 지켜. )')
    stage.unit(1).setAction(6)
    stage.unit(1).setAction(0)
    stage.unit(122).setAction(2)
    stage.effectSound(31, 1)
    stage.delay(10)
    stage.attackAction(122, 1, 2)
    stage.delay(10)
    stage.unit(124).move(4, 17, 3)
    stage.unit(124).setDir(stage.countDir(124, 1))
    stage.unit(124).setAction(5)
    stage.effectSound(37, 1)
    stage.delay(10)
    stage.unit(124).setAction(6)
    stage.unit(124).setAction(0)
    stage.unit(1).setDir(stage.countDir(1, 124))
    stage.unit(1).setAction(2)
    stage.effectSound(31, 1)
    stage.delay(15)
    stage.say('&124\n흠! 탈출했다고!?\n&1\n이런 사소한 장난들—나한테 뭘 할 수 있겠어!')
    fight = stage.startFight(1, 124, 5)
    fight.showUnit(False, '(이번에는 반드시 너를 죽여야겠어.)', 0)
    fight.showUnit(True, '젠장! 어떻게 개입해서 문제를 일으킬 수 있지!\n절대 그냥 두지 않을 거야!', 9)
    fight.showStart()
    fight.setAction(False, 1)
    fight.setAction(False, 2)
    fight.setAction(False, 3)
    fight.setAction(True, 2)
    fight.say(True, '멈춰! 도망가지 마!', True)
    fight.setAction(False, 1)
    fight.say(False, '흥, 속았구나? 하후돈!\n내 묘기를 써!', True)
    fight.attack1(False, 0, True)
    stage.delay(10)
    fight.setAction(True, 11)
    fight.say(True, '와, 눈, 내 눈!', True)
    fight.setAction(False, 2)
    fight.say(False, '승리!\n그런 부상으로 더 이상 싸울 수 없었다!\n기회를 잡아 죽여!', True)
    fight.setAction(True, 8)
    stage.delay(5)
    fight.say(True, '이 일로 물러서지 않을 거야!\n음, 아!\n(푸훗! )', True)
    fight.setAction(False, 4)
    fight.say(False, '응?\n눈알과 화살까지 함께 뽑혔다!', True)
    fight.setAction(True, 6)
    stage.delay(5)
    fight.say(True, '오 오!\n(꿀꺽! )', True)
    fight.setAction(False, 4)
    fight.say(False, '뭐라고!\n이 사람이요......\n네 눈알을 삼키다니!?', True)
    fight.setAction(True, 10)
    fight.say(True, '오 오 오!\n어서! 내 눈을 훔친 자에게 복수하고 싶어!\n죽을 준비를 해라!', True)
    fight.setAction(False, 1)
    fight.say(False, '정말 웃기네!\n그런 사람과 싸울 수 있을까요?', True)
    fight.setAction(False, 3)
    fight.setAction(False, 13)
    fight.setAction(True, 2)
    fight.setAction(True, 9)
    fight.say(True, '이봐! 멈춰!', True)
    fight.end()
    model.setFace(128)
    stage.say('&1\n정말 증오스러워! 이 눈부신 원한!\n꼭 신청해야 해!\n&0\n오 오 오... 원양!\n젠장, 여포 어떻게 감히 ......!')
    sel = stage.choice('그리고 처음으로 구조에 나섰유비\n복수 하후돈', -1)
    if sel == 1:
        stage.unit(0).setDir(stage.countDir(0, 1))
        stage.say('&0\n원양, 빨리 물러서!\n다른 이들은 즉시 샤오페이를 도왔다!')
        stage.unit(1).setDir(stage.countDir(1, 0))
        stage.say('&1\n이건 그냥 경미한 부상일 뿐이야......\n난 아직 싸울 수 있어!')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.say('&32\n맹덕 선생님......\n진심으로 감사드립니다......')
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 후퇴유비.\n3. 턴 수가 20명을 초과한다.')
        stage.showWinCondition('죽을 때까지 붙잡유비!')
        stage.unit(32).heightLight()
        stage.unit(32).setDir(1)
        stage.say('&32\n(쉬저우에는 여포를 원망하는 사람이 꽤 있을 것이다,\n그들이 도움을 받았다면 좋았을 텐데...... )')
    elif sel == 2:
        stage.unit(0).setDir(stage.countDir(0, 119))
        stage.unit(0).setAction(5)
        stage.say('&0\n원양 위험해!\n전면 군대 구조 원양!')
        stage.unit(0).setAction(0)
        stage.unit(119).setDir(stage.countDir(119, 32))
        stage.say('&119\n좋아!\n지금 이 기회를 활용해 유비 제거하세요.')
        stage.unit(32).setAction(4)
        stage.say('&32\n지원군을 기대할 수 없는 것 같조조!\n오직 자신의 힘에 의지해야만 어려움을 극복할 수 있다......')
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
        stage.showWinCondition('전부 전멸시적군!')
        stage.unit(41).show()
        stage.unit(42).show()
        stage.unit(40).show()
        stage.setObjects(False, 16, [
            [
                8,
                17,
                23],
            [
                9,
                17,
                24]])
        stage.unit(41).setDir(stage.countDir(41, 32))
        stage.unit(40).setDir(stage.countDir(40, 32))
        stage.unit(42).setDir(stage.countDir(42, 32))
        stage.say('&41\n유비Sir!"\n빨리 서저우 성으로 도망쳐 주세요!')
        stage.unit(32).setDir(stage.countDir(32, 41))
        stage.unit(3).setDir(stage.countDir(3, 41))
        stage.unit(33).setDir(stage.countDir(33, 41))
        stage.say('&32\n오!\n미주, 미팡, 손첸!\n다들 괜찮아?\n&41\n주군 여포에 의해 쉬저우에서 쫓겨났다.\n우리가 쉬두로 도망쳤을 때, 한 걸음 늦었어,\n그래서 그는 여포에게 항복할 수밖에 없었다.\n&41\n오늘은 마침내 그 수치심을 씻어낼 수 있어요.\n주군, 빨리 도시로 들어가 주세요.\n&32\n오! 여러분 모두에게 정말 감사해요.')
        stage.unit(32).move(19, 24, 3)
        stage.unit(3).move(19, 23, 3)
        stage.unit(33).move(19, 25, 3)
        stage.unit(32).hide()
        stage.unit(3).hide()
        stage.unit(33).hide()
        stage.setObjects(True, 17, [
            [
                8,
                17,
                23],
            [
                9,
                17,
                24]])
        if not vars[50]:
            stage.unit(41).setDir(stage.countDir(41, 119))
            stage.unit(119).setDir(stage.countDir(119, 41))
            stage.say('&119\n뭐-뭐라고!\n쉬저우는 유비에게 점령당했다!\n혹시 미주와 다른 사람들이 우리를 배신한 건가요?')
            stage.unit(41).setAction(6)
            stage.say('&41\n하하하, 여포!\n네 인생은 오늘 끝난다!\n조조 너를 파괴하게 놔둬!')
            stage.unit(41).setAction(0)
            stage.say('&119\n젠장......\n내가 조조를 죽일 때,\n그럼 나중에 너랑 결판 낼게.')
        stage.unit(41).hide()
        stage.unit(42).hide()
        stage.unit(40).hide()
        vars[58] = 1
    stage.startOper()
    vars[513] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 1 and stage.round() == 2:
        stage.say('&33\n저는 수비술이 제일 싫어요!\n&32\n맹덕 주님의 도움 덕분에,\n적군의 군대는 이미 흩어졌다,\n지금이 바로 공격할 때.......\n&3\n우리도 조다차이의 의로움에 협력해야 합니다,\n싸워서 빠져나가세요.')
        stage.unit(32).setAI(1)
        stage.unit(3).setAI(1)
        stage.unit(33).setAI(1)
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 11, 5):
        stage.getItem(153, 0, True, 1025)
        vars[20] = 1
    if not vars[6] and not vars[54] and not vars[56] and stage.totalRectUnit(0, 5, 13, 19, 27) >= 3 and stage.curCamp() == 2 and stage.totalRectUnit(2, 14, 10, 16, 13) == 5:
        stage.unit(2).setDir(stage.countDir(2, 0))
        stage.unit(2).setAction(5)
        stage.say('&2\n조조 소식을 나눴어요!\n전면 돌격!')
        stage.unit(2).setAction(0)
        stage.unit(2).setAI(3, 0, 0, 0)
        stage.unit(121).setAI(3, 0, 0, 0)
        stage.unit(120).setAI(3, 0, 0, 0)
        stage.unit(310).setAI(3, 0, 0, 0)
        stage.unit(311).setAI(3, 0, 0, 0)
        if not stage.totalRectUnit(0, 0, 0, 15, 9) == 0 and not vars[56] and not vars[57]:
            stage.unit(126).setDir(stage.countDir(126, 0))
            stage.unit(125).setDir(stage.countDir(125, 0))
            stage.unit(126).setAction(5)
            stage.say('&126\n더 이상 이 패스를 들고 있을 필요가 없었다.\n그들과 함께 장료합시다!')
            stage.unit(126).setAction(0)
            stage.unit(125).setAction(7)
            stage.say('&125\n다른 방법이 없어. 나도 같이 갈까?\n아니면 천천히 걸을까?')
            stage.unit(125).setAction(0)
            stage.unit(126).setAI(3, 0, 0, 0)
            stage.unit(125).setAI(3, 0, 0, 0)
            stage.unit(236).setAI(3, 0, 0, 0)
            stage.unit(237).setAI(3, 0, 0, 0)
            stage.unit(318).setAI(3, 0, 0, 0)
        vars[6] = 1
    if not vars[6] and not vars[7] and stage.isInRect(1025, 9, 2, 13, 8) and stage.curCamp() == 2:
        stage.unit(125).setAI(0)
        stage.unit(236).setAI(0)
        stage.unit(237).setAI(0)
        stage.unit(318).setAI(0)
        vars[7] = 1
    if not vars[40] and stage.isNear(0, 124, True):
        stage.unit(0).setDir(stage.countDir(0, 124))
        stage.unit(124).setDir(stage.countDir(124, 0))
        stage.say('&0\n죽을 준비가 된 것 같군.\n복수하고 싶원양!\n&124\n흥!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 122, True):
        stage.unit(0).setDir(stage.countDir(0, 122))
        stage.unit(122).setDir(stage.countDir(122, 0))
        stage.say('&0\n원양의 복수를 위해, 너희 목숨을 원한다!\n&122\n뤼 장군의 명령으로, 너를 죽이겠다!')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 119, True):
        stage.unit(0).setDir(stage.countDir(0, 119))
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.say('&0\n우리가 마주한 횟수는,\n몇 명이나 될까......\n&119\n어느 쪽도 먼저 쓰러지지 않는다면,\n이 전쟁은 절대 끝나지 않을 거야!\n죽을 준비를 해라!')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 123, True):
        stage.unit(0).setDir(stage.countDir(0, 123))
        stage.unit(123).setDir(stage.countDir(123, 0))
        stage.say('&0\n흥, 이름 없는 젊은이! 꺼져!\n&123\n뭐라고 했어? 내가 한 방 가르쳐 줄게!')
        vars[43] = 1
    if not vars[44] and stage.isNear(0, 125, True):
        stage.unit(0).setDir(stage.countDir(0, 125))
        stage.unit(125).setDir(stage.countDir(125, 0))
        stage.say("비켜! 너한테 신경 쓸 시간이 없어!\n이렇게 나에게 말하다니, 절대로 용서 못 해! 적어도 '좀 비켜주시겠어요'라고는 해야지.")
        vars[44] = 1
    if not vars[6] and not vars[45] and stage.isNear(0, 126, True):
        stage.unit(0).setDir(stage.countDir(0, 126))
        stage.unit(126).setDir(stage.countDir(126, 0))
        stage.say('빨리 항복하고 투항해라! 이렇게 하면 내가 너를 죽이지 않을 수도 있어. 무슨 헛소리야! 난관이 그렇게 쉽게 함락될 리가 없어!')
        vars[45] = 1
    if not vars[46] and stage.isNear(0, 2, True):
        stage.unit(0).setDir(stage.countDir(0, 2))
        stage.unit(2).setDir(stage.countDir(2, 0))
        stage.say('&0\n그는 정말 뛰어난 장군입니다!\n불행히도 그는 적을 위해 일하고 있었다.\n&2\n경고할게!\n전장에서 한 번의 부주의한 순간이 목숨을 잃을 수도 있다.\n싸움에 집중해야 해!\n&0\n(점점 더 장료을 길들이고 싶어지고 있어. )\n&2\n죽을 준비를 해라!')
        vars[46] = 1
    if not vars[47] and stage.isNear(0, 32, True):
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.say('&0\n쉬안더, 괜찮아?\n&32\n맹덕 선생님, 진심으로 감사드립니다.\n당신의 의로운 도움에 보답하기 위해,\n이걸 받아주시겠습니까?')
        stage.getItem(160, 0)
        vars[47] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n조조, 유비!\n이게 정말 네 모습이야?\n음, .......')
        stage.unit(119).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(123, 7, 0, 2):
        stage.say('&123\n음!\n어떻게 이렇게 참담한 패배가 될 수 있지......\n후퇴!')
        stage.unit(123).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(122, 7, 0, 2):
        stage.say('&122\n루 장군, 제가 실망시켰습니다.\n후퇴.')
        stage.unit(122).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(124, 7, 0, 2):
        stage.say('&124\n아!')
        stage.unit(124).hide(2)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(2, 7, 0, 2):
        stage.say('&2\n다른 방법은 없었다.\n후퇴.')
        stage.unit(2).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(120, 7, 0, 2):
        stage.say('&120\n젠장!\n이걸 기억하세요!')
        stage.unit(120).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(126, 7, 0, 2):
        stage.say('&126\n음음!\n후퇴, 후퇴!')
        stage.unit(126).hide(1)
        if not vars[6] and not vars[54] and stage.totalRectUnit(2, 14, 10, 16, 13) == 5:
            stage.unit(2).setAction(5)
            stage.say('&2\n난관이 무너질 줄은 몰랐어! 큰일이야.\n전군이 적군와 맞서야 한다!\n아무도 통과시키지 마!')
            stage.unit(2).setAction(0)
            stage.unit(2).setAI(1)
            stage.unit(121).setAI(1)
            stage.unit(120).setAI(1)
            stage.unit(310).setAI(1)
            stage.unit(311).setAI(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(125, 7, 0, 2):
        stage.say('&125\n흠, 운이 좋았나 보네......\n진짜로 나를 이겼어......\n아니, 무승부라는 뜻이야......\n&125\n먼저 저승에서 기다릴게,\n그럼 진짜 대결이 벌어질 거야......\n안타깝게도!')
        stage.unit(125).hide(2)
        stage.getItem(126, 0, True, 1027)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n흠, 흠, 이게 내 운명인가......?')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n오, 안 돼!\n현덕 ......님!')
        stage.unit(41).show()
        stage.unit(42).show()
        stage.unit(40).show()
        stage.setObjects(False, 16, [
            [
                8,
                17,
                23],
            [
                9,
                17,
                24]])
        stage.unit(41).setDir(stage.countDir(41, 32))
        stage.unit(42).setDir(stage.countDir(42, 32))
        stage.unit(42).setDir(stage.countDir(42, 32))
        stage.say('&41\n주군, 아직 포기할 때가 아니야!\n서주로 도망쳐 주세요!')
        stage.unit(32).setDir(stage.countDir(32, 41))
        stage.say('&32\n오!\n미주, 미팡, 손첸!\n다들 괜찮아?\n&41\n주군 여포에 의해 쉬저우에서 쫓겨났다.\n우리가 쉬두로 도망쳤을 때, 한 걸음 늦었어,\n그래서 그는 여포에게 항복할 수밖에 없었다.\n&41\n오늘은 마침내 그 수치심을 씻어낼 수 있어요.\n&41\n주군, 빨리 도시로 들어가 주세요.\n&32\n오! 여러분 모두에게 정말 감사해요.')
        stage.unit(32).move(19, 24, 3)
        if not vars[59]:
            stage.unit(3).setDir(stage.countDir(3, 41))
            stage.say('&3\n미주 씨, 괜찮으시군요!')
            stage.unit(3).move(19, 23, 3)
        if not vars[60]:
            stage.unit(33).setDir(stage.countDir(33, 41))
            stage.say('&33\n좋아, 이제 살렸어!')
            stage.unit(33).move(19, 25, 3)
        stage.unit(32).hide()
        stage.unit(3).hide()
        stage.unit(33).hide()
        stage.setObjects(True, 17, [
            [
                8,
                17,
                23],
            [
                9,
                17,
                24]])
        if not vars[50]:
            stage.unit(41).setDir(stage.countDir(41, 119))
            stage.unit(119).setDir(stage.countDir(119, 41))
            stage.say('&119\n뭐-뭐라고!\n쉬저우가 유비기를 꽂았다고?\n혹시 미주와 다른 사람들이 우리를 배신한 건가요!')
            stage.unit(41).setAction(6)
            stage.say('&41\n하하하, 여포!\n네 인생은 오늘 끝난다!\n조조 너를 파괴하게 놔둬!')
            stage.unit(41).setAction(0)
            stage.say('&119\n젠장......\n내가 조조를 죽일 때,\n그럼 나중에 너랑 결판 낼게.')
        stage.unit(41).hide()
        stage.unit(42).hide()
        stage.unit(40).hide()
        stage.unit(0).setDir(2)
        stage.unit(0).setAction(5)
        stage.say('좋습니다. 유비가 위험에서 벗어났군요.\n다음은 적군을 격멸하고 전력을 집중해야 합니다!')
        stage.unit(0).setAction(0)
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
        stage.showWinCondition('전부 전멸시적군!')
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n그러니 원치 않아, 물러나!')
        stage.unit(3).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n이걸 기억하세요!\n이번엔 봐줄게.')
        stage.unit(33).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(121, 7, 0, 2):
        stage.say('&121\n도와줘, 도와줘.........\n지금이 기회야! 빨리 도망쳐, 서둘러!')
        stage.unit(121).hide(1)
        vars[61] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어.\n아군 이겼어!')
        if not vars[47] and not vars[58]:
            stage.unit(0).setDir(stage.countDir(0, 32))
            stage.unit(32).setDir(stage.countDir(32, 0))
            stage.say('&0\n이번에는 어려움을 극복했지만,\n하지만 그는 여전히 여포를 죽여야 했다.\n쉬안더, 아군 합류해.\n&32\n만약 이것이 혼란스러운 시대의 표준이라면,\n물론 저도 동의할 수밖에 없었죠.\n&32\n먼저 은혜를 갚아야겠어.\n이걸 받아주시겠습니까?')
            stage.getItem(160, 0)
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[613] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 여포군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
