# Source Generated with Decompyle++
# File: S_10.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        16,
        144])
    stage.nearEvent([
        16,
        143,
        16,
        23], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 31,
            'x': 16,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'i': 0 },
        {
            'id': 30,
            'hide': 1,
            'x': 6,
            'y': 8,
            'dir': 1,
            'lv': 1,
            'ai': 1,
            'i': 1 }])
    stage.createEnemy([
        {
            'id': 143,
            'x': 22,
            'y': 8,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 23,
            'x': 22,
            'y': 7,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 1 },
        {
            'id': 210,
            'x': 21,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 211,
            'x': 9,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 212,
            'x': 10,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 213,
            'x': 13,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 214,
            'x': 14,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 215,
            'x': 13,
            'y': 14,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 216,
            'x': 14,
            'y': 13,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 234,
            'x': 21,
            'y': 5,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 235,
            'x': 12,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 236,
            'x': 14,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 237,
            'x': 14,
            'y': 15,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 238,
            'x': 16,
            'y': 16,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 144,
            'x': 17,
            'y': 8,
            'dir': 1,
            'lv': 6,
            'ai': 3,
            'targetId': 16,
            'i': 14 },
        {
            'id': 217,
            'x': 16,
            'y': 7,
            'dir': 1,
            'lv': 0,
            'ai': 3,
            'targetId': 16,
            'i': 15 },
        {
            'id': 218,
            'x': 17,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'ai': 3,
            'targetId': 16,
            'i': 16 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 12,
            'y': 8,
            'dir': 3 },
        {
            'idx': 1,
            'x': 20,
            'y': 8,
            'dir': 1 },
        {
            'idx': 2,
            'x': 1,
            'y': 8,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 3,
            'x': 14,
            'y': 6,
            'dir': 1 },
        {
            'idx': 4,
            'x': 13,
            'y': 11 },
        {
            'idx': 5,
            'x': 10,
            'y': 9,
            'dir': 3 },
        {
            'idx': 6,
            'x': 1,
            'y': 10,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 7,
            'y': 8,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 8,
            'x': 1,
            'y': 7,
            'dir': 1,
            'hide': 1 },
        {
            'idx': 9,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(144, -1, 0, 23, 0, -1)
    stage.loadBg(10)
    stage.setFire(True, 7, 5)
    stage.setFires(True, [
        [
            8,
            4],
        [
            8,
            5]])
    stage.setFires(True, [
        [
            9,
            4],
        [
            8,
            6]])
    stage.setFires(True, [
        [
            9,
            5],
        [
            8,
            7]])
    stage.setFire(True, 9, 6)
    stage.setFires(True, [
        [
            10,
            5],
        [
            11,
            5]])
    stage.setFire(True, 9, 12)
    stage.setFires(True, [
        [
            10,
            13],
        [
            10,
            12]])
    stage.setFires(True, [
        [
            11,
            13],
        [
            11,
            12],
        [
            11,
            11]])
    stage.setFire(True, 12, 12)
    stage.setFires(True, [
        [
            20,
            13],
        [
            20,
            12]])
    stage.setFires(True, [
        [
            19,
            13],
        [
            20,
            11]])
    stage.setFire(True, 19, 12)
    stage.setFires(True, [
        [
            18,
            13],
        [
            19,
            11]])
    stage.setFires(True, [
        [
            18,
            12],
        [
            19,
            10]])
    stage.setFire(True, 18, 11)
    stage.setFire(True, 17, 12)
    stage.setFire(True, 18, 4)
    stage.setFire(True, 19, 5)
    stage.setFire(True, 17, 4)
    stage.setFire(True, 18, 5)
    stage.setFire(True, 19, 6)
    stage.setFires(True, [
        [
            16,
            5],
        [
            17,
            5]])
    stage.setFire(True, 18, 6)
    stage.setFire(True, 19, 7)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab52')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab52')
    stage.draw()
    stage.bgSound(6)
    stage.unit(31).setDir(stage.countDir(31, 0))
    stage.unit(0).setDir(stage.countDir(0, 31))
    stage.say('&31\n서문 수비대는 매우 약해 보였다.\n아버지, 빨리 떠나 주세요!')
    stage.unit(144).setDir(stage.countDir(144, 31))
    stage.say('&144\n뭐라고 부르든 상관없어.\n너랑 조만이 함께 저승으로 내려가야 해!')
    stage.attackAction(144, 31, 1)
    stage.delay(10)
    stage.unit(31).setAction(4)
    stage.say('&31\n와!')
    stage.unit(31).hide(2)
    stage.unit(0).setAction(4)
    stage.say('&0\n조—조앙! 젠장장수!')
    stage.unit(16).setDir(stage.countDir(16, 0))
    stage.say('&16\n주군, 빨리 도망쳐!\n곧 갈게!\n&0\n하지만 전위, 당신은 .......\n&0\n젠장...... 반드시 병력을 데려올게.\n전위, 버텨야 해, 버텨!')
    stage.unit(0).setDir(3)
    stage.unit(0).setAction(5)
    stage.say('&0\n서문으로 도망쳐라!\n모두 앞에서 길을 열고,\n반드시 퇴로가 적에게 끊기지 않도록 해야 한다.')
    stage.unit(0).setAction(0)
    stage.unit(143).setDir(stage.countDir(143, 0))
    stage.say('&143\n도망치고 싶어? 그렇게 쉽지 않아.')
    stage.setWinCondition('승리 조건\n1. 조조 서쪽 끝에 도착한다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('조조 도망쳐!')
    stage.heightLight(0, 7, 1, 10)
    stage.startOper()
    vars[510] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and not vars[53] and stage.round() >= 1 and stage.unitStateTest(16, 7, 50, 1):
        stage.unit(16).setAction(9)
        stage.say('&16\n음음 음...... 젠장!')
        stage.unit(16).setAction(7)
        stage.say('&16\n아직 그렇게 빨리 빠진 적은 없어요, 아직은요!')
        stage.unit(16).setAction(0)
        vars[11] = 1
    if not vars[11] and not vars[12] and not vars[53] and stage.unitStateTest(16, 7, 100, 1) and stage.round() >= 1:
        stage.unit(16).setAction(5)
        stage.say('&16\n꺼져! 이 작은 하수들아!')
        stage.unit(16).setAction(0)
        stage.unit(16).setAction(6)
        stage.say('&16\n용기가 있다면 최선을 다해 보세요!')
        stage.unit(16).setAction(0)
        vars[12] = 1
    if not vars[30] and not vars[31] and stage.isInRect(0, 0, 0, 7, 19):
        stage.unit(30).show()
        stage.unit(30).setDir(stage.countDir(30, 0))
        stage.say('&30\n삼촌, 다치셨어요?\n이건 나한테 맡겨, 도망가야 해."')
        vars[30] = 1
    if not vars[31] and not vars[33] and stage.isInRect(0, 0, 7, 1, 10):
        stage.unit(237).setAI(1)
        stage.unit(2, 1).show()
        stage.unit(6, 1).show()
        stage.unit(7, 1).show()
        stage.unit(8, 1).show()
        stage.unit(31).setDir(stage.countDir(31, 0))
        stage.say('&12\n다행이네요, 다치지 않았주군 그렇죠!')
        stage.unit(0).setDir(stage.countDir(0, 31))
        stage.say('&0\n조홍, 다른 사람들은 어떻게 됐어?\n&12\n이번 일은 정말 갑작스러워서...\n제가 다른 부대를 집결시켰지만,\n이 정도밖에 안 돼요.')
        if vars[53]:
            stage.say('&0\n정말?\n&12\n하지만 장군......전위 그는...\n그들이 포위전에 갇혀 있었기 때문이다...\n결국 그는 의로움을 위해 죽기로 선택했다......\n&0\n전위 ..........')
            stage.unit(0).setAction(4)
            stage.unit(0).setDir(1)
            stage.unit(0).setAction(5)
            stage.say('&0\n정말 미운 장수!\n한숨, 이 재앙은 다 내 부주의 탓이야.\n&12\n주군, 이곳은 꽤 위험한 곳이야.......\n&0\n흠, 군대 전체가 후퇴해야 해. 후퇴!\n후퇴 후 재정비했다.')
            stage.unit(0).setAction(0)
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[610] = 1
            return True
        if not vars[53]:
            stage.say('&12\n전위 장군은 여전히 깊은 적의 포위망에 갇혀 있었다...\n그 덕분에 우리는 탈출할 수 있었다.\n&0\n오! 그래서 내 이빌라이구나,\n그는 만 명의 용기를 지녔고, 만 명의 병사도 이길 수 없어!\n좋아, 지금 당장 구하러 가전위!')
            stage.unit(0).setDir(stage.countDir(0, 16))
            stage.say('&12\n주군 절대 안 돼!\n지금 돌아서는 것은 분명 자멸일 것이다.')
            stage.unit(0).setDir(stage.countDir(0, 12))
            stage.say('&0\n뭐라고? 전위 버릴 생각이야!?\n&12\n혹시 주군 희망이 당신을 구하기 위해 목숨을 걸고 대가를 치르는 대가전위 걸 수도 있겠네요,\n그렇게 그냥 헛되이 버릴까요?\n전위도 우리가 이걸 하길 원하지 않을 거라고 믿어.')
            stage.unit(0).setDir(stage.countDir(0, 16))
            stage.say('전위,...')
            sel = stage.choice('그리고 나서 병력을 철수시켰다\n구조 전위로 돌아가세요', -1)
            if sel == 1:
                stage.unit(0).setAction(4)
                stage.say('&0\n…… 정말 미안해, 전위!')
                stage.say('&16\n(주군, 몸조심해....... )')
                stage.unit(16).setAction(8)
                stage.say('&16\n와! 뭘 하고 싶어?\n정말 내가 그렇게 죽길 바라는 거야!?\n정말 나를 그렇게 소중히 여기시네요!')
                stage.reward()
                stage.end()
                vars[0] = 1
                vars[101] = 1
                vars[610] = 1
                vars[710] = 1
                return True
            if sel == 2:
                stage.unit(0).setAction(5)
                stage.say('&0\n…… 싸워서 다시 돌아오고 싶어!\n죽는 게 두렵지 않다면, 나랑 같이 가자!\n부하의 목숨도 구하지 못하면 세상을 위해 싸워야 무슨 소용이 있겠어!\n&12\n주군.......\n조홍 이해했다..........\n우리 모두 죽기로 결심했어!\n&0\n좋아!\n전 군대가 완청으로 돌아가 전위를 구출했다!')
                stage.unit(0).setAction(0)
                stage.setWinCondition('승리 조건\n1. 전위 서쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
                stage.showWinCondition('전위 도망쳐!')
                stage.unit(16).heightLight()
                stage.heightLight(0, 7, 1, 10)
                vars[2] = 1
        vars[31] = 1
    if not vars[31] and vars[33] and stage.isInRect(0, 0, 7, 1, 10):
        stage.unit(237).setAI(1)
        stage.unit(2, 1).show()
        stage.unit(6, 1).show()
        stage.unit(7, 1).show()
        stage.unit(8, 1).show()
        stage.unit(31).setDir(stage.countDir(31, 0))
        stage.say('&12\n다행이네, 다치지 않았지?')
        stage.unit(0).setDir(stage.countDir(0, 31))
        stage.say('&0\n조홍, 다른 사람들은 어떻게 됐어?\n&12\n이번 일은 정말 갑작스러워서...\n제가 다른 부대를 집결시켰지만,\n이 정도밖에 안 돼요.')
        if vars[53]:
            stage.say('&0\n정말?\n&12\n하지만 장군......전위 그는...\n그들이 포위전에 갇혀 있었기 때문이다...\n결국 그는 의로움을 위해 죽기로 선택했다......\n&0\n전위 ..........')
            stage.unit(0).setAction(4)
            stage.unit(0).setDir(1)
            stage.unit(0).setAction(5)
            stage.say('&0\n정말 미운 장수!\n한숨, 이 재앙은 다 내 부주의 탓이야.\n&12\n주군, 이곳은 꽤 위험한 곳이야.......\n&0\n흠, 군대 전체가 후퇴해야 해. 후퇴!\n후퇴 후 재정비했다.')
            stage.unit(0).setAction(0)
        if not vars[53]:
            stage.unit(0).setAction(4)
            stage.unit(0).setDir(1)
            stage.unit(0).setAction(5)
            stage.say('&0\n정말 미운 장수!\n한숨, 이 재앙은 다 내 부주의 탓이야.\n&12\n주군, 이곳은 꽤 위험한 곳이야.......\n&0\n흠, 군대 전체가 후퇴해야 해. 후퇴!\n후퇴 후 재정비했다.')
            stage.unit(0).setAction(0)
        vars[31] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[102] = 1
        vars[610] = 1
        return True
    if vars[2] and not vars[32] and stage.isInRect(16, 0, 7, 1, 10):
        stage.say('&16\n여기 오면 더 이상 문제가 아니에요, 하하하.\n헤헤, 근육을 스트레칭하는 게 정말 기분 좋다.')
        stage.unit(0).setDir(stage.countDir(0, 16))
        stage.say('&0\n흠! 전위, 정말 많이 빚졌어.')
        stage.unit(16).setDir(stage.countDir(16, 0))
        stage.say('&16\n주군.......')
        stage.unit(0).setAction(5)
        stage.say('좋습니다. 전력을 후퇴시키겠습니다!\n저는 반드시 다시 돌아와서 싸울 것입니다.\n장수, 목을 씻어 저를 기다리세요!')
        stage.unit(0).setAction(0)
        vars[32] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[103] = 1
        vars[610] = 1
        return True
    if not vars[33] and stage.isInRect(16, 0, 0, 10, 19):
        vars[33] = 1
    if not vars[2] and not vars[40] and stage.isNear(16, 144, False):
        stage.unit(144).setDir(stage.countDir(144, 16))
        stage.unit(16).setDir(stage.countDir(16, 144))
        stage.say('&144\n이 시점에서도 저항하고 싶어?\n반드시 죽여버릴 거야!\n&16\n막 너한테 일대일로 도전하려던 참이었어.\n네가 말만 하는 건지 한번 보자!')
        fight = stage.startFight(16, 144, 5)
        fight.showUnit(False, '하하하, 오늘이 네 죽는 날이야!', 0)
        fight.showUnit(True, '장군으로서 나는 주군에게 충성하며 죽었어야 했다!\n하지만 네 몇 가지 기술만으로도,\n네가 날 쉽게 이기게 전위won 수 없어!', 9)
        fight.showStart()
        fight.say(False, '이걸 받아라!', False)
        fight.attack1(False, 1, False)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '어? 내 치명적인 숨겨진 무기를 피......!\n이거 다시 봐!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 2, True)
        stage.delay(5)
        fight.setAction(True, 10)
        fight.say(True, '건방지게 굴지 마! 이번엔 내 모습 좀 봐!', True)
        fight.setAction(True, 2)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.say(False, '오!', False)
        fight.attack2(True, 0, False)
        fight.attack1(True, 3, True)
        fight.attack1(False, 0, False)
        stage.delay(5)
        fight.setAction(True, 11)
        fight.say(True, '흠!', True)
        stage.delay(10)
        fight.setAction(False, 0)
        fight.say(False, '……, 너무 방심했잖아?\n나한테 암기만 쓰는 줄 알았어.\n이번엔 네 목숨까지 가져갈 거야!', True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, False)
        fight.attack2(False, 0, True)
        fight.attack2(True, 1, False)
        fight.say(False, '와!', True)
        stage.delay(10)
        fight.setAction(True, 1)
        fight.setAction(False, 12)
        fight.say(False, "'에라이'라는 이름은 정말 그럴 만한 이름입니다,\n하지만 얼마나 더 버틸 수 있을까요......?\n하하하.", True)
        fight.setAction(False, 2)
        fight.setAction(False, 2)
        fight.setAction(False, 3)
        fight.setAction(False, 13)
        stage.delay(10)
        fight.setAction(True, 11)
        fight.say(True, '푸훗! 이 아이 정말 대단해!', True)
        stage.delay(5)
        fight.setAction(True, 6)
        fight.say(True, '하지만 나를 이기는 게 그렇게 쉽지 않아!\n죽어도 널 보내주지 않을 거야!', True)
        fight.end()
        vars[40] = 1
    if not vars[2] and not vars[41] and stage.isNear(16, 143, True):
        stage.unit(16).setDir(stage.countDir(16, 143))
        stage.unit(143).setDir(-1)
        stage.say('&16\n내가 여기 있는 한,\n내 집 주군 머리카락 한 올도 만지지 마!\n&143\n이 사람, 이 사람...\n괴물일까......?')
        vars[41] = 1
    if not vars[2] and not vars[42] and stage.isNear(16, 23, True):
        stage.unit(16).setDir(stage.countDir(16, 23))
        stage.unit(23).setDir(stage.countDir(23, 16))
        stage.say('&23\n무적의 전위조차도,\n이제는 그가 어떻게 해야 할지 모르겠네요.\n&16\n이 음모를 꾸민 사람이 바로 당신이죠?\n너 정말 비열해......\n&23\n이것이 바로 전략의 의미입니다,\n전쟁은 여러 방법을 필요로 합니다.\n이게 혼돈의 흔한 규칙이야; 그냥 평화롭게 죽어야 해.')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(143, 7, 0, 2):
        stage.say('&143\n이런 상황에 몰릴 줄은 몰랐어...\n조의 군대는 정말 무서웠다......')
        stage.unit(143).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(23, 7, 0, 2):
        stage.say('&23\n더는 못 참겠어, 더는 못 참겠어.\n전략가로서 전투에 매달려서는 안 된다!\n안전한 숨을 곳을 찾아야 해.')
        stage.unit(23).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(144, 7, 0, 2):
        stage.say('&144\n이게 어떻게 가능하지...\n와!')
        stage.unit(144).hide(2)
        stage.getItem(91, 0, True, 1027)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(16, 7, 0, 2):
        if vars[2]:
            stage.unit(16).setAction(4)
            stage.say('&16\n아니, ......주군 무사히 도망쳤는지 궁금해.\n저는 군사 장군으로 전위합니다......\n마침내 이 삶은 헛되지 않았다.......')
            stage.unit(16).retreatTxt(False)
            stage.unit(16).hide(2)
            stage.unit(0).setDir(stage.countDir(0, 16))
            stage.say('전위, 전위! 전위!... 우와...! 전군 퇴각한다, 퇴각! 전위... 내가 반드시 네 원수를 갚을 것이다...!')
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[104] = 1
            vars[610] = 1
            vars[710] = 1
            return True
        if not vars[2]:
            stage.unit(16).setAction(4)
            stage.say('&16\n절대 통과시키지 않을 거야!\n와! 주군.......\n………….')
            stage.unit(16).retreatTxt(False)
            stage.unit(16).hide(2)
            vars[710] = 1
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(30, 7, 0, 2):
        stage.say('&30\n조앙, 나도 못 갈 것 같아.\n나는 저승에서 삼촌의 영역을 지키겠다!\n훗!')
        stage.unit(30).hide(2)
        vars[54] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 전멸시켰어!\n하지만 손실은 결코 적지 않습니다!\n일단 후퇴하고 다시 정비하자!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[610] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 장수군에 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
