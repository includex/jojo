# Source Generated with Decompyle++
# File: S_18.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28], [
        '(6,8)',
        '(6,19)',
        '(19,8)',
        '(27,12)',
        '(28,14)',
        '(3,6)',
        '(3,11)',
        '(6,7)'])
    stage.nearEvent([
        15,
        7])
    stage.nearEvent([
        0,
        101,
        0,
        7,
        0,
        107,
        0,
        106,
        15,
        101,
        15,
        113,
        15,
        115,
        0,
        104], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, 101, 0, 0, 1)
    stage.createEnemy(
        [{'id': 101, 'x': 6, 'y': 8, 'lv': 6, 'i': 0},
         {'id': 102, 'x': 6, 'y': 7, 'lv': 6, 'ai': 0, 'i': 1},
         {'id': 210, 'x': 5, 'y': 6, 'lv': 0, 'ai': 0, 'i': 2},
         {'id': 211, 'x': 7, 'y': 6, 'lv': 0, 'ai': 0, 'i': 3},
         {'id': 298, 'x': 3, 'y': 6, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 299, 'x': 3, 'y': 11, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 113, 'x': 3, 'y': 8, 'dir': 3, 'lv': 4, 'ai': 0, 'i': 6},
         {'id': 212, 'x': 3, 'y': 7, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 213, 'x': 3, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 234, 'x': 4, 'y': 8, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 115, 'x': 8, 'y': 7, 'dir': 1, 'lv': 4, 'ai': 0, 'i': 10},
         {'id': 214, 'x': 8, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 11},
         {'id': 215, 'x': 8, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 235, 'x': 7, 'y': 7, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 106, 'x': 5, 'y': 10, 'lv': 6, 'ai': 0, 'i': 14},
         {'id': 103, 'x': 6, 'y': 10, 'lv': 4, 'ai': 0, 'i': 15},
         {'id': 216, 'x': 5, 'y': 11, 'lv': 0, 'ai': 0, 'i': 16},
         {'id': 217, 'x': 6, 'y': 11, 'lv': 0, 'ai': 0, 'i': 17},
         {'id': 236, 'x': 4, 'y': 11, 'lv': 0, 'ai': 0, 'i': 18},
         {'id': 237, 'x': 7, 'y': 11, 'lv': 0, 'ai': 0, 'i': 19},
         {'id': 7, 'x': 4, 'y': 14, 'lv': 8, 'i': 20},
         {'id': 258, 'x': 3, 'y': 14, 'lv': 0, 'i': 21},
         {'id': 259, 'x': 5, 'y': 14, 'lv': 0, 'i': 22},
         {'id': 282, 'x': 4, 'y': 13, 'lv': 0, 'i': 23},
         {'id': 107, 'x': 7, 'y': 15, 'lv': 6, 'i': 24},
         {'id': 260, 'x': 6, 'y': 15, 'lv': 0, 'i': 25},
         {'id': 261, 'x': 8, 'y': 15, 'lv': 0, 'i': 26},
         {'id': 283, 'x': 7, 'y': 14, 'lv': 0, 'i': 27},
         {'id': 111, 'x': 27, 'y': 12, 'lv': 6, 'ai': 0, 'i': 28},
         {'id': 218, 'x': 28, 'y': 12, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 219, 'x': 27, 'y': 14, 'lv': 0, 'ai': 0, 'i': 30},
         {'id': 220, 'x': 10, 'y': 7, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 31},
         {'id': 221, 'x': 10, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 32},
         {'id': 222, 'x': 10, 'y': 9, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 33},
         {'id': 238, 'x': 9, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 34},
         {'id': 310, 'x': 19, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 35},
         {'id': 318, 'x': 18, 'y': 9, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 36},
         {'id': 319, 'x': 20, 'y': 7, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 37},
         {'id': 320, 'x': 6, 'y': 19, 'lv': 0, 'ai': 0, 'i': 38},
         {'id': 311, 'x': 5, 'y': 20, 'lv': 0, 'ai': 0, 'i': 39},
         {'id': 312, 'x': 7, 'y': 19, 'lv': 0, 'ai': 0, 'i': 40},
         {'id': 104, 'x': 6, 'y': 6, 'lv': 4, 'ai': 0, 'i': 41}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 15,
            'y': 30,
            'dir': 0 },
        {
            'idx': 1,
            'x': 11,
            'y': 27,
            'dir': 0 },
        {
            'idx': 2,
            'x': 18,
            'y': 27,
            'dir': 0 },
        {
            'idx': 3,
            'x': 12,
            'y': 28,
            'dir': 0 },
        {
            'idx': 4,
            'x': 17,
            'y': 28,
            'dir': 0 },
        {
            'idx': 5,
            'x': 13,
            'y': 28,
            'dir': 0 },
        {
            'idx': 6,
            'x': 16,
            'y': 28,
            'dir': 0 },
        {
            'idx': 7,
            'x': 12,
            'y': 29,
            'dir': 0 },
        {
            'idx': 8,
            'x': 17,
            'y': 29,
            'dir': 0 },
        {
            'idx': 9,
            'x': 13,
            'y': 29,
            'dir': 0 },
        {
            'idx': 10,
            'x': 16,
            'y': 29,
            'dir': 0 },
        {
            'idx': 11,
            'x': 14,
            'y': 30,
            'dir': 0 },
        {
            'idx': 12,
            'x': 15,
            'y': 29,
            'dir': 0 },
        {
            'idx': 13,
            'x': 14,
            'y': 29,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(101, -1, 0, -1, 0, 4)
    stage.setEnemyEquip(106, 52, 0, -1, 0, -1)
    stage.setEnemyEquip(102, 55, 0, -1, 0, -1)
    stage.setEnemyEquip(113, -1, 0, 12, 0, -1)
    stage.setEnemyEquip(107, -1, 0, -1, 0, 20)
    stage.setEnemyEquip(111, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(103, -1, 0, -1, 0, 8)
    stage.loadBg(18)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab30')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab30')
    stage.draw()
    stage.bgSound(1)
    stage.unit(101).setDir(stage.countDir(101, 102))
    stage.say('&101\n봉기, 조조의 군사 상황은 어떤가요?')
    stage.unit(102).setDir(stage.countDir(102, 101))
    stage.say('&102\n조조 사슴 울타리를 지켰고,\n아직 공격 개시 조짐은 없다.')
    stage.unit(104).setDir(stage.countDir(104, 101))
    stage.say('&104\n조조 속임수에 속지 마라,\n그는 우차오 곡물 창고를 주시하고 있을 것이다.\n주군, 곡물 창고에서 경계를 강화해 주세요.\n&101\n봉기, 어떻게 생각해?\n&102\n우차오의 곡물 창고는 자연 요새입니다,\n춘위칭은 방어도 강화했다.\n문제는 없을 거라고 생각해요.\n&101\n좋아, 계획대로야.\n내일 전면 공격을 개시하라!\n&102\n만약 우리가 저 사슴 울타리를 점령할 수 있다면,\n조조 후퇴할 수밖에 없었다.')
    stage.heightLight(15, 30, 15, 30)
    stage.say('&104\n주군, 잠시만 기다려 주세요! 내가 맞았나 봐요.\n나는 조조의 성격을 아주 잘 알아,\n아군 사례도 있습니다......')
    stage.unit(101).setDir(stage.countDir(101, 104))
    stage.say('&101\n아, 정말 귀찮네요!\n지금 물러서!\n&104\n네, 네! (젠장, 후회하게 만들어 주겠다!)\n그렇다면 그냥 해보세요...... )')
    stage.unit(101).setDir(stage.countDir(101, 0))
    stage.unit(102).setDir(stage.countDir(102, 0))
    stage.unit(104).move(8, 9, 2)
    stage.unit(115).setDir(stage.countDir(115, 104))
    stage.say('&115\n이봐, 허유!\n그렇게 당황해서 어디로 급히 가고 있어?')
    stage.unit(104).setDir(stage.countDir(104, 115))
    stage.say('&104\n응...? 나 화장실 좀 다녀와야 해! 정신 조심해!\n&115\n어떻게 감히 주군 아들에게 무례할 수 있어!\n아버지께 말씀드리고 싶어요.')
    stage.unit(104).move(6, 12, 2)
    stage.unit(106).setDir(stage.countDir(106, 104))
    stage.say('&106\n허유, 이런 때에 나가?\n이제 조의 진영과 너무 가까워졌어......\n좀 더 조심해야 할 것 같아요!')
    stage.unit(104).setDir(stage.countDir(104, 106))
    stage.say('&104\n걱정해 주셔서 감사합니다!')
    stage.unit(103).setDir(stage.countDir(103, 104))
    stage.say('&103\n저 사람 뭐 하는 거야! 너무 무례하네.\n솔직히 왜 다들 이런 걸까요......')
    stage.unit(104).move(6, 17, 2)
    stage.unit(7).setDir(stage.countDir(7, 104))
    stage.say('&7\n허유, 네가 그랬구나!\n여기서 뭐 하는 거야?')
    stage.unit(104).setDir(stage.countDir(104, 7))
    stage.say('&104\n산책 좀 하러 나갔어......')
    stage.unit(104).move(8, 22, 2)
    stage.unit(107).setDir(stage.countDir(107, 104))
    stage.say('&107\n참 이상한 사람이네.')
    stage.unit(104).move(10, 26, 2)
    stage.unit(104).setAction(9)
    stage.say('&104\n하하.\n마침내, 마침내, 도착했다.\n하하.')
    stage.unit(15).setDir(stage.countDir(15, 104))
    stage.unit(104).setDir(stage.countDir(104, 15))
    stage.unit(15).setAction(5)
    stage.say('&15\n수상한 사람, 내 이름을 말해!\n안 그러면 죽여버릴 거야!')
    stage.unit(15).setAction(0)
    stage.unit(104).setAction(10)
    stage.say('&104\n기-기다려!\n나는 원소의 전략가야, 허유!\n&104\n나는 무력한 원소을 따르고 싶지 않다,\n조공을 섬기려고,\n그래서 특별히 선물을 가져왔어요.')
    stage.unit(15).setDir(stage.countDir(15, 0))
    stage.say('&15\n주군, 이 사람이 그렇게 말했어......')
    stage.unit(0).setDir(stage.countDir(0, 104))
    stage.unit(15).setDir(stage.countDir(15, 104))
    stage.say('&0\n좋아.\n할 말 있으면 빨리 말해!')
    stage.unit(104).setDir(stage.countDir(104, 0))
    stage.say('&104\n내가 가져온 선물은 위안 준에 관한 정보야,\n이것은 오직 저, 전략가로서 저만이 할 수 있는 일입니다.\n그때서야 비로소 내부 이야기를 알게 되었습니다!\n&0\n오?\n&104\n원소 내일 이곳에 전면 공격을 감행할 계획이야!\n&0\n그럼 먼저 전면 공격을 시작할까요?\n&104\n아니, 우차오의 곡창고에 기습 공격을 하는 게 여전히 최선이다.\n&0\n하지만 자연의 요새였다......\n아마도 그렇게 쉽게 잡히지는 않을 것이다......\n&104\n맞아. 하지만 사실은......\n여기 방어가 꽤 약해요......')
    stage.unit(111).setAction(10)
    stage.say('&111\n에취!\n누군가는 나를 험담할 가능성이 큽니다.\n아, 여기 있는 게 정말 지루해......\n&104\n원소 병사인 척하면,\n기습 공격은 반드시 성공할 것이다!\n&0\n흠, 알겠어요.\n&104\n원소 내부 이야기를 알면서,\n아마도 변장하기에 가장 좋은 선택이었을 것이다.\n어떻게 생각하세요?')
    sel = stage.choice('전면 공격 개시\n곡물 창고에 대한 기습 공격\n죽였허유', -1)
    if sel == 1:
        stage.say('&0\n정말 흥미로운 전략입니다.\n하지만 어떻게 보장할 수 있을까요\n이거 원소가 만든 함정 아니야?\n&104\n절대 그런 거 없어!\n다시 한 번 생각해 주세요!\n&0\n수다 떨지 마!\n내 마음속에 이미 답이 있어!\n&104\n응? 조공,\n나도 믿지 않는 거야......?\n&0\n하하하, 허저.\n허유 잘 대해야 해,\n매우 신중하게 행동하세요.\n&15\n이 일은 해결됐어. 나를 탓하지 마.\n&104\n젠장!')
        stage.unit(104).hide(1)
        stage.unit(0).setDir(0)
        stage.unit(0).setAction(5)
        stage.say('다들 전투 준비하세요! 원소를 맞이하자.')
        stage.unit(0).setAction(0)
    elif sel == 2:
        stage.say('&0\n흠......\n직접적인 대결은 확실히 최선의 전략이 아니다.\n&104\n맞아!\n&0\n좋아, 우차오를 공격해라.\n&15\n주군, 세 번 생각해 보시길 바란다,\n이 사람을 쉽게 믿을 수 없어요......\n&0\n걱정 마, 허저.\n원소 그런 방첩 계획을 절대 생각해내지 못할 것이다.\n&0\n이 사람은 원소에 불만을 품고 있었습니다,\n또한 불충한 사람이기도 합니다.\n&0\n나는 그런 사람이 필요 없다고 조조해,\n하지만 그를 도망치게 하는 건 골치 아플 거야.\n허저, 그를 가둬.\n&15\n좋아, 그게 현실이야.\n나를 탓하지 마!\n&104\n살려 주세요!')
        stage.unit(104).hide(1)
        stage.unit(0).setDir(0)
        stage.unit(0).setAction(5)
        stage.say('다들 전투 준비하세요! 오소의 곡창을 습격한다! 병사 절반은 녹암에 남아 방어하라! 반드시 우리가 곡창을 점령할 때까지 지켜야 한다!')
        stage.unit(0).setAction(0)
        stage.unit(111).setAI(2)
        stage.unit(218).setAI(2)
        stage.unit(219).setAI(2)
        vars[2] = 1
    elif sel == 3:
        stage.say('&0\n허저, 그를 내려라!\n&104\n아! 뭐라고?\n&0\n허유, 당신의 전략 정말 감사해요.\n하지만 아군 너 같은 배신자는 필요 없어!\n&15\n바로 그런 일이 일어났습니다.\n나를 탓하지 마!\n&104\n살려 주세요!')
        stage.unit(15).setAction(6)
        stage.unit(15).setAction(0)
        stage.unit(104).setAction(8)
        stage.unit(104).move(6, 6, 2)
        stage.unit(107).setDir(stage.countDir(107, 104))
        stage.unit(103).setDir(stage.countDir(103, 104))
        stage.say('&107\n뭐, 뭐라고? 허유야?\n&103\n이 사람!')
        stage.unit(101).setDir(stage.countDir(101, 104))
        stage.unit(115).setDir(stage.countDir(115, 104))
        stage.say('&115\n허유. 어디 가는 거야!')
        stage.unit(104).setDir(stage.countDir(104, 101))
        stage.unit(104).setAction(9)
        stage.say('&104\n헉, 하, 헉, 하!\n………………\n주군. 끔찍한 일이 생겼어!\n&101\n무슨 일이야? 허유!\n&104\n내 목숨을 걸고,\n조조 군대에 대한 정보를 수집했고,\n그들은 정말로 곡물 창고를 공격할 의도였다.\n&101\n캠프에 갔조조고!?\n젠장, 조조 내 준비 부족을 실제로 이용했어!\n원상! 즉시 싸울 준비해!\n&115\n네!\n아버지, 제발 저에게 맡겨주세요!\n&101\n나머지는 조조 공격을 경계했다,\n원담 동쪽의 루얀 방어를 강화하고,\n장합 고람 남쪽 사슴 요새의 방어를 강화하라!')
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.unit(310).setAI(4, -1, 28, 14)
        stage.unit(318).setAI(4, -1, 28, 14)
        stage.unit(319).setAI(4, -1, 28, 14)
        stage.unit(115).setAI(4, -1, 28, 14)
        stage.unit(214).setAI(4, -1, 28, 14)
        stage.unit(215).setAI(4, -1, 28, 14)
        stage.unit(235).setAI(4, -1, 28, 14)
        stage.unit(220).setAI(4, -1, 28, 14)
        stage.unit(221).setAI(4, -1, 28, 14)
        stage.unit(222).setAI(4, -1, 28, 14)
        stage.unit(238).setAI(4, -1, 28, 14)
        stage.unit(113).setAI(4, -1, 20, 9)
        stage.unit(212).setAI(4, -1, 20, 9)
        stage.unit(213).setAI(4, -1, 20, 9)
        stage.unit(234).setAI(4, -1, 20, 9)
        stage.unit(7).setAI(4, -1, 6, 22)
        stage.unit(7).setAI(4, -1, 6, 22)
        stage.unit(258).setAI(4, -1, 6, 22)
        stage.unit(259).setAI(4, -1, 6, 22)
        stage.unit(282).setAI(4, -1, 6, 22)
        stage.unit(107).setAI(4, -1, 8, 21)
        stage.unit(260).setAI(4, -1, 8, 21)
        stage.unit(261).setAI(4, -1, 8, 21)
        stage.unit(283).setAI(4, -1, 8, 21)
        stage.unit(15).setDir(stage.countDir(15, 0))
        stage.say('&15\n주군, 허저 무능해!\n그러나 부주의한 순간에,\n허유 도망쳤어.\n&0\n괜찮아.\n아마 자랑스럽게 말할 원소,\n그들은 우리가 반드시 곡물 창고를 공격할 거라고 했어.\n&0\n그럼 원소 반드시 곡물 창고를 지키기 위해 증원군을 보낼 거야,\n이로 인해 주 방어선이 약화되었다......\n&15\n주군 훌륭한 계획이야!\n정말 훌륭합니다!')
        vars[3] = 1
    stage.bgSound(10)
    stage.setWinCondition('승리 조건\n1. 원소 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 주요 조조가 점령되었다.\n3. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('원소를 물리쳐라!')
    stage.unit(101).heightLight()
    stage.startOper()
    vars[518] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[3] and not vars[11] and not vars[30] and stage.curCamp() == 2 and stage.round() == 3:
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.unit(101).setAction(5)
        stage.say('&101\n이제 전면 공격을 시작합시다!\n장합. 고람 네가 이끌어 있어.\n우리는 반드시 조조를 이겨야 한다!')
        stage.unit(101).setAction(0)
        stage.unit(107).setDir(stage.countDir(107, 101))
        stage.unit(7).setDir(stage.countDir(7, 101))
        stage.say('&7\n그렇죠! 장합 분명히 주군 기대에 부응할 거예요!\n&107\n좋아, 싸울 준비해!')
        stage.unit(7).setAI(4, -1, 15, 30)
        stage.unit(258).setAI(4, -1, 15, 30)
        stage.unit(259).setAI(4, -1, 15, 30)
        stage.unit(282).setAI(4, -1, 15, 30)
        vars[11] = 1
    if not vars[3] and not vars[12] and not vars[30] and stage.curCamp() == 2 and stage.round() == 4:
        stage.unit(107).setAction(5)
        stage.say('&107\n전진!\n잘해야 해!')
        stage.unit(107).setAction(0)
        stage.unit(107).setAI(4, -1, 15, 30)
        stage.unit(260).setAI(4, -1, 15, 30)
        stage.unit(261).setAI(4, -1, 15, 30)
        stage.unit(283).setAI(4, -1, 15, 30)
        vars[12] = 1
    if not vars[3] and not vars[13] and not vars[30] and stage.curCamp() == 2 and stage.round() == 5:
        stage.unit(101).setDir(stage.countDir(101, 106))
        stage.unit(106).setDir(stage.countDir(106, 101))
        stage.unit(103).setDir(stage.countDir(103, 101))
        stage.unit(101).setAction(5)
        stage.say('&101\n궈투 심배!\n한 번에 전멸시켜!')
        stage.unit(101).setAction(0)
        stage.unit(103).setAction(1)
        stage.say('&103\n우리를 지켜봐!\n조조 완전히 없애야 합니다.')
        stage.unit(106).setAction(5)
        stage.say('&106\n공격 시작!')
        stage.unit(106).setAction(0)
        stage.unit(106).setAI(4, -1, 15, 30)
        stage.unit(103).setAI(4, -1, 15, 30)
        stage.unit(216).setAI(4, -1, 15, 30)
        stage.unit(217).setAI(4, -1, 15, 30)
        stage.unit(236).setAI(4, -1, 15, 30)
        stage.unit(237).setAI(4, -1, 15, 30)
        vars[13] = 1
    if not vars[3] and not vars[14] and not vars[30] and not vars[32] and stage.round() == 8 and stage.curCamp() == 2:
        stage.unit(101).setDir(stage.countDir(101, 113))
        stage.say('&101\n원상. 원담, 괜찮아.\n가서 싸워서 네 흔적을 남겨라!')
        stage.unit(113).setDir(stage.countDir(113, 101))
        stage.say('&113\n아버지, 성취를 이루고 돌아오는 모습을 봅시다!')
        stage.unit(115).setDir(stage.countDir(115, 101))
        stage.say('&115\n네, 아버지.\n아이는 즉시 전투에 나섰다.')
        stage.unit(115).setAI(4, -1, 15, 30)
        stage.unit(113).setAI(4, -1, 15, 30)
        stage.unit(212).setAI(4, -1, 15, 30)
        stage.unit(213).setAI(4, -1, 15, 30)
        stage.unit(214).setAI(4, -1, 15, 30)
        stage.unit(215).setAI(4, -1, 15, 30)
        stage.unit(234).setAI(4, -1, 15, 30)
        stage.unit(235).setAI(4, -1, 15, 30)
        vars[14] = 1
    if vars[3] and not vars[16] and not vars[30] and stage.curCamp() == 2 and stage.round() == 4:
        stage.unit(7).setAI(0)
        stage.unit(107).setAI(0)
        stage.unit(258).setAI(0)
        stage.unit(259).setAI(0)
        stage.unit(260).setAI(0)
        stage.unit(261).setAI(0)
        stage.unit(282).setAI(0)
        stage.unit(283).setAI(0)
        vars[16] = 1
    if vars[3] and not vars[15] and not vars[30] and stage.curCamp() == 2 and stage.round() == 9:
        stage.unit(115).setAI(0)
        stage.unit(113).setAI(0)
        stage.unit(212).setAI(0)
        stage.unit(213).setAI(0)
        stage.unit(214).setAI(0)
        stage.unit(215).setAI(0)
        stage.unit(234).setAI(0)
        stage.unit(235).setAI(0)
        vars[15] = 1
    if not vars[20] and stage.isInPos(1026, 15, 30):
        vars[20] = 1
        stage.resumeCtrl()
        stage.unit(101).setDir(2)
        stage.unit(101).setAction(1)
        stage.say('&101\n하하하!\n조조의 주 진영을 점령했다.')
        stage.talk(1, 186, '주군, 우리의 주요 사업!\n본진이 점령됐어......!')
        stage.unit(0).setDir(stage.countDir(0, 101))
        stage.unit(0).setAction(4)
        stage.say('&0\n너무 부주의했어......')
        stage.info('조조 원소에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if not vars[21] and stage.isInPos(1025, 6, 8):
        stage.getItem(151, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 6, 19):
        stage.getItem(151, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 19, 8):
        stage.getItem(151, 0, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 27, 12):
        stage.getItem(152, 0, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 28, 14):
        stage.getItem(152, 0, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 3, 6):
        stage.getItem(150, 0, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 3, 11):
        stage.getItem(150, 0, True, 1025)
        vars[27] = 1
    if not vars[28] and stage.isInPos(1025, 6, 7):
        stage.getItem(150, 0, True, 1025)
        vars[28] = 1
    if not vars[6] and stage.totalRectUnit(2, 26, 11, 29, 15) == 0:
        stage.unit(101).setDir(1)
        stage.unit(101).setAction(4)
        stage.say('&101\n뜻밖에도 우차오의 곡창고가 사라졌다......\n이건 정말 골칫거리입니다.')
        if not vars[53]:
            stage.say('&103\n뜻밖에도 중요한 군사 보급품이\n결국 적군가 가져갔어요!\n춘위궁은 도대체 뭘 하고 있는 거야!\n하아, 두세 명이면 궈투가 버틸 수 있어!')
        if not vars[54]:
            stage.say('&106\n병사들은 ......에서 흔들리기 시작했다!\n좋지 않아!')
        stage.setUnitStatus([
            {
                'status': 1,
                'lift': 0,
                'x1': 0,
                'y1': 0,
                'x2': 32,
                'y2': 32,
                'camp': 2 }])
        vars[6] = 1
    if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 0, 14, 15):
        stage.unit(101).setAction(10)
        stage.say('&101\n경비원들은 뭐 하는 거야!?')
        stage.unit(113).setAI(3, 101, 0, 0)
        stage.unit(115).setAI(3, 101, 0, 0)
        stage.unit(212).setAI(3, 101, 0, 0)
        stage.unit(213).setAI(3, 101, 0, 0)
        stage.unit(214).setAI(3, 101, 0, 0)
        stage.unit(215).setAI(3, 101, 0, 0)
        stage.unit(220).setAI(3, 101, 0, 0)
        stage.unit(221).setAI(3, 101, 0, 0)
        stage.unit(234).setAI(3, 101, 0, 0)
        stage.unit(235).setAI(3, 101, 0, 0)
        stage.unit(238).setAI(3, 101, 0, 0)
        stage.unit(298).setAI(1)
        stage.unit(299).setAI(1)
        if vars[3] and not vars[31] and not vars[52]:
            stage.unit(101).setDir(stage.countDir(101, 104))
            stage.say('&101\n야, 허유, 무슨 일이야!\n조조 우차오의 곡물 창고에 간 적이 없어!')
            stage.unit(104).setDir(stage.countDir(104, 101))
            stage.say('&104\n응? 이거, 이거......\n&101\n조조에게 너무 쉽게 속았다,\n왜 아직도 전략가야?\n정말 뻔뻔하군요!')
            stage.unit(104).setAction(4)
            stage.say('&104\n………')
            stage.unit(104).setAI(3, 0, 0, 0)
        vars[30] = 1
    if not vars[31] and stage.isInRect(1025, 23, 8, 31, 18):
        vars[31] = 1
    if vars[2] and not vars[32] and not vars[59] and stage.isInRect(1025, 26, 11, 29, 15):
        stage.unit(111).setAction(8)
        stage.say('&111\n응? 조조 침입했어!\n도대체 무슨 일이 벌어지고 있는 거죠?\n내가 기습당한 거야!?')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 26,
                'y1': 11,
                'x2': 29,
                'y2': 15,
                'camp': 2 }])
        stage.unit(101).setDir(stage.countDir(101, 111))
        stage.unit(101).setAction(5)
        stage.say('&101\n뭐라고! 우차오 곡창이 공격당했다고?\n춘위궁은 어떻게 해냈지!\n&101\n젠장조조!\n서둘러 증원군을 보내라,\n무슨 일이 있어도 반드시 지켜야 해!')
        stage.unit(101).setAction(0)
        stage.unit(220).setAI(4, -1, 28, 14)
        stage.unit(221).setAI(4, -1, 28, 14)
        stage.unit(222).setAI(4, -1, 28, 14)
        stage.unit(238).setAI(4, -1, 28, 14)
        if not vars[55]:
            stage.unit(7).setDir(stage.countDir(7, 111))
            stage.say('&7\n(뜻밖에도 그들은 우차오의 곡물 창고를 성공적으로 공격했다,\n조조 소문보다 더 강력한 존재가 될 수 있을까......? )')
        if not vars[56]:
            stage.unit(107).setDir(stage.countDir(107, 111))
            stage.say('&107\n까마귀 둥지가 공격당했다고!?')
        vars[32] = 1
    if vars[2] and not vars[23] and not vars[33] and stage.curCamp() == 2 and stage.isInRect(1025, 17, 6, 21, 10):
        stage.unit(101).setDir(1)
        stage.say('&101\n뭐라고! 적이 동쪽 사슴 요새에 도달했다고?\n음음 흠흠, 젠장it조조......')
        if not vars[14] and not vars[58]:
            stage.unit(101).setDir(stage.countDir(101, 115))
            stage.say('&101\n원상, 즉시 구하러 가!\n만약 그 사슴 요새가 무너진다면,\n주요 사업장도 위험에 처했어!')
            stage.unit(115).setDir(stage.countDir(115, 101))
            stage.say('&115\n아버지, 제발 저에게 맡겨주세요!\n기대에 부응할 거예요!')
            stage.unit(115).setAI(4, -1, 19, 8)
            stage.unit(214).setAI(4, -1, 19, 8)
            stage.unit(215).setAI(4, -1, 19, 8)
            stage.unit(235).setAI(4, -1, 19, 8)
        vars[33] = 1
    if not vars[40] and stage.isNear(0, 101, True):
        stage.unit(0).setDir(stage.countDir(0, 101))
        stage.unit(101).setDir(stage.countDir(101, 0))
        stage.say('&0\n원소, 이번엔 절대 그냥 두지 않을 거야!\n&101\n항상 전투에서 지는 걸 어떻게 참겠어!')
        vars[40] = 1
    if vars[32] and not vars[41] and stage.isNear(0, 7, False):
        stage.unit(0).setDir(stage.countDir(0, 7))
        stage.unit(7).setDir(stage.countDir(7, 0))
        stage.say('&0\n너 장합 아니야!\n당신의 명성도 조금 들었어요!\n&7\n그러니까 당신이 조공이군요?\n잠깐 장합 있을게!')
        stage.attackAction(7, 0, 2)
        stage.delay(10)
        stage.attackAction(7, 0, 2)
        stage.delay(10)
        stage.say('&7\n그의 무술 실력은 정말 뛰어납니다!\n그는 평범한 사람이 아닌 것 같다.\n&0\n정말 만족스러워요!\n장합, 나를 섬길 수 있겠어?\n&7\n나를 설득하려는 거야?\n저는 불충하거나 불의로운 사람이 장합 아닙니다.')
        vars[41] = 1
    if vars[32] and not vars[42] and stage.isNear(0, 107, False):
        stage.unit(0).setDir(stage.countDir(0, 107))
        stage.unit(107).setDir(stage.countDir(107, 0))
        stage.say('고람, 네 실력으로 나를 이길 수 없을걸! 뭐? 조조라고!? 적군 주장이 내 눈앞에!? 너가 허점을 보였어!')
        stage.attackAction(0, 107, 1)
        stage.delay(10)
        stage.unit(107).setAction(4)
        stage.say('&107\n좋지 않아! 와!\n&0\n전장에 있는 모든 장군,\n침착함을 유지해야 한다,\n그의 지휘원소 뛰어난 장군이 없는 것 같습니다.')
        stage.unit(107).hide(2)
        stage.getItem(127, 0)
        vars[56] = 1
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 106, True):
        stage.unit(0).setDir(stage.countDir(0, 106))
        stage.unit(106).setDir(stage.countDir(106, 0))
        stage.say('&0\n심배, 대부분의 실패원소,\n너 같은 부하 때문이야.\n하하하.\n&106\n칭찬 감사합니다!\n절대 용서하지 않을 거야, 조조!')
        vars[43] = 1
    if not vars[44] and stage.isNear(15, 101, True):
        stage.unit(15).setDir(stage.countDir(15, 101))
        stage.unit(101).setDir(stage.countDir(101, 15))
        stage.say('&15\n원소, 오늘 네 인생은 끝이야!\n&101\n헛소리 그만해!')
        vars[44] = 1
    if not vars[45] and stage.isNear(15, 113, True):
        stage.unit(15).setDir(stage.countDir(15, 113))
        stage.unit(113).setDir(stage.countDir(113, 15))
        stage.say('&15\n흥, 쓸모없는 녀석!\n&113\n뭐라고? 사람들을 깔보지 마!\n내가 얼마나 강한지 보여줄게!')
        vars[45] = 1
    if not vars[46] and stage.isNear(15, 115, True):
        stage.unit(15).setDir(stage.countDir(15, 115))
        stage.unit(115).setDir(stage.countDir(115, 15))
        stage.say('&15\n야, 이 자식아!\n이기기 힘들지, 네 아버지한테서 물려받은 거겠지?\n&115\n뭐라고! 감히 어떻게 그럴 수 있어!')
        vars[46] = 1
    if not vars[47] and stage.isNear(15, 7, False):
        stage.unit(15).setDir(stage.countDir(15, 7))
        stage.unit(7).setDir(stage.countDir(7, 15))
        stage.say('&15\n장합, 나랑 경쟁하자!\n&7\n하하, 꽤 힘이 있는 것 같네요.\n하지만 말씀드리자면,\n무력으로는 나를 이길 수 없어.')
        fight = stage.startFight(15, 7, 5)
        fight.showUnit(True, '어서, 장합!\n한 번에 끝장내주마!', 10)
        fight.showUnit(False, "소위 '사나운 돼지 타입 장군'은 너 같은 사람이야.\n오늘은 멧돼지를 잡게 해줘.\n목숨을 내놓아!", 0)
        fight.showStart()
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        stage.delay(5)
        fight.setAction(True, 2)
        fight.say(True, '멈춰!\n도망치고 싶어?', True)
        fight.setAction(False, 1)
        fight.say(False, '하하하!\n정말 속았다!\n내 묘기를 써!', True)
        fight.attack1(False, 3, True)
        fight.say(True, '뭐라고!\n휴, 아슬아슬했어요!', True)
        stage.delay(5)
        fight.setAction(False, 0)
        fight.say(False, '뭐-뭐라고!\n피했어?\n이 사람은 내가 상상했던 것보다 훨씬 민첩하다.', True)
        fight.setAction(True, 8)
        fight.say(True, '화살을 쏠 수 있는 자는 항상 이 속임수를 쓰게 됩니다.\n난 속지 않을 거야!', True)
        fight.setAction(False, 8)
        stage.delay(5)
        fight.say(False, '음음!\n이번엔 꼭 죽여버릴 거야!', True)
        fight.say(True, '이봐, 잠깐만!\n이제 내 차례야?\n내 수를 가져가!', True)
        fight.attack1(True, 1, False)
        fight.say(False, '어!? 저-저게 뭐야!?\n깃털 달린 화살도 없고!?', True)
        fight.say(True, '난 아직 싸울 수 있어!', True)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(True, 0, True)
        fight.setAction(False, 11)
        fight.say(False, '와!\n아-아, 안 돼!', True)
        fight.setAction(True, 8)
        fight.say(True, '맞아!', True)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.setAction(False, 11)
        stage.delay(5)
        fight.setAction(True, 6)
        fight.say(True, '야, 우리가 이겼어!', True)
        fight.say(False, '네게 패배했으니 할 말이 없어.', True)
        fight.say(False, '하지만 결국 나는 장군이니까,\n자비를 구걸하지 않겠습니다.\n빨리 날 죽여!', True)
        stage.delay(10)
        fight.say(True, '……………', True)
        fight.say(False, '무슨 일이야?!\n빨리 시작하세요!', True)
        stage.delay(10)
        fight.setAction(True, 0)
        fight.say(True, '장군장합, 우리 집안 주군에도 합류하지?\n재능 있는 사람은 항상 잘 대우받아,\n네 실력은 문제가 되지 않을 거야.', True)
        fight.say(False, '……。', True)
        fight.say(True, '바로 대답할 필요 없어.\n하지만 신중히 생각하는 게 최선이야.', False)
        fight.setAction(True, 1)
        fight.say(True, '이제 제발 먼저 전장을 떠나!', True)
        stage.delay(5)
        fight.say(False, '네가 그렇게 말했으니......\n생각해볼게.', True)
        stage.delay(5)
        fight.setAction(False, 13)
        stage.delay(5)
        fight.setAction(True, 8)
        fight.say(True, '그를 해고해야 할지 확신이 서지 않나요?\n주군 동의할 것 같아요.\n결국 상대방은 강한 사람이었으니까요.', True)
        fight.end()
        stage.unit(7).hide()
        vars[55] = 1
        vars[718] = 1
        vars[47] = 1
    if vars[3] and not vars[48] and stage.isNear(0, 104, True):
        stage.unit(0).setDir(stage.countDir(0, 104))
        stage.unit(104).setDir(stage.countDir(104, 0))
        stage.say('&0\n너희 같은 사람들, 친구와 적 사이를 흔들며,\n정말 뻔뻔하군요!\n&104\n다 네 잘못이야!\n절대 그냥 두지 않을 거야!')
        vars[48] = 1
    if not vars[50] and stage.unitStateTest(101, 7, 0, 2):
        stage.say('&101\n또 패배했다.\n왜 언제든 이길 수 없는 soon조조......\n후퇴.')
        stage.unit(101).hide(1)
        stage.setRectUnitHide(0, 0, 31, 31, 2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(102, 7, 0, 2):
        stage.say('&102\n후퇴, 빨리 후퇴!')
        stage.unit(102).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(104, 7, 0, 2):
        stage.say('&104\n왜 그럴까요?\n아직 죽고 싶지 않아......')
        stage.unit(104).hide(2)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(103, 7, 0, 2):
        stage.say('&103\n어떻게 질 수 있겠어......\n정말 증오스럽다.\n후퇴!')
        stage.unit(103).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(106, 7, 0, 2):
        stage.say('&106\n이건 너무 위험해.\n먼저 후퇴하자......')
        stage.unit(106).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(7, 7, 0, 2):
        stage.say('&7\n진심으로 너무 늦게 후회하고 있어......\n뜻밖에도 그는 붙잡혔다......')
        stage.unit(7).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(107, 7, 0, 2):
        stage.say('&107\n와!\n너무 부주의했어......\n정말 받아들일 수 없어요......')
        stage.unit(107).hide(2)
        stage.getItem(127, 0, True, 1027)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(113, 7, 0, 2):
        stage.say('&113\n후퇴.\n도둑조조Old, 이걸 명심해!"')
        stage.unit(113).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(115, 7, 0, 2):
        stage.say('&115\n아버지와 아이가 먼저 물러났어.')
        stage.unit(115).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(111, 7, 0, 2):
        stage.say('&111\n뜻밖에도 조조가 우차오를 공격했다......\n일찍 알았더라면 곡물 창고를 지키러 오지 않았을 텐데.')
        stage.unit(111).hide(2)
        stage.getItem(118, 0, True, 1027)
        vars[59] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 격퇴했어.\n아군 이겼어!')
        stage.reward(0, [
            48,
            -1])
        stage.end()
        vars[0] = 1
        vars[618] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원소에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
