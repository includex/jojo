# Source Generated with Decompyle++
# File: R_57.marshal (Python 3.9)


def scene0():
    '''최후 결전'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(0)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setEventName('최후 결전')
    stage.setStageName('우장평원 조조 본진')
    stage.delay(3)
    stage.showUnit(151, 54, 22, 2)
    stage.delay(3)
    stage.say('&151\n…… 총리님.')
    stage.unit(0).setAction(3)
    stage.say('&0\n오, 쉬슈, 드디어 왔구나!')
    stage.unit(0).setAction(0)
    stage.unit(151).move(54, 64, 2)
    stage.delay(3)
    stage.unit(151).setAction(6)
    stage.say('&151\n위안즈는 지하로 이어지는 비밀 통로를 발견했다,\n즉시 병력을 보내 추격하라공명.')
    stage.unit(0).setAction(3)
    stage.say('&0\n그래요! 여기서 감사드립니다.\n이번에는 진짜로 위안즈의 든든한 지원 덕분이에요.')
    stage.unit(0).setAction(0)
    stage.say('&151\n위안즈는 두려움에 떨었다......')
    stage.unit(151).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n좋아.\n그는 말을 타고 공명를 추격했다.\n이게 마지막 결전이니 모두 조심해야 해!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(151).setAction(6)
    stage.say('&151\n총리님, 원지는 물러나셨습니다......\n&0\n흠.\n이번에는 당신 덕분이에요.\n&151\n어떻게 감히 그럴 수 있겠습니까? 마도 총리님의 성공과 성공을 기원합니다.')
    stage.unit(151).setAction(0)
    stage.say('&151\n(내 friend공명......\n이제 나는 네가 죽길 바란다.\n나를 미워할 거야......? )')
    stage.delay(5)
    stage.unit(151).setAction(0, 1)
    stage.say('&151\n(아니...... 아마 날 탓하지 않을 거야.\n만약 당신이 정말 여전히 당신이라면,\n그는 분명히 제가 하는 모든 일에 동의할 거예요. )')
    stage.delay(5)
    stage.unit(151).setAction(0, 0)
    stage.say('&151\n(내 friend공명......\n진심으로 하늘에 기도하겠습니다,\n그저 당신이 평안히 쉬길 바랄 뿐입니다. )')
    stage.unit(151).move(54, 22, 0)
    stage.unit(151).hide()
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 57
    stage.setBattlePos([
        [
            21,
            19],
        [
            18,
            18],
        [
            18,
            21],
        [
            21,
            20],
        [
            21,
            18],
        [
            21,
            21],
        [
            20,
            19],
        [
            20,
            20],
        [
            20,
            18],
        [
            20,
            21],
        [
            19,
            19],
        [
            19,
            20],
        [
            19,
            18],
        [
            19,
            21],
        [
            18,
            19]])
    return False


def scene1():
    if stage.battleTest():
        stage.say('&0\n출발!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n아군 지하 전장의 상황에 대해 아무것도 몰랐다,\n조심만 하면 분명히 이길 수 있습니다.\n&0\n흠.')
    if stage.unitClickTest(19):
        stage.say('&19\n공명......\n이 상황에서 너랑 싸우고 싶지 않아.')
    if stage.unitClickTest(23):
        stage.say('&23\n왜 제단공명 지하에 지었나요?\n그럴 수도 있......\n&0\n…… 지하에는 태양이 결코 비치지 않는 곳이야,\n아마도 이곳이 죽은 자들이 나타나기에 가장 적합한 장소일지도 모른다.\n&23\n특히 조심해야 할 것 같주군.')
    if stage.unitClickTest(1):
        stage.say('&1\n더 이상 할 말 없어.\n승리는 분명히 우리 몫일 거야.')
    if stage.unitClickTest(3):
        stage.say('&3\n우리가 이 싸움에서 이기만 한다면,\n그는 형이 관에게 맡긴 미래를 볼 수 있었다.')
    if stage.unitClickTest(17):
        stage.say('&17\n(아버지, 어머니, 기다려 주세요,\n이것이 마지막 전투가 될 것이다.\n봉선...... 힘을 주소서...... )\n&0\n무슨 일이야? 초선.\n&17\n응? 아니, 아무것도 아니야.\n총리님, 명령을 내리십시오.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
