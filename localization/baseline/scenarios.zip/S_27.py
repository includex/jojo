# Source Generated with Decompyle++
# File: S_27.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        2,
        91])
    stage.nearEvent([
        0,
        77,
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 210,
            'x': 5,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 0 },
        {
            'id': 211,
            'x': 13,
            'y': 19,
            'lv': 0,
            'ai': 1,
            'i': 1 },
        {
            'id': 212,
            'x': 9,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 213,
            'x': 18,
            'y': 19,
            'lv': 0,
            'ai': 1,
            'i': 3 },
        {
            'id': 214,
            'x': 18,
            'y': 23,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 215,
            'x': 18,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 216,
            'x': 18,
            'y': 31,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 217,
            'x': 26,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 234,
            'x': 9,
            'y': 23,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 235,
            'x': 5,
            'y': 31,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 236,
            'x': 13,
            'y': 23,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 237,
            'x': 13,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 238,
            'x': 13,
            'y': 31,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 239,
            'x': 22,
            'y': 23,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 240,
            'x': 22,
            'y': 27,
            'lv': 0,
            'ai': 1,
            'i': 14 },
        {
            'id': 241,
            'x': 26,
            'y': 31,
            'lv': 0,
            'ai': 1,
            'i': 15 }])
    stage.createEnemy([
        {
            'id': 91,
            'x': 3,
            'y': 35,
            'dir': 1,
            'lv': 6,
            'i': 0 },
        {
            'id': 86,
            'x': 4,
            'y': 36,
            'dir': 1,
            'lv': 6,
            'i': 1 },
        {
            'id': 94,
            'x': 5,
            'y': 36,
            'dir': 1,
            'lv': 4,
            'i': 2 },
        {
            'id': 89,
            'x': 2,
            'y': 36,
            'dir': 1,
            'lv': 4,
            'i': 3 },
        {
            'id': 87,
            'x': 3,
            'y': 36,
            'dir': 1,
            'lv': 4,
            'i': 4 },
        {
            'id': 406,
            'x': 5,
            'y': 35,
            'dir': 1,
            'lv': 0,
            'i': 5 },
        {
            'id': 407,
            'x': 4,
            'y': 35,
            'dir': 1,
            'lv': 0,
            'i': 6 },
        {
            'id': 408,
            'x': 2,
            'y': 35,
            'dir': 1,
            'lv': 0,
            'i': 7 },
        {
            'id': 84,
            'hide': 1,
            'x': 29,
            'y': 24,
            'dir': 0,
            'lv': 6,
            'i': 8 },
        {
            'id': 95,
            'hide': 1,
            'x': 30,
            'y': 23,
            'dir': 0,
            'lv': 6,
            'i': 9 },
        {
            'id': 80,
            'hide': 1,
            'x': 29,
            'y': 25,
            'dir': 0,
            'lv': 6,
            'i': 10 },
        {
            'id': 358,
            'hide': 1,
            'x': 30,
            'y': 24,
            'dir': 0,
            'lv': 0,
            'i': 11 },
        {
            'id': 85,
            'hide': 1,
            'x': 0,
            'y': 21,
            'dir': 0,
            'lv': 6,
            'i': 12 },
        {
            'id': 93,
            'hide': 1,
            'x': 1,
            'y': 22,
            'dir': 0,
            'lv': 4,
            'i': 13 },
        {
            'id': 82,
            'hide': 1,
            'x': 2,
            'y': 22,
            'dir': 0,
            'lv': 4,
            'i': 14 },
        {
            'id': 359,
            'hide': 1,
            'x': 1,
            'y': 23,
            'dir': 0,
            'lv': 0,
            'i': 15 },
        {
            'id': 76,
            'hide': 1,
            'x': 6,
            'y': 39,
            'dir': 1,
            'lv': 6,
            'i': 16 },
        {
            'id': 81,
            'hide': 1,
            'x': 7,
            'y': 39,
            'dir': 1,
            'lv': 6,
            'i': 17 },
        {
            'id': 78,
            'hide': 1,
            'x': 5,
            'y': 39,
            'dir': 1,
            'lv': 6,
            'i': 18 },
        {
            'id': 360,
            'hide': 1,
            'x': 6,
            'y': 39,
            'dir': 1,
            'lv': 0,
            'i': 19 },
        {
            'id': 361,
            'hide': 1,
            'x': 7,
            'y': 39,
            'dir': 1,
            'lv': 0,
            'i': 20 },
        {
            'id': 362,
            'hide': 1,
            'x': 5,
            'y': 39,
            'dir': 1,
            'lv': 0,
            'i': 21 },
        {
            'id': 77,
            'hide': 1,
            'x': 19,
            'y': 39,
            'dir': 1,
            'lv': 6,
            'i': 22 },
        {
            'id': 98,
            'hide': 1,
            'x': 20,
            'y': 39,
            'dir': 1,
            'lv': 6,
            'i': 23 },
        {
            'id': 83,
            'hide': 1,
            'x': 18,
            'y': 39,
            'dir': 1,
            'lv': 4,
            'i': 24 },
        {
            'id': 96,
            'hide': 1,
            'x': 19,
            'y': 39,
            'dir': 1,
            'lv': 4,
            'i': 25 },
        {
            'id': 363,
            'hide': 1,
            'x': 20,
            'y': 39,
            'dir': 1,
            'lv': 0,
            'i': 26 },
        {
            'id': 364,
            'hide': 1,
            'x': 18,
            'y': 39,
            'dir': 1,
            'lv': 0,
            'i': 27 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 16,
            'y': 21 },
        {
            'idx': 1,
            'x': 8,
            'y': 20 },
        {
            'idx': 2,
            'x': 15,
            'y': 21 },
        {
            'idx': 3,
            'x': 16,
            'y': 20 },
        {
            'idx': 4,
            'x': 25,
            'y': 22 },
        {
            'idx': 5,
            'x': 25,
            'y': 23 },
        {
            'idx': 6,
            'x': 17,
            'y': 8 },
        {
            'idx': 7,
            'x': 18,
            'y': 8 },
        {
            'idx': 8,
            'x': 7,
            'y': 10 },
        {
            'idx': 9,
            'x': 10,
            'y': 13 },
        {
            'idx': 10,
            'x': 27,
            'y': 15 },
        {
            'idx': 11,
            'x': 25,
            'y': 5 },
        {
            'idx': 12,
            'x': 9,
            'y': 19 },
        {
            'idx': 13,
            'x': 24,
            'y': 21 },
        {
            'idx': 14,
            'x': 23,
            'y': 20 }])
    stage.setEnemyEquip(77, -1, 0, -1, 0, 5)
    stage.setEnemyEquip(94, -1, 0, 14, 0, -1)
    stage.setEnemyEquip(91, -1, 0, -1, 0, 31)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.setEnemyEquip(95, -1, 0, 11, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(98, -1, 0, -1, 0, 13)
    if vars[706]:
        stage.setEnemyEquip(89, 30, 0, -1, 0, -1)
    else:
        stage.setEnemyEquip(89, 31, 0, -1, 0, -1)
    stage.loadBg(27)
    stage.setObjects(True, 27, [
        [
            1,
            4,
            26],
        [
            1,
            5,
            26],
        [
            1,
            6,
            26]])
    stage.setObject(True, 27, 1, 4, 27)
    stage.setObject(True, 27, 1, 6, 27)
    stage.setObjects(True, 27, [
        [
            1,
            4,
            28],
        [
            1,
            5,
            28],
        [
            1,
            6,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            4,
            30],
        [
            1,
            5,
            30],
        [
            1,
            6,
            30]])
    stage.setObject(True, 27, 1, 4, 31)
    stage.setObject(True, 27, 1, 6, 31)
    stage.setObjects(True, 27, [
        [
            1,
            4,
            32],
        [
            1,
            5,
            32],
        [
            1,
            6,
            32]])
    stage.setObjects(True, 27, [
        [
            1,
            8,
            22],
        [
            1,
            9,
            22],
        [
            1,
            10,
            22]])
    stage.setObject(True, 27, 1, 8, 23)
    stage.setObject(True, 27, 1, 10, 23)
    stage.setObjects(True, 27, [
        [
            1,
            8,
            24],
        [
            1,
            9,
            24],
        [
            1,
            10,
            24]])
    stage.setObjects(True, 27, [
        [
            1,
            8,
            26],
        [
            1,
            9,
            26],
        [
            1,
            10,
            26]])
    stage.setObject(True, 27, 1, 8, 27)
    stage.setObject(True, 27, 1, 10, 27)
    stage.setObjects(True, 27, [
        [
            1,
            8,
            28],
        [
            1,
            9,
            28],
        [
            1,
            10,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            12,
            18],
        [
            1,
            13,
            18],
        [
            1,
            14,
            18]])
    stage.setObject(True, 27, 1, 12, 19)
    stage.setObject(True, 27, 1, 14, 19)
    stage.setObjects(True, 27, [
        [
            1,
            12,
            20],
        [
            1,
            13,
            20],
        [
            1,
            14,
            20]])
    stage.setObjects(True, 27, [
        [
            1,
            12,
            22],
        [
            1,
            13,
            22],
        [
            1,
            14,
            22]])
    stage.setObject(True, 27, 1, 12, 23)
    stage.setObject(True, 27, 1, 14, 23)
    stage.setObjects(True, 27, [
        [
            1,
            12,
            24],
        [
            1,
            13,
            24],
        [
            1,
            14,
            24]])
    stage.setObjects(True, 27, [
        [
            1,
            12,
            26],
        [
            1,
            13,
            26],
        [
            1,
            14,
            26]])
    stage.setObject(True, 27, 1, 12, 27)
    stage.setObject(True, 27, 1, 14, 27)
    stage.setObjects(True, 27, [
        [
            1,
            12,
            28],
        [
            1,
            13,
            28],
        [
            1,
            14,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            12,
            30],
        [
            1,
            13,
            30],
        [
            1,
            14,
            30]])
    stage.setObject(True, 27, 1, 12, 31)
    stage.setObject(True, 27, 1, 14, 31)
    stage.setObjects(True, 27, [
        [
            1,
            12,
            32],
        [
            1,
            13,
            32],
        [
            1,
            14,
            32]])
    stage.setObjects(True, 27, [
        [
            1,
            17,
            18],
        [
            1,
            18,
            18],
        [
            1,
            19,
            18]])
    stage.setObject(True, 27, 1, 17, 19)
    stage.setObject(True, 27, 1, 19, 19)
    stage.setObjects(True, 27, [
        [
            1,
            17,
            20],
        [
            1,
            18,
            20],
        [
            1,
            19,
            20]])
    stage.setObjects(True, 27, [
        [
            1,
            17,
            22],
        [
            1,
            18,
            22],
        [
            1,
            19,
            22]])
    stage.setObject(True, 27, 1, 17, 23)
    stage.setObject(True, 27, 1, 19, 23)
    stage.setObjects(True, 27, [
        [
            1,
            17,
            24],
        [
            1,
            18,
            24],
        [
            1,
            19,
            24]])
    stage.setObjects(True, 27, [
        [
            1,
            17,
            26],
        [
            1,
            18,
            26],
        [
            1,
            19,
            26]])
    stage.setObject(True, 27, 1, 17, 27)
    stage.setObject(True, 27, 1, 19, 27)
    stage.setObjects(True, 27, [
        [
            1,
            17,
            28],
        [
            1,
            18,
            28],
        [
            1,
            19,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            17,
            30],
        [
            1,
            18,
            30],
        [
            1,
            19,
            30]])
    stage.setObject(True, 27, 1, 17, 31)
    stage.setObject(True, 27, 1, 19, 31)
    stage.setObjects(True, 27, [
        [
            1,
            17,
            32],
        [
            1,
            18,
            32],
        [
            1,
            19,
            32]])
    stage.setObjects(True, 27, [
        [
            1,
            21,
            22],
        [
            1,
            22,
            22],
        [
            1,
            23,
            22]])
    stage.setObject(True, 27, 1, 21, 23)
    stage.setObject(True, 27, 1, 23, 23)
    stage.setObjects(True, 27, [
        [
            1,
            21,
            24],
        [
            1,
            22,
            24],
        [
            1,
            23,
            24]])
    stage.setObjects(True, 27, [
        [
            1,
            21,
            26],
        [
            1,
            22,
            26],
        [
            1,
            23,
            26]])
    stage.setObject(True, 27, 1, 21, 27)
    stage.setObject(True, 27, 1, 23, 27)
    stage.setObjects(True, 27, [
        [
            1,
            21,
            28],
        [
            1,
            22,
            28],
        [
            1,
            23,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            25,
            26],
        [
            1,
            26,
            26],
        [
            1,
            27,
            26]])
    stage.setObject(True, 27, 1, 25, 27)
    stage.setObject(True, 27, 1, 27, 27)
    stage.setObjects(True, 27, [
        [
            1,
            25,
            28],
        [
            1,
            26,
            28],
        [
            1,
            27,
            28]])
    stage.setObjects(True, 27, [
        [
            1,
            25,
            30],
        [
            1,
            26,
            30],
        [
            1,
            27,
            30]])
    stage.setObject(True, 27, 1, 25, 31)
    stage.setObject(True, 27, 1, 27, 31)
    stage.setObjects(True, 27, [
        [
            1,
            25,
            32],
        [
            1,
            26,
            32],
        [
            1,
            27,
            32]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab156')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab156')
    stage.draw()
    stage.bgSound(10)
    stage.unit(238).setDir(stage.countDir(238, 0))
    stage.say('&238\n주군, 황가이 장군과 곡물 수송선이 이미 도착했다,\n이제 도킹을 요청합니다.\n&0\n그럼 내가 따뜻하게 환영한다고 전해줘.')
    stage.unit(238).setDir(2)
    stage.unit(406).move(10, 35, 1)
    stage.unit(407).move(9, 35, 1)
    stage.unit(91).move(8, 35, 1)
    stage.unit(408).move(7, 35, 1)
    stage.unit(94).move(10, 36, 1)
    stage.unit(86).move(9, 36, 1)
    stage.unit(87).move(8, 36, 1)
    stage.unit(89).move(7, 36, 1)
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n주군, 그 배는 매우 수상해.\n불 공격 냄새가 거의 나는 듯했다!\n&22\n황가이의 지위가 아무리 높아도,\n군대의 함선과 함선을 동원하는 것은 어려울 것이다,\n따라서 이 항복은 주유의 지시에 따른 것임에 틀림없다.')
    stage.unit(21).setDir(stage.countDir(21, 0))
    stage.say('&21\n주군Please 저 배를 봐,\n물 흐름이 얕지 않나요?\n&21\n만약 배에 정말로 곡물이 실려 있다면,\n아주 깊어야 해,\n저는 그 배가 화약일 가능성이 매우 높다고 생각합니다.\n&0\n그럼 계획대로 하자.\n&22\n대부분의 함선은 화재 대비 상태입니다,\n병사들도 고도의 경계 태세에 들어갔다.\n걱정 마세요, 주군.\n&21\n나는 적의 매복이 더 걱정된다,\n하지만 우리가 준비되어 있었으니,\n설령 정말로 매복이 있었다 해도, 그것은 위협이 되지 않을 것이다.\n&0\n잘 말씀하셨습니다.\n때가 되면 매복에 신경 쓰지 마라,\n첫째, 적의 주력 부대를 제거하세요.\n&91\n마침내 적이 보인다,\n적군 물 요새로 돌진하라!')
    stage.unit(406).move(10, 32, 0)
    stage.unit(407).move(9, 31, 0)
    stage.unit(91).move(8, 31, 0)
    stage.unit(408).move(8, 32, 0)
    stage.unit(94).move(10, 33, 0)
    stage.unit(86).move(9, 32, 0)
    stage.unit(87).move(9, 33, 0)
    stage.unit(89).move(8, 33, 0)
    stage.unit(86).setAction(5)
    stage.say('&86\n돌격! 서둘러!\n불 붙여, 불붙여, 돌진해!\n헤헤헤.')
    stage.unit(86).setAction(0)
    stage.unit(407).move(9, 29, 0)
    stage.setObject(True, 27, 2, 9, 28)
    stage.unit(407).hide(1)
    stage.setObject(True, 27, 2, 8, 28)
    stage.setObject(True, 27, 2, 10, 28)
    stage.unit(212).setAction(10)
    stage.say('&212\n와......\n아-아니, 이거 큰일이야!')
    stage.unit(87).setAction(5)
    stage.say('&87\n저우타이, 나도 불 피울게!\n좋아, 들어가자.\n하하하!')
    stage.unit(87).setAction(0)
    stage.unit(408).move(7, 31, 3)
    stage.setObject(True, 27, 2, 6, 31)
    stage.unit(408).hide(1)
    stage.setObject(True, 27, 2, 6, 30)
    stage.setObject(True, 27, 2, 6, 32)
    stage.unit(235).setAction(5)
    stage.say('&235\n불을 즉시 꺼라!\n이러면 불길이 더 심해질 뿐이야!')
    stage.unit(235).setAction(0)
    stage.unit(94).setAction(5)
    stage.say('&94\n저우 타이, 장친의 행동은 너무 비열해!\n우리는 반역자를 공개적으로 처벌해야 조조,\n화약선을 보내라!')
    stage.unit(94).setAction(0)
    stage.unit(406).move(11, 31, 1)
    stage.setObject(True, 27, 2, 12, 31)
    stage.unit(406).hide(1)
    stage.setObject(True, 27, 2, 12, 30)
    stage.setObject(True, 27, 2, 12, 32)
    stage.unit(238).setAction(7)
    stage.say('&238\n도와줘, 누군가 불 좀 꺼줘!')
    stage.unit(238).setAction(0)
    stage.unit(89).setDir(stage.countDir(89, 91))
    stage.say('&89\n황가이 장군, 돌격!\n매복이 이 불길을 보면 행동에 나섰다.\n즉시 돌진해!')
    stage.unit(91).setAction(5)
    stage.say('&91\n흠!\n전 군대가 수이완으로 돌진했다,\n곧장 조조로 향하고 있어.')
    stage.unit(91).setAction(0)
    stage.unit(91).move(8, 30, 0)
    stage.unit(87).move(10, 31, 0)
    stage.unit(94).move(8, 31, 0)
    stage.unit(86).move(9, 30, 0)
    stage.unit(89).move(9, 31, 0)
    stage.unit(0).setAction(5)
    stage.say('&0\n흥! 우린 함정에 빠졌어!\n유인선에 불을 질러!')
    stage.unit(0).setAction(0)
    stage.setObjects(True, 27, [
        [
            2,
            4,
            32],
        [
            2,
            5,
            32]])
    stage.setObjects(True, 27, [
        [
            2,
            13,
            32],
        [
            2,
            14,
            32]])
    stage.setObjects(True, 27, [
        [
            2,
            17,
            32],
        [
            2,
            18,
            32],
        [
            2,
            19,
            32],
        [
            2,
            19,
            31],
        [
            2,
            19,
            30]])
    stage.setObjects(True, 27, [
        [
            2,
            21,
            28],
        [
            2,
            22,
            28],
        [
            2,
            23,
            28]])
    stage.setObjects(True, 27, [
        [
            2,
            25,
            30],
        [
            2,
            25,
            31],
        [
            2,
            25,
            32],
        [
            2,
            26,
            32],
        [
            2,
            27,
            32]])
    stage.unit(85).show()
    stage.unit(93).show()
    stage.unit(82).show()
    stage.unit(359).show()
    stage.unit(85).setAction(5)
    stage.say('&85\n불이 너무 커!\n가만히 있을 수도 없어.\n돌진해!')
    stage.unit(85).setAction(0)
    stage.unit(93).setAction(5)
    stage.say('&93\n좋아! 불을 질러!\n태워조조!')
    stage.unit(93).setAction(0)
    stage.unit(82).setAction(5)
    stage.say('&82\n조조 방심하게 만들어!\n빨리 불을 지르라!')
    stage.unit(82).setAction(0)
    stage.setFires(True, [
        [
            3,
            23],
        [
            3,
            22],
        [
            3,
            21],
        [
            4,
            21]])
    stage.setFires(True, [
        [
            3,
            20],
        [
            4,
            20]])
    stage.setFires(True, [
        [
            3,
            19],
        [
            4,
            19],
        [
            5,
            19],
        [
            5,
            18],
        [
            6,
            18],
        [
            6,
            17],
        [
            7,
            17]])
    stage.unit(234).setAction(10)
    stage.say('&234\n여기도 불이 났어!?')
    stage.unit(211).setAction(5)
    stage.say('&211\n어서 적을 막아라!')
    stage.unit(211).setAction(0)
    stage.unit(84).show()
    stage.unit(95).show()
    stage.unit(80).show()
    stage.unit(358).show()
    stage.unit(84).setAction(5)
    stage.say('&84\n오, 오, 오!\n링통은 이미 불을 피우기 시작했다!\n그에게 질 수 없어, 모두들, 시작해!')
    stage.unit(84).setAction(0)
    stage.unit(95).setAction(5)
    stage.say('&95\n뒤처질 수 없어.\n시작하자.')
    stage.unit(95).setAction(0)
    stage.unit(80).setAction(5)
    stage.say("&80\n이것은 '흐름을 뒤집기 위한 싸움!'이 될 것입니다.\n그들은 절대 조조의 군대에 패배할 수 없었다.\n기회는 드물고 덧없어요!")
    stage.unit(80).setAction(0)
    stage.setFire(True, 31, 20)
    stage.setFires(True, [
        [
            30,
            19],
        [
            30,
            18],
        [
            29,
            18]])
    stage.setFires(True, [
        [
            30,
            17],
        [
            30,
            16],
        [
            30,
            15],
        [
            30,
            14],
        [
            30,
            13],
        [
            28,
            16],
        [
            28,
            15],
        [
            28,
            14],
        [
            29,
            12]])
    stage.setFires(True, [
        [
            28,
            11],
        [
            28,
            10],
        [
            28,
            9]])
    stage.say('&22\n정말로 매복을 설치한 것 같적군,\n하지만 이렇게 close아군...... 정도일 줄은 몰랐어요\n&0\n왜 이렇게 작은 병력에 신경 써야 하지!\n핵심은 주요 손권......\n운이 좋으면 그가 속아들길 바란다......')
    stage.unit(91).setDir(2)
    stage.say('&91\n흠!? 전투 상황이 좀 이상한가?\n불길이 상상만큼 강하지 않았다......\n설마...... 안 돼, 안 돼!')
    stage.unit(76).show()
    stage.unit(76).move(9, 37, 0)
    stage.unit(81).show()
    stage.unit(81).move(10, 37, 0)
    stage.unit(78).show()
    stage.unit(78).move(8, 37, 0)
    stage.unit(360).show()
    stage.unit(360).move(9, 38, 0)
    stage.unit(361).show()
    stage.unit(361).move(10, 38, 0)
    stage.unit(362).show()
    stage.unit(362).move(8, 38, 0)
    stage.say('&76\n황가이와 다른 이들이 성공한 것 같다,\n우리도 들어가자!\n&81\n네! 즉시 행진합니다.\n우리 동조조 해군의 힘을 보게 하라.\n&78\n진정으로 황가이 장군이라 불릴 만한 분이시여,\n탁월한 작업이에요,\n정말 저도 팔로우할 가치가 노숙어요!')
    stage.unit(77).show()
    stage.unit(77).move(22, 37, 0)
    stage.unit(98).show()
    stage.unit(98).move(23, 37, 0)
    stage.unit(83).show()
    stage.unit(83).move(21, 37, 0)
    stage.unit(96).show()
    stage.unit(96).move(22, 38, 0)
    stage.unit(363).show()
    stage.unit(363).move(23, 38, 0)
    stage.unit(364).show()
    stage.unit(364).move(21, 38, 0)
    stage.say('&77\n음, 정말 아름다워요!\n이 불꽃들이 하늘을 가로질러 소용돌이치고,\n내 주유 영혼을 태우고 있어.\n&98\n저우 주지사님, 시작합시다.\n&83\n손권주군도 도착했다.\n주군 앞에서 창피당할 수 없어!\n여러분, 계속하세요.\n&96\n화염 공격으로 적을 집게공 공격하세요!\n난 오래전부터 조조 당황한 얼굴을 보고 싶었어.')
    stage.unit(76).move(9, 32, 0)
    stage.unit(81).move(10, 32, 0)
    stage.unit(78).move(8, 32, 0)
    stage.unit(360).move(9, 33, 0)
    stage.unit(361).move(10, 33, 0)
    stage.unit(362).move(8, 33, 0)
    stage.unit(77).move(22, 32, 0)
    stage.unit(98).move(23, 32, 0)
    stage.unit(83).move(21, 32, 0)
    stage.unit(96).move(22, 33, 0)
    stage.unit(363).move(23, 33, 0)
    stage.unit(364).move(21, 33, 0)
    stage.unit(76).setDir(stage.countDir(76, 91))
    stage.say('&76\n황가이, 잘했어!\n이로써 동오는 구원받았다.')
    stage.unit(91).setDir(stage.countDir(91, 76))
    stage.say('&91\n주군, 뭔가 이상해!\n조조 이미 우리 계획을 간파했어요......')
    stage.unit(76).setAction(10)
    stage.say('&76\n뭐-뭐라고!\n…………\n아-아, 안 돼!')
    stage.unit(0).setAction(5)
    stage.say('&0\n손권 속았어!\n하나씩 풀리고 패배적군!\n제거손권!')
    stage.unit(0).setAction(0)
    stage.setObject(False, 13, 1, 5, 30)
    stage.setObject(False, 13, 1, 5, 28)
    stage.setObject(False, 13, 1, 10, 27)
    stage.setObject(False, 13, 1, 12, 27)
    stage.setObject(False, 13, 1, 13, 30)
    stage.setObject(False, 13, 1, 18, 30)
    stage.setObject(False, 13, 1, 19, 27)
    stage.setObject(False, 13, 1, 21, 27)
    stage.setObject(False, 13, 1, 26, 28)
    stage.setObject(False, 13, 1, 26, 30)
    stage.setObject(False, 13, 1, 23, 23)
    stage.setObject(False, 13, 1, 17, 23)
    stage.setObject(False, 13, 1, 17, 19)
    stage.setObject(False, 13, 1, 14, 19)
    stage.setObject(False, 13, 1, 14, 23)
    stage.setObject(False, 13, 1, 8, 23)
    stage.say('&77\n이 전투 전략은 더욱 전략적이며, 승리의 노래가 크게 불린다,\n정말 멋진 연기였어!\n이 단계가 제가 주유습니다.')
    stage.unit(76).setDir(stage.countDir(76, 0))
    stage.unit(76).setAction(5)
    stage.say('&76\n이 전투는 동우의 운명에 결정적인 역할을 했다.\n그는 반 걸음도 물러설 수 없었다.\n즉시 전군을 공격하라!')
    stage.unit(76).setAction(0)
    stage.unit(91).setAI(1)
    stage.unit(86).setAI(1)
    stage.unit(94).setAI(1)
    stage.unit(89).setAI(1)
    stage.unit(87).setAI(1)
    stage.unit(406).setAI(1)
    stage.unit(407).setAI(1)
    stage.unit(408).setAI(1)
    stage.unit(84).setAI(1)
    stage.unit(95).setAI(1)
    stage.unit(80).setAI(1)
    stage.unit(358).setAI(1)
    stage.unit(85).setAI(1)
    stage.unit(93).setAI(1)
    stage.unit(82).setAI(1)
    stage.unit(359).setAI(1)
    stage.unit(76).setAI(1)
    stage.unit(81).setAI(1)
    stage.unit(78).setAI(1)
    stage.unit(360).setAI(1)
    stage.unit(361).setAI(1)
    stage.unit(362).setAI(1)
    stage.unit(77).setAI(1)
    stage.unit(98).setAI(1)
    stage.unit(83).setAI(1)
    stage.unit(96).setAI(1)
    stage.unit(363).setAI(1)
    stage.unit(364).setAI(1)
    vars[527] = 1
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[6] and stage.totalUnit(2) >= 10 and stage.totalRectUnit(0, 0, 0, 2, 2) == 0 and stage.totalUnit(4) < 10:
        stage.say('&0\n흠, 적의 속임수를 간파할 줄은 몰랐네요.\n그리고 힘든 싸움에 직면하게 될 것이다......\n다른 방법이 없었다; 그들은 군대를 철수시키는 것을 고려해야 하는 것 같았다.')
        sel = stage.choice('전체 군대가 후퇴했다\n계속 공격해', -1)
        if sel == 1:
            stage.say('&0\n어쩔 수 없이 군대 전체가 후퇴했다!\n쉬두로 돌아가 쉬고 재충전하라!')
            stage.setWinCondition('승리 조건\n1. 북서쪽 끝에 도달조조.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(0, 0, 2, 2)
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 0))
                stage.unit(76).setAction(5)
                stage.say('&76\n빨리 쫓아가! 그를 놓칠 수 없어!')
                stage.unit(76).setAction(0)
            if not vars[53]:
                stage.unit(77).setDir(stage.countDir(77, 0))
                stage.say('&77\n원래는 병에 거북이를 잡는 극적인 게임이었는데,\n사실 이렇게 끝났어.\n저는 절대 그들이 제 주유의 미적 미학을 모욕하게 두지 않을 것입니다.')
            if not vars[51]:
                stage.unit(81).setDir(stage.countDir(81, 0))
                stage.unit(81).setAction(7)
                stage.say('&81\n뭐, 도망치려는 거야!?\n진정한 남자는 끝까지 버텨야 한다!\n조조, 마지막 순간에 도망치지 말았어야 했어!')
                stage.unit(81).setAction(0)
            vars[2] = 1
        elif sel == 2:
            stage.say('&0\n이 전투가 실패한다면,\n즉, 우리는 동우를 점령할 수 없다는 뜻이다.\n그러므로 어떤 상황에서도 승리를 쟁취해야 합니다!')
            if not vars[50]:
                stage.unit(76).setDir(stage.countDir(76, 0))
                stage.say('&76\n도둑조조Old, 우리 동오가 얼마나 무서운 건지 알지?')
            if not vars[53]:
                stage.unit(77).setDir(stage.countDir(77, 0))
                stage.say('&77\nNow조조 바람에 흔들리는 꺼져가는 촛불처럼,\n언제든 꺼질 수 있었다.\n&77\n나는 조조......의 마지막 순간을 목격하게 될 것 같다\n하, 나 정말 죄주유 있네, 하하하......')
            if not vars[51]:
                stage.unit(81).setDir(stage.countDir(81, 0))
                stage.unit(81).setAction(5)
                stage.say('&81\n모두 계속 나아가야 해!\n승리까지 단 한 걸음 남았다!\n우리는 조조을 제거하고 동우의 미래를 함께 만들어야 합니다!')
                stage.unit(81).setAction(0)
        vars[6] = 1
    if vars[2] and not vars[30] and stage.isInRect(0, 0, 0, 2, 2):
        stage.resumeCtrl()
        stage.say('&0\n뜻밖에도 그렇게 큰 군대가 동오에 패배할 것이다,\n동우의 힘을 정말 과소평가했어......\n이 시점에서 할 말이 없습니다......')
        vars[30] = 1
        stage.talk(1, 186, '주군, 빨리 출발해 주세요!\n그렇지 않으면 적군 다시 따라잡을 것이다.')
        stage.unit(0).setAction(5)
        stage.say('&0\n흠, 빨리 후퇴!\n무슨 일이 있어도 그는 쉬두로 돌아가야 했다!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.say('&76\n젠장, 도망쳤어......\n이 수업 끝나고 나면 잊어버려.........\n그가 다시 동우를 침략할 용기는 없을 거야!')
        if not vars[53]:
            stage.unit(77).setDir(stage.countDir(77, 0))
            stage.say('&77\n조조!\n강가에 엎드려 강물 표면을 바라본다......\n그녀 자신의 표정에는 두려움과 수치심이 가득했다.\n&77\n강물이 너를 조롱하게 놔둬......\n"참 슬프구나...... 참 안타까운 일이야...... 그렇지!\n하하하!')
        if not vars[51]:
            stage.unit(81).setDir(stage.countDir(81, 0))
            stage.unit(81).setAction(5)
            stage.say('&81\n이겼다고? 정말 이겼다고? 우리가 정말 이겼어!\n모두 잘했어! 동오의 병사들!\n우리는 동우를 방어하는 데 승리를 거두었습니다!')
            stage.unit(81).setAction(0)
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[627] = 1
        vars[727] = 0
        return True
    if not vars[40] and stage.isNear(2, 91, False):
        stage.unit(91).setDir(stage.countDir(91, 2))
        stage.unit(2).setDir(stage.countDir(2, 91))
        stage.say('&91\n꼬마야, 어디 있조조!\n&2\n이름도 있고 성도 있는데, 장료 그게 맞나요!\n노장군님, 저와 싸우게 해 주세요!')
        fight = stage.startFight(2, 91, 5)
        fight.showUnit(True, '황 장군과 겨룰 수 있다면,\n저에게는 정말 큰 영광입니다!\n이거 받아.', 9)
        fight.showUnit(False, '흠, 네가 진짜 너를 쳐다보는 게 보여!\n하지만 정말 나한테 이길 수 있겠어?', 0)
        fight.showStart()
        fight.setAction(True, 8)
        fight.say(True, '이봐!', True)
        fight.setAction(False, 8)
        fight.say(False, '야하!', True)
        fight.attack2(True, 2, True)
        stage.delay(20)
        fight.say(False, '음, 젊은이들은 꽤 유능하네요.', True)
        fight.say(False, '노인이 ......\n이미 끝난 상태였다......', True)
        fight.setAction(False, 11)
        stage.effectSound(38, 1)
        fight.death(True)
        fight.setAction(True, 1)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '이 나이에 나랑 경쟁할 장료 있어......\n조금 너무 오래된 것 같아요......\n황가이 장군......', True)
        fight.end()
        stage.unit(91).hide(2)
        stage.getItem(138, -1, True, 2)
        vars[57] = 1
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 77, True):
        stage.unit(0).setDir(stage.countDir(0, 77))
        stage.unit(77).setDir(stage.countDir(77, 0))
        stage.say('&77\n내 계략을 간파했구나,\n너 같은 라이벌이 있으면 외롭지 않을 거야.\n&0\n조의 진영에는 지혜와 전략을 가진 사람들이 있었다.\n네 속임수에 쉽게 넘어가지 않을 거야.\n&77\n결과는 아직 정해지지 않았으니, 잡담은 그만하자.\n어떻게 끝나는지 보자!')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n손권, 동우는 이미 내 손아귀에 들어왔다.\n&76\n그렇게 쉽게 넘기지 않을 거야!\n동오는 아버지와 형제들이 목숨을 걸고 이겼다,\n나는 이 땅을 지켜야 한다.')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n젠장, 우리 싸움은 아직 끝나지도 않았어!\n일단 후퇴하자.')
        stage.unit(76).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n후회하라, 후퇴!\n모두에게 미안해.\n이 모든 것은 제 fault육손이에요. 마음은 있지만 그럴 힘도 있어요.')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n안 좋네, 더는 못 버티겠어!\n후퇴, 빨리 나가!')
        stage.unit(78).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(77, 7, 0, 2):
        stage.say('&77\n아, 아! 내 마음이 얼마나 슬픈지!\n내 아름다운 꿈은 얼음처럼 연약해,\n어떻게 내 주유가 이렇게 될 수 있지......')
        stage.talk(186, 186, '저우 사령관!? … 다행히도 그는 기절만 했다.\n빨리 주 주지사를 전장에서 호위하고 퇴각하라!')
        stage.unit(77).hide(1)
        stage.getItem(112, -1, True, 1027)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(98, 7, 0, 2):
        stage.say('&98\n안 좋으니 후퇴!')
        stage.unit(98).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n뜻밖에도, 대전투가 한창일 때,\n하지만 전장에서 물러나야 해......\n정말 안타깝네요.')
        stage.unit(83).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n아군 상황이 암울해 보인다.\n후퇴!')
        stage.unit(96).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(91, 7, 0, 2):
        stage.say('&91\n정말 받아들일 수 없어요......\n다만 시간이 아무도 기다려주지 않는다는 게 아쉽다......\n음......')
        stage.unit(91).hide(2)
        stage.getItem(138, -1, True, 1027)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n쳇, 도망치는 게 최선의 전략이야.\n나 간다!')
        stage.unit(86).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n제발 목숨을 살려주세요...... 말도 안 돼!\n헤헤헤, 나 먼저 갈게!')
        stage.unit(87).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(89, 7, 0, 2):
        stage.say('&89\n하지만 실패했습니다.\n먼저 후퇴하자.')
        stage.unit(89).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(84, 7, 0, 2):
        stage.say('&84\n아파! 쳇, 내가 너무 부주의했나?\n기억해, 내 이름은 감녕야!\n다시 쫓아올 거야. 후퇴!')
        stage.unit(84).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(95, 7, 0, 2):
        stage.say('&95\n정말 안타깝네요.\n하지만 아직 죽을 수는 없어.\n후퇴!')
        stage.unit(95).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(80, 7, 0, 2):
        stage.say('&80\n사람이 천을 이길 수 있다고 하지만, 천의 뜻이 그렇기 때문이다,\n오늘은 먼저 후퇴하는 게 낫다.')
        stage.unit(80).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n젠장, 일단 후퇴하자.\n그렇다고 우리가 졌다는 뜻은 아니야.')
        stage.unit(85).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(93, 7, 0, 2):
        stage.say('&93\n젠장, 진짜로 졌어!\n후퇴!')
        stage.unit(93).hide(1)
        vars[65] = 1
    if not vars[66] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n아-아, 안 돼...... 젠장!\n후퇴!')
        stage.unit(82).hide(1)
        vars[66] = 1
    if not vars[67] and stage.unitStateTest(94, 7, 0, 2):
        stage.say('&94\n와! 받아들일 수 없어......')
        stage.unit(94).hide(2)
        stage.getItem(82, -1, True, 1027)
        vars[67] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아요, 드디어 모든 적군을 다 지웠어요!\n아군 이겼어!')
        if not vars[2]:
            stage.reward(0, [
                42,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[627] = 1
        vars[727] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 손권에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    if vars[727] and vars[1001]:
        stage.jumpScene(59)
        return False
    stage.jumpScene(57)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
