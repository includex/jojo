# Source Generated with Decompyle++
# File: R_29.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 49)
    stage.showUnits([
        [
            32,
            54,
            73],
        [
            35,
            40,
            57,
            1],
        [
            3,
            67,
            57,
            3],
        [
            33,
            67,
            51,
            3],
        [
            34,
            67,
            45,
            3]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('관우 서약')
    stage.setStageName('장샤 유비 거주지')
    stage.say('&32\n공명, 동우와 조위 사이의 상황은 어땠나요?')
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n주군에게 보고합니다.\n동오는 유리한 바람을 이용했다,\n그리고 조의 군대에 대규모 화력 공격을 감행했다.')
    stage.say('&35\n조의 군대는 분명히 큰 패배를 겪을 것이다,\n그때 우리는 도망치는 조조군을 추격해 격파할 것이다.\n&32\n흠, 모든 건 당신에게 맡길게요.')
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n네! 그럼 즉시 병력을 동원하세요.')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n자룡과 이데, 명령 들어!')
    stage.unit(34).setAction(6)
    stage.say('&34\n존재한다.')
    stage.unit(33).setAction(3)
    stage.say('&33\n존재한다.')
    stage.unit(34).setAction(0)
    stage.unit(33).setAction(0)
    stage.say('&35\n조의 군대는 분명 경주로 도망칠 것이다,\n미리 도착했구나......')
    stage.unit(35).setAction(11)
    stage.say('&35\n등등......')
    stage.unit(34).setAction(6)
    stage.say('&34\n전략가는 훌륭한 계획을 세웠다.')
    stage.unit(33).setAction(3)
    stage.say('&33\n알겠어요!\n지켜봐.')
    stage.unit(35).setAction(0)
    stage.say('&35\n그러니 즉시 출발해 주세요.')
    stage.unit(3).setAction(2)
    stage.say('&3\n전략가!')
    stage.unit(33).setAction(0)
    stage.unit(34).setAction(0)
    stage.delay(3)
    stage.unit(33).setAction(0, 2)
    stage.unit(34).setAction(0, 2)
    stage.delay(5)
    stage.say('&35\n윤창 장군님, 무슨 일입니까?')
    stage.unit(3).setAction(0)
    stage.say('&3\n전략가, 당신은 이이드와 쯔롱에게 명령을 내렸습니다,\n하지만 관은 어떤 명령도 받지 못했다.\n왜 그럴까요?')
    stage.unit(35).setAction(11)
    stage.say('&35\n아, 이 일 때문이야?')
    stage.unit(35).setAction(0)
    stage.say('&35\n장군님께 폐를 끼치고 싶은 일이 많습니다,\n그냥 작은 걱정이 하나 있어요.')
    stage.unit(3).setAction(3)
    stage.say('&3\n무슨 걱정거리?')
    stage.unit(3).setAction(0)
    stage.effectSound(203, 255)
    stage.bgSound(19)
    stage.delay(3)
    stage.say('&35\n오랫동안 조조에게 큰 존경을 받아왔습니다.\n아직도 그의 친절함을 기억하겠지.')
    stage.unit(3).setAction(6)
    stage.say('&3\n이전에 원소 싸울 때,\n관은 이미 그에게 보답했다.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n그렇다면.........\n조조 비참한 상태로 간청합니다,\n죽일 거조조?')
    stage.unit(3).setAction(2)
    stage.say('&3\n관이 분명히 조조를 죽일 수 있을 거야!\n관이 그를 처형하지 못한다면,\n군사 처벌을 받아들이겠습니다.')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n…… 군사 서약서에 서명할 수 있나요?')
    stage.unit(3).setAction(0)
    stage.say('&3\n물론이지.')
    stage.say('&35\n좋아.')
    stage.say('&35\n제3분대에 이데 장군을 따르라고 명령해 주십시오,\n그들은 마른 나무를 불태워 짙은 연기를 피우고, 조의 군대를 기습할 준비를 했다.')
    stage.unit(3).setAction(3)
    stage.say('&3\n조의 군대가 짙은 연기를 본다면,\n적군이 앞에 숨어 있다는 것을 알면서도,\n그냥 다른 경로로 바뀌지 않을까요?')
    stage.unit(3).setAction(0)
    stage.say('&35\n그렇지 않다. 조조 전쟁의 기술에 능통한 사람이다,\n그는 신호 화염이 속임수 진형을 만들기 위한 속임수라고 생각했을 것이다,\n대신, 그들은 대담하게 앞으로 나아갈 것이다.\n&3\n그래서 그런 거야.')
    stage.unit(35).setAction(0)
    stage.say('&35\n이제 이해했어?\n그럼 당장 행동합시다.')
    stage.unit(3).setAction(6)
    stage.say('&3\n네.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(34),
            67,
            10,
            0],
        [
            stage.unit(33),
            67,
            10,
            0],
        [
            stage.unit(3),
            67,
            10,
            0]])
    stage.unit(34).hide()
    stage.unit(33).hide()
    stage.unit(3).hide()
    stage.delay(5)
    stage.say('&32\n......공명.')
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n네.\n&32\n둘째 형이 단호히 약속했지만,\n그가 조조를 죽이지 않을 것 같아요.\n&35\n음, 미안하지만 그럴 용기가 나지 않네요.\n&32\n그렇다면 그의 군사 기사단은?')
    stage.unit(35).setAction(6)
    stage.say('&35\n윤창 장군이 아직도 과거의 친절을 마음에 품고 있다면,\n그는 이 기회를 이용해 모든 것을 완전히 정리할 것이다.')
    stage.unit(35).setAction(0)
    stage.say('&35\n이것도 윤창 장군을 위한 것이었다.\n&32\n공명, 정말 먼 미래를 생각하네요......')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            2,
            44,
            64,
            1],
        [
            21,
            64,
            64,
            3]])
    stage.draw()
    stage.setStageName('울린조조 주 진영')
    model.setFace(2)
    stage.unit(0).setAction(2)
    stage.say('&0\n저 빌어먹을 우 개들!\n네가 나를 너무 심하게 이겨서 완전히 패배했어!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 5, [
        2,
        21,
        15,
        13])
    gvars[4076] = 0
    gvars[4057] = 29
    stage.setBattlePos([
        [
            34,
            19],
        [
            33,
            20],
        [
            34,
            19],
        [
            33,
            8],
        [
            32,
            8],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(21):
        stage.say('&21\n징저우로 가는 길은 두 개가 있습니다.\n올바른 경로를 선택하는 것이 중요합니다.\n&0\n전체 지형은 어떤가요?\n&21\n지형은 산과 늪지대가 있어 매우 복잡합니다.\n빠르게 움직이기 어렵다.\n&0\n흠.........')
    if stage.unitClickTest(2):
        stage.say('&2\n주군, 아군에서의 손실은 상상보다 심각합니다,\n다른 사람들은 어떻게 됐을까?\n&0\n흠.........\n유일한 방법은 이곳을 최대한 빨리 벗어나는 것이다,\n나중에 어떻게 만날지 생각하자.\n&0\n원위안, 이 패배는,\n동우를 과소평가한 내 잘못이야.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
