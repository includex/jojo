# Source Generated with Decompyle++
# File: R_17.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 18)
    stage.showUnits([
        [
            101,
            35,
            56,
            1],
        [
            32,
            50,
            45,
            2],
        [
            109,
            50,
            67]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setEventName('당황스러움')
    stage.setStageName('바이마 원소군 본대')
    stage.say('&101\n뜻밖에도 옌량은 실제로 ...... 죽었다.')
    stage.unit(101).setAction(2)
    stage.say('&101\n조조That 악당!')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(109).setAction(0, 1)
    stage.say('&109\n누가 알았겠어, 큰형 옌량이 이런 곳에서 죽을 줄!')
    stage.unit(109).setAction(2)
    stage.say('&109\n정말 미운 참 어려워!')
    stage.unit(109).setAction(0)
    stage.delay(5)
    stage.say('&101\n그런데, 유비님.')
    stage.unit(101).setAction(0, 3)
    stage.say('&101\n부하로부터 보고를 받았다,\n관장군이 백마 전장에 나타났다고 들었어.')
    stage.unit(109).setAction(0, 0)
    stage.delay(3)
    stage.unit(109).setAction(3)
    stage.say('&109\n관우!?')
    stage.unit(32).setAction(3)
    stage.say('&32\n오!!')
    stage.unit(109).setAction(0)
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.say('&101\n붉은 얼굴과 긴 수염을 가진 건장한 남자라고 전해진다.')
    stage.unit(101).setAction(0, 1)
    stage.say('&101\n유비, 무슨 일이야?')
    stage.unit(32).setAction(3)
    stage.say('&32\n...... 사실인가요?')
    stage.unit(32).setAction(0)
    stage.say('&32\n윤창은 결코 villain조조 때문에 목숨을 걸지 않을 것이다')
    stage.unit(109).setAction(2)
    stage.say('&109\n그만 싸워......!\n&101\n원초우, 충동적으로 굴지 마.')
    stage.unit(109).setAction(0)
    stage.say('&101\n유비 선생님......\n우리한테 거짓말하는 거 아니지?')
    stage.unit(32).setAction(6)
    stage.say('&32\n원군, 조조 진형에 무서운 장군들이 많다고 들었습니다.\n&32\n그들 중에는 어김없이 동생과 닮은 이들도 있다.\n&32\n조조 이 남자는 항상 전략에 뛰어났지만,\n이게 그의 계략일 거라고 의심해,\n우리 사이를 갈라놓으려는 거야.')
    stage.unit(32).setAction(0)
    stage.say('&101\n흠...... 알겠어.\n조조 실제로 그렇게 할 수 있습니다.')
    stage.unit(101).setAction(2)
    stage.say('&101\n혐오스러운 조조,\n실제로 그렇게 영리함을 과시하다니.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(109).setAction(2)
    stage.say('&109\n주군, 제발 형님의 복수를 하게 해주세요!\n&101\n그런 의도가 있다니 기쁘네요.\n다음 전투, 네가 선봉이 되게 해.')
    stage.unit(109).setAction(0)
    stage.say('&109\n네!')
    stage.unit(32).setAction(0, 1)
    stage.say('&32\n(둘째 형은 아직 살아 있을지도 몰라......\n그리고 그는 조나라 군대의 장......가 되었다! )')
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3],
        [
            3,
            49,
            54,
            2]])
    stage.draw()
    stage.setStageName('바이마 조조군 본군 진영')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n윤창, 이번엔 정말 잘했어!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n이런 사소한 일은 총리님의 큰 은혜를 갚기 어렵습니다.')
    stage.say('&0\n흠...... 흠.\n수고해 주셔서 감사합니다. 이제 쉬러 가십시오."\n&3\n네.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).move(49, 16, 0)
    stage.unit(3).hide()
    stage.delay(3)
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n주군.\n이번에는 단지 지역 전투에서의 승리에 불과했다.')
    stage.unit(21).setAction(0, 2)
    stage.say('&21\n네, 전반적인 상황은 여전히 위안의 군대에 유리했습니다.\n&0\n알아.')
    stage.showUnit(181, 49, 16, 2)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 원소가 옌진을 공격했어!')
    stage.unit(22).setAction(0, 3)
    stage.unit(21).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n뭐라고!?\n&22\n이거 큰일이야.')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n연진이 무너진다면,\n흰 말을 키우기 어려울 뿐만 아니라,\n쉬두도 위험해.')
    stage.unit(0).setAction(0)
    stage.say('&0\n흠, 원나라 군대의 선봉은 누구였나요?\n&181\n위대한 원초우 장군이었다.\n&0\n원초우야?\n또 한 명의 용감한 장군.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n네.\n그가 옌량보다도 강한 사나운 장군이라고 들었어.')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n그럼에도 불구하고,\n이 남자는 용감하지만 전략이 부족하다고 할 수 .......')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그는 용기가 있지만 전략은 없는 무모한 장군으로 드러났다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n좋아.\n상황이 긴급하니,\n그는 어쩔 수 없이 옌진으로 가서 원소를 맞서야 했다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n출발 준비해!\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.unit(0).setAction(0)
    stage.unit(20).setAction(0, 3)
    stage.unit(22).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        2])
    gvars[4076] = 0
    gvars[4057] = 17
    stage.setBattlePos([
        [
            11,
            21],
        [
            15,
            14],
        [
            20,
            14],
        [
            4,
            16],
        [
            3,
            15],
        [
            5,
            15],
        [
            15,
            13],
        [
            20,
            13],
        [
            15,
            12],
        [
            20,
            12]])
    return False


def scene2():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(3):
        stage.say('&3\n원초우 문제는 관에게 맡겨라.')
    if stage.unitClickTest(1):
        stage.say('&1\n원소군 중 가장 강력한 인물은 옌량과 원초우였다.\n이제 옌량이 제거되었으니, 원초우가 다시 처형될 수 있다면,\n이제부터 전쟁은 훨씬 쉬워질 것이다.\n&0\n정확히 그렇습니다.')
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 지형을 설명해 주세요.\n&20\n네.\n이전 하쿠마들과 비교하면,\n여기서는 큰 차이가 없었다.\n&20\n승패의 열쇠는 여전히 이 점에 있습니다\n그들이 건널 다리를 점령할 수 있을지 여부.\n&0\n흠.')
    if stage.unitClickTest(22):
        stage.say('&22\nUnexpectedly원소 흰 말을 붙잡지 않고,\n대신 그들은 옌진을 공격하기 위해 방향을 돌렸.......\n&0\n그를 다르게 보시나요?\n&22\n…… 아니요, 그 정도까지는 아니에요.\n&0\n정말 고집이 세구나, 너 .......')
    if stage.unitClickTest(21):
        stage.say('&21\n무기 가게에 새 갑옷과 옷이 들어온 것 같다,\n이 모든 것들은 앞으로 준비되어야 합니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n빈백은 정말 편리하죠. 하지만......\n맞을 때마다 회복 콩을 섭취해야 합니다,\n다만 꽤 비싸요.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
