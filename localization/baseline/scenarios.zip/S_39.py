# Source Generated with Decompyle++
# File: S_39.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(19,11)',
        '(19,14)',
        '(15,12)',
        '(23,13)',
        '(8,24)',
        '(11,24)',
        '(10,20)',
        '(9,28)'])
    stage.nearEvent([
        0,
        34,
        0,
        35,
        19,
        50,
        0,
        57,
        19,
        37], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 19, 'y': 11, 'dir': 3, 'lv': 6, 'i': 0},
         {'id': 34, 'x': 19, 'y': 12, 'dir': 3, 'lv': 6, 'i': 1},
         {'id': 50, 'x': 19, 'y': 13, 'dir': 3, 'lv': 6, 'i': 2},
         {'id': 59, 'x': 19, 'y': 14, 'dir': 3, 'lv': 4, 'i': 3},
         {'id': 210, 'x': 15, 'y': 12, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 211, 'x': 23, 'y': 13, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 212, 'x': 17, 'y': 12, 'dir': 3, 'lv': 0, 'i': 6},
         {'id': 213, 'x': 17, 'y': 13, 'dir': 3, 'lv': 0, 'i': 7},
         {'id': 234, 'x': 18, 'y': 11, 'dir': 3, 'lv': 0, 'i': 8},
         {'id': 235, 'x': 18, 'y': 12, 'dir': 3, 'lv': 0, 'i': 9},
         {'id': 236, 'x': 18, 'y': 13, 'dir': 3, 'lv': 0, 'i': 10},
         {'id': 237, 'x': 18, 'y': 14, 'dir': 3, 'lv': 0, 'i': 11},
         {'id': 298, 'x': 18, 'y': 10, 'dir': 3, 'lv': 0, 'i': 12},
         {'id': 299, 'x': 18, 'y': 15, 'dir': 3, 'lv': 0, 'i': 13},
         {'id': 300, 'hide': 1, 'x': 20, 'y': 11, 'dir': 3, 'lv': 0, 'i': 14},
         {'id': 301, 'hide': 1, 'x': 20, 'y': 14, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 40, 'x': 8, 'y': 24, 'dir': 0, 'lv': 4, 'i': 16},
         {'id': 68, 'x': 9, 'y': 24, 'dir': 0, 'lv': 4, 'i': 17},
         {'id': 70, 'x': 10, 'y': 24, 'dir': 0, 'lv': 4, 'i': 18},
         {'id': 43, 'x': 11, 'y': 24, 'dir': 0, 'lv': 4, 'i': 19},
         {'id': 214, 'x': 10, 'y': 20, 'dir': 0, 'lv': 0, 'i': 20},
         {'id': 215, 'x': 9, 'y': 28, 'dir': 0, 'lv': 0, 'i': 21},
         {'id': 216, 'x': 9, 'y': 22, 'dir': 0, 'lv': 0, 'i': 22},
         {'id': 217, 'x': 10, 'y': 22, 'dir': 0, 'lv': 0, 'i': 23},
         {'id': 238, 'x': 8, 'y': 23, 'dir': 0, 'lv': 0, 'i': 24},
         {'id': 239, 'x': 9, 'y': 23, 'dir': 0, 'lv': 0, 'i': 25},
         {'id': 240, 'x': 10, 'y': 23, 'dir': 0, 'lv': 0, 'i': 26},
         {'id': 241, 'x': 11, 'y': 23, 'dir': 0, 'lv': 0, 'i': 27},
         {'id': 302, 'x': 7, 'y': 23, 'dir': 0, 'lv': 0, 'i': 28},
         {'id': 303, 'x': 12, 'y': 23, 'dir': 0, 'lv': 0, 'i': 29},
         {'id': 304, 'hide': 1, 'x': 8, 'y': 25, 'dir': 0, 'lv': 0, 'i': 30},
         {'id': 305, 'hide': 1, 'x': 11, 'y': 25, 'dir': 0, 'lv': 0, 'i': 31},
         {'id': 66, 'hide': 1, 'x': 11, 'y': 4, 'lv': 6, 'ai': 1, 'i': 32},
         {'id': 37, 'hide': 1, 'x': 12, 'y': 4, 'lv': 6, 'ai': 1, 'i': 33},
         {'id': 54, 'hide': 1, 'x': 13, 'y': 4, 'lv': 6, 'ai': 1, 'i': 34},
         {'id': 53, 'hide': 1, 'x': 14, 'y': 4, 'lv': 6, 'ai': 1, 'i': 35},
         {'id': 390, 'hide': 1, 'x': 12, 'y': 5, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 391, 'hide': 1, 'x': 13, 'y': 5, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 382, 'hide': 1, 'x': 11, 'y': 5, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 383, 'hide': 1, 'x': 14, 'y': 5, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 60, 'hide': 1, 'x': 1, 'y': 14, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 40},
         {'id': 57, 'hide': 1, 'x': 1, 'y': 15, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 41},
         {'id': 58, 'hide': 1, 'x': 1, 'y': 16, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 42},
         {'id': 44, 'hide': 1, 'x': 1, 'y': 17, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 43},
         {'id': 462, 'hide': 1, 'x': 2, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 44},
         {'id': 463, 'hide': 1, 'x': 2, 'y': 15, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 45},
         {'id': 464, 'hide': 1, 'x': 2, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 46},
         {'id': 465, 'hide': 1, 'x': 2, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 47}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 1,
            'y': 4,
            'dir': 1 },
        {
            'idx': 1,
            'x': 1,
            'y': 5,
            'dir': 1 },
        {
            'idx': 2,
            'x': 2,
            'y': 5,
            'dir': 1 },
        {
            'idx': 3,
            'x': 2,
            'y': 4,
            'dir': 1 },
        {
            'idx': 4,
            'x': 2,
            'y': 6,
            'dir': 1 },
        {
            'idx': 5,
            'x': 3,
            'y': 5,
            'dir': 1 },
        {
            'idx': 6,
            'x': 1,
            'y': 6,
            'dir': 1 },
        {
            'idx': 7,
            'x': 3,
            'y': 4,
            'dir': 1 },
        {
            'idx': 8,
            'y': 7,
            'dir': 1 },
        {
            'idx': 9,
            'x': 4,
            'y': 3,
            'dir': 1 },
        {
            'idx': 10,
            'y': 6,
            'dir': 1 },
        {
            'idx': 11,
            'x': 3,
            'y': 3,
            'dir': 1 },
        {
            'idx': 12,
            'y': 5,
            'dir': 1 },
        {
            'idx': 13,
            'x': 2,
            'y': 3,
            'dir': 1 },
        {
            'idx': 14,
            'x': 1,
            'y': 3,
            'dir': 1 }])
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.loadBg(39)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(3)
    stage.unit(15).setDir(stage.countDir(15, 0))
    stage.unit(0).setDir(stage.countDir(0, 15))
    stage.say('&15\n주군, 양평관이 바로 우리 앞에 있었다,\n한 번에 돌진하자, 알겠지?\n&0\n여기는 양평관, 공명가 지키고 있습니다.\n함정이 있을 수도 있어.')
    stage.unit(0).setDir(stage.countDir(0, 19))
    stage.say('&0\n중달, 만약 당신이 그 상황이라면 어떻게 하시겠습니까?')
    stage.unit(19).setDir(2)
    stage.say('&19\n먼저, 남문을 점령했다,\n뒤에서 걱정을 없애기 위해서입니다.')
    stage.heightLight(7, 23, 12, 25)
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n병력의 절반을 동원하고 싶다,\n양평관으로 가는 구불구불한 길 뒤에 있다.\n&0\n그런데 어떻게 뒤쪽으로 가나요?\n산에 둘러싸여 있어서 무슨 일이 있어도 통과할 수 없었다.')
    stage.unit(19).setDir(1)
    stage.say('&19\n주군 네가 그렇게 생각하니까,\n공명도 같은 생각을 하고 있을지도 몰라,\n이렇게 하면 기회를 잡을 수 있습니다.')
    stage.unit(19).setDir(stage.countDir(19, 0))
    stage.say('&19\n허저 능력을 빌리고 싶어.\n산에서 자란 허저,\n아마 지나가는 산길들을 알고 있을 거야.\n&0\n이해가 됩니다.\n&19\n하지만 아마도 시간이 좀 걸릴 것입니다.\n주군 이 기간 동안,\n적의 절반 병력으로 교전하세요.\n&0\n당신은 고개로 다시 감긴 이후의 기간 동안,\n주력 부대가 위험에 처할 가능성은 있을까?\n흠.........')
    sel = stage.choice('전체 군대는 고개 내륙으로 진격했다\n적을 측면에서 공격할 병력을 파견하라', -1)
    if sel == 1:
        stage.say('&0\n위험이 너무 크다고 생각해요,\n정면에서 공격하는 게 낫다.\n&19\n네!\nHowever공명 함정이 있을 거야,\n행진할 때는 매우 조심해야 합니다.\n&0\n흠.')
    elif sel == 2:
        stage.say('부대를 두 부분으로 나눈다면, 비록 공명의 계략에 걸리더라도 절반의 부대는 지원할 수 있을 겁니다.\n좋다! 네 제안을 받아들이겠다. 너와 허저는 반 병력으로 관문 뒤로 돌아가라.\n분부가 명확합니다. 다만 우회하는 데 시간이 좀 걸릴 테니, 행군 속도를 조금 늦춰 주십시오.')
        stage.setRectUnitHide(0, 5, 2, 7, 0)
        vars[2] = 1
    stage.unit(34).setDir(stage.countDir(34, 35))
    stage.say('&34\n총리님, 조의 군대가 도착한 것 같습니다.')
    stage.unit(35).setDir(stage.countDir(35, 34))
    stage.say('&35\n이 모든 것은 예상된 일이었다.\n남은 건 조조가 공격하는 것뿐이야.')
    stage.unit(35).setDir(stage.countDir(35, 50))
    stage.say('&35\n마수, 전장이 흩어지면,\n전략가도 몇 명 추가해야 합니다,\n그래서 네 도움이 필요해.')
    stage.unit(50).setDir(stage.countDir(50, 35))
    stage.say('&50\n나한테 맡겨, 마유창.\n저희는 반드시 기대에 부응할 것입니다.\n&35\n이번에는 이미 매복을 설치했어,\n패스 수비 임무는 네 몫이야.\n실수하진 않겠지?\n&50\n총리님께 제 말 유창을 데려가지 말아 달라고 간청합니다,\n무능한 전략가들과 똑같이 대하세요,\n절대 간과는 없을 것입니다.\n&59\n(주변 지형을 고려하지 않고 진형을 어떻게 배치할지 결정하며,\n정말 오해가 없는 걸까? )')
    stage.unit(40).setDir(stage.countDir(40, 0))
    stage.unit(40).setAction(7)
    stage.say('&40\n조조Ah! 빨리 와!\n나, 손첸은 전 영주의 후회를 청산하고자 한다!')
    stage.unit(40).setAction(0)
    stage.unit(68).setDir(stage.countDir(68, 40))
    stage.say('&68\n네 기분을 이해해,\n하지만 서두르면 실패만 끝날 뿐입니다.\n주군의 후회를 정리하고 싶다면 침착함을 유지하고 도전에 맞서야 합니다.')
    stage.unit(70).setDir(stage.countDir(70, 40))
    stage.say('&70\n네! 서두르지 마세요,\n조조 분명히 이곳을 지나갈 거야,\n이제 인내심을 가지고 기다려.')
    stage.unit(43).setDir(stage.countDir(43, 40))
    stage.say('&43\n하하하.\n맞아요, 손첸 경.\n요컨대, 우리는 조조을 이겨야 합니다.')
    stage.setWinCondition('승리 조건\n1. 양평관을 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('양평관을 돌파하라!')
    stage.heightLight(22, 11, 23, 15)
    stage.startOper()
    vars[539] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[11] and stage.round() == 7:
        stage.unit(1, 1).show(9, 31, 0)
        stage.unit(2, 1).show(9, 30, 0)
        stage.unit(4, 1).show(8, 30, 0)
        stage.unit(6, 1).show(10, 30, 0)
        stage.unit(8, 1).show(8, 31, 0)
        stage.unit(10, 1).show(10, 31, 0)
        stage.unit(12, 1).show(7, 31, 0)
        stage.unit(15).setAction(9)
        stage.say('&15\n휴, 꽤 시간이 걸렸어요.\n주군 무사하길 바래.')
        stage.unit(19).setDir(stage.countDir(19, 15))
        stage.say('&19\n적이 준비되기 전에 공격하라!')
        stage.unit(15).setDir(stage.countDir(15, 19))
        stage.unit(15).setAction(5)
        stage.say('&15\n흠!\n전면 군대 공격!')
        stage.unit(15).setAction(0)
        if not vars[54]:
            stage.unit(40).setDir(stage.countDir(40, 15))
            stage.unit(40).setAction(10)
            stage.say('&40\n뭐-뭐라고!\n네 뒤에 적이 있나!?')
        if not vars[55]:
            stage.unit(68).setDir(stage.countDir(68, 15))
            stage.say('&68\n아-아, 안 돼......\n언제......')
        if not vars[56]:
            stage.unit(70).setDir(stage.countDir(70, 15))
            stage.unit(70).setAction(8)
            stage.say('&70\n와...... 오, 안 돼!')
        if not vars[57]:
            stage.unit(43).setDir(stage.countDir(43, 15))
            stage.say('&43\n마수가 뒤에서 공격하지 않겠다고 했어!\n이 금발 애!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 2,
                'y1': 22,
                'x2': 17,
                'y2': 31,
                'camp': 2 }])
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 15))
            stage.say('&35\n그 아이 마수,\n그 뒤에 있는 방어가 방치되어 있었던 걸까?')
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 15))
            stage.say('&34\n이거 큰일이야.')
        if not vars[3]:
            if not vars[50]:
                stage.say('&35\n선택의 여지가 없어!\n위연에게 즉시 전투 준비를 마초 알리라.')
            if not vars[51]:
                stage.unit(34).setAction(5)
                stage.say('&34\n한 번의 결정적인 움직임으로 조조를 짓밟아라!\n난관이 무너지기 전에 그를 제거해!')
                stage.unit(34).setAction(0)
            stage.unit(66).show()
            stage.unit(37).show()
            stage.unit(54).show()
            stage.unit(53).show()
            stage.unit(382).show()
            stage.unit(390).show()
            stage.unit(391).show()
            stage.unit(383).show()
            stage.unit(66).setDir(stage.countDir(66, 0))
            stage.unit(37).setDir(stage.countDir(37, 0))
            stage.unit(54).setDir(stage.countDir(54, 0))
            stage.unit(53).setDir(stage.countDir(53, 0))
            stage.say('&66\n오랫동안 기다렸어, 조조!\n오늘, 나, 관수오가 네 목을 베겠다!')
            stage.unit(37).setDir(stage.countDir(37, 66))
            stage.say('&37\n흥! 왜 그와 대화하는 거야!\n요컨대, 목표는 조조를 죽이는 것이었습니다.\n오해하지 마세요!\n&54\n만약 승자가 빨리 결정되지 않으면,\n손천 장군은 큰 위험에 처할 것이다.\n서둘러! 관싱.\n&53\n간다!\n돌격!')
            stage.unit(60).show()
            stage.unit(57).show()
            stage.unit(58).show()
            stage.unit(44).show()
            stage.unit(462).show()
            stage.unit(463).show()
            stage.unit(464).show()
            stage.unit(465).show()
            stage.unit(60).setDir(stage.countDir(60, 0))
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(58).setDir(stage.countDir(58, 0))
            stage.unit(44).setDir(stage.countDir(44, 0))
            stage.say('&60\n상황이 암울해 보였지만,\n하지만 우리가 져도 우리 잘못은 아니야,\n이렇게 생각하면 좀 더 편하게 느껴진다.\n&57\n이번에는 반드시 조조를 이겨야 해!\n&58\n낭관은 위험해!\n서둘러 돌격해!\n&44\n전면 군대 공격!')
            stage.unit(0).setDir(stage.countDir(0, 66))
            stage.unit(0).setDir(stage.countDir(0, 60))
            stage.say('&0\n매복인가요......\n꽤 많은 사람이 있는 것 같아요.')
            stage.unit(0).setDir(stage.countDir(0, 19))
            stage.unit(0).setAction(5)
            stage.say('빨리 관문을 점령해서 방어 거점을 만들어라!')
            stage.unit(0).setAction(0)
            vars[3] = 1
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 19, 11):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 19, 14):
        stage.getItem(152, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 15, 12):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 23, 13):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 8, 24):
        stage.getItem(152, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 11, 24):
        stage.getItem(152, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 10, 20):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 9, 28):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if not vars[3] and not vars[6] and stage.totalRectUnit(0, 15, 8, 16, 18) >= 3:
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n지금이 바로 그때입니다!\n위연. 앞마초가!')
            stage.unit(35).setAction(0)
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.unit(34).setAction(5)
            stage.say('&34\n한 번에 조조를 물리쳐라!\n사방에서 그들을 둘러싸고 있었다.\n공격!')
            stage.unit(34).setAction(0)
        stage.unit(66).show()
        stage.unit(37).show()
        stage.unit(54).show()
        stage.unit(53).show()
        stage.unit(382).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(383).show()
        stage.unit(66).setDir(stage.countDir(66, 0))
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(54).setDir(stage.countDir(54, 0))
        stage.unit(53).setDir(stage.countDir(53, 0))
        stage.say('&66\n오랫동안 기다렸어, 조조!\n오늘, 나, 관수오가 네 목을 베겠다!')
        stage.unit(37).setDir(stage.countDir(37, 66))
        stage.say('&37\n흥! 왜 그와 대화하는 거야!\n요컨대, 목표는 조조를 죽이는 것이었습니다.\n오해하지 마세요!\n&54\n관싱! 시합하자,\n누가 먼저 조조 목을 베는지 보자.\n&53\n하하하, 동의해요!\n지지 마, 장바오!')
        stage.unit(60).show()
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(44).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&60\n좋아, 크레딧은 바로 네 앞에 있어.\n서둘러 돌격해!\n&57\n이번에는 반드시 조조를 죽여야 해!\n&58\n좋아! 조의 군대를 추격하라!\n사방에서 공격한다면,\n아무리 강력한 조조도 막을 수 없습니다.\n&44\n모두 돌격!')
        stage.unit(0).setDir(stage.countDir(0, 66))
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.say('&0\n매복인가요......\n꽤 많은 사람이 있는 것 같아요.')
        stage.unit(0).setAction(5)
        stage.say('빨리 관문을 점령해서 방어 거점을 만들어라!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.say('&35\n내 계획은 여기서 조조를 물리치는 거야.\n우리는 이 배신자를 반드시 죽여야 한다!')
        if not vars[51]:
            stage.say('&34\n나도 싸움에 합류할게!')
        stage.unit(34).setAI(1)
        stage.unit(50).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(35).setAI(0)
        stage.unit(59).setAI(0)
        stage.unit(298).setAI(0)
        stage.unit(299).setAI(0)
        if not vars[55]:
            stage.unit(68).setDir(stage.countDir(68, 0))
            stage.say('&68\n우리도 싸우자!')
        if not vars[56]:
            stage.unit(70).setDir(stage.countDir(70, 0))
            stage.say('&70\n오늘은 전임 영주의 남은 후회를 끝낼 때다!\n죽여라!')
        stage.unit(68).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(40).setAI(0)
        stage.unit(43).setAI(0)
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        vars[3] = 1
        vars[6] = 1
    if not vars[3] and not vars[7] and stage.totalRectUnit(0, 6, 20, 13, 21) >= 3:
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n지금이 바로 그때입니다!\n위연. 마초 필드로!')
            stage.unit(35).setAction(0)
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.unit(34).setAction(5)
            stage.say('&34\n한 번에 조조를 물리쳐라!\n사방에서 공격해라!')
            stage.unit(34).setAction(0)
        stage.unit(66).show()
        stage.unit(37).show()
        stage.unit(54).show()
        stage.unit(53).show()
        stage.unit(382).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(383).show()
        stage.unit(66).setDir(stage.countDir(66, 0))
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(54).setDir(stage.countDir(54, 0))
        stage.unit(53).setDir(stage.countDir(53, 0))
        stage.say('&66\n오랫동안 기다렸어, 조조!\n오늘, 나, 관수오가 네 목을 베겠다!')
        stage.unit(37).setDir(stage.countDir(37, 66))
        stage.say('&37\n흥! 왜 그와 대화하는 거야!\n요컨대, 목표는 조조를 죽이는 것이었습니다.\n오해하지 마세요!\n&54\n관싱! 시합하자,\n누가 먼저 조조 목을 베는지 보자.\n&53\n하하하, 동의해요!\n지지 마, 장바오!')
        stage.unit(60).show()
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(44).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&60\n좋아, 크레딧은 바로 네 앞에 있어.\n서둘러 돌격해!\n&57\n이번에는 반드시 조조를 죽여야 해!\n&58\n좋아, 조조의 군대를 추격하라!\n사방에서 공격한다면,\n아무리 강력한 조조도 막을 수 없습니다.\n&44\n모두 돌격!')
        stage.unit(0).setDir(stage.countDir(0, 66))
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.say('&0\n매복인가요......\n꽤 많은 사람이 있는 것 같아요.')
        stage.unit(0).setAction(5)
        stage.say('빨리 관문을 점령해서 방어 거점을 만들어라!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.say('&35\n내 계획은 여기서 조조를 물리치는 거야.\n우리는 이 배신자를 반드시 죽여야 한다!')
        if not vars[51]:
            stage.say('&34\n나도 싸움에 합류할게!')
        stage.unit(34).setAI(1)
        stage.unit(50).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(35).setAI(0)
        stage.unit(59).setAI(0)
        stage.unit(298).setAI(0)
        stage.unit(299).setAI(0)
        if not vars[55]:
            stage.unit(68).setDir(stage.countDir(68, 0))
            stage.say('&68\n우리도 싸우자!')
        if not vars[56]:
            stage.unit(70).setDir(stage.countDir(70, 0))
            stage.say('&70\n오늘은 전임 영주의 남은 후회를 끝낼 때다!\n죽여라!')
        stage.unit(68).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(40).setAI(0)
        stage.unit(43).setAI(0)
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        vars[3] = 1
        vars[7] = 1
    if not vars[3] and not vars[30] and stage.isInRect(1025, 10, 3, 15, 6):
        stage.unit(66).show()
        stage.unit(37).show()
        stage.unit(54).show()
        stage.unit(53).show()
        stage.unit(382).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(383).show()
        stage.unit(66).setDir(stage.countDir(66, 0))
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(54).setDir(stage.countDir(54, 0))
        stage.unit(53).setDir(stage.countDir(53, 0))
        stage.say('&66\n야, 걸렸어!\n그럼 우리가 할 수 있는 게 없네.\n조조, 나 관수오랑 같이 왔어!\n&37\n발견됐다고? 좋아!\n나중에 내가 뭘 할 수 있는지 보여줄게.\n&54\n우리가 할 수 있는 게 없어.\n가, 관싱.\n&53\n좋아! 장바오!\n정면에서만 공격할 수 있어!')
        stage.unit(60).show()
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(44).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&60\n흥! 왜 매복도 못 해?\n&57\n싸워서 빠져나가자!\n&58\n한숨, 조금만 더 움직일 수만 있다면......\n&44\n모두 돌격!')
        stage.unit(0).setDir(stage.countDir(0, 66))
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.say('&0\n매복인가요......\n꽤 많은 사람이 있는 것 같아요.')
        stage.unit(0).setAction(5)
        stage.say('빨리 관문을 점령해서 방어 거점을 만들어라!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n무슨 일이 있어도 계획을 완수해야 해......\n어쩔 수 없이 주둔군도 투입하세요.\n무슨 일이 있어도 반드시 조조을 물리쳐야 해!')
            stage.unit(35).setAction(0)
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n나도 싸움에 합류할게!')
        stage.unit(34).setAI(1)
        stage.unit(50).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(35).setAI(0)
        stage.unit(59).setAI(0)
        stage.unit(298).setAI(0)
        stage.unit(299).setAI(0)
        if not vars[55]:
            stage.unit(68).setDir(stage.countDir(68, 0))
            stage.say('&68\n발각된 이후로는 아무것도 할 수 없었다.\n즉시 추격조조!')
        if not vars[56]:
            stage.unit(70).setDir(stage.countDir(70, 0))
            stage.unit(70).setAction(5)
            stage.say('&70\n뜻밖에도 조조 매복을 발견했다.\n모두 돌격!')
            stage.unit(70).setAction(0)
        stage.unit(68).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(40).setAI(0)
        stage.unit(43).setAI(0)
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        vars[3] = 1
        vars[30] = 1
    if not vars[3] and not vars[31] and stage.isInRect(1025, 0, 13, 3, 18):
        stage.unit(60).show()
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(44).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(60).setDir(stage.countDir(60, 0))
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.unit(44).setDir(stage.countDir(44, 0))
        stage.say('&60\n뭐-뭐라고!?\n발견했다!?\n야, 료화, 네가 헛소리 질러서 다 그렇잖아.\n&44\n무-무슨 소리야!\n난 한마디도 안 했어!\n&57\n리옌, 그만 싸워!\n어쨌든 지금이 해결책을 찾아야 할 때입니다......\n&58\n이 시점에서,\n그들은 정면으로 맞서야 했다.\n돌격!')
        stage.unit(66).show()
        stage.unit(37).show()
        stage.unit(54).show()
        stage.unit(53).show()
        stage.unit(382).show()
        stage.unit(390).show()
        stage.unit(391).show()
        stage.unit(383).show()
        stage.unit(66).setDir(stage.countDir(66, 0))
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(54).setDir(stage.countDir(54, 0))
        stage.unit(53).setDir(stage.countDir(53, 0))
        stage.say('&66\n리옌과 다른 이들이 위험에 처해 있었다.\n좋아! 내가 다 구하러 갈게!\n&37\n그렇게 순조롭게 풀리지 않을 거라는 걸 알고 있었어요.\n싸워라!\n&54\n우리가 할 수 있는 게 없어.\n가, 관싱.\n&53\n좋아! 장바오!\n정면에서만 공격할 수 있어!')
        stage.unit(0).setDir(stage.countDir(0, 66))
        stage.unit(0).setDir(stage.countDir(0, 60))
        stage.say('정말로 매복군이야. 그것도 꽤 많은 수로.')
        stage.unit(0).setAction(5)
        stage.say('빨리 관문을 점령해서 방어 거점을 만들어라!')
        stage.unit(0).setAction(0)
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(35).setAction(5)
            stage.say('&35\n무슨 일이 있어도 계획을 완수해야 해......\n다른 방법은 없고, 그냥 주둔군도 전투에 투입하는 거죠.\n무슨 일이 있어도 반드시 조조을 물리쳐야 해!')
            stage.unit(35).setAction(0)
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n나도 싸움에 합류할게!')
        stage.unit(34).setAI(1)
        stage.unit(50).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(35).setAI(0)
        stage.unit(59).setAI(0)
        stage.unit(298).setAI(0)
        stage.unit(299).setAI(0)
        if not vars[55]:
            stage.unit(68).setDir(stage.countDir(68, 0))
            stage.say('&68\n발각된 이후로는 아무것도 할 수 없었다.\n즉시 추격조조!')
        if not vars[56]:
            stage.unit(70).setDir(stage.countDir(70, 0))
            stage.unit(70).setAction(5)
            stage.say('&70\nUnexpectedly조조 이 사람이 매복을 발견했어.\n모두 돌격!')
            stage.unit(70).setAction(0)
        stage.unit(68).setAI(1)
        stage.unit(70).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(40).setAI(0)
        stage.unit(43).setAI(0)
        stage.unit(302).setAI(0)
        stage.unit(303).setAI(0)
        vars[3] = 1
        vars[31] = 1
    if not vars[32] and stage.isInRect(0, 22, 5, 23, 23):
        stage.resumeCtrl()
        if not vars[50]:
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.say('&35\n안 돼! 조조 뚫었어......\n조의 군대는 예상보다 훨씬 끈질겼다.\n계획을 수정해야 할 것 같군. 후퇴!')
        if not vars[51]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n후퇴! 장에로 후퇴해 그들과 맞서라!')
        if not vars[54]:
            stage.unit(40).setDir(stage.countDir(40, 0))
            stage.say('&40\n한숨, 다음번엔 고인의 후회를 정리해야겠네.\n후퇴!')
        if not vars[59]:
            stage.unit(37).setDir(stage.countDir(37, 0))
            stage.say('&37\n공명의 계획도 실패하고 있는 것 같습니다.\n조조That가 대단해! 후퇴!')
        if not vars[63]:
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.say('&57\n다음번엔 무슨 일이 있어도 죽여조조......\n철수해!')
        stage.setRectUnitHide(0, 0, 23, 31, 2)
        vars[32] = 1
        stage.say('&0\n쑤 군대는 퇴각했다.\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[639] = 1
        return True
    if not vars[40] and stage.isNear(0, 34, True):
        stage.unit(0).setDir(stage.countDir(0, 34))
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.say('&0\n유비Since 이미 세상을 떠났으니,\n더 이상 슈에게 충성할 필요 없어.\n어때? 나한테 와?\n&34\n비록 전 영주가 돌아가셨지만, 유비\n하지만 그 정신은 계속 남아 있습니다.\n절대 배신하지 않을 주군!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 35, True):
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.say('&35\n이번에는 내 속임수에 넘어가지 않았지만,\n그럼에도 불구하고 조준의 투지는 여전히 존경스럽다.\n&0\n과거에 너한테 많은 고통을 겪었어,\n다시는 이런 일 없을 거야.\n이거 기억해, 공명!')
        vars[41] = 1
    if not vars[42] and stage.isNear(19, 50, True):
        stage.unit(50).setDir(stage.countDir(50, 19))
        stage.unit(19).setDir(stage.countDir(19, 50))
        stage.say('&19\n당신이 공명의 사랑받는 장군이라고 들었어요,\n자신을 위한 가장 큰 희망을 모으며,\n그게 전부인 것 같아요......\n&50\n하하하, 더 이상 숨길 필요 없어.\n&50\n나는 네 소심한 마음을 꿰뚫어봤어.\n&19\n(그의 자존심은 꽤 강하지만,\n하지만 여전히 제 사마의에는 맞지 않습니다. )')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&57\n멈춰! 조조!\n내 마초 한 방 맞아!\n&0\n(음, 정말 골칫거리네...... )')
        vars[43] = 1
    if not vars[44] and stage.isNear(19, 37, True):
        stage.unit(37).setDir(stage.countDir(37, 19))
        stage.unit(19).setDir(stage.countDir(19, 37))
        stage.say('&37\n저는 전략가 같은 사람과는 전혀 잘 맞지 않아요,\n너도 내가 싫어하는 사람이야,\n내 찔림을 받아라!\n&19\n당신 같은 무모한 남자가,\n너무 쉽게 다루기 쉬웠다.')
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n전 영주가 사망한 후에도 많은 미해결 문제들이 남아 있었다,\n하지만 공명 완성하고 싶긴 해요, ......\n한숨, 후퇴!')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n안 돼! 너무 부주의해!\n후퇴!')
        stage.unit(34).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n아, 어떻게 이런 지경까지 된 거지......\n아마 운이 안 좋았던 걸지도 몰라요!\n후퇴!')
        stage.unit(50).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(59, 7, 0, 2):
        stage.say('&59\n안 돼, 못 버텨!\n후퇴!')
        stage.unit(59).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(40, 7, 0, 2):
        stage.say('&40\n남아 있는 후회는 해결되지 않았다,\n하지만 결국 철수할 수밖에 없었다.\n유비주군, 미안해.')
        stage.unit(40).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(68, 7, 0, 2):
        stage.say('&68\n승패는 군사 전략에서 흔히 일어나는 문제입니다.\n후퇴.')
        stage.unit(68).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(70, 7, 0, 2):
        stage.say('&70\n안 돼! 빨리 후퇴해!')
        stage.unit(70).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(43, 7, 0, 2):
        stage.say('&43\n안타깝게도 그들은 패배했다.\n순종적으로 후퇴하는 게 낫다.')
        stage.unit(43).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(66, 7, 0, 2):
        stage.say('&66\n음, 오늘은 돌봄의 날이라고 하자!\n조조Old 도둑, 다시 만날 때까지!"')
        stage.unit(66).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n젠장! 후퇴!\n다음번에는 꼭 ......')
        stage.unit(37).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(54, 7, 0, 2):
        stage.say('&54\n아!\n후퇴, 후퇴!\n정말 운이 없네요!')
        stage.unit(54).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(53, 7, 0, 2):
        stage.say('&53\n길을 잃었어, 길을 잃었어!\n여기서 물러날 줄은 몰랐어......')
        stage.unit(53).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(60, 7, 0, 2):
        stage.say('&60\n한숨.........\n공명와 마수의 계획은 더 철저할 것이다.\n…… 후퇴!')
        stage.unit(60).hide(1)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n물러나야 할까요......?\n후회......!')
        stage.unit(57).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n아, 안 돼, 졌어!\n미안, 먼저 물러나겠어!')
        stage.unit(58).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(44, 7, 0, 2):
        stage.say('&44\n아, 이번엔 너무 부주의했어!\n다음에 만나는 날이 네 죽는 날이 될 거야.\n후퇴!')
        stage.unit(44).hide(1)
        vars[65] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 제거했어!\n아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[639] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 류산의 군대 앞에서 큰 패배를 겪었으나 돌아왔다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
