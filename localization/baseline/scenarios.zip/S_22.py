# Source Generated with Decompyle++
# File: S_22.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(0,2)',
        '(0,1)',
        '(1,1)',
        '(1,2)',
        '(4,6)',
        '(6,8)',
        '(20,1)',
        '(21,1)'])
    stage.nearEvent([
        0,
        106,
        0,
        118,
        0,
        115,
        117,
        106,
        117,
        115,
        8,
        115], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 117,
            'x': 16,
            'y': 18,
            'dir': 0,
            'lv': 4,
            'ai': 5,
            'targetId': 0,
            'i': 0 },
        {
            'id': 318,
            'hide': 1,
            'x': 3,
            'y': 9,
            'lv': 0,
            'ai': 1,
            'i': 1 },
        {
            'id': 319,
            'hide': 1,
            'x': 2,
            'y': 2,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 2 }])
    stage.createEnemy(
        [{'id': 106, 'x': 0, 'y': 2, 'dir': 1, 'lv': 6, 'i': 0},
         {'id': 234, 'x': 1, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 1},
         {'id': 235, 'x': 1, 'y': 2, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 2},
         {'id': 298, 'x': 0, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 3},
         {'id': 210, 'x': 3, 'y': 9, 'lv': 0, 'ai': 0, 'i': 4},
         {'id': 211, 'x': 4, 'y': 9, 'lv': 0, 'ai': 0, 'i': 5},
         {'id': 212, 'x': 7, 'y': 5, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 6},
         {'id': 213, 'x': 7, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 7},
         {'id': 236, 'x': 2, 'y': 9, 'lv': 0, 'ai': 0, 'i': 8},
         {'id': 237, 'x': 5, 'y': 9, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 238, 'x': 7, 'y': 4, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 10},
         {'id': 239, 'x': 7, 'y': 7, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 11},
         {'id': 299, 'x': 3, 'y': 7, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 300, 'x': 5, 'y': 5, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 310, 'x': 4, 'y': 6, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 14},
         {'id': 311, 'x': 6, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 0, 'i': 15},
         {'id': 118, 'x': 20, 'y': 1, 'lv': 4, 'i': 16},
         {'id': 214, 'x': 19, 'y': 0, 'lv': 0, 'ai': 0, 'i': 17},
         {'id': 215, 'x': 22, 'y': 0, 'lv': 0, 'ai': 0, 'i': 18},
         {'id': 216, 'x': 20, 'y': 4, 'lv': 0, 'i': 19},
         {'id': 217, 'x': 21, 'y': 4, 'lv': 0, 'i': 20},
         {'id': 240, 'x': 20, 'y': 3, 'lv': 0, 'i': 21},
         {'id': 241, 'x': 21, 'y': 3, 'lv': 0, 'i': 22},
         {'id': 242, 'x': 19, 'y': 4, 'lv': 0, 'i': 23},
         {'id': 243, 'x': 22, 'y': 4, 'lv': 0, 'i': 24},
         {'id': 301, 'x': 21, 'y': 1, 'lv': 0, 'ai': 0, 'i': 25},
         {'id': 312, 'x': 18, 'y': 2, 'lv': 0, 'ai': 0, 'i': 26},
         {'id': 313, 'x': 23, 'y': 2, 'lv': 0, 'ai': 0, 'i': 27},
         {'id': 115,
          'hide': 1,
          'x': 31,
          'y': 6,
          'dir': 3,
          'lv': 4,
          'ai': 6,
          'targetX': 9,
          'targetY': 5,
          'i': 28},
         {'id': 218,
          'hide': 1,
          'x': 30,
          'y': 6,
          'dir': 3,
          'lv': 0,
          'ai': 6,
          'targetX': 9,
          'targetY': 6,
          'i': 29},
         {'id': 219,
          'hide': 1,
          'x': 30,
          'y': 7,
          'dir': 3,
          'lv': 0,
          'ai': 6,
          'targetX': 10,
          'targetY': 5,
          'i': 30},
         {'id': 244,
          'hide': 1,
          'x': 31,
          'y': 7,
          'dir': 3,
          'lv': 0,
          'ai': 6,
          'targetX': 10,
          'targetY': 6,
          'i': 31},
         {'id': 258, 'hide': 1, 'x': 29, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 259, 'hide': 1, 'x': 29, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 260, 'hide': 1, 'x': 29, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 261, 'hide': 1, 'x': 29, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 282, 'hide': 1, 'x': 30, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 283, 'hide': 1, 'x': 30, 'y': 4, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 284, 'hide': 1, 'x': 30, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 285, 'hide': 1, 'x': 30, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 39}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 17,
            'y': 18,
            'dir': 0 },
        {
            'idx': 1,
            'x': 18,
            'y': 18,
            'dir': 0 },
        {
            'idx': 2,
            'x': 17,
            'y': 16,
            'dir': 0 },
        {
            'idx': 3,
            'x': 15,
            'y': 16,
            'dir': 0 },
        {
            'idx': 4,
            'x': 19,
            'y': 16,
            'dir': 0 },
        {
            'idx': 5,
            'x': 14,
            'y': 17,
            'dir': 0 },
        {
            'idx': 6,
            'x': 20,
            'y': 17,
            'dir': 0 },
        {
            'idx': 7,
            'x': 16,
            'y': 17,
            'dir': 0 },
        {
            'idx': 8,
            'x': 18,
            'y': 17,
            'dir': 0 },
        {
            'idx': 9,
            'x': 15,
            'y': 19,
            'dir': 0 },
        {
            'idx': 10,
            'x': 19,
            'y': 19,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(106, 52, 0, -1, 0, -1)
    stage.loadBg(22)
    stage.setObjects(True, 17, [
        [
            16,
            3,
            1],
        [
            17,
            3,
            2]])
    stage.setObjects(True, 17, [
        [
            12,
            0,
            5],
        [
            13,
            1,
            5]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab29')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab29')
    stage.draw()
    stage.bgSound(1)
    stage.unit(118).setDir(stage.countDir(118, 0))
    stage.unit(118).setAction(5)
    stage.say('&118\n조조 늙은 도둑이 드디어 도착했어!\n군대 전체가 전투 준비를 마쳤다,\n조조의 공격을 경계하라!')
    stage.unit(118).setAction(0)
    stage.unit(106).setDir(stage.countDir(106, 0))
    stage.unit(106).setAction(2)
    stage.say('&106\n성문을 닫아라! 적이 접근하지 못하게 하라.\n원상주군 돌아오기 전에,\n무슨 일이 있어도 반드시 지켜야 해!')
    stage.setObjects(True, 17, [
        [
            10,
            8,
            5],
        [
            11,
            8,
            6]])
    stage.setObjects(True, 17, [
        [
            14,
            3,
            10],
        [
            15,
            4,
            10]])
    stage.say('&0\n이 도시는 공격하기 쉽지 않다,\n조언 있으신가요?')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n먼저, 한단의 사슴 요새를 공격하세요.\n&22\n이곳을 점령하면 도시 밖의 적들을 제거할 수 있습니다,\n그 후 평화롭게 도시를 포위할 수 있었다.')
    stage.unit(117).setDir(stage.countDir(117, 0))
    stage.say('&117\n곽가 씨의 전략은 합리적으로 들릴 수 있지만,\n하지만 저는 예시의 내부 사정을 잘 알고 있습니다.\n제가 제안할 계획이 있습니다.')
    stage.unit(0).setDir(stage.countDir(0, 117))
    stage.say('&0\n오?\n좋아, 말해봐.\n&117\n도시 안에는 내가 신뢰하는 사람들이 있다,\n도시 문을 열라고 알릴 수 있어.\n&117\n만약 성문이 한 번에 함락된다면,\n우리는 자유롭게 오가고 갈 수 있습니다,\n예시도 쉽게 접근할 수 있는 곳이었다.\n&0\n음, 아주 좋아......')
    stage.unit(0).setDir(0)
    stage.unit(22).setDir(0)
    stage.unit(117).setDir(0)
    sel = stage.choice('공격은 예시에서 시작되었다\n공격은 한단의 사슴 요새에서 시작되었다', -1)
    if sel == 1:
        stage.say('&0\n만약 우리가 성문을 열 방법을 찾는다면,\n예시는 쉽게 점령될 수 있었다.\n그렇다면 예시를 공격합시다!\n&22\n그래, 전 군대가 공격 준비를 하게 하라.')
        stage.unit(22).setAction(9)
        stage.say('&22\n기침, 기침.........')
        stage.unit(0).setDir(stage.countDir(0, 22))
        stage.say('&0\n무슨 일이야? 곽가.\n괜찮아?\n&22\n조금 uncomfortable......주군 것 같으니 걱정하지 마세요,\n하룻밤만 쉬고 괜찮아; 먼저 도시를 공격하자.\n&0\n정말?\n몸이 안 좋으면 억지로 싸울 필요 없어.')
        stage.unit(0).setDir(stage.countDir(0, 117))
        stage.say('&0\n신비, 네가 안내자로 해!\n&117\n총리께서 안심해 주시길 부탁드립니다.\n도시 문을 열러 데려가겠습니다.')
        stage.unit(117).move(11, 18, 3)
        stage.unit(117).setAI(6, -1, 3, 15)
        stage.unit(8).setDir(stage.countDir(8, 117))
        stage.say('&8\n(저 사람 믿을 만한가?\n아버지는 그를 너무 쉽게 믿었어. )')
        vars[2] = 1
    elif sel == 2:
        stage.say('좋습니다, 먼저 한단의 녹재에 진격하겠습니다!\n후방의 걱정을 해결하기 위함입니다.\n신비의 전략 자체는\n무슨 의심할 여지가 없으나,\n만약 실패하면 전군이 멸망하는 위험이 있습니다.\n그렇다면 전군을 출동 준비하도록 하겠습니다.')
        stage.unit(22).setAction(9)
        stage.say('&22\n기침, 기침.......')
        stage.unit(0).setDir(stage.countDir(0, 22))
        stage.say('&0\n무슨 일이야? 곽가.\n괜찮아?\n&22\n조금 uncomfortable......주군 것 같으니 걱정하지 마세요,\n하룻밤만 쉬고 괜찮아; 먼저 도시를 공격하자.\n&0\n정말?\n몸이 안 좋으면 억지로 싸우지 마.')
        stage.unit(0).setDir(stage.countDir(0, 117))
        stage.say('&0\n한단을 포획한 후,\n그럼 신비의 전략대로 진행하세요.\n&117\n네.')
        stage.unit(8).setDir(stage.countDir(8, 0))
        stage.say('&8\n전장에 나가는 건 이번이 처음이야,\n너무 신나요.')
    stage.bgSound(3)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 25명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[522] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[2] and not vars[11] and stage.round() == 3:
        stage.unit(117).setAI(6, -1, 3, 11)
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 0, 2):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 0, 1):
        stage.getItem(153, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 1, 1):
        stage.getItem(150, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 1, 2):
        stage.getItem(150, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 4, 6):
        stage.getItem(150, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 6, 8):
        stage.getItem(150, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 20, 1):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 21, 1):
        stage.getItem(150, -1, True, 1025)
        vars[27] = 1
    if not vars[6] and not vars[7] and stage.totalRectUnit(2, 17, 0, 24, 4) < 8 and stage.curCamp() == 0:
        stage.unit(115).show()
        stage.unit(218).show()
        stage.unit(219).show()
        stage.unit(244).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(284).show()
        stage.unit(285).show()
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.say('&115\n도둑조조Old!"\n그들이 실제로 여기까지 공격했어......')
        if not vars[31] and not vars[32] and not vars[33]:
            stage.unit(115).setAction(5)
            stage.say('&115\n위기는 임박했다,\n조조 루자이에 집중하는 동안,\n빨리 도심으로 도망쳐!')
            stage.unit(115).setAction(0)
            stage.unit(106).setDir(stage.countDir(106, 115))
            stage.say('&106\n오, 주군 돌아왔어!\n즉시 성문을 열어라!\n도시에 오신 주군 것을 환영합니다!')
            stage.unit(0).setDir(stage.countDir(0, 115))
            stage.say('&0\n마침내 아이 위안 샹이 도착했다.\n좋아, 즉시 루자이를 잡고 원상과 맞서라!')
            if not vars[53]:
                stage.unit(117).setDir(stage.countDir(117, 0))
                stage.say('&117\n총리님, 잠시만 기다려 주십시오,\n당분간은 원상에 대한 원정을 벌일 수 없었다.')
                stage.unit(0).setDir(stage.countDir(0, 117))
                stage.say('&0\n뭐라고!?\n&117\n지금이 예시를 점령할 완벽한 기회다,\n도망치는 원상을 쫓는 한,\n아군 쉽게 도시로 들어갈 수 있습니다.\n&0\n맞아!\n그들은 반드시 성문을 열어 원상을 구할 것이다,\n이 way아군 그들은 한 번에 도시로 돌진할 수 있었다.\n&117\n도시 안으로 들어가면 모든 것이 훨씬 쉬워진다,\n우리는 분명히 도시를 점령할 수 있을 거예요.')
            else:
                stage.unit(115).setAction(5)
                stage.say('&115\n모두, 서둘러 뒤로 숨어!')
                stage.unit(115).setAction(0)
                stage.unit(0).setDir(stage.countDir(0, 115))
                stage.say('&0\n마침내 아이 위안 샹이 도착했다.\n좋아, 즉시 루자이를 잡고 원상과 맞서라!')
                stage.setAI(27, 0, 31, 19, 2, 1)
        vars[6] = 1
    if not vars[7] and not vars[32] and not vars[50] and stage.totalRectUnit(2, 0, 0, 7, 9) < 5:
        stage.unit(106).setAction(4)
        stage.say('&106\n예시가 위험에 처했어!\n하지만 그렇게 쉽게 조조에게 주진 않을 거예요!')
        stage.unit(106).setAction(6)
        stage.say('&106\n방화!')
        stage.unit(106).setAction(0)
        stage.setFires(True, [
            [
                0,
                0],
            [
                0,
                1],
            [
                0,
                2],
            [
                0,
                3],
            [
                0,
                4]])
        stage.setFires(True, [
            [
                1,
                0],
            [
                1,
                1],
            [
                1,
                2],
            [
                1,
                3],
            [
                1,
                4]])
        stage.setFires(True, [
            [
                2,
                0],
            [
                2,
                1],
            [
                2,
                2],
            [
                2,
                3],
            [
                2,
                4]])
        stage.unit(0).setDir(stage.countDir(0, 106))
        stage.say('&106\n하하하하......')
        stage.unit(106).hide(2)
        stage.unit(234).hide(2)
        stage.unit(235).hide(2)
        stage.unit(298).hide(2)
        vars[50] = 1
        stage.setFires(True, [
            [
                0,
                0],
            [
                0,
                1],
            [
                0,
                2],
            [
                0,
                3],
            [
                0,
                4]])
        stage.setFires(True, [
            [
                1,
                0],
            [
                1,
                1],
            [
                1,
                2],
            [
                1,
                3],
            [
                1,
                4]])
        stage.setFires(True, [
            [
                2,
                0],
            [
                2,
                1],
            [
                2,
                2],
            [
                2,
                3],
            [
                2,
                4]])
        stage.say('&0\n심배......\n정말 존경스러운 상대군.')
        stage.unit(117).setAI(3, 0, 0, 0)
        if not vars[6]:
            stage.unit(115).show()
            stage.unit(218).show()
            stage.unit(219).show()
            stage.unit(244).show()
            stage.unit(258).show()
            stage.unit(259).show()
            stage.unit(260).show()
            stage.unit(261).show()
            stage.unit(282).show()
            stage.unit(283).show()
            stage.unit(284).show()
            stage.unit(285).show()
            stage.say('&115\n응? 예시티가 불타고 있어......\n아직 한 걸음 늦었어......\n&115\n다른 선택지가 없어 그들은 후퇴할 수밖에 없었다.\n도둑조조Old, 이걸 명심해!"')
            if not vars[51]:
                stage.unit(115).setDir(stage.countDir(115, 118))
                stage.say('&115\n저곡, 빨리 조의 군대를 막아라!')
                stage.unit(118).setDir(stage.countDir(118, 115))
                stage.say('&118\n네!')
                stage.unit(118).setAI(1)
                stage.unit(214).setAI(1)
                stage.unit(215).setAI(1)
                stage.unit(216).setAI(1)
                stage.unit(217).setAI(1)
                stage.unit(240).setAI(1)
                stage.unit(241).setAI(1)
                stage.unit(242).setAI(1)
                stage.unit(243).setAI(1)
                stage.unit(301).setAI(1)
                stage.unit(312).setAI(1)
                stage.unit(313).setAI(1)
            stage.setRectUnitHide(29, 0, 31, 19, 2)
            vars[52] = 1
        vars[7] = 1
    if not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 17, 0, 24, 4):
        stage.unit(118).setAction(5)
        stage.say('&118\n적이 사슴 요새에 들어오지 못하게 하라,\n무슨 일이 있어도 적을 막아야 한다!')
        stage.unit(118).setAction(0)
        stage.unit(118).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(240).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(242).setAI(1)
        stage.unit(243).setAI(1)
        stage.unit(301).setAI(1)
        stage.unit(312).setAI(1)
        stage.unit(313).setAI(1)
        vars[30] = 1
    if not vars[31] and not vars[32] and not vars[33] and stage.curCamp() == 0 and stage.isInRect(117, 2, 11, 5, 13):
        stage.unit(117).setDir(0)
        stage.say('&117\n성문을 열 시간이다!')
        stage.setRectUnitHide(3, 9, 3, 9, 2)
        stage.unit(318).show()
        stage.unit(318).setDir(stage.countDir(318, 117))
        stage.say('&318\n오, 신비님,\n우리가 기다리고 있어.')
        stage.setObjects(False, 16, [
            [
                14,
                3,
                10],
            [
                15,
                4,
                10]])
        stage.unit(106).setDir(stage.countDir(106, 117))
        stage.unit(106).setAction(10)
        stage.say('&106\n뭐-뭐라고!?\n왜 성문이 열렸지!\n도시 경비대는 무슨 일이야!')
        stage.unit(0).setDir(stage.countDir(0, 117))
        stage.unit(0).setAction(5)
        stage.say('&0\n신비, 잘했어.\n군대 전체가 예시로 돌진했다!\n한 번에 예시를 점령하라!')
        stage.unit(0).setAction(0)
        stage.unit(117).setAI(6, -1, 4, 1)
        vars[31] = 1
    if not vars[7] and not vars[32] and stage.isInRect(117, 4, 0, 7, 5):
        stage.unit(117).setDir(3)
        stage.say('&117\n빨리, 성문을 열어라,\n적들이 눈치채기 전에. 서둘러!')
        stage.setRectUnitHide(2, 2, 2, 2, 2)
        stage.unit(319).show()
        stage.unit(318).setDir(stage.countDir(318, 117))
        stage.say('&319\n오랫동안 조급하게 기다렸어요!')
        stage.setObjects(False, 16, [
            [
                16,
                3,
                1],
            [
                17,
                3,
                2]])
        stage.unit(106).setDir(stage.countDir(106, 117))
        stage.say('&106\n젠장, 도심 문이 열려 있어......\n누군가 실제로 적군......와 공모했어!\n&0\n좋아, 서둘러 들어와!')
        stage.unit(0).setDir(stage.countDir(0, 106))
        stage.unit(117).setAI(3, 0, 0, 0)
        stage.unit(106).setAI(1)
        vars[32] = 1
    if vars[6] and not vars[33] and stage.isInRect(115, 9, 4, 11, 7):
        stage.unit(115).setDir(3)
        stage.unit(115).setAction(7)
        stage.say('&115\n심배, 내 원상이야!\n즉시 성문을 열어라!')
        stage.unit(115).setAction(0)
        stage.unit(106).setDir(stage.countDir(106, 115))
        stage.say('&106\n문 열어, 문 열어!\n도시로 주군 들어가, 서둘러!')
        stage.setObjects(False, 16, [
            [
                10,
                8,
                5],
            [
                11,
                8,
                6]])
        if not vars[31]:
            stage.unit(0).setDir(stage.countDir(0, 115))
            stage.say('&0\n문이 닫히기 전에 빨리 들어가라! \n성문이 닫히면 우리는 어쩔 도리가 없다!')
        stage.unit(115).setAI(6, -1, 1, 6)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        stage.unit(244).setAI(1)
        stage.unit(117).setAI(6, -1, 4, 1)
        vars[33] = 1
    if vars[33] and not vars[34] and stage.isInRect(115, 0, 6, 2, 9):
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.unit(115).setAction(4)
        stage.say('&115\n오, 안 돼!\n이러다간 목숨을 잃을 거야......\n나는 .........할 방법을 찾아야 해요')
        stage.unit(115).setAI(0)
        vars[34] = 1
    if not vars[40] and stage.isNear(0, 106, True):
        stage.unit(0).setDir(stage.countDir(0, 106))
        stage.unit(106).setDir(stage.countDir(106, 0))
        stage.say('&0\n심배, 실패했어.\n차라리 항복하는 게 낫겠다!\n네 목숨은 살려줄 수 있어.\n&106\n젠장......')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 118, True):
        stage.unit(118).setDir(stage.countDir(118, 0))
        stage.unit(0).setDir(stage.countDir(0, 118))
        stage.say('&118\n조조, 조심해!\n목숨을 걸고 너를 죽일 거야!\n&0\n야망이 있긴 하지만,\n안타깝게도 그는 그런 실력이 없어요!')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 115, True):
        stage.unit(0).setDir(stage.countDir(0, 115))
        stage.unit(115).setDir(stage.countDir(115, 0))
        stage.say('&0\n원상, 오늘이 네가 죽는 날이야,\n아버지를 순종적으로 찾아가!\n&115\n말은 그만해! 도둑 조!\n널 지옥에 보내버릴 거야!')
        vars[42] = 1
    if not vars[43] and stage.isNear(117, 106, True):
        stage.unit(106).setDir(stage.countDir(106, 117))
        stage.unit(117).setDir(stage.countDir(117, 106))
        stage.say('&106\n배신자야!\n&117\n원소주군가 죽은 후,\n원 형제들은 사이가 좋지 않았다......\n물론, 나는 또 다른 현명한 통치자를 찾아야 한다.\n&117\n심배! 궈투!\n너희 둘이 그들 사이에 소란을 일으켰어,\n네 죄는 결코 작은 것이 아니다!\n&106\n무-무슨 ......?')
        vars[43] = 1
    if not vars[44] and stage.isNear(117, 115, True):
        stage.unit(115).setDir(stage.countDir(115, 117))
        stage.unit(117).setDir(stage.countDir(117, 115))
        stage.say('&115\n신비?\n왜 조조의 군대에 합류했......?\n&117\n이제 위안 가문은 예전과 다르다,\n신비 자연스럽게 시대를 이해합니다.\n&115\n개자식!\n불충하고 부정한 놈, 내가 널 죽여 보라!')
        vars[44] = 1
    if not vars[45] and stage.isNear(8, 115, True):
        stage.unit(115).setDir(stage.countDir(115, 8))
        stage.unit(8).setDir(stage.countDir(8, 115))
        stage.say('&8\n나는 조조조비의 아들이다\n아버지의 상대가 누군지 보자!\n&115\n조조 아들이라고!?\n내가 널 죽이는 걸 지켜봐.\n&8\n흥, 쓸모없는 녀석,\n당신은 저와 말할 권리가 없습니다.\n&115\n뭐라고!!!\n이 자식아, 널 그냥 두지 않을 거야.')
        vars[45] = 1
    if not vars[50] and stage.unitStateTest(106, 7, 0, 2):
        stage.say('&106\n아-아, 안 돼!\n아이고......')
        stage.unit(106).hide(2)
        stage.getItem(50, -1, True, 1027)
        if vars[32] and not vars[6]:
            stage.say('&0\n네, 함단 (Han Dan) 의 녹재만 남았습니다.\n원상 (Yuan Shang) 이 도착하기 전에는,\n일시에 이를 정복해내겠습니다!')
            stage.setObjects(False, 16, [
                [
                    10,
                    8,
                    5],
                [
                    11,
                    8,
                    6]])
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(118, 7, 0, 2):
        stage.say('&118\n잃었고, 실패했다.\n와!')
        stage.unit(118).hide(2)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(115, 7, 0, 2):
        stage.say('&115\n예시가 항복했다......\n끝났어...... 후퇴해.')
        stage.unit(115).hide(1)
        if not vars[2] and not vars[31] and not vars[32] and not vars[33]:
            stage.say('&106\n젠장!\n그들은 이 도시조차 지키지 못했어!')
            if not vars[53]:
                stage.say('&117\n내가 성문을 열 거야,\n제발 조조주군 엄호해 주세요.')
                stage.unit(117).setAI(6, -1, 3, 11)
            else:
                stage.say('&0\n좋지 않아요, 신비도 무너졌어요.\n성문이 열리지 않기 때문에,\n그래서 그들은 먼저 후퇴할 수밖에 없었다.')
                stage.info('조조 원상에게 패배했다.')
                stage.end()
                stage.lose()
                vars[1] = 1
                return True
            vars[52] = 1
            if not vars[53] and stage.unitStateTest(117, 7, 0, 2):
                if not vars[31] and not vars[32] and not vars[33]:
                    stage.say('&117\n아, 안 돼......\n나 없이는 도시에서 신뢰하는 보좌관들과 연락할 수 없어.\n&117\n이렇게 하면 성문이 열릴 수 없고,\n총리는 어떻게 해야 할지 몰라 당황했다.')
                stage.say('&117\n그는 여기서 죽을 거라고는 전혀 예상하지 못했다......\n아!')
                stage.unit(117).hide(2)
                vars[53] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        if not vars[7]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[622] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 원상에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
