# Source Generated with Decompyle++
# File: R_01.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(-1)
    stage.video('레벨 클리어 애니메이션을 재생하나요?', 3)
    if stage.video() == 1:
        stage.video(1)
    stage.bgSound(16)
    stage.sectionName(1, '오버로드의 탄생')
    stage.loadBg(0, 16)
    stage.draw()
    stage.video('약 1,800년 전,\n동한 말기 중국 본토.')
    stage.video('그때 영제는 쾌락에 빠져 있었고, 조정은 부패했다,\n백성들은 굶주렸고, 한나라에 대한 불만은 더욱 커졌다\n정상에 도달했어.')
    stage.video('지금 이 순간, ......,')
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(147, 320, 180)
    stage.showHead(146, 440, 130)
    stage.delay(5)
    stage.bottomTxt('태평도파의 지도자 장교가 이끄는 황번의 반란,', False, True, False)
    stage.delay(5)
    stage.bottomTxt('이로 인해 중국 전역에서 발병이 발생했다.', True, False, False)
    stage.delay(10)
    stage.showHead(0, 260, 60)
    stage.delay(5)
    stage.bottomTxt('그가 지휘한 정부군 조조,', True, True, False)
    stage.head(0).move(320, 60)
    stage.delay(5)
    stage.head(147).hide()
    stage.head(146).hide()
    stage.delay(5)
    stage.bottomTxt('그들은 이 반란군을 진압하기 위해 큰 어려움을 겪었지만,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그러나 그는 더 이상 한나라의 쇠퇴를 막을 수 없었다.', True, True, True)
    stage.bottomTxt('이것이 혼란스러운 시대의 시작이었습니다.', False, True, True)
    stage.loadBg(0, 16)
    stage.draw()
    stage.video('황띠의 난이 진압된 지 얼마 지나지 않아, 영제가 곧 서거하셨다,\n지도자 부재 상황을 이용해 궁정은 움직이기 시작했다\n치열한 권력 투쟁.')
    stage.video('마지막에 동탁은 자신의 힘으로 조정의 혼란을 틈타 낙양의 실권을 장악했다.')
    stage.bgSound(-1)
    return False


def scene1():
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            192,
            52,
            41,
            2],
        [
            193,
            58,
            41,
            2],
        [
            131,
            64,
            41,
            2],
        [
            128,
            70,
            41,
            2],
        [
            101,
            52,
            70],
        [
            0,
            58,
            70],
        [
            133,
            64,
            70],
        [
            134,
            70,
            70]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.setEventName('조조가 군대를 일으키다')
    stage.setStageName('낙양 @ 총리관')
    stage.delay(3)
    stage.unit(101).setAction(-1, 1)
    stage.say('&101\n동탁 남자가 갑자기 우리를 불렀는데—도대체 무슨 일이야?"\n어떻게 생각해? 조조!')
    stage.unit(0).setAction(-1, 3)
    stage.say('세상이 이미 그 손아귀에 들어왔다고 우리에게 알려주려는 거겠지.')
    stage.unit(101).setAction(2)
    stage.say('&101\n세상이라고!? 젠장, 저 녀석은 정말 짐승이야.......')
    stage.unit(0).setAction(-1, 0)
    stage.say('...본초, 몇 마디 더 해야겠군. 짐승 같은 분이 오셨어.')
    stage.unit(101).setAction(0, 0)
    stage.showUnit(127, 90, 55, 3)
    stage.unit(127).move(84, 55, 3)
    stage.showUnits([
        [
            119,
            90,
            58,
            3],
        [
            132,
            90,
            52,
            3]])
    stage.unitsMove([
        [
            stage.unit(127),
            41,
            55,
            3],
        [
            stage.unit(119),
            47,
            58,
            3],
        [
            stage.unit(132),
            47,
            52,
            3]])
    stage.unit(127).setAction(0)
    stage.unit(119).setAction(0)
    stage.unit(132).setAction(0)
    stage.delay(3)
    stage.unit(127).move(41, 58, 2)
    stage.unit(127).move(33, 58, 3)
    stage.unit(127).move(33, 55, 1)
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(119),
            41,
            58,
            3],
        [
            stage.unit(132),
            41,
            52,
            3]])
    stage.unit(119).setAction(0)
    stage.unit(132).setAction(0)
    stage.delay(3)
    stage.unit(132).move(41, 46, 0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(119),
            33,
            58,
            3],
        [
            stage.unit(132),
            33,
            46,
            3]])
    stage.unitsMove([
        [
            stage.unit(119),
            33,
            61,
            1],
        [
            stage.unit(132),
            33,
            47,
            1]])
    stage.unit(119).setAction(0)
    stage.unit(132).setAction(0)
    stage.delay(5)
    stage.unit(127).setAction(3)
    stage.say('&127\n하하하, 다들 왔네.')
    stage.unit(127).setAction(0)
    stage.say('&127\n오늘은 모두를 모아 큰 행사를 발표합니다.')
    stage.unit(192).setAction(6)
    stage.say('&192\n총리가 발표한 중요한 사항이 무엇인지 모르겠습니다.')
    stage.unit(192).setAction(0)
    stage.say('&127\n황제에 관한 것이었어.')
    stage.unit(127).setAction(17)
    stage.say('&127\n나는 오늘날의 무능한 황제를 폐위시키려 한다,\n천류왕이 새 황제로 세워졌다.')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(3)
    stage.say('&192\n뭐-뭐라고!?')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n이......!')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n흥.......')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n……。')
    stage.unit(127).setAction(3)
    stage.say('&127\n어떻게? 어떤 이의가 있나요?')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n…… 아니, 아니.')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(6)
    stage.say('&192\n모든 것은 총리의 명령에 달려 있습니다.')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n젠장!')
    stage.unit(0).setAction(0, 2)
    stage.say('...잠깐, 본초. 일단 그의 말을 들어보자.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0, 1)
    stage.delay(3)
    stage.unit(101).setAction(2)
    stage.say('&101\n뭐라고!?\n조조, 이런 때에 왜 저 사람을 죽이지 않는 거야!?\n&0\n장군이 동탁 옆에 서 있는 거 봤어?\n그는 여포!')
    stage.unit(101).setAction(0)
    stage.say('&101\n여포가 누구야?\n&0\n모르겠어? 그는 세상에서 비할 데 없는 영웅이야.\n칼을 뽑고 나오면,\n그건 헛된 죽음일 뿐이었다.\n그만두세요, 지금은 그냥 따르는 게 낫습니다.')
    stage.unit(101).setAction(2)
    stage.say('&101\n얼마나 혐오스러운 .......')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0, 0)
    stage.unit(0).setAction(-1, 0)
    stage.delay(5)
    stage.unit(127).setAction(3)
    stage.say('&127\n하하하!')
    stage.unit(127).setAction(0)
    stage.say('&127\n알겠어요, 그렇군요.\n모두 동의하죠?')
    stage.unit(127).setAction(0, 0)
    stage.say('&127\n리루.')
    stage.unit(132).setAction(0, 2)
    stage.delay(3)
    stage.unit(132).setAction(6)
    stage.say('&132\n존재한다.')
    stage.unit(127).setAction(3)
    stage.say('&127\n모두가 동의했으니,\n당장 준비하러 가야 해.')
    stage.unit(127).setAction(0)
    stage.say('&132\n복종해.')
    stage.unit(132).setAction(0)
    stage.delay(3)
    stage.unit(127).setAction(0, 1)
    stage.delay(3)
    stage.unit(127).setAction(3)
    stage.say('&127\n하하하, 짜릿해!\n여러분, 오늘은 맛있는 술 한잔 하자!')
    stage.unit(127).setAction(0)
    stage.say('&119\n……。')
    stage.delay(3)
    stage.unit(101).setAction(0, 1)
    stage.say('&101\n조조.')
    stage.delay(3)
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n무슨 일이야?')
    stage.unit(101).setAction(3)
    stage.say('&101\n나는 낙양에 군대가 없다,\n동탁를 죽이는 것은 아마도 쉽지 않을 것이다.')
    stage.unit(101).setAction(0)
    stage.say('&101\n나는 허베이로 돌아가 말을 모집하고 살 계획이다,\n낙양성 외곽에서 동탁을 공격했다.')
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n……네가 낙양을 떠난다고?\n&101\n그래, 너는 무슨 계획이 있느냐, 조조?')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n다시 동탁 사람을 관찰하고 싶어.\n&101\n관찰하라고?\n&0\n네.\n&101\n조조... 계획이 뭐야?\n&0\n아직도 이 사람이 동탁 모르겠어요,\n그래서 그가 침착한지 보고 싶었어요.\n&101\n동탁 태도는?')
    stage.unit(101).setAction(2, 1)
    stage.say('&101\n저 녀석은 사나운 늑대일 뿐이야!')
    stage.unit(0).setAction(0, 3)
    stage.say('크게 소리 지르지 마세요!')
    stage.unit(0).setAction(0, 2)
    stage.say('사나운 늑대는 들을 거야, 하하하.')
    stage.unit(101).setAction(0)
    stage.say('&119\n(…… 저기 있는 두 사람은 원소 원벤추였다\n조조조맹덕 ....... )')
    stage.clsUnit()
    stage.effectSound(205, 255)
    return False


def scene2():
    stage.bgSound(16)
    stage.loadBg(0, 16)
    stage.draw()
    stage.info('그는 황제의 칙령을 장관들에게 전달하는 동탁가 되어 권력을 독점했다\n폭력이 만연하고 있어. 수도 낙양은 사람들로 둘러싸여 있어.\n슬픔과 한숨.')
    stage.bgSound(-1)
    stage.loadBg(2, 39)
    stage.showUnit(153, 68, 57, 0, 1)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('뤄양 @ 왕윈의 거주지')
    stage.say('&153\n동탁 잔혹함은 날로 커졌고, 조정 관리들은 그를 두려워했다,\n군주와 신하의 생명은 모두 동탁의 손에 달려 있다.\n&153\n우리 집안은 한나라의 인용을 대대로 받아왔고,\n이제 저는 개인적으로 미사들을 총괄하는 중요한 직책을 맡고 있습니다,\n하지만 그는 배신자 장동탁 앞에서 무력했다!')
    stage.unit(153).setAction(9)
    stage.say('&153\n한숨.......\n&196\n왕 경은 집에 계신가요?')
    stage.unit(153).setAction(1)
    stage.say('&153\n존재한다.')
    stage.showUnit(196, 55, 29, 2)
    stage.say('&196\n왕 경, 폐를 드려 죄송합니다.')
    stage.unit(153).setAction(0)
    stage.say('&153\n괜찮아.')
    stage.unit(196).move(55, 49, 2)
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(153).move(55, 57, 0)
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n대사령관님,\n무슨 일 생기면 그냥 불러, 왕윤이 직접 올 거야.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(6)
    stage.say('&196\n흠...... 어떻게 그렇게 위대한 존재감으로 왕 경을 폐 끼치겠습니까?')
    stage.unit(196).setAction(0)
    stage.say('&196\n사실, 오늘 나오는 것은,\n왕 경에게 누군가를 소개하고 싶었다.')
    stage.unit(153).setAction(6)
    stage.say('&153\n누구세요?')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(0, 0)
    stage.say('&196\n조조, 들어와.')
    stage.showUnit(0, 55, 29, 2)
    stage.say('&0\n안녕하세요.')
    stage.unitsMove([
        [
            stage.unit(196),
            61,
            49,
            2],
        [
            stage.unit(0),
            55,
            49,
            2]])
    stage.delay(5)
    stage.unit(196).setAction(6)
    stage.say('&196\n이분은 조조, 예식 맹덕입니다.\n그는 드문 재능이다.')
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n그는 하위 계급의 조조로, 맹덕이라는 칭호를 받았다.\n왕윤 공이 점점 더 조율되어 주시길 요청합니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n아, 장군님, 너무 예의 바르시네요.')
    stage.unit(153).setAction(0)
    stage.say('&153\n형식적인 절차에 얽매이지 말아 주세요.')
    stage.unit(0).setAction(6)
    stage.say('&0\n감사합니다, 왕 경.')
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.unitsMove([
        [
            stage.unit(153),
            68,
            57,
            0],
        [
            stage.unit(196),
            74,
            49,
            2],
        [
            stage.unit(0),
            68,
            49,
            2]])
    stage.unit(196).setAction(1)
    stage.unit(0).setAction(1)
    stage.unit(153).setAction(1)
    stage.delay(5)
    stage.info('잠시 후에, .......', 3)
    stage.delay(5)
    stage.say('&153\n조조, 현재 법원에 대한 의견은 어떠신가요?\n&0\n아마도 이제는 법원이라고 부르기 어려울 것이다,\n완전히 동탁 독점적인 권력이었어요,\n그가 본 것은 한숨뿐이었다.\n&153\n장군도 같은 생각이었던 거야......\n저도 같은 생각이에요.\n하지만 이런 상황이 계속된다면 세상은 혼란에 빠질 것이다......')
    stage.unit(0).setAction(0)
    stage.say('&0\n나는 동탁를 섬기는 척했어,\n사실, 그들은 그를 관찰하고 있었다.')
    stage.unit(153).setAction(0)
    stage.say('&153\n아, 그렇구나.......')
    stage.unit(0).setAction(6)
    stage.say('&0\n비록 동탁 권력을 독점하지만,\n하지만 그는 용기나 전략을 가진 사람도 아니었다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n낙양 시에서는 그를 제거할 수 없습니다,\n게다가 여러 영주들 중 어느 누구도 실질적인 힘을 가진 것이 아니었다\n벌을 줘.')
    stage.unit(153).setAction(1, 0)
    stage.say('&153\n흠.......\n&153\n나도 그렇게 생각해,\n몇몇 영주의 권력만으로는 부족했다......')
    stage.unit(0).setAction(3)
    stage.say('&0\n네, 일부 봉건 영주들은 실제로 약했습니다.\n&0\n....... 정도')
    stage.unit(0).setAction(0)
    stage.delay(10)
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(3)
    stage.say('&153\n아, 그렇군요.\n일부 봉건 영주들은 동탁보다 약했지만,\n하지만 많은 사람들의 힘을 모을 수 있다면......')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n네,\n영웅들을 하나로 묶을 수만 있다면!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(0, 3)
    stage.say('&196\n동맹?!')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n네, 하지만 영웅들 사이에 동맹을 맺는 것은 ...... 쉽지 않습니다.')
    stage.unit(0).setAction(0, 2)
    stage.unit(196).setAction(0, 2)
    stage.delay(5)
    stage.unit(153).setAction(0, 2)
    stage.say('&153\n…… 이건 좀 부적절할 수도 있어요,\n그러나 천자의 이름으로 선포를 할 수 있다면,\n영웅들은 분명히 앞으로 나서야 한다.')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n조 장군, 이 동맹을 하나로 모으는 것은 당신에게 달려 있습니다.')
    stage.unit(0).setAction(3)
    stage.say('&0\n나?')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n네, 장군님을 보자마자,\n그냥 위대한 일을 이룰 수 있다고 믿어,\n어쨌든, 장군께서 이 문제에 동의하시길 바랍니다.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n하지만... 동맹을 맺기 위해서,\n그들은 일정 수준의 힘을 가졌어야 합니다.\n&0\n병력도 없고 병사를 모집할 재정 자원도 없습니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n집에 소중한 검이 있는데, 일곱성검이야.\n&153\n이 임무를 받아들일 의향이 있다면,\n이 소중한 검을 드리겠다,\n판매하면 자금이 생깁니다.')
    stage.say('&153\n어떻게? 받아들일 의향이 있나요?')
    stage.unit(153).setAction(0)
    stage.effectSound(202, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('이 역할을 맡을 의향이 있습니다\n이 책임을 지지 못해 죄송합니다', -1)
    if sel == 1:
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.say('...알았다.')
        stage.unit(0).setAction(6)
        stage.say('&0\n저는 이 중요한 책임을 맡았습니다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n아, 동의했어?')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n사소한 사람도 분명히 최선을 다할 것이다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n감사합니다, 감사합니다, 조 장군님.')
        stage.unit(153).setAction(0)
        stage.say('&153\n그렇기에 시간을 낭비할 여유가 없었다.\n이 칠성검은 네게 맡길게.')
    elif sel == 2:
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n너무 무거운 책임이라 감당할 수 없을 것 같아요.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n왜 그렇게 말하죠? 장군님이 너무 날카롭게 분석하셨어요,\n이 문제는 장군님만의 문제입니다.')
        stage.unit(153).setAction(0)
        stage.delay(5)
        stage.unit(196).setAction(0, 3)
        stage.say('&196\n조조, 왕 경이 그렇게 말했으니,\n거절하지 마세요.')
        stage.delay(5)
        stage.say('...알았다.')
        stage.unit(0).setAction(6)
        stage.say('&0\n그럼 이 중요한 책임을 맡겠습니다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n아, 동의했구나!')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n사소한 사람도 분명히 최선을 다할 것이다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n감사합니다, 감사합니다, 조 경.')
        stage.unit(153).setAction(0)
        stage.say('&153\n그렇기에 시간을 낭비할 여유가 없었다.\n이 칠성검은 네게 맡길게.')
    stage.say('&153\n빨리 나와, 초선, 초선!')
    stage.showUnit(17, 55, 29, 2)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n아빠, 온다.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.unit(196).setAction(0, 0)
    stage.delay(3)
    stage.unit(153).setAction(3)
    stage.say('&153\n초선, 빨리 칠성검을 가져와라.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(6)
    stage.say('&17\n네, 아빠.')
    stage.unit(17).setAction(0)
    stage.delay(5)
    stage.unit(17).hide()
    stage.delay(5)
    stage.unit(0).setAction(0, 2)
    stage.unit(196).setAction(0, 2)
    stage.delay(3)
    stage.unit(196).setAction(6)
    stage.say('&196\n왕 경, 방금 그 젊은 아가씨는 누구였나요?')
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n아, 내 입양딸 이름은 초선야.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(6)
    stage.say('&196\n정말? 정말 놀라워.\n왕 경이 이렇게 아름다운 딸을 가질 줄은 몰랐다.')
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(3)
    stage.say('&153\n전혀 아니에요, 아직 아이일 뿐이에요.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(6)
    stage.say('&196\n아, 너무 아름다워.')
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.showUnit(17, 55, 29, 2)
    stage.say('&17\n아버지, 기다려 주셔서 감사합니다.')
    stage.unit(17).move(55, 57, 1)
    stage.delay(3)
    stage.unit(153).setAction(0, 3)
    stage.say('&153\n오, 착한 아이야.')
    stage.unit(17).move(64, 57, 1)
    stage.delay(3)
    stage.unit(17).move(55, 57, 1)
    stage.say('&153\n초선, 소개할게.')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n이분은 대사령관이십니다,\n이 젊은이는 조 장군이었다.')
    stage.unit(17).setAction(6)
    stage.say('&17\n두 분 인사초선 드릴게요.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(196).setAction(0, 3)
    stage.delay(3)
    stage.unit(196).setAction(6)
    stage.say('&196\n아, 안녕하세요.')
    stage.unit(196).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n안녕하세요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(153).setAction(6)
    stage.say('&153\n조 장군님, 제 딸은 어떻습니까?')
    stage.unit(153).setAction(0)
    stage.delay(5)
    model.setFace(1)
    stage.unit(0).setAction(3)
    stage.say('아?')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.effectSound(202, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('정말 인상적이에요\n특별한 건 없어요', -1)
    if sel == 1:
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.delay(3)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('아, 정말 아름답다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(17).setAction(3)
        stage.say('&17\n"천만에요, 칭찬해 주셔서 감사합니다, 선생님."')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n하하하, 조 장군이 정말 당신을 존경하는 것 같군요, 초선.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(3)
        model.setFace(1)
        stage.say('아, 왕윤 어른, 저는……')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(17).setAction(3)
        stage.say('&17\n이것은 저의 영광입니다, 조 경.')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n아, 그거 .......')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(17),
                55,
                63,
                0],
            [
                stage.unit(153),
                55,
                57,
                0]])
        stage.unit(153).move(55, 49, 1)
        stage.unit(153).setAction(0)
        stage.unit(0).setAction(0, 3)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n그럼, 조 장군, 이 검은 당신 것입니다.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(153).move(64, 49, 1)
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.delay(3)
        stage.unit(153).move(55, 49, 1)
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n모든 것은 장군에 달려 있습니다.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('나리 분부대로 하십시오. 소인이 결코 나리의 큰 기대를 저버리지 않겠습니다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(153),
                55,
                55,
                0],
            [
                stage.unit(0),
                55,
                49,
                2]])
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).setAction(6)
        stage.say('&0\n그럼 여기서 물러나겠습니다.')
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).move(55, 29, 0)
        stage.unit(0).hide()
        stage.delay(5)
        stage.unit(153).setAction(0, 1)
        stage.say('&153\n정말 뛰어난 청년이네요,\n앞으로 분명히 성공과 명성을 얻을 것입니다.')
        stage.unit(196).setAction(0, 2)
        stage.say('&196\n저도 그렇게 생각해요.')
        stage.unit(17).setAction(0, 1)
        stage.say('&17\n(조조 ....... )')
        vars[302] = 1
    elif sel == 2:
        stage.addAmbition(-5)
        stage.delay(3)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n왕 경, 아직 검을 주지 않으셨잖아요.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n아, 미안.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(0, 3)
        stage.say('&153\n초선, 먼저 가도 좋다.')
        stage.unit(17).setAction(6)
        stage.say('&17\n네.')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(17).move(55, 29, 0)
        stage.unit(17).hide()
        stage.delay(5)
        stage.unit(153).move(55, 57, 3)
        stage.unit(153).setAction(0)
        stage.unit(153).move(55, 49, 1)
        stage.unit(153).setAction(0)
        stage.unit(0).setAction(0, 3)
        stage.unit(196).setAction(0, 3)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n그럼, 조 장군, 이 검은 당신 것입니다.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(153).move(64, 49, 1)
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.delay(3)
        stage.unit(153).move(55, 49, 1)
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(6)
        stage.say('&153\n모든 것은 장군에 달려 있습니다.')
        stage.unit(153).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('나리 분부대로 하십시오. 소인이 결코 나리의 큰 기대를 저버리지 않겠습니다.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unitsMove([
            [
                stage.unit(153),
                55,
                55,
                0],
            [
                stage.unit(0),
                55,
                49,
                2]])
        stage.unit(153).setAction(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(6)
        stage.say('&0\n그럼, 저는 이만 가보겠습니다.')
        stage.unit(0).setAction(0)
        stage.delay(5)
        stage.unit(0).move(55, 29, 0)
        stage.unit(0).hide()
        stage.delay(5)
        stage.unit(153).setAction(0, 1)
        stage.say('&153\n정말 뛰어난 청년이네요,\n앞으로 분명히 성공과 명성을 얻을 것입니다.')
        stage.unit(196).setAction(0, 2)
        stage.say('&196\n저도 그렇게 생각해요.')
        vars[303] = 1
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 282, 95)
    stage.bottomTxt('조조 왕윤의 의뢰를 수락했다.', False, False, False)
    stage.delay(5)
    stage.head(0).move(378, 118)
    stage.delay(5)
    stage.bottomTxt('낙양을 떠나 고향 천류로 돌아갔다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('또한 여러 지역에 반동탁 동맹을 결성하라는 선언문을 보냈다.', True, True, True)
    stage.bottomTxt('선언에 응답한 이들은 다음과 같습니다:', False, True, False)
    stage.delay(5)
    stage.showHead(101, 408, 8)
    stage.delay(5)
    stage.bottomTxt('보하이 총독 원소,', True, False, False)
    stage.delay(5)
    stage.showHead(161, 478, 0)
    stage.delay(5)
    stage.bottomTxt('공손찬 베이핑 도지님께,', True, False, False)
    stage.delay(5)
    stage.showHead(145, 476, 126)
    stage.delay(5)
    stage.bottomTxt('도겸 쉬저우 감찰관님,', True, False, False)
    stage.delay(5)
    stage.showHead(99, 347, 229)
    stage.delay(5)
    stage.bottomTxt('창사 주지사, 손견,', True, True, False)
    stage.delay(5)
    stage.showHead(136, 258, 200)
    stage.delay(5)
    stage.bottomTxt('난양 도지사, 원술 그리고 다른 이들,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('모두 세계의 뛰어난 영웅들입니다.', True, False, True)
    stage.loadBg(0, 16)
    stage.draw()
    stage.info('반면, 왕윤의 칠성검을 팔조조\n그는 매각 자금으로 자신의 군대를 건설했다.')
    stage.bgSound(18)
    stage.loadBg(2, 21)
    stage.showUnit(0, 49, 67)
    stage.draw()
    stage.setStageName('천류에 있는 @조조군 본거지')
    stage.showUnits([
        [
            1,
            49,
            22,
            2],
        [
            6,
            49,
            16,
            2]])
    stage.say('&1\n맹덕!')
    stage.unitsMove([
        [
            stage.unit(1),
            49,
            52,
            2],
        [
            stage.unit(6),
            49,
            46,
            2]])
    stage.delay(1)
    stage.unitsMove([
        [
            stage.unit(1),
            45,
            52,
            2],
        [
            stage.unit(6),
            53,
            52,
            2]])
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n맹덕, 며칠 만에 봤네!')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n하후돈. 하후연, 드디어 왔구나.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n군대를 모으면 우리가 안 갈 수 있겠어?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(6).setAction(6)
    stage.say('&6\n그런데 갑자기 돈을 주고 병사를 모집하겠다고 하더라고,\n우리도 놀랐어.')
    stage.unit(6).setAction(0)
    stage.say('&0\n네 병사들은 어때?')
    stage.unit(1).setAction(17)
    stage.say('&1\n밖에 줄 서고 있어.')
    stage.unit(1).setAction(3)
    stage.say('&1\n이 모든 것은 우리의 엄격한 훈련의 결과입니다,\n그럼 우리가 뭘 할 수 있는지 보자.')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n자, 두 형제가 형제처럼 가까우면,\n우리가 함께 싸운다면,\n마음이 훨씬 편안해졌어요.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n그런데, 조인과 조홍 사이에 무슨 일이 있었나요?')
    stage.unit(6).setAction(0, 3)
    stage.say('&6\n아, 네......')
    stage.say('아직도 소식은 없네요……….')
    stage.showUnit(181, 49, 16, 2)
    stage.say('&181\n보고해.')
    stage.unit(1).setAction(0, 0)
    stage.unit(6).setAction(0, 0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 두 명의 건장한 남자가 아군에 합류하러 왔다.')
    stage.unit(1).setAction(0, 1)
    stage.say('&1\n조인과 조홍인가요?')
    stage.say('&0\n빨리, 들여보내!')
    stage.say('&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(1),
            35,
            52,
            1],
        [
            stage.unit(6),
            63,
            52,
            3]])
    stage.showUnits([
        [
            10,
            49,
            16,
            2],
        [
            11,
            49,
            16,
            2]])
    stage.unit(10).move(49, 22, 2)
    stage.unitsMove([
        [
            stage.unit(10),
            45,
            52,
            2],
        [
            stage.unit(11),
            53,
            52,
            2]])
    stage.delay(3)
    stage.say('&0\n너희 둘 같이 갈 거아군?')
    stage.unit(10).setAction(11)
    stage.say('&10\n맞아요, 저는 악진, 자식 원첸입니다.\n&10\n세상의 위대한 생각들, 하소한 자들은 깊이 감동한다,\n그래서 그들이 피신하러 온 거야.\n&10\n부디 그를 꼭 데려가세요.')
    stage.unit(11).setAction(11)
    stage.say('&11\n나는 이전 스타일의 만청이다.\n&11\n악진처럼 저도 어른들에게 피신하러 왔습니다.\n&11\n겸손히 주님께 제 요청을 들어주시길 간청합니다.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('이제 막 병거를 일으켰는데, 여러분처럼 뛰어난 무장들이 아군에 투항하다니 정말 좋군요! 모두 환영합니다!')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&10\n그게... 선생님!')
    stage.say('&11\n감사합니다, 선생님!')
    stage.unit(10).setAction(0)
    stage.unit(11).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(10),
            45,
            46,
            0],
        [
            stage.unit(11),
            53,
            46,
            0]])
    stage.showUnit(5, 49, 16, 2)
    stage.unit(5).move(49, 22, 2)
    stage.showUnit(12, 49, 16, 2)
    stage.unitsMove([
        [
            stage.unit(10),
            35,
            46,
            1],
        [
            stage.unit(11),
            63,
            46,
            3],
        [
            stage.unit(5),
            49,
            52,
            2],
        [
            stage.unit(12),
            49,
            46,
            2]])
    stage.unitsMove([
        [
            stage.unit(5),
            45,
            52,
            2],
        [
            stage.unit(12),
            53,
            52,
            2]])
    stage.delay(3)
    stage.unit(5).setAction(9)
    stage.unit(12).setAction(9)
    stage.say('&5\n허프, 미안, 늦었어.')
    stage.say('&12\n헤, 조조님!\n우리도 여러분의 대열에 합류하게 해 주세요.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n쯔샤오, 쯔리안, 왔구나! 왜 늦었어?')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.say('&5\n휙, 병력 배치가 한동안 지연되었다.')
    stage.say('&12\n헤헤, 난 이미 준비했어,\n모두 조인이 기회를 놓쳤기 때문이었다.')
    stage.unit(5).setAction(0, 1)
    stage.delay(3)
    stage.unit(5).setAction(2, 1)
    stage.say('&5\n뭐야, 다 내 잘못이야!')
    stage.unit(12).setAction(0, 3)
    stage.delay(3)
    stage.unit(12).setAction(2, 3)
    stage.say('&12\n그렇지 않나요?')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하, 그만들 해!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(5).setAction(0, 2)
    stage.unit(12).setAction(0, 2)
    stage.say('걱정 마세요. 여러분도 빠지지 않을 겁니다. 잘 해내세요.')
    stage.unit(5).setAction(6, 2)
    stage.say('&5\n네, 명령에 따르세요!')
    stage.unit(12).setAction(6, 2)
    stage.say('&12\n지켜봐!')
    stage.unit(5).setAction(0, 2)
    stage.unit(12).setAction(0, 2)
    stage.unit(1).setAction(0, 2)
    stage.unit(6).setAction(0, 2)
    stage.unit(10).setAction(0, 2)
    stage.unit(11).setAction(0, 2)
    stage.delay(5)
    model.setFace(0)
    stage.unit(0).setAction(3)
    stage.say('&0\n시간이 얼마 남지 않았어.\n빨리 연합군과 합류하자!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n출발!')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 54)
    stage.showUnit(0, 54, 52, 1)
    stage.draw()
    stage.effectSound(202, 0)
    stage.setStageName('낙양 외곽 @ 연합군 본진지')
    stage.say('&0\n회의 시간까지 아직 꽤 시간이 남아 있었다.\n그때 누가 올지 궁금하네요.\n&99\n죄송합니다.')
    stage.unit(0).setAction(0, 2)
    stage.showUnit(99, 54, 94)
    stage.unit(99).move(54, 60, 0)
    stage.delay(3)
    stage.unit(99).setAction(6)
    stage.say('&99\n나는 손견, 원타이라는 칭이야. 선언문을 보고 나서,\n연합군에 합류하세요. …… 누구세요, 선생님?')
    stage.unit(99).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n아, 강둥의 쑨 장군이었군요.\n그는 아래의 조조였고, 맹덕 칭호를 받았다.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&99\n아, 그러니까 조조구나. 부디 잘 부탁해.')
    stage.unit(0).setAction(6)
    stage.say('나리가 정말 빨리 오셨네요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.say('&99\n전혀 아니에요, 그냥 어른들이 판단하길 바랐을 뿐이에요,\n우리 영웅들의 실력을 보자.')
    stage.unit(99).setAction(6)
    stage.say('&99\n선생님도 마음속으로 같은 계획을 세웠겠죠.')
    stage.unit(99).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n……그래. (……대단한 인물이야.)')
    stage.unit(0).setAction(0)
    stage.delay(5)
    stage.unit(99).move(42, 68, 1)
    stage.delay(10)
    stage.info('잠시 후에......,', 3)
    stage.showUnit(136, 54, 94)
    stage.unit(136).move(54, 60, 0)
    stage.delay(3)
    stage.unit(136).setAction(3)
    stage.say('&136\n난양의 원술입니다. 내 자리는 어디죠?')
    stage.unit(136).setAction(0)
    stage.say('(이 자식, 원소의 동생인가……)')
    stage.unit(0).setAction(6)
    stage.say('&0\n알고 보니 원술이니 왼쪽에 앉아 주세요.')
    stage.unit(0).setAction(0)
    stage.say('&136\n어떻게? 명예의 자리가 아니라고? 쳇!')
    stage.unit(136).move(42, 60, 1)
    stage.say('&99\n헤헤, .......')
    stage.unit(136).setAction(2, 2)
    stage.say('&136\n뭐가 그렇게 말도 안 되는 거야?')
    stage.unit(136).setAction(0, 2)
    stage.say('&99\n아니, 아무것도 아니야.')
    stage.unit(136).setAction(2, 2)
    stage.say('&136\n…… 누구세요?!\n&99\n…… 로어 Jiang손견 동부에 위치해 있습니다')
    stage.unit(136).setAction(0, 1)
    stage.delay(3)
    stage.unit(136).setAction(3, 1)
    stage.say('&136\n뭐라고? 알고 보니 시골 촌뜨기였어!')
    stage.unit(136).setAction(0)
    stage.say('&99\n…………。')
    stage.unit(0).setAction(0, 0)
    stage.say('(……이 녀석 정말 싫다.)')
    stage.showUnit(145, 54, 94)
    stage.say('&145\n영웅들, 죄송합니다!')
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(145).move(54, 60, 0)
    stage.delay(3)
    stage.unit(145).setAction(6)
    stage.say('&145\n서저우 하부 도겸에 위치해 있습니다.')
    stage.unit(145).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n그리고 하부 조맹덕,\n도군은 자비와 정의의 군주입니다,\n저는 오래전부터 들어왔습니다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(145).setAction(6)
    stage.say('&145\n아니, 내 늙은 몸이,\n부디 모두에게 문제를 일으키지 않길 바랍니다.')
    stage.unit(145).setAction(0)
    stage.delay(1)
    stage.unit(145).move(42, 76, 1)
    stage.showUnits([
        [
            161,
            54,
            94],
        [
            32,
            62,
            94]])
    stage.say('&161\n죄송합니다!')
    stage.unit(0).setAction(0, 2)
    stage.unitsMove([
        [
            stage.unit(161),
            54,
            60,
            0],
        [
            stage.unit(32),
            62,
            60,
            0]])
    stage.delay(3)
    stage.unit(161).setAction(6)
    stage.say('&161\n그는 샤오베이핑 공손찬에 있었으며, 보귀라는 별명을 가지고 있었다.')
    stage.unit(161).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('&0\n그는 아래의 조조였고, 맹덕 칭호를 받았다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n응? 이게 .......')
    stage.unit(161).setAction(6)
    stage.say('&161\n아, 이건 유비유현덕야,\n그는 황번의 난을 진압한 반군의 지도자였다.\n이번에는 그녀가 나와 함께 왔다.')
    stage.unit(161).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(6)
    stage.say('아, 유비…? 우리가 영천에서 황건군과 싸울 때 만난 적이 있어요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(6)
    stage.say('&32\n네, 오랜만이에요.\n이번에는 공손 장군과 함께 전투를 지원하러 왔습니다.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('&0\n알겠어요... 정말 멋지네요.')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&0\n그럼 공손 장군과 류 장군을 오른쪽에 앉게 해라.')
    stage.say('&161\n흠.')
    stage.say('&32\n네.')
    stage.unit(32).move(67, 68, 3)
    stage.unit(32).setAction(0)
    stage.unit(161).move(67, 60, 3)
    stage.unit(161).setAction(0)
    stage.showUnit(101, 54, 94)
    stage.say('&101\n죄송합니다.')
    stage.unitsMove([
        [
            stage.unit(0),
            42,
            52,
            1],
        [
            stage.unit(101),
            54,
            52,
            0]])
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n그는 하부 허베이 원소에 있었으며, 벤추라는 칭호를 받았다.')
    stage.unit(0).setAction(3)
    stage.say('본초, 나는 계속 당신을 기다리고 있었어요.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(0, 3)
    stage.say('&101\n조조, 난 너 때문에 온 게 아니야.')
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n내가 직접 왔어.')
    stage.say('&0\n네, 이해합니다.')
    stage.say('&0\n자, 벤추, 앉으세요. 이번에는 당신이 지휘권을 잡으세요.')
    stage.unit(101).setAction(0, 3)
    stage.say('&101\n내가 감독이라고? 너는 어때, 조조?')
    stage.say('&0\n나? 그냥 전략가가 돼.\n수고하셨습니다, 위안 경.\n&101\n위안 경? 조조, 나에 대해 그렇게 말하지 마.\n&0\n당신은 총사령관이고, 나는 단지 조언자일 뿐입니다,\n물론, 그는 공개석상에서 모두에게 그렇게 말한다.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.clsUnit()
    stage.bgSound(16)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(127, 263, 38)
    stage.bottomTxt('동탁 낙양에서는 잔인하고 무법적이었어,', False, False, False)
    stage.delay(5)
    stage.showHead(0, 371, 74)
    stage.showHead(101, 435, 74)
    stage.showHead(161, 499, 74)
    stage.showHead(136, 371, 154)
    stage.showHead(99, 435, 154)
    stage.showHead(145, 499, 154)
    stage.bottomTxt('따라서 동탁을 억누르는 것.', True, True, False)
    stage.bottomTxt('반동탁동맹은 낙양 근처에 모였다.', True, False, True)
    stage.bottomTxt('동탁 이 사실을 듣고 분노했다. 연합군을 격퇴하기 위해,', False, True, False)
    stage.delay(5)
    stage.showHead(134, 263, 118)
    stage.delay(5)
    stage.bottomTxt('따라서 강력한 장군들이 dispatched화웅', True, False, False)
    stage.delay(5)
    stage.head(134).move(307, 118)
    stage.delay(5)
    stage.bottomTxt('시수이 고개로 향합니다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            101,
            54,
            37,
            2],
        [
            0,
            50,
            45,
            2],
        [
            99,
            42,
            71,
            1],
        [
            136,
            42,
            63,
            1],
        [
            145,
            42,
            55,
            1],
        [
            161,
            67,
            55,
            3],
        [
            32,
            67,
            63,
            3]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.setStageName('낙양 외곽 @ 연합군 본진지')
    stage.showUnit(181, 54, 94)
    stage.unit(181).move(54, 86, 0)
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n보고하라! 동탁 군대가 이미 시수이 관에 도달했다,\n선봉 장군은 화웅.')
    stage.unit(101).setAction(3)
    stage.say('&101\n화웅?! 그가 무서운 장군이라고 들었어!')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n좋아, 아군도 시수이 고개로 출발한다.')
    stage.unit(101).setAction(0)
    stage.say('&101\n누가 선두에 서서 화웅를 이길 준비가 되어 있을까요?')
    stage.delay(5)
    stage.unit(99).setAction(6)
    stage.say('&99\n나, 선은 자격이 없으며 이 자리를 차지하고자 한다!')
    stage.unit(99).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(3)
    stage.say('&101\n아, 선 장군이군요,\n좋아, 너를 선봉으로 임명하겠다.')
    stage.unit(101).setAction(0)
    stage.delay(3)
    stage.unit(99).setAction(6)
    stage.say('&99\n바로 준비하러 갈게.')
    stage.unit(99).setAction(0)
    stage.delay(3)
    stage.unit(99).move(42, 95, 2)
    stage.unit(99).hide()
    stage.delay(5)
    stage.unit(101).setAction(17)
    stage.say('&101\n원술, 네가 식량 공급 책임자야. 어때?')
    stage.unit(101).setAction(0)
    stage.delay(5)
    stage.say('&136\n…… 네.')
    stage.delay(5)
    stage.unit(136).setAction(0, 2)
    stage.say('&136\n(흥, 둘 다 위안 가문 출신이야,\n당신은 총사령관이지만, 나는 그냥 곡물 담당관일 뿐이에요. )')
    stage.unit(136).setAction(2)
    stage.say('&136\n(젠장, 뻔뻔한 손견 진짜 원했어\n...... 주도권을 잡아야 할까요? )')
    stage.unit(136).setAction(0)
    stage.say('&136\n(어, 잠깐만! 손견 군대 전부 배급해,\n즉, ....... )')
    stage.unit(136).setAction(3)
    stage.say('&136\n(헤헤헤....... )')
    stage.unit(136).setAction(0)
    stage.delay(3)
    stage.unit(101).setAction(17)
    stage.say('&101\n좋아, 각자 캠프로 돌아가서 출발 준비해.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene6():
    model.unitJoin(1, 0, 0)
    model.unitJoin(6, 0, 0)
    model.unitJoin(10, 0, 0)
    model.unitJoin(11, 0, 0)
    model.unitJoin(5, 0, 0)
    model.unitJoin(12, 0, 0)
    if vars[1013]:
        gvars[0] = 1
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 6
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 10
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 11
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 5
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
        gvars[0] = 12
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    return False


def scene7():
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            66],
        [
            1,
            38,
            52,
            1],
        [
            5,
            38,
            46,
            1],
        [
            10,
            38,
            40,
            1],
        [
            6,
            60,
            52,
            3],
        [
            12,
            60,
            46,
            3],
        [
            11,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('시수이 고개에 있는 @조조군 본진')
    stage.say('&0\n마침내 그들은 동탁군과 교전하려 하고 있었다,\n아군 원타이 장군을 선봉으로 임명했다,\n나머지 병사들도 뒤따랐고, 모두가 최선을 다해야 했다.')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 7, [
        1])
    gvars[4076] = 0
    gvars[4057] = 1
    stage.setBattlePos([
        [
            19,
            9],
        [
            18,
            8],
        [
            18,
            11],
        [
            18,
            9],
        [
            18,
            10],
        [
            19,
            8],
        [
            19,
            11],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene8():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n그런데, 맹덕, 전에 황탁과 싸울 때 들었는데,\n당신은 "태평청령도"라는 책을 입수했습니다.\n&0\n네.\n&1\n장비 잊지 않는 게 좋을 것 같아.\n그리고 앞으로 전리품 장비도 잘 살펴봐.')
    if stage.unitClickTest(6):
        stage.say('&6\n아이템과 무기는 전투 중에 획득우군,\n전쟁이 끝난 후 모두 아군로 돌아왔습니다.\n&6\n그래서 항상 그를 이용하는 것 같은 기분이 들어요.')
    if stage.unitClickTest(5):
        stage.say('&5\n화웅 남자들은 언급할 가치가 없어.\n&0\n상대를 과소평가하는 습관은 좋지 않아요.')
    if stage.unitClickTest(12):
        stage.say('&12\n보병의 기동성과 공격력은 기병에 비해 열등합니다.\n하지만 방어력은 강력하다.')
    if stage.unitClickTest(10):
        stage.say('&10\n하후돈 장군과 조인장군은 기병 부대입니다,\n이동력과 공격력을 극대화할 수 있습니다.\n하지만 방어력은 다소 부족했다.......\n&1\n뭐라고 했어!!\n&10\n아, 아무것도 아니.......')
    if stage.unitClickTest(11):
        stage.say('&11\n하후연 장군이 이끄는 궁수와 기병,\n아군 유일하게 장거리 공격이 가능한 유닛입니다.\n주목하고 활용할 가치가 있는 단위라고 할 수 있습니다.\n&6\n아, 넌 날 잘 알잖아.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
