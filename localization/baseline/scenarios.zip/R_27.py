# Source Generated with Decompyle++
# File: R_27.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 265, 172)
    stage.showHead(32, 329, 172)
    stage.showHead(76, 565, 216)
    stage.bottomTxt('유비 군대', False, False, False)
    stage.delay(5)
    stage.head(32).move(364, 192)
    stage.delay(5)
    stage.bottomTxt('그리고 장샤로 도망쳤다.', True, False, False)
    stage.delay(8)
    stage.head(0).move(272, 213)
    stage.delay(5)
    stage.bottomTxt('조조군은 양쯔강을 따라 전략적으로 중요한 장링을 점령했다.', True, True, False)
    stage.delay(8)
    stage.showHead(35, 428, 192)
    stage.bottomTxt('제갈량 조조에 대응하기 위해 손권유비 동맹을 제안했다.', True, True, False)
    stage.delay(5)
    stage.head(35).move(501, 216)
    stage.delay(5)
    stage.bottomTxt('그는 혼자 동우로 가서 그 지역을 설득했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 49)
    stage.showUnits([
        [
            0,
            53,
            72],
        [
            24,
            40,
            56,
            1]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setEventName('레드 클리프스로 가는 길')
    stage.setStageName('장링: 임시 총리의 관저')
    stage.say('&0\n아군 유비 절망에 몰렸지만,\n하지만 이 사람은 꽤 오래 살아요.')
    stage.unit(24).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n유비 장샤로 도망친 것 같아.\n&0\n장샤 ......? 동우와 아주 가까워.\n좋아, 공다, 사절을 보내 손권를 만나게 해라.')
    stage.unit(0).setAction(0, 1)
    stage.say('그에게 내가 유비를 토벌하는 것을 돕는다면, 그의 영토 안전은 보장해 주겠다고 전해라.')
    stage.unit(24).setAction(0)
    stage.say('&24\n이게 최후통첩인가요......?')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n네. 그리고요.........\n그는 전 군대를 동우와 접한 우린으로 이동시키라고 명령했다.')
    stage.unit(24).setAction(6)
    stage.say('&24\n손권 동의하시나요?\n&0\n거부하면 공격해.')
    stage.say('&24\n네, 바로 처리하겠습니다.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 10)
    stage.showUnits([
        [
            76,
            71,
            55,
            3],
        [
            77,
            55,
            38,
            2],
        [
            88,
            49,
            38,
            2],
        [
            35,
            55,
            55,
            1],
        [
            192,
            55,
            71],
        [
            193,
            49,
            71],
        [
            194,
            43,
            71]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('동부 우손권 저택')
    stage.info('동우는 조조로부터 최종 최후통첩을 받았다,\n장관들은 전쟁을 옹호하는 파벌과 항복을 지지하는 파벌로 나뉘었다.\n하지만 제갈량의 설득 덕분에,\n점차 모두가 전쟁을 시작하기로 동의했다.')
    stage.say('&76\n공진과 장군들은 전투를 시작하고자 했다,\n하지만 조조를 이길 수 없을까 걱정돼요.')
    stage.unit(88).setAction(6)
    stage.say('&88\n저도 그렇게 생각해요.\n항복만이 나라를 지키는 유일한 방법이다.')
    stage.unit(88).setAction(0)
    stage.delay(3)
    stage.unit(77).setAction(3)
    stage.say('&77\n조조 우리 조국을 짓밟게 놔둘 생각이야?')
    stage.unit(77).setAction(4)
    stage.say('&77\n그때쯤이면 우리는 집이 없을 거예요.')
    stage.unit(77).setAction(17)
    stage.say('&77\n주군, 군주로서,\n우리는 반조조 반항자들과 단호히 싸워야 합니다.')
    stage.unit(77).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(6)
    stage.say('&35\n정확히 그렇습니다.\n항복은 조조에 의해서만 사라질 것입니다.\n&88\n닥쳐!\n정말 싸움만으로 이길 수 있을까?')
    stage.unit(35).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 0)
    stage.say('&35\n그래서 승리가 이루어질 수 있다.')
    stage.unit(76).setAction(3)
    stage.say('&76\n뭐라고!?\n왜 그렇게 확신하는 거죠?')
    stage.unit(76).setAction(0)
    stage.delay(3)
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n조조의 주력은 북부 병사들로 구성되어 있다.\n북부 병력과 말들은 확실히 해상 전쟁에 익숙하지 않다.\n&35\n더불어, 적응 문제로 인해,\n나는 분명히 막사에서 발병이 일어날 것이라고 믿는다.\n&35\n군사력이 아무리 강해도, 조조\n결국 실패는 불가피했다.')
    stage.say('&76\n그건 사실이야......\n좋아! 내 마음은 정해졌어!\n끝까지 조조 저항하세요.')
    stage.unit(77).setAction(3)
    stage.say('&77\n음, 주군 잘 보여!\n우리는 최선을 다할 것입니다!\n&76\n공진, 전군을 지휘하라 명령한다,\n모든 것은 당신에게 달려 있습니다.')
    stage.unit(77).setAction(11)
    stage.say('&77\n반드시 이길 거야,\n걱정 마세요, 주군.\n&76\n저도 제가 씨에게 공진을 도와달라고 부탁합니다.')
    stage.unit(35).setAction(6)
    stage.say('&35\n네.')
    stage.unit(76).setAction(17)
    stage.say('&76\n좋아! 병력을 보내라!')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 49)
    stage.showUnits([
        [
            0,
            53,
            72],
        [
            24,
            40,
            56,
            1]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('장링: 임시 총리의 관저')
    stage.say('&0\n손권 유비와 동맹을 맺고 있나요?')
    stage.unit(24).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n네.\n손권 주유를 총사령관으로 임명했다.\n현재 치비에 배치될 병력이 집결 중입니다.')
    stage.unit(0).setAction(17)
    stage.say('공달, 당장 장병들에게 명령을 내려 전군을 적벽 건너편 오림으로 이동시켜라. 내가 손권을 무너뜨리겠다.')
    stage.say('&24\n복종해.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 264, 192)
    stage.showHead(32, 368, 191)
    stage.showHead(76, 559, 210)
    stage.bottomTxt('손권 조의 군대와 전투를 벌이기로 결심했다.', False, False, False)
    stage.delay(5)
    stage.head(32).move(368, 158)
    stage.head(76).move(339, 238)
    stage.delay(5)
    stage.bottomTxt('그리고 레드 클리프에서 함선을 집결시켰다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('조의 군대도 행동에 나섰다,', True, True, False)
    stage.delay(5)
    stage.head(0).move(275, 238)
    stage.delay(5)
    stage.bottomTxt('우린이 등장한다, 붉은 절벽 너머.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('두 군대가 긴장된 대치 상태에 있을 때,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('한 명이 조조의 주 캠프에 도착했다.', True, False, False)
    stage.delay(5)
    stage.showHead(90, 243, 158)
    stage.delay(5)
    stage.bottomTxt('이 사람은 방통였다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            90,
            54,
            64,
            2]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setStageName('울린조조 주 진영')
    stage.unit(0).setAction(3)
    stage.say('&0\n팡시위안 씨는 세계적으로 유명한 덕망 있는 학자였다,\n라인업을 보고 아군 생각이 어떠신가요?')
    stage.unit(0).setAction(0)
    stage.say('&90\n오! 정말 놀랍네요!\n육상 및 수상 야영지의 배치는 전적으로 군사 전략에 따라 이루어졌다.')
    model.setFace(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n정말?\n팡시위안 씨의 따뜻한 말씀에 감사드립니다,\n조는 진심으로 기뻐했다.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(90).setAction(6)
    stage.say('&90\n하지만... 구성이 완벽하지만,\n병사들의 얼굴은 끔찍했다.')
    stage.unit(90).setAction(0)
    model.setFace(0)
    stage.say('&0\n응? 그것도 보여!\n진정으로 팡시위안 씨에게 어울리는 사람이야.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n최근 군인들이 자주 병에 걸렸고,\n저도 이 점이 걱정돼요.\n&90\n그래서 바로 그런 상황입니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n선생님, 좋은 계획이 있으신가요?')
    stage.unit(90).setAction(6)
    stage.say('&90\n네, 있습니다.\n군인들이 병에 걸리는 주요 원인은 다음과 같습니다.\n그들은 배 생활에 익숙하지 않았기 때문이다.')
    stage.unit(90).setAction(0)
    stage.say('&90\n철사슬로 연결되어 있다면,\n문제를 해결하려면 모든 함대를 고치세요.\n&90\n이렇게 하면 함선의 흔들림을 줄일 수 있습니다.\n행진은 평평한 땅 위를 걷는 것처럼 해야 한다,\n병사들은 더 이상 아프지 않을 것이다.\n&0\n알겠어...... 그건 사실이야!\n알았어! 바로 누군가 처리하게 할게.\n지도해 주셔서 감사합니다, 선생님.')
    stage.unit(90).setAction(6)
    stage.say('&90\n그럼 여기서 물러나겠습니다.\n&0\n정말?\n신사께서 원하시면,\n앞으로 군대에 남아 조를 지도해도 될까요?\n&90\n그리고 총리의 친절에 감사를 표했다.\n시위안은 항상 떠다니는 구름이나 야생 학 같았다,\n방황하는 삶이 사실 적절합니다.\n&0\n정말?\n정말 안타깝네요.\n&90\n그럼 여기서 물러나겠습니다.')
    stage.unit(90).setAction(0)
    stage.delay(3)
    stage.unit(90).move(54, 22, 0)
    stage.unit(90).hide()
    stage.say('&0\n원양, 다 들었지?\n즉시 함선을 연결하는 철제 사슬을 건설하러 가세요.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\nBut맹덕......\n전함을 연결하는 사슬은 정말 흔들리지 않아,\n또한 병사들이 병에 걸리는 것을 예방하는 데도 도움이 됩니다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n하지만 이 때문에 행동이 지연될 것입니다,\n만약 오나라 군대가 불로 공격한다면,\n그때쯤이면 빠져나갈 길은 없을 것이다.')
    stage.unit(1).setAction(0)
    stage.say('&0\n원양, 걱정할 필요 없어.\n지금, 이맘때쯤에는 북서풍만 불고,\n즉, 모든 타격은 동조군을 향해 집중되었다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n만약 그들이 불로 공격한다면, 그건 스스로를 태우는 거 아닌가요?\n&1\n아! 알겠어.\n알았어, 바로 체인 만들러 갈게.')
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            7,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            23,
            64,
            58,
            3],
        [
            24,
            64,
            52,
            3]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.info('며칠 후, .......', 3)
    stage.setStageName('울린조조 주 진영')
    stage.showUnit(181, 54, 22, 2)
    stage.say('&181\n보고해.')
    stage.unit(181).setAction(11)
    stage.say('&181\n주군.\n오나라 장군 황개라고 주장하는 사자가 도착했다.\n&0\n황가이가 사람을 보냈다고?\n황가이는 동오의 노련한 장군 아니었나?\n좋아, 데려와.\n&181\n네.')
    stage.unit(181).setAction(0)
    stage.delay(3)
    stage.unit(181).hide()
    stage.delay(5)
    stage.showUnit(192, 54, 22, 2)
    stage.say('&192\n안녕하세요.')
    stage.unit(192).move(54, 64, 2)
    stage.say('&0\n저는 한나라 총리조조입니다.\n당신은 황가이의 사신이라고 주장하네요,\n도대체 무슨 일이 벌어지고 있는 거죠?')
    stage.unit(192).setAction(6)
    stage.say('&192\n나는 주최자 황가이의 명령에 복종한다,\n그리고 복종을 요청하러 왔다.\n&0\n황가이가 나에게 복종하고 싶어 한다고?\n황가이는 동오의 충성스럽고 공로가 높은 관리였다.\n왜 나에게 항복하지?\n&192\n주최자 황개이는 실제로 동오의 공로운 관리였다,\n하지만 작은 문제 때문에,\n며칠 전, 그는 군중 주유 지휘관에게 공개적으로 꾸중을 들었다.\n&192\n그 결과 그는 피부가 찢기고 살이 찢겨 나가며 살과 피가 찢겨 나갈 때까지 맞았다,\n오늘날까지도 그는 침대에 누워 일어나지 않는다.\n&192\n그러므로 이 수치를 씻기 위해,\n그는 총리의 기발에 합류하고 싶어 했다.\n&0\n음, 이 문제에 대해 대략 이해하고 있습니다.\n이제 장관들과 논의해야 합니다,\n일단 한 발 물러서서 제 답변을 기다리세요.\n&192\n네.')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(192).move(54, 22, 0)
    stage.unit(192).hide()
    stage.say('&0\n문약, 전령이 방금 한 말에 대해,\n여러분 생각은 어떠신가요?')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n정말 믿기 힘들다......\n황개이 같은 장군도 반란을 일으킬까?\n이건 정말 말이 안 돼......')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(0, 2)
    stage.say('&24\n하지만 만약 맞으면,\n어쩌면 정말 그런 일이 있었을지도 모른다.\n&0\n흠.')
    stage.effectSound(208, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('사절을 믿으세요\n믿을 수가 없어', 0)
    if sel == 1:
        stage.addAmbition(-2)
        stage.bgSound(-1)
        stage.effectSound(208, 0)
        stage.delay(3)
        stage.say('&0\n좋아! 일단 그를 믿자.\n문약, 전령을 불러라.\n&20\n네.')
        stage.unit(20).move(54, 64, 3)
        stage.delay(1)
        stage.unit(20).move(54, 22, 0)
        stage.unit(20).hide()
        stage.unit(23).setAction(0, 2)
        stage.say('&23\n이게 정말 가능한가요?\n누군가를 이렇게 쉽게 믿다니,\n그것은 불가피한 .........\n&0\n걱정할 필요 없어.\n황가이가 항복하는 척했더라도,\n큰 피해는 없을 거예요.\n&0\n하지만 항복이 진심이라면,\n장군들에게 큰 도움이 될 아군.')
        stage.delay(5)
        stage.showUnit(20, 54, 22, 2)
        stage.unit(20).move(54, 64, 2)
        stage.unit(20).setAction(6)
        stage.unit(23).setAction(0, 3)
        stage.unit(24).setAction(0, 3)
        stage.delay(3)
        stage.say('&20\n주군, 전령이 도착했다.\n&0\n음, 수고하셨습니다.')
        stage.unit(20).move(64, 64, 3)
        stage.delay(5)
    elif sel == 2:
        stage.addAmbition(2)
        stage.bgSound(-1)
        stage.effectSound(208, 0)
        stage.delay(3)
        stage.say('&0\n전령이 전한 말은,\n아직 몇 가지 문제가 남아 있습니다.\n그를 그렇게 쉽게 믿을 수는 없어.')
        stage.delay(5)
        stage.showUnit(181, 54, 22, 2)
        stage.unit(181).move(54, 64, 2)
        stage.unit(20).setAction(0, 3)
        stage.unit(24).setAction(0, 3)
        stage.delay(3)
        stage.unit(181).setAction(11)
        stage.say('&181\n주군, 동우에 침투한 스파이가 보고하러 왔어!\n&0\n아, 어디 보자.\n&181\n네! 한번 보세요.')
        stage.unit(181).setAction(0)
        stage.delay(3)
        stage.unit(181).move(54, 76, 2)
        stage.delay(3)
        stage.unit(0).setAction(5)
        stage.delay(3)
        stage.unit(181).move(54, 64, 2)
        stage.delay(3)
        stage.unit(181).setAction(11)
        stage.say('&0\n아, 방금 사절의 말이 사실이었나 보군요.')
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n그럼 주유 황가이를 제대로 벌주었나?')
        stage.unit(20).setAction(0)
        stage.say('&0\n흠.\n보고서는 다른 장군들도 주유를 불만으로 여겼다고 언급했다.\n&0\n알겠습니다! 황가이의 사절을 소환하라.\n&181\n네.')
        stage.unit(181).setAction(0)
        stage.delay(3)
        stage.unit(181).move(54, 22, 0)
        stage.unit(181).hide()
        stage.delay(5)
    stage.showUnit(192, 54, 22, 2)
    stage.say('&192\n무례하게 굴어서 죄송합니다.')
    stage.unit(192).move(54, 64, 2)
    stage.unit(20).setAction(0, 3)
    stage.say('&0\n아, 기다리게 해서 미안해.\n방금 직원들과 상의했어요,\n말씀하신 내용이 맞는 것 같아요.')
    stage.unit(192).setAction(6)
    stage.say('&192\n그래서 우리가 항복하는 걸 허락하는 거야?\n&0\n흠, 황 장군에게 항복을 환영한다고 전해라.\n&192\n총리님께 깊이 감사드립니다.\n&0\n그래서, 황 장군님......\n언제 항복할 계획이야?\n&192\n내 주인이 말했어,\n총리가 동의한다면,\n그리고 3일 후 그는 항복할 것이다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n...... 3일 후에?\n&192\n우리 가족주군 청룡 깃발을 달고 달려,\n군수품을 실은 전함들이 항복하러 왔다.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n이해했어.\n그가 올 때까지 기다릴게요.\n&192\n그럼 즉시 내 주인 황가이에게 보고하겠다,\n이게 내 작별 인사야.\n&0\n음, 수고하셨어요.')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(192).move(54, 22, 0)
    stage.unit(192).hide()
    stage.effectSound(208, 255)
    stage.clsUnit()
    return False


def scene5():
    if vars[724]:
        stage.bgSound(0)
        stage.delay(3)
        stage.loadBg(2, 53)
        stage.showUnits([
            [
                0,
                54,
                80],
            [
                1,
                44,
                64,
                1],
            [
                15,
                44,
                58,
                1],
            [
                17,
                44,
                52,
                1],
            [
                20,
                64,
                64,
                3],
            [
                23,
                64,
                58,
                3],
            [
                21,
                64,
                52,
                3]])
        stage.draw()
        stage.info('황개이의 항복에 동의한 지 사흘 후,\n약속된 날이 마침내 찾아왔다.')
        stage.setStageName('울린조조 주 진영')
        stage.say('&0\n오늘은 황가이와 약속을 잡은 날이야,\n청룡기(Azure Dragon Banner)를 휘두른 배가 도착하자마자,\n출발하자!')
        stage.say('&22\n절대 나를 맞이하러 오면 안 돼!')
        stage.showUnit(22, 54, 22, 2)
        stage.unit(22).move(54, 64, 2)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('&0\n오, 펑샤오!\n병이 완치되었나요?')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(22).setAction(6)
        stage.say('&22\n네.\n그것이 주군을 걱정하게 한다,\n펑샤오는 이미 회복했다.\n&0\n정말? 정말 멋지다.')
        model.setFace(0)
        stage.say('하지만…… 왜 저를 만류하는 건가요? 동오를 공격하는 계획을 취소하라는 말인가요?')
        stage.unit(22).setAction(0)
        stage.say('&22\n안 돼! 동오를 공격하는 것은 분명히 필수적이었다.\n하지만 이렇게 군대를 그냥 보낼 수는 없어,\n그렇지 않으면 동우의 손에 바로 들어가게 될 것이다.')
        stage.unit(20).setAction(6)
        stage.say('&20\n곽가 씨, 왜 이런 일이 일어나는 거죠?')
        stage.unit(22).setAction(0, 1)
        stage.say('&22\n순욱 씨, 침착하게 생각하면,\n당신 같은 현명한 전략가,\n그런 속임수를 놓칠 리가 없다.')
        stage.unit(20).setAction(0)
        stage.say('&20\n응?')
        stage.unit(22).setAction(0, 2)
        stage.say('&22\n주군, 외부 여론이 변했습니다.\n&0\n바람이 바뀌...... 있나요?\n아군 불리하다는 말인가요?\n이 일에 대해 너무 걱정할 필요 없어.')
        stage.unit(22).setAction(6)
        stage.say('&22\n주군 주유를 과소평가해서는 안 됩니다,\n어쩌면 공명도 그와 함께 있을지도 몰랐다.')
        stage.unit(22).setAction(0)
        stage.say('&22\n주군, 이상하지 않아?\n황개이가 임명된 날, 바람 방향이 실제로 바뀌었다,\n정말 우연의 일치네요.\n&0\n황가이가 항복했다는 말인가요,\n동부 오 사절의 배신적인 음모인가?')
        stage.say('&22\n그럴 수밖에 없어.')
        stage.say('&0\n하지만 효를 섬긴다면,\n황개이는 주유 막대기로 처벌받았다,\n정말 사실입니다.')
        stage.delay(3)
        stage.unit(22).setAction(0, 1)
        stage.say('&22\n이건 주유 속임수임에 틀림없어.')
        stage.unit(22).setAction(0, 2)
        stage.say('&22\n그리고... 배들은 철사슬로 머리부터 꼬리까지 연결되어 있고,\n정확히 누가 그 아이디어를 냈나요?\n&0\n며칠 전, 방통가 방문했어,\n병에 걸리지 않도록 ......\n&22\n방통!?\n방통 여기 오세요?\n…… 그래서 그런 거야.')
        stage.unit(22).setAction(6)
        stage.say('&22\n주군, 방통 동오의 스파이이기도 한 것 같다.')
        stage.unit(22).setAction(0)
        stage.say('&22\n모든 선박과 선박을 고정하는 데 철제 사슬이 사용되었다.\n불 공격을 쓰는 것임에 틀림없어,\n모든 함선을 불태우아군.')
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n오! 방통 진짜 ......')
        stage.unit(0).setAction(0)
        model.setFace(0)
        stage.say('봉효, 나를 어찌해야 할까?')
        stage.unit(22).setAction(6)
        stage.say('&22\n몇 척의 배를 준비해서 그들을 불길로 유인하세요.\n&22\n남은 함정들은 화재 예방 조치를 취해야 합니다,\n이로 인해 동조군은 자신들의 계획이 성공했다고 믿게 되었다.')
        stage.unit(22).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n사슬은 제거된 거 아니야?')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(22).setAction(0, 3)
        stage.say('&22\n일부는 제거할 수 있습니다,\n하지만 모두 제거하면,\n이로 인해 동오군의 주목을 받게 될 것이다.')
        stage.unit(22).setAction(0, 2)
        stage.say('&22\n주군, 황가이가 불을 지르러 온 게 틀림없어.\n우리는 이 순간을 잡아야 합니다.')
        stage.unit(0).setAction(17)
        stage.say('좋습니다, 봉선. 바로 준비해라!')
        stage.unit(22).setAction(6)
        stage.say('&22\n네.\n&0\n다른 사람들은 모두 출발 준비를 하고 있어요!')
        stage.unit(0).setAction(0)
        stage.unit(22).setAction(0)
        stage.setMenuVisible(True)
        stage.setJoinBattle(1, 15, [
            2,
            21,
            22])
        gvars[4076] = 0
        gvars[4057] = 27
        stage.setBattlePos([
            [
                16,
                21],
            [
                8,
                20],
            [
                15,
                21],
            [
                16,
                20],
            [
                25,
                22],
            [
                25,
                23],
            [
                17,
                8],
            [
                18,
                8],
            [
                7,
                10],
            [
                10,
                13],
            [
                27,
                15],
            [
                25,
                5],
            [
                9,
                19],
            [
                24,
                21],
            [
                23,
                20]])
    if not vars[724]:
        stage.jumpScene(55)
    return False


def scene6():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n다행히도 곽가 씨는 동우와의 결정적인 전투 전에 도착했다,\n이제 안심할 수 있어, 맹덕.\n&0\n흠.')
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 지형은 어떤가요?\n&20\n네, 전장은 거의 전부 물로 이루어져 있었습니다.\n&0\n음, 안타깝게도 아군 해전에는 익숙하지 않아.')
    if stage.unitClickTest(15):
        stage.say('&15\n물속에서 싸우고 있다고? 아, 안타깝게도!\n&17\n장군 허저, 무슨 일이죠?\n왜 한숨을 쉬어?\n&15\n응? 안 돼...... 아무것도 ......!\n&17\n장군허저 수영을 못하는 걸까......\n&15\n아니...... 그건 사실이 아니에요!!')
    if stage.unitClickTest(17):
        stage.say('&17\n이상하게도, 어떻게 바람이 바뀔 수 있지?\n&17\n이번 시즌에는 북서풍만 불 것으로 보입니다......')
    if stage.unitClickTest(22):
        stage.say('&22\n주군 적의 계략을 간파했음에도 불구하고,\n하지만 이 전투는 여전히 힘들었다.\n&0\n흠, 주유 정말 대단한 청년이네.')
    if stage.unitClickTest(21):
        stage.say('&21\n강 건너편에는 유비군의 깃발이 보이지 않는다,\n유비 공명 관측관할 계획인 것 같습니다.')
    if stage.unitClickTest(23):
        stage.say('&23\n그런 계획조차도 밝혀지지 않았다,\n정말 누구도 마주할 수 없어.\n&22\n글쎄, 내가 탓할 일은 없어.\n방금 밖에서 돌아왔어요,\n구경꾼이 더 잘 본다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
