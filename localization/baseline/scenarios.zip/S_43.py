# Source Generated with Decompyle++
# File: S_43.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27], [
        '(23,28)',
        '(24,28)',
        '(23,27)',
        '(24,27)',
        '(14,28)',
        '(14,33)',
        '(7,33)',
        '(4,24)'])
    stage.nearEvent([
        0,
        35,
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, 35, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 24, 'y': 28, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 76, 'x': 23, 'y': 28, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 79, 'x': 24, 'y': 27, 'dir': 0, 'lv': 6, 'i': 2},
         {'id': 92, 'x': 23, 'y': 27, 'dir': 0, 'lv': 4, 'i': 3},
         {'id': 210, 'x': 23, 'y': 24, 'dir': 0, 'lv': 0, 'i': 4},
         {'id': 211, 'x': 24, 'y': 24, 'dir': 0, 'lv': 0, 'i': 5},
         {'id': 212, 'x': 27, 'y': 27, 'dir': 1, 'lv': 0, 'i': 6},
         {'id': 213, 'x': 27, 'y': 28, 'dir': 1, 'lv': 0, 'i': 7},
         {'id': 234, 'x': 23, 'y': 25, 'dir': 0, 'lv': 0, 'i': 8},
         {'id': 235, 'x': 24, 'y': 25, 'dir': 0, 'lv': 0, 'i': 9},
         {'id': 236, 'x': 26, 'y': 27, 'dir': 1, 'lv': 0, 'i': 10},
         {'id': 237, 'x': 26, 'y': 28, 'dir': 1, 'lv': 0, 'i': 11},
         {'id': 78, 'x': 14, 'y': 33, 'dir': 0, 'lv': 6, 'i': 12},
         {'id': 88, 'x': 14, 'y': 28, 'dir': 0, 'lv': 4, 'i': 13},
         {'id': 358, 'x': 14, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 359, 'x': 15, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 360, 'x': 16, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 361, 'x': 17, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 96, 'x': 7, 'y': 33, 'dir': 0, 'lv': 4, 'ai': 0, 'i': 18},
         {'id': 310, 'x': 6, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 19},
         {'id': 311, 'x': 8, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 20},
         {'id': 85, 'x': 7, 'y': 28, 'dir': 0, 'lv': 6, 'ai': 3, 'targetId': 0, 'i': 21},
         {'id': 258, 'x': 5, 'y': 30, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 22},
         {'id': 259, 'x': 6, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 23},
         {'id': 260, 'x': 8, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 24},
         {'id': 83, 'x': 7, 'y': 29, 'dir': 0, 'lv': 4, 'ai': 3, 'targetId': 0, 'i': 25},
         {'id': 282, 'x': 6, 'y': 30, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 26},
         {'id': 283, 'x': 8, 'y': 28, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 27},
         {'id': 82, 'x': 4, 'y': 24, 'dir': 0, 'lv': 4, 'ai': 0, 'targetId': 0, 'i': 28},
         {'id': 214, 'x': 4, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 0, 'targetId': 0, 'i': 29},
         {'id': 215, 'x': 6, 'y': 24, 'dir': 0, 'lv': 0, 'ai': 0, 'targetId': 0, 'i': 30},
         {'id': 216, 'x': 4, 'y': 26, 'dir': 0, 'lv': 0, 'ai': 0, 'targetId': 0, 'i': 31},
         {'id': 81, 'hide': 1, 'x': 30, 'y': 9, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 32},
         {'id': 86, 'hide': 1, 'x': 29, 'y': 8, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 33},
         {'id': 87, 'hide': 1, 'x': 29, 'y': 9, 'dir': 3, 'lv': 4, 'ai': 1, 'i': 34},
         {'id': 362, 'hide': 1, 'x': 29, 'y': 7, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 363, 'hide': 1, 'x': 29, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 364, 'hide': 1, 'x': 30, 'y': 7, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 365, 'hide': 1, 'x': 30, 'y': 8, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 366, 'hide': 1, 'x': 30, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 414, 'hide': 1, 'x': 14, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 40},
         {'id': 415, 'hide': 1, 'x': 13, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 41},
         {'id': 416, 'hide': 1, 'x': 15, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 42},
         {'id': 417, 'hide': 1, 'x': 14, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 43},
         {'id': 418, 'hide': 1, 'x': 14, 'y': 27, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 44},
         {'id': 419, 'hide': 1, 'x': 13, 'y': 28, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 45},
         {'id': 420, 'hide': 1, 'x': 15, 'y': 28, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 46},
         {'id': 421, 'hide': 1, 'x': 14, 'y': 29, 'dir': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 47}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 9,
            'y': 9 },
        {
            'idx': 1,
            'x': 10,
            'y': 8 },
        {
            'idx': 2,
            'x': 9,
            'y': 10 },
        {
            'idx': 3,
            'x': 10,
            'y': 9 },
        {
            'idx': 4,
            'x': 11,
            'y': 8 },
        {
            'idx': 5,
            'x': 8,
            'y': 10 },
        {
            'idx': 6,
            'x': 8,
            'y': 9 },
        {
            'idx': 7,
            'x': 9,
            'y': 8 },
        {
            'idx': 8,
            'x': 10,
            'y': 7 },
        {
            'idx': 9,
            'x': 7,
            'y': 9 },
        {
            'idx': 10,
            'x': 8,
            'y': 8 },
        {
            'idx': 11,
            'x': 9,
            'y': 7 },
        {
            'idx': 12,
            'x': 7,
            'y': 8 },
        {
            'idx': 13,
            'x': 8,
            'y': 7 },
        {
            'idx': 14,
            'x': 9,
            'y': 6 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.loadBg(43)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(1)
    stage.unit(0).setDir(stage.countDir(0, 35))
    stage.say('&0\n우리가 슈를 정복할 때 너무 부주의했어.\n그래서 지금 그녀는 ...... 무력하게 지내고 있다.\n공명와 손권가 손을 잡는 모습을 지켜보는 것...... 얼마나 부주의하는가!')
    stage.unit(76).setDir(stage.countDir(76, 35))
    stage.unit(35).setDir(stage.countDir(35, 76))
    stage.say('&76\n공명 씨의 지시에 따라 이미 준비되어 있습니다.\n어떻게 생각하세요, 선생님?\n&35\n물 위에서 싸우면,\n오나라 군대를 막을 수 있는 자는 없었다.\n조조 결국 다시 붉은 절벽 전투의 쓰라림을 겪게 될 것이다.')
    stage.unit(79).setDir(stage.countDir(79, 35))
    stage.say('&79\n덕망 있는 동생.\n일이 그렇게 순조롭게 진행될까요?')
    stage.unit(35).setDir(stage.countDir(35, 79))
    stage.say('&35\n형, 걱정 마.\n모든 게 계획대로 진행된다면,\n그때가 되면 조의 군대는 완전히 패배할 뿐이었다.\n&35\n그런데 거기 육손는 어때?\n이제 때가 된 것 같아요, 그렇죠?')
    stage.unit(92).setDir(stage.countDir(92, 35))
    stage.say('&92\n조의 군대는 아직 움직이지 않았다.\n대화하기 전에 먼저 조사하는 게 좋을 것 같아.')
    stage.unit(35).setDir(stage.countDir(35, 92))
    stage.say('&35\n우리가 해안에서 조의 군대를 막지 못한다면,\n우의 이점은 활용할 수 없었다.\n육해의 동시 공격은 여전히 필요합니다.')
    stage.unit(76).setDir(stage.countDir(76, 92))
    stage.say('&76\n권총이 즉시 육손에게 말했다.\n그가 싸우게 놔둬.')
    stage.unit(92).setDir(stage.countDir(92, 76))
    stage.say('&92\n주군의 명령이었으니,\n나는 어쩔 수 없이 복종할 수밖에 없었다.')
    stage.unit(92).setDir(0)
    stage.unit(92).setAction(5)
    stage.say('&92\n육손에게 신호를 보내.\n&35\n조의 군대가 행동하지 않았더라면......')
    stage.unit(92).setAction(0)
    stage.unit(0).setAction(5)
    stage.say("&0\n적군 전투에 공명 했으니,\n여기 머무는 건 정말 위험해.\n&0\n속담에 있듯이, '전쟁에서 속도가 가장 중요하다.'\n전면 공격!\n서둘러 상륙해.")
    stage.unit(0).setAction(0)
    stage.unit(35).setDir(stage.countDir(35, 76))
    stage.say('&35\n좋지 않아!\n그래서 조조 것 같았어요—너무 빨리 왔으니까요!\n손권, 노숙, 장조 경에게 빨리 알리세요.')
    stage.unit(76).setDir(stage.countDir(76, 88))
    stage.unit(76).setAction(5)
    stage.say('&76\n흠. 장자오, 노숙!\n빨리, 나무 인형을 불러.')
    stage.unit(76).setAction(0)
    stage.unit(78).setAction(5)
    stage.say('&78\n네, 즉시 나무 인형들을 소환하겠습니다.\n나무 인형, 나와!')
    stage.unit(78).setAction(0)
    stage.unit(414).show()
    stage.unit(415).show()
    stage.unit(416).show()
    stage.unit(417).show()
    stage.say('&88\n주군 또 한 번 공명의 근거 없는 말에 속았다.\n흥! 정말 짜증나.')
    stage.unit(88).setAction(5)
    stage.say('&88\n하지만 이 지경에 이르렀다,\n더 이상 주군 맞설 수 없어.\n나무 사람, 빨리 싸워!')
    stage.unit(88).setAction(0)
    stage.unit(418).show()
    stage.unit(419).show()
    stage.unit(420).show()
    stage.unit(421).show()
    stage.say('&0\n음, 또 나무 인형?\n하지만 이전 전투들에서 이미 알려진 바로는,\n시전자가 패배하면 주문은 무효화됩니다.\n&0\n하지만 어떻게 시전자를 이길 수 있을까요......')
    sel = stage.choice('전 군대가 상륙했다\n부대는 두 개의 경로로 나뉘었다', -1)
    if sel == 1:
        stage.say('&0\n먼저 상륙하는 게 낫다,\n해상 전쟁은 아군에게 매우 불리했다.\n&0\n군대 전체가 만으로 돌파했다,\n그럼 시전자를 물리치세요!')
        stage.unit(5, 1).move(5, 13, 2)
        stage.unit(9, 1).move(4, 12, 2)
        stage.unit(2, 1).move(6, 13, 2)
        stage.unit(6, 1).move(5, 12, 2)
        stage.unit(12, 1).move(4, 11, 2)
        stage.unit(0, 1).move(6, 12, 2)
        stage.unit(10, 1).move(5, 11, 2)
        stage.unit(3, 1).move(7, 12, 2)
        stage.unit(7, 1).move(6, 11, 2)
        stage.unit(13, 1).move(5, 10, 2)
        stage.unit(1, 1).move(7, 11, 2)
        stage.unit(11, 1).move(6, 10, 2)
        stage.unit(4, 1).move(8, 11, 2)
        stage.unit(8, 1).move(7, 10, 2)
        stage.unit(14, 1).move(6, 9, 2)
        stage.unit(362).show()
        stage.unit(86).show()
        stage.unit(87).show()
        stage.unit(363).show()
        stage.unit(364).show()
        stage.unit(365).show()
        stage.unit(81).show()
        stage.unit(366).show()
        stage.unit(76).setDir(stage.countDir(76, 81))
        stage.unit(35).setDir(stage.countDir(35, 81))
        stage.say('&76\n육손, 드디어 따라잡았구나!\n어서 싸워조조!\n&81\n걱정 마세요, 주군\n필사적으로 싸우는 한, 후회는 없을 거야.\n모든 병사들, 전력을 다해라!\n&86\n전투에서 지면 모든 것이 끝난다.\n모두가 죽을 때까지 싸우겠다는 결의를 가지고 싸워야 한다.\n&87\n헤헤, 맞아.\n육손 전략가들은 아마 이 정도를 잘 이해하지 못할 겁니다!\n&35\n(하지만 그들은 너무 늦게 온 것 같다,\n이제, 그게 조조 상륙을 막지는 못할 것 같아. )')
        stage.unit(362).move(25, 8, 3)
        stage.unit(86).move(25, 9, 3)
        stage.unit(87).move(25, 10, 3)
        stage.unit(363).move(25, 11, 3)
        stage.unit(364).move(26, 8, 3)
        stage.unit(365).move(26, 9, 3)
        stage.unit(81).move(26, 10, 3)
        stage.unit(366).move(26, 11, 3)
    elif sel == 2:
        stage.say('군대를 두 부분으로 나누세요! 제가 주력 부대로 먼저 상륙해서, 적들을 유인해 올게요. 동시에 분대도 만 안으로 보내서, 선술을 쓰는 자들을 직접 격파하세요!')
        stage.unit(5, 1).move(5, 13, 2)
        stage.unit(9, 1).move(4, 12, 2)
        stage.unit(2, 1).move(6, 13, 2)
        stage.unit(6, 1).move(5, 12, 2)
        stage.unit(12, 1).move(4, 11, 2)
        stage.unit(0, 1).move(6, 12, 2)
        stage.unit(10, 1).move(5, 11, 2)
        stage.unit(13, 1).move(5, 10, 2)
        stage.unit(3, 1).move(13, 12, 2)
        stage.unit(4, 1).move(14, 11, 2)
        stage.unit(1, 1).move(13, 11, 2)
        stage.unit(7, 1).move(12, 11, 2)
        stage.unit(8, 1).move(13, 10, 2)
        stage.unit(11, 1).move(12, 10, 2)
        stage.unit(14, 1).move(12, 9, 2)
        stage.unit(362).show()
        stage.unit(86).show()
        stage.unit(87).show()
        stage.unit(363).show()
        stage.unit(364).show()
        stage.unit(365).show()
        stage.unit(81).show()
        stage.unit(366).show()
        stage.unit(76).setDir(stage.countDir(76, 81))
        stage.unit(35).setDir(stage.countDir(35, 81))
        stage.say('&76\n육손, 드디어 따라잡았구나!\n어서 싸워조조!\n&81\n걱정 마세요, 주군\n필사적으로 싸우는 한, 후회는 없을 거야.\n모든 병사들, 전력을 다해라!\n&86\n전투에서 지면 모든 것이 끝난다.\n모두가 죽을 때까지 싸우겠다는 결의를 가지고 싸워야 한다.\n&87\n헤헤, 맞아.\n육손 전략가들은 아마 이 정도를 잘 이해하지 못할 겁니다!\n&35\n(하지만 그들은 너무 늦게 온 것 같다,\n이제, 그게 조조 상륙을 막지는 못할 것 같아. )')
        stage.unit(362).move(25, 8, 3)
        stage.unit(86).move(25, 9, 3)
        stage.unit(87).move(25, 10, 3)
        stage.unit(363).move(25, 11, 3)
        stage.unit(364).move(26, 8, 3)
        stage.unit(365).move(26, 9, 3)
        stage.unit(81).move(26, 10, 3)
        stage.unit(366).move(26, 11, 3)
        stage.say('&0\n흠, 부대에 서두르라고 전해!\n적의 증원군이 거의 도착했다!')
        stage.unit(3, 1).move(15, 15, 2)
        stage.unit(4, 1).move(16, 14, 2)
        stage.unit(1, 1).move(15, 14, 2)
        stage.unit(7, 1).move(14, 14, 2)
        stage.unit(8, 1).move(15, 13, 2)
        stage.unit(11, 1).move(14, 13, 2)
        stage.unit(14, 1).move(13, 13, 2)
        vars[2] = 1
    stage.unit(82).setDir(stage.countDir(82, 35))
    stage.say('&82\n쳇! 공명 이 사람.\n주군 그가 자신을 조종하도록 내버려 두고,\n정말 지루해!')
    stage.unit(96).setDir(stage.countDir(96, 76))
    stage.say('&96\n나라조차 없는 사람과 동맹을 맺는다는 것,\n도대체 무슨 생각손권주군 거지?')
    stage.unit(85).setDir(stage.countDir(85, 0))
    stage.say('&85\n나도 그렇게 생각해. 우리가 이해할 수 있게 주군 필요해,\n여기서는 전투에 돌진하기만 하면 된다,\n공명 필요 없었다.')
    stage.unit(83).setDir(stage.countDir(83, 96))
    stage.say('&83\n판장, 딩펑, 너희가 진형을 지키는 책임자야!\n네 몫은 내 몫으로 가져가!')
    stage.unit(82).setDir(stage.countDir(82, 83))
    stage.unit(96).setDir(stage.countDir(96, 83))
    stage.say('&82\n부탁할게!\n공명 혼자 거만하게 굴지 마.\n&96\n네가 믿고 있어.')
    stage.bgSound(10)
    stage.setWinCondition('승리 조건\n1. 패배 제갈량.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('제갈량를 이겨라!')
    stage.unit(35).heightLight()
    stage.startOper()
    vars[543] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[70] and stage.round() == 4:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[70] = 1
    if not vars[71] and stage.round() == 7:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[71] = 1
    if not vars[72] and stage.round() == 10:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[72] = 1
    if not vars[73] and stage.round() == 13:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[73] = 1
    if not vars[74] and stage.round() == 16:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[74] = 1
    if not vars[75] and stage.round() == 19:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[75] = 1
    if not vars[76] and stage.round() == 22:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[76] = 1
    if not vars[77] and stage.round() == 25:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[77] = 1
    if not vars[78] and stage.round() == 28:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[78] = 1
    if not vars[79] and stage.round() == 31:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[79] = 1
    if not vars[80] and stage.round() == 34:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[80] = 1
    if not vars[81] and stage.round() == 37:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[81] = 1
    if not vars[82] and stage.round() == 40:
        if not vars[58]:
            stage.unit(414).show(14, 32, 0)
            stage.unit(415).show(13, 33, 0)
            stage.unit(416).show(15, 33, 0)
            stage.unit(417).show(14, 34, 0)
        if not vars[57]:
            stage.unit(418).show(14, 27, 0)
            stage.unit(419).show(13, 28, 0)
            stage.unit(420).show(15, 28, 0)
            stage.unit(421).show(14, 29, 0)
        if stage.isInRect(1025, 11, 24, 18, 35):
            stage.unit(414).setAI(1)
            stage.unit(415).setAI(1)
            stage.unit(416).setAI(1)
            stage.unit(417).setAI(1)
            stage.unit(418).setAI(1)
            stage.unit(419).setAI(1)
            stage.unit(420).setAI(1)
            stage.unit(421).setAI(1)
        vars[82] = 1
    if not vars[20] and stage.isInPos(1025, 23, 28):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 24, 28):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 23, 27):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 24, 27):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 14, 28):
        stage.getItem(151, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 14, 33):
        stage.getItem(151, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 7, 33):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 4, 24):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if vars[2] and not vars[6] and not vars[30] and stage.curCamp() == 2 and stage.totalRectUnit(2, 21, 24, 27, 31) < 10:
        if not vars[56]:
            stage.unit(35).setDir(stage.countDir(35, 79))
            stage.unit(79).setDir(stage.countDir(79, 35))
            stage.say('&35\n형님,\n당신은 군인들을 지원하는 책임이 있습니다.\n&79\n좋아!')
        if not vars[55]:
            stage.unit(76).setAction(5)
            stage.say('&76\n나도 전투에 참여하게 해줘!')
            stage.unit(76).setAction(0)
            stage.unit(35).setDir(stage.countDir(35, 76))
            stage.say('&35\n이 경기에서 졌다고 해서 상황이 끝난 것은 아니었다.\n어른들, 싸워도 좋지만 너무 무리하지 마.')
            stage.unit(76).setDir(stage.countDir(76, 35))
            stage.say('&76\n알아요, 강요하지 않을게요.\n하지만 저는 절대 포기하지 않는 사람입니다.\n그게 바로 제 성격이에요, 하하하!')
        if not vars[61]:
            stage.unit(35).setDir(stage.countDir(35, 79))
            stage.unit(79).setDir(stage.countDir(79, 35))
            stage.say('&35\n전총장군, 전투에 나갈 수 있습니까?\n&92\n물론 할 수 있지. 이건 오나라 군대의 전투야!')
        stage.unit(35).setAI(0)
        stage.unit(76).setAI(0)
        stage.unit(79).setAI(0)
        stage.unit(92).setAI(0)
        vars[6] = 1
    if not vars[7] and stage.totalUnit(0) >= 6 and stage.curCamp() == 2 and stage.totalUnit(2) < 9:
        stage.resumeCtrl()
        stage.say('&35\n계속 싸우는 것은 무의미할 것이다.\n먼저 철수해야 해.')
        stage.unit(35).hide()
        if not vars[55]:
            stage.say('&76\n내가 졌어......?\n선택의 여지가 없었습니다.\n전군을 후퇴시켜라!')
            stage.unit(76).hide()
        if not vars[51]:
            stage.say('&81\n누가 그가 적에게 등을 돌리고 도망칠 줄 알았겠는가......\n정말 후회의 원천입니다!')
            stage.unit(81).hide()
        stage.setRectUnitHide(0, 0, 31, 39, 2)
        vars[50] = 1
        stage.say('&0\n좋아, 드디어 적군 쫓아냈어!\n아군 이겼어!')
        stage.reward(0, [
            144,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[643] = 1
        return True
    if vars[2] and not vars[6] and not vars[30] and stage.curCamp() == 2 and stage.isInRect(1025, 11, 24, 31, 39):
        if not vars[56]:
            stage.unit(79).setDir(stage.countDir(79, 0))
            stage.say('&79\n적이 우리를 향해 다가오고 있어.\n이거 안 좋네!')
        if not vars[61]:
            stage.unit(92).setAction(8)
            stage.say('&92\n적이 실제로 우위를 점했다!\n공명, 네가 어떻게 책임지는지 보자!\n&35\n조의 군대가 상륙하게 두지 말았어야 했어!\n만약 육손 장군의 증원군이 더 일찍 도착했다면......')
        if not vars[55]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.unit(76).setAction(5)
            stage.say('&76\n이미 상륙한 조조 병력과 교전하라!')
            stage.unit(76).setAction(0)
        stage.unit(96).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(82).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        vars[30] = 1
    if not vars[2] and not vars[31] and stage.totalRectUnit(0, 4, 24, 31, 39) >= 3 and stage.curCamp() == 2:
        if not vars[56]:
            stage.unit(79).setDir(stage.countDir(79, 0))
            stage.say('&79\n적이 우리를 향해 다가오고 있어.\n이거 안 좋네!')
        if not vars[61]:
            stage.unit(92).setAction(8)
            stage.say('&92\n적이 실제로 우위를 점했다!\n공명, 네가 어떻게 책임지는지 보자!\n&35\n조의 군대가 상륙하게 두지 말았어야 했어!\n만약 육손 장군의 증원군이 더 일찍 도착했다면......')
        if not vars[55]:
            stage.unit(76).setDir(stage.countDir(76, 0))
            stage.unit(76).setAction(5)
            stage.say('&76\n이미 상륙한 조조 병력과 교전하라!')
            stage.unit(76).setAction(0)
        stage.unit(96).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(82).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        vars[31] = 1
    if not vars[40] and stage.isNear(0, 35, True):
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&0\n왜 손권와 동맹을 맺고 싶으신가요?\n그가 나보다 세상에 평화를 가져올 수 있는 능력이 있을까?\n&35\n나와 손권의 동맹은 일시적일 뿐이야,\n전 영주의 소원을 들어야 유비.\n&0\n나라조차 없는 사람이 무엇을 이룰 수 있을까요?\n비록 이건 결코 이룰 수 없는 꿈이지만,\n과거 관계를 생각하면, 너를 저승으로 보내버릴 거야!\n&35\n네가 날 죽인 후에 그렇게 말할 거야!\n전쟁은 아직 끝나지 않았다.')
        vars[40] = 1
    if vars[629] and not vars[41] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n손권, 레드 클리프 헤이트를 눈 속에서 씻어줄게.\n&76\n흥! 또 패배를 맛보게 해주겠다!')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&35\n좋지 않아!\n먼저 후퇴해야 해.')
        stage.unit(35).hide(1)
        if not vars[55]:
            stage.say('&76\n공명 후퇴?\n다른 방법은 없었다.\n전군을 후퇴시켜라!')
            stage.unit(76).hide()
        if not vars[51]:
            stage.say('&81\n흠, 우리는 후퇴할 수밖에 없는 건가요?\n누가 그가 적에게 등을 돌리고 도망칠 줄 알았겠는가......\n정말 후회의 원천입니다!')
            stage.unit(81).hide()
        stage.setRectUnitHide(0, 0, 31, 39, 2)
        vars[50] = 1
        stage.say('&0\n아주 좋아! 드디어 적군 쫓아냈어!\n아군 이겼어!')
        stage.reward(0, [
            144,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[643] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n아프고, 정말 강렬해!\n조조, 네 끈기를 존경해.\n육손 돌아올게. 다시 만날 때까지!')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n푸훗! 진짜로 졌어.\n어쩔 수 없으니 일단 반품해야 할 것 같아요.\n나 간다!')
        stage.unit(86).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n이런 식으로 불필요한 것들,\n설령 실패해도 슬퍼할 일이 없어요!\n후퇴!')
        stage.unit(96).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n아-아, 안 돼!\n나는 후퇴하고 있다,\n제발 날 놔줘!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n음, 젠장!\n좋아, 정면으로 싸우지 말았어야 했어.\n후퇴!')
        stage.unit(76).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n뭐라고!?\n후퇴! 후퇴!')
        stage.unit(79).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n음, 지금은 그게 전부.......\n후퇴! 후퇴!')
        stage.unit(88).hide(1)
        stage.unit(418).hide()
        stage.unit(419).hide()
        stage.unit(420).hide()
        stage.unit(421).hide()
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n도와줘, 도와줘!\n후퇴! 후퇴!')
        stage.unit(78).hide(1)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n무너질 지경까지 몰릴 줄은 전혀 예상하지 못했습니다......\n후퇴! 후퇴!')
        stage.unit(85).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n음, 그럼 좋은 거래를 안 받고 그냥 물러날 수 있다는 거군요?')
        stage.unit(83).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n공명 계획을 너무 믿어서 우리 잘못이야......\n아, 정말 짜증나네요!\n이제 후퇴만이 유일한 선택지입니다!')
        stage.unit(92).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n위험! 위험!\n목숨을 잃기 전에 빨리 후퇴하는 게 좋을 거야!')
        stage.unit(87).hide(1)
        vars[62] = 1
    if vars[100] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적군 쫓아냈어!\n아군 이겼어!')
        stage.reward(0, [
            144,
            -1])
        stage.end()
        vars[0] = 1
        vars[643] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 연합군 앞에서 참패를 당했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
