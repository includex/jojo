# Source Generated with Decompyle++
# File: R_35.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            9,
            44,
            58,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            21,
            64,
            52,
            3]])
    stage.draw()
    stage.effectSound(208, 0)
    stage.delay(3)
    stage.setEventName('같은 하늘 아래서')
    stage.setStageName('조조군의 주영지인 락쉬 입구')
    if vars[734]:
        stage.unit(1).setAction(0, 2)
        stage.say('&1\n맹덕, 이번에는 마침내 탈출에 성공했지만,\n그러나 아군 손실은 예상보다 심각했다.')
        stage.unit(1).setAction(3)
        stage.say('&1\n만약 동오군이 다시 공격하러 병력을 보내면,\n우리가 그들을 막아낼 수 없을 것 같아!')
        stage.unit(1).setAction(0)
        stage.say('걱정 마세요.')
        stage.unit(1).setAction(2)
        stage.say('&1\n뭐라고!?\n뭐라고 했어?\n현재 군 상황을 살펴보겠습니다......')
        stage.say('&0\n원양 이제 웨이, 우, 슈 모두 집에서 걱정이 있다.')
        stage.unit(1).setAction(0)
        stage.say('&1\n아무도 전력을 다하지 못한다는 말인가요?\n&0\n흠. 이제 삼국이 서로 제약하고 있어,\n아무도 성급하게 행동하지 못했다.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n서나라가 남아 있는 한,\n손권 우리와 계속 얽히지 않을 거야.')
        stage.unit(1).setAction(2)
        stage.say('&1\n그럼 이제 어떻게 해야 하지?')
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n할 수 있는 건 기다리는 것뿐이에요.\n손권 사절을 보내 휴전을 요청했다.')
        stage.unit(1).setAction(0)
        stage.say('&1\n사람을 보내......?')
        stage.showUnit(181, 54, 22, 2)
        stage.say('&181\n보고해!')
        stage.delay(3)
        stage.unit(181).setAction(11)
        stage.say('&181\n주군, 동무에서 온 사절단이 도착했다.')
        stage.unit(1).setAction(0, 1)
        stage.say('&1\n!!\n&0\n정말? 예상보다 일찍.\n좋아, 데려와.\n&181\n네.')
        stage.unit(181).hide()
        stage.delay(5)
        stage.showUnit(193, 55, 22, 2)
        stage.say('&193\n방해해서 미안해.')
        stage.unit(193).move(54, 64, 2)
        stage.say('&0\n저는 Han조조 총장입니다\n당신은 동우에서 온 사신임에 틀림없군요.\n무슨 일이야?')
        stage.unit(193).setAction(6)
        stage.say('&193\n네, 주군 저에게 휴전을 요청하라고 명령했습니다.\n&0\n아, 휴전?\n&193\n네, 양측 모두 병력을 철수시키길 바라주군,\n그 이후로 그들의 우호적인 관계는 더욱 깊어졌다.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n손권 꽤 잘 생각했다,\n그때 전쟁을 시작한 건 너희였던 것 같아.\n&193\n네.\n물론 당신 말이 맞지만, 선생님,\n하지만 이번에는 무슨 일이 있어도 제발 ......')
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n좋아!\n휴전을 약속했잖아,\n돌아가서 손권 대답해.\n&193\n네, 셰 경.\n그럼 이제 물러가겠습니다!')
        stage.unit(193).setAction(0)
        stage.delay(3)
        stage.unit(193).move(54, 22, 0)
        stage.unit(193).hide()
        stage.effectSound(208, 255)
        stage.clsUnit()
    if not vars[734]:
        stage.unit(19).setAction(0, 2)
        stage.delay(3)
        stage.unit(19).setAction(6)
        stage.say('&19\n비록 동우가 결국 후퇴했지만,\n아군 손실도 매우 크다.')
        stage.unit(19).setAction(0)
        stage.delay(3)
        stage.unit(20).setAction(0, 2)
        stage.delay(3)
        stage.unit(20).setAction(6)
        stage.say('&20\n싸움을 계속하는 것은 너무 무리일 것이다.')
        stage.unit(20).setAction(0)
        stage.say('&0\n글쎄, 우리가 할 수 있는 게 없어.\n먼저 쉬두로 철수합시다!\n&0\n문약, 너는 동오 진영에 사신으로 파견되고 있다,\n손권와 휴전에 대해 논의하세요.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네, 바로 출발하겠습니다.')
        stage.unit(20).setAction(0)
        stage.say('좋습니다, 휴전 협상이 성사되면,\n우리는 귀국할 것입니다.')
        stage.effectSound(208, 255)
        stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 426, 161)
    stage.showHead(76, 490, 200)
    stage.bottomTxt('러쉬관에서 결정적인 전투가 끝난 후,', False, False, False)
    stage.delay(5)
    stage.bottomTxt('조조 손권와 조화롭게 살았다,', True, False, False)
    stage.delay(10)
    stage.head(0).move(337, 100)
    stage.delay(8)
    stage.head(76).move(507, 218)
    stage.delay(5)
    stage.bottomTxt('양군 모두 병력을 철수시키고 고향으로 돌아갔다.', True, True, True)
    stage.delay(5)
    stage.bottomTxt('그래서......', False, False, False)
    stage.delay(5)
    stage.bottomTxt('위조조, 동우 손권,', True, False, False)
    stage.delay(5)
    stage.showHead(32, 26, 172)
    stage.delay(5)
    stage.bottomTxt('그리고 이 세 국가를 유비 서와 함께,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('각자는 영토를 공고히 했다,', True, True, True)
    stage.delay(10)
    stage.bottomTxt('삼국지 삼국의 전례 없는 시대가 도래했다.', False, False, False)
    stage.delay(20)
    stage.bgSound(-1)
    return False


def scene1():
    stage.loadBg(2, 28)
    stage.showUnits([
        [
            19,
            68,
            42,
            1],
        [
            181,
            52,
            79,
            1],
        [
            182,
            54,
            46,
            1]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('수두, 총리 관저 앞')
    stage.showUnit(0, 68, 94)
    stage.unit(0).move(68, 65, 0)
    stage.delay(3)
    stage.unit(0).setAction(0, 3)
    stage.say('&0\n수고 많으셨습니다.')
    stage.unit(181).setAction(11)
    stage.unit(182).setAction(11)
    stage.say('&181\n네.')
    stage.unit(0).setAction(0, 0)
    stage.say('&0\n음, 그게 중달?\n&182\n그래. 전략가는 잠시 그곳에서 하늘을 바라보고 있었다.\n&181\n예전에는 똑같았다, 완전히 움직이지 않았다......\n&0\n한숨!\n이 사람은 여전히 예전과 같아.')
    stage.unit(0).move(68, 50, 0)
    stage.unit(0).setAction(0)
    stage.unit(181).setAction(0)
    stage.unit(182).setAction(0)
    stage.say('&0\n중달.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n응? 그러니까 주군.\n&0\n다시 한 번 천체 현상을 관찰하고 세계의 미래를 예측하고 있나요?\n&19\n이게 제 유일한 관심사입니다.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n이자, 그렇지?\n세상은 광대하지만, 혼란스러운 시대의 흐름을 예측하는 당신 같은 사람들,\n그것을 관심사로 여기는 사람은 매우 드뭅니다.')
    stage.unit(0).setAction(0, 0)
    stage.say('하지만 이런 흥미를 가볍게 여겨서는 안 됩니다. 당신이 아까 말했듯이, 천하는 이미 삼국으로 나뉘었으니까요. 예. 하지만 이 국면은 곧 깨질 겁니다. 삼국 정립의 상황이 곧 끝난다는 말씀이신가요? 네. 삼국 중 반드시 한 나라가 세상을 통일할 것입니다. 어느 나라라고요? 우리 위나라인가요? 그 점은 신도 아직 모르겠습니다만... 다만... 위나라일 것이라 믿습니다.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하.\n천상이 어떤 징조를 보인다고 해서 중요하지는 않습니다,\n우리의 업적을 실현하는 것이 중요합니다.')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.delay(3)
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 1)
    stage.say('&19\n주군, 유비 주와 손권 나라 오,\n우리는 모두 같은 하늘 아래에 있어.')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n슈와 우는 ......?')
    stage.delay(10)
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.sectionName(4, '그리고 왕국은 통일되었다')
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            23,
            48,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(205, 0)
    stage.delay(3)
    stage.setEventName('한중을 붙잡고 있다')
    stage.setStageName('서두, 총리 관저')
    stage.say('&23\n주군, 나 찾고 있어?\n&0\n오, 원허, 널 기다리고 있었어.\n너랑 얘기하고 싶은 게 있어. 어떻게 생각해, 조비?\n&23\n응?\n왜 갑자주군 그런 말을 했을까?\n&0\n그가 내 후계자로 적합하다고 생각해?\n&23\n…… 왜 저한테 이런 질문을 하시는 거죠?')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n순욱와 정욱 내 아들들을 너무 잘 알고 있어,\n그리고 각자 선호하는 이유가 다 다르죠.\n&0\n사마의 네가 나와 함께 있는 날들이 길지 않다면,\n그래서 이 문제는 오직 당신만 물어볼 수 있습니다.')
    stage.unit(23).setAction(0)
    stage.say('&23\n그럼, 주군 누구가 적합하다고 생각해?')
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n흠.........')
    stage.effectSound(205, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('조비 적절하네요\n조지는 적합하다', 0)
    if sel == 1:
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(205, 0)
        stage.delay(3)
        stage.say('&0\n흠,\n저는 여전히 정당한 상속인이 상속해야 한다고 생각합니다조비.')
        stage.unit(23).setAction(6)
        stage.say('&23\n아, 주군, 나도 동의해.\n고대부터 적자아들은 아버지로부터 상속받아 왔습니다.\n&0\n나도 그렇게 생각해.\n그러나 일부 신하들은 조지를 지지했다.')
        stage.unit(23).setAction(0)
        stage.say('&23\n그건 절대 안 될 거야,\n아들 원소 잊었어?\n&23\n원소 셋째 아들을 상속자로 지정했기 때문이다,\n이로 인해 위안 가문의 붕괴와 파멸이 이어졌다.')
        stage.unit(23).setAction(6)
        stage.say('&23\n주군, 원소의 실수를 반복할 수 없어.\n&0\n맞아요.\n음, 결정했어.\n내 경력은 조비에게 물려받을 거야.\n&23\n네.')
        vars[312] = 1
    elif sel == 2:
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(205, 0)
        stage.delay(3)
        stage.say('&0\n장남 조비는 꽤 재능이 있었지만,\n하지만 그는 모두를 지휘할 용기가 부족했다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n셋째 아들 조즈는 나라의 통치자가 될 재능을 지녔다,\n아마 그가 상속받는 게 더 나을지도 몰라.')
        stage.unit(23).setAction(6)
        stage.say('&23\n주군, 이건 절대 불가능해,\n원소 잊은 거야?\n&23\n원소 셋째 아들을 상속자로 지정했기 때문이다,\n이로 인해 위안 가문의 붕괴와 파멸이 이어졌다.\n&23\n주군, 원소의 실수를 반복할 수 없어.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n맞아요.\n음, 결정했어.\n내 경력은 조비에게 물려받을 거야.\n&23\n네.')
        vars[312] = 0
    stage.effectSound(205, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 333, 96)
    stage.bottomTxt('그 순간에......', False, False, False)
    stage.delay(8)
    stage.showHead(32, 24, 166)
    stage.delay(5)
    stage.bottomTxt('유비 국가 전력을 축적하고 전력과 예비력을 키우고,', True, True, False)
    stage.delay(5)
    stage.head(32).move(88, 90)
    stage.delay(5)
    stage.bottomTxt('마침내 한중을 공격하기 위해 군대가 파견되었다.', True, False, False)
    stage.delay(10)
    stage.showHead(12, 152, 75)
    stage.delay(5)
    stage.bottomTxt('한중을 지키는 조홍,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('서군의 압도적인 기세를 보고,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('쉬두의 조조에 도움을 구하고 있습니다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            6,
            58,
            70],
        [
            15,
            64,
            70],
        [
            9,
            70,
            70],
        [
            13,
            76,
            70],
        [
            20,
            52,
            40,
            2],
        [
            19,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            23,
            76,
            40,
            2],
        [
            181,
            48,
            55,
            3,
            11]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n뭐라고!\n슈가 한중을 공격하기 위해 거대한 군대를 보내다니!?')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&181\n네, 조홍 장군, 즉시 증원군을 보내주십시오.')
    stage.unit(19).setAction(6)
    stage.say('&19\n공명 마침내 행동에 나섰다.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(21).setAction(6)
    stage.say('&21\n한중 수비대는 며칠 이상 버티지 못했다,\n즉시 증원군을 보내야 합니다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n좋아! 즉시 군대를 이끌고 한중을 지원하라.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n하지만 주군, 주력 부대가 움직인다면,\n구출할 시간이 부족할 것 같아요.')
    stage.unit(20).setAction(0)
    stage.say('&0\n가장 빠른 선봉군을 보내야겠군.\n먀오차이!')
    stage.unit(6).setAction(0, 3)
    stage.say('&6\n존재한다.\n&0\n선봉대를 지휘하라 명령한다,\n즉시 한중으로 급히 이동해 증원군을 요청했다.\n나는 곧 주력 부대를 이끌고 도착했다.')
    stage.unit(6).setAction(6)
    stage.say('&6\n걱정 맹덕 마.')
    stage.unit(6).setAction(0)
    stage.say('&0\n네가 결정해, 하후연.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            6,
            54,
            80],
        [
            7,
            44,
            64,
            1]])
    stage.draw()
    stage.setStageName('한중: 조조군의 본진')
    stage.say('&6\n주군의 주력군이 곧 도착할 것이다,\n우리는 무슨 일이 있어도 이곳을 지켜야 합니다.')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        6,
        7,
        12], [
        0])
    gvars[4076] = 0
    gvars[4057] = 35
    stage.setBattlePos([
        [
            23,
            16],
        [
            22,
            17],
        [
            6,
            4],
        [
            4,
            6],
        [
            12,
            16],
        [
            19,
            26],
        [
            21,
            16],
        [
            23,
            18],
        [
            12,
            15],
        [
            19,
            25],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene5():
    if stage.unitClickTest(7):
        stage.say('&7\n전장은 온통 산들이고,\n지형이 꽤 복잡합니다,\n차라리 뒤로 물러서서 자리를 지키는 게 낫다.')
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&6\n가자!')
        stage.bgSound(-1)
        return True

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
