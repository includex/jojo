# Source Generated with Decompyle++
# File: R_39.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    if vars[738]:
        model.unitJoin(9, 255, 0)
        stage.bgSound(13)
        stage.delay(3)
        stage.loadBg(2, 53)
        stage.showUnits([
            [
                0,
                54,
                80],
            [
                14,
                54,
                64,
                2,
                6],
            [
                1,
                44,
                64,
                1],
            [
                15,
                44,
                58,
                1],
            [
                12,
                44,
                52,
                1],
            [
                20,
                64,
                64,
                3],
            [
                19,
                64,
                58,
                3],
            [
                21,
                64,
                52,
                3]])
        stage.draw()
        stage.setEventName('충성심과 righteousness방덕')
        stage.setStageName('판청 조조 본진')
        stage.say('&14\n주군 죄송합니다.\n팡 장군의 죽음에 대한 책임은 나에게 있다.\n&0\n잊어버려, 그건 방덕 운명이야,\n네 책임이 아니야.')
        stage.unit(14).setAction(0)
        stage.say('&14\n하지만......\n&0\n유진, 그게 우리가 생각할 수 있는 전부야.')
        stage.unit(14).setAction(6)
        stage.say('&14\n…… 네.\n주군, 한 가지 더 보고할 일이 있습니다,\n리뷰 주군 부탁드립니다......')
        stage.unit(14).setAction(0)
        stage.delay(3)
        stage.unit(14).move(54, 76, 2)
        stage.delay(3)
        stage.unit(14).move(54, 64, 2)
        stage.say('&0\n이게 ......야?')
        stage.getItem(41, 0)
        stage.unit(14).setAction(6)
        stage.say('&14\n이것은 판청을 지원하기 위한 길이었다,\n팡 장군이 모든 재산을 써서 샀어.\n&14\n그는 만약 예상치 못한 일이 생기면,\n이거 주군한테 넘겨.')
        stage.unit(14).setAction(0)
        stage.say('&0\n그는 죽음 이후의 충성을 표현하기 위해 그렇게 했다,\n그래서 이걸 두고 온 거지?')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n방덕 방덕.\n당신의 변함없는 충성을 증명하기 위해,\n조는 이 운석망치를 받아들일 거야.\n&0\n방덕, 네 영웅의 영혼은 지하에서 평안히 쉴 수 있어.\n방덕Ah, 정말 불 같구나......\n깊은 애정을 가진 사람이야!')
        stage.bgSound(-1)
        stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 294, 124)
    stage.showHead(3, 294, 204)
    stage.bottomTxt('관우 조의 군대에 패배했다', False, False, False)
    stage.delay(5)
    stage.head(3).move(254, 210)
    stage.delay(5)
    stage.bottomTxt('패배하여 마이청으로 도망쳤다,', True, False, False)
    stage.delay(10)
    stage.showHead(80, 368, 236)
    stage.delay(5)
    stage.bottomTxt('동우의 여몽', True, True, False)
    stage.delay(5)
    stage.head(80).move(318, 210)
    stage.delay(5)
    stage.bottomTxt('끈질기게 쫓아가며,', True, False, False)
    stage.delay(5)
    stage.head(3).hide()
    stage.delay(5)
    stage.bottomTxt('결국 관우 죽임을 당했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('서의 세력 조조을 성공적으로 약화시켰다', True, True, False)
    stage.delay(8)
    stage.head(0).move(331, 96)
    stage.delay(5)
    stage.bottomTxt('그래서 그는 다시 쉬두로 돌아갔다.', True, False, True)
    stage.bottomTxt('얼마 지나지 않아,', False, False, False)
    stage.delay(5)
    stage.head(80).hide()
    stage.delay(5)
    stage.bottomTxt('여몽 신비롭게 미쳐 죽었다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('동부 오의 사람들은 관우가 죽은 후 소란을 일으켰다고 믿었다.', True, True, False)
    stage.delay(8)
    stage.showHead(76, 501, 208)
    stage.delay(5)
    stage.bottomTxt('손권 사람들의 마음을 사로잡기 위해,', True, True, False)
    stage.delay(5)
    stage.bottomTxt('유비 보복을 피하며,', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 관우의 머리를 조조에게 건넸다.', True, False, True)
    stage.bgSound(13)
    stage.delay(3)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            50,
            70],
        [
            2,
            56,
            70],
        [
            8,
            62,
            70],
        [
            15,
            68,
            70],
        [
            20,
            50,
            41,
            2],
        [
            19,
            56,
            41,
            2],
        [
            23,
            62,
            41,
            2],
        [
            24,
            68,
            41,
            2],
        [
            21,
            74,
            41,
            2],
        [
            3,
            47,
            55,
            1]])
    stage.unit(201).move(48, 55, 1)
    stage.draw()
    stage.setEventName('서나라와 오나라의 공격과 방어')
    stage.setStageName('서두, 총리 관저')
    stage.unit(20).setAction(6)
    stage.say('&20\n동우가 관우의 목을 보냈다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    model.setFace(1)
    stage.unit(0).setAction(9)
    stage.say('&0\n와, 대단하네요......')
    stage.unit(2).setAction(9)
    stage.say('&2\n관우......')
    stage.unit(19).setAction(6)
    stage.say('&19\n손권 아마도 관우를 죽인 책임을 지려 했을 것이다,\n우리 탓해.')
    model.setFace(0)
    stage.say('&0\n손권 모든 노력이 헛수고였다.\n&19\n응?')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0)
    stage.say('&0\n유비 쉽게 넘기지 않을 거야.\n&0\n동우는 분명히 관우를 죽이지 않은 것을 후회할 것이다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n그러나 서는 동우에게 복수할 생각이었다.\n분명히, 그것은 오히려 해를 끼칠 뿐이었다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n공명도 이 사실을 알고 있을 거야......')
    stage.unit(24).setAction(0)
    stage.say('&0\n공명 복수가 어리석다는 것을 진심으로 알고 있었다,\n하지만 그는 여전히 유비을 멈출 수 없었다.')
    stage.unit(23).setAction(6)
    stage.say('&23\n복수에 성공할 수 있유비까?')
    stage.unit(23).setAction(0)
    stage.say('&0\n전쟁에서 충성과 정의는 얻을 수 없다,\n유비의 상황은 정말 한심해.')
    stage.say('&0\n장료.')
    stage.unit(2).setAction(0)
    stage.say('&2\n......\n&0\n국장과 함께 호화로운 장례를 치르기 위해 관우 머리를 바쳤다.\n이 일은 당신에게 맡겨도 될까요?')
    stage.unit(2).setAction(6)
    stage.say('&2\n......\n명령에 따르겠습니다.')
    stage.unit(2).setAction(0)
    stage.say('&0\n좋아, 모두, 나가도 돼.\n나랑 관우 단둘이 방에 있게 해줘......')
    stage.delay(5)
    stage.unitsMove([
        [
            stage.unit(21),
            98,
            41,
            1],
        [
            stage.unit(24),
            98,
            41,
            1],
        [
            stage.unit(23),
            98,
            41,
            1],
        [
            stage.unit(19),
            98,
            41,
            1],
        [
            stage.unit(20),
            98,
            41,
            1],
        [
            stage.unit(15),
            98,
            70,
            1],
        [
            stage.unit(8),
            98,
            70,
            1],
        [
            stage.unit(2),
            98,
            70,
            1],
        [
            stage.unit(1),
            98,
            70,
            1]])
    stage.unit(20).hide()
    stage.unit(19).hide()
    stage.unit(23).hide()
    stage.unit(24).hide()
    stage.unit(21).hide()
    stage.unit(1).hide()
    stage.unit(2).hide()
    stage.unit(8).hide()
    stage.unit(15).hide()
    stage.delay(10)
    stage.say('관우……\n예전에 우리 사이의 정은,\n나 조조가 아직도 생생하게 기억하고 있네!')
    stage.unit(0).setAction(9)
    stage.say('관우야, 관우……')
    stage.bgSound(-1)
    stage.clsUnit()
    return False


def scene2():
    if model.ambition() >= 85:
        stage.loadBg(2, 8)
        stage.showUnits([
            [
                0,
                34,
                55,
                1],
            [
                1,
                50,
                70],
            [
                8,
                56,
                70],
            [
                15,
                62,
                70],
            [
                2,
                68,
                70],
            [
                20,
                50,
                41,
                2],
            [
                19,
                56,
                41,
                2],
            [
                23,
                62,
                41,
                2],
            [
                24,
                68,
                41,
                2],
            [
                21,
                74,
                41,
                2]])
        stage.draw()
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.info('조조 그 아래 위나라의 모든 장군들,\n관우의 죽음을 애도하려면 상복을 입으세요.\n그리고 애도 기간이 끝나려던 바로 그때......')
        stage.setStageName('서두, 총리 관저')
        stage.unit(19).setAction(6)
        stage.say('&19\n주군, 진심으로 빠른 결정을 내리라고 권합니다,\n오늘은 모든 관리들이 조문하러 왔습니다.\n&0\n결정?\n&19\n실제로 이제 한나라의 권력은 완전히 사라졌다,\n천국은 한나라를 오래전에 버렸다.\n&0\n물론, 그건 알고 있어,\n왕국의 삼자 분할 상황은 실제로 오랜 기간 지속되어 왔습니다.\n&19\n게다가 삼국 중 주군가 가장 강하다,\n토지와 정부 업무는 명확했고, 사람들은 번영하는 삶을 살았다.\n&19\n이 모든 것은 주군 자비와 덕 덕 때문이다......')
        stage.say('&0\n잠깐.\n&0\n사마의, 내가 왕위에 오르라는 말인가?\n&19\n네, 오직 주군만이 왕위에 오르고 황제가 될 수 있는 가장 적합한 사람입니다.')
        stage.unit(19).setAction(0)
        stage.say('...여러분도 그렇게 생각하시나요?')
        stage.unit(21).setAction(6)
        stage.say('&21\n사마의 말씀이 전적으로 맞습니다.')
        stage.unit(21).setAction(0)
        stage.delay(3)
        stage.unit(23).setAction(6)
        stage.say('&23\n오직 주군만이 새로운 황제가 되었다.')
        stage.unit(23).setAction(0)
        stage.delay(3)
        stage.unit(1).setAction(0, 3)
        stage.delay(3)
        stage.unit(1).setAction(3)
        stage.say('&1\n맹덕, 나도 그렇게 생각해.')
        stage.unit(1).setAction(0)
        stage.delay(3)
        stage.unit(8).setAction(0, 3)
        stage.say('&8\n아버지, 꼭 왕위에 오르시길 바랍니다.\n&0\n저도 방금 말했어요.\n이제 왕국은 세 부분으로 나뉘었다,\n왕위 계승 문제를 논의하기에는 아직 이르다.')
        stage.unit(19).setAction(6)
        stage.say('&19\n이제 왕국은 실제로 세 부분으로 나뉘어 있습니다,\n하지만 조만간 그는 세상을 통일할 later주군다.\n&19\n가까운 시일 내에 반드시 그렇게 될 것입니다.')
        stage.unit(19).setAction(0)
        stage.say('&0\n사마의, 천체 현상이 정말 그렇게 명확한가요?')
        stage.unit(19).setAction(6)
        stage.say('&19\n네, 주군.\n곧 왕위에 오르고 스스로 황제로 선포하길 결심해 주십시오!')
        stage.unit(19).setAction(0)
        stage.say('&0\n흠......')
        stage.effectSound(202, 255)
        stage.bgSound(11)
        stage.delay(3)
        sel = stage.choice('그리고 왕위에 오르고 스스로 황제로 선포했다\n그리고 왕위에 오르지 못했다', 0)
        if sel == 1:
            stage.addAmbition(20)
            vars[313] = 1
            stage.bgSound(-1)
            stage.effectSound(202, 0)
            stage.delay(3)
            stage.unit(0).setAction(3)
            stage.say('&0\n좋아.\n왕국이 통일될 때,\n내가 왕위에 올라 천황이 되겠다.')
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(19).setAction(6)
            stage.say('&19\n아, 드디어 결심했구나.')
            stage.unit(19).setAction(0)
            stage.say('&0\n세상은 단 하루라도 통치자 없이 있을 수 없다,\n왕국을 통일하기 위해,\n어쩔 수 없이 그렇게 할 수밖에 없었어요.\n&8\n아버지께 축하드립니다!\n&0\n조비, 오해하지 마세요,\n세상을 하나로 묶는 순간을 말하는 거야.')
            stage.unit(0).setAction(17)
            stage.say('&0\n이 발언은 모두에게 분명히 하기 위한 것입니다,\n지금 우리의 생각은 오직 싸움뿐이야.')
        elif sel == 2:
            stage.addAmbition(-20)
            vars[313] = 0
            stage.bgSound(-1)
            stage.effectSound(202, 0)
            stage.delay(3)
            stage.say('&0\n나는 왕위에 오르거나 천황이 될 생각이 없다.')
            stage.unit(19).setAction(6)
            stage.say('&19\n왜!?')
            stage.unit(19).setAction(0)
            stage.say('&0\n나는 무력으로 왕국을 통일했다,\n지혜로 세상을 다스리며,\n황제가 된다는 것은 오히려 자신의 짐만 더할 뿐이다.')
            stage.unit(0).setAction(0, 3)
            stage.say('&0\n나는 단지 패권적 사업을 세우려 할 뿐이다,\n왕좌는 나에게 중복이다.')
            stage.unit(20).setAction(6)
            stage.say('&20\n하지만 주군, 세상은 통치 없이 하루도 지낼 수 없고,\n주군가 왕위에 오르지 않는다면......')
            stage.unit(20).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(0, 1)
            stage.say('&0\n천자의 아들이 없어도 세상을 다스릴 수 있다.\n그러니까 내가 천황이 되지 않는 게 낫겠어.')
            stage.unit(19).setAction(6)
            stage.say('&19\n주군 천자의 아들을 어떻게 보았나요?')
            stage.unit(19).setAction(0)
            stage.say('&0\n천자는 사람이면서도 사람이 아니다.\n결국 천자라 불리는 존재일 뿐이지.\n&0\n내가 천자가 되면 나 자신을 잃게 될 것이다.\n너희는 이 조맹덕에게 인간이기를 포기하라는 것이냐?')
            stage.unit(0).setAction(3)
            stage.say('&0\n이 세상은 인간의 것이고,\n비인간 인간들이 여전히 통치할 수 있을까요?')
            stage.unit(0).setAction(0)
            stage.say('&0\n원양, 황제가 되고 싶니?\n폐하께 불러 드리겠습니다, 알겠죠?')
            stage.unit(1).setAction(2)
            stage.say('&1\n맹덕!')
            stage.unit(1).setAction(0)
            stage.delay(3)
            stage.unit(0).setAction(3)
            model.setFace(3)
            stage.say('하하하.\n나의 말은 여기까지입니다.\n나는 쉬어야 합니다.')
            model.setFace(0)
            stage.unit(0).setAction(0)
            stage.delay(3)
            stage.unit(0).move(95, 55, 1)
            stage.unit(0).hide()
            stage.unit(1).setAction(0, 0)
            stage.unit(8).setAction(0, 0)
            stage.delay(3)
            stage.unit(21).setAction(0, 1)
            stage.say('&21\n주군 도대체 어떤 사람일까요......\n결국 왕좌는 주군......에게 무의미하다는 것이 드러났다')
            stage.unit(20).setAction(0, 1)
            stage.say('&20\n황제로 선포주군 조언하며 조언하며,\n분명히 그가 야망을 포기하도록 설득하는 방법이었을 것이다.')
        stage.effectSound(202, 255)
        stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            32,
            32,
            54,
            1],
        [
            35,
            52,
            41,
            2],
        [
            34,
            58,
            70],
        [
            33,
            52,
            70]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('이 시기에 슈 왕국은 ......', 3)
    stage.setStageName('청두 유비 거주지')
    stage.delay(3)
    stage.unit(33).setAction(0, 3)
    stage.delay(3)
    stage.unit(33).setAction(3)
    stage.say('&33\n에, 에!?\n그럼 둘째 형을 복수할 수 있다는 거야?')
    stage.unit(33).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(17)
    stage.say('&32\n음, 복수하기 위해 동우를 공격하기로 결심했관우!\n삼형님, 당신이 선봉이 될 것입니다.')
    stage.unit(32).setAction(0)
    stage.delay(3)
    stage.unit(33).setAction(3)
    stage.say('&33\n좋아! 바로 준비할게.\n손권You 파란 눈의 도둑이야!"\n네 목을 꼭 잘라버릴 거야!')
    stage.unit(33).setAction(0)
    stage.delay(3)
    stage.unit(33).move(52, 74, 2)
    stage.unit(33).move(98, 74, 1)
    stage.unit(33).hide()
    stage.unit(34).setAction(0, 3)
    stage.delay(3)
    stage.unit(34).setAction(6)
    stage.say('&34\n주군, 동우를 공격하지 마십시오.\n지금은 대규모 전쟁을 시작할 때가 아니다.')
    stage.unit(34).setAction(0)
    stage.say('&32\n조운......')
    stage.unit(34).setAction(6)
    stage.say('&34\n싸울 거면 위나라를 공격해야 해!')
    stage.unit(34).setAction(0)
    stage.say('&32\n말 그만해, 쯔롱.\n마음이 정해졌어!')
    stage.unit(35).setAction(6)
    stage.say('&35\n주군......')
    stage.say('&32\n공명, 너도 반대해?\n&35\n네.\n주군, 쯔롱 말이 맞았다,\n지금은 동우를 공격할 때가 아닙니다.')
    stage.unit(35).setAction(0)
    stage.say('&32\n알아.\n웨이는 항상 한중을 호랑이처럼 바라보았다,\n지금 동오를 공격하는 것은 정말 절박한 전략이었다.')
    stage.say('&32\n하지만...... 어쩔 수 없이 이걸 할 수밖에 없었어!')
    stage.unit(32).setAction(2)
    stage.say('&32\n황번의 난 진압 시기 이후로,\n나와 함께 싸웠던 의형제가 이제 죽었어,\n동우와 나 사이의 증오는 정말 화해할 수 없어!')
    stage.unit(35).setAction(6)
    stage.say('&35\n주군 그렇게 말씀하셨으니,\n공명도 그를 막을 수 없었다.')
    stage.unit(35).setAction(0)
    stage.delay(3)
    stage.unit(32).setAction(0)
    stage.say('&32\n공명, 청두에 머물러,\n위를 경계해 줘.')
    stage.unit(35).setAction(6)
    stage.say('&35\n......')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene4():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 333, 96)
    stage.showHead(76, 499, 203)
    stage.showHead(32, 5, 172)
    stage.bottomTxt('유비', False, False, False)
    stage.delay(5)
    stage.showHead(33, 69, 172)
    stage.delay(5)
    stage.bottomTxt('그리고 장비', True, False, False)
    stage.delay(5)
    stage.bottomTxt('관우에 대한 복수를 위해 동우에 대한 원정 준비가 이루어졌다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('하지만 출발 전야에,', True, True, False)
    stage.delay(8)
    stage.bottomTxt('장비', True, False, False)
    stage.delay(6)
    stage.showHead(299, 133, 212)
    stage.delay(5)
    stage.bottomTxt('잠든 사이, 부하들이 그의 목을 잘랐다,', True, False, False)
    stage.delay(8)
    stage.head(33).hide()
    stage.delay(5)
    stage.bottomTxt('그는 출발하기도 전에 죽었다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('배신자들은 장비의 머리를 선물로 바쳤다', True, True, False)
    stage.delay(5)
    stage.head(299).move(435, 203)
    stage.delay(5)
    stage.head(299).hide()
    stage.delay(5)
    stage.bottomTxt('그는 동우로 도망쳤다.', True, False, True)
    stage.bottomTxt('관우와 장비의 복수를 위해,', False, True, False)
    stage.delay(8)
    stage.head(32).move(135, 201)
    stage.bottomTxt('유비 직접 대군을 이끌고 동오를 계속 공격했다.', True, False, False)
    stage.head(32).move(249, 211)
    stage.delay(5)
    stage.bottomTxt('곧 그들은 징저우에 다가갔다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('손권', True, True, False)
    stage.delay(5)
    stage.showHead(81, 435, 203)
    stage.delay(5)
    stage.bottomTxt('육손 대사령관으로 임명되었다', True, False, False)
    stage.delay(5)
    stage.head(81).move(313, 211)
    stage.delay(5)
    stage.bottomTxt('슈 군대와 교전하기 위해서였다.', True, False, True)
    stage.bottomTxt('이릉에서 육손 화염 공격을 감행해 슈군에 결정적인 패배를 안겼다.', False, True, False)
    stage.delay(8)
    stage.head(32).move(161, 215)
    stage.head(81).move(435, 203)
    stage.head(81).hide()
    stage.delay(5)
    stage.bottomTxt('패배한 슈 군대는 백디 성으로 후퇴했다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('그 후 유비의 상태는 악화되기 시작했다.', True, True, False)
    stage.delay(8)
    stage.bottomTxt('유비 결국, 실망 속에서,', True, False, False)
    stage.delay(5)
    stage.head(32).hide()
    stage.delay(5)
    stage.bottomTxt('그는 세상을 떠났다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('슈는 유비의 아들에 의해 만들어졌다', True, True, False)
    stage.delay(5)
    stage.showHead(67, 26, 173)
    stage.delay(5)
    stage.bottomTxt('류산은 위대한 사업을 물려받았다,', True, False, False)
    stage.delay(8)
    stage.showHead(35, 90, 173)
    stage.delay(5)
    stage.bottomTxt('제갈량', True, False, False)
    stage.delay(5)
    stage.bottomTxt('그는 마지막 황제 유산을 돕는 데 전념했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            50,
            70],
        [
            8,
            56,
            70],
        [
            15,
            62,
            70],
        [
            2,
            68,
            70],
        [
            20,
            50,
            41,
            2],
        [
            19,
            56,
            41,
            2],
        [
            23,
            62,
            41,
            2],
        [
            24,
            68,
            41,
            2],
        [
            21,
            74,
            41,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n정말...?\n유비 죽었어......?')
    stage.unit(19).setAction(6)
    stage.say('&19\n네.')
    stage.unit(19).setAction(0)
    stage.say('&0\n충성심에서 군대를 보내는 것은 정말 어리석은 일이다,\n하지만 바로 이 때문에 이 사람이 어려운 시기에도 굳건히 버틸 수 있었다,\n바로 자비와 덕이 이것에 의존하고 있었다.\n&0\n이게 운명일까?\n유비......')
    stage.unit(1).setAction(0, 3)
    stage.say('&1\n그러나 맹덕보다 더 이상 하지 않는다,\n지금이 슈를 공격할 좋은 기회다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.\n서는 전투에서 패배하며 국력을 모두 소진시켰다.\n유비를 잃은 것은 상황을 더 악화시켰다.')
    stage.unit(21).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n실제로 그렇습니다.\n지금이 한중을 되찾을 때다,\n슈를 파괴할 좋은 기회였다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n흠.\n좋아, 출발 준비해.\n한중을 공격했다.')
    stage.unit(0).setAction(0)
    stage.say('(유비야 유비여…… 내가 이 두 손으로 네 고향을 무너뜨릴 것이다. 너가 세운 촉국을 전력을 다해 멸망시키겠다!)')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            67,
            32,
            54,
            1],
        [
            35,
            50,
            41,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.info('반면에, 슈는 ......', 3)
    stage.setStageName('청두 유산 저택')
    stage.say('&67\n공명, 이게 우리나라의 생존에 관한 일이라는 말인가요?\n동오와 힘을 합쳐야 합니까......?')
    stage.unit(35).setAction(6)
    stage.say('&35\n그래, 다른 선택지는 없어,\n과거의 증오는 사라졌다,\n서와 동오를 평화롭게 하라.')
    stage.unit(35).setAction(0)
    stage.say('&67\n하지만 동오와 위나라는 동맹입니다.\n우리와 동맹을 맺어 줄까요……?\n&35\n위와 오의 동맹은 오래가지 못한다.\n&35\n지금 위나라가 이토록 강성하니,\n동오 한 나라의 힘만으로는 이길 수 없다.\n게다가 오와 촉의 다툼은 위나라만 이롭게 할 뿐이다.\n&35\n이대로라면 천하는 반드시 조위의 차지가 될 것이다.\n그러므로 오와 촉이 다시 우호를 맺어야만\n위나라에 멸망하는 것을 막을 수 있다.')
    stage.unit(35).setAction(11)
    stage.say('&35\n동오도 이 점을 잘 알고 있을 것이다.')
    stage.unit(35).setAction(0)
    stage.say('&67\n흠...... 알겠어.\n이 문제는 전적으로 당신에게 맡기겠습니다.')
    stage.unit(35).setAction(6)
    stage.say('&35\n주군 수락해 주셔서 감사합니다.')
    stage.unit(35).setAction(0)
    stage.showUnit(183, 90, 54, 3)
    stage.say('&183\n신고됐어.')
    stage.say('&183\n주군, 위는 한중으로 진격했다.\n&67\n응?\n위나라가 한중을 공격했다......\n&35\n역시나, 그 소리가 나왔다.\n조조 타이밍을 완벽하게 익혔어요.\n&67\n그렇다면 위나라의 군사력은 어떨까요......\n&183\n군사력은 상당히 강력했다.\n&67\n콩 ...... 콩 ......공명,\n그-이제 어떻게 해야 하지......')
    stage.unit(35).setAction(6)
    stage.say('&35\n주군 안심하세요.\n웨이의 공격은 이미 내 예상 안이었다.')
    stage.unit(35).setAction(0)
    stage.say('&35\n한중을 공격하려면 양평관을 통과해야 합니다,\n정예 부대를 이용해 그곳에서 적군을 차단할 거야.\n&67\n아니, 괜찮지......?')
    stage.unit(35).setAction(6)
    stage.say('&35\n네.\n하지만 이렇게 하면,\n우리는 동오와 빨리 평화를 맺어야 한다.')
    stage.unit(35).setAction(0)
    stage.say('&35\n그는 즉시 사절을 동우로 보냈다.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene6():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 334, 98)
    stage.showHead(67, 23, 170)
    stage.bottomTxt('조의 군대', False, False, False)
    stage.delay(5)
    stage.head(0).move(143, 59)
    stage.delay(5)
    stage.bottomTxt('그들은 양평관까지 싸웠고,', True, False, False)
    stage.delay(8)
    stage.head(67).hide()
    stage.delay(5)
    stage.showHead(35, 23, 170)
    stage.delay(5)
    stage.bottomTxt('제갈량 쑤 군대를 이끌었다', True, True, False)
    stage.delay(5)
    stage.head(35).move(79, 87)
    stage.delay(5)
    stage.bottomTxt('그리고 그들과 전투를 벌였다.', True, False, True)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            4,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            24,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('양평관 앞, 조조군의 본진지입니다')
    stage.say('&0\n순유, 슈 군대에서 무슨 일이 벌어지고 있나?')
    stage.unit(24).setAction(0, 2)
    stage.delay(3)
    stage.unit(24).setAction(6)
    stage.say('&24\n네.\n방금 정찰병들로부터 보고를 받았어요,\n쑤군은 현재 양평관에 집결 중이었다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n공명 뭔가 속임수를 준비했나 봐.')
    stage.unit(19).setAction(0)
    stage.say('&0\n흠.\n최선의 경우, 양평관을 점령하지 못한다면,\n한중에는 들어갈 수 없을 것이다.')
    stage.unit(0).setAction(17)
    stage.say('여러분, 방심해서는 안 됩니다!')
    stage.unit(0).setAction(0)
    stage.unit(19).setAction(0, 3)
    stage.unit(24).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15, [
        19,
        15])
    gvars[4076] = 0
    gvars[4057] = 39
    stage.setBattlePos([
        [
            1,
            4],
        [
            1,
            5],
        [
            2,
            5],
        [
            2,
            4],
        [
            2,
            6],
        [
            3,
            5],
        [
            1,
            6],
        [
            3,
            4],
        [
            0,
            7],
        [
            4,
            3],
        [
            0,
            6],
        [
            3,
            3],
        [
            0,
            5],
        [
            2,
            3],
        [
            1,
            3]])
    return False


def scene7():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n전장의 동쪽과 남쪽 양쪽에 전략적 고개가 있었다.\n동쪽의 양평관은 한중으로 접근할 수 있는 접근로를 제공합니다.\n&0\n흠.\n무슨 일이 있어도 양평관을 뚫어야 했다.')
    if stage.unitClickTest(15):
        stage.say('&15\n주변이 모두 산인가요?\n드디어 얼굴을 보여드렸네요!\n&0\n흠.\n결정은 당신에게 달렸어요, 허저.\n&15\n네!')
    if stage.unitClickTest(19):
        stage.say('&19\n이 전투는 삼자 대치에서 결정적인 돌파구였다.')
    if stage.unitClickTest(24):
        stage.say('&24\n혼란스러운 전투가 반드시 일어날 것이므로 준비를 철저히 해야 합니다.')
    if stage.unitClickTest(1):
        stage.say('&1\n양평관은 꽤 넓어 보인다.\n하지만 검문소가 아무리 커도,\n그들은 온 힘을 다해 공격할 수밖에 없었다.')
    if stage.unitClickTest(4):
        stage.say('&4\n아버지, 제발 제가 싸우러 나가게 해 주세요.\n반드시 큰 공을 이루겠습니다.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
