# Source Generated with Decompyle++
# File: S_01.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(2,11)',
        '(2,8)'])
    stage.nearEvent([
        3,
        134])
    stage.nearEvent([
        134,
        1025], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createFriend([
        {
            'id': 3,
            'x': 18,
            'y': 13,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 99,
            'x': 9,
            'y': 9,
            'dir': 3,
            'lv': 4,
            'i': 1 },
        {
            'id': 98,
            'x': 8,
            'y': 9,
            'dir': 3,
            'lv': 4,
            'i': 2 },
        {
            'id': 91,
            'x': 9,
            'y': 10,
            'dir': 3,
            'lv': 4,
            'i': 3 },
        {
            'id': 217,
            'x': 8,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'i': 4 },
        {
            'id': 218,
            'x': 9,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'i': 5 },
        {
            'id': 219,
            'x': 9,
            'y': 11,
            'dir': 3,
            'lv': 0,
            'i': 6 },
        {
            'id': 101,
            'x': 19,
            'y': 6,
            'dir': 3,
            'lv': 6,
            'i': 7 },
        {
            'id': 220,
            'x': 18,
            'y': 5,
            'dir': 3,
            'lv': 0,
            'i': 8 },
        {
            'id': 221,
            'x': 18,
            'y': 6,
            'dir': 3,
            'lv': 0,
            'i': 9 }])
    stage.createEnemy([
        {
            'id': 134,
            'x': 5,
            'y': 9,
            'dir': 1,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 135,
            'x': 2,
            'y': 8,
            'dir': 1,
            'lv': 4,
            'i': 1 },
        {
            'id': 131,
            'hide': 1,
            'x': 10,
            'y': 5,
            'lv': 4,
            'ai': 1,
            'i': 2 },
        {
            'id': 129,
            'hide': 1,
            'x': 10,
            'y': 14,
            'dir': 0,
            'lv': 4,
            'ai': 1,
            'i': 3 },
        {
            'id': 258,
            'x': 5,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 259,
            'x': 5,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 260,
            'x': 5,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 210,
            'hide': 1,
            'x': 9,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 211,
            'hide': 1,
            'x': 11,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 212,
            'hide': 1,
            'x': 9,
            'y': 14,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 213,
            'hide': 1,
            'x': 11,
            'y': 14,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 214,
            'x': 4,
            'y': 9,
            'dir': 1,
            'lv': 0,
            'i': 11 },
        {
            'id': 215,
            'x': 4,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'i': 12 },
        {
            'id': 216,
            'x': 2,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 13 },
        {
            'id': 234,
            'x': 3,
            'y': 8,
            'dir': 1,
            'lv': 0,
            'i': 14 },
        {
            'id': 235,
            'x': 3,
            'y': 9,
            'dir': 1,
            'lv': 0,
            'i': 15 },
        {
            'id': 236,
            'x': 3,
            'y': 10,
            'dir': 1,
            'lv': 0,
            'i': 16 },
        {
            'id': 237,
            'x': 3,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 17 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 19,
            'y': 9,
            'dir': 3 },
        {
            'idx': 1,
            'x': 18,
            'y': 8,
            'dir': 3 },
        {
            'idx': 2,
            'x': 18,
            'y': 11,
            'dir': 3 },
        {
            'idx': 3,
            'x': 18,
            'y': 9,
            'dir': 3 },
        {
            'idx': 4,
            'x': 18,
            'y': 10,
            'dir': 3 },
        {
            'idx': 5,
            'x': 19,
            'y': 8,
            'dir': 3 },
        {
            'idx': 6,
            'x': 19,
            'y': 11,
            'dir': 3 },
        {
            'idx': 7,
            'dir': 1 },
        {
            'idx': 8,
            'dir': 1 },
        {
            'idx': 9,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(99, 35, 0, -1, 0, -1)
    stage.setEnemyEquip(101, -1, 0, -1, 0, 4)
    stage.setEnemyEquip(134, -1, 0, -1, 0, 20)
    stage.setEnemyEquip(98, -1, 0, -1, 0, 13)
    stage.loadBg(1)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.setUnitStatus([
        {
            'hp': -50,
            'x1': 7,
            'y1': 7,
            'x2': 10,
            'y2': 12,
            'camp': 1 }])
    stage.draw()
    stage.bgSound(1)
    stage.say('&101\n이제 그들은 동탁가 지키고 있는 시수이 고개를 공격하려 하고 있다,\n모두가 한 번에 앞으로 나아가 뤄양을 향해 곧장 향했다.')
    stage.unit(1).setDir(stage.countDir(1, 0))
    stage.say('&1\n맹덕, 왜 감독직을 원소 대신 내줬어!\n연합군 지도자가 된다는 게 멋지지 않나요?\n&0\n그때서야 원소 동맹군에 자원을 기꺼이 제공할 것이다,\n이 기회를 빌려 좋은 싸움을 벌이자,\n그래야만 다른 사람들이 우리에게 더 높은 평가를 줄 것입니다.\n&1\n그러니까 모든 문제를 원소한테 떠넘기는 거야?\n정말 과소평가할 수 없어.\n&0\n어쨌든, 이 전투에서 그들이 성과를 내지 못한다면,\n그러면 모든 것이 무의미해집니다.\n네가 결정해, 원양.\n&1\n지켜봐.\n내 하후돈로 조의 군대는 완벽해!\n하하하.')
    stage.unit(1).setDir(3)
    stage.say('&99\n군 식량은 아직 도착하지 않았나요?')
    stage.unit(98).setDir(stage.countDir(98, 99))
    stage.say('&98\n네.\n군수품 담당 사람이 곡물 배달을 중단했다는 소문을 들었습니다.\n&99\n알고 보니 우리는 눈앞의 적뿐만 아니라 더 많은 것을 마주해야 합니다.\n이 동맹은 오래 가지 못할 것 같아,\n우리는 탈출 계획을 세워야 해.')
    stage.unit(98).setDir(3)
    stage.bgSound(2)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    vars[501] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 1:
        stage.unit(98).setDir(stage.countDir(98, 99))
        stage.say('&98\n주군 병사들은 더 이상 싸울 수 없었다,\n우리는 후퇴해야 해.\n&99\n침착함을 잃지 마!\n앞에 큰 적이 있다는 것을 잊지 마라,\n한 번의 실수로 치명적이다.\n&91\n주군, 황가이는 온 것을 후회하지 않았다,\n그냥 우리가 적에게 지지 않았을 뿐이야,\n하지만 그들은 자기 .......에게 졌다')
        stage.unit(98).setDir(3)
        stage.say('&135\n어떻게? 적군 선봉대가 천천히 움직인다,\n이것은 우리가 기여할 수 있는 좋은 기회입니다.')
        stage.unit(210).show()
        stage.unit(211).show()
        stage.unit(131).show()
        stage.say('&131\n나는 오늘이 길일일 거라고 이미 계산했어,\n우리는 이 싸움에서 반드시 이길 것입니다.')
        stage.unit(212).show()
        stage.unit(213).show()
        stage.unit(129).show()
        stage.say('&129\n적은 충분히 먹지 못한 듯 전혀 상대가 되지 못했다.\n&129\n식량이 부족한 적들을 몰아내며,\n정말 아무런 노력도 하지 않아요!\n하하하!')
        stage.say('&98\n주군 적이 갑자기 공격을 시작했어!\n&99\n당황하지 말고 서둘러 싸워라,\n혼란에 뛰어들면 적의 손에 딱 맞는 거야!')
        stage.unit(101).setAction(10)
        stage.say('&101\n뭐, 기습 공격이라고!?\n조조, 당장 손견 구하러 가!\n선봉대가 전멸하면 군대 전체의 사기에 영향을 미칩니다.')
        stage.startOper()
        vars[11] = 1
    if not vars[12] and stage.round() == 2:
        stage.unit(99).setAI(1)
        stage.unit(98).setAI(1)
        stage.unit(91).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(218).setAI(1)
        stage.unit(219).setAI(1)
        vars[12] = 1
    if not vars[20] and stage.isInPos(1025, 2, 11):
        stage.getItem(155, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 2, 8):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[30] and stage.isInRect(1026, 15, 0, 19, 19):
        stage.say('&101\n젠장! 적이 진영 바로 앞에서 싸웠다니...\n정말 화가 납니다.......')
        stage.unit(220).setAI(1)
        stage.unit(221).setAI(1)
        vars[30] = 1
    if not vars[31] and stage.isInRect(1025, 0, 0, 4, 19):
        stage.unit(135).setAction(8)
        stage.unit(135).setAction(7)
        stage.say('&135\n이곳이 함락되면, 동탁 총리가 그를 처형할 것이다!\n죽을 각오를 가지고 싸워야 해!')
        stage.unit(135).setAction(0)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        vars[31] = 1
    if vars[51] and vars[52] and vars[53] and not vars[6] and not vars[55] and stage.totalUnit(0) < 6 and stage.totalUnit(2) < 9:
        stage.say('적군이 이미 절반 이상 소멸했어... 하지만 우리 손실도 적지 않은데, 철수해야 할까?')
        sel = stage.choice('후퇴\n계속 싸워', -1)
        if sel == 1:
            stage.resumeCtrl()
            stage.unit(0).setDir(stage.countDir(0, 101))
            stage.say('&0\n위안 장군, 적을 상대하기 어렵습니다,\n계속 싸우면 아군 손실만 늘릴 뿐이다,\n철회 명령을 내리세요.\n&101\n그래, 알겠어, 군대 전체가 후퇴해,\n이렇게 싸우는 것도 이미 꽤 괜찮아,\n모두 빨리 후퇴해!')
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[601] = 1
            return True
        if sel == 2:
            stage.say('&0\n지금은 후퇴할 때가 아니야, 남은 적을 밀어낼 때가 아니야,\n연합군이 얼마나 강력한지 알리세요.')
        vars[6] = 1
    if not vars[40] and stage.isNear(3, 134, False):
        stage.unit(3).setDir(stage.countDir(3, 134))
        stage.unit(134).setDir(stage.countDir(134, 3))
        stage.say('&3\n나는 둘째 동생을 유비관우관운장,\n만나게 해줘.\n&134\n흥, 아무도 아니야!')
        fight = stage.startFight(3, 134, 5)
        fight.showUnit(True, '관우관운장,\n화웅, 네 목을 가져가러 왔어.', 9)
        fight.showUnit(False, '어떻게 그저 반란군이 이렇게 무모하게 행동할 수 있단 말인가,\n후회하지 마세요!', 8)
        fight.showStart()
        fight.setAction(True, 0)
        fight.say(True, '어서!', True)
        fight.setAction(False, 6)
        fight.say(False, '흥! 용기 있으면 말 타고 나한테 덤벼.', False)
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        stage.delay(20)
        fight.say(False, '젠장... 와!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 1)
        fight.setAction(True, 6)
        fight.say(True, '관우관운장 적을 죽였general화웅!', True)
        fight.end()
        stage.unit(134).hide(2)
        stage.getItem(127, 0, True, 3)
        stage.unit(135).setAction(8)
        stage.say('&135\n아, 화웅 장군이 패배했다!')
        stage.unit(3).setAI(1)
        vars[40] = 1
    if not vars[41] and stage.isNear(134, 1025, True):
        stage.say('&134\n나는 화웅다! 동재상에 반대하는 반군,\n먼저 화웅 처리할게.\n&134\n연합군 중에는 죽음을 두려워하지 않는 자들이 있다,\n내 화웅 강철검을 써봐! 하하하.')
        if not vars[55]:
            stage.unit(101).setAction(10)
            stage.say('&101\n그럼 화웅 동탁 장군이 강인한 거군이라니!?\n아군Who 감히 그에게 도전할 수 있을까?')
            if not vars[54]:
                stage.unit(3).setDir(stage.countDir(3, 101))
                stage.unit(0).setDir(stage.countDir(0, 101))
                stage.unit(101).setDir(stage.countDir(101, 3))
                stage.say('&3\n나는 유비의 subordinate관우관운장\n전선으로 보내 주세요.\n&101\n어떻게 그렇게 의로운 병사들을 전투에 보내는 것이 합리적일 수 있단 말인가?\n이는 연합군의 명성에 관한 문제입니다.\n한 발 물러나는 게 좋겠어.\n&3\n그런 말들은 나에게 무시할 수 없다,\n우리 모두 동탁을 정복하려 하니,\n군사 조직이 정규군이든 아니든 무슨 상관이야?')
                stage.unit(0).setDir(stage.countDir(0, 3))
                stage.say('관 장군님, 진정하십시오.')
                stage.unit(0).setDir(stage.countDir(0, 101))
                stage.say('&0\n위안 장군, 이 일에 대해 어떻게 생각하십니까?\n&0\n자원병을 보내면 화웅를 물리칠 수 있다면,\n적군 사기 추락할 것이다,\n그게 더 흥미롭지 않나요?\n&101\n알겠습니다, 어느 정도 이해가 됩니다.\n좋아요, 관 장군님, 제가 말씀을 잘못 했습니다.\n너를 1대1로 결투화웅 보내줄게.')
                stage.unit(0).setDir(stage.countDir(0, 3))
                stage.say('관 장군님, 저 조모도 한 잔 올리겠습니다. (음, 이 사람은 양쪽 모두를 달래는 것이 꽤 만만치 않군. 내가 관우와 함께 있어 주지.) 이 술은 제가 먼저 감사드립니다... 꿀꺽. 저는 술이 따뜻할 때 화웅을 베어버릴 겁니다. 이 사람은 정말 호방하고 말이 빠르군요... (내가 먼저 화웅을 베어야겠어. 에헴!)')
                stage.unit(3).setAI(3, 134, 0, 0)
            else:
                stage.unit(0).setDir(stage.countDir(0, 101))
                stage.say('&0\n원소 왜 여기저기 적을 만들었을까요?\n지휘관이 계속 이렇게 지휘하면 군 전체에 영향을 미칠 것입니다.\n원소 더 이상 감독이 될 수 없는 것 같아요......')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(135, 7, 0, 2):
        stage.say('&135\n와! 연합군이 이렇게 강할 줄은 몰랐어,\n그리고 우리가 이렇게 될 줄도 몰랐어요......')
        stage.unit(135).hide(2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(134, 7, 0, 2):
        stage.say('&134\n와우.......')
        stage.unit(134).hide(2)
        stage.getItem(127, 0, True, 1027)
        stage.unit(3).setAI(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(131, 7, 0, 2):
        stage.say("&131\n아, 이거 큰일이야!\n오늘 육각에 나오는 '조'라는 불운한 힌트를 깜빡했네요.")
        stage.unit(131).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(129, 7, 0, 2):
        stage.say('&129\n말도 안 돼! 연합군은 그냥 엉망진창 아닌가?\n젠장, 그들을 과소평가했네......')
        stage.unit(129).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n흠...... 정말 인상적이네요.\n다음으로, 정규군의 성과에 달려 있습니다.\n나, 관이 먼저 떠나겠다!')
        stage.unit(3).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(101, 7, 0, 2):
        stage.say('&101\n젠장, 일단 후퇴하자.\n조조, 후위 문제는 네가 할 일이야.\n본캠프에서 좋은 소식을 기다릴게요.')
        stage.unit(101).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(99, 7, 0, 2):
        stage.say('&99\n선택의 여지가 없고, 후퇴한다,\n싸움을 계속하면 쓸데없는 희생만 낳을 뿐이었다.')
        stage.unit(99).hide(1)
        vars[701] = 1
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(98, 7, 0, 2):
        stage.say('&98\n기습 공격이 아니었다면......\n아니요, 가장 증오스러운 것은 우리 국민입니다.\n정말 안타깝네요!')
        stage.unit(98).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(91, 7, 0, 2):
        stage.say('&91\n흥! 만약 직접 대면이 나오면...\n동탁 우리 맞지 않을 수도 있어.......')
        stage.unit(91).hide(1)
        vars[58] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        if not vars[56]:
            stage.unit(0).setDir(stage.countDir(0, 99))
            stage.unit(99).setDir(stage.countDir(99, 0))
            stage.say('&99\n이번에는 조조 덕분에 살아남았어,\n선은 정말 고마워해!\n&99\n아군 시수이관에 남아 있던 병사들을 추격하기 위해,\n군수품을 징발할 수 있나?\n&0\n마침내 전투가 끝난 후,\n그는 이렇게 잔인한 .......을 전혀 예상하지 못했다\n&0\n그럼 아군의 군사 보급품 일부를 너에게 할당하겠다."\n&99\n깊이 감사드립니다!\n보답하기 위해 이것을 받아주세요.\n&0\n이게 뭐야!?\n&99\n여기서 작별 인사then아군 해야지. 본캠프에서 다시 만나자.')
            stage.unit(99).hide()
            stage.unit(98).hide()
            stage.unit(91).hide()
            stage.unit(217).hide()
            stage.unit(218).hide()
            stage.unit(219).hide()
            stage.getItem(33, 0)
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[601] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 동탁군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
