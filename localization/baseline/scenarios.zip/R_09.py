# Source Generated with Decompyle++
# File: R_09.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 67)
    stage.showUnits([
        [
            2,
            44,
            98],
        [
            126,
            54,
            98]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setEventName('황제 바치기')
    stage.setStageName('푸양, 교외 산길')
    stage.unitsMove([
        [
            stage.unit(2),
            44,
            86,
            0],
        [
            stage.unit(126),
            54,
            86,
            0]])
    stage.showUnit(119, 49, 98)
    stage.unitsMove([
        [
            stage.unit(2),
            44,
            40,
            0],
        [
            stage.unit(126),
            54,
            40,
            0],
        [
            stage.unit(119),
            49,
            52,
            0]])
    stage.delay(3)
    stage.unit(119).setAction(0, 2)
    stage.delay(3)
    stage.unit(119).setAction(2, 2)
    stage.say('&119\n조만, 늙은 악당아, 이 원한을 반드시 갚아야 해!')
    stage.unit(2).setAction(0, 1)
    stage.unit(126).setAction(0, 3)
    stage.delay(5)
    stage.unit(126).setAction(0, 2)
    stage.say('&126\n주군, 네 기분 이해해,\n하지만 이제는 탈출이 최우선이었다.')
    stage.unit(119).setAction(0, 0)
    stage.say('&119\n그렇다면, 어디로 갈 수 있을까?\n&126\n쉬저우로 가서 유현덕에 합류해.')
    stage.say('&2\n유현덕......?')
    stage.unit(119).setAction(0, 2)
    stage.say('&119\n이 사람을 알아요.........\n하지만 그가 우리를 받아들일까요......?\n&126\n유현덕 충성심을 무엇보다 중요하게 여기며 분명히 우리를 받아들일 거야.')
    stage.unit(119).setAction(0, 0)
    stage.say('&119\n좋아! 네 생각대로 쉬저우로 갈게.\n&126\n네.')
    stage.unit(2).setAction(0, 2)
    stage.say('&2\n네.')
    stage.unitsMove([
        [
            stage.unit(2),
            44,
            4,
            0],
        [
            stage.unit(126),
            54,
            4,
            0],
        [
            stage.unit(119),
            49,
            12,
            0]])
    stage.unit(2).hide()
    stage.unit(126).hide()
    stage.unit(119).move(49, 4, 0)
    stage.unit(119).hide()
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 416, 67)
    stage.showHead(119, 480, 67)
    stage.showHead(32, 459, 152)
    stage.bottomTxt('여포가 조조에게 패배한 후 여러 곳을 도망쳤다,', False, False, False)
    stage.delay(5)
    stage.head(119).move(523, 67)
    stage.head(119).move(523, 152)
    stage.bottomTxt('마지막에는 서주 유비의 휘하로 투항했다.', True, False, True)
    stage.bottomTxt('이 시점에서,', False, True, False)
    stage.delay(5)
    stage.showHead(131, 220, 82)
    stage.bottomTxt('이각와 곽사는 권력과 이익을 두고 경쟁했다,', True, True, False)
    stage.showHead(129, 156, 82)
    stage.bottomTxt('마침내 무력 충돌이 발발했다.', True, False, False)
    stage.delay(5)
    stage.bottomTxt('장안은 다시 전쟁의 불길에 휩싸였다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 15)
    stage.showUnits([
        [
            149,
            27,
            55,
            1],
        [
            23,
            46,
            55,
            3,
            6],
        [
            192,
            46,
            43,
            2],
        [
            193,
            52,
            43,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('장안궁')
    stage.say('&149\n뭐라고? 날 도망치게 해주고 싶다고 했잖아!?\n&23\n네.')
    stage.unit(192).setAction(3)
    stage.say('&192\n뭐라고!')
    stage.unit(192).setAction(0)
    stage.delay(5)
    stage.unit(23).setAction(0)
    stage.say('&23\n…… 폐하, 서둘러 주십시오.\n&149\n하지만 자아이칭, 당신은 이각군의 전략가입니다,\n왜 ......?')
    stage.unit(23).setAction(6)
    stage.say('&23\n좋은 새는 앉을 나무를 선택한다; 이각 나무는 내 주군가 될 자격이 없다.')
    stage.unit(149).setAction(0, 3)
    stage.say('&149\n알겠어...... 자아이칭, 고마워.')
    stage.unit(149).setAction(0, 1)
    stage.say('&149\n빨리 가서 신하들에게 알리고 즉시 장안을 떠나라,\n…… 나는 반드시 낙양으로 돌아가야 한다.\n&192\n네.\n&193\n네.')
    stage.unitsMove([
        [
            stage.unit(193),
            91,
            43,
            1],
        [
            stage.unit(192),
            85,
            43,
            1]])
    stage.unit(193).hide()
    stage.unit(192).hide()
    stage.say('&149\n가후 경, 앞으로 어찌할 생각인가?\n&23\n완성의 장수에게 몸을 의탁할까 합니다.\n&149\n장수?\n&23\n세상을 떠난 장제 장군의 조카입니다.\n&149\n가후 경, 짐을 위해 일할 생각은 없는가?\n그대야말로 진정한 충신이니,\n높은 벼슬과 후한 녹봉을 내리겠다.')
    stage.unit(23).setAction(0)
    stage.say('&23\n…… 용서해 주세요, 저는 따르기 어렵습니다.\n&149\n나한테 안 해주겠다는 거야?\n&23\n폐하\n제 재능을 최대한 활용할 수 있는 분들을 섬기고 싶습니다.')
    stage.unit(23).setAction(6)
    stage.say('&23\n솔직히 말씀드려 죄송합니다, 폐하께서는 아직 힘이 부족하십니다.\n&149\n…………….\n&149\n그를 섬기는 게 장수 가치가 있나?\n&23\n폐하, 제 일은 걱정하지 마십시오,\n폐하께서는 자신의 안전에 더 집중하시기 바랍니다.')
    stage.showUnits([
        [
            192,
            85,
            43,
            3],
        [
            193,
            91,
            43,
            3]])
    stage.unitsMove([
        [
            stage.unit(192),
            66,
            43,
            3],
        [
            stage.unit(193),
            72,
            43,
            3]])
    stage.unit(192).setAction(0)
    stage.unit(193).setAction(0)
    stage.say('&192\n폐하, 모두가 매우 기뻐하십니다.\n&193\n지금 출발하자, 시간이 없어!\n&149\n흠...... 자 아이칭.\n&23\n폐하, 여행 조심하시길.')
    stage.unit(149).move(27, 48, 0)
    stage.delay(1)
    stage.unit(149).move(66, 48, 1)
    stage.delay(5)
    stage.unit(192).setAction(0, 2)
    stage.unit(193).setAction(0, 2)
    stage.delay(5)
    stage.unitsMove([
        [
            stage.unit(149),
            92,
            48,
            1],
        [
            stage.unit(192),
            85,
            43,
            1],
        [
            stage.unit(193),
            91,
            43,
            1]])
    stage.unit(192).hide()
    stage.unit(193).hide()
    stage.unit(149).hide()
    stage.unit(23).setAction(0, 3)
    stage.delay(3)
    stage.unit(23).setAction(0, 1)
    stage.say('&23\n곧 이각 폐하께서 도망치셨다는 사실을 알게 될 것이다,\n저도 즉시 장안을 떠나야 합니다.')
    stage.effectSound(202, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(0, 9)
    stage.draw()
    stage.info('이각 군대의 장군들 곽사와 곽사 장군들 간의 투쟁에서,\n서황 훌륭한 성과를 보였고, 곽사군에 매우 유리한 상황이 되었다.')
    stage.info('하지만 결정적인 순간에 헌제는 가후\n그를 보내주고 창안성을 떠나라. 이각. 곽사 알게 된 후,\n그들은 즉시 전투를 중단하고 힘을 합쳐 헌제를 추격했다.')
    stage.bgSound(-1)
    return False


def scene2():
    stage.loadBg(2, 59)
    stage.showUnit(192, 49, 95)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('장안 외곽의 산길')
    stage.unit(192).move(49, 85, 0)
    stage.showUnit(149, 49, 95)
    stage.unitsMove([
        [
            stage.unit(192),
            49,
            75,
            0],
        [
            stage.unit(149),
            49,
            85,
            0]])
    stage.showUnits([
        [
            193,
            44,
            95],
        [
            194,
            54,
            95]])
    stage.unitsMove([
        [
            stage.unit(192),
            49,
            30,
            0],
        [
            stage.unit(149),
            49,
            40,
            0],
        [
            stage.unit(193),
            44,
            50,
            0],
        [
            stage.unit(194),
            54,
            50,
            0]])
    stage.unit(149).setAction(0, 0)
    stage.delay(5)
    stage.say('&149\n아, 아, .......')
    stage.unit(192).setAction(0, 2)
    stage.delay(3)
    stage.unit(192).setAction(3, 2)
    stage.say('&192\n아, 폐하!')
    stage.unit(192).setAction(0, 2)
    stage.unit(193).move(44, 40, 0)
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(0, 1)
    stage.say('&193\n너 왜 그래?')
    stage.say('&149\n더 이상 걸을 수 ...... 없어요.\n&193\n하지만 내가 여기 머무르면,\n그들은 이각군과 곽사군에게 붙잡힐 것이다.')
    stage.unit(149).setAction(0, 1)
    stage.say('&149\n난 떠나지 않을 거야, 이각 그들이 날 죽이지 않을 거야,\n나 걱정하지 말고, 목숨 걸고 도망쳐.')
    stage.unit(192).setAction(3, 2)
    stage.say('&192\n그건 ...... 그건 안 돼.')
    stage.unit(192).setAction(0, 2)
    stage.delay(3)
    stage.unit(194).setAction(6)
    stage.say('&194\n폐하, 근처 영주들에게 도움을 청하시는 게 어떻습니까?')
    stage.unit(149).move(54, 40, 1)
    stage.unit(149).setAction(0)
    stage.delay(3)
    stage.unit(149).setAction(0, 2)
    stage.say('&149\n봉건 영주 중에서 진정한 힘을 가진 자는 누구인가?\n그렇다면 이각군과 곽사군과 싸우는 것은 어떨까요?\n&194\n후보가 두 명 있는데, 한 명은 허베이 출신 원소입니다.\n&194\n그는 당시 반동탁 연합군 총사령관이었다.\n&194\n군사력은 이각과 곽사보다 강해야 합니다.\n&149\n다른 사람이 어디...... 있지?\n&194\n여기는 푸양의 조조입니다. 비록 이 사람의 군대가 원소\n짧았지만 부하들은 전략가와 용감한 장군들로 가득했다.\n더욱이 그는 산적을 제거하고 궁정에 큰 공헌을 했다.')
    stage.unit(149).setAction(0, 1)
    stage.say('&149\n원소 그리고 조조......?\n알겠습니다. 구조 요청하러 가세요.\n&194\n그럼 바로 갈게.')
    stage.unit(194).setAction(0, 0)
    stage.delay(3)
    stage.unit(194).move(44, 50, 3)
    stage.delay(3)
    stage.unit(194).setAction(0, 0)
    stage.say('&194\n가자.')
    stage.unit(193).setAction(0, 2)
    stage.say('&193\n네.')
    stage.unitsMove([
        [
            stage.unit(193),
            44,
            4,
            0],
        [
            stage.unit(194),
            44,
            14,
            0]])
    stage.unit(193).hide()
    stage.unit(194).move(44, 4, 0)
    stage.unit(194).hide()
    stage.unit(192).move(49, 40, 1)
    stage.say('&192\n폐하, 낙양으로 가십시오.')
    stage.unit(192).setAction(0, 3)
    stage.say('&192\n내가 도와줄게.')
    stage.unit(149).setAction(0, 3)
    stage.delay(3)
    stage.unit(149).move(51, 40, 3)
    stage.unit(149).setAction(0)
    stage.say('&149\n…… 도움 주셔서 감사합니다.')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            194,
            52,
            31,
            2,
            5],
        [
            101,
            49,
            46],
        [
            106,
            57,
            46]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('며칠 후, .......', 3)
    stage.setStageName('신두 원소 저택')
    stage.say('&194\n…… 황제의 칙령이 도착했다,\n그는 신하들에게 불을 원소고 황제를 보호하기 위해 폐하 곁으로 신속히 달려가라고 명령했다,\n충성심과 청렴성을 보여주기 위해서입니다.\n&101\n네.')
    stage.unit(194).setAction(0)
    stage.say('&194\n제국의 명령을 받아라.\n&101\n정말 무서워요, 용서해 주세요, 받아들일 수 없어요.\n&194\n왜? 어쨌든 이건 황제의 칙령이야!')
    stage.say('&101\n이제 산적들이 신두 근처를 돌아다니고 있다,\n나는 산적들을 쓸어내느라 바쁘다,\n정말 ...... 못 했어요.')
    stage.delay(3)
    stage.unit(106).setAction(6)
    stage.say('&106\n네, 정말 죄송합니다.......')
    stage.say('&194\n하지만 그렇지 않은 것 같아요,\n도시 안팎의 보안이 정말 잘 되어 있는 걸 봤어요.')
    stage.say('&101\n아니, 아직 산적이 많아.')
    stage.say('&106\n대서관님, 정말 죄송합니다.......')
    stage.unit(194).setAction(0, 0)
    stage.say('&194\n음......... 잊어버려!\n폐하께 네가 진심으로 불성실했음을 보고하겠다.\n&101\n정말 무력한 상황입니다.\n&106\n네, .......')
    stage.unit(194).move(45, 31, 3)
    stage.unit(194).setAction(0)
    stage.delay(1)
    stage.unit(194).move(45, 90, 2)
    stage.unit(194).hide()
    stage.delay(3)
    stage.unit(101).setAction(0, 1)
    stage.say('&101\n심배, 이게 괜찮을까......?')
    stage.unit(106).setAction(0, 3)
    stage.say('&106\n알겠어.')
    stage.unit(106).setAction(0, 2)
    stage.say('&106\n어쨌든 주군 현재 법정에서 어떤 보상도 받지 못할 거야,\n그렇다면 왜 헛되이 병력을 낭비하겠습니까?')
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n흠.......')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene4():
    model.initLocalVar()
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 12)
    stage.showUnits([
        [
            193,
            30,
            54,
            1],
        [
            1,
            50,
            41,
            3,
            6],
        [
            16,
            56,
            41,
            3,
            6],
        [
            20,
            50,
            68,
            3,
            6],
        [
            22,
            56,
            68,
            3,
            6],
        [
            21,
            62,
            68,
            3,
            6]])
    if not vars[706]:
        stage.showUnit(18, 62, 41, 3, 6)
    stage.showUnit(0, 50, 54, 3, 6)
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('푸양 조조 저택')
    stage.say('&193\n…… 황제의 칙령이 도착했다,\n신하들에게 불을 조조 명령하고 신속히 폐하 곁으로 가서 황제를 보호하라,\n충성심과 청렴성을 보여주기 위해서입니다.\n조조, 동의해야 하지 않나요?\n&0\n네! 전적으로 폐하의 명령에 따르겠습니다.\n&193\n아, 그럼 즉시 병력을 보낼 수 있나요?\n&0\n네.\n&193\n진정으로 조 공이 될 자격이 있는,\n폐하께서 당신의 충성과 의로움을 아신다면,\n황제께서 분명히 기뻐하실 거야.\n&193\n그럼 즉시 돌아가 폐하께 보고하겠습니다,\n수고하셨습니다, 조 경.')
    stage.unit(193).move(30, 48, 0)
    stage.delay(1)
    stage.unit(193).move(95, 48, 1)
    stage.unit(193).hide()
    stage.unit(0).setAction(0)
    stage.unit(1).setAction(0)
    stage.unit(21).setAction(0)
    stage.unit(20).setAction(0)
    stage.unit(22).setAction(0)
    if not vars[706]:
        stage.unit(18).setAction(0)
    stage.unit(16).setAction(0)
    stage.delay(3)
    stage.unit(0).move(50, 48, 0)
    stage.delay(1)
    stage.unit(0).move(30, 48, 3)
    stage.delay(1)
    stage.unit(0).move(30, 54, 2)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n흥! 너 꽤 덩치 크구나,\n기본적으로, 우리 목숨을 구해달라는 요구일 뿐입니다.\n&0\n원양, 헛소리를 해서는 안 된다.\n오늘날 황제는 세상 앞에서 허세만 부릴 뿐이다.\n&0\n하지만 문약, 우리가 기다려온 날이 드디어 왔어.')
    stage.unit(20).setAction(6, 3)
    stage.say('&20\n그래, 이것은 황제를 맞이하기에 완벽한 기회였다.')
    if vars[706]:
        stage.effectSound(202, 255)
        stage.delay(3)
        stage.bgSound(18)
        stage.delay(3)
        stage.showUnit(18, 95, 54, 3)
        stage.say('&18\n무례하게 죄송합니다.')
        stage.unit(1).setAction(0, 2)
        stage.unit(16).setAction(0, 2)
        stage.unit(20).setAction(0, 0)
        stage.unit(22).setAction(0, 0)
        stage.unit(21).setAction(0, 0)
        stage.unit(18).move(50, 54, 3)
        stage.say('&18\n주군, 방금 허베이에서 정찰을 마치고 돌아왔어.')
        stage.unit(0).setAction(3)
        stage.say('&0\n아, 수고 많으셨어요. 새로운 소식 있나요?')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(18).setAction(6)
        stage.say('&18\n특별한 건 없어...\n하지만 원소와 공손찬 간의 전쟁,\n원소 여전히 우위를 점하고 있다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n음, 정말?')
        stage.say('&18\n더불어 원소 황제를 구하러 가라는 황제 명령을 거부했다.')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n오, 감히 황제의 명령을 거역하다니?!\n&18\n네.\n그는 궁정에서 어떤 보상도 받을 수 없다고 느꼈기 때문이다.')
        stage.unit(0).setAction(3)
        stage.say('하하하, 상으로? 바보 같으니! 이 자식 정말 눈앞에 콩나물밖에 안 보이는군.')
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(22).setAction(0, 3)
        stage.say('&22\n원소 패권을 달성하는 데 필요한 웅장함과 재능이 정말로 부족했다.')
        stage.say('&0\n쯔양, 수고했어,\n아군 이제 나는 천황을 구하러 가야 한다,\n나랑 같이 가야 해.')
        stage.say('&18\n네.')
        model.unitJoin(18, 0, 0)
        if vars[1013]:
            gvars[0] = 18
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
    stage.unit(0).setAction(17)
    stage.say('좋습니다, 출전합니다! 어쨌든 황제를 구해야 합니다!')
    stage.bgSound(-1)
    stage.effectSound(202, 255)
    stage.delay(3)
    stage.bgSound(0)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, -1)
    stage.draw()
    stage.showHead(149, 246, 89)
    stage.delay(5)
    stage.bottomTxt('헌제가 장안에서 도망친 후,', False, False, False)
    stage.delay(5)
    stage.showHead(131, 173, 46)
    stage.delay(5)
    stage.bottomTxt('이각', True, False, False)
    stage.delay(5)
    stage.showHead(129, 173, 126)
    stage.delay(5)
    stage.bottomTxt('그는 곽사했고, 다른 이들은 끈질기게 쫓아갔다.', True, False, False)
    stage.delay(8)
    stage.showHead(101, 403, 7)
    stage.delay(5)
    stage.bottomTxt('허베이 원소의 영웅들은 헌제의 지원 요청을 거절했다.', True, True, False)
    stage.delay(8)
    stage.showHead(0, 445, 91)
    stage.delay(5)
    stage.bottomTxt('조조 황제를 환영할 기회를 잡아,', True, True, False)
    stage.delay(6)
    stage.head(0).move(310, 89)
    stage.delay(5)
    stage.bottomTxt('그리고 현제를 구하러 갔다.', True, False, True)
    return False


def scene5():
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            52,
            1]])
    if not vars[706] and not vars[707]:
        stage.showUnits([
            [
                16,
                38,
                46,
                1],
            [
                15,
                38,
                40,
                1]])
    stage.showUnits([
        [
            20,
            60,
            52,
            3],
        [
            22,
            60,
            46,
            3],
        [
            21,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('장안 근처, 조조군의 본진')
    if vars[706]:
        stage.say('전위, 너는 어쩌려고 그래? 아직 안 왔니?')
        stage.unit(20).setAction(0, 2)
        stage.say('&20\n무슨 일이 있었던 걸까?')
        stage.showUnit(16, 49, 16, 2)
        stage.say('&16\n주군.')
        stage.unit(20).setAction(0, 3)
        stage.unit(16).move(49, 46, 2)
        stage.delay(3)
        model.setFace(2)
        stage.unit(0).setAction(2, 0)
        stage.say('전위, 너 어디 갔다 왔느냐! 군사 회의에 늦었잖아!')
        stage.unit(16).setAction(6, 2)
        stage.say('&16\n...... 미안해.\n나는 매우 숙련된 ...... 건장한 남자를 찾았다.')
        model.setFace(0)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n무술에 매우 능숙한가?')
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n네.')
        stage.unit(16).setAction(0, 0)
        stage.say('&16\n이봐! 들어와!')
        stage.bgSound(18)
        stage.delay(3)
        stage.showUnit(15, 49, 16, 2)
        stage.unitsMove([
            [
                stage.unit(16),
                38,
                46,
                1],
            [
                stage.unit(15),
                49,
                40,
                2]])
        stage.delay(3)
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n이 남자는 허저이며 주군를 섬기고 싶어 합니다.')
        stage.unit(15).setAction(11, 2)
        stage.say('&15\n허저, 부탁이야.\n&0\n아, 정말 원후 장군 같네.')
        stage.unit(16).setAction(0, 1)
        stage.say('&16\n이 사람은 정말 무서워요—무술 실력은 제 수준이에요.')
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n게다가 그는 신성한 힘을 가지고 태어났다,\n야생 황소의 꼬리를 잡아당겨 백 걸음이나 끌고 갈 수 있어!')
        model.setFace(3)
        stage.unit(0).setAction(3)
        stage.say('하하하, 진실인가요? 정말로 무예가 뛰어나군요!')
        stage.say('&16\n맞아!\n&0\n하하하, 아주 좋아. 전장에서 네 힘을 보여줘!\n전위, 허저 맡길게.\n&16\n오? 정말...... 좋네.')
        stage.unit(16).setAction(0, 1)
        stage.say('&16\n이봐, 허저, 이리 와.\n행진과 싸움을 가르쳐 줄게.\n&15\n네!')
        stage.unit(15).setAction(0, 2)
        stage.delay(3)
        stage.unit(15).move(38, 40, 1)
        model.setFace(0)
        stage.unit(0).setAction(0)
        model.unitJoin(15, 0, 0)
        if vars[1013]:
            gvars[0] = 15
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
    if vars[707] and not vars[706]:
        stage.say('전위, 무슨 일이야? 왜 아직 안 오는 거야.')
        stage.unit(20).setAction(0, 2)
        stage.say('&20\n네, 무슨 일이 있었던 걸까요?')
        stage.showUnit(16, 49, 16, 2)
        stage.say('&16\n주군!')
        stage.unit(20).setAction(0, 3)
        stage.unit(16).move(49, 46, 2)
        stage.delay(3)
        model.setFace(2)
        stage.unit(0).setAction(2, 0)
        stage.say('전위, 너 어디 갔다 왔느냐! 군사 회의에 늦었잖아!')
        stage.unit(16).setAction(6, 2)
        stage.say('&16\n...... 미안해.\n나는 매우 숙련된 ...... 건장한 남자를 찾았다.')
        model.setFace(0)
        stage.unit(0).setAction(0, 0)
        stage.say('&0\n무술에 매우 능숙한가?')
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n네.')
        stage.unit(16).setAction(0, 0)
        stage.say('&16\n이봐! 들어와!')
        stage.bgSound(18)
        stage.delay(3)
        stage.showUnit(15, 49, 16, 2)
        stage.unitsMove([
            [
                stage.unit(16),
                38,
                46,
                1],
            [
                stage.unit(15),
                49,
                40,
                2]])
        stage.delay(3)
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n이 남자는 허저이며 주군를 섬기고 싶어 합니다.')
        stage.unit(15).setAction(11, 2)
        stage.say('&15\n허저, 부탁이야.\n&0\n아, 정말 원후 장군 같네.')
        stage.unit(16).setAction(0, 1)
        stage.say('&16\n이 사람은 정말 무서워요—무술 실력은 제 수준이에요.')
        stage.unit(16).setAction(0, 2)
        stage.say('&16\n게다가 그는 신성한 힘을 가지고 태어났다,\n야생 황소의 꼬리를 잡아당겨 백 걸음이나 끌고 갈 수 있어!')
        model.setFace(3)
        stage.unit(0).setAction(3)
        stage.say('하하하, 진실인가요? 정말로 무예가 뛰어나군요!')
        stage.say('&16\n맞아!\n&0\n하하하, 아주 좋아. 전장에서 네 힘을 보여줘!\n전위, 허저 맡길게.\n&16\n오? 정말...... 좋네.')
        stage.unit(16).setAction(0, 1)
        stage.say('&16\n이봐, 허저, 이리 와.\n행진과 싸움을 가르쳐 줄게.\n&15\n네!')
        stage.unit(15).setAction(0, 2)
        stage.delay(3)
        stage.unit(15).move(38, 40, 1)
        model.setFace(0)
        stage.unit(0).setAction(0)
        model.unitJoin(15, 0, 0)
        if vars[1013]:
            gvars[0] = 15
            gvars[4076] = 0
            gvars[1] = gvars[0]
            gvars[2] = 5259072
            gvars[3] = 0
            gvars[4] = 0
            gvars[5] = 0
            gvars[1] *= 4
            gvars[1] += gvars[2]
            pvars[0] = gvars[1]
            stage.varOper(2, 3, 2, 1, 0)
            stage.setUnitAttr(gvars[0], 17, gvars[3])
            if gvars[3] >= 24 and gvars[3] <= 33:
                gvars[4] = 1
            if gvars[3] >= 65 and gvars[3] <= 66:
                gvars[4] = 1
            if gvars[3] == 69:
                gvars[4] = 1
            if gvars[3] == 74:
                gvars[4] = 1
            if gvars[3] == 0:
                gvars[4] = 2
            if gvars[3] == 57:
                gvars[4] = 2
            if gvars[3] == 67:
                gvars[4] = 2
            if gvars[3] == 71:
                gvars[4] = 2
            if gvars[3] == 79:
                gvars[4] = 2
            gvars[4076] = 0
            gvars[6] = stage.unitAttr(gvars[0], 9)
            gvars[7] = stage.unitAttr(gvars[0], 10)
            gvars[8] = stage.unitAttr(gvars[0], 11)
            gvars[9] = stage.unitAttr(gvars[0], 8)
            gvars[20] = stage.unitAttr(gvars[0], 18)
            gvars[9] -= gvars[20]
            if gvars[4] == 0:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[4] == 1:
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
                if gvars[9] <= 35:
                    stage.setUnitAbility(gvars[0], 6, 1, 30)
                    stage.setUnitAbility(gvars[0], 8, 1, 30)
            if gvars[4] == 2:
                if gvars[6] <= 34:
                    stage.setUnitAbility(gvars[0], 10, 0, 35)
                if gvars[7] <= 34:
                    stage.setUnitAbility(gvars[0], 11, 0, 35)
                if gvars[8] <= 34:
                    stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[3] <= 59:
                if gvars[20] >= 15:
                    gvars[3] += 1
                if gvars[20] >= 30:
                    gvars[3] += 1
            gvars[102] = gvars[3]
            if 0 == 0:
                gvars[4076] = 0
                gvars[2] = 0
                gvars[4081] = 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(0)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(1)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(2)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(3)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(4)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(5)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(6)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(7)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(8)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(9)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(10)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(11)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(12)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(13)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(14)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(15)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(16)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(17)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(18)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(19)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(20)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(21)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(22)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(23)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(24)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(25)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(26)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(27)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(28)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(29)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(30)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(31)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(32)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(33)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(34)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(35)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(36)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(37)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(38)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(39)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(40)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(41)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(42)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(43)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(44)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(45)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(46)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(47)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(48)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(49)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(50)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(51)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(52)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(53)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(54)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(55)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(56)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(57)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(58)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(59)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(60)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(61)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(62)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(63)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(64)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(65)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(66)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(67)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(68)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(69)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(70)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(71)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(72)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(73)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(74)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(75)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(76)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(77)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(78)
                gvars[2] += 1
                if gvars[102] == gvars[2]:
                    model.unit(gvars[0]).setPosts(79)
                gvars[4081] = 0
    stage.bgSound(0)
    stage.delay(3)
    stage.say('&0\n신사 여러분, 드디어 황제를 맞이할 기회가 왔습니다.\n모두가 더 열심히 일해야 해.')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 15)
    gvars[4076] = 0
    gvars[4057] = 9
    stage.setBattlePos([
        [
            17,
            11],
        [
            16,
            11],
        [
            18,
            12],
        [
            17,
            9],
        [
            19,
            9],
        [
            18,
            7],
        [
            17,
            4],
        [
            17,
            2],
        [
            19,
            3],
        [
            19,
            2],
        [
            18,
            1],
        [
            17,
            0],
        [
            18,
            2],
        [
            16,
            1],
        [
            19,
            0]])
    return False


def scene6():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n나는 맹덕를 영원히 따라갈 계획이야,\n황제가 황제인지 아닌지는 누가 신경 쓰겠습니까.')
    if stage.unitClickTest(22):
        if vars[706]:
            stage.say('&22\n류예 씨는 아마도 포병 호송대의 일원일 거야.\n이 유닛은 가장 긴 공격 범위를 자랑합니다......\n이것은 아군의 전투력에 매우 도움이 될 것입니다.')
        if not vars[706]:
            stage.say('&22\n원소 황제를 구하러 가라는 황제의 명령을 거부했다는 소문을 들었습니다.\n이 사람의 능력은 특별할 게 없었다.\n&0\n그래도 아직 아군 이길 수 없잖아!')
    if stage.unitClickTest(21):
        if vars[706]:
            stage.say('&21\n도둑 병사들은 지리 기반 전략을 사용할 수 있습니다,\n하지만 일반 허저들이 어떤 계획을 쓸지 알 수 없었어요.\n&15\n뭐라고...... 무슨 뜻이야!\n&21\n하하, 아무것도 아니.......')
        if vars[707] and not vars[706]:
            stage.say('&21\n도둑 병사들은 지리 기반 전략을 사용할 수 있습니다,\n하지만 일반 허저들이 어떤 계획을 쓸지 알 수 없었어요.\n&15\n뭐라고...... 무슨 뜻이야!\n&21\n하하, 아무것도 아니.......')
        if not vars[706] and not vars[707]:
            stage.say('&21\n마침내 그는 황제를 맞이할 수 있었다.')
    if stage.unitClickTest(16):
        if vars[706]:
            stage.say('&16\n진짜야! 정말 황소를 끌고 갈 수 있.......\n&0\n하하하, 믿어! 믿어!\n&16\n야, 허저, 너도 한마디 해봐!\n&15\n응? …… 뭐라고 했어?\n&16\n너 .......')
        if vars[707] and not vars[706]:
            stage.say('&16\n진짜야! 정말 황소를 끌고 갈 수 있.......\n&0\n하하하, 믿어! 믿어!\n&16\n안녕, 허저\n너도 말해야 해!\n&15\n응? …… 뭐라고 했어?\n&16\n너 .......')
        if not vars[706] and not vars[707]:
            stage.say('&16\n황제님... 아직 못 봤어......')
    if stage.unitClickTest(15):
        if vars[706]:
            stage.say('&15\n나는 산적 병사들이다, 황무지를 빠르게 가로질러 걷고 있다!')
        if vars[707] and not vars[706]:
            stage.say('&15\n나는 산적 병사들이다, 황무지를 빠르게 가로질러 걷고 있다!')
        if not vars[706] and not vars[707]:
            stage.say('&15\n최선을 다하겠습니다.')
    if stage.unitClickTest(20):
        stage.say('&20\n전장의 중앙과 북쪽에는 산들이 있습니다.\n아군 북동쪽에서 산의 남쪽으로 방향을 틀어갑니다.\n&20\n그런데...... 가후가 헌제를 풀어준 사람이라고 들었어.\n&0\n가후Jia 원과 ......? 지금 폐하와 함께 있나?\n&20\n…… 그는 황제가 그를 붙잡으려는 시도를 거절한 듯했다,\n이제 아무도 ......가 어디로 가는지 모른다.\n&0\n흠....... 난 항상 그렇게 생각했어\n가장 무서운 적은 가후 자원허였다.\n&0\n그가 없으면 적은 더 이상 위협이 되지 않았을 것이다.\n&20\n아니...... 적을 과소평가하는 것은 매우 위험하다,\n특히 적이 아직 서황을 가지고 있으니까요.\n&0\n서황? 들어본 적 없어.\n&20\n그는 뛰어난 무술을 가진 용맹한 장군이었다.\n&0\n서황......?\n&20\n부주의하지 마.\n&0\n흠.......')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
