# Source Generated with Decompyle++
# File: R_53.marshal (Python 3.9)


def scene0():
    '''흰 제단'''
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            3,
            44,
            58,
            1],
        [
            17,
            44,
            52,
            1]])
    stage.draw()
    stage.setEventName('흰 제단')
    stage.setStageName('유후푸 조조 주 캠프')
    model.setFace(1)
    stage.say('&0\n그는 마왕이 이렇게 무한한 힘을 가질 줄은 전혀 예상하지 못했다.\n우리의 진격은 꽤 오랫동안 지연되었습니다.')
    model.setFace(0)
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n그들이 바이디 시티에 도착했을 때,\n예상보다 훨씬 늦은 것 같아요.')
    stage.unit(19).setAction(0)
    stage.say('하지만 공명은 길에 함정을 파서 차례로 방해하는 것은, 우리가 백제성 근처에 접근하지 못하게 하려는 것뿐입니다. 보니 백제성 안에는 반드시 수상한 점이 있습니다.')
    stage.unit(0).setAction(17)
    stage.say('좋습니다, 한 번에 백제성을 공략합니다!')
    stage.unit(0).setAction(0)
    stage.unit(19).setAction(0, 3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10)
    gvars[4076] = 0
    gvars[4057] = 53
    stage.setBattlePos([
        [
            13,
            20],
        [
            14,
            20],
        [
            12,
            20],
        [
            15,
            20],
        [
            13,
            21],
        [
            14,
            21],
        [
            12,
            21],
        [
            15,
            21],
        [
            13,
            22],
        [
            14,
            22],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene1():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n이전에 저는 주군 보고한 적이 있습니다.\n바이디 시 안팎에는 세 개의 벽으로 이루어진 구조물이 있습니다.\n매우 견고하게 지어졌습니다.')
    if stage.unitClickTest(19):
        stage.say('&19\n왜 공명 더 가까이 가게 해주지 않는 거야......\n주군, 유일한 가능성밖에 생각할 수 없어요......\n&0\n…… 두 번째 제단!')
    if stage.unitClickTest(3):
        stage.say('&3\n형님......\n윤창은 다시 백디 시로 돌아왔다.')
    if stage.unitClickTest(17):
        stage.say('&17\n우리는 유후푸에서 청룡옥을 얻었어,\n그렇다면 정확히 어떤 기능이 있을까요?\n&20\n초선, 이 귀한 옥은 이름 그대로야,\n이 안에는 네 신 중 하나인 아쥬르 드래곤의 힘이 담겨 있습니다.\n&20\n청룡의 힘은 번개라고 전해진다.\n&17\n그래서 순욱 씨가 정말 해박한 것도 당연하다.')
    if stage.unitClickTest(23):
        stage.say('&23\n청룡옥을 장착한 군대,\n승마 전략가 계급의 사마의 신사들만 남아 있는 것 같다.')
    if stage.unitClickTest(1):
        stage.say('&1\n서나라 장군은 공명가 마왕에게 빙의된 사실을 알고 있을까?\n&0\n아직도 진실을 모른다는 게 두렵습니다,\n지금까지는 아직 공명 어둠 속에 있었어요!\n&3\n……………')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
