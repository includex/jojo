# Source Generated with Decompyle++
# File: S_46.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(4,24)'])
    stage.nearEvent([
        6,
        36,
        7,
        63])
    stage.nearEvent([
        7,
        36,
        12,
        57], 1)
    stage.initFight()
    stage.setGlobalData(25, -2, -1, -1, 0, 1)
    stage.createFriend([
        {
            'id': 29,
            'x': 19,
            'y': 1,
            'lv': 4,
            'i': 0 },
        {
            'id': 214,
            'x': 17,
            'y': 1,
            'dir': 3,
            'lv': 0,
            'i': 1 },
        {
            'id': 215,
            'x': 19,
            'y': 3,
            'lv': 0,
            'i': 2 },
        {
            'id': 216,
            'x': 21,
            'y': 1,
            'dir': 1,
            'lv': 0,
            'i': 3 },
        {
            'id': 322,
            'x': 11,
            'y': 16,
            'lv': 0,
            'i': 4 },
        {
            'id': 323,
            'x': 13,
            'y': 16,
            'lv': 0,
            'i': 5 },
        {
            'id': 324,
            'x': 18,
            'y': 26,
            'lv': 0,
            'i': 6 },
        {
            'id': 325,
            'x': 20,
            'y': 26,
            'lv': 0,
            'i': 7 },
        {
            'id': 0,
            'hide': 1,
            'x': 24,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'i': 8 },
        {
            'id': 263,
            'hide': 1,
            'x': 23,
            'y': 2,
            'dir': 3,
            'lv': 0,
            'i': 9 },
        {
            'id': 264,
            'hide': 1,
            'x': 24,
            'y': 2,
            'dir': 3,
            'lv': 0,
            'i': 10 },
        {
            'id': 265,
            'hide': 1,
            'x': 24,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'i': 11 },
        {
            'id': 266,
            'hide': 1,
            'x': 25,
            'y': 2,
            'dir': 3,
            'lv': 0,
            'i': 12 },
        {
            'id': 267,
            'hide': 1,
            'x': 25,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'i': 13 },
        {
            'id': 268,
            'hide': 1,
            'x': 25,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'i': 14 },
        {
            'id': 286,
            'hide': 1,
            'x': 26,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'i': 15 },
        {
            'id': 287,
            'hide': 1,
            'x': 26,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'i': 16 },
        {
            'id': 288,
            'hide': 1,
            'x': 27,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'i': 17 },
        {
            'id': 289,
            'hide': 1,
            'x': 27,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'i': 18 },
        {
            'id': 290,
            'hide': 1,
            'x': 27,
            'y': 5,
            'dir': 3,
            'lv': 0,
            'i': 19 }])
    stage.createEnemy(
        [{'id': 36, 'x': 5, 'y': 20, 'dir': 1, 'lv': 6, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 0},
         {'id': 48, 'x': 4, 'y': 20, 'dir': 1, 'lv': 4, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 1},
         {'id': 258, 'x': 5, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 2},
         {'id': 259, 'x': 5, 'y': 21, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 3},
         {'id': 282, 'x': 4, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 4},
         {'id': 334, 'x': 4, 'y': 21, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 12, 'targetY': 16, 'i': 5},
         {'id': 34, 'x': 2, 'y': 18, 'dir': 1, 'lv': 6, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 6},
         {'id': 38, 'x': 1, 'y': 18, 'dir': 1, 'lv': 4, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 7},
         {'id': 210, 'x': 2, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 8},
         {'id': 211, 'x': 2, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 9},
         {'id': 234, 'x': 1, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 10},
         {'id': 235, 'x': 1, 'y': 19, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 23, 'targetY': 16, 'i': 11},
         {'id': 57, 'x': 2, 'y': 2, 'dir': 1, 'lv': 6, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 12},
         {'id': 462, 'x': 1, 'y': 3, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 13},
         {'id': 463, 'x': 3, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 14},
         {'id': 464, 'x': 1, 'y': 2, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 15},
         {'id': 465, 'x': 2, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 16},
         {'id': 37, 'x': 18, 'y': 34, 'dir': 0, 'lv': 6, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 17},
         {'id': 63, 'x': 17, 'y': 33, 'dir': 0, 'lv': 4, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 18},
         {'id': 260, 'x': 18, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 19},
         {'id': 310, 'x': 17, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 20},
         {'id': 311, 'x': 16, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 21},
         {'id': 65, 'x': 4, 'y': 24, 'dir': 0, 'lv': 4, 'i': 22},
         {'id': 45, 'hide': 1, 'x': 1, 'y': 29, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 23},
         {'id': 318, 'hide': 1, 'x': 2, 'y': 29, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 319, 'hide': 1, 'x': 1, 'y': 28, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 320, 'hide': 1, 'x': 1, 'y': 30, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 321, 'hide': 1, 'x': 0, 'y': 29, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 62, 'hide': 1, 'x': 1, 'y': 1, 'dir': 1, 'lv': 4, 'ai': 1, 'i': 28},
         {'id': 212, 'hide': 1, 'x': 2, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 29},
         {'id': 213, 'hide': 1, 'x': 0, 'y': 2, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 236, 'hide': 1, 'x': 1, 'y': 0, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 31},
         {'id': 237, 'hide': 1, 'x': 0, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 32},
         {'id': 35, 'x': 12, 'y': 34, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 33},
         {'id': 3, 'x': 11, 'y': 33, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 34},
         {'id': 269, 'x': 12, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 270, 'x': 13, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 271, 'x': 14, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 291, 'x': 12, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 292, 'x': 13, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 221, 'hide': 1, 'x': 0, 'y': 29, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 293, 'x': 17, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 41},
         {'id': 350, 'x': 16, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 26, 'i': 42},
         {'id': 351, 'x': 1, 'y': 1, 'dir': 1, 'lv': 0, 'ai': 4, 'targetX': 19, 'targetY': 1, 'i': 43}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 23,
            'y': 16,
            'dir': 3 },
        {
            'idx': 1,
            'x': 22,
            'y': 17,
            'dir': 3 },
        {
            'idx': 2,
            'x': 6,
            'y': 4,
            'dir': 3 },
        {
            'idx': 3,
            'x': 4,
            'y': 6,
            'dir': 0 },
        {
            'idx': 4,
            'x': 12,
            'y': 16 },
        {
            'idx': 5,
            'x': 19,
            'y': 26 },
        {
            'idx': 6,
            'x': 21,
            'y': 16,
            'dir': 3 },
        {
            'idx': 7,
            'x': 23,
            'y': 18 },
        {
            'idx': 8,
            'x': 12,
            'y': 15 },
        {
            'idx': 9,
            'x': 19,
            'y': 25 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(3, 36, 0, -1, 0, 16)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(63, -1, 0, -1, 0, 20)
    stage.setEnemyEquip(48, -1, 0, -1, 0, 13)
    stage.setEnemyEquip(62, -1, 0, -1, 0, 11)
    stage.loadBg(46)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab29')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab29')
    stage.draw()
    stage.bgSound(6)
    stage.unit(29).setDir(stage.countDir(29, 36))
    stage.unit(29).setAction(8)
    stage.say('&29\n한숨, 어떻게 해야 할까?\n군대가 공격하려던 찰나,\n왜 아직 주군 안 왔지?')
    stage.unit(12).setDir(stage.countDir(12, 29))
    stage.say('&12\n진정해, 궈화이.\n주군 곧 도착할 거야,\n이제 그가 해야 할 일은 적군 저항하는 것뿐이다.')
    stage.unit(36).setDir(stage.countDir(36, 48))
    stage.say('&36\n얀 장군, 이 젊은이는 ......\n적과 용감히 싸울 기회를 목격하라.\n힘을 합쳐서 적군 장군들을 모두 처리합시다!')
    stage.unit(48).setDir(stage.countDir(48, 36))
    stage.say('&48\n하하하! 황 장군님.\n데뷔하는 젊은 남자 같아!\n&36\n하하하, 잘 말씀하셨네요.\n내 정신과 힘은 젊은이들 못지않다.\n&48\n하지만 이번에는 반대자들 중에서,\n하후연라는 숙련된 궁수가 있었던 것 같다,\n장군은 이미 손과 손가락 마디를 문지르기 시작했을 것이다!')
    stage.unit(6).heightLight()
    stage.say('&36\n흠!\n저는 항상 그와 경쟁하고 싶었어요.\n&48\n하하하, 황 장군이 너를 노리면,\n하후연 아마도 실패할 것이다.\n여기서 목숨을 잃을 것 같하후연!')
    stage.unit(6).setDir(stage.countDir(6, 7))
    stage.say('&6\n적군 군사력은 막대하다,\n주군 올 때까지 버틸 수 있을까?\n&7\n딩준산은 자연의 요새입니다,\n방어를 강화하면 정복당하지 않아야 한다,\n지금은 포기하지 않고 버티는 것만이 유일한 선택이었다.\n&6\n적군 선봉 중에는 황충라는 베테랑이 있었다,\n나는 그에게 도전하고 싶었다,\n또한 적의 사기를 저하시킵니다.')
    stage.unit(36).heightLight()
    stage.unit(7).setDir(stage.countDir(7, 6))
    stage.say('&7\n황충가 오랫동안 샤호우 장군에 도전하고 싶어 했다는 소문을 들었습니다.\n이 남자는 나이가 들수록 점점 강해지고 무술에도 매우 능숙하다,\n만약 주군 도착하기 전에 무슨 일이 생기면 어쩌지?\n&6\n흥! 난 그에게 지지 않을 거야.\n하지만 확실히 하기 위해,\n황충 가까이 가지 않는 게 좋아.')
    stage.unit(3).setDir(stage.countDir(3, 35))
    stage.say('&3\n관은 이미 진형을 마쳤다.\n공명 씨, 지시사항 있나요?')
    stage.unit(35).setDir(stage.countDir(35, 3))
    stage.say('&35\n아직 전략을 쓸 필요는 없겠지?\n조운와 장군들에게 맡기황충 문제없을 거야.\n&3\n(전략가는 항상 일상 계획을 세우며,\n이번에는 왜 이렇게 급하게 진행된 걸까......\n정말 이 땅을 포기할 거야? )')
    stage.unit(34).setDir(stage.countDir(34, 38))
    stage.say('&34\n적군 아직 딩준산 안에서 버티고 있나?\n그들의 계획이 정확히 무엇일까요?')
    stage.unit(38).setDir(stage.countDir(38, 34))
    stage.say('&38\n먼저 서쪽 고상 플랫폼을 캡처하자.\n그곳에서 적군의 현실과 환상이 완전히 드러날 수 있다.')
    stage.unit(34).setDir(1)
    stage.unit(48).setDir(stage.countDir(48, 38))
    stage.say('&48\n법정General, 높은 플랫폼은 우리에게 맡겨."\n&34\n그럼 정준산 본진을 공격할 적절한 순간을 기다리겠습니다.')
    stage.unit(36).setDir(stage.countDir(36, 65))
    stage.say('&36\n멍다 장군, 가몽관은 당신 손에 달렸습니다!\n우리는 절대 뒤에서 공격당하고 싶지 않아요!')
    stage.unit(65).setDir(stage.countDir(65, 36))
    stage.say('&65\n네가 아무 말 안 해도 내가 버틸 거야!\n(사실 두 노인을 선봉으로 내버려 두었다......\n슈의 미래는 상상하기 쉽다! )')
    stage.unit(221).show()
    stage.unit(221).move(11, 34, 1)
    stage.unit(221).setDir(stage.countDir(221, 3))
    stage.say('&221\n끔찍한 일이 일어났어!')
    stage.unit(3).setDir(stage.countDir(3, 221))
    stage.say('&3\n무슨 일이야?\n&221\n징과 징저우는 우나라의 매복 공격을 받았다......\n제발, 제발 지원군을 보내 구해줘!\nOtherwise주군 당신의 생명이 구원받지 못할 수도 있습니다......')
    stage.unit(35).setDir(stage.countDir(35, 221))
    stage.say('&35\n(하하하.\n주유This 아이가 성공한 것 같아." )')
    stage.unit(3).setDir(stage.countDir(3, 35))
    stage.say('&3\n공명Mr 톈!\n서둘러 징저우로 돌아가자!\n&35\n아니요, 허용되지 않습니다.\n먼저 딩준산을 점령해야 한다!\n&3\n전략가가 형을 더 이상 신경 쓰지 않는 걸까!?\n&35\n공명 그런 뜻이 아니었다.\n주군 세 명의 장군이 그의 곁에 있었다,\n안전할 거야.\n&3\n형이 사람들을 보내 도움을 구하러 갔으니,\n상황이 이미 매우 불리함을 나타냅니다,\n전략가가 이걸 이해하지 못할 수 있겠어!?\n&3\n전략가의 결정은 일반적인 관행과 달리 보인다,\n그렇다면, 설령 한 사람에 관한 일이라도,\n형을 구하러 징저우로 급히 가야 해!\n&35\n(쳇, 참견관우 진짜 대단하다!\n좋아, 너만 혼자 갈 관우,\n나한테 뭘 할 수 있겠어? )')
    stage.unit(3).move(0, 29, 3)
    stage.unit(221).move(1, 29, 3)
    stage.unit(3).hide()
    stage.unit(221).hide()
    stage.unit(34).setDir(stage.countDir(34, 35))
    stage.unit(36).setDir(stage.countDir(36, 35))
    stage.say('&34\n공명 씨, 무슨 일이 있었나요?"\n관 장군은 어디로 가는가?\n&36\n전투가 시작되기 전, 군대 전체가 혼란에 빠져 있었다,\n정확히 무슨 일이 있었던 거야?')
    stage.unit(35).setDir(stage.countDir(35, 34))
    stage.say('&35\n아, 심각한 건 아니니 안심해.\n그나저나, 아직 중요한 일이 남아 있어,\n잠시 이곳을 떠나야 합니다.\n&35\n황충 장군, 조운 장군,\n잠시 여기 있어 주세요.\n&36\n흠, 흠. 내가 처리할 수 있어......\n&34\n………')
    stage.unit(35).hide()
    stage.unit(34).setDir(stage.countDir(34, 36))
    stage.unit(36).setDir(stage.countDir(36, 34))
    stage.say('&34\n관장군과 전략가 모두 떠났다......\n도대체 무슨 일이 벌어지고 있는 거죠?\n&36\n그건 잊어버려!\n우리는 전장에 에너지를 집중해야 합니다.')
    stage.unit(36).setDir(1)
    stage.unit(34).setDir(1)
    stage.unit(57).setDir(stage.countDir(57, 36))
    stage.unit(57).setAction(5)
    stage.say('&57\n두 노련한 장군의 선봉대가 행동에 나섰다.\n전투 준비도 하자!\n양평관을 점령하고 한중을 직접 공격하라!')
    stage.unit(57).setAction(0)
    stage.unit(37).setDir(stage.countDir(37, 63))
    stage.say('&37\n선봉대가 행동에 나섰다.\n우리의 목표는 앞에 있는 고지를 점령하는 것입니다.\n적이 도망치지 못하게 해!')
    stage.unit(63).setDir(stage.countDir(63, 37))
    stage.say('&63\n지연된 우군도 점진적으로 도착해야 합니다.\n이 승리아군 전투는 확실하다!')
    stage.unit(36).setDir(1)
    stage.unit(36).setAction(5)
    stage.say('&36\n군대 전체가 공격을 시작했다!\n돌격!')
    stage.unit(36).setAction(0)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n2. 턴 수가 25명을 초과한다.\n\n패배 조건\n1. 우리 군대 전체가 전멸했다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[546] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 2 and stage.round() == 10:
        stage.resumeCtrl()
        stage.unit(35).show(12, 34, 0)
        stage.say('&35\n(흠, 이건 여전히 안 될 것 같네,\n북쪽으로 진격하지 못하면...... )')
        if not vars[50]:
            stage.unit(36).setDir(stage.countDir(36, 35))
            stage.say('&36\n오, 오, 공명 씨, 돌아오셨나요?')
        if not vars[52]:
            stage.unit(34).setDir(stage.countDir(34, 35))
            stage.say('&34\n전략가, 어디 갔었어?')
        if not vars[54]:
            stage.unit(57).setDir(stage.countDir(57, 35))
            stage.say('&57\n공명Mr.?!')
        if not vars[55]:
            stage.unit(37).setDir(stage.countDir(37, 35))
            stage.say('&37\n공명Mr.?!\n(모두가 전쟁 중인데, 이 사람은 어디로 간 걸까?) )')
        stage.say('&35\n장군님들, 공명 말씀을 들어주십시오.\n징저우는 오나라의 매복을 받았다,\n주군 지금 위험한 상황에 처해 있다.\n&35\n공명 이미 윤창 장군을 먼저 보내 지원을 제공했지만,\n하지만 증원군이 즉시 돌아오지 못하면 징저우는 예기치 못한 위험에 직면할 수 있다.\n&35\n전투 중에 예상치 못한 사건을 마주하는 것은 우리가 원하는 바가 아닙니다.\n이제 전 군대가 후퇴해 전속력으로 징저우로 급히 달려가야 했다.')
        if not vars[50]:
            stage.say('&36\n어떻게, 어떻게 이런 일이 일어날 수 있지?')
        if not vars[52]:
            stage.say('&34\n빨리 돌아와!')
        if not vars[54]:
            stage.say('&57\n음, 어쩔 수 없어!')
        if not vars[55]:
            stage.say('&37\n(관우가 징저우로 급히 돌아왔을 때,\n공명 무슨 일이 일어나고 있는지 알고 있었다.\n이 사람이 도대체 뭘 계획하고 있는 거야? )\n&37\n도망쳐! 후퇴!')
        stage.say('&35\n(하하하.\n이제 서둘러 돌아간다 해도 너무 늦을지도 몰랐다. )')
        stage.setRectUnitHide(0, 0, 27, 35, 2)
        if not vars[61]:
            stage.unit(29).setAction(4)
            stage.say('&29\n휴, 드디어 구원받았네요.\n단기적으로는 또 다른 캠페인에 나가고 싶지 않을 거예요.\n돌아오면 휴가 가서 잠시 쉴게.')
        if not vars[62]:
            stage.say('&6\n왜 서나라 군대는 후퇴했을까?')
        if not vars[63]:
            stage.say('&2\n정확히 무슨 일이 있었던 거야?')
        if not vars[64]:
            stage.say('&12\n우리가 승리했나요?\n공명 행동은 정말 예측 불가능해!')
        vars[11] = 1
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[646] = 1
        return True
    if not vars[20] and stage.isInPos(1025, 4, 24):
        stage.getItem(154, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and not vars[54] and stage.isInPos(1026, 6, 4):
        stage.say('&57\n훌륭해!\n양평관을 점령했고,\n한중이 바로 네 앞에 있어!')
        stage.unit(62).show()
        stage.unit(212).show()
        stage.unit(213).show()
        stage.unit(236).show()
        stage.unit(237).show()
        stage.unit(62).setDir(stage.countDir(62, 57))
        stage.unit(62).setAction(10)
        stage.say('&62\n우란의 군대가 도착했다!\n오!?\n양평관이 벌써 점령당했어!?')
        stage.unit(57).setDir(stage.countDir(57, 62))
        stage.say('&57\n아, 그러니까 우란 장군이구나.\n이제 우리는 한중으로 곧장 행군할 수 있습니다,\n앞으로 나아가 한중을 잡자.')
        vars[21] = 1
    if not vars[22] and not vars[50] and not vars[57] and stage.isInPos(1026, 12, 16):
        stage.say('&36\n조준은 정말 쓸모없구나!\n어떻게 그렇게 쉽게 자리를 포기할 수 있지......')
        if not vars[51]:
            stage.unit(48).setDir(stage.countDir(48, 36))
            stage.say('&48\n아니에요, 모두 황 장군의 명성 때문이에요.')
        stage.unit(65).setDir(stage.countDir(65, 36))
        stage.say('&65\n(흥! 군사력의 격차가 이렇게 크다면,\n아이들도 이길 수 있습니다.\n이 노인은 너무 거만해...... )')
        stage.unit(45).show()
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(45).setDir(stage.countDir(45, 65))
        stage.say('&45\n아, 아, 아\n늦었어......\n전투는 어떻게 되고 있나요!?')
        stage.unit(65).setDir(stage.countDir(65, 45))
        stage.say('&65\n(왜 항상 이런 쓰레기들이 있지...... )\n사실은 바로 눈앞에 있습니다,\n늦으면 인정 못 받아.')
        stage.unit(36).setAI(1)
        stage.unit(48).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(334).setAI(1)
        vars[22] = 1
    if not vars[23] and not vars[55] and stage.isInPos(1026, 19, 26):
        if not vars[56]:
            stage.say('&63\n좋아!\n그들은 적의 진지를 점령했다.')
        else:
            stage.say('&37\n흠! 적의 진영을 점령했어.')
        stage.say('&37\n살아있는 모든 사람을 죽여라!\n그들은 우리를 완전히 반대할 수 없을 것이다.')
        stage.unit(37).setAI(1)
        stage.unit(63).setAI(1)
        stage.unit(310).setAI(1)
        stage.unit(311).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(350).setAI(1)
        stage.unit(293).setAI(1)
        vars[23] = 1
    if not vars[24] and not vars[25] and stage.isInPos(1026, 23, 16):
        if not vars[50]:
            stage.say('&36\n하하하, 우리가 이곳을 점령하는 한,\n마치 그들이 이 승리를 거둔 것 같았다!')
        if not vars[52]:
            stage.say('&34\n음, 좀 더 노력해 보자.')
        if not vars[54]:
            stage.say('&57\n적군 위대한 상황은 이미 사라졌다.')
        if not vars[55]:
            stage.say('&37\n수용소는 점령되었지만,\n하지만 그것이 승리를 의미하지는 않습니다,\n우리는 부주의하거나 적을 과소평가해서는 안 됩니다.')
        stage.info('전장 옆 숲에서......')
        stage.talk(186, 186, '음, 딩준산 진지를 점령했다......\n알려야 immediately주군......')
        stage.info('조조 증원군의 정찰병들이 전속력으로 조조 위치에 도착했다.')
        stage.talk(186, 186, '주군, 딩준산 진지를 점령했다!')
        stage.talk(0, 0, '뭐라고!\n흠, 목적지에 도착했네,\n그래도 시간이 좀 걸려요.')
        stage.talk(0, 0, '딩준산에 있는 군대를 후퇴시켜야 하나?\n아니면 증원군이 도착할 때까지 버텨야 할까?')
        sel = stage.choice('전체 군대가 후퇴했다\n계속 싸워', 0)
        vars[24] = 1
        if sel == 1:
            stage.resumeCtrl()
            stage.talk(0, 0, '딩준산의 군대에 후퇴하라고 명령하라!\n일단 이곳은 포기하자.\n나중에 다시 낚아채자!')
            stage.talk(186, 186, '네!')
            stage.info('정찰병들은 즉시 딩준산으로 돌아갔다,\n이 명령은 군 전체에 전달되었다.')
            if not vars[61]:
                stage.unit(29).setAction(4)
                stage.say('&29\n이제 후퇴할 때인가? 이제 우린 구원받았어!\n내가 장군이 될 자격이 없어 보이는 것 같아,\n차라리 산과 숲으로 은퇴하는 게 낫다.')
            if not vars[62]:
                stage.say('&6\n주군의 명령이었으니,\n다른 선택지가 없었다.\n후퇴.')
            if not vars[63]:
                stage.say('&7\n이 상황에서는 정말 다른 선택지가 없었다.')
            if not vars[64]:
                stage.say('&12\n후퇴, 후퇴!')
            if not vars[50]:
                stage.say('&36\n하하하!\n내가 황충 있을까 봐 무서워?')
            if not vars[52]:
                stage.say('&34\n좋아, 적군 쫓아가.')
            if not vars[54]:
                stage.say('&57\n쫓아가, 도망가지 못하게 해!')
            if not vars[55]:
                stage.say('&37\n도망치게 두지 않을 거야!')
            stage.unit(35).show(12, 34, 0)
            stage.say('&35\n(흠, 이건 여전히 안 될 것 같네,\n북쪽으로 진격하지 못하면...... )')
            if not vars[50]:
                stage.unit(36).setDir(stage.countDir(36, 35))
                stage.say('&36\n오, 오, 공명 씨, 돌아오셨나요?')
            if not vars[52]:
                stage.unit(34).setDir(stage.countDir(34, 35))
                stage.say('&34\n전략가, 어디 갔었어?')
            if not vars[54]:
                stage.unit(57).setDir(stage.countDir(57, 35))
                stage.say('&57\n공명Mr.?!')
            if not vars[55]:
                stage.unit(37).setDir(stage.countDir(37, 35))
                stage.say('&37\n공명Mr.?!\n(모두가 전쟁 중인데, 이 사람은 어디로 간 걸까?) )')
            stage.say('&35\n장군님들, 공명 말씀을 들어주십시오.\n징저우는 오나라의 매복을 받았다,\n주군 지금 위험한 상황에 처해 있다.\n&35\n공명 이미 윤창 장군을 먼저 보내 지원을 제공했지만,\n하지만 증원군이 즉시 돌아오지 못하면 징저우는 예기치 못한 위험에 직면할 수 있다.\n&35\n전투 중에 예상치 못한 사건을 마주하는 것은 우리가 원하는 바가 아닙니다.\n이제 전 군대가 후퇴해 전속력으로 징저우로 급히 달려가야 했다.')
            if not vars[50]:
                stage.say('&36\n어떻게, 어떻게 이런 일이 일어날 수 있지?')
            if not vars[52]:
                stage.say('&34\n빨리 돌아와!')
            if not vars[54]:
                stage.say('&57\n음, 어쩔 수 없어!')
            if not vars[55]:
                stage.say('&37\n(관우가 징저우로 급히 돌아왔을 때,\n공명 무슨 일이 일어나고 있는지 알고 있었다.\n이 사람이 도대체 뭘 계획하고 있는 거야? )\n&37\n도망쳐! 후퇴!')
            stage.say('&35\n(흥,\n이제 서둘러 돌아간다 해도 너무 늦을지도 몰랐다. )')
            stage.setRectUnitHide(0, 0, 27, 35, 2)
            if not vars[61]:
                stage.say('&29\n？？？')
            if not vars[62]:
                stage.say('&6\n왜 서나라 군대는 후퇴했을까?')
            if not vars[63]:
                stage.say('&2\n정확히 무슨 일이 있었던 거야?')
            if not vars[64]:
                stage.say('&12\n우리가 승리했나요?\n공명 행동은 정말 예측 불가능해!')
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[646] = 1
            return True
        if sel == 2:
            stage.talk(0, 0, '그는 딩준산의 군대에게 말했다,\n그들은 버티라는 말을 들었다.')
            stage.talk(186, 186, '네!')
            stage.info('정찰병들은 즉시 딩준산으로 돌아갔다,\n이 명령은 군 전체에 전달되었다.')
            if not vars[61]:
                stage.say('&29\n주군 상황을 이해하겠습니까?')
            if not vars[62]:
                stage.say('&6\n증원군이 없어도 우리는 버텨야 해.')
            if not vars[63]:
                stage.say('&7\n증원군은 언제 도착하나요......\n정말 버틸 수 있을까?')
            if not vars[64]:
                stage.say('&12\n방어를 강화하세요!\n적을 밀어내라!')
    if not vars[24] and not vars[25] and stage.isInPos(1026, 19, 1):
        if not vars[50]:
            stage.say('&36\n하하하, 우리가 이곳을 누르는 한,\n마치 그들이 이 승리를 거둔 것 같았다!')
        if not vars[52]:
            stage.say('&34\n음, 좀 더 노력해 보자.')
        if not vars[54]:
            stage.say('&57\n적군 위대한 상황은 이미 사라졌다.')
        if not vars[55]:
            stage.say('&37\n수용소는 점령되었지만,\n하지만 그것이 승리를 의미하지는 않습니다,\n우리는 부주의하거나 적을 과소평가해서는 안 됩니다.')
        stage.info('전장 옆 숲에서......')
        stage.talk(186, 186, '음, 한중시가 점령당했어......\n알려야 immediately주군......')
        stage.info('조조 증원군의 정찰병들이 전속력으로 조조 위치에 도착했다.')
        stage.talk(186, 186, '주군! 한중시가 점령당했어.')
        stage.talk(0, 0, '뭐라고!\n흠, 목적지에 도착했네,\n그래도 시간이 좀 걸려요.')
        stage.talk(0, 0, '딩준산에 있는 군대를 후퇴시켜야 하나?\n아니면 증원군이 도착할 때까지 버텨야 할까?')
        sel = stage.choice('전체 군대가 후퇴했다\n계속 싸워', 0)
        vars[25] = 1
        if sel == 1:
            stage.resumeCtrl()
            stage.talk(0, 0, '딩준산의 군대에 후퇴하라고 명령하라!\n일단 이곳은 포기하자.\n나중에 다시 낚아채자!')
            stage.talk(186, 186, '네!')
            stage.info('정찰병들은 즉시 딩준산으로 돌아갔다,\n이 명령은 군 전체에 전달되었다.')
            if not vars[61]:
                stage.unit(29).setAction(4)
                stage.say('&29\n이제 후퇴할 때인가? 이제 우린 구원받았어!\n내가 장군이 될 자격이 없어 보이는 것 같아,\n차라리 산과 숲으로 은퇴하는 게 낫다.')
            if not vars[62]:
                stage.say('&6\n주군의 명령이었으니,\n다른 선택지가 없었다.\n후퇴.')
            if not vars[63]:
                stage.say('&7\n이 상황에서는 정말 다른 선택지가 없었다.')
            if not vars[64]:
                stage.say('&12\n후퇴, 후퇴!')
            if not vars[50]:
                stage.say('&36\n하하하!\n내가 황충할까 봐 무서워?')
            if not vars[52]:
                stage.say('&34\n좋아, 적군 쫓아가.')
            if not vars[54]:
                stage.say('&57\n쫓아가! 도망치게 하지 마!')
            if not vars[55]:
                stage.say('&37\n도망치게 두지 않을 거야!')
            stage.unit(35).show(12, 34, 0)
            stage.say('&35\n(흠, 이건 여전히 안 될 것 같네,\n북쪽으로 진격하지 못하면...... )')
            if not vars[50]:
                stage.unit(36).setDir(stage.countDir(36, 35))
                stage.say('&36\n오, 오, 공명 씨, 돌아오셨나요?')
            if not vars[52]:
                stage.unit(34).setDir(stage.countDir(34, 35))
                stage.say('&34\n전략가, 어디 갔었어?')
            if not vars[54]:
                stage.unit(57).setDir(stage.countDir(57, 35))
                stage.say('&57\n공명Mr.?!')
            if not vars[55]:
                stage.unit(37).setDir(stage.countDir(37, 35))
                stage.say('&37\n공명Mr.?!\n(모두가 전쟁 중인데, 이 사람은 어디로 간 걸까?) )')
            stage.say('&35\n장군님들, 공명 말씀을 들어주십시오.\n징저우는 오나라의 매복을 받았다,\n주군 지금 위험한 상황에 처해 있다.\n&35\n공명 이미 윤창 장군을 먼저 보내 지원을 제공했지만,\n하지만 증원군이 즉시 돌아오지 못하면 징저우는 예기치 못한 위험에 직면할 수 있다.\n&35\n전투 중에 예상치 못한 사건을 마주하는 것은 우리가 원하는 바가 아닙니다.\n이제 전 군대가 후퇴해 전속력으로 징저우로 급히 달려가야 했다.')
            if not vars[50]:
                stage.say('&36\n어떻게, 어떻게 이런 일이 일어날 수 있지?')
            if not vars[52]:
                stage.say('&34\n빨리 돌아와!')
            if not vars[54]:
                stage.say('&57\n음, 어쩔 수 없어!')
            if not vars[55]:
                stage.say('&37\n(관우가 징저우로 급히 돌아왔을 때,\n공명 무슨 일이 일어나고 있는지 알고 있었다.\n이 사람이 도대체 뭘 계획하고 있는 거야? )\n&37\n도망쳐! 후퇴!')
            stage.say('&35\n(흥,\n이제 서둘러 돌아간다 해도 너무 늦을지도 몰랐다. )')
            stage.setRectUnitHide(0, 0, 27, 35, 2)
            if not vars[61]:
                stage.say('&29\n？？？')
            if not vars[62]:
                stage.say('&6\n왜 서나라 군대는 후퇴했을까?')
            if not vars[63]:
                stage.say('&2\n정확히 무슨 일이 있었던 거야?')
            if not vars[64]:
                stage.say('&12\n우리가 승리했나요?\n공명 행동은 정말 예측 불가능해!')
            stage.reward()
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[646] = 1
            return True
        if sel == 2:
            stage.talk(0, 0, '그는 딩준산의 군대에게 말했다,\n그들은 버티라는 말을 들었다.')
            stage.talk(186, 186, '네!')
            stage.info('정찰병들은 즉시 딩준산으로 돌아갔다,\n이 명령은 군 전체에 전달되었다.')
            if not vars[61]:
                stage.say('&29\n주군 상황을 이해하겠습니까?')
            if not vars[62]:
                stage.say('&6\n증원군이 없어도 우리는 버텨야 해.')
            if not vars[63]:
                stage.say('&7\n증원군은 언제 도착하나요......\n정말 버틸 수 있을까?')
            if not vars[64]:
                stage.say('&12\n방어를 강화하세요!\n적을 밀어내라!')
    if not vars[6] and stage.totalRectUnit(0, 18, 0, 20, 2) >= 1:
        stage.unit(29).setAI(0)
        vars[6] = 1
    if not vars[40] and stage.isNear(6, 36, False):
        stage.unit(36).setDir(stage.countDir(36, 6))
        stage.unit(6).setDir(stage.countDir(6, 36))
        stage.say('&36\n마침내 전설의 위나라 하후연 장군을 보았다.\n오늘날 진정으로 세계 최고의 궁수인 사람은 누구일까요?\n오늘, 우리는 마침내 진실을 볼 수 있게 되었습니다!\n&6\n(황충 이미 나이가 많다고 들었어,\n뜻밖에도 그는 노인과 다를 바 없어 보였다,\n이제 그는 나와 상대가 되지 않아. )\n&6\n선생님, 돌아가셔야 합니다!\n여기서 네 인생을 끝내고 싶지 않아.\n&36\n너무 무례하네요!\n하후연 장군은 그의 위대한 명성에 걸맞은 것 같다,\n그는 군 지휘관의 마음을 이해할 수 없었다......\n&6\n그렇게 고집하니까 받아들일게.\n당신은 평화롭게 마지막 시절을 즐기기 위해 집으로 돌아갈 수도 있었다......\n지금 후회하지 마세요!')
        fight = stage.startFight(6, 36, 5)
        fight.showUnit(True, '한 수 승자가 결정돼!\n신호를 보내면서 동시에 화살을 쏘세요!\n괜찮나요!?', 0)
        fight.showUnit(False, '좋아.\n우리 힘의 큰 격차를 보여줄게!', 0)
        fight.showStart()
        fight.setAction(True, 1)
        fight.setAction(True, 2)
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        stage.delay(5)
        fight.setAction(True, 1)
        fight.setAction(False, 1)
        stage.delay(5)
        stage.effectSound(136, 1)
        stage.delay(20)
        fight.setAction(True, 8)
        stage.effectSound(37, 1)
        fight.say(True, '직접 경험해봤어요!', True)
        fight.setAction(False, 8)
        stage.effectSound(37, 1)
        fight.say(False, '어서!', True)
        fight.setAction(True, 9)
        fight.setAction(False, 9)
        stage.effectSound(36, 1)
        stage.delay(15)
        fight.setAction(False, 11)
        fight.say(False, '흠!', True)
        stage.delay(10)
        fight.say(False, '', False)
        fight.setAction(True, 3)
        stage.delay(10)
        fight.setAction(True, 3)
        stage.delay(10)
        fight.say(True, '나... 계산을 잘못했어......', True)
        stage.delay(5)
        fight.setAction(True, 11)
        stage.delay(10)
        fight.say(True, '제발, 제가 실례로 말씀드려 죄송합니다.\n일단 후퇴하자......', True)
        fight.setAction(True, 13)
        stage.delay(15)
        fight.setAction(False, 0)
        fight.say(False, '좋아... 아슬아슬했어!\n정말 무서운 무술이야!', True)
        fight.end()
        stage.unit(6).retreatTxt(False)
        stage.unit(6).hide(1)
        vars[62] = 1
        if not vars[63]:
            stage.unit(7).setDir(stage.countDir(7, 36))
            stage.unit(7).setAction(4)
            stage.say('&7\n아, 장군 하후연!\n어떻게 이런 일이 일어날 수 있지!?\n이미 그와 가까이 가지 말라고 했잖아......')
        if not vars[61]:
            stage.unit(29).setDir(stage.countDir(29, 36))
            stage.unit(29).setAction(8)
            stage.say('&29\n와, 더 이상 못 하겠어!\n뜻밖에도 샤후우 장군조차 패배했다......')
        if not vars[64]:
            stage.unit(12).setDir(stage.countDir(12, 36))
            stage.unit(12).setAction(4)
            stage.say('&12\n뭐... 뭐라고?\n하후연General!')
        vars[40] = 1
    if not vars[41] and stage.isNear(7, 36, True):
        stage.unit(36).setDir(stage.countDir(36, 7))
        stage.unit(7).setDir(stage.countDir(7, 36))
        stage.say('&36\n아, 그러니까 화살표도 쓰시네요?\n흥미롭네요, 몇 가지 기술을 가르쳐드릴게요.\n헤헤헤.\n&7\n알려드릴게요......\n이미 나이가 많다는 사실.')
        vars[41] = 1
    if not vars[42] and stage.isNear(12, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 12))
        stage.unit(12).setDir(stage.countDir(12, 57))
        stage.say('&57\n오늘이 네가 죽는 날이야!\n목숨을 내놓아!\n&12\n음, 어떻게 그렇게 말도 안 돼!\n아직 진 적 없어!')
        vars[42] = 1
    if not vars[43] and stage.isNear(7, 63, False):
        stage.unit(7).setDir(stage.countDir(7, 63))
        stage.unit(63).setDir(stage.countDir(63, 7))
        stage.say('&63\n그냥 순종적으로 운명을 받아들여라!\n&7\n나를 만나면 네 운이 다할 거야.\n네가 궁지에 몰려서 갈 곳이 없다는 걸 알아줬으면 해!')
        fight = stage.startFight(7, 63, 0)
        fight.showUnit(False, '정말 나를 절박한 상황에 몰아넣겠어?\n말도 안 돼!', 10)
        fight.showUnit(True, '믿지 않지?\n내가 증명해 보여줄게.', 0)
        fight.showStart()
        fight.setAction(False, 8)
        fight.say(False, '잔소리 좀 하네!\n내 칼 가져가!', True)
        fight.setAction(False, 2)
        fight.attack1(False, 4, True)
        stage.delay(10)
        fight.setAction(True, 8)
        fight.say(True, '다시 말할게,\n죽음을 맞이하는 건 너야!', True)
        fight.setAction(False, 1)
        fight.say(False, '음, 아하!', True)
        fight.setAction(False, 4)
        fight.attack1(True, 0, True)
        stage.delay(10)
        fight.setAction(False, 11)
        fight.say(False, '말도 안 돼!', True)
        fight.death(True)
        fight.setAction(True, 1)
        fight.say(True, '자신의 상황조차 모른 채,\n그런 사람은 군사 장군이라 불릴 자격이 없다.', True)
        fight.setAction(True, 4)
        fight.say(True, '운전해!', True)
        fight.setAction(True, 3)
        fight.setAction(True, 2)
        fight.setAction(True, 13)
        fight.end()
        stage.unit(63).hide(2)
        stage.getItem(127, -1, True, 7)
        vars[56] = 1
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(36, 7, 0, 2):
        stage.say('&36\n장난! 내가 정말 나이 들었나......\n아니, 그냥 운이 나쁜 거야!\n먼저 후퇴하자!')
        stage.unit(36).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(48, 7, 0, 2):
        stage.say('&48\n음, 나 방금 크게 공중제비를 돌았어!\n여기서 목숨을 잃을 줄은 전혀 예상하지 못했어요.........\n하지만 오늘까지 살아남는 것만으로도 충분해...... 흠.')
        stage.unit(48).hide(2)
        stage.getItem(120, -1, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n너무 부주의했어.........\n후퇴!')
        stage.unit(34).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(38, 7, 0, 2):
        stage.say('&38\n뭔가 이상해! 후퇴해.')
        stage.unit(38).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n이-어떻게 이게 가능하지!?\n흠, 어떻게 아버지를 이렇게 복수하라는 거지?\n후퇴!')
        stage.unit(57).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n더는 못 참겠어.\n여기서 죽을 이유가 없어!\n후퇴!')
        stage.unit(37).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(63, 7, 0, 2):
        stage.say('&63\n아-아, 안 돼!\n말도 안 돼!')
        stage.unit(63).hide(2)
        stage.getItem(127, -1, True, 1027)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(65, 7, 0, 2):
        stage.say('&65\n운이 없었어!\n난 떠난다, 후퇴!')
        stage.unit(65).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(45, 7, 0, 2):
        stage.say('&45\n도와줘, 도와줘!\n서둘러, 서둘러 도망가......')
        stage.unit(45).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(62, 7, 0, 2):
        stage.say('&62\n선택의 여지가 없어, 후퇴해!')
        stage.unit(62).hide(2)
        stage.getItem(118, -1, True, 1027)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(3, 7, 0, 2):
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(29, 7, 0, 2):
        stage.say('&29\n와! 정말 장군이 되지 말았어야 했는데.\n아직 죽고 싶지 않아......... 정말이야.')
        stage.unit(29).hide(2)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(6, 7, 0, 2):
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(7, 7, 0, 2):
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(12, 7, 0, 2):
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(35, 7, 0, 2):
        vars[65] = 1
    if not vars[0] and stage.winTest():
        stage.talk(7, 186, '어? 적이 후퇴하고 있어!')
        if not vars[62]:
            stage.say('&6\n드-드디어 버텨?')
        stage.unit(35).show(12, 34, 0)
        stage.say('&35\n(흠, 이건 여전히 안 될 것 같네,\n북쪽으로 진격하지 못하면...... )\n&35\n!? 조의 군대는 꽤 끈질겼다!\n그들은 실제로 우리 슈 군대를 격퇴하는 데 성공했습니다.\n그렇다면 나도 후퇴해야겠다!\n&35\n지금, 동오의 기습 공격 아래, 징저우\n그들은 실패의 운명을 피하지 못할 가능성이 큽니다.\n참고로, 어쩌면 유비 ...... 하하하.')
        stage.unit(35).hide()
        stage.reward(0, [
            140,
            -1])
        stage.end()
        vars[0] = 1
        vars[646] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조의 군대는 유비군 앞에서 참패를 당하고 후퇴했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
