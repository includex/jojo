# Source Generated with Decompyle++
# File: S_05.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        24,
        25,
        26], [
        '(19,13)',
        '(15,9)',
        '(7,12)',
        '(17,2)',
        '(16,21)'])
    stage.nearEvent([
        0,
        145,
        0,
        41,
        0,
        32], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, 145, 0, 0, 1)
    stage.createEnemy(
        [{'id': 145, 'x': 19, 'y': 12, 'dir': 3, 'lv': 4, 'i': 0},
         {'id': 41, 'x': 19, 'y': 13, 'dir': 3, 'lv': 6, 'i': 1},
         {'id': 210, 'x': 15, 'y': 10, 'dir': 3, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 15, 'y': 11, 'dir': 3, 'lv': 0, 'i': 3},
         {'id': 212, 'x': 15, 'y': 12, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 213, 'x': 15, 'y': 13, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 214, 'x': 18, 'y': 7, 'dir': 3, 'lv': 0, 'i': 6},
         {'id': 215, 'x': 19, 'y': 7, 'dir': 3, 'lv': 0, 'i': 7},
         {'id': 216, 'x': 18, 'y': 16, 'dir': 3, 'lv': 0, 'i': 8},
         {'id': 217, 'x': 19, 'y': 16, 'dir': 3, 'lv': 0, 'i': 9},
         {'id': 234, 'x': 20, 'y': 9, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 10},
         {'id': 235, 'x': 18, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 11},
         {'id': 236, 'x': 18, 'y': 14, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 237, 'x': 20, 'y': 15, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 13},
         {'id': 218, 'x': 7, 'y': 11, 'dir': 3, 'lv': 0, 'i': 14},
         {'id': 219, 'x': 7, 'y': 12, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 220, 'x': 7, 'y': 13, 'dir': 3, 'lv': 0, 'i': 16},
         {'id': 238, 'x': 8, 'y': 12, 'dir': 3, 'lv': 0, 'i': 17},
         {'id': 258, 'x': 12, 'y': 10, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 259, 'x': 12, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 260, 'x': 12, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 261, 'x': 12, 'y': 13, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 282, 'x': 13, 'y': 11, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 283, 'x': 13, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 221, 'x': 17, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 24},
         {'id': 222, 'x': 18, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 25},
         {'id': 239, 'x': 17, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 26},
         {'id': 223, 'x': 16, 'y': 21, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 27},
         {'id': 224, 'x': 17, 'y': 20, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 240, 'x': 16, 'y': 22, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 32, 'yj': 1, 'hide': 1, 'x': 22, 'y': 1, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 30},
         {'id': 3, 'yj': 1, 'hide': 1, 'x': 21, 'y': 1, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 31},
         {'id': 33, 'yj': 1, 'hide': 1, 'x': 21, 'y': 2, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 32},
         {'id': 34, 'yj': 1, 'hide': 1, 'x': 22, 'y': 2, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 33},
         {'id': 298, 'x': 17, 'y': 12, 'dir': 3, 'lv': 0, 'ai': 0, 'i': 34}]
    )
    stage.createMine([
        {
            'idx': 0,
            'y': 12,
            'dir': 1 },
        {
            'idx': 1,
            'y': 11,
            'dir': 1 },
        {
            'idx': 2,
            'y': 13,
            'dir': 1 },
        {
            'idx': 3,
            'x': 1,
            'y': 12,
            'dir': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 11,
            'dir': 1 },
        {
            'idx': 5,
            'x': 1,
            'y': 13,
            'dir': 1 },
        {
            'idx': 6,
            'x': 1,
            'y': 10,
            'dir': 1 },
        {
            'idx': 7,
            'x': 1,
            'y': 14,
            'dir': 1 },
        {
            'idx': 8,
            'y': 10,
            'dir': 1 },
        {
            'idx': 9,
            'y': 14,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(145, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(41, -1, 0, -1, 0, 23)
    stage.loadBg(5)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab29')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab29')
    stage.draw()
    stage.bgSound(5)
    stage.unit(0).setAction(5)
    stage.say('&0\n이제 서저우 공격을 시작하라.\n&0\n(이 혼란스러운 세상에서 내 이름을 알리고 싶다,\n아버지의 복수를 하는 것이 왕국을 평정하는 첫걸음이 될 것이다. )')
    stage.unit(0).setAction(0)
    stage.say('&22\n(이것이 내가 처음으로 참여한 전투였다,\n첫째, 그는 군사 .......에서 자신의 입지를 확립해야 했다 )\n&21\n(전략가는 무엇을 해야 할까요?\n이 전투가 나의 기준점이 될까......? )\n&145\n부하들조차 제대로 관리하지 못했다,\n정말 나이 들었도겸 ......\n&145\n하지만 이제는 후회하기엔 너무 늦었다.\n주지사로서 이곳을 지킬 의무가 있습니다,\n머리를 넘기는 것이 이 문제를 끝낼 수 있다면.........')
    stage.unit(41).setDir(stage.countDir(41, 145))
    stage.say('&41\n주군, 절대 안 돼!\n조조 아버지의 복수를 위한 것은 단지 핑계일 뿐이었다,\n그의 진짜 목표는 쉬저우였다.\n&41\n이 전투는 이미 조조의 야망을 드러냈다,\n그가 이곳을 다스린다면, 백성들에게 불행이 될 것이다.\n두 번 생각해 주세요!\n&145\n하지만 우리는 조의 군대를 막을 수 없었다......\n이대로 계속되면 무고한 민간인들만 해를 끼칠 것입니다.\n&41\n분명히 의로운 힘이 구하러 올 것이다,\n절망하지 마.')
    stage.unit(41).setDir(3)
    stage.setWinCondition('승리 조건\n1. 도겸 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('도겸 격퇴해!')
    stage.unit(145).heightLight()
    stage.startOper()
    vars[505] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 8:
        stage.unit(32).show()
        stage.unit(3).show()
        stage.unit(33).show()
        stage.unit(34).show()
        stage.say('&32\n흠! 전투는 이미 시작됐어.\n그는 조조가 그런 일을 할 거라고는 전혀 예상하지 못했다......\n&3\n겉으로는 아버지의 복수를 위해서였다,\n하지만 나는 그의 세계 정복 야망을 느꼈다,\n이번에는 반드시 그를 막아야 해.\n&32\n흠! 먼저 설득해 보자.\n&34\n물론 그녀가 들을 수 있다면 최선이겠지만, 그녀는 두려웠.......')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.say('&32\n조공은 어디 있지?\n조 공에게 할 말이 있어!\n지금은 그만해 주세요.')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n유현덕! 이 전투는 아버지의 복수를 위한 것이었어,\n간섭하지 마.\n&32\n도군님 상황은 알지만, 괜찮으시다\n야망—이 문제에 오해가 있을 것이다,\n사실 그는 악의...... 없었다.\n&0\n아버지의 죽음은 확실한 사실입니다,\n도겸의 성격과는 아무 상관이 없습니다.\n&32\n이 문제는 국가의 안전에 관한 것입니다.\n개인적인 원한은 제쳐두세요.\n&0\n네가 그렇게 말해도 난 못 해!')
        stage.unit(32).setAction(10)
        stage.unit(32).setAction(4)
        stage.say('&32\n무슨 ......? 혹시 제가 누군가를 잘못 판단유비 걸까요!\n세상을 생각하는 줄 알았는데, 뜻밖에조맹덕!\n&0\n물론, 한때 세상을 생각했지만, 쉬안더,\n당신의 방법을 사용한다면, 세상을 바꿀 수는 없습니다.')
        stage.unit(22).setDir(stage.countDir(22, 0))
        stage.talk(22, 186, '주군, 잠깐 할 말 좀 있을까...\n그래서 .......')
        stage.say('(뭐라고!? 여포가 부여를 공격한다고!) (눈앞에서 서주를 함락할 것 같은데, 이때 어떻게 해야 할까……?)')
        sel = stage.choice('평화 회담은 즉시 푸양으로 옮겨갔다\n계속 campaign도겸', -1)
        if sel == 1:
            stage.say('&0\n유현덕! 이번엔 체면 좀 보여줄게,\n나는 화해하기로 동의했어.\n&32\n그래? 네가 동의했잖아!\n&0\n하지만 다음에 나한테 문제 일으키면,\n나는 숨기지 않는다, 기억해.')
            stage.unit(145).setDir(stage.countDir(145, 0))
            stage.say('&145\n조 공, 잠시만 기다려 주십시오,\n이 은갑옷을 받아주세요.\n&145\n우리가 악의가 없음을 보여주기 위해,\n이 보물을 줄게.')
            stage.unit(0).setDir(stage.countDir(0, 145))
            stage.getItem(81, 0)
            stage.say('&0\n좋아, 그럼 내가 할게.')
            stage.unit(0).setDir(3)
            stage.unit(0).setAction(5)
            stage.say('&0\n군대 전체가 철수하여 즉시 푸양으로 돌아갔다.')
            stage.unit(0).setAction(0)
            stage.unit(0).setDir(stage.countDir(0, 32))
            stage.say('&0\n유비! 도시도, 군인도 없고,\n아이디어만 해도 뭐든 할 수 있어요!\n&0\n세상을 생각하는 법만 알고,\n모든 사람을 고려하는 것은 불가능합니다.')
            stage.setRectUnitHide(0, 0, 23, 23, 0)
            stage.unit(32).setDir(stage.countDir(32, 3))
            stage.say('&32\n마침내 갈등이 진정되었다,\n하지만, .......')
            stage.unit(3).setDir(stage.countDir(3, 32))
            stage.say('&3\n그래서 이게 세상을 평정조조 방법인가요?\n&32\n현재 상황으로는 아마도 아무것도 이룰 수 없을 것 같습니다.\n&3\n형, 쉬저우 백성 구출은 부인할 수 없는 사실입니다.\n이제 내가 할 수 있는 건 모든 것을 하늘에 맡기는 것뿐이야,\n우리만의 소속감을 찾게 만들었다.\n&32\n맞아.\n좋아, 공손찬 집으로 돌아가자.\n또한 원소의 행동에도 주의를 기울여야 합니다.')
            stage.unit(145).setDir(stage.countDir(145, 32))
            stage.say('&145\n쉬안더 씨, 감사합니다.\n갚을 일도 없어.')
            stage.unit(145).setDir(stage.countDir(145, 41))
            stage.say('&145\n미주, 축제 준비를 명령하라.')
            stage.unit(41).setDir(stage.countDir(41, 32))
            stage.talk(41, 41, '당신은 우리 쉬저우의 은인이시니까요,\n잘 대접하자.\n꼭 머물러 주세요.')
            stage.unit(32).setDir(stage.countDir(32, 145))
            stage.unit(3).setDir(stage.countDir(3, 145))
            stage.unit(33).setDir(stage.countDir(33, 145))
            stage.unit(34).setDir(stage.countDir(34, 145))
            stage.unit(145).setDir(stage.countDir(145, 32))
            stage.say('&32\n이런 작은 일은 마음에 담을 필요가 없다,\n우리는 단지 정의를 수호하기 위해 여기 있을 뿐입니다,\n이제 그는 다시 돌아가 보고해야 했다.\n&33\n누군가가 우리를 즐겁게 해주는 건 드문 일이니까, 그냥 받아들여, 형.\n이 행진 후에도 그들의 배는 이미 비어 있었다!\n그럼 형님을 대신해 미리 감사드릴게요!\n&32\n안녕, 셋째 형.........\n됐어, 거절할 수 없어.\n좋아, 그럼 도군님의 은혜를 받아들이겠다.\n&3\n흠! 도겸Sir, 친절한 환대에 감사드립니다."\n&145\n전혀요. 어서, 어서!\n부끄러워하지 마세요.')
            stage.reward()
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[605] = 1
            return True
        if sel == 2:
            stage.say('(거의 서주를 함락시킬 지경인데, 무슨 일이 있어도 포기할 수 없어.)\n별말 필요 없다! 살고 싶으면 피하면 돼!\n곁에 있는 어려움에 처한 사람을 돕는 것은 언제나 나의 유비의 방식이었어! 나는 결코 물러서지 않을 거야!')
            stage.unit(33).setDir(stage.countDir(33, 0))
            stage.unit(33).setAction(5)
            stage.say('&33\n협상이 이미 무산된 것 같아!\n좋아, 싸우자!')
            stage.unit(33).setAction(0)
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 19, 13):
        stage.getItem(157, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 15, 9):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[24] and stage.isInPos(1025, 7, 12):
        stage.getItem(150, 0, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 17, 2):
        stage.getItem(150, 0, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 16, 21):
        stage.getItem(150, 0, True, 1025)
        vars[26] = 1
    if not vars[30] and stage.isInRect(1025, 5, 0, 23, 23):
        stage.unit(218).setAI(0)
        stage.unit(219).setAI(0)
        stage.unit(220).setAI(0)
        stage.unit(238).setAI(0)
        vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 15, 7, 21, 16):
        stage.unit(145).setAction(4)
        stage.say('&145\n내 시간이 ...... 온 걸까?')
        stage.unit(41).setDir(stage.countDir(41, 145))
        stage.say('&41\n주군... 그렇다면\n전군을 동원해 싸우는 것뿐조조')
        stage.unit(41).setDir(stage.countDir(41, 0))
        stage.unit(41).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(221).setAI(1)
        stage.unit(222).setAI(1)
        stage.unit(223).setAI(1)
        stage.unit(224).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(239).setAI(1)
        stage.unit(240).setAI(1)
        vars[31] = 1
    if not vars[40] and stage.isNear(0, 145, True):
        stage.unit(0).setDir(stage.countDir(0, 145))
        stage.unit(145).setDir(stage.countDir(145, 0))
        stage.say('&0\n도겸, 일어나야 해!\n&145\n이제 더 이상 할 말이 없는 것 같습니다......')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 41, True):
        stage.unit(41).setDir(stage.countDir(41, 0))
        stage.unit(0).setDir(stage.countDir(0, 41))
        stage.say('&41\n조송의 죽음은 우리 잘못이다,\n요즘은 더 이상 할 말이 없습니다.\n&41\n하지만 조조가 서주를 병합하려 한다면,\n나, 미주는 한 발짝도 물러서지 않을 것이다.\n&0\n세상의 영웅들과 맞서려면 당연히 힘이 필요하지!\n그래서 이번에는, 여러분이 직접 뿌린 씨앗들이,\n내가 할 수 있는 말은, 네 불운이라는 거야!\n&41\n젠장, 이 ...... 정말 쉬저우를 겨냥한 거야.')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 32, True):
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&32\n조조!\n&0\n유비!')
        stage.unit(32).setAction(6)
        stage.unit(0).setAction(6)
        stage.say('&0\n우리는 같은 야망을 공유하지만, 같은 길을 걷고 있습니다\n하지만 이건 달라... 정말 믿기 힘들어,\n다시 만날 시간이 꽤 남았네요!')
        stage.unit(32).setAction(0)
        stage.unit(0).setAction(0)
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(145, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&145\n내 목숨을 원한다면 언제든 가져가도 돼.\n하지만...... 쉬저우 사람들은 무죄입니다,\n그들을 해치면 안 됩니다.')
        stage.getItem(81, 0)
        stage.unit(0).setDir(stage.countDir(0, 145))
        stage.say('&0\n나는 쉬저우 사람들을 학살할 생각이 없다,\n걱정 마.')
        stage.talk(21, 186, '조조주군, 보도가 푸양에서 들어왔어...\n수비군은 여포과의 전투에서 패배했고, 푸양은 함락되었다.......')
        stage.say('&0\n뭐라고! 미운 여포!\n&0\n(쉬저우를 진정할 시간은 남지 않았다,\n우리는 푸양을 되찾아야 합니다. )\n도겸, 지금은 네 개 목숨을 지켜.')
        stage.unit(0).setDir(3)
        stage.unit(0).setAction(5)
        stage.say('&0\n군대 전체를 후퇴시켜라! 즉시 후퇴하라!\n우리는 푸양을 되찾아야 합니다.')
        stage.unit(0).setAction(0)
        vars[50] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[101] = 1
        vars[605] = 1
        return True
    if not vars[51] and stage.unitStateTest(41, 7, 0, 2):
        stage.say('&41\n주님, 주군...... 내 마음은 풍요하지만 내 힘은 부족하다,\n그들이 먼저 후퇴했다.')
        stage.unit(41).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n이 잔혹 행위를 멈추고 싶지만...\n안타깝게도 마음은 원하지만, 힘은 부족하다......\n정말 안타깝네요!')
        stage.unit(32).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n젠장, 진짜 이 녀석들한테 졌어......!\n한숨, 후퇴, 후퇴!')
        stage.unit(33).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(3, 7, 0, 2):
        stage.say('&3\n음, 조의 군대가 점점 강해지고 있어.\n후퇴.')
        stage.unit(3).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n응, 응.......\n정말 안타깝네요; 철수가 필요해 보입니다.')
        stage.unit(34).hide(1)
        vars[55] = 1
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n훌륭해! 마침내 적을 전멸시켰다.\n드디어 아군 이겼어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[605] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 도겸군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
