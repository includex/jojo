# Source Generated with Decompyle++
# File: S_44.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(10,33)',
        '(11,33)',
        '(10,32)',
        '(11,32)'])
    stage.nearEvent([
        0,
        35,
        0,
        76], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, 35, 0, 0, 1)
    stage.createEnemy(
        [{'id': 35, 'x': 11, 'y': 33, 'dir': 0, 'lv': 6, 'i': 0},
         {'id': 76, 'x': 10, 'y': 33, 'dir': 0, 'lv': 6, 'i': 1},
         {'id': 78, 'x': 10, 'y': 32, 'dir': 0, 'lv': 6, 'i': 2},
         {'id': 88, 'x': 11, 'y': 32, 'dir': 0, 'lv': 4, 'i': 3},
         {'id': 82, 'x': 10, 'y': 25, 'dir': 0, 'lv': 4, 'i': 4},
         {'id': 96, 'x': 11, 'y': 25, 'dir': 0, 'lv': 4, 'i': 5},
         {'id': 85, 'x': 12, 'y': 25, 'dir': 0, 'lv': 6, 'i': 6},
         {'id': 92, 'x': 11, 'y': 26, 'dir': 0, 'lv': 4, 'i': 7},
         {'id': 83, 'x': 12, 'y': 26, 'dir': 0, 'lv': 4, 'i': 8},
         {'id': 79, 'x': 12, 'y': 27, 'dir': 0, 'lv': 6, 'i': 9},
         {'id': 210, 'x': 13, 'y': 25, 'dir': 0, 'lv': 0, 'i': 10},
         {'id': 234, 'x': 10, 'y': 26, 'dir': 0, 'lv': 0, 'i': 11},
         {'id': 235, 'x': 13, 'y': 26, 'dir': 0, 'lv': 0, 'i': 12},
         {'id': 86, 'x': 11, 'y': 23, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 13},
         {'id': 87, 'x': 12, 'y': 23, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 14},
         {'id': 358, 'x': 10, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 359, 'x': 11, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 360, 'x': 12, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 361, 'x': 13, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 362, 'x': 10, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 363, 'x': 13, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 81, 'hide': 1, 'x': 22, 'y': 17, 'dir': 3, 'lv': 6, 'ai': 1, 'i': 21},
         {'id': 364, 'hide': 1, 'x': 21, 'y': 15, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 365, 'hide': 1, 'x': 21, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 366, 'hide': 1, 'x': 21, 'y': 17, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 367, 'hide': 1, 'x': 21, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 368, 'hide': 1, 'x': 22, 'y': 15, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 369, 'hide': 1, 'x': 22, 'y': 16, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 370, 'hide': 1, 'x': 22, 'y': 18, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 28},
         {'id': 69, 'hide': 1, 'x': 3, 'y': 38, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 29},
         {'id': 72, 'hide': 1, 'x': 5, 'y': 38, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 30},
         {'id': 71, 'hide': 1, 'x': 4, 'y': 37, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 31},
         {'id': 73, 'hide': 1, 'x': 3, 'y': 36, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 32},
         {'id': 310, 'hide': 1, 'x': 5, 'y': 39, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 33},
         {'id': 382, 'hide': 1, 'x': 4, 'y': 38, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 34},
         {'id': 390, 'hide': 1, 'x': 3, 'y': 37, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 35},
         {'id': 350, 'hide': 1, 'x': 4, 'y': 39, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 36},
         {'id': 414, 'hide': 1, 'x': 10, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 37},
         {'id': 415, 'hide': 1, 'x': 9, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 38},
         {'id': 416, 'hide': 1, 'x': 9, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 39},
         {'id': 417, 'hide': 1, 'x': 9, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 40},
         {'id': 418, 'hide': 1, 'x': 11, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 419, 'hide': 1, 'x': 12, 'y': 31, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 42},
         {'id': 420, 'hide': 1, 'x': 12, 'y': 32, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 43},
         {'id': 421, 'hide': 1, 'x': 12, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 44}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 12,
            'y': 12 },
        {
            'idx': 1,
            'x': 13,
            'y': 12 },
        {
            'idx': 2,
            'x': 12,
            'y': 13 },
        {
            'idx': 3,
            'x': 13,
            'y': 13 },
        {
            'idx': 4,
            'x': 11,
            'y': 13 },
        {
            'idx': 5,
            'x': 14,
            'y': 13 },
        {
            'idx': 6,
            'x': 11,
            'y': 12 },
        {
            'idx': 7,
            'x': 14,
            'y': 12 },
        {
            'idx': 8,
            'x': 12,
            'y': 8 },
        {
            'idx': 9,
            'x': 13,
            'y': 8 },
        {
            'idx': 10,
            'x': 11,
            'y': 8 },
        {
            'idx': 11,
            'x': 14,
            'y': 8 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(79, 54, 0, -1, 0, -1)
    stage.setEnemyEquip(85, -1, 0, -1, 0, 3)
    stage.setEnemyEquip(82, -1, 0, -1, 0, 11)
    stage.setEnemyEquip(83, -1, 0, 15, 0, -1)
    stage.loadBg(44)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab28')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab28')
    stage.draw()
    stage.bgSound(6)
    stage.unit(76).setDir(stage.countDir(76, 88))
    stage.say('&76\n장자오.\n아직도 이 전쟁에 반대하십니까?')
    stage.unit(88).setDir(stage.countDir(88, 76))
    stage.say('&88\n서나라가 멸망한 후, 조조의 군대는 동오를 목표로 삼았다.\n장기적인 계획을 위해 더 이상 평화 회담을 제안하지 않겠습니다.\n이제는 죽을 때까지 싸워야만 희망의 빛이 생길 수 있었다.')
    stage.unit(78).setDir(stage.countDir(78, 0))
    stage.say('&78\n조의 군대가 언제 공격할지 궁금하네......\n그들이 맞은편 강둑에 진형을 갖추자 더 이상의 움직임은 없었다.')
    stage.unit(35).setDir(stage.countDir(35, 0))
    stage.say('&35\n분명히 공격할 기회를 노리고 있을 거야!\n해전이 오나라에 유리했기 때문입니다.')
    stage.unit(76).setDir(stage.countDir(76, 0))
    stage.say('&76\n하지만 우리가 이미 여기서 싸웠으니,\n빈손으로 그냥 나갈 수는 없어.\n아마 공격하려는 거야?')
    stage.unit(35).setDir(stage.countDir(35, 76))
    stage.say('&35\n또한 그 때가 왔다고 느낍니다.\n장군육손 잘 준비하고 계신가요?"')
    stage.unit(76).setDir(stage.countDir(76, 35))
    stage.say('&76\n흠, 문제 없을 거예요.\n공명 장군님, 증원군은 어떻게 되나요?\n&35\n아군 먼 남쪽 야만인들로부터 왔다,\n조금 더 기다려야 할 것 같아요.\n&76\n정말? 시간 못 맞출 것 같아.')
    stage.unit(0).setDir(stage.countDir(0, 76))
    stage.say('적이 왜 아무런 움직임이 없어? 그냥 우리가 강을 건너오길 기다리는 거야? 손권은 정말 치밀하구나! 어떻게 하지? 적군이 스스로 참지 못하고 뛰쳐나올 때까지 기다릴까? 아니면 한 번에 뚫고 나아갈까?')
    sel = stage.choice('그리고 캠프에서 조용히 기다렸다\n전면 공세였다', -1)
    if sel == 1:
        stage.say('&0\n우리는 해상 전투에 능하지 않다.\n우리는 손권군이 스스로 싸우길 기다릴 수밖에 없어!\n그들은 분명히 우리를 자극하러 올 것이다.')
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&76\n도둑조조Old, 소모전을 하려는 거야?"\n좋아, 지원군도 기다리고 있어.\n&82\n조조 군대가 공격하지 않을까?\n&96\n그들은 물에서 싸우고 싶어 하지 않는가?\n&85\n기다리는 게 제일 싫어요!\n그들이 공격하지 않으면,\n그냥 싸우며 뚫고 나가자!')
        stage.unit(35).setDir(stage.countDir(35, 85))
        stage.say('&35\n절대 아니에요.\n해안을 지키고 성급하게 행동하지 말아 주세요.')
        stage.unit(85).setDir(stage.countDir(85, 35))
        stage.say('&85\n음, 더 이상 참을 수가 없어.')
        stage.unit(79).setDir(stage.countDir(79, 85))
        stage.say('&79\n그가 맞아.\n우리 증원군이 곧 도착할 거야,\n지원군이 도착할 때까지 기다리는 게 낫다!\n&92\n더는 못 참겠어, 하품이 올 것 같아.\n&83\n이것이 명령이므로,\n우리가 할 수 있는 건 기다리는 것뿐이야.\n&0\n흠, 아직도 아무 소식 없어?')
        stage.unit(69).show()
        stage.unit(73).show()
        stage.unit(71).show()
        stage.unit(72).show()
        stage.unit(390).show()
        stage.unit(382).show()
        stage.unit(310).show()
        stage.unit(350).show()
        stage.unit(69).setDir(stage.countDir(69, 35))
        stage.unit(73).setDir(stage.countDir(73, 35))
        stage.unit(71).setDir(stage.countDir(71, 35))
        stage.unit(72).setDir(stage.countDir(72, 35))
        stage.say('&69\n공명Sir, 늦어서 미안해!"\n&73\n왜 이렇게 조용하지!\n&71\n아직 싸움도 안 시작했어?\n&72\n전투 전 긴장된 분위기가 참 멋지다,\n가장 흥미로운 것.')
        stage.unit(76).setAction(5)
        stage.say('&76\n좋아! 육손 가서 싸워!\n이제 모든 병력이 도착했다.\n전 군대를 동원해 전면 공격을 개시하라!')
        stage.unit(76).setAction(0)
        stage.unit(364).show()
        stage.unit(365).show()
        stage.unit(366).show()
        stage.unit(367).show()
        stage.unit(368).show()
        stage.unit(369).show()
        stage.unit(81).show()
        stage.unit(370).show()
        stage.unit(81).setAction(5)
        stage.say('&81\n손권주군.\n육손 싸우고 있어!')
        stage.unit(81).setAction(0)
        stage.say('&86\n좋아!\n우리 트롤들이 얼마나 강력한지 알려주세요!\n&87\n하하하!')
        stage.unit(85).setDir(stage.countDir(85, 0))
        stage.unit(85).setAction(5)
        stage.say('&85\n마침내 전투 명령을 내렸다.\n좋아! 내 답답함을 털어놓고 싶어.\n전면 행군!')
        stage.unit(85).setAction(0)
        stage.say('&0\n흠, 그래서 그들은 증원군이 도착하기를 기다리고 있었던 거군요.\n아마도 공명의 또 다른 계획일 거야, 그렇지?\n공명This 녀석은 진작에 처리됐어야 했어.\n&0\n병력을 전면 동원해 맞서라!')
        stage.setAI(0, 0, 23, 39, 2, 1)
        stage.unit(35).setAI(0)
        stage.unit(76).setAI(0)
        stage.unit(78).setAI(0)
        stage.unit(88).setAI(0)
        stage.setMaxRound(15)
        stage.bgSound(5)
        stage.setWinCondition('승리 조건\n1. 패배 제갈량.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 15를 초과한다.')
        stage.showWinCondition('제갈량를 이겨라!')
        stage.unit(35).heightLight()
        vars[2] = 1
    elif sel == 2:
        stage.unit(0).setAction(5)
        stage.say('좋습니다! 공격합시다!\n적군이 방어 체계를 확립하기 전에,\n그들의 본거지를 점령합시다!')
        stage.unit(0).setAction(0)
        stage.unit(4, 1).move(11, 16, 2)
        stage.unit(2, 1).move(12, 16, 2)
        stage.unit(3, 1).move(13, 16, 2)
        stage.unit(5, 1).move(14, 16, 2)
        stage.unit(6, 1).move(11, 15, 2)
        stage.unit(0, 1).move(12, 15, 2)
        stage.unit(1, 1).move(13, 15, 2)
        stage.unit(7, 1).move(14, 15, 2)
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.unit(76).setAction(5)
        stage.say('&76\n음, 조나라 군대가 움직이고 있어!\n장친, 저우타이!\n조조군이 상륙하지 못하게 하라,\n그들과 맞서기 위해서였다.')
        stage.unit(76).setAction(0)
        stage.say('&87\n헤헤헤.\n물은 우리의 영역입니다.\n&86\n가라! 모두, 적과 용감히 싸워라.\n&85\n힘들게 해!')
        stage.unit(35).setDir(stage.countDir(35, 85))
        stage.say('&35\n영통 장군, 해안에서 적을 막아야 합니다,\n절대 그들이 육지에 올라오는 것을 허용해서는 안 됩니다.')
        stage.unit(85).setDir(stage.countDir(85, 35))
        stage.say('&85\n음, 내가 할 수 있는 게 없어.\n판장과 딩펑은 지시를 따랐다!\n&82\n우리는 잘해야 해......\n&96\n이번에는 물에서 그들을 이기고 싶어,\n걱정 마.\n&83\n양측을 방어하는 임무는 우리에게 달려 있습니다!\n&92\n활과 화살을 사용해 적을 고슴도치로 만들어라!\n&79\n부상이 있으면 치료해 드리겠습니다.\n여러분, 어서 싸워라!')
        stage.unit(0).setAction(5)
        stage.say('&0\n이 입장의 방어는 괜찮습니다,\n군대 전체를 동원해 공격해라!\n&0\n첫째, 오군 내에서 전략을 세운 공명을 공격하라!\n저 녀석들을 물리치고, 죽여라공명!')
        stage.unit(0).setAction(0)
        stage.unit(4, 1).move(11, 19, 2)
        stage.unit(2, 1).move(12, 19, 2)
        stage.unit(3, 1).move(13, 19, 2)
        stage.unit(5, 1).move(14, 19, 2)
        stage.unit(6, 1).move(11, 18, 2)
        stage.unit(0, 1).move(12, 18, 2)
        stage.unit(1, 1).move(13, 18, 2)
        stage.unit(7, 1).move(14, 18, 2)
        stage.unit(8, 1).move(12, 13, 2)
        stage.unit(9, 1).move(13, 13, 2)
        stage.unit(10, 1).move(12, 12, 2)
        stage.unit(11, 1).move(13, 12, 2)
        stage.bgSound(5)
        stage.setWinCondition('승리 조건\n1. 패배 제갈량.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
        stage.showWinCondition('제갈량를 이겨라!')
        stage.unit(35).heightLight()
    stage.startOper()
    vars[544] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[2] and not vars[11] and stage.round() == 3 and stage.curCamp() == 2:
        stage.unit(35).setAction(5)
        stage.say('&35\n육손General, 전투에 나가세요!"')
        stage.unit(35).setAction(0)
        if not vars[55]:
            stage.say('&76\n좋아! 육손 가서 싸워!\n우리 트롤들이 얼마나 강력한지 알려주세요!')
        stage.unit(364).show()
        stage.unit(365).show()
        stage.unit(366).show()
        stage.unit(367).show()
        stage.unit(368).show()
        stage.unit(369).show()
        stage.unit(81).show()
        stage.unit(370).show()
        stage.say('&81\n육손 싸워!\n모든 장교와 병사들, 명령에 따르라!\n조조 군대를 물리쳐라!')
        vars[11] = 1
    if not vars[2] and not vars[12] and stage.round() == 8 and stage.curCamp() == 2:
        stage.unit(69).show()
        stage.unit(73).show()
        stage.unit(71).show()
        stage.unit(72).show()
        stage.unit(390).show()
        stage.unit(382).show()
        stage.unit(310).show()
        stage.unit(350).show()
        stage.unit(69).setDir(stage.countDir(69, 35))
        stage.unit(73).setDir(stage.countDir(73, 35))
        stage.unit(71).setDir(stage.countDir(71, 35))
        stage.unit(72).setDir(stage.countDir(72, 35))
        stage.say('&69\n공명Sir, 늦어서 미안해!"\n&73\n탈진해서 죽을 것 같아!\n&71\n벌써 시작됐어?\n내가 좀 더 일찍 왔어야 한다고 했잖아!\n&72\n승리의 여신, 주융이 도착했다.\n모두가 행복해야 합니다!\n하하하!')
        if not vars[55]:
            stage.unit(76).setDir(stage.countDir(76, 69))
            stage.say('&76\n아, 공명 씨의 증원군이 도착했지?')
        stage.unit(35).setDir(stage.countDir(35, 69))
        stage.unit(35).setAction(5)
        stage.say('&35\n드디어 따라잡았어.\n좋아, 장위, 너는 직접 조조 군대를 공격하러 가라.')
        stage.unit(35).setAction(0)
        stage.say('&69\n네!\n공명Sir, 제발 안심하세요!"')
        vars[12] = 1
    if vars[31] and not vars[2] and not vars[70] and stage.round() == 4:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[70] = 1
    if vars[31] and not vars[2] and not vars[71] and stage.round() == 7:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[71] = 1
    if vars[31] and not vars[2] and not vars[72] and stage.round() == 10:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[72] = 1
    if vars[31] and not vars[2] and not vars[73] and stage.round() == 13:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[73] = 1
    if vars[31] and not vars[2] and not vars[74] and stage.round() == 16:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[74] = 1
    if vars[31] and not vars[2] and not vars[75] and stage.round() == 19:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[75] = 1
    if vars[31] and not vars[2] and not vars[76] and stage.round() == 22:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[76] = 1
    if vars[31] and not vars[2] and not vars[77] and stage.round() == 25:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[77] = 1
    if vars[31] and not vars[2] and not vars[78] and stage.round() == 28:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[78] = 1
    if vars[31] and not vars[2] and not vars[79] and stage.round() == 31:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[79] = 1
    if vars[31] and not vars[2] and not vars[80] and stage.round() == 34:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[80] = 1
    if vars[31] and not vars[2] and not vars[81] and stage.round() == 37:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[81] = 1
    if vars[31] and not vars[2] and not vars[82] and stage.round() == 40:
        if not vars[58]:
            stage.unit(414).show(10, 31, 2)
            stage.unit(415).show(9, 31, 2)
            stage.unit(416).show(9, 32, 2)
            stage.unit(417).show(9, 33, 2)
        if not vars[57]:
            stage.unit(418).show(11, 31, 0)
            stage.unit(419).show(12, 31, 0)
            stage.unit(420).show(12, 32, 0)
            stage.unit(421).show(12, 33, 0)
        vars[82] = 1
    if not vars[20] and stage.isInPos(1025, 10, 33):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 11, 33):
        stage.getItem(154, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 10, 32):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 11, 32):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(35, 10, 33):
        stage.unit(35).setAI(2)
        vars[24] = 1
    if vars[2] and not vars[6] and stage.curCamp() == 2 and stage.totalRectUnit(2, 0, 0, 23, 26) < 9 and stage.totalUnit(0) >= 6:
        stage.resumeCtrl()
        stage.say('&35\n더 이상 승리의 기회는 없었다.\n일단 전군을 후퇴시켜라!')
        if not vars[55]:
            stage.say('&76\n지안예로 후퇴하는 것 외에는 다른 방법이 없었다.\n최종 결론이 다가오고 있는 것 같아.')
        if not vars[57]:
            stage.say('&88\n만약 누군가가 우나라를 지키고자 한다면,\n이제 우리는 잠시 후퇴할 수밖에 없어!')
        if not vars[58]:
            stage.say('&78\n한숨, 이러다간 우도 파괴될 거야.\n어떻게 해야 하지? 한숨!\n지안예로 돌아온 후에 생각해 봐......')
        stage.unit(35).setAction(5)
        stage.say('&35\n부상자들을 빨리 데려가라.\n전군을 후퇴시켜라!')
        stage.unit(35).setAction(0)
        stage.setRectUnitHide(0, 0, 23, 39, 2)
        vars[6] = 1
        stage.say('&0\n물러났다고? \n좋아, 이제 건업을 공격하는 것만 남았군.\n건업만 함락하면 난세를 평정할 수 있어!')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[644] = 1
        return True
    if not vars[2] and not vars[30] and stage.isInRect(1025, 9, 24, 14, 27) and stage.curCamp() == 2:
        if not vars[59]:
            stage.unit(85).setDir(stage.countDir(85, 0))
            stage.unit(85).setAction(5)
            stage.say('&85\n그들을 육지에 보내지 마!\n무슨 일이 있어도 그들을 막아야 해!')
            stage.unit(85).setAction(0)
        stage.unit(96).setAI(1)
        stage.unit(85).setAI(1)
        stage.unit(92).setAI(1)
        stage.unit(82).setAI(1)
        stage.unit(83).setAI(1)
        stage.unit(79).setAI(1)
        stage.unit(210).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        vars[30] = 1
    if not vars[2] and not vars[31] and not vars[55] and not vars[57] and not vars[58] and stage.curCamp() == 2 and stage.isInRect(1025, 8, 25, 15, 28):
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.unit(35).setAction(5)
        stage.say('&35\n마침내 그들은 상륙하는 데 성공했다.\n노숙 장군, 장조 장군이 당신을 믿고 있습니다.')
        stage.unit(35).setAction(0)
        if not vars[57]:
            stage.unit(88).setDir(stage.countDir(88, 0))
            stage.unit(88).setAction(5)
            stage.say('&88\n오를 지키기 위해 나무 인간들을 전쟁에 나가게 하라!\n적을 막는 철벽이 되어야 한다!')
            stage.unit(88).setAction(0)
            stage.unit(418).show()
            stage.unit(419).show()
            stage.unit(420).show()
            stage.unit(421).show()
        if not vars[58]:
            stage.unit(78).setDir(stage.countDir(78, 0))
            stage.unit(78).setAction(5)
            stage.say('&78\n세상에...... 뭔가 방법을 찾아야 해!\n나무 조각상들이여, 충성스러운 하인들이여,\n우리를 위해 적과 싸워라!')
            stage.unit(78).setAction(0)
            stage.unit(414).show()
            stage.unit(415).show()
            stage.unit(416).show()
            stage.unit(417).show()
        if not vars[55]:
            stage.unit(76).setDir(stage.countDir(76, 35))
            stage.say('&76\n나도 싸움에 합류할게!\n이제부터는 모든 것이 여러분에게 달려 있습니다.')
            stage.unit(76).setAI(1)
            stage.unit(35).setAI(6, -1, 10, 33)
        vars[31] = 1
    if not vars[40] and stage.isNear(0, 35, True):
        stage.unit(0).setDir(stage.countDir(0, 35))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.say('&0\n이 정도까지 저항하다니,\n정말 감탄스럽군.\n하지만 이제 모든 것은 끝이다!\n&35\n마지막 순간까지 절대 쉽게 포기할 수 없다.\n이미 돌아가신 선주 유비를 위해서라도,\n무슨 일이 있어도 끝까지 버티겠다……')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 76, True):
        stage.unit(0).setDir(stage.countDir(0, 76))
        stage.unit(76).setDir(stage.countDir(76, 0))
        stage.say('&0\n그가 손견의 아들인 것도 당연하다,\n꽤 인상적이야.\n&76\n내가 너를 이길 수 있다면,\n돌아가신 아버지와 형님은 기뻐하실 거예요.\n목숨을 내놓아!')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.resumeCtrl()
        stage.say('&35\n음, 이쯤 되니 그냥 .......\n후퇴!')
        stage.unit(35).hide(1)
        if not vars[55]:
            stage.unit(76).setAction(5)
            stage.say('&76\n공명 씨가 후퇴를 명령했으니,\n그럼 우리가 할 수 있는 게 없네.\n전군을 후퇴시켜라!')
            stage.unit(76).setAction(0)
            stage.unit(76).hide()
        stage.setRectUnitHide(0, 0, 31, 39, 2)
        vars[50] = 1
        stage.say('&0\n물러났다고? \n좋아, 이제 건업을 공격하는 것만 남았군.\n건업만 함락하면 난세를 평정할 수 있어!')
        stage.reward()
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[644] = 1
        return True
    if not vars[51] and stage.unitStateTest(81, 7, 0, 2):
        stage.say('&81\n음, 흠, 또 패배했어......\n하지만 전투의 결과는 끝까지 알 수 없었다.\n다음번에도 다시 최선을 다하겠습니다.')
        stage.unit(81).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(86, 7, 0, 2):
        stage.say('&86\n훗! 지금 후퇴하라고?')
        stage.unit(86).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(96, 7, 0, 2):
        stage.say('&96\n다른 방법은 없었다.\n일단 후퇴해!')
        stage.unit(96).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(82, 7, 0, 2):
        stage.say('&82\n길을 잃었어, 길을 잃었어.\n후퇴!')
        stage.unit(82).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(76, 7, 0, 2):
        stage.say('&76\n후퇴!\n그렇다면 건예에서 맞서자!')
        stage.unit(76).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(79, 7, 0, 2):
        stage.say('&79\n너무 부주의했어.\n후퇴!')
        stage.unit(79).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(88, 7, 0, 2):
        stage.say('&88\n흠, 여기서도 졌나?\n후퇴!')
        stage.unit(88).hide(1)
        stage.unit(418).hide()
        stage.unit(419).hide()
        stage.unit(420).hide()
        stage.unit(421).hide()
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(78, 7, 0, 2):
        stage.say('&78\n아! 용서해 주군어!\n노숙 더 이상 참을 수 없었다.\n먼저 후퇴하자!')
        stage.unit(78).hide(1)
        stage.unit(414).hide()
        stage.unit(415).hide()
        stage.unit(416).hide()
        stage.unit(417).hide()
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(85, 7, 0, 2):
        stage.say('&85\n그는 실제로 패배했다.\n이 굴욕을 갚아야 해.\n후퇴!')
        stage.unit(85).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(83, 7, 0, 2):
        stage.say('&83\n휴, 더 이상 싸울 수 없겠어.\n후퇴, 후퇴, 후퇴!')
        stage.unit(83).hide(1)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(92, 7, 0, 2):
        stage.say('&92\n아파, 아파!\n훗! 또 패배했어!\n도망쳐!')
        stage.unit(92).hide(1)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(87, 7, 0, 2):
        stage.say('&87\n와아!')
        stage.unit(87).hide(2)
        vars[62] = 1
    if not vars[63] and stage.unitStateTest(69, 7, 0, 2):
        stage.say('&69\n아니야.\n공명Sir, 장웨이가 먼저 물러난 것을 용서해 주세요!"')
        stage.unit(69).hide(1)
        vars[63] = 1
    if not vars[64] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n끊임없는 강행군이 아니었다면,\n이렇게 피곤하지 않았다면......\n후퇴! 더는 못 참겠어.')
        stage.unit(71).hide(1)
        vars[64] = 1
    if not vars[65] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&73\n다른 방법은 없었다.\n후퇴!\n응? 그런데 지안예는 어디 있어?')
        stage.unit(73).hide(1)
        vars[65] = 1
    if not vars[66] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n우리를 과소평가하지 마.\n조만간 복수는 반드시 이루어질 것이다.\n후퇴!')
        stage.unit(72).hide(1)
        vars[66] = 1
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n물러났다고? \n좋아, 이제 건업을 공격하는 것만 남았군.\n건업만 함락하면 난세를 평정할 수 있어!')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[644] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 연합군 앞에서 참패를 당했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
