# Source Generated with Decompyle++
# File: R_13.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.bgSound(16)
    stage.setMenuVisible(False)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(143, 251, 146)
    stage.showHead(0, 315, 146)
    stage.bottomTxt('조조 장수에 대한 원정은 반복적으로 패배했다.', False, False, False)
    stage.delay(5)
    stage.head(0).move(342, 111)
    stage.delay(5)
    stage.bottomTxt('서두로 돌아와야만 군사 훈련을 강화할 수 있었다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('이 시점에서,', True, True, False)
    stage.delay(5)
    stage.showHead(101, 390, 22)
    stage.delay(5)
    stage.bottomTxt('허베이의 원소', True, False, False)
    stage.delay(5)
    stage.showHead(161, 471, 1)
    stage.delay(5)
    stage.bottomTxt('공손찬 북평을 공격하기로 결정했다,', True, False, False)
    stage.delay(8)
    stage.bottomTxt('그는 조조에게 지원을 요청하기 위해 사절을 보냈다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1,
            5],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setEventName('여포 이겨라!')
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n원소 순진하게 나를 찾아왔어,\n그는 나한테 군인과 식량을 빌리고 싶어 해.\n&20\n병력과 군수품을 빌리는 게 ......?')
    stage.unit(0).setAction(0)
    stage.say('&0\n이 공격은 북평의 공손찬을 공격하기 위한 것이라고 전해진다.\n&22\n이 개인적인 고난 때문에......\n우리에게 그런 뻔뻔한 요구를 하다니.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n이 사람은 늘 이랬어.\n&20\n맞아요……. 주군은 어떻게 대답하시겠습니까?\n&0\n음.')
    stage.effectSound(202, 255)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('그는 조용히 동의했다.\n요청을 거절했다.', -1)
    if sel == 1:
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n그냥 그의 요청에 동의해.\n&20\n네.\n&0\n지금은 원소와 맞설 수 없었다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n문약, 관대한 면을 보여줘.\n이 way원소에서는 북평에 집중할 것이다.')
        stage.unit(0).setAction(17, 2)
        stage.say('&0\n우리는 이 기회를 잡아 외적을 제거해야 합니다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n그는 나중에 이 빚을 원소에게 되찾았다.')
        stage.unit(20).setAction(6, 2)
        stage.say('&20\n복종해.')
        vars[305] = 1
    elif sel == 2:
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(202, 0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n그의 요청을 거절해!')
        stage.unit(20).setAction(6)
        stage.say('&20\n주군, 제발 다시 생각해 봐.\n이 순간에는 견디고 동의하는 것이 최선의 전략원소 되었다.')
        stage.unit(22).setAction(6)
        stage.say('&22\n바로 그거예요.\n그렇지 않았다면 위안의 군대가 베이핑을 공격하지 않았을 것이다,\n대신 그들은 곧장 쉬두를 향해 향하고 있었다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n원소 안 올 거야.\n&22\n하지만 .......')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n원소 사람을 과소평가하지 마세요.\n북평이 위협이 된 상황에서,\n그가 나를 공격할 만큼 어리석진 않을 거야.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n이 짜증나는 녀석,\n분명히 저를 위한 시험이에요!')
        stage.unit(20).setAction(0)
        stage.say('&20\n테스트주군?\n&0\n나쁘지 않네. 그가 내가 너희 모두를 데려왔는지 보고 싶어 해......\n큰 그림을 보는 능력.')
        stage.unit(22).setAction(0)
        stage.say('&22\n……………。')
        stage.unit(0).move(34, 59, 2)
        stage.say('&0\n충동적으로 거절하면,\n그는 내가 그런 사람이라고 생각하는 모양이야.\n&20\n그래서 그렇게 된 거.......')
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n문약 그는 사절을 심하게 꾸짖고 그를 돌려보냈다.')
        stage.unit(0).move(34, 55, 0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.say('&0\n우리 주변에는 장수이 있습니다,\n제거해야 할 적들이 여포 많아.\n&0\n그들을 제거한 후,\n그리고 다시 한 번 원소 싸웠다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n그 전에는,\n그냥 그가 나를 깔보게 하려고 해봐.')
        stage.unit(20).setAction(6)
        stage.say('&20\n네.')
        vars[305] = 0
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            101,
            53,
            28,
            2],
        [
            113,
            68,
            48,
            3],
        [
            114,
            68,
            54,
            3],
        [
            115,
            68,
            60,
            3],
        [
            109,
            68,
            66,
            3],
        [
            106,
            38,
            48,
            1],
        [
            110,
            38,
            54,
            1],
        [
            102,
            38,
            60,
            1],
        [
            103,
            38,
            66,
            1],
        [
            193,
            53,
            48,
            0,
            6]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.info('며칠 후에......', 3)
    stage.setStageName('신두 원소 저택')
    if vars[305]:
        stage.say('&101\n아, 조조 남자가 내 요청을 받아들였어?\n&193\n네.\n제공된 병사들과 보급품은 우리가 요청한 것보다 훨씬 많았다.\n&106\n조조This 사람은 내가 상상했던 것보다 훨씬 더 솔직해 보인다.')
        stage.unit(101).setAction(0, 1)
        stage.say('&101\n응.\n조금 놀랐습니다.')
        stage.unit(101).setAction(0, 2)
        stage.delay(3)
        stage.unit(101).setAction(3)
        stage.say('&101\n좋아, 원래 계획대로 베이핑을 공격하자.')
        stage.unit(101).setAction(0)
        stage.delay(3)
        stage.unit(101).setAction(17)
        stage.say('&101\n내가 공손찬를 물리치면,\n허베이 전역이 내 거야!')
    if not vars[305]:
        stage.say('&101\n아, 조조 남자가 내 요청을 거절했어?\n&193\n네.\n심지어 크게 욕을 퍼부어 견디기 힘들게 만들었다.......\n&106\n조조 이 사람은 제가 상상했던 것보다 훨씬 더 감정적인 것 같아요.')
        stage.unit(101).setAction(0, 1)
        stage.say('&101\n응.\n조금 놀랐습니다.')
        stage.unit(101).setAction(0, 2)
        stage.say('&101\n흠, 이번 여행에서 수고하셨습니다, 사절님.')
        stage.unit(101).setAction(0, 0)
        stage.say('&101\n우리는 사실 아무것도 요구한 적이 없어요,\n그 후 원래 계획대로 베이핑을 공격하라.')
        stage.unit(101).setAction(0, 2)
        stage.delay(3)
        stage.unit(101).setAction(17, 2)
        stage.say('&101\n내가 공손찬를 물리치면,\n허베이 전역이 내 거야!')
    stage.effectSound(202, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, -1)
    stage.draw()
    stage.showHead(0, 342, 111)
    stage.showHead(101, 390, 22)
    stage.showHead(161, 471, 0)
    stage.bottomTxt('원소 답변을 받아조조,', False, False, False)
    stage.delay(5)
    stage.head(101).move(407, 0)
    stage.delay(5)
    stage.bottomTxt('북평을 공격하기 위해 병력이 파견되었다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene2():
    '''서두, 총리 관저'''
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            6,
            58,
            70],
        [
            5,
            64,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('막 보고를 받았습니다. 원소가 북평으로 출병했다고 합니다. 이건 우리에게도 좋은 기회입니다. 음.')
    stage.unit(0).setAction(17)
    stage.say('&0\n원소의 시선이 북평에 머물 때,\n우리가 먼저 외적을 섬멸하자.')
    stage.unit(0).setAction(0)
    stage.say('&0\n주요 적은 여포와 장수.......\n&0\n공다, 장수 뭐 있어?')
    stage.unit(24).setAction(6)
    stage.say('&24\n현재는 특수 기술이 없습니다.')
    stage.unit(24).setAction(0)
    stage.say('&0\n음, 비록 아군의 공격을 두 번이나 막았지만,\n지금은 방어적인 태도를 취하는 것이 더 낫다.\n&0\n아마 내 영역을 공격하지 않을 거야.')
    stage.unit(0).setAction(0, 2)
    stage.say('&0\n그렇다면 우리 쪽 여포을 공격합시다.')
    stage.unit(0).setAction(17, 2)
    stage.say('&0\n우리는 절대 이 기회를 놓칠 수 없습니다,\n우리는 여포을 벌해야 해.')
    stage.unit(0).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n문약, 사신을 샤오페이 유비로 보내라,\n그는 쉬저우 공격에 협조하라는 명령을 아군받았다.')
    stage.unit(20).setAction(6, 2)
    stage.say('&20\n네.')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(0).setAction(17, 1)
    stage.say('좋습니다, 출전합니다!')
    stage.effectSound(202, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 6)
    stage.showUnits([
        [
            119,
            69,
            55,
            3],
        [
            126,
            52,
            55,
            1]])
    stage.draw()
    stage.effectSound(202, 0)
    stage.delay(3)
    stage.setStageName('쉬저우 여포 관저')
    stage.delay(3)
    stage.unit(119).setAction(2)
    stage.say('&119\n뭐라고! 조조 유비와 힘을 합쳐서 나를 공격하려는 거야!?\n&126\n네.')
    stage.unit(119).setAction(0)
    stage.say('&119\n정말 공식 채널인가요?\n&126\n정말 정확합니다.\n&126\n어제 우리는 수상한 남자를 잡았어,\n심문 후 그가 조조의 전령임이 밝혀졌다.')
    stage.unit(119).setAction(2)
    stage.say('&119\n음 음...... 절대 그를 그냥 넘어가지 않을 거야!\n겉으로는 나와 화해했지만,\n몰래 나를 음모 모의하고 있어......\n&126\n이렇게 두 군대는 힘을 합쳤다.\n우리에게는 매우 불리한 상황입니다.')
    stage.unit(119).setAction(0)
    stage.say('&119\n알아!')
    stage.unit(119).move(69, 51, 0)
    stage.say('&119\n조조 대규모 병력을 이끌고 이곳에 왔다,\n아마 시간이 좀 더 걸릴 것 같죠?')
    stage.unit(119).move(69, 55, 2)
    stage.say('&119\n이제 샤오페이가 유비,\n우리 쉬저우와 접해 있습니다.')
    stage.unit(119).setAction(0, 3)
    stage.delay(3)
    stage.unit(119).setAction(2, 3)
    stage.say('&119\n우리는 조조의 도착을 이용할 수 있습니다,\n샤오페이를 공격해서 유비를 전멸시켜라!')
    stage.unit(119).setAction(17, 3)
    stage.say('&119\n공식 플랫폼, 모든 장군들에게 출격 명령을 내리라!\n&126\n네.')
    stage.effectSound(202, 255)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 328, 103)
    stage.showHead(32, 422, 111)
    stage.showHead(119, 510, 138)
    stage.bottomTxt('준비가 부족할 때 유비을 활용여포,', False, False, False)
    stage.delay(5)
    stage.head(119).move(486, 111)
    stage.delay(5)
    stage.bottomTxt('그는 샤오페이를 공격하기 위해 군대를 보냈다.', True, False, False)
    stage.delay(8)
    stage.bottomTxt('유비 위험한 상황에 처해 있었기에 사절을 보내 조조 도움을 요청했다.', True, True, True)
    stage.bgSound(-1)
    return False


def scene4():
    model.initLocalVar()
    stage.clsUnit()
    stage.bgSound(15)
    stage.delay(3)
    stage.setMenuVisible(False)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            10,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3],
        [
            193,
            49,
            54,
            2,
            6]])
    stage.draw()
    stage.delay(3)
    stage.info('이때 조의 군대는 서저우로 향하고 있었다.')
    stage.delay(3)
    stage.setStageName('차오현 근처, 조조 본군')
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('&0\n뭐라고!? 샤오페이여포 공격하다고!?\n&193\n네.\n&193\n총리께 신속히 군대를 파견해 구호를 요청합니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n알겠습니다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n원양, 당장 샤오페이로 가서 유비를 구해!')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(3, 1)
    stage.say('&1\n오, 맞아!')
    stage.unit(1).setAction(0, 1)
    stage.say('&193\n응? 감사합니다, 선생님.\n다시 가서 주군에게 굳건히 서라고 말할게.\n&0\n흠.')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(193).move(49, 16, 0)
    stage.unit(193).hide()
    stage.say('&0\n곧 군대를 이끌고 도착할 것이다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n출발!')
    stage.unit(0).setAction(0)
    stage.unit(1).setAction(0, 1)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 11, [
        1])
    gvars[4076] = 0
    gvars[4057] = 13
    stage.setBattlePos([
        [
            1,
            1],
        [
            4,
            16],
        [
            3,
            15],
        [
            2,
            16],
        [
            2,
            14],
        [
            3,
            1],
        [
            1,
            3],
        [
            2,
            2],
        [
            2,
            0],
        [
            0,
            2],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene5():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n샤오페이로 가는 길은 두 가지가 있습니다.\n&20\n그 중 하나는 전략적인 패스입니다.\n&0\n흠.')
    if stage.unitClickTest(22):
        stage.say('&22\n뉴스가 어떻게 새어나갔는지는 모르겠지만,\n하지만 여포 충분히 빨리 행동해야 합니다.\n&0\n음, 아마 그 전략가가 그 아이디어를 진궁 것 같네요.')
    if stage.unitClickTest(1):
        stage.say('&0\n네가 결정해, 원양.\n&1\n걱정 마.')
    if stage.unitClickTest(10):
        stage.say('&10\n무기 가게에 새 검과 총이 재고 있다고 들었어.\n&10\n또는 더 높은 레벨에 도달한 후,\n무기를 다시 팔아라.......\n&0\n왜?\n&15\n왜냐하면 그것이 우리에게 다른 이점도 제공할 것이기 때문입니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n제발 제가 처리하게 해주세요여포,\n나는 절대 그에게 지지 않을 거야.')
    if stage.unitClickTest(21):
        stage.say('&21\n상대가 여포이므로,\n우리는 완전히 준비해야 합니다.')
    if stage.unitClickTest(193):
        stage.say('&193\n제발 내 주군을 구해줘.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
