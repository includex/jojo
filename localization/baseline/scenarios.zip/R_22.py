# Source Generated with Decompyle++
# File: R_22.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            24,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setEventName('내부 갈등을 기다리며')
    stage.setStageName('리양 조조 주 진영')
    stage.say('&0\n젠장, 이 녀석들,\n그들은 실제로 엄청난 병력을 모았다.')
    stage.unit(21).setAction(0, 2)
    stage.say('&21\n이번에는 상대를 정말 과소평가했어.')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\nUnexpectedly원소 많은 병력이 뒤에 남겨졌다......')
    stage.unit(22).setAction(0, 2)
    stage.say('&22\n네......\n주군, 먼저 쉬두로 철수하자.')
    stage.unit(1).setAction(3, 1)
    stage.say('&1\n철수?\n이렇게 허베이를 포기할 건가요?')
    stage.unit(1).setAction(0, 1)
    stage.delay(3)
    stage.unit(22).setAction(0, 3)
    stage.say('&22\n안 돼! 허베이는 조만간 우리 것이 될 거야.')
    stage.unit(24).setAction(6)
    stage.say('&24\n네, 저도 좋은 공연을 보고 싶어요,\n원 형제들이 내부 갈등에 빠지길 기다리고 있었다.\n&24\n이 way아군 손실도 줄일 수 있습니다.')
    stage.unit(24).setAction(0)
    stage.say('&0\n좋아.\n&0\n원양. 그는 전 군대를 서두로 철수하라고 명령했다.')
    stage.unit(1).setAction(0, 2)
    stage.say('&1\n네.')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 67)
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.info('이 moment원담 궈투와 궈 ......')
    stage.setStageName('리양: 시골 외곽의 산길')
    stage.showUnits([
        [
            113,
            44,
            98,
            1],
        [
            103,
            54,
            98]])
    stage.unitsMove([
        [
            stage.unit(113),
            44,
            30,
            0],
        [
            stage.unit(103),
            54,
            30,
            0]])
    stage.delay(3)
    stage.unit(113).setAction(0, 2)
    stage.delay(3)
    stage.unit(113).setAction(2)
    stage.say('&113\n젠장, 이 자식 원상 진짜!\n만약 그가 한 걸음 더 일찍 왔더라면,\n내가 이길 수 있조조!')
    stage.unit(103).setAction(0, 3)
    stage.say('&113\n나는 분명히 그의 형이야,\n왜 그가 후계자가 되었는가,\n너무 가볍게 명령해줘!!')
    stage.unit(103).setAction(6)
    stage.say('&103\n원안 영주님......\n이것이 주군의 마지막 말이기도 했다......')
    stage.unit(113).setAction(0, 2)
    stage.delay(3)
    stage.unit(113).setAction(0, 1)
    stage.say('&113\n마지막 말? 말도 안 돼!!')
    stage.unit(113).setAction(2)
    stage.say('&113\n그건 아버지가 혼란스러울 때 하신 말씀이었다,\n이런 무심한 농담을 진지하게 받아들일 수 있을까?\n&103\n네...... 네.\n그리고 진지하게 받아들여질 수 없다.')
    stage.unit(113).setAction(0)
    stage.say('&113\n궈투, 나는 예시로 돌아가지 않을 거야.')
    stage.unit(103).setAction(0)
    stage.say('&103\n아, 그럼 젊은 주인님은 어디로 가실까......?')
    stage.unit(113).setAction(2)
    stage.say('&113\n속이 매우 속상했다,\n원상에게 돌아가고 싶지 않아!')
    stage.unit(113).setAction(0)
    stage.delay(3)
    stage.unit(113).setAction(0, 0)
    stage.say('&113\n난피로 가!\n거기 있는 모든 병사들은 내 명령에 복종하라!')
    stage.unit(113).setAction(3)
    stage.say('&113\n나는 아버지의 유산을 잇는 후계자다!\n젠장, it원상 두고 보세요!\n그때 얼마나 강력한지 알게 될 거야!\n&103\n음, 야심차네요!\n원영주님, 하찮은 사람들은 항상 당신을 따릅니다.')
    stage.unit(113).setAction(0)
    stage.unitsMove([
        [
            stage.unit(113),
            47,
            5,
            0],
        [
            stage.unit(103),
            57,
            5,
            0]])
    stage.unit(113).hide()
    stage.unit(103).hide()
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 289, 83)
    stage.showHead(115, 353, 30)
    stage.delay(8)
    stage.showHead(113, 353, 110)
    stage.delay(5)
    stage.bottomTxt('리양 전투 이후, 원담', False, False, False)
    stage.delay(8)
    stage.bottomTxt('그는 원상가 있던 예시로 돌아가지 않았다.', True, False, False)
    stage.delay(5)
    stage.head(113).move(459, 110)
    stage.head(113).move(459, 21)
    stage.delay(5)
    stage.bottomTxt('대신 그는 난피로 가서 그곳에 주둔했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 42)
    stage.showUnits([
        [
            113,
            54,
            70],
        [
            103,
            35,
            56,
            1],
        [
            112,
            71,
            50,
            2],
        [
            117,
            71,
            56,
            2]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('난피 원담 저택')
    stage.delay(3)
    stage.unit(113).setAction(3)
    stage.say('&113\n나는 원씨 가문의 장남이다,\n내가 상속자야!')
    stage.unit(113).setAction(0)
    stage.say('&113\n그러니 무슨 일이 있어도 원상을 몰아내야 한다,\n원가의 진정한 권력을 내가 쥐게 해줘!\n여러분 생각은 어떠신가요?')
    stage.unit(103).setAction(6)
    stage.say('&103\n네.')
    stage.unit(103).setAction(0)
    stage.delay(3)
    stage.unit(112).setAction(6)
    stage.say('&112\n전심을 다해 주군를 섬기겠습니다.')
    stage.unit(112).setAction(0)
    stage.delay(3)
    stage.unit(117).setAction(6)
    stage.say('&117\n…………')
    stage.unit(117).setAction(0)
    stage.say('&113\n문제는: 우리가 어떻게 이 문제를 다룰 것인가it원상......')
    stage.unit(103).setAction(6)
    stage.say('&103\n주군에게 보고합니다.\n정면 결투에서 이길 수 있지만,\n하지만 이는 상당한 병력 손실을 초래할 것이다.\n&103\n내 생각엔...... 조조랑 동맹을 맺자, 맞지?\n&113\n뭐라고?\n그 늙은 도둑과 함께 싸울까?\n&103\n아니, 조조 혼자 싸우원상 게 낫다.\n&113\n흠.........\n&103\n원상 탈락한 후,\n우리는 이 동맹을 통해 힘을 쌓고,\n그리고 돌아서서 조조를 물리치세요.\n&113\n좋아요, 정말 윈윈윈 전략이에요.\n&103\n셰 주군.')
    stage.unit(103).setAction(0)
    stage.delay(3)
    stage.unit(113).setAction(3)
    stage.say('&113\n하하하!\n좋아! 즉시 사절을 보내 조조와 동맹을 맺으라.')
    stage.unit(113).setAction(0)
    stage.delay(3)
    stage.unit(117).setAction(6)
    stage.say('&117\n주군, 제발 제가 사신으로 봉사하게 해주세요.\n&113\n아, 신비?\n흠. 하지만......\n성공만 허용되고, 실패는 허용되지 않습니다.\n&117\n...... .........\n(안타깝게도, 권력과 이익을 놓고 경쟁하는 법만 알고,\n하지만 그는 세상의 전반적인 상황을 이해하지 못했다. )\n&117\n(그렇게 계속 따라다니면 아마 미래가 없을 거야.) )')
    stage.say('&113\n좋아! 바로 출발해.\n&117\n.........')
    stage.unit(117).setAction(0)
    stage.delay(3)
    stage.unit(112).setAction(0, -1)
    stage.say('&112\n주군,\n동맹을 성공적으로 맺어야 합니다.')
    stage.unit(113).setAction(3)
    stage.say('&113\n하하하!\n원상! 감히 형에게 반항하다니?\n정말 어리석었네요, 하하하!\n&117\n…………')
    stage.effectSound(200, 255)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 8)
    stage.showUnits([
        [
            0,
            34,
            55,
            1],
        [
            1,
            52,
            70],
        [
            15,
            58,
            70],
        [
            2,
            64,
            70],
        [
            23,
            70,
            70],
        [
            20,
            52,
            40,
            2],
        [
            22,
            58,
            40,
            2],
        [
            24,
            64,
            40,
            2],
        [
            21,
            70,
            40,
            2],
        [
            117,
            48,
            55,
            3,
            6]])
    stage.draw()
    stage.effectSound(200, 0)
    stage.delay(3)
    stage.setStageName('서두, 총리 관저')
    stage.say('&0\n오, 나랑 동맹을 맺고 싶다는 거야......?\n&117\n네.\n&0\n흠............')
    stage.unit(117).setAction(0)
    stage.say('&117\n하지만 동맹이 형성되더라도,\n진심도 아니었다.')
    model.setFace(1)
    stage.say('&0\n뭐라고?\n&117\n원담 그냥 원상를 없애기 위해 너를 이용하고 싶을 뿐이야.\n&117\n진정한 동맹이 아니기 때문에,\n조만간 약속을 어기고 총리를 공격할 것이다.')
    stage.unit(0).setAction(3)
    model.setFace(0)
    stage.say('&0\n닥쳐!')
    stage.unit(0).setAction(0)
    stage.say('&0\n신비, 너 원담 고종이야?')
    stage.say('&117\n나는 그런 대가를 인정하지 않는다.\n&117\n형제들은 오직 권력과 이익을 위해 경쟁하는 법만 알았다,\n그는 평민들의 고난에는 전혀 신경 쓰지 않았다,\n그런 식으로 모시는 건 어리석은 짓이야.\n&0\n그래서 그런 거구나............')
    stage.say('&0\n좋아, 원담와 동맹을 맺겠다.\n&117\n응?')
    model.setFace(3)
    stage.unit(0).setAction(3, 1)
    stage.say('&0\n원담 전략을 세우기 어렵다고 느낍니다.\n지난번엔 그냥 속을 거야.')
    stage.unit(0).setAction(0)
    stage.say('&117\n하지만............')
    model.setFace(0)
    stage.say('&0\n저도 이 동맹을 활용하고 싶습니다.\n&0\n신비, 그들은 원상가 있던 예시를 공격했다,\n난 아직도 네 힘이 필요해,\n도와주셨으면 좋겠습니다.')
    stage.unit(117).setAction(6)
    stage.say('&117\n네! 명령에 따르겠습니다......')
    stage.unit(117).setAction(0)
    stage.say('&0\n아주 좋아.\n문약, 사절을 보내 원담와 동맹을 맺으라,\n그는 원상를 함께 공격할 병력을 요청했다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n네, 바로 처리하겠습니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(117).setAction(0, 0)
    stage.say('&117\n그는 군대를 보내지 않을 것이다.\n&20\n하하하, 아마 그럴 거예요.\n&117\n그런데 왜 총리는 아직도 ...... 있을까요?')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하.')
    stage.unit(117).setAction(0, 3)
    stage.delay(3)
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n그가 군대를 보내지 않으려 한다면,\n그를 때릴 핑계가 생겼어.\n&117\n응......? (깊은 지혜,\n늦은 원소주군조차도 손이 닿지 않는 곳에 있다,\n아들들도 말할 것도 없고. )')
    stage.effectSound(200, 255)
    stage.bgSound(18)
    stage.delay(3)
    stage.showUnit(8, 95, 55, 3)
    stage.say('&8\n아버지!')
    stage.unit(117).setAction(0, 1)
    stage.unit(117).move(48, 60, 2)
    stage.delay(3)
    stage.unit(117).setAction(0, 0)
    stage.unit(8).move(48, 55, 3)
    stage.unit(8).setAction(0)
    stage.say("&0\n쯔환, 무슨 일이야?\n&8\n아버지, 제발 이 전투에 참여하게 해주세요.\n&0\n너는?\n&8\n네.\n군사 전략은 아버지의 '맹덕 신서'에서 배웠습니다,\n그래서 아버지께서 제 아들을 전투에 보내 주시길 간절히 부탁합니다.\n&0\n'맹덕 New Book'을 가지고 계신가요?\n&8\n네.\n&0\n흠.........")
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('그리고 전투에 합류하기로 동의했다\n아직 시기가 이릅니다', 0)
    if sel == 1:
        stage.addAmbition(-2)
        stage.bgSound(18)
        stage.delay(3)
        stage.say('&0\n좋아.\n전장에서 본 것을 보여드리겠습니다.\n&8\n네, 감사합니다, 신부님.\n&0\n즈환, 잘해야 해.\n그리고 원소 아들들,\n전장에서는 우위를 놓고 경쟁했다.\n&8\n그래, 나는 절대 아버지의 명예를 더럽히지 않을 거야.')
    elif sel == 2:
        stage.addAmbition(2)
        stage.bgSound(18)
        stage.delay(3)
        stage.say('&0\n안 돼! 지금 전장에 나서는 건 너무 이르잖아.\n&8\n하지만, 아버지……\n&0\n충분해! 너는 겨우 대강의 병법을 배운 것뿐이야. 전장은 장난이 아니라고!\n&8\n…………\n&21\n주군의 심정은 제가 이해합니다. 자환 공자께서 이런 뜻을 가지시다니, 주군께서 기꺼이 허락해주셔야 합니다.\n&20;맞아요. 만약 적장자인 조비가 출전한다면,\n병사들의 투지도 크게 고취될 겁니다.\n&0\n오? 그래. 너희들이 그렇게 말하니, 이 아이를 출전시키도록 하지.\n&8\n아? 아버지 감사합니다.\n&0\n다만, 이건 네가 자원해서 참전하는 거니,\n전장에서 나에게 창피한 짓은 하지 마라.\n&8\n예! 아들은 아버지의 가르침을 명심하겠습니다.')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하.\n좋습니다. 군대를 출동시키자!')
    model.setFace(0)
    model.unitJoin(8, 0, 0)
    if vars[1013]:
        gvars[0] = 8
        gvars[4076] = 0
        gvars[1] = gvars[0]
        gvars[2] = 5259072
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        gvars[1] *= 4
        gvars[1] += gvars[2]
        pvars[0] = gvars[1]
        stage.varOper(2, 3, 2, 1, 0)
        stage.setUnitAttr(gvars[0], 17, gvars[3])
        if gvars[3] >= 24 and gvars[3] <= 33:
            gvars[4] = 1
        if gvars[3] >= 65 and gvars[3] <= 66:
            gvars[4] = 1
        if gvars[3] == 69:
            gvars[4] = 1
        if gvars[3] == 74:
            gvars[4] = 1
        if gvars[3] == 0:
            gvars[4] = 2
        if gvars[3] == 57:
            gvars[4] = 2
        if gvars[3] == 67:
            gvars[4] = 2
        if gvars[3] == 71:
            gvars[4] = 2
        if gvars[3] == 79:
            gvars[4] = 2
        gvars[4076] = 0
        gvars[6] = stage.unitAttr(gvars[0], 9)
        gvars[7] = stage.unitAttr(gvars[0], 10)
        gvars[8] = stage.unitAttr(gvars[0], 11)
        gvars[9] = stage.unitAttr(gvars[0], 8)
        gvars[20] = stage.unitAttr(gvars[0], 18)
        gvars[9] -= gvars[20]
        if gvars[4] == 0:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
        if gvars[4] == 1:
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
            if gvars[9] <= 35:
                stage.setUnitAbility(gvars[0], 6, 1, 30)
                stage.setUnitAbility(gvars[0], 8, 1, 30)
        if gvars[4] == 2:
            if gvars[6] <= 34:
                stage.setUnitAbility(gvars[0], 10, 0, 35)
            if gvars[7] <= 34:
                stage.setUnitAbility(gvars[0], 11, 0, 35)
            if gvars[8] <= 34:
                stage.setUnitAbility(gvars[0], 12, 0, 35)
        if gvars[3] <= 59:
            if gvars[20] >= 15:
                gvars[3] += 1
            if gvars[20] >= 30:
                gvars[3] += 1
        gvars[102] = gvars[3]
        if 0 == 0:
            gvars[4076] = 0
            gvars[2] = 0
            gvars[4081] = 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(0)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(1)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(2)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(3)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(4)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(5)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(6)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(7)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(8)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(9)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(10)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(11)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(12)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(13)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(14)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(15)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(16)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(17)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(18)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(19)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(20)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(21)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(22)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(23)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(24)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(25)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(26)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(27)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(28)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(29)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(30)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(31)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(32)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(33)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(34)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(35)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(36)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(37)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(38)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(39)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(40)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(41)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(42)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(43)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(44)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(45)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(46)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(47)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(48)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(49)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(50)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(51)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(52)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(53)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(54)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(55)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(56)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(57)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(58)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(59)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(60)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(61)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(62)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(63)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(64)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(65)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(66)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(67)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(68)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(69)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(70)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(71)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(72)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(73)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(74)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(75)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(76)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(77)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(78)
            gvars[2] += 1
            if gvars[102] == gvars[2]:
                model.unit(gvars[0]).setPosts(79)
            gvars[4081] = 0
    stage.setJoinEquip(8, -1, 0, -1, 0, 21)
    stage.bgSound(16)
    stage.delay(3)
    stage.clsUnit()
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 315, 129)
    stage.showHead(115, 379, 28)
    stage.delay(8)
    stage.head(0).move(315, 28)
    stage.delay(5)
    stage.bottomTxt('조의 군대는 원상의 주영인 예시를 공격했다.', False, False, True)
    stage.bgSound(-1)
    return False


def scene4():
    stage.loadBg(2, 7)
    stage.showUnits([
        [
            115,
            53,
            28,
            2],
        [
            106,
            38,
            48,
            1],
        [
            118,
            53,
            48]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setStageName('예시 @원상 관저')
    stage.delay(3)
    stage.unit(115).setAction(2)
    stage.say('&115\n뭐라고...... 무슨 ......?\nBrother원담 조조와 동맹을 맺었나요!?')
    stage.unit(115).setAction(0)
    stage.say('&118\n네.\n&106\n그래서, ......?')
    stage.unit(118).setAction(0, 3)
    stage.say('&118\n조조 이미 쉬두에서 출발했다,\n그들이 우리를 향해 다가오고 있어.')
    stage.say('&115\n음, 형이 어떻게 나를 이렇게 대할 수 있......?')
    stage.unit(118).setAction(0, 0)
    stage.delay(3)
    stage.unit(115).setAction(2)
    stage.say('&115\n다시는 그를 내 형제로 인정하지 않을 거야!')
    stage.unit(106).setAction(6)
    stage.say('&106\n주군, 조조 어떻게 해야 할지 찾아야 해!')
    stage.unit(115).setAction(0)
    stage.say('&115\n좋아, 내가 직접 군대를 이끌고 조조와 맞서겠다!\n&115\n심배, 저곡,\n너는 도시에 남아 나를 지지해!\n&106\n네.')
    stage.unit(106).setAction(0)
    stage.say('&118\n네.')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene5():
    stage.bgSound(15)
    stage.delay(3)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            67],
        [
            1,
            38,
            54,
            1],
        [
            15,
            38,
            48,
            1],
        [
            8,
            38,
            42,
            1],
        [
            20,
            60,
            54,
            3],
        [
            22,
            60,
            48,
            3],
        [
            21,
            60,
            42,
            3]])
    stage.draw()
    stage.setStageName('교외 외곽, 군조조 본부')
    stage.say('&0\n문약, 원상 군대에서 무슨 일이 벌어지고 있습니까?')
    stage.unit(20).setAction(0, 2)
    stage.say('&20\n네.\n&20\n심배 그는 예시를 단단히 방어저곡,\n원상 직접 말을 이끌고 아군와 맞섰다.')
    stage.unit(1).setAction(3)
    stage.say('&1\n가로채기? 못 봤적군?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(0, 3)
    stage.say('&20\n원상 잘못된 방향으로 간 것 같아요......\n&1\n응?\n&0\n응?')
    stage.unit(0).setAction(3)
    model.setFace(3)
    stage.say('하하하하.')
    stage.unit(0).setAction(0)
    stage.say('&0\n이 사람 정말 흥미롭네요,\n나는 원소 아들을 좀 좋아해,\n쯔환, 너도 그들에게서 배워야 해.')
    stage.unit(8).setAction(0, 2)
    stage.say('&8\n아버지, 뭐라고 하셨어요!?')
    stage.unit(0).setAction(3)
    stage.say('하하하. 농담입니다, 농담입니다!')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&0\n좋아! 공격 시작해.\n우리는 원상를 놀라게 하고 싶어.')
    stage.unit(8).setAction(0, 1)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 11, [
        22,
        8])
    gvars[4076] = 0
    gvars[4057] = 22
    stage.setBattlePos([
        [
            17,
            18],
        [
            18,
            18],
        [
            17,
            16],
        [
            15,
            16],
        [
            19,
            16],
        [
            14,
            17],
        [
            20,
            17],
        [
            16,
            17],
        [
            18,
            17],
        [
            15,
            19],
        [
            19,
            19],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene6():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n예시의 군 지휘관들은 저곡,\n저수의 아들인 것 같아.\n&0\n아, 저수 아들......?')
    if stage.unitClickTest(8):
        stage.say('&8\n아버지,\n삼촌에게서 배운 활쏘기 하후연 좀 봐줘.\n&0\n흠.')
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 전장의 특징은 무엇인가요?\n&20\n네.\n&20\n예시 자체는 방어가 잘 되어 있고 강하다, 말할 필요도 없이,\n게다가 도시 외곽에 사슴 요새가 세워진 것으로 보입니다.\n&0\n흠.')
    if stage.unitClickTest(15):
        stage.say('&15\n형제들끼리 뭐가 싸울 게 있겠어?\n정말 이해가 안 돼요.\n&0\n…………')
    if stage.unitClickTest(21):
        stage.say('&21\n원상을 과소평가해서는 안 된다,\n원소 그를 상속자로 두세요,\n그럴 만한 이유가 있다.\n&0\n네, 그건 알고 있습니다.')
    if stage.unitClickTest(22):
        stage.say('&22\n조비 마침내 전장에 나갔다.\n&0\n흠.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
