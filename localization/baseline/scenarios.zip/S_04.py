# Source Generated with Decompyle++
# File: S_04.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22], [
        '(4,4)',
        '(13,17)',
        '(15,5)'])
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createEnemy([
        {
            'id': 474,
            'x': 15,
            'y': 5,
            'dir': 3,
            'i': 0 },
        {
            'id': 475,
            'x': 14,
            'y': 4,
            'dir': 3,
            'ai': 0,
            'i': 1 },
        {
            'id': 476,
            'x': 16,
            'y': 5,
            'dir': 3,
            'ai': 0,
            'i': 2 },
        {
            'id': 477,
            'x': 15,
            'y': 4,
            'dir': 3,
            'ai': 0,
            'i': 3 },
        {
            'id': 478,
            'x': 14,
            'y': 6,
            'dir': 3,
            'ai': 0,
            'i': 4 },
        {
            'id': 479,
            'x': 15,
            'y': 6,
            'dir': 3,
            'ai': 0,
            'i': 5 },
        {
            'id': 480,
            'x': 16,
            'y': 6,
            'dir': 3,
            'ai': 0,
            'i': 6 },
        {
            'id': 481,
            'x': 14,
            'y': 5,
            'dir': 3,
            'ai': 0,
            'i': 7 },
        {
            'id': 482,
            'x': 16,
            'y': 4,
            'dir': 3,
            'ai': 0,
            'i': 8 },
        {
            'id': 483,
            'x': 13,
            'y': 17,
            'dir': 3,
            'i': 9 },
        {
            'id': 484,
            'x': 13,
            'y': 16,
            'dir': 3,
            'ai': 0,
            'i': 10 },
        {
            'id': 485,
            'x': 14,
            'y': 16,
            'dir': 3,
            'ai': 0,
            'i': 11 },
        {
            'id': 486,
            'x': 12,
            'y': 17,
            'dir': 3,
            'ai': 0,
            'i': 12 },
        {
            'id': 487,
            'x': 12,
            'y': 18,
            'dir': 3,
            'ai': 0,
            'i': 13 },
        {
            'id': 488,
            'x': 13,
            'y': 18,
            'dir': 3,
            'ai': 0,
            'i': 14 },
        {
            'id': 489,
            'x': 14,
            'y': 18,
            'dir': 3,
            'ai': 0,
            'i': 15 },
        {
            'id': 490,
            'x': 12,
            'y': 16,
            'dir': 3,
            'ai': 0,
            'i': 16 },
        {
            'id': 491,
            'x': 14,
            'y': 17,
            'dir': 3,
            'ai': 0,
            'i': 17 },
        {
            'id': 492,
            'x': 4,
            'y': 4,
            'i': 18 },
        {
            'id': 493,
            'x': 3,
            'y': 3,
            'ai': 0,
            'i': 19 },
        {
            'id': 494,
            'x': 4,
            'y': 3,
            'ai': 0,
            'i': 20 },
        {
            'id': 495,
            'x': 5,
            'y': 3,
            'ai': 0,
            'i': 21 },
        {
            'id': 496,
            'x': 5,
            'y': 4,
            'ai': 0,
            'i': 22 },
        {
            'id': 497,
            'x': 3,
            'y': 5,
            'ai': 0,
            'i': 23 },
        {
            'id': 498,
            'x': 4,
            'y': 5,
            'ai': 0,
            'i': 24 },
        {
            'id': 499,
            'x': 3,
            'y': 4,
            'ai': 0,
            'i': 25 },
        {
            'id': 500,
            'x': 5,
            'y': 5,
            'ai': 0,
            'i': 26 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 1,
            'y': 16,
            'dir': 1 },
        {
            'idx': 1,
            'x': 2,
            'y': 17,
            'dir': 1 },
        {
            'idx': 2,
            'y': 16,
            'dir': 1 },
        {
            'idx': 3,
            'x': 2,
            'y': 18,
            'dir': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 15,
            'dir': 1 },
        {
            'idx': 5,
            'x': 3,
            'y': 17,
            'dir': 1 },
        {
            'idx': 6,
            'x': 2,
            'y': 16,
            'dir': 1 },
        {
            'idx': 7,
            'x': 1,
            'y': 17,
            'dir': 1 },
        {
            'idx': 8,
            'y': 17,
            'dir': 1 },
        {
            'idx': 9,
            'x': 1,
            'y': 18,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.loadBg(4)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab21')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab21')
    stage.draw()
    stage.bgSound(1)
    stage.unit(475).setAction(10)
    stage.say('&475\n정부군이 또 공격해!')
    stage.unit(474).setAction(2)
    stage.say('&474\n젠장, 이번에 상대가 꽤 강해 보이네......\n&0\n황제의 칙령에 따라 우리는 황번군을 진압해야 합니다.')
    stage.unit(0).setAction(5)
    stage.say('&0\n이번이 내가 조조 새로운 세력이 무대에 오른 첫 번째 기회야,\n모두가 더 열심히 해야 해!')
    stage.unit(0).setAction(0)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    vars[504] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.round() == 1:
        stage.unit(0).move(2, 15, 1)
        stage.say('&0\n순욱, 전위, 순유, 앞으로 나와!\n&20\n네!\n&16\n네!\n&24\n네!')
        stage.unit(20).move(3, 14, 3)
        stage.unit(16).move(3, 15, 3)
        stage.unit(24).move(3, 16, 3)
        stage.say('&0\n오늘이 처음으로 참가하는 날이에요,\n앞으로 고려할 때, 당신의 능력을 보고 싶습니다.\n&0\n여러분의 생각을 나눠주셔도 됩니다.\n황번군을 어떻게 상대해야 할까?\n&20\n주군, 불필요하게 희생하는 대신,\n차라리 그들을 설득해 항복시키는 것이 더 나을 것이다.......\n&16\n나는 황반에게 지지 않을 것이다.\n&20\n손실을 피하려고 노력해야 할 mean아군 있습니다.\n&20\n혼돈은 오랫동안 계속될 것이다,\n이제부터 적군 전투력을 보아군해야 한다.\n&20\n따라서 어른들이 동의한다면,\n나는 항복을 설득하기 위해 사절로 봉사할 준비가 되어 있다,\n어떻게 생각하세요?\n&16\n황번군을 상대하려고 그렇게까지 할 필요는 없어,\n나는 그들을 물리치기 위해 혼자서 전위다.\n&16\n전투 능력then아군 명성으로,\n그것은 강력한 군대의 힘의 원천이 될 것이다.\n&24\n두 가지 의견 모두 이해하지만,\n하지만 제 생각은 다릅니다.\n&24\n이제부터 전투의 승패는 전략에 의해 결정될 것이다,\n순유, 진짜 계획이 있어—내게 맡겨!')
        sel = stage.choice('순욱의 조언을 따르세요\n전위의 조언을 따르세요\n그는 순유의 조언을 받아들였다', -1)
        if sel == 1:
            stage.say('&0\n또한 무의미한 전쟁을 하고 싶지 않습니다.\n좋아, 문약, 적을 설득해 항복하게 해.\n&20\n네.')
            stage.unit(20).move(8, 10, 1)
            stage.say('&20\n황번 형제들, 잘 들어라!\n&20\n장교가 죽은 이후,\n황띠의 싸움은 더 이상 신앙과는 관련이 없었습니다.\n아마 이걸 눈치채셨을 거예요!')
            stage.unit(20).setDir(2)
            stage.say('&20\n네가 그렇게 이유 없이 죽고 싶지 않을 거라고 믿어!\n&20\n나는 단지 당신의 믿음을 보장할 뿐만 조조주군아니라,\n또한 땅과 집도 제공할 것입니다.')
            stage.unit(20).setDir(0)
            stage.unit(20).setAction(5)
            stage.say('&20\n모두가 살아남고 자신의 신념을 굳게 지키고 싶다면,\n그러면 무의미한 싸움은 즉시 멈춰야 한다,\n내 주군에게 항복해!')
            stage.unit(20).setAction(0)
            stage.unit(474).setAction(6)
            stage.say('&474\n말도 안 돼요, 저는 그런 말을 전혀 믿지 않아요!')
            stage.unit(474).setAction(0)
            stage.say('&493\n하지만 정부군이 우리에게 이렇게 말할 때,\n이번이 처음이에요.\n그리고 그들의 신앙도 인정합니다.\n&492\n이렇게 평생 싸울 수는 없어......\n&492\n그들이 우리의 신앙을 인정하니,\n지금은 운에 맡기고 그를 믿자!')
            stage.unit(492).setAction(1)
            stage.say('&492\n이봐, 전략가, 네 말을 믿어!\n&20\n오! 내 말 이해하지?\n하지만 이곳의 위험으로 인해 당분간 한 발 물러나 주시기 바랍니다.\n전쟁이 끝날 때까지 기다리자.')
            stage.unit(497).move(0, 5, 3)
            stage.unit(498).move(1, 5, 3)
            stage.unit(500).move(2, 5, 3)
            stage.unit(499).move(0, 4, 3)
            stage.unit(492).move(1, 4, 3)
            stage.unit(496).move(2, 4, 3)
            stage.unit(493).move(0, 3, 3)
            stage.unit(494).move(1, 3, 3)
            stage.unit(495).move(2, 3, 3)
            stage.setRectUnitHide(0, 3, 2, 5, 2)
            stage.unit(20).move(3, 14, 3)
            stage.unit(0).setAction(5)
            stage.say('&0\n문약, 정말 잘했어!\n그들은 자신들의 신앙을 원하는 대로 인정했을 뿐만 아니라,\n그리고 그들에게 살 곳도 제공했어요!')
            stage.unit(0).setAction(0)
            stage.say('&20\n네, 그들은 분명히 좋은 군인이 될 것입니다.\n&16\n응, 응.......')
            stage.unit(474).setAction(10)
            stage.unit(474).setAction(4)
            stage.say('&474\n뭐라고? 그들의 달콤한 말에 속았어!\n이건 그들만 사용할 거야!')
            stage.unit(20).setDir(1)
            stage.unit(16).setDir(1)
            stage.unit(24).setDir(1)
            vars[2] = 1
        elif sel == 2:
            stage.unit(0).setAction(6)
            stage.say('전위, 여기는 너에게 맡긴다.')
            stage.unit(0).setAction(0)
            stage.say('&16\n네.\n&16\n황막 병사들, 잘 들어라!\n공격을 개시하려 합니다.\n&16\n죽기 싫으면 비켜! 내 길을 막는 자는 죽는다!')
            stage.unit(16).move(11, 17, 1)
            stage.unit(16).setAction(7)
            stage.say('&16\n죽여라!')
            stage.unit(16).setAction(0)
            stage.unit(490).setAction(10)
            stage.unit(491).setAction(10)
            stage.say('&490\n좋지 않은데, 이 사람이 전력을 다할 계획인가?\n&491\n이 사람 진심이야!\n더 있으면 ...... 있을까 봐 걱정돼!\n목숨을 걸고 도망치는 게 낫다!')
            stage.unit(490).hide()
            stage.unit(491).hide()
            stage.unit(16).move(13, 5, 1)
            stage.unit(16).setAction(3)
            stage.say('&16\n죽여라!')
            stage.unit(481).setAction(10)
            stage.unit(482).setAction(10)
            stage.say('&481\n…….\n&482\n이거 안 좋네, 나도 도망쳐야 해!')
            stage.unit(481).hide()
            stage.unit(482).hide()
            stage.unit(16).move(4, 6, 0)
            stage.unit(16).setAction(5)
            stage.say('&16\n죽여라!')
            stage.unit(16).setAction(0)
            stage.unit(499).setAction(10)
            stage.unit(500).setAction(10)
            stage.say('&499\n여기서 죽고 싶지 않아!\n&500\n기다려, 데려가 줘!')
            stage.unit(499).hide()
            stage.unit(500).hide()
            stage.unit(16).move(3, 15, 3)
            stage.unit(16).setAction(9)
            stage.say('&16\n흥...... 엉성한 무리네!')
            stage.unit(474).setAction(4)
            stage.say('&474\n쓸모없는 녀석...\n하지만 나머지는 모두 엘리트입니다!\n이 녀석들은 복종하기보단 차라리 죽겠어!')
            stage.unit(483).setAction(2)
            stage.say('&483\n우리는 여전히 수적으로 우위를 점하고 있습니다!\n두려워할 필요 없어!')
            stage.unit(492).setAction(5)
            stage.say('&492\n맞아! 우리가 얼마나 강한지 알리자!')
            stage.unit(492).setAction(0)
            stage.unit(474).addLv(1)
            stage.unit(475).addLv(1)
            stage.unit(476).addLv(1)
            stage.unit(477).addLv(1)
            stage.unit(478).addLv(1)
            stage.unit(479).addLv(1)
            stage.unit(480).addLv(1)
            stage.unit(483).addLv(1)
            stage.unit(484).addLv(1)
            stage.unit(485).addLv(1)
            stage.unit(486).addLv(1)
            stage.unit(487).addLv(1)
            stage.unit(488).addLv(1)
            stage.unit(489).addLv(1)
            stage.unit(492).addLv(1)
            stage.unit(493).addLv(1)
            stage.unit(494).addLv(1)
            stage.unit(495).addLv(1)
            stage.unit(496).addLv(1)
            stage.unit(497).addLv(1)
            stage.unit(498).addLv(1)
            stage.say('&20\n싸워야 할 것 같아.\n&0\n음, 이 사람들조차도 감당 못 한다면,\n그가 이룰 수 있는 위대한 업적은 무엇일까?')
            stage.unit(0).setAction(5)
            stage.say('&0\n선택의 여지가 없어, 모두 싸워!\n여러분, 적을 과소평가하지 마세요!')
            stage.unit(0).setAction(0)
            stage.say('&16\n내 모든 노력이 헛수고였나 보네.......\n잊어버려! 장군으로서,\n전투에서 힘으로 체면을 되찾는 것만이 유일한 방법이었다!')
            stage.unit(20).setDir(1)
            stage.unit(16).setDir(1)
            stage.unit(24).setDir(1)
            vars[3] = 1
        elif sel == 3:
            stage.say('&0\n순유, 네 전략에 달렸어.\n&24\n네, 이렇게 해야 한다고 생각해요......\n&0\n알겠습니다. 문약. 전위, 너도 순유를 도와야 해.\n&20\n네!\n&16\n네!\n&24\n병력을 이동시킬 때는 적에게 눈치채지 마세요.\n소규모 그룹으로 이동한다면 아마 주목받지 못할 것입니다.')
            stage.unit(24).move(13, 11, 2)
            stage.unit(20).move(14, 11, 2)
            stage.unit(16).move(15, 11, 2)
            stage.unit(24).setAction(5)
            stage.say('&24\n전면 군대 공격!')
            stage.unit(24).setAction(0)
            stage.unit(483).setDir(stage.countDir(483, 24))
            stage.unit(483).setAction(10)
            stage.say('&483\n뭐라고? 조나라 군대가 언제 들어왔지!?\n서둘러 와! 그들이 마을에 가까이 오지 못하게 해!')
            stage.unit(483).move(13, 12, 0)
            stage.unit(484).move(14, 12, 0)
            stage.unit(485).move(15, 12, 0)
            stage.unit(486).move(13, 13, 0)
            stage.unit(487).move(14, 13, 0)
            stage.unit(488).move(15, 13, 0)
            stage.unit(489).move(13, 14, 0)
            stage.unit(490).move(14, 14, 0)
            stage.unit(491).move(15, 14, 0)
            stage.unit(24).setAction(10)
            stage.say('&24\n안 돼! 수적으로 열세야, 도망쳐!')
            stage.unit(483).setAction(5)
            stage.say('&483\n이렇게 사람이 적을 줄은 몰랐어요,\n우린 반드시 이길 거야, 그냥 넘어가지 마!')
            stage.unit(483).setAction(0)
            stage.unit(24).move(6, 8, 1)
            stage.unit(20).move(6, 9, 1)
            stage.unit(16).move(6, 10, 1)
            stage.unit(483).move(7, 8, 3)
            stage.unit(484).move(7, 9, 3)
            stage.unit(485).move(7, 10, 3)
            stage.unit(486).move(8, 8, 3)
            stage.unit(487).move(8, 9, 3)
            stage.unit(488).move(8, 10, 3)
            stage.unit(489).move(9, 8, 3)
            stage.unit(490).move(9, 9, 3)
            stage.unit(491).move(9, 10, 3)
            stage.unit(4, 1).move(9, 19, 0)
            stage.unit(5, 1).move(8, 19, 0)
            stage.unit(6, 1).move(7, 19, 0)
            stage.unit(7, 1).move(6, 19, 0)
            stage.unit(0).move(0, 10, 1)
            stage.unit(8, 1).move(0, 11, 1)
            stage.unit(9, 1).move(0, 12, 1)
            stage.say('&483\n멈춰! 도망가지 마!')
            stage.unit(24).move(0, 17, 1)
            stage.unit(20).move(1, 18, 1)
            stage.unit(16).move(2, 19, 1)
            stage.unit(483).move(4, 14, 3)
            stage.unit(484).move(5, 14, 3)
            stage.unit(485).move(6, 14, 3)
            stage.unit(486).move(4, 15, 3)
            stage.unit(487).move(5, 15, 3)
            stage.unit(488).move(6, 15, 3)
            stage.unit(489).move(4, 16, 3)
            stage.unit(490).move(5, 16, 3)
            stage.unit(491).move(6, 16, 3)
            stage.say('&483\n뭔가 이상한 점이 있나요?')
            stage.unit(0).move(6, 11, 2)
            stage.unit(8, 1).move(5, 11, 2)
            stage.unit(9, 1).move(4, 11, 2)
            stage.say('&0\n맞아요, 이미 포위됐어요.\n아직도 갇힌 괴물과 싸우고 싶으신가요?')
            stage.unit(4, 1).move(10, 14, 3)
            stage.unit(5, 1).move(10, 15, 3)
            stage.unit(6, 1).move(10, 16, 3)
            stage.unit(7, 1).move(10, 17, 3)
            stage.say('&483\n뭐, 언제 ......이 우리를 둘러싼 거야?\n&487\n더 이상 견딜 수 없는 것 같다......\n&491\n아직 죽고 싶지 않아!\n&483\n진정해! 진정해!\n혼란에 뛰어들면 적의 손에 정면으로 들어갈 뿐이다.')
            stage.setAI(4, 14, 6, 16, 5, 1)
            stage.setUnitStatus([
                {
                    'hStatus': [
                        9],
                    'x1': 5,
                    'y1': 15,
                    'x2': 6,
                    'y2': 16,
                    'camp': 5 }])
            vars[4] = 1
        stage.bgSound(2)
        stage.startOper()
        vars[11] = 1
    if not vars[20] and stage.isInPos(1025, 4, 4):
        stage.getItem(150, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 13, 17):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 15, 5):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[2] and not vars[6] and not vars[7] and stage.totalRectUnit(2, 3, 3, 5, 5) < 5 and stage.curCamp() == 2 and stage.totalRectUnit(2, 14, 4, 16, 6) >= 7:
        stage.unit(474).setDir(1)
        stage.unit(474).setDir(3)
        stage.unit(474).setAction(6)
        stage.say('&474\n서쪽 마을이 위험해! 빨리 가서 지원해!')
        stage.unit(474).setAction(0)
        stage.unit(477).setAI(4, -1, 4, 4)
        stage.unit(478).setAI(4, -1, 4, 4)
        stage.unit(479).setAI(4, -1, 4, 4)
        stage.unit(480).setAI(4, -1, 4, 4)
        stage.unit(481).setAI(4, -1, 4, 4)
        stage.unit(482).setAI(4, -1, 4, 4)
        vars[6] = 1
    if not vars[4] and not vars[6] and not vars[7] and stage.totalRectUnit(2, 12, 16, 14, 18) < 5 and stage.curCamp() == 2 and stage.totalRectUnit(2, 14, 4, 16, 6) >= 7:
        stage.unit(474).setDir(2)
        stage.unit(474).setDir(2)
        stage.unit(474).setAction(6)
        stage.say('&474\n남쪽 마을이 위험해! 빨리 가서 지원해!')
        stage.unit(474).setAction(0)
        stage.unit(477).setAI(4, -1, 13, 17)
        stage.unit(478).setAI(4, -1, 13, 17)
        stage.unit(479).setAI(4, -1, 13, 17)
        stage.unit(480).setAI(4, -1, 13, 17)
        stage.unit(481).setAI(4, -1, 13, 17)
        stage.unit(482).setAI(4, -1, 13, 17)
        vars[7] = 1
    if not vars[50] and stage.unitStateTest(474, 7, 0, 2):
        stage.say('&474\n우리의 꿈도 그냥 거품 같은 거야......?')
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(483, 7, 0, 2):
        stage.say('&483\n젠장조조!\n이 원한은 죽어도 절대 잊지 못할 거야!')
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(492, 7, 0, 2):
        stage.say('&492\n마을의 여성과 아이들을 해치지 마라......')
        vars[52] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        if vars[3]:
            stage.reward(0, [
                91,
                -1])
        else:
            stage.reward(0, [
                96,
                -1])
        stage.end()
        vars[0] = 1
        vars[604] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 청주에서 황띠군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
