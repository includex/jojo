# Source Generated with Decompyle++
# File: R_03.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            127,
            32,
            53,
            1],
        [
            132,
            32,
            44,
            1],
        [
            192,
            50,
            40,
            2],
        [
            193,
            58,
            40,
            2],
        [
            181,
            50,
            70],
        [
            182,
            58,
            70]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setEventName('낙양에서 큰 화재가 발생했다')
    stage.setStageName('뤄양, 총리 관저')
    stage.unit(127).setAction(0, 0)
    stage.say('&127\n리루, 연합군이 이미 낙양에 접근하고 있다.')
    stage.unit(132).setAction(0, 2)
    stage.say('&132\n네.')
    stage.unit(127).setAction(3)
    stage.say('&127\n좋은 아이디어 있나요?')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(132).setAction(6)
    stage.say('&132\n낙양은 개활지로 둘러싸여 있어 방어에 적합하지 않았다.')
    stage.say('&132\n그래서 낙양은 버려졌다,\n수도를 자연 요새가 있는 장안으로 옮기고 재정비하세요.')
    stage.unit(132).setAction(0)
    stage.say('&127\n음, 수도를 옮긴다는 말인가요?')
    stage.unit(127).setAction(0, 3)
    stage.say('&127\n이게 유일한 방법인 것 같아.')
    stage.unit(192).setAction(3)
    stage.say('&192\n뭐라고...... 뭐라고!?')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n...... 잠깐!\n이 일은 절대 끝나면 안 됩니다.')
    stage.unit(127).setAction(0, 1)
    stage.say('&127\n응? 어떻게? 누가 반대하지?')
    stage.unit(192).setAction(6)
    stage.say('&192\n낙양은 오랜 역사를 가진 수도입니다.')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.unit(127).setAction(2)
    stage.say('&127\n젠장, 연합군이 아마 공격하려 할 거야,\n어떤 역사를 이야기할 수 있을까요?')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(193).setAction(6)
    stage.say('&193\n수도를 급하게 옮기면 백성들이 고통받을 것이다.')
    stage.unit(193).setAction(0)
    stage.delay(3)
    stage.unit(192).setAction(6)
    stage.say('&192\n네, 농민들은 이 때문에 땅을 잃게 될 것입니다.\n상인들은 가게를 잃게 될 것이다.')
    stage.unit(192).setAction(0)
    stage.delay(3)
    stage.say('&127\n이 일로 인해 사람들이 고통받을 거라고 생각하나요?')
    stage.unit(127).setAction(0, 3)
    stage.say('&127\n흠, 알겠어요.')
    stage.unit(127).setAction(-1, 0)
    stage.say('&127\n리루!')
    stage.unit(132).setAction(6)
    stage.say('&132\n존재한다.')
    stage.unit(132).setAction(0)
    stage.delay(3)
    stage.unit(127).setAction(3)
    stage.say('&127\n불을 지펴 낙양을 재로 만들고,\n국민의 모든 재산은 몰수되었다.')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(127).setAction(0, 1)
    stage.say('&127\n남은 것이 없으니 땅이나 상점이 필요 없습니다.')
    stage.unit(127).setAction(3)
    stage.say('&127\n하하하하!!')
    stage.unit(127).setAction(0)
    stage.delay(3)
    stage.unit(132).setAction(6)
    stage.say('&132\n총리님은 정말 현명하십니다; 즉시 임무를 수행하겠습니다.')
    stage.unit(132).setAction(0)
    stage.delay(3)
    stage.unit(127).setAction(0, 3)
    stage.say('&127\n사람들은 나를 진심으로 섬기면 된다.')
    stage.unit(127).setAction(3)
    stage.say('&127\n하하하.')
    stage.unit(193).setAction(6)
    stage.say('&193\n아!')
    stage.unit(192).setAction(6)
    stage.say('&192\n…… 이것은 단순히 악마의 행위일 뿐입니다.')
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 39)
    stage.showUnits([
        [
            153,
            69,
            60],
        [
            17,
            69,
            50,
            2]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('뤄양, 왕윈의 거처')
    stage.unit(153).setAction(3)
    stage.say('&153\n초선, 좋은 소식이야!\n연합군은 마침내 후라오 고개를 점령했다.')
    stage.unit(153).setAction(0)
    stage.delay(3)
    stage.unit(17).setAction(3)
    stage.say('&17\n정말? 그럼 낙양이 곧 함락될까?\n아빠?')
    stage.unit(17).setAction(0)
    stage.say('&153\n흠!')
    stage.unit(153).setAction(0, 1)
    stage.say('&153\n동탁 운명이 다 떨어지고 있어.')
    stage.delay(5)
    stage.say('&153\n그런데, 그초선,')
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n연합군 참모장교가 그렇게 조조했다고 들었어요.')
    if vars[302]:
        stage.unit(17).setAction(3)
        stage.say('&17\n아, 그러니까 그 조조 주인님!')
        stage.unit(17).setAction(0)
        stage.say('&153\n흠.')
        stage.unit(153).setAction(0, 1)
        stage.say('&153\n그는 진정으로 그의 신뢰에 부응하여 반동탁 연합을 형성하는 데 기여했다.\n이제 드디어 동탁를 제거할 때가 왔습니다.')
        stage.unit(153).setAction(3)
        stage.say('&153\n이 젊은이는 정말 평범한 사람이 아닙니다.')
        stage.unit(153).setAction(0)
        stage.delay(5)
        stage.unit(153).setAction(0, 0)
        stage.say('&153\n그나저나, 정말 고마워조조.')
        stage.unit(17).setAction(6)
        stage.unit(17).setAction(0, 0)
        stage.say('&17\n아버지가 다시 농담을 던졌다.')
        stage.unit(17).setAction(0, 2)
        stage.delay(3)
        stage.unit(17).setAction(6)
        stage.say('&17\n그렇지 않아!')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n하하하, 아빠가 너무 심했네, 하하하.')
        stage.unit(153).setAction(0)
    if not vars[302]:
        stage.say('&17\n……。')
        stage.delay(5)
        stage.say('&17\n......조조 선생님?"')
        stage.say('&153\n뭐, 잊었어?')
        stage.say('&153\n나는 대사령관과 함께 우리 집에 자주 왔어.')
        stage.unit(17).setAction(6)
        stage.say('&17\n아, 그 사람이야?')
        stage.unit(17).setAction(0)
        stage.delay(3)
        stage.unit(153).setAction(3)
        stage.say('&153\n하하하, 내 딸아!\n좋아, 조조 화려한 귀환을 기다리자.')
        stage.unit(153).setAction(0)
    stage.delay(5)
    stage.showUnit(181, 55, 30, 2)
    stage.say('&181\n보고해!')
    stage.delay(5)
    stage.unit(17).setAction(0, 0)
    stage.delay(3)
    stage.say('&181\n재상의 명령을 왕윤 장관에게 전해라.')
    stage.say('&153\n응? 도대체 무슨 일이 벌어지고 있는 거야?')
    stage.say('&181\n승상께서 오늘 장안 천도를 상주하셨고,\n폐하께서 이미 윤허하셨습니다.\n&181\n사도 대인께서는 즉시 장안으로 가 주십시오.')
    stage.unit(153).setAction(3)
    stage.say('&153\n뭐라고...... 뭐라고? 수도를 옮긴다고?')
    stage.unit(153).setAction(0)
    stage.delay(5)
    stage.unit(153).setAction(0, 1)
    stage.delay(5)
    stage.say('&153\n(동탁 이 짐승은 ......! )')
    stage.delay(10)
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n…… 그럼 바로 준비할게.')
    stage.say('&181\n즉시 총리님께 보고하겠습니다.')
    stage.delay(3)
    stage.unit(181).hide()
    stage.delay(8)
    stage.unit(153).setAction(0, 1)
    stage.say('&153\n젠장... 내가 동탁를 과소평가했나 봐.')
    stage.unit(17).setAction(0, 2)
    stage.delay(5)
    stage.unit(17).setAction(6)
    stage.say('&17\n우리가 더 이상 낙양에 머물 수 없을까?')
    stage.unit(17).setAction(0)
    stage.delay(5)
    stage.unit(153).setAction(0, 0)
    stage.say('&153\n더 이상 할 수 없어; 황제의 칙령을 따라야 해.')
    stage.unit(153).setAction(0, 1)
    stage.say('&153\n그리고 폐하를 동탁의 독이 있는 손으로부터 보호해야 합니다!')
    stage.unit(17).setAction(6)
    stage.say('&17\n아버지 .......')
    stage.delay(5)
    stage.effectSound(203, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.clsUnit()
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 361, 45)
    stage.showHead(101, 425, 45)
    stage.showHead(161, 489, 45)
    stage.showHead(136, 361, 125)
    stage.showHead(99, 425, 125)
    stage.showHead(145, 489, 125)
    stage.delay(5)
    stage.showHead(127, 280, 78)
    stage.bottomTxt('연합군을 피하기 위해 동탁,', False, True, False)
    stage.delay(5)
    stage.head(127).move(191, 78)
    stage.bottomTxt('화재로 낙양이 불타자 수도는 장안으로 옮겨졌다.', True, True, False)
    stage.delay(5)
    stage.bottomTxt('낙양은 수도로서의 역사를 마감했다.', True, True, True)
    stage.bottomTxt('연합군은 불길을 보고 충격을 받았다,', False, True, False)
    stage.head(0).move(280, 45)
    stage.head(101).move(344, 45)
    stage.head(161).move(408, 45)
    stage.head(136).move(280, 125)
    stage.head(99).move(344, 125)
    stage.head(145).move(408, 125)
    stage.bottomTxt('그래서 그들은 진군을 가속해 낙양성에 진입했다.', True, False, True)
    stage.bgSound(-1)
    stage.loadBg(2, 54)
    stage.showUnits([
        [
            101,
            54,
            37,
            2],
        [
            0,
            44,
            46,
            1]])
    stage.draw()
    stage.effectSound(203, 0)
    stage.delay(3)
    stage.setStageName('뤄양: 연합군 본진')
    stage.say('&0\n원소님, 방금 받은 정보에 따르면,\n동탁 수도를 장안으로 옮기려 했다.')
    stage.say('&101\n응? 수도를 옮긴다고 했......?')
    stage.say('&0\n그들은 ...... 장안으로 가는 중이었다.')
    stage.unit(0).setAction(17)
    stage.say('&0\n지금이 완벽한 기회입니다; 즉시 추구해야 합니다.')
    stage.unit(0).setAction(0)
    stage.say('&101\n아니, 힘을 아끼려면 적절한 순간을 기다리는 게 낫겠어.\n어쨌든, 낙양은 이미 점령당했어.')
    stage.say('&0\n원소Sir, 우리의 목표는 이게 아닙니다\n이 폐허를 차지하라.')
    stage.delay(5)
    stage.unit(101).setAction(0, 0)
    stage.say('&101\n조조, 네가 무슨 말 하는지 알아?')
    stage.delay(3)
    stage.unit(101).setAction(0, 2)
    stage.say('&101\n아무 말 없이 수도를 장안으로 옮길 거라고 생각동탁나?\n우리에게 어떤 조치도 안 취하고 있나?')
    stage.unit(101).setAction(3)
    stage.say('&101\n지금 동탁 쫓는 건 너무 위험해!')
    stage.unit(101).setAction(17)
    stage.say('&101\n나는 지휘관이고, 진격을 멈추라고 명령할 권한이 있다.')
    stage.unit(101).setAction(0)
    stage.say('&0\n응.......')
    stage.effectSound(203, 255)
    stage.delay(3)
    stage.bgSound(11)
    stage.delay(3)
    sel = stage.choice('그리고 그들의 own동탁을 추격했다\npursuit동탁을 버려라.', -1)
    if sel == 1:
        vars[303] = 1
        stage.addAmbition(5)
        stage.bgSound(-1)
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.say('...알았다.')
        stage.delay(5)
        stage.unit(0).setAction(2)
        model.setFace(2)
        stage.say('&0\n내가 직접 쫓아갈게, 너는 낙양에서 좋은 소식을 기다려.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.delay(3)
        stage.unit(101).setAction(3)
        stage.say('&101\n너 ...... 뭐라고 했어......?')
        stage.unit(101).setAction(0)
        stage.say('&101\n조조, 어떻게 감히 그렇게 고집을 부릴 수 있니?')
        stage.say('&0\n원소 선생님, 후회하지 마세요."\n지금이 바로 우리의 힘을 세상에 보여줄 때입니다,\n그리고 이 훌륭한 기회를 놓치게 될 것입니다.')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n안녕히 계세요, 원소 경.')
        stage.unit(0).move(44, 98, 2)
        stage.unit(0).hide()
        stage.delay(5)
        stage.unit(101).setAction(0, 1)
        stage.say('&101\n이 사람은 조조What 하려는 거야......?')
        stage.effectSound(203, 255)
        stage.clsUnit()
        return False
    if sel == 2:
        vars[303] = 0
        stage.addAmbition(-5)
        stage.bgSound(-1)
        stage.effectSound(203, 0)
        stage.delay(3)
        stage.say('...알았어, 더는 쫓지 않겠다.')
        stage.unit(101).setAction(3)
        stage.say('&101\n정말?')
        stage.unit(101).setAction(0)
        stage.say('&0\n원소Sir, 오해하지 마.\n내가 네 말을 듣기 위해 이러는 게 아니야.')
        stage.say('&101\n……。')
        stage.unit(0).setAction(0, 2)
        stage.say('&0\n이런 좋은 기회조차 잡지 못한다면,\n이는 원소의 관대함이 특별하지 않다는 것을 보여준다.')
        stage.unit(101).setAction(2)
        stage.say('&101\n너, 뭐라고 했어!')
        stage.unit(101).setAction(0)
        stage.delay(3)
        stage.unit(0).setAction(0, 1)
        stage.delay(5)
        stage.unit(0).setAction(3)
        model.setFace(3)
        stage.say('하하하하하, 절대 화내지 마세요.')
        model.setFace(0)
        stage.unit(0).setAction(0)
        stage.say('&0\n병사들에게 휴식을 명령하라.')
        stage.unit(0).setAction(0, 2)
        stage.delay(5)
        stage.say('(감히 천하에 이름을 떨치고 위세를 세울 좋은 기회를 놓치다니.)')
        stage.unit(0).move(44, 98, 2)
        stage.unit(0).hide()
        stage.delay(5)
        stage.unit(101).setAction(0, 1)
        stage.say('&101\n쳇! 도대체 조조What 생각하는 거야?')
        stage.effectSound(203, 255)
        stage.clsUnit()
        stage.jumpScene(7)
    return False


def scene3():
    stage.bgSound(15)
    stage.loadBg(2, 21)
    stage.showUnits([
        [
            0,
            49,
            66],
        [
            1,
            39,
            52,
            1],
        [
            5,
            39,
            46,
            1],
        [
            10,
            39,
            40,
            1],
        [
            6,
            60,
            52,
            3],
        [
            12,
            60,
            46,
            3],
        [
            11,
            60,
            40,
            3]])
    stage.draw()
    stage.setStageName('뤄양 조조군 본캠프')
    stage.say('&0\n아군 혼자 동탁을 쫓으러 갈 거야.\n모두가 승리에 대한 신뢰를 가져야 합니다.')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 7, [
        1])
    gvars[4076] = 0
    gvars[4057] = 3
    stage.setBattlePos([
        [
            0,
            6],
        [
            1,
            5],
        [
            1,
            8],
        [
            1,
            6],
        [
            1,
            7],
        [
            0,
            5],
        [
            0,
            8],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출발.')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(1):
        stage.say('&1\n원소 이 겁쟁이,\n그때 맹덕 감독이었더라면 좋았을 텐데.\n&0\n원양, 그만 말해.')
    if stage.unitClickTest(6):
        stage.say('&6\n싸움은 끊임없는 공격이 아닙니다,\n타이밍이 매우 중요합니다.......\n&0\n하후연, 또 군사 전략을 검토하는 거야? 정말 성실하구나.\n&6\n아니, 좀 배워야 해.')
    if stage.unitClickTest(5):
        stage.say('&5\n이봐! 동탁 별일 아니야.\n&0\n이봐, 이봐, 경계를 늦추면 안 돼.......')
    if stage.unitClickTest(12):
        stage.say('&12\n동탁 군대가 백성을 이끌고 천천히 행진해야 한다...\n아마 싱양 근처에서 그들을 따라잡을 수 있을지도 몰라.')
    if stage.unitClickTest(10):
        stage.say('&10\n이번에는 내 실력을 보여줘야 해.')
    if stage.unitClickTest(11):
        stage.say('&11\n동탁의 전략가 리루는 전략에 뛰어났다.\n성양은 매복에도 적합해서 .......')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
