# Decompiled from SGCCZ custom Python 3.9 bytecode


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23], [
        '(13,11)',
        '(11,11)',
        '(13,13)',
        '(12,12)'])
    stage.nearEvent([
        0,
        136], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 2, 4)
    stage.createFriend([
        {
            'id': 119,
            'x': 1,
            'y': 13,
            'dir': 1,
            'lv': 6,
            'ai': 1,
            'i': 0 },
        {
            'id': 322,
            'x': 1,
            'y': 12,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 1 },
        {
            'id': 323,
            'x': 1,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'ai': 1,
            'i': 2 },
        {
            'id': 100,
            'x': 1,
            'y': 22,
            'dir': 0,
            'lv': 6,
            'ai': 1,
            'i': 3 },
        {
            'id': 258,
            'x': 1,
            'y': 21,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 259,
            'x': 2,
            'y': 23,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 32,
            'x': 23,
            'y': 12,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 6 },
        {
            'id': 3,
            'x': 23,
            'y': 11,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 7 },
        {
            'id': 33,
            'x': 23,
            'y': 13,
            'dir': 3,
            'lv': 6,
            'ai': 1,
            'i': 8 },
        {
            'id': 192,
            'hide': 1,
            'x': 11,
            'y': 0,
            'lv': 0,
            'i': 9 }])
    stage.createEnemy([
        {
            'id': 136,
            'x': 12,
            'y': 12,
            'lv': 6,
            'i': 0 },
        {
            'id': 298,
            'x': 11,
            'y': 11,
            'lv': 0,
            'ai': 0,
            'i': 1 },
        {
            'id': 299,
            'x': 13,
            'y': 13,
            'lv': 0,
            'ai': 0,
            'i': 2 },
        {
            'id': 310,
            'x': 12,
            'y': 13,
            'lv': 0,
            'ai': 0,
            'i': 3 },
        {
            'id': 311,
            'x': 10,
            'y': 9,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 318,
            'x': 11,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 319,
            'x': 8,
            'y': 14,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 320,
            'x': 13,
            'y': 15,
            'lv': 0,
            'ai': 0,
            'i': 7 },
        {
            'id': 321,
            'x': 15,
            'y': 11,
            'lv': 0,
            'ai': 0,
            'i': 8 },
        {
            'id': 210,
            'x': 11,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 9 },
        {
            'id': 211,
            'x': 12,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 10 },
        {
            'id': 234,
            'x': 10,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 11 },
        {
            'id': 235,
            'x': 13,
            'y': 7,
            'dir': 0,
            'lv': 0,
            'i': 12 },
        {
            'id': 236,
            'x': 11,
            'y': 8,
            'dir': 0,
            'lv': 0,
            'i': 13 },
        {
            'id': 212,
            'x': 7,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'i': 14 },
        {
            'id': 213,
            'x': 7,
            'y': 13,
            'dir': 3,
            'lv': 0,
            'i': 15 },
        {
            'id': 237,
            'x': 7,
            'y': 11,
            'dir': 3,
            'lv': 0,
            'i': 16 },
        {
            'id': 238,
            'x': 7,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'i': 17 },
        {
            'id': 239,
            'x': 8,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'i': 18 },
        {
            'id': 214,
            'x': 11,
            'y': 17,
            'lv': 0,
            'i': 19 },
        {
            'id': 215,
            'x': 12,
            'y': 17,
            'lv': 0,
            'i': 20 },
        {
            'id': 240,
            'x': 10,
            'y': 17,
            'lv': 0,
            'i': 21 },
        {
            'id': 241,
            'x': 13,
            'y': 17,
            'lv': 0,
            'i': 22 },
        {
            'id': 242,
            'x': 11,
            'y': 16,
            'lv': 0,
            'i': 23 },
        {
            'id': 216,
            'x': 17,
            'y': 12,
            'dir': 1,
            'lv': 0,
            'i': 24 },
        {
            'id': 217,
            'x': 17,
            'y': 13,
            'dir': 1,
            'lv': 0,
            'i': 25 },
        {
            'id': 243,
            'x': 17,
            'y': 11,
            'dir': 1,
            'lv': 0,
            'i': 26 },
        {
            'id': 244,
            'x': 17,
            'y': 14,
            'dir': 1,
            'lv': 0,
            'i': 27 },
        {
            'id': 245,
            'x': 16,
            'y': 12,
            'dir': 1,
            'lv': 0,
            'i': 28 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 12 },
        {
            'idx': 1,
            'x': 13 },
        {
            'idx': 2,
            'x': 13,
            'y': 2 },
        {
            'idx': 3,
            'x': 12,
            'y': 2 },
        {
            'idx': 4,
            'x': 11,
            'y': 2 },
        {
            'idx': 5,
            'x': 12,
            'y': 1 },
        {
            'idx': 6,
            'x': 14,
            'y': 1 },
        {
            'idx': 7,
            'x': 10,
            'y': 1 },
        {
            'idx': 8,
            'x': 13,
            'y': 1 },
        {
            'idx': 9,
            'x': 11,
            'y': 1 },
        {
            'idx': 10,
            'x': 10 },
        {
            'idx': 11,
            'x': 14 },
        {
            'idx': 12 },
        {
            'idx': 13 },
        {
            'idx': 14 }])
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(3, 36, 0, -1, 0, -1)
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.loadBg(11)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab27')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab27')
    stage.draw()
    stage.bgSound(1)
    stage.unit(192).show()
    stage.say('&192\n주군, 나쁜 일이 생겼어.\n&0\n무슨 일이야? 곡물 담당관.\n&192\n이 폭우에 영향을 받아,\n도착하기로 되어 있던 군수품들,\n도착하는 데 시간이 오래 걸릴 거야.')
    stage.unit(0).setDir(stage.countDir(0, 192))
    stage.unit(0).setAction(10)
    stage.say('&0\n뭐라고!\n&192\n비록 조치를 취했지만,\n병사들의 식량을 끊고,\n하지만 남은 시간은 단 3일뿐이었다.\n&0\n음, 그건 좋지 않네.\n이런 상황이 계속되면 일부 병사들이 탈출할 것입니다.\n그는 해결책을 찾아야 했다......')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n주군, 유비와 상의해도 됩니다,\n주군 유비에게 친절을 베풀었고,\n거절하기가 힘들었을 것이다.')
    stage.unit(22).setDir(stage.countDir(22, 192))
    stage.say('&22\n곡물 담당관!\n&22\n이유가 무엇이든,\n군수량 배송을 지연시키는 것은 당신의 책임이며 엄중히 처벌받아야 합니다.\n&192\n그래서...... 그건 다 폭우 때문이야.......\n&22\n이 문제는 이 전투의 결과에 매우 중요했다.\n사형을 피할 수 없을 것 같군.\n&192\n제발, 선생님, 제 목숨을 살려 주세요......!')
    stage.unit(0).setDir(stage.countDir(0, 22))
    stage.say('곽가, 그도 너무 무섭게 하지 마. 이렇게 비가 많이 오니 어쩔 수 없는 일이야. 이렇게 장난치는 건 지나치지 않았어?')
    stage.unit(22).setDir(stage.countDir(22, 0))
    stage.say('&22\n아니, 진심이야.\n군 기율이 허술하다면 어떻게 모두를 제지할 수 있겠습니까!\n&22\n조화는 군사 기법을 지킬 수 없다.\n&0\n무슨 뜻인지 모르는 건 아니곽가, 음, ..........')
    sel = stage.choice('도움을 요청하세요유비\n그리고 곡물 담당관은 처형당했다', -1)
    if sel == 1:
        stage.say('&0\n좋아, 곡물 담당관, 물러서도 좋다!\n&192\n네.')
        stage.setRectUnitHide(11, 0, 11, 0, 6)
        stage.unit(0).setDir(stage.countDir(0, 22))
        stage.say('곽가, 사람을 보내 현덕을 만나게 해라!')
        stage.unit(22).setDir(stage.countDir(22, 0))
        stage.say('&22\n네, 바로 처리하겠습니다.')
        stage.unit(3).setDir(stage.countDir(3, 32))
        stage.say('&3\n형님, 조조 누군가를 보내 면담을 요청하게 하세요,\n식량 지원 요청합니다.')
        stage.unit(32).setDir(stage.countDir(32, 3))
        stage.say('&32\n조조 우리를 챙겨줬어,\n그게 유일한 방법입니다.')
        stage.unit(33).setDir(stage.countDir(33, 32))
        stage.say('&33\n뭐라고 했어?\n우리도 부유하지 않아!')
        stage.unit(32).setDir(stage.countDir(32, 33))
        stage.say('&32\n지금 조조와 잘 지낼 수 없다면,\n앞으로 관계는 매우 어려워질 것입니다,\n그래서 이번에는 상대방을 도와야 했다.......\n&33\n정말 그런가요?\n정말 이해가 안 돼요!\n&3\n군수품을 준비하고 조의 진영으로 옮길게.')
        stage.unit(0).setDir(2)
        stage.unit(22).setDir(2)
        stage.unit(32).setDir(3)
        stage.unit(3).setDir(3)
        stage.unit(33).setDir(3)
        stage.say('&22\n유비 이미 동의했어,\n그는 또한 군사 보급품도 가져왔다,\n다음에 뭘 해야 할까?\n&0\n좋아, 군대 전체가 싸울 준비 완료!\n즉시 쇼춘에 대한 공격을 개시했다.\n&22\n네!')
        stage.bgSound(4)
        stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
        stage.showWinCondition('전부 전멸시적군!')
    elif sel == 2:
        stage.unit(0).setDir(stage.countDir(0, 192))
        stage.say('군법대로 처리한다. 곡식 관리에게 사형을 선고한다.\n어른께서는 어찌 이리 잔인하십니까… 제가 주군님을 따르면서 오늘까지도, 어른께서 이런 분이신 줄은 알지 못했습니다…\n저는 죽음을 각오하고 있습니다. 죽이든 베든 마음대로 하십시오.\n음! 당신은 당장 이곳을 떠나세요.\n아? 뭐라고요?\n제가 전군에 공지하겠습니다. 당신이 군량을 횡령한 죄로 이미 자백했으니, 더 이상 여기에 머무를 수 없습니다.\n당신에게 평생 살 만큼의 돈을 상으로 줄 테니, 일이 진정된 후에 다시 부르겠습니다.\n알고 보니 그런 거였군요. 어른께서 너무 심하십니다! 하지만 이것도 대국을 위한 것이니, 제가 받아들이겠습니다.')
        stage.setRectUnitHide(11, 0, 11, 0, 6)
        stage.unit(0).setDir(stage.countDir(0, 22))
        stage.say('곽가, 전군에 공문을 보내라. 곡식 담당관이 군량을 횡령하다 목이 베였다고 하라.')
        stage.unit(22).setDir(stage.countDir(22, 0))
        stage.say('&22\n최근 식량 부족 문제,\n모든 책임은 곡물 공급 담당자들에게 전가되었다.\n이렇게 해서 병사들은 불만을 품지 않았다.\n&22\n하지만 제발 잊지 주군 마라,\n우리는 앞으로의 도전을 극복하기 위해 여기 있습니다.')
        stage.unit(22).setDir(2)
        stage.unit(0).setDir(2)
        stage.say('&0\n어떻게든 이 싸움은 신속하게 끝내야 해.\n&22\n이건 힘든 싸움이 될 것 같군.')
        stage.bgSound(4)
        stage.setWinCondition('승리 조건\n1. 원술 격퇴.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 12명을 초과한다.')
        stage.setMaxRound(12)
        stage.showWinCondition('원술을 쫓아내라!')
        stage.unit(136).heightLight()
        vars[2] = 1
    stage.unit(0).setAction(5)
    stage.say('&0\n전면 공격!')
    stage.unit(0).setAction(0)
    stage.say('&119\n조조랑 팀을 이룰 줄은 몰랐어...\n공직의 외교 능력은 정말 놀랍습니다.\n정말 훌륭한 전략가를 만났습니다.')
    stage.unit(119).setAction(5)
    stage.say('&119\n좋아, 전군이 전투에 나선다!\n이 전투는 반드시 이겨야 한다.')
    stage.unit(119).setAction(0)
    stage.unit(100).setAction(5)
    stage.say('&100\n흠, 조조 행동에 옮겼어? 우리도 약속을 지켰어.\n좋아, 전면 공격!')
    stage.unit(100).setAction(0)
    stage.unit(32).setAction(5)
    stage.say('&32\n둘째 형, 셋째 형, 공격해!')
    stage.unit(32).setAction(0)
    stage.unit(136).setDir(1)
    stage.unit(136).setDir(2)
    stage.unit(136).setDir(3)
    stage.unit(136).setDir(0)
    stage.unit(136).setAction(8)
    stage.say('&136\n응? 여포와 손책도 .......')
    stage.startOper()
    vars[511] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if (vars[2]) and (not (vars[11])) and (stage.round() == 12) and (stage.curCamp() == 2):
        stage.say('&0\n음, 알갱이가 다 남았네......\n선택의 여지가 없어, 후퇴해!\n전군을 후퇴시켜라!')
        vars[11] = 1
        stage.info('조조 원술군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    if (not (vars[20])) and (stage.isInPos(1025, 13, 11)):
        stage.getItem(156, 0, True, 1025)
        vars[20] = 1
    if (not (vars[21])) and (stage.isInPos(1025, 11, 11)):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if (not (vars[22])) and (stage.isInPos(1025, 13, 13)):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if (not (vars[23])) and (stage.isInPos(1025, 12, 12)):
        stage.getItem(151, 0, True, 1025)
        vars[23] = 1
    if (not (vars[30])) and (stage.isInRect(1025, 9, 6, 14, 8)):
        stage.unit(210).setAI(1)
        stage.unit(211).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(236).setAI(1)
        vars[30] = 1
    if (not (vars[31])) and (stage.isInRect(1025, 6, 10, 8, 15)):
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[31] = 1
    if (not (vars[32])) and (stage.isInRect(1025, 9, 16, 14, 18)):
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(240).setAI(1)
        stage.unit(241).setAI(1)
        stage.unit(242).setAI(1)
        vars[32] = 1
    if (not (vars[33])) and (stage.isInRect(1025, 16, 10, 18, 15)):
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(243).setAI(1)
        stage.unit(244).setAI(1)
        stage.unit(245).setAI(1)
        vars[33] = 1
    if (not (vars[40])) and (stage.isNear(0, 136, True)):
        stage.unit(0).setDir(stage.countDir(0, 136))
        stage.unit(136).setDir(stage.countDir(136, 0))
        stage.say('&0\n오랜만이야, 원술.\n넌 아직도 너무 멍청해.\n&136\n어떻게 감히 황제에게 그런 말을 할 수 있니,\n누군가! 누군가 그를 내 대신 처형할 수 있어!\n&0\n너 같은 바보들과 싸우면 내 명성만 망칠 뿐이야.\n하지만 가짜 황제인 당신만 가만히 있을 수는 없어요!\n그냥 내려서 항복해!\n&136\n젠장!')
        vars[40] = 1
    if (not (vars[50])) and (stage.unitStateTest(119, 7, 0, 2)):
        stage.say('&119\n좋아, 이미 조조 호의를 베풀었어!\n공무원은 적절한 시기에 다시 나오겠다고 했습니다.\n그리고 후퇴하세요.')
        stage.unit(119).hide(1)
        vars[50] = 1
    if (not (vars[51])) and (stage.unitStateTest(100, 7, 0, 2)):
        stage.say('&100\n원술를 이기지 못하는 것은 이렇게 그냥 떠나고 싶지 않다는 뜻입니다.\n하지만 여기서 죽을 수는 없어—후퇴해야 해.')
        stage.unit(100).hide(1)
        vars[51] = 1
    if (not (vars[52])) and (stage.unitStateTest(32, 7, 0, 2)):
        stage.say('&32\n흠, 어쩔 수 없이 물러날 수밖에 없었.......')
        stage.unit(32).hide(1)
        vars[52] = 1
    if (not (vars[53])) and (stage.unitStateTest(3, 7, 0, 2)):
        stage.say('&3\n오늘은 여기까지입니다.\n후퇴!')
        stage.unit(3).hide(1)
        vars[53] = 1
    if (not (vars[54])) and (stage.unitStateTest(33, 7, 0, 2)):
        stage.say('&33\n휴, 이제 거의 죽임을 다 했네.\n배불리 먹었으니 돌아가자.')
        stage.unit(33).hide(1)
        vars[54] = 1
    if (not (vars[55])) and (stage.unitStateTest(136, 7, 0, 2)):
        stage.say('&136\n한숨, 정말 운이 없네.\n쇼춘시를 원하면 그냥 가져가!\n저에게 더 잘 맞는 도시들이 다른 곳에 있습니다.')
        stage.unit(136).hide(1)
        vars[55] = 1
        if (vars[2]):
            stage.resumeCtrl()
            stage.setRectUnitHide(0, 0, 23, 23, 2)
            stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
            stage.reward(0, list((51, -1, 114, -1, 160, -1)))
            stage.end()
            vars[0] = 1
            vars[100] = 1
            vars[611] = 1
            return True
    if (not (vars[0])) and (stage.winTest()):
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n아군 이겼어!')
        stage.reward(0, list((51, -1, 114, -1)))
        stage.end()
        vars[0] = 1
        vars[611] = 1
        return True
    if (not (vars[1])) and (stage.loseTest()):
        stage.info('조조 원술군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True
    return False


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
