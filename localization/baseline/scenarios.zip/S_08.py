# Source Generated with Decompyle++
# File: S_08.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25], [
        '(18,3)',
        '(18,2)',
        '(19,2)',
        '(20,2)',
        '(4,2)',
        '(19,3)'])
    stage.nearEvent([
        16,
        119,
        15,
        119,
        1,
        119], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 174,
            'hide': 1,
            'x': 20,
            'y': 3,
            'lv': 0,
            'i': 0 }])
    stage.createEnemy([
        {
            'id': 119,
            'x': 19,
            'y': 3,
            'lv': 6,
            'ai': 0,
            'i': 0 },
        {
            'id': 126,
            'x': 20,
            'y': 3,
            'lv': 6,
            'ai': 0,
            'i': 1 },
        {
            'id': 266,
            'x': 17,
            'y': 2,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 2 },
        {
            'id': 267,
            'x': 17,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 3 },
        {
            'id': 268,
            'x': 19,
            'y': 4,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 269,
            'x': 20,
            'y': 4,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 286,
            'x': 18,
            'y': 2,
            'lv': 0,
            'ai': 0,
            'i': 6 },
        {
            'id': 287,
            'x': 20,
            'y': 2,
            'lv': 0,
            'ai': 0,
            'i': 7 },
        {
            'id': 214,
            'x': 9,
            'y': 2,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 8 },
        {
            'id': 215,
            'x': 9,
            'y': 3,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 9 },
        {
            'id': 236,
            'x': 9,
            'y': 1,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 10 },
        {
            'id': 237,
            'x': 9,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 11 },
        {
            'id': 216,
            'x': 19,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 12 },
        {
            'id': 217,
            'x': 20,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 13 },
        {
            'id': 238,
            'x': 18,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 14 },
        {
            'id': 239,
            'x': 21,
            'y': 12,
            'lv': 0,
            'ai': 0,
            'i': 15 },
        {
            'id': 2,
            'x': 4,
            'y': 2,
            'lv': 6,
            'ai': 1,
            'i': 16 },
        {
            'id': 259,
            'x': 3,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 260,
            'x': 4,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 261,
            'x': 5,
            'y': 3,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 282,
            'x': 3,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 283,
            'x': 5,
            'y': 2,
            'lv': 0,
            'ai': 1,
            'i': 21 },
        {
            'id': 125,
            'x': 20,
            'y': 16,
            'dir': 3,
            'lv': 4,
            'ai': 1,
            'i': 22 },
        {
            'id': 263,
            'x': 19,
            'y': 15,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 23 },
        {
            'id': 264,
            'x': 19,
            'y': 16,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 24 },
        {
            'id': 265,
            'x': 19,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 25 },
        {
            'id': 284,
            'x': 20,
            'y': 15,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 26 },
        {
            'id': 285,
            'x': 20,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 27 },
        {
            'id': 288,
            'x': 19,
            'y': 2,
            'lv': 0,
            'ai': 0,
            'i': 28 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 2,
            'y': 21,
            'dir': 1 },
        {
            'idx': 1,
            'x': 2,
            'y': 19,
            'dir': 1 },
        {
            'idx': 2,
            'x': 3,
            'y': 20,
            'dir': 1 },
        {
            'idx': 3,
            'x': 4,
            'y': 21,
            'dir': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 18,
            'dir': 1 },
        {
            'idx': 5,
            'x': 5,
            'y': 22,
            'dir': 1 },
        {
            'idx': 6,
            'x': 1,
            'y': 19,
            'dir': 1 },
        {
            'idx': 7,
            'x': 4,
            'y': 22,
            'dir': 1 },
        {
            'idx': 8,
            'x': 2,
            'y': 20,
            'dir': 1 },
        {
            'idx': 9,
            'x': 3,
            'y': 21,
            'dir': 1 },
        {
            'idx': 10,
            'y': 20,
            'dir': 1 },
        {
            'idx': 11,
            'x': 2,
            'y': 23,
            'dir': 1 },
        {
            'idx': 12,
            'x': 1,
            'y': 21,
            'dir': 1 },
        {
            'idx': 13,
            'x': 2,
            'y': 22,
            'dir': 1 },
        {
            'idx': 14,
            'x': 1,
            'y': 22,
            'dir': 1 }])
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(125, -1, 0, -1, 0, 19)
    stage.setEnemyEquip(126, -1, 0, -1, 0, 8)
    stage.loadBg(8)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab26')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab26')
    stage.draw()
    stage.bgSound(3)
    stage.unit(119).setDir(stage.countDir(119, 0))
    stage.unit(16).setAction(5)
    stage.say('&16\n이번이 세 번째야,\n이번에는 반드시 여포을 제거해야 합니다.')
    stage.unit(16).setAction(0)
    stage.unit(1).setAction(7)
    stage.say('&1\n도망칠 곳이 없어!\n포기해!')
    stage.unit(1).setAction(0)
    stage.say('&119\n응.\n그들은 실제로 우리 .......를 공격하기 위해 엄청난 병력을 동원했다\n&2\n우리는 죽겠다는 결의를 굳건히 지켜야 합니다.\n무슨 일이 있어도 반드시 이겨야 .......\n&125\n하하하, 이렇게 작은 군대는 사실상 쓸모가 없네요.')
    stage.unit(0).setAction(5)
    stage.say('&0\n여포, 네 목숨을 가져와.')
    stage.unit(0).setAction(0)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[508] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.round() == 4:
        stage.say('&119\n난 싸워서 빠져나갈 거야!\n내 갑옷을 가져와!\n&126\n주군, 공격은 아군에게 불리해!\n도시를 지켜주세요.')
        stage.unit(119).setDir(stage.countDir(119, 126))
        stage.say('&119\n적이 너무 많아 도시를 지킬 수 없을 것 같아,\n도시 밖으로 나가서 죽여.\n&126\n알았어, 나도 나갈게.\n하지만 억지로 하지 마라,\n때가 되면 먼저 도시로 돌아갈 거야.\n&126\n필요한 건 방어뿐이야.\n게다가 조조 대규모 군대를 배치하니,\n그는 이번이 마지막 싸움 기회라고 말했다.\n&126\n이 순간을 붙잡을 수 있다면,\n조조 푸양을 포기할 수밖에 없었다,\n그러므로 우리는 죽을 때까지 싸워야 합니다.\n&119\n흠!')
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.unit(119).setAI(1)
        stage.unit(126).setAI(1)
        stage.unit(266).setAI(1)
        stage.unit(267).setAI(1)
        stage.unit(268).setAI(1)
        stage.unit(269).setAI(1)
        stage.unit(286).setAI(1)
        stage.unit(287).setAI(1)
        stage.unit(288).setAI(1)
        vars[11] = 1
    if not vars[12] and not vars[50] and stage.round() == 6 and stage.curCamp() == 2:
        stage.unit(119).setDir(stage.countDir(119, 0))
        stage.unit(119).setAction(5)
        stage.say('&119\n전면 공격, 모두 따라와!')
        stage.unit(119).setAction(0)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(216).setAI(1)
        stage.unit(217).setAI(1)
        stage.unit(236).setAI(4, -1, 0, 3)
        stage.unit(237).setAI(4, -1, 0, 3)
        stage.unit(238).setAI(4, -1, 19, 23)
        stage.unit(239).setAI(4, -1, 19, 23)
        vars[12] = 1
    if not vars[13] and stage.round() == 7:
        stage.unit(236).setAI(1)
        stage.unit(237).setAI(1)
        stage.unit(238).setAI(1)
        stage.unit(239).setAI(1)
        vars[13] = 1
    if not vars[20] and stage.isInPos(1025, 18, 3):
        stage.getItem(157, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 18, 2):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 19, 2):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 20, 2):
        stage.getItem(150, 0, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 4, 2):
        stage.getItem(150, 0, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 19, 3):
        stage.getItem(151, 0, True, 1025)
        vars[25] = 1
    if not vars[6] and not vars[50] and stage.totalRectUnit(6, 8, 0, 22, 13) == 0 and stage.totalUnit(0) >= 8:
        stage.setObjects(True, 17, [
            [
                4,
                8,
                2],
            [
                5,
                8,
                3]])
        stage.setObjects(True, 17, [
            [
                6,
                19,
                13],
            [
                7,
                20,
                13]])
        stage.unit(119).setAction(10)
        stage.say('&119\n뭐, 무슨 일이야! 무슨 일이야!?')
        stage.unit(174).show()
        stage.say('&174\n정말 미안해, 문 닫았어.')
        stage.unit(119).setDir(stage.countDir(119, 174))
        stage.unit(119).setAction(5)
        stage.say('&119\n이 자식아! 왜 이러는 거야!\n&174\n전쟁 중에 우리 가족의 재산을 불태웠다,\n우린 너를 참을 수 없어,\n그래서 여기서 조조 지배하길 바랍니다.\n&119\n젠장, 젠장!')
        stage.unit(119).setAction(0)
        if not vars[51]:
            stage.unit(126).setDir(stage.countDir(126, 174))
            stage.unit(126).setAction(4)
            stage.say('&126\n계산을 잘못했어요!\n이전에는 상인들을 반란을 일으켜 세웠다,\n내가 너무 어리석었어.')
            stage.unit(119).setDir(stage.countDir(119, 126))
            stage.say('&119\n자책하지 마. 네가 아니었으면,\n저도 그렇게 많은 전투에서 이기지 못했을 거예요.')
            stage.unit(126).setDir(stage.countDir(126, 119))
            stage.say('&126\n뤼 ....... 장군\n(안 돼, 안 돼! 어떻게 전략가가 먼저 낙담할 수 있겠어! )\n&126\n상황이 나쁘지도 않았다; 먼저 그들은 조의 군대를 격퇴했고,\n도시를 다시 되찾으려 해.')
            stage.unit(119).setAction(5)
            stage.say('&119\n맞아요, 도전하세요!')
            stage.unit(119).setAction(0)
        else:
            stage.unit(119).setDir(stage.countDir(119, 174))
            stage.say('&119\n흠, 어쩔 수 없네!\n먼저 조조를 물리치고, 그 다음에 너를 처리하겠다, 교활한 상인아!')
        stage.setUnitStatus([
            {
                'hStatus': [
                    9],
                'x1': 0,
                'y1': 0,
                'x2': 23,
                'y2': 23,
                'camp': 2 }])
        stage.say('&174\n오, 요.\n이 상황에서도 여전히 야망이 있나?\n하하하!\n&174\n지금은 숨어야 해,\n전투가 끝날 때까지 기다리자, 안녕.\n&119\n젠장! 정말 미워!')
        stage.unit(174).hide()
        stage.unit(0).setDir(stage.countDir(0, 119))
        stage.unit(0).setAction(6)
        stage.say('적군의 진영이 불안정해졌어. 지금 상황은 소탕전으로 바뀌었어. 다들 돌격하자!')
        stage.unit(0).setAction(0)
        vars[6] = 1
    if not vars[40] and stage.isNear(16, 119, False):
        stage.unit(16).setDir(stage.countDir(16, 119))
        stage.unit(119).setDir(stage.countDir(119, 16))
        stage.say('&16\n음 오 오 오! 여포!\n네 목을 가져갈 거야!\n나랑 같이 해결해!\n&119\n가자! 내가 만나자.')
        stage.attackAction(16, 119, 2)
        stage.delay(10)
        stage.unit(119).setAction(6)
        stage.unit(119).setAction(0)
        stage.unit(16).setAction(2)
        stage.effectSound(31, 1)
        stage.delay(10)
        stage.say('&119\n흥, 흥, 흥!\n넌 아직 나한테 상대가 안 돼!')
        vars[40] = 1
    if not vars[41] and stage.isNear(15, 119, False):
        stage.unit(15).setDir(stage.countDir(15, 119))
        stage.unit(119).setDir(stage.countDir(119, 15))
        stage.say('&15\n여포 있어? 내가 처리할게!\n&119\n이 사람은 꽤 낯설어 보여요!\n자, 네가 뭘 하는지 보자.')
        stage.unit(15).setAction(6)
        stage.unit(15).setAction(0)
        stage.unit(119).setAction(2)
        stage.effectSound(31, 1)
        stage.delay(10)
        stage.attackAction(119, 15, 2)
        stage.delay(10)
        stage.say('&119\n아, 꽤 유능하네,\n하지만 이 정도 실력으로는 나를 이길 수 없어.')
        vars[41] = 1
    if not vars[42] and stage.isNear(1, 119, False):
        stage.unit(1).setDir(stage.countDir(1, 119))
        stage.unit(119).setDir(stage.countDir(119, 1))
        stage.say('&1\n내 하후돈 사격 실력을 경험해 봐!\n&119\n흥! 내 앞에서 이런 사소한 속임수,\n이건 기본적으로 전문가 앞에서 자랑하는 거예요!')
        stage.attackAction(1, 119, 2)
        stage.delay(10)
        stage.attackAction(119, 1, 2)
        stage.delay(10)
        stage.say('&119\n더는 못 참겠어, 더는 못 참겠어!')
        vars[42] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n정말 안타깝네요, 후퇴합시다.')
        stage.unit(119).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(126, 7, 0, 2):
        stage.say('&126\n루 장군님, 정말 죄송합니다!\n후퇴 .......')
        stage.unit(126).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(2, 7, 0, 2):
        stage.say('&2\n젠장, 적이 너무 많아.......\n후퇴!')
        stage.unit(2).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(125, 7, 0, 2):
        stage.say('&125\n그리고 바로 그 순간, 만성 질환이 다시 악화되었습니다. .......\n후퇴!')
        stage.unit(125).hide(1)
        vars[53] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어.\n아군 이겼어!')
        if vars[6]:
            stage.unit(174).show(20, 3, 2)
            stage.setObjects(False, 16, [
                [
                    4,
                    8,
                    2],
                [
                    5,
                    8,
                    3]])
            stage.setObjects(False, 16, [
                [
                    6,
                    19,
                    13],
                [
                    7,
                    20,
                    13]])
            if stage.unitStateTest(16, 7, 1, 0) and stage.unitStateTest(15, 7, 1, 0):
                vars[2] = 1
                stage.unit(0).move(20, 4, 0)
                stage.unit(16).move(19, 4, 0)
                stage.unit(15).move(21, 4, 0)
                stage.say('&174\n조조 진정으로 지휘에 능숙하다,\n이제부터 우호적인 관계를 쌓자.')
                stage.unit(16).setDir(stage.countDir(16, 0))
                stage.unit(0).setDir(stage.countDir(0, 16))
                stage.say('&16\n이 사람은 흐름에 몸을 맡기고 있어요—쉽게 믿지 마세요!\n정말 그를 내쫓고 싶어.......')
                stage.unit(15).setDir(stage.countDir(15, 0))
                stage.unit(0).setDir(stage.countDir(0, 15))
                stage.say('&15\n상인은 실제로 푸양을 되찾은 공로를 인정받았다.\n그냥 그냥 봐줄래......')
                stage.unit(0).setDir(stage.countDir(0, 174))
                stage.say('&0\n흠.......')
                sel = stage.choice('과거는 잊으라\n도시에서 쫓겨났다', -1)
                if sel == 1:
                    stage.say('&0\n이번에는 당신의 공로를 인정하며,\n과거는 추구하지 않을 것이다.\n&174\n네, 감사합니다, 선생님.\n&174\n조 공은 분명히 이 혼란스러운 시대를 통일할 수 있을 것이다,\n앞으로는 어른 여러분을 돕기 위해 노력을 아끼지 않을 것입니다.\n&0\n흠.\n&174\n그럼 받아......,\n성인도 사용할 수 있어야 한다고 생각합니다.')
                    stage.getItem(39, 0)
                elif sel == 2:
                    stage.unit(0).setAction(5)
                    stage.say('&0\n불의한 자여, 나는 너를 믿지 않아! 당장 부여성에서 꺼져.')
                    stage.unit(0).setAction(0)
                    stage.say('&174\n날 용서하지 않아......')
                    stage.setRectUnitHide(20, 3, 20, 3, 1)
                    stage.say('&16\n우리는 그의 자산을 압수했고, 그 금액이 꽤 많았다.\n그냥 군사 자금이라고 생각하세요!')
                    model.addMoney(3000)
                    stage.setStageName('3000골드를 얻었어!')
                    stage.say('&0\n공격, 방어, 외교, 국내 문제...\n이제부터 모든 것이 조율되고 정리되어야 합니다.')
            if not vars[2]:
                stage.say('&174\n조조 위대한 사람이 분명히 혼돈의 세상을 통합할 수 있을 것이다,\n앞으로는 당신을 위해 노력을 아끼지 않겠습니다.\n&0\n바로 그 상인의 지지 덕분입니다\n그래야만 군대를 조직할 수 있습니다. 앞으로 저를 잘 부탁드립니다.\n&174\n그러니 먼저 ......을 받아주세요,\n성인도 사용할 수 있어야 한다고 생각합니다.')
                stage.getItem(39, 0)
            stage.reward()
        else:
            stage.reward(0, [
                39,
                -1])
        stage.end()
        vars[0] = 1
        vars[608] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 여포군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
