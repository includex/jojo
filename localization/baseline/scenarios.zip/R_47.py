# Source Generated with Decompyle++
# File: R_47.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    stage.loadBg(2, 31)
    model.setRAvatar(3, 199)
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setEventName('복숭아정원의 꿈이 깨졌다')
    stage.setStageName('바이디 시 외곽의 산길')
    stage.showUnit(3, 5, 49, 1)
    stage.unit(3).move(51, 49, 1)
    stage.say('&3\n형!\n셋째 형님!\n아무 일도 일어나지 않게 해!')
    stage.showUnit(181, 95, 55, 3)
    stage.unit(181).move(59, 55, 3)
    stage.say('&181\n관, 관 장군!\n관장군인가요!?\n&3\n너...... 너희가 징저우 주둔군이냐?\n어디 가는 거야?\n&181\n전략가 공명에게 보고하려던 참이었어요.\n&3\n보고?\n무엇을 보고해야 할까요?\n어렵다고, 설마......\n&181\n관장군, 징저우가 이미 함락되었습니다!\n&3\n정말...... 그래서 늦었네......\n그럼 주군와 세 장군은 어쩌지!?\n&181\n그들은 바이디 시로 후퇴했다.\n&3\n정말...... 이해해.\n수고 많으셨습니다.\n바이디 시로 급히 가야 해!\n&181\n네.\n&3\n그는 전략가에게 망설이지 말고 즉시 증원군을 보내라고 말했다.\n&181\n네, 꼭 할게요!\n&3\n네가 믿고 있어.\n&181\n관, 장군 관우......')
    stage.unit(3).move(98, 49, 1)
    stage.unit(3).hide()
    stage.effectSound(201, 255)
    model.setRAvatar(3, 6)
    stage.clsUnit()
    return False


def scene1():
    stage.bgSound(13)
    stage.delay(3)
    stage.loadBg(2, 5)
    stage.showUnits([
        [
            32,
            55,
            46,
            2,
            10],
        [
            203,
            58,
            43,
            2,
            13]])
    stage.draw()
    stage.setStageName('바이디 시')
    stage.showUnit(3, 31, 61, 1)
    stage.say('&3\n형!')
    stage.unit(3).move(52, 61, 1)
    stage.delay(3)
    stage.unit(3).move(52, 52, 0)
    stage.say('&3\n형!\n&32\n…… 아, 둘째 형님?')
    stage.unit(3).setAction(3)
    stage.say('&3\n형, 괜찮아?')
    stage.unit(3).setAction(0)
    stage.say('&3\n(…… 흠!? 이런 부상이라니...... )\n&32\n…… 보시다시피, 나는 이 세상에 남은 시간이 얼마 남지 않을 것이다.')
    stage.unit(3).setAction(3)
    stage.say('&3\n…… 그런 낙담시키는 말 하지 마!')
    stage.unit(3).setAction(0)
    stage.say('&32\n하지만 나 걱정할 필요 없어......\n&32\n셋째 형님과 다른 이들은 내가 도망칠 수 있도록 매청을 죽을 때까지 지켰어,\n아마도 그들은 아직도 오나라 군대와 싸우고 있을 것이다......')
    stage.unit(3).setAction(6)
    stage.say('&3\n셋째 형님...... 아직도 격렬하게 싸우고 있니?\n&32\n둘째 형, 셋째 형님과 다른 사람들을 도와줘.\n&3\n…… 윤창은 분명히 이해했다.\n꼭 구해낼게요.\n안심하세요, 형제여.')
    stage.unit(3).setAction(0)
    stage.say('&32\n그 말에 마음이 놓여 있네요.\n&32\n…… 징저우 전투는 악몽 그 자체였다.\n&32\n우리 징저우 군에는 세 명의 동생이 있어, 주창, 관평 그리고 다른 이들이야......\n진정한 무적의 전투 단련된 전사.\n&32\n…… 그 사람의 군대가 나타날 때까지!')
    stage.unit(3).setAction(6)
    stage.say('&3\n그 사람?\n누구세요?')
    stage.delay(5)
    stage.say('&32\n......주유.')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(3)
    stage.say('&3\n주유!?\n주유 붉은 절벽 전투 후에 병으로 죽지 않았나요?')
    stage.unit(3).setAction(0)
    stage.say('&32\n처음에는 이미 죽은 줄 알았는데,\n하지만 우리 징저우 군을 무찌르는 것은 정말 주유입니다.')
    stage.say('&32\n둘째 형, 공명 어떻게 지내?')
    stage.unit(3).setAction(6)
    stage.say('&3\n…… 전략가는 아직 도착하지 않았다.')
    stage.unit(3).setAction(0)
    stage.say('&32\n정말...... 좋아.')
    stage.delay(5)
    stage.say('&32\n…… 둘째 형, 공명 우리를 배신했어.')
    stage.unit(3).setAction(3)
    stage.say('&3\n뭐라고 했어!?\n전략가가 ......')
    stage.unit(3).setAction(0)
    stage.say('&32\n나도 믿지 않아.\n아니, 오히려 믿고 싶지 않아!\n하지만......')
    stage.unit(3).setAction(0, 1)
    stage.say('&3\n(…… 한때 그런 의심을 했었어요,\n하지만 뜻밖에도 실제로 ......였다! )')
    stage.say('&32\n아마 곧 죽을 것 같아...... 음음!')
    stage.unit(3).setAction(0, 0)
    stage.delay(3)
    stage.unit(3).setAction(6)
    stage.say('&3\n형, 형!\n&32\n…… 둘째 형.\n내가 죽으면 조조 합류해!')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(3)
    stage.say('&3\n뭐-뭐라고!?')
    stage.unit(3).setAction(0)
    stage.say('&32\n슈 군대는 아마도 공명의 꼭두각시가 되었을 것이다.\n이제 공명 감당할 수 있는 사람은 조조뿐이야!\n&32\n…… 둘째 형, 부탁할게.\n슈가 올바른 길을 가도록 해야 해...... 음음...')
    stage.unit(3).setAction(9)
    stage.say('&3\n우우, 형제여......\n나는 형의 소원을 이루겠다.\n&32\n......공명, 왜 ......고 싶어?\nI .........\n원래는 이 위대한 사업을 당신에게 맡기려 했어요......\n&32\n……………………')
    stage.delay(10)
    stage.say('&3\n…… 형?\n…… 형제여!!')
    stage.unit(3).setAction(7)
    stage.say('&3\n우 오!!')
    stage.delay(10)
    stage.unit(3).setAction(9)
    stage.say('&3\n…………')
    stage.unit(3).setAction(0)
    stage.delay(3)
    stage.unit(3).setAction(0, 2)
    stage.say('&3\n감상에 빠질 시간이 없어.\n삼형님과 다른 사람들을 구하러 가야 해!')
    stage.clsUnit()
    return False


def scene2():
    stage.loadBg(2, 31)
    model.setRAvatar(3, 199)
    stage.draw()
    stage.showUnit(3, 5, 51, 1)
    stage.setStageName('마이청 외곽의 산길')
    stage.unit(3).move(51, 51, 1)
    stage.say('&3\n셋째 형님!\n지금 바로 구하러 갈게!')
    stage.unit(3).move(95, 51, 1)
    stage.unit(3).hide()
    stage.delay(3)
    stage.bgSound(15)
    model.setRAvatar(3, 6)
    stage.clsUnit()
    return False


def scene3():
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            6,
            44,
            52,
            1],
        [
            7,
            44,
            46,
            1],
        [
            9,
            44,
            40,
            1]])
    stage.draw()
    stage.info('지금 이 순간에는......', 3)
    stage.setStageName('딩준 Mountain조조 본진')
    stage.say('&0\n하후연, 수고하셨습니다.\n장합. 방덕도 잘 해냈어요.')
    stage.unit(6).setAction(0, 2)
    stage.delay(3)
    stage.unit(6).setAction(6)
    stage.say('&6\n네.')
    stage.unit(6).setAction(0)
    stage.delay(3)
    stage.unit(7).setAction(0, 2)
    stage.delay(3)
    stage.unit(7).setAction(6)
    stage.say('&7\n그렇긴 해도......\n공명의 전장에서의 행동은 정말 수수께끼를 자아낸다.')
    stage.unit(7).setAction(0)
    stage.delay(3)
    stage.unit(9).setAction(0, 2)
    stage.delay(3)
    stage.unit(9).setAction(6)
    stage.say('&9\n저도 전혀 이해할 수 없었어요.\n공명 처음부터 딩준산을 공격할 생각이 전혀 없어 보였다.')
    stage.unit(9).setAction(0)
    stage.delay(3)
    stage.unit(1).setAction(0, 0)
    stage.delay(3)
    stage.unit(1).setAction(3)
    stage.say('&1\n무슨 일이야?\n혹시 충동적으로 딩준산을 공격한 걸까?')
    stage.unit(1).setAction(0)
    stage.delay(3)
    stage.unit(9).setAction(6)
    stage.say('&9\n링밍은 직접적으로 말할 엄두를 내지 못하고 그저 .........')
    stage.unit(9).setAction(0)
    stage.say('&0\n……음.\n정말 믿기지 않는군.\n&0\n어쨌든 수고했다. 이제 쉬도록 해.')
    stage.unit(6).setAction(6)
    stage.say('&6\n네.')
    stage.unit(6).setAction(0)
    stage.unit(1).setAction(0, 1)
    stage.unit(6).setAction(0, 1)
    stage.unit(7).setAction(0, 1)
    stage.unit(9).setAction(0, 1)
    stage.unitsMove([
        [
            stage.unit(6),
            54,
            52,
            1],
        [
            stage.unit(7),
            54,
            46,
            1],
        [
            stage.unit(9),
            54,
            40,
            1]])
    stage.unitsMove([
        [
            stage.unit(9),
            54,
            22,
            0],
        [
            stage.unit(7),
            54,
            28,
            0],
        [
            stage.unit(6),
            54,
            34,
            0]])
    stage.unit(9).hide()
    stage.unitsMove([
        [
            stage.unit(7),
            54,
            22,
            0],
        [
            stage.unit(6),
            54,
            28,
            0]])
    stage.unit(7).hide()
    stage.unit(6).move(54, 22, 0)
    stage.unit(6).hide()
    stage.delay(10)
    stage.showUnit(17, 54, 22, 2)
    stage.say('&17\n초선 죄송합니다.\n&0\n초선 응?\n무슨 일이야?')
    stage.unit(17).setAction(6)
    stage.say('&17\n유비 경이 총리에게 편지를 보냈다.')
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n나한테 유비 편지 왔어, ......?')
    model.setFace(0)
    stage.unit(0).setAction(0)
    stage.say('&17\n네, 황번 교파의 스파이를 통해 방금 받았습니다.')
    stage.unit(17).setAction(0)
    stage.say('&0\n흠.\n유비의 의도를 이해하지 못한다면, 먼저 살펴보자.')
    stage.unit(17).move(54, 76, 2)
    stage.delay(3)
    stage.unit(0).setAction(5)
    stage.delay(3)
    stage.unit(17).move(54, 64, 2)
    stage.bgSound(13)
    stage.delay(10)
    model.setFace(1)
    stage.say('……어, 어찌 그럴 수가!?')
    model.setFace(0)
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 무슨 일이야?\n편지유비 뭐라고 썼어?')
    stage.unit(20).setAction(0)
    stage.say('&0\n유비 공명와 주유가 힘을 합쳐 그를 죽이려 했다고 말했다.')
    stage.unit(19).setAction(0, 2)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n뭐라고!?')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n정말 믿기 힘들다!\n주유 죽지 않았어?')
    stage.unit(20).setAction(0)
    stage.say('그리고 만약 그가 불의가 있으시면\n관우와 장비를 제가 돌보도록 하였습니다.')
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n무슨 ......?')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0)
    stage.say('초선아, 이 편지 내용은 너무 이상해. 혹시 공명의 계략은 아닐까?')
    stage.unit(17).setAction(6)
    stage.say('&17\n이 편지는 거짓과 구분하기 어렵지만,\n하지만 편지는 함께 전달되었다,\n또한 쌍검과 탈것도 사용할 유비 있습니다.')
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n뭐라고!?\n쌍검과 완벽한 짝!')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.say('&17\n네.\n확인 결과 진짜였다.')
    stage.unit(17).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 1)
    stage.say('&0\n그럼 이 편지가 정말 사기가 아니라는 뜻인가요?\n하지만......')
    stage.unit(20).setAction(6)
    stage.say('&20\n그나저나, 이전 정군산 전투 때,\n공명 행동은 정말 이상해......')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(19).setAction(6)
    stage.say('&19\n하지만 이 일이 사실이라면,\n그는 공명가 유비를 배신했다고 말했다.')
    stage.unit(19).setAction(0)
    model.setFace(1)
    stage.say('&0\n공명 반항할까요......?\n정말 믿기지 않아.')
    stage.getItem(30, 0)
    stage.getItem(121, 0)
    stage.showUnit(182, 54, 22, 2)
    stage.delay(3)
    stage.unit(182).setAction(11)
    stage.unit(0).setAction(0, 0)
    stage.unit(19).setAction(0, 3)
    stage.unit(20).setAction(0, 3)
    stage.unit(23).setAction(0, 3)
    stage.say('&182\n보고해!\n오나라 군대는 이미 징저우를 점령했다.')
    stage.unit(0).setAction(3)
    model.setFace(0)
    stage.say('&0\n뭐라고!?')
    stage.unit(0).setAction(0)
    stage.say('&182\n유비 패배하여 바이디 시로 도망쳤고, 그곳에서 사망했다.')
    stage.unit(0).setAction(3)
    model.setFace(1)
    stage.say('&0\n뭐라고!?\n유비 죽었어?\n유비 정말 죽은 거야!?')
    stage.unit(0).setAction(0)
    model.setFace(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n이 군사 정보가 정말 정확한가요?')
    stage.unit(23).setAction(0)
    stage.say('&182\n정말 맞는 말입니다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n…… 그렇다면 징저우의 다른 장군들은 어떠한가?')
    stage.unit(20).setAction(0)
    stage.say('&182\n주군에 보고한 결과, 대부분의 장교와 병사들이 전투에서 사망했다.\n살아남은 자들은 장비의 지휘로 마이청을 죽을 때까지 지켰다.\n그들은 여전히 동부 오나라 군대와 전투 중이었다.')
    stage.unit(20).setAction(6)
    stage.say('&20\n공명 증원군을 보냈나요?\n청두에는 아마도 아직 정예 슈 군대가 있을 거야, 맞지?')
    stage.unit(20).setAction(0)
    stage.say('&182\n아니요, 증원군은 보내지지 않았습니다.\n청두는 기다릴 생각인 것 같다,\n증원군이 파견된 흔적은 없습니다.\n&182\n현재 상황을 고려하면,\n마이청의 몰락은 시간 문제였다.')
    stage.unit(20).setAction(0, 1)
    stage.say('&20\n유비 죽었고, 장비 위험에 처해 있다......')
    stage.unit(20).setAction(0, 2)
    stage.delay(3)
    stage.unit(20).setAction(6)
    stage.say('&20\n주군, 유비가 편지에 쓴 내용과 일치하는 것 같습니다.')
    stage.unit(20).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('...관우는 왜 그래? 지금 어디에 있는 거지?')
    stage.unit(0).setAction(0)
    stage.say('&0\n유비 죽고 장비 곤경에 처한 상황에서,\n아무리 공명 관우 앞으로 나아가는 것을 막아도,\n무슨 일이 있어도 그는 구하러 달려갈 것이다.\n&182\n그래, 관우 바이디 시에서 유비 죽음을 목격한 후,\n그래서 그는 혼자 마이청으로 가서 장비를 구출했다.')
    stage.unit(0).setAction(0, 1)
    stage.delay(3)
    stage.say('&0\n유비가 죽은 후 주유가 다시 살아났고, 반공명 계획했다.\n이 모든 것을 내 눈으로 직접 봐야 한다!')
    stage.unit(23).setAction(0, 2)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n첫째, 장비 관우 구출하라,\n조사를 하나씩 더 깊이 파고들어 봅시다.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(0, 0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('&0\n싸울 준비해!\n급히 마이청으로 가서 구조해!\n즉시 전 군대에 명령을 내려라!')
    stage.unit(0).setAction(0)
    stage.say('&182\n네!')
    stage.unit(182).setAction(0)
    stage.delay(3)
    stage.unit(182).hide()
    stage.unit(20).setAction(0, 3)
    stage.unit(19).setAction(0, 3)
    stage.unit(23).setAction(0, 3)
    stage.bgSound(15)
    stage.delay(3)
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10)
    gvars[4076] = 0
    gvars[4057] = 47
    stage.setBattlePos([
        [
            20,
            2],
        [
            21,
            3],
        [
            19,
            1],
        [
            21,
            2],
        [
            20,
            1],
        [
            21,
            1],
        [
            22,
            2],
        [
            20,
            0],
        [
            22,
            1],
        [
            21,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene4():
    if stage.battleTest():
        stage.say('&0\n출발!')
        stage.setMenuVisible(False)
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&20\n마이청은 세 개의 큰 산으로 둘러싸여 있습니다.\n&20\n도시 주변 지역은 비교적 평탄하지만,\n이미 동부 오나라 군대의 통제 하에 있었을 가능성이 높다.\n&0\n다시 말해, 장비와 다른 이들은 이미 새장 속 새와 같다,\n날개로 나는 건 불가능해.\n&20\n그렇게 말할 수 있죠.')
    if stage.unitClickTest(19):
        stage.say('&19\n군사력은 아군 다소 불리했지만,\n그러나 동오군은 육상 전투에 능숙하지 않았다.\n&19\n아직 기회가 있어.')
    if stage.unitClickTest(1):
        stage.say('&1\n하지만 어쨌든, 관우 단독 구조 작전은,\n너무 용감하지만 전략이 부족하다.\n&0\n이것이 세 형제 사이의 깊은 유대감을 증명합니다.\n&0\n관우 개인들에게,\n이길 가능성이 있든 없든 더 이상 중요하지 않습니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n항상 몸 안을 감싸는 한기가 느껴져요.\n도대체 무슨 일이 벌어지고 있는 거야?\n&0\n무서워? 허저.\n&15\n아-아니, 그건 사실이 아니야.')
    if stage.unitClickTest(17):
        stage.say('초선아, 황건적의 첩자들은 뭐야? 그들은 내가 돌아가신 부모님의 옛 친구들이야. 예전에 내가 장로를 항복시키려 할 때 도움을 받았었어. 아, 그렇구나.')
    if stage.unitClickTest(23):
        stage.say('&23\n동오 군대가 아무리 강력해도,\n결국 마이청 수비대는 호랑이 장군 장비였다.\n&23\n논리적으로는 쉽게 잃어버릴 수 없지만......\n&0\nHowever공명 그가 반란을 모의한다면,\n그래서 말하기 어렵죠?\n&23\n네.')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
