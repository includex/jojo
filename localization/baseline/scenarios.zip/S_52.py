# Source Generated with Decompyle++
# File: S_52.marshal (Python 3.9)


def scene0():
    stage.nearEvent([
        0,
        170,
        0,
        171,
        0,
        172,
        0,
        173], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 2, 2)
    stage.createFriend([
        {
            'id': 148,
            'hide': 1,
            'x': 4,
            'y': 20,
            'dir': 0,
            'lv': 0,
            'ai': 0,
            'i': 0 }])
    stage.createEnemy([
        {
            'id': 170,
            'hide': 1,
            'x': 5,
            'y': 5,
            'lv': 6,
            'i': 0 },
        {
            'id': 171,
            'hide': 1,
            'x': 10,
            'y': 10,
            'dir': 3,
            'lv': 6,
            'i': 1 },
        {
            'id': 172,
            'hide': 1,
            'x': 15,
            'y': 15,
            'dir': 3,
            'lv': 6,
            'i': 2 },
        {
            'id': 173,
            'hide': 1,
            'x': 15,
            'y': 5,
            'dir': 3,
            'lv': 6,
            'i': 3 },
        {
            'id': 438,
            'hide': 1,
            'x': 8,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 4 },
        {
            'id': 439,
            'hide': 1,
            'x': 11,
            'y': 4,
            'lv': 0,
            'ai': 1,
            'i': 5 },
        {
            'id': 440,
            'hide': 1,
            'x': 8,
            'y': 7,
            'lv': 0,
            'ai': 1,
            'i': 6 },
        {
            'id': 441,
            'hide': 1,
            'x': 11,
            'y': 7,
            'lv': 0,
            'ai': 1,
            'i': 7 },
        {
            'id': 442,
            'hide': 1,
            'x': 16,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 8 },
        {
            'id': 443,
            'hide': 1,
            'x': 16,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 9 },
        {
            'id': 444,
            'hide': 1,
            'x': 13,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 10 },
        {
            'id': 445,
            'hide': 1,
            'x': 13,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 11 },
        {
            'id': 446,
            'hide': 1,
            'x': 16,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 12 },
        {
            'id': 447,
            'hide': 1,
            'x': 16,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 13 },
        {
            'id': 448,
            'hide': 1,
            'x': 13,
            'y': 14,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 14 },
        {
            'id': 449,
            'hide': 1,
            'x': 13,
            'y': 17,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 15 },
        {
            'id': 450,
            'hide': 1,
            'x': 16,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 451,
            'hide': 1,
            'x': 16,
            'y': 7,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 452,
            'hide': 1,
            'x': 13,
            'y': 4,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 453,
            'hide': 1,
            'x': 13,
            'y': 7,
            'dir': 3,
            'lv': 0,
            'ai': 1,
            'i': 19 }])
    stage.createMine([
        {
            'idx': 0,
            'x': 4,
            'y': 20,
            'dir': 0 },
        {
            'idx': 1,
            'x': 5,
            'y': 20,
            'dir': 0 },
        {
            'idx': 2,
            'x': 3,
            'y': 20,
            'dir': 0 },
        {
            'idx': 3,
            'x': 6,
            'y': 20,
            'dir': 0 },
        {
            'idx': 4,
            'x': 4,
            'y': 21,
            'dir': 0 },
        {
            'idx': 5,
            'x': 5,
            'y': 21,
            'dir': 0 },
        {
            'idx': 6,
            'x': 3,
            'y': 21,
            'dir': 0 },
        {
            'idx': 7,
            'x': 6,
            'y': 21,
            'dir': 0 },
        {
            'idx': 8,
            'x': 4,
            'y': 22,
            'dir': 0 },
        {
            'idx': 9,
            'x': 5,
            'y': 22,
            'dir': 0 },
        {
            'idx': 10,
            'x': 3,
            'y': 22,
            'dir': 0 },
        {
            'idx': 11,
            'x': 6,
            'y': 22,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(170, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(171, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(172, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(173, 51, 0, 26, 0, 9)
    stage.loadBg(52)
    stage.setObjects(True, 17, [
        [
            61,
            7,
            15],
        [
            62,
            7,
            16]])
    stage.setObjects(True, 17, [
        [
            69,
            4,
            8],
        [
            70,
            5,
            8]])
    stage.setObjects(True, 17, [
        [
            67,
            7,
            10],
        [
            68,
            7,
            11]])
    stage.setObjects(True, 17, [
        [
            65,
            12,
            15],
        [
            66,
            12,
            16]])
    stage.setObjects(True, 17, [
        [
            71,
            12,
            5],
        [
            72,
            12,
            6]])
    stage.setObjects(True, 17, [
        [
            73,
            14,
            3],
        [
            74,
            15,
            3]])
    vars[20] = 1
    vars[21] = 1
    vars[22] = 1
    vars[23] = 1
    vars[24] = 1
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab41')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab41')
    stage.draw()
    stage.bgSound(6)
    stage.say('&0\n이 흙벽은 뭐야?')
    stage.talk(35, 35, '조조!\n네가 이렇게 빨리 우를 정복할 줄은 몰랐어.\n정말 놀랐습니다.')
    stage.unit(0).setDir(1)
    stage.unit(0).setDir(3)
    stage.unit(0).setDir(0)
    stage.say('&0\n공명?\n어디야? 빨리 나와!')
    stage.talk(35, 35, '잠시 쉬게 해줘.\n하하하!')
    stage.unit(0).setAction(5)
    stage.say('&0\n네가 어떤 속임수를 가지고 있는지 모르겠지만,\n하지만 절대 네가 성공하지 못하게 할 거야!\n좋아, 전면 공격!\n유후푸를 돌파한다!')
    stage.unit(0).setAction(0)
    stage.setWinCondition('승리 조건\n1. 유후푸를 돌파조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('유후푸를 돌파한다!')
    stage.heightLight(12, 0, 17, 2)
    stage.startOper()
    vars[552] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[25] and not vars[11] and not vars[53] and stage.round() == 8:
        stage.say('&0\n흠, 진퇴양난에 처할 줄은 몰랐네,\n이제 후퇴하여 유후푸로 우회해 진격할 때입니다,\n아니면 계속 공격......?')
        sel = stage.choice('병력을 철수시키고 우회하라.\n계속 공격해', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n여기서 지체할 수 없어. 일단 후퇴해서 어복포를 우회하고,\n그다음 백제성 쪽으로 방향을 틀자.\n&0\n퇴로를 찾아야 해!')
            stage.unit(0).setAction(0)
            stage.unit(148).show()
            stage.unit(148).setDir(stage.countDir(148, 0))
            stage.say('&148\n조 총리님, 잘 지내셨길 바랍니다.\n탈출로를 열어줄게.\n하!')
            vars[50] = 1
            vars[51] = 1
            vars[52] = 1
            vars[53] = 1
            stage.setRectUnitHide(0, 0, 19, 23, 2)
            if stage.totalRectUnit(0, 3, 9, 6, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        61,
                        7,
                        15],
                    [
                        62,
                        7,
                        16]])
            if stage.totalRectUnit(0, 8, 14, 11, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        69,
                        4,
                        8],
                    [
                        70,
                        5,
                        8]])
            if stage.totalRectUnit(0, 8, 4, 11, 7) == 0:
                stage.setObjects(False, 17, [
                    [
                        67,
                        7,
                        10],
                    [
                        68,
                        7,
                        11]])
            if stage.totalRectUnit(0, 13, 9, 16, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        65,
                        12,
                        15],
                    [
                        66,
                        12,
                        16]])
            if stage.totalRectUnit(0, 13, 14, 16, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        71,
                        12,
                        5],
                    [
                        72,
                        12,
                        6]])
            if stage.totalRectUnit(0, 0, 18, 19, 23) == 0:
                stage.setObjects(False, 17, [
                    [
                        63,
                        4,
                        18],
                    [
                        64,
                        5,
                        18]])
            stage.unit(0).move(5, 20, 3)
            stage.unit(0).setDir(stage.countDir(0, 148))
            stage.say('&0\n그 신사가 길을 찾아 불멸자에게 가는 여정을 떠났다는 소문을 들었습니다,\n예전에는 이곳에 살고 있었어.\n&148\n헤헤헤.\n주님이 꽤 안타까운 상태인 것 같아.\n&148\n이 특별한 구조물에 흙담을 사용하면,\n특수 주문으로 강화되었다,\n심지어 복제인간도 만들 수 있습니다.\n&0\n어쨌든, 이번에는 도와주셔서 감사합니다.\n조는 진심으로 감사했다.\n&148\n헤헤헤, 신경 쓰지 마, 신경 쓰지 마.\n그런데, 서장님, 빨리 가고 싶지 않으세요?\n&148\n내가 이미 인간 세계를 떠났으니,\n이 모든 것들이 성인에게 도움이 될 수 있습니다.\n열심히 해. 하! 하! 하!')
            stage.unit(148).hide()
            stage.talk(35, 35, '(도중에 정요금이 갑자기 나타났다.\n어쩔 수 없지. 어차피 너희가 여기를 지나가지 못한다면,\n시간만 더 낭비하게 될 뿐이야. 크크크.)')
            stage.unit(0).setDir(2)
            stage.unit(0).setAction(6)
            stage.say('&0\n음, 서둘러!\n우리는 가능한 한 빨리 바이디 시로 서둘러야 해.')
            stage.unit(0).setAction(0)
            stage.reward(0, [
                142,
                -1])
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[652] = 1
            return True
        if sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n공명 여기서 그런 속임수를 쓴 이유는,\n분명히 우리가 바이디 시에 가까이 가는 걸 원하지 않는 거야.\n&0\n무슨 일이 있어도 이 장애물을 반드시 넘어야 해!')
            stage.unit(0).setAction(0)
            stage.talk(35, 35, '(하하하, 네가 정말 이곳을 돌파할 수 있을까?)')
            stage.say('빌어먹을 공명!')
        vars[11] = 1
    if vars[25] and not vars[12] and not vars[53] and stage.round() == 16:
        stage.say('&0\n젠장, 아직도 위험에서 벗어나지 못하네......\n이런 상황이 계속된다면, 그게 바로 공명가 바랐던 바 아닐까요?')
        sel = stage.choice('병력을 철수시키고 우회하라.\n계속 공격해', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n여기서 지체할 수 없어. 일단 후퇴해서 어복포를 우회하고,\n그다음 백제성 쪽으로 방향을 틀자.\n&0\n퇴로를 찾아야 해!')
            stage.unit(0).setAction(0)
            stage.talk(148, 148, '그건 다 환상이야!\n두려워하지 마!')
            stage.unit(148).show()
            stage.unit(148).setDir(stage.countDir(148, 0))
            stage.say('&148\n조 총리님, 잘 지내셨길 바랍니다.\n탈출로를 열어줄게.\n하!')
            vars[50] = 1
            vars[51] = 1
            vars[52] = 1
            vars[53] = 1
            stage.setRectUnitHide(0, 0, 19, 23, 2)
            if stage.totalRectUnit(0, 3, 9, 6, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        61,
                        7,
                        15],
                    [
                        62,
                        7,
                        16]])
            if stage.totalRectUnit(0, 8, 14, 11, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        69,
                        4,
                        8],
                    [
                        70,
                        5,
                        8]])
            if stage.totalRectUnit(0, 8, 4, 11, 7) == 0:
                stage.setObjects(False, 17, [
                    [
                        67,
                        7,
                        10],
                    [
                        68,
                        7,
                        11]])
            if stage.totalRectUnit(0, 13, 9, 16, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        65,
                        12,
                        15],
                    [
                        66,
                        12,
                        16]])
            if stage.totalRectUnit(0, 13, 14, 16, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        71,
                        12,
                        5],
                    [
                        72,
                        12,
                        6]])
            if stage.totalRectUnit(0, 0, 18, 19, 23) == 0:
                stage.setObjects(False, 17, [
                    [
                        63,
                        4,
                        18],
                    [
                        64,
                        5,
                        18]])
            stage.unit(0).move(5, 20, 3)
            stage.unit(0).setDir(stage.countDir(0, 148))
            stage.say('&0\n그 신사가 길을 찾아 불멸자에게 가는 여정을 떠났다는 소문을 들었습니다,\n예전에는 이곳에 살고 있었어.\n&148\n헤헤헤.\n주님이 꽤 안타까운 상태인 것 같아.\n&148\n이 특별한 구조물에 흙담을 사용하면,\n특수 주문으로 강화되었다,\n심지어 복제인간도 만들 수 있습니다.\n&0\n어쨌든, 이번에는 도와주셔서 감사합니다.\n조는 진심으로 감사했다.\n&148\n헤헤헤, 신경 쓰지 마, 신경 쓰지 마.\n그런데, 서장님, 빨리 가고 싶지 않으세요?\n&148\n내가 이미 인간 세계를 떠났으니,\n이 모든 것들이 성인에게 도움이 될 수 있습니다.\n열심히 해. 하! 하! 하!')
            stage.unit(148).hide()
            stage.talk(35, 35, '(도중에 정요금이 갑자기 나타났다.\n어쩔 수 없지. 어차피 너희가 여기를 지나가지 못한다면,\n시간만 더 낭비하게 될 뿐이야. 크크크.)')
            stage.unit(0).setDir(2)
            stage.unit(0).setAction(6)
            stage.say('&0\n음, 서둘러!\n우리는 가능한 한 빨리 바이디 시로 서둘러야 해.')
            stage.unit(0).setAction(0)
            stage.reward(0, [
                142,
                -1])
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[652] = 1
            return True
        if sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이 시점에서 그는 쉽게 물러설 여유가 없었다.\n무슨 일이 있어도 반드시 이곳을 뚫어야 했다!')
            stage.unit(0).setAction(0)
            stage.talk(35, 35, '(덤벼봐, 덤벼봐.\n네 실력을 내가 한번 보고 싶구나. 하하하.)')
            stage.say('빌어먹을 공명!')
        vars[12] = 1
    if vars[25] and not vars[13] and not vars[53] and stage.round() == 24:
        stage.say('&0\n그런데도 아직도 돌파구를 돌파하지 못해......\n이번에는 또다시 공명의 함정에 빠졌다.')
        sel = stage.choice('병력을 철수시키고 우회하라.\n계속 공격해', -1)
        if sel == 1:
            stage.unit(0).setAction(5)
            stage.say('&0\n여기서 지체할 수 없어. 일단 후퇴해서 어복포를 우회하고,\n그다음 백제성 쪽으로 방향을 틀자.\n&0\n퇴로를 찾아야 해!')
            stage.unit(0).setAction(0)
            stage.talk(148, 148, '그건 다 환상이야!\n두려워하지 마!')
            stage.unit(148).show()
            stage.unit(148).setDir(stage.countDir(148, 0))
            stage.say('&148\n조 총리님, 잘 지내셨길 바랍니다.\n탈출로를 열어줄게.\n하!')
            vars[50] = 1
            vars[51] = 1
            vars[52] = 1
            vars[53] = 1
            stage.setRectUnitHide(0, 0, 19, 23, 2)
            if stage.totalRectUnit(0, 3, 9, 6, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        61,
                        7,
                        15],
                    [
                        62,
                        7,
                        16]])
            if stage.totalRectUnit(0, 8, 14, 11, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        69,
                        4,
                        8],
                    [
                        70,
                        5,
                        8]])
            if stage.totalRectUnit(0, 8, 4, 11, 7) == 0:
                stage.setObjects(False, 17, [
                    [
                        67,
                        7,
                        10],
                    [
                        68,
                        7,
                        11]])
            if stage.totalRectUnit(0, 13, 9, 16, 12) == 0:
                stage.setObjects(False, 17, [
                    [
                        65,
                        12,
                        15],
                    [
                        66,
                        12,
                        16]])
            if stage.totalRectUnit(0, 13, 14, 16, 17) == 0:
                stage.setObjects(False, 17, [
                    [
                        71,
                        12,
                        5],
                    [
                        72,
                        12,
                        6]])
            if stage.totalRectUnit(0, 0, 18, 19, 23) == 0:
                stage.setObjects(False, 17, [
                    [
                        63,
                        4,
                        18],
                    [
                        64,
                        5,
                        18]])
            stage.unit(0).move(5, 20, 3)
            stage.unit(0).setDir(stage.countDir(0, 148))
            stage.say('&0\n그 신사가 길을 찾아 불멸자에게 가는 여정을 떠났다는 소문을 들었습니다,\n예전에는 이곳에 살고 있었어.\n&148\n헤헤헤.\n주님이 꽤 안타까운 상태인 것 같아.\n&148\n이 특별한 구조물에 흙담을 사용하면,\n특수 주문으로 강화되었다,\n심지어 복제인간도 만들 수 있습니다.\n&0\n어쨌든, 이번에는 도와주셔서 감사합니다.\n조는 진심으로 감사했다.\n&148\n헤헤헤, 신경 쓰지 마, 신경 쓰지 마.\n그런데, 서장님, 빨리 가고 싶지 않으세요?\n&148\n내가 이미 인간 세계를 떠났으니,\n이 모든 것들이 성인에게 도움이 될 수 있습니다.\n열심히 해. 하! 하! 하!')
            stage.unit(148).hide()
            stage.talk(35, 35, '(도중에 정요금이 갑자기 나타났다.\n어쩔 수 없지. 어차피 너희가 여기를 지나가지 않을 거라면,\n시간만 더 낭비하게 될 뿐이야. 크크크.)')
            stage.unit(0).setDir(2)
            stage.unit(0).setAction(6)
            stage.say('&0\n음, 서둘러!\n우리는 가능한 한 빨리 바이디 시로 서둘러야 해.')
            stage.unit(0).setAction(0)
            stage.reward(0, [
                142,
                -1])
            stage.end()
            vars[100] = 1
            vars[0] = 1
            vars[652] = 1
            return True
        if sel == 2:
            stage.unit(0).setAction(5)
            stage.say('&0\n이미 너무 많은 시간이 낭비되었다.\n이 시점에서 되돌릴 수 없었다!')
            stage.unit(0).setAction(0)
            stage.talk(35, 35, '(차라리 돌아가는 게 어때? 너희는 이곳을 통과할 수 없을 거야.)')
            stage.say('빌어먹을 공명!')
        vars[13] = 1
    if not vars[70] and stage.round() == 4:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[70] = 1
    if not vars[71] and stage.round() == 7:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[71] = 1
    if not vars[72] and stage.round() == 10:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[72] = 1
    if not vars[73] and stage.round() == 13:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[73] = 1
    if not vars[74] and stage.round() == 16:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[74] = 1
    if not vars[75] and stage.round() == 19:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[75] = 1
    if not vars[76] and stage.round() == 22:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[76] = 1
    if not vars[77] and stage.round() == 25:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[77] = 1
    if not vars[78] and stage.round() == 28:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[78] = 1
    if not vars[79] and stage.round() == 31:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[79] = 1
    if not vars[80] and stage.round() == 34:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[80] = 1
    if not vars[81] and stage.round() == 37:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[81] = 1
    if not vars[82] and stage.round() == 40:
        if vars[2] and not vars[50]:
            stage.unit(438).show(8, 4, 2)
            stage.unit(439).show(11, 4, 2)
            stage.unit(440).show(8, 7, 2)
            stage.unit(441).show(11, 7, 2)
        if vars[3] and not vars[51]:
            stage.unit(442).show(16, 9, 3)
            stage.unit(443).show(16, 12, 3)
            stage.unit(444).show(13, 9, 3)
            stage.unit(445).show(13, 12, 3)
        if vars[4] and not vars[52]:
            stage.unit(446).show(16, 14, 3)
            stage.unit(447).show(16, 17, 3)
            stage.unit(448).show(13, 14, 3)
            stage.unit(449).show(13, 17, 3)
        if vars[5] and not vars[53]:
            stage.unit(450).show(16, 4, 3)
            stage.unit(451).show(16, 7, 3)
            stage.unit(452).show(13, 4, 3)
            stage.unit(453).show(13, 7, 3)
        vars[82] = 1
    if vars[30] and not vars[20] and stage.totalRectUnit(0, 3, 9, 6, 12) == 0 and stage.totalRectUnit(6, 7, 15, 7, 16) == 0:
        stage.setObjects(True, 17, [
            [
                61,
                7,
                15],
            [
                62,
                7,
                16]])
        if not vars[3]:
            stage.say('&0\n흠!?\n문이 실제로 닫혔다고!?')
        vars[30] = 0
        vars[20] = 1
    if vars[31] and not vars[21] and stage.totalRectUnit(0, 8, 14, 11, 17) == 0 and stage.totalRectUnit(6, 4, 8, 5, 8) == 0:
        stage.setObjects(True, 17, [
            [
                69,
                4,
                8],
            [
                70,
                5,
                8]])
        if not vars[4]:
            stage.say('&0\n어떤 문이 닫혀 있어서 그런 걸까?')
        vars[31] = 0
        vars[21] = 1
    if vars[32] and not vars[22] and stage.totalRectUnit(0, 8, 4, 11, 7) == 0 and stage.totalRectUnit(6, 7, 10, 7, 11) == 0:
        stage.setObjects(True, 17, [
            [
                67,
                7,
                10],
            [
                68,
                7,
                11]])
        if not vars[5]:
            stage.say('&0\n갇힌 부대는 이미 포위가 풀렸나요?')
        vars[32] = 0
        vars[22] = 1
    if vars[33] and not vars[23] and stage.totalRectUnit(0, 13, 9, 16, 12) == 0 and stage.totalRectUnit(6, 12, 15, 12, 16) == 0:
        stage.setObjects(True, 17, [
            [
                65,
                12,
                15],
            [
                66,
                12,
                16]])
        if not vars[53]:
            stage.say('&0\n……………')
        vars[33] = 0
        vars[23] = 1
    if vars[34] and not vars[24] and stage.totalRectUnit(0, 13, 14, 16, 17) == 0 and stage.totalRectUnit(6, 12, 5, 12, 6) == 0:
        stage.setObjects(True, 17, [
            [
                71,
                12,
                5],
            [
                72,
                12,
                6]])
        if not vars[53]:
            stage.say('&0\n…………으윽!')
        vars[34] = 0
        vars[24] = 1
    if not vars[25] and stage.totalRectUnit(0, 0, 18, 19, 23) == 0:
        stage.setObjects(True, 17, [
            [
                63,
                4,
                18],
            [
                64,
                5,
                18]])
        stage.unit(0).setDir(2)
        stage.unit(0).setAction(10)
        stage.say('아, 입구가 막혔어! 큰일 났다… 이제 물러설 곳이 없어.')
        vars[25] = 1
    if vars[20] and not vars[30] and stage.isInRect(1025, 3, 9, 6, 12):
        stage.setObjects(False, 0, [
            [
                61,
                7,
                15],
            [
                62,
                7,
                16]])
        if not vars[2]:
            stage.say('&0\n흠!?\n문이 열렸어!')
        vars[20] = 0
        vars[30] = 1
    if vars[21] and not vars[31] and stage.isInRect(1025, 8, 14, 11, 17):
        stage.setObjects(False, 0, [
            [
                69,
                4,
                8],
            [
                70,
                5,
                8]])
        if not vars[2]:
            stage.say('&0\n문이 다시 열렸다.\n정확히 무슨 일이 있었던 거야?')
            stage.unit(170).show()
            stage.unit(170).setDir(stage.countDir(170, 0))
            stage.say('&170\n하하하하!\n여기가 네 묘지야.')
            stage.unit(0).setDir(stage.countDir(0, 170))
            stage.unit(0).setAction(5)
            stage.say('&0\n젠장, 드디어 모습을 드러냈구공명!\n전군을 동원해 공명을 공격하라!')
            stage.unit(0).setAction(0)
            stage.unit(170).move(10, 5, 3)
            stage.say('&170\n나와라, 충성스러운 하인들이여!')
            stage.unit(438).show()
            stage.unit(439).show()
            stage.unit(440).show()
            stage.unit(441).show()
            stage.unit(439).move(8, 5, 3)
            stage.unit(441).move(8, 6, 3)
            stage.unit(0).setDir(stage.countDir(0, 35))
            stage.say('&0\n이-이게 뭐야!?\n이것은 한때 우장이 사용했던 나무 인형으로 보입니다.\n이게 그때 나무 인형들과 똑같은 건가요?')
            vars[2] = 1
        vars[21] = 0
        vars[31] = 1
    if vars[22] and not vars[32] and stage.isInRect(1025, 8, 4, 11, 7):
        stage.setObjects(False, 0, [
            [
                67,
                7,
                10],
            [
                68,
                7,
                11]])
        if not vars[3]:
            stage.say('&0\n또 다른 문이 열렸다.\n게이트가 닫히는 것이 이 진형에 들어가고 나오는 것과 관련이 있을까요?')
            stage.unit(171).show()
            stage.unit(171).setDir(stage.countDir(171, 0))
            stage.say('&171\n오랫동안 기다렸어, 조조!')
            stage.unit(171).move(15, 10, 3)
            stage.say('&171\n가라, 내 하인들아!')
            stage.unit(442).show()
            stage.unit(443).show()
            stage.unit(444).show()
            stage.unit(445).show()
            stage.unit(442).move(13, 10, 3)
            stage.unit(443).move(13, 11, 3)
            stage.unit(0).setDir(stage.countDir(0, 171))
            stage.unit(0).setAction(5)
            stage.say('&0\n이-어떻게 이게 가능하지!?\n또 다른 공명!?')
            stage.unit(0).setAction(0)
            vars[3] = 1
        vars[22] = 0
        vars[32] = 1
    if vars[23] and not vars[33] and stage.isInRect(1025, 13, 9, 16, 12):
        stage.setObjects(False, 0, [
            [
                65,
                12,
                15],
            [
                66,
                12,
                16]])
        if not vars[4]:
            stage.say('&0\n또 하나 나타났어?')
            stage.unit(172).show()
            stage.unit(172).setDir(stage.countDir(172, 0))
            stage.say('&172\n조조, 무슨 일이야?\n피곤해 보이지?\n가라, 내 하인들아!')
            stage.unit(446).show()
            stage.unit(447).show()
            stage.unit(448).show()
            stage.unit(449).show()
            stage.unit(446).move(13, 15, 3)
            stage.unit(447).move(13, 16, 3)
            stage.unit(0).setDir(stage.countDir(0, 172))
            stage.say('&0\n또 다른 공명!?\n어느 게 진짜인가요!?')
            vars[4] = 1
        vars[23] = 0
        vars[33] = 1
    if vars[24] and not vars[34] and stage.isInRect(1025, 13, 14, 16, 17):
        stage.setObjects(False, 0, [
            [
                71,
                12,
                5],
            [
                72,
                12,
                6]])
        if not vars[5]:
            stage.say('&0\n……………。')
            stage.unit(173).show()
            stage.unit(173).setDir(stage.countDir(173, 0))
            stage.say('&173\n헤헤헤.\n가라, 내 하인들아!')
            stage.unit(450).show()
            stage.unit(451).show()
            stage.unit(452).show()
            stage.unit(453).show()
            stage.unit(450).move(13, 5, 3)
            stage.unit(451).move(13, 6, 3)
            stage.unit(0).setDir(stage.countDir(0, 173))
            stage.say('&0\n음, 네가 보기 전에 본 모든 게 그냥 환상일 수도 있을까?')
            vars[5] = 1
        vars[24] = 0
        vars[34] = 1
    if not vars[35] and stage.isInRect(0, 12, 0, 17, 2):
        stage.resumeCtrl()
        vars[35] = 1
        stage.talk(35, 35, '실제로 제 클론을 물리쳤습니다.\n정말 대단한 일이었다.')
        stage.talk(35, 35, '논리적으로, 이 대형에 나타난 클론들은,\n그들의 능력은 내 능력과 동등해야 한다.\n조의 군대를 과소평가해서는 안 된다는 뜻이군요. 안녕히 계세요!')
        stage.unit(0).setAction(5)
        stage.say('&0\n비록 시간이 꽤 걸렸지만,\n그래도 적어도 그는 위험에서 벗어났다.\n좋아, 전 군대가 바로 바이디 시로 진격하라!')
        stage.unit(0).setAction(0)
        stage.reward(0, [
            142,
            -1,
            116,
            -1])
        stage.end()
        vars[101] = 1
        vars[0] = 1
        vars[652] = 1
        return True
    if not vars[40] and stage.isNear(0, 170, True):
        stage.unit(170).setDir(stage.countDir(170, 0))
        stage.unit(0).setDir(stage.countDir(0, 170))
        stage.say('&0\n공명, 목숨 걸고 와!\n&170\n헤헤헤.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 171, True):
        stage.unit(171).setDir(stage.countDir(171, 0))
        stage.unit(0).setDir(stage.countDir(0, 171))
        stage.say('&0\n정말 공명 있나요?\n&171\n정말? 어떻게 생각해?')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 172, True):
        stage.unit(172).setDir(stage.countDir(172, 0))
        stage.unit(0).setDir(stage.countDir(0, 172))
        stage.say('&0\n음, 혹시 환상일까요?\n&172\n정말 그렇게 생각해?')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 173, True):
        stage.unit(173).setDir(stage.countDir(173, 0))
        stage.unit(0).setDir(stage.countDir(0, 173))
        stage.say('&0\n너—이 괴물!\n&173\n그렇게 말하면 너무 무례할 거야.')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(170, 7, 0, 2):
        stage.say('&170\n아-아, 안 돼!')
        stage.unit(170).hide(2)
        stage.unit(438).hide()
        stage.unit(439).hide()
        stage.unit(440).hide()
        stage.unit(441).hide()
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(171, 7, 0, 2):
        stage.say('&171\n와!')
        stage.unit(171).hide(2)
        stage.unit(442).hide()
        stage.unit(443).hide()
        stage.unit(444).hide()
        stage.unit(445).hide()
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(172, 7, 0, 2):
        stage.say('&172\n와, 와!')
        stage.unit(172).hide(2)
        stage.unit(446).hide()
        stage.unit(447).hide()
        stage.unit(448).hide()
        stage.unit(449).hide()
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(173, 7, 0, 2):
        stage.say('&173\n흠!')
        stage.unit(173).hide(2)
        stage.unit(450).hide()
        stage.unit(451).hide()
        stage.unit(452).hide()
        stage.unit(453).hide()
        stage.setObjects(False, 0, [
            [
                73,
                14,
                3],
            [
                74,
                15,
                3]])
        stage.say('&0\n마지막 문이 열렸다.\n흠, 흠, 증오스러운 공명!\n이번에는 다시 그녀를 놀렸다.')
        vars[53] = 1
    if vars[35] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n빨리, 전 군대가 바이디 성으로 향해!\n기도제갈량 그만두셔야 합니다!')
        stage.reward(0, [
            142,
            -1])
        stage.end()
        vars[0] = 1
        vars[652] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 패배제갈량')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
