# Source Generated with Decompyle++
# File: R_42.marshal (Python 3.9)


def scene0():
    model.initLocalVar()
    if vars[1002]:
        stage.infoTransfer(18, '')
    stage.clsUnit()
    stage.setMenuVisible(False)
    model.setFace(128)
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 72, 131)
    stage.showHead(35, 8, 176)
    stage.bottomTxt('조조', False, False, False)
    stage.delay(5)
    stage.head(35).hide()
    stage.delay(5)
    stage.bottomTxt('서군을 격파했고,', True, False, False)
    stage.delay(8)
    stage.head(0).move(29, 173)
    stage.delay(5)
    stage.bottomTxt('마침내 청두가 점령되었다.', True, False, False)
    stage.delay(10)
    stage.bottomTxt('이로써 유비가 세운 슈 왕국은 종말을 맞았다.', True, True, True)
    stage.bgSound(-1)
    stage.loadBg(2, 67)
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.setEventName('서나라의 몰락')
    stage.setStageName('청두 외곽 산길')
    stage.showUnit(35, 49, 95)
    stage.unit(35).move(49, 85, 0)
    stage.showUnits([
        [
            69,
            45,
            95],
        [
            50,
            53,
            95]])
    stage.unitsMove([
        [
            stage.unit(35),
            49,
            45,
            0],
        [
            stage.unit(69),
            45,
            55,
            0],
        [
            stage.unit(50),
            53,
            55,
            0]])
    stage.delay(3)
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n너희 둘 다쳤어?')
    stage.unit(69).setAction(6)
    stage.say('&69\n괜찮아.')
    stage.unit(69).setAction(0)
    stage.delay(3)
    stage.unit(50).setAction(6)
    stage.say('&50\n흥, 다치는 건 내가 할 수 없는 일이야.')
    stage.unit(50).setAction(0)
    stage.say('&35\n정말......?\n비록 슈가 이제 몰락했지만,\n하지만 네가 살아 있는 한, 항상 전환점이 있을 거야.')
    stage.unit(69).setAction(6)
    stage.say('&69\n공명Sir, 앞으로 어떻게 할까?')
    stage.unit(69).setAction(0)
    stage.say('&35\n그냥 따라오면 알게 될 거야.\n좋은 생각이 있어......\n&69\n아......')
    stage.unit(69).setAction(0, 2)
    stage.delay(3)
    stage.unit(69).setAction(2)
    stage.say('&69\n그렇긴 해도, 류찬의 죽음은 정말 부끄러운 일주군 있었다.\n그런 주군은 정말 쓸모가 없습니다.')
    stage.unit(50).setAction(0, 2)
    stage.say('&50\n실제로 그런 사람은 그를 섬길 가치가 없다.')
    stage.unit(35).setAction(2, 2)
    stage.say('&35\n장웨이, 마수!\n그리고 류산을 험담주군,\n절대 그냥 두지 않을 거야!')
    stage.unit(69).setAction(0)
    stage.delay(3)
    stage.unit(69).setAction(0, 0)
    stage.unit(50).setAction(0, 0)
    stage.delay(5)
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n모든 책임은 나에게 있다.\n유비 유산을 내게 맡긴 것은 전 영주였주군.')
    stage.unit(35).setAction(0, 1)
    stage.say('&35\n누군가를 탓하고 싶으면 나를 탓해!')
    stage.unit(69).setAction(6)
    stage.say('&69\n공명 선생님......\n&50\n………\n&35\n(유비주군...... 안타깝네. )')
    stage.unit(35).setAction(0, 2)
    stage.say('&35\n가자.')
    stage.unit(69).setAction(0)
    stage.delay(3)
    stage.unitsMove([
        [
            stage.unit(35),
            49,
            5,
            0],
        [
            stage.unit(50),
            53,
            5,
            0],
        [
            stage.unit(69),
            45,
            5,
            0]])
    stage.unit(35).hide()
    stage.unit(50).hide()
    stage.unit(69).hide()
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene1():
    stage.loadBg(2, 9)
    stage.showUnits([
        [
            0,
            32,
            54,
            1],
        [
            1,
            50,
            70],
        [
            8,
            56,
            70],
        [
            4,
            62,
            70],
        [
            5,
            68,
            70],
        [
            12,
            74,
            70],
        [
            20,
            50,
            40,
            2],
        [
            19,
            56,
            40,
            2],
        [
            24,
            62,
            40,
            2],
        [
            21,
            68,
            40,
            2],
        [
            23,
            74,
            40,
            2]])
    stage.draw()
    stage.effectSound(201, 0)
    stage.delay(3)
    stage.info('이 time조조 그는 슈나라를 통치하는 데 바빴다.\n도망간 공명을 찾으러 다니는 동안.')
    stage.setStageName('청두 임시 총리 관저')
    stage.say('&0\n중더, 이 책을 여러 부로 작성하고 양식을 작성해라,\n그리고 이를 슈 왕국의 전 관리들에게 지급했다.\n복직 가능한 사람들은 계속 고용되어야 합니다.')
    stage.unit(21).setAction(6)
    stage.say('&21\n네.')
    stage.unit(21).setAction(0)
    stage.say('&0\n순유, 평민들은 어떻게 지내고 있나?')
    stage.unit(24).setAction(6)
    stage.say('&24\n네.\n평민들은 거의 여전히 슈 왕국을 갈망했다,\n일을 할 수 없고 하루 종일 울었어요.')
    stage.unit(24).setAction(0)
    stage.say('&0\n그럴 만도 하죠......')
    stage.unit(0).setAction(3)
    stage.say('좋습니다. 관저를 열고 백성들에게 곡식을 배급하며, 또한 촉국 백성들의 일 년간세를 감면하겠습니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n앞으로 슈를 잊게 하자,\n안심하고 위나라 시민이 되세요.\n우리는 백성의 마음을 달래고 굴복하게 해야 합니다.')
    stage.unit(24).setAction(6)
    stage.say('&24\n네, 즉시 진행하겠습니다.')
    stage.unit(24).setAction(0)
    stage.delay(3)
    stage.unit(23).setAction(6)
    stage.say('&23\n문제가 발생하기 전에 공공 안전이 이미 막힌 것 같습니다.')
    stage.unit(23).setAction(0)
    stage.say('&0\n흠, 하지만 경영진은 여전히 편안해질 수 없네요,\n군대 내에서 평민의 재산을 약탈하는 행위가 있다면,\n계급에 상관없이 모두 처형될 것이다.')
    stage.unit(23).setAction(6)
    stage.say('&23\n네.')
    stage.unit(23).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(3)
    stage.say('좋습니다. 내정 부분은 여기까지로 하겠습니다.')
    stage.unit(0).setAction(0)
    stage.say('&0\n남은 건 공명뿐이야.\n사마의, 아직도 공명 행방을 못 찾았어?')
    stage.unit(19).setAction(6)
    stage.say('&19\n네, 하지만 이미 많은 첩자들이 파견되었어요,\n곧 결과가 나올 거야.')
    stage.unit(19).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(2)
    model.setFace(2)
    stage.say('&0\n아, 왜 이렇게 오래 걸렸지!?')
    stage.showUnit(181, 90, 54, 3)
    stage.say('&181\n신고됐어.')
    stage.delay(3)
    stage.unit(181).setAction(11)
    stage.say('&181\n주군, 이미 공명의 행방을 알아냈다.')
    stage.unit(0).setAction(3)
    model.setFace(0)
    stage.say('&0\n오! 소식 있어?\n지금 어디에 있지?')
    stage.unit(0).setAction(0)
    stage.say('&181\n주군에게 보고합니다,\n공명 남은 병력을 모아 바이디 시에서 버텼다.\n&0\n바이디 시티!?\n그래서 그런 거야.')
    stage.unit(20).setAction(6)
    stage.say('&20\n바이디 시는 유비 목숨을 잃은 곳이다,\n또한 가장 위험한 장소이기도 했다.')
    stage.unit(20).setAction(0)
    stage.say('&0\n흥, 어린 공명아,\n옛 주군의 망령과 함께 우리를 맞아 싸울 셈이냐?')
    stage.unit(0).setAction(3)
    stage.say('&0\n네.\n장수들에게 곧바로 위임받은 임무 완료를 명하되, 다른 부대는 즉시 출격에 대비하라.')
    stage.unit(0).setAction(0)
    stage.delay(3)
    stage.unit(0).setAction(17)
    stage.say('공명은 반드시 일찍 없애야 합니다. 병사들을 백제성으로 보내세요!')
    stage.effectSound(201, 255)
    stage.clsUnit()
    return False


def scene2():
    stage.bgSound(16)
    stage.delay(3)
    stage.loadBg(1, 0)
    stage.draw()
    stage.showHead(0, 25, 175)
    stage.bottomTxt('청두가 함락된 후,', False, False, False)
    stage.delay(8)
    stage.showHead(35, 161, 217)
    stage.delay(5)
    stage.bottomTxt('제갈량와 다른 슈의 전직 관리들은 바이디 시로 도망쳤다.', True, True, False)
    stage.delay(10)
    stage.head(0).move(97, 217)
    stage.delay(5)
    stage.bottomTxt('이에 조의 군대는 복수를 위한 작전을 개시했다.', True, True, True)
    stage.delay(3)
    stage.bgSound(15)
    stage.loadBg(2, 53)
    stage.showUnits([
        [
            0,
            54,
            80],
        [
            1,
            44,
            64,
            1],
        [
            15,
            44,
            58,
            1],
        [
            2,
            44,
            52,
            1],
        [
            20,
            64,
            64,
            3],
        [
            19,
            64,
            58,
            3],
        [
            23,
            64,
            52,
            3]])
    stage.draw()
    stage.setStageName('바이디 시 외곽, 조조군 본군 캠프')
    stage.setMenuVisible(True)
    stage.setJoinBattle(1, 10, [
        19])
    gvars[4076] = 0
    gvars[4057] = 42
    stage.setBattlePos([
        [
            13,
            20],
        [
            14,
            20],
        [
            12,
            20],
        [
            15,
            20],
        [
            13,
            21],
        [
            14,
            21],
        [
            12,
            21],
        [
            15,
            21],
        [
            13,
            22],
        [
            14,
            22],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0],
        [
            0,
            0]])
    return False


def scene3():
    if stage.battleTest():
        stage.setMenuVisible(False)
        stage.say('&0\n출격해라!')
        stage.bgSound(-1)
        return True
    if stage.unitClickTest(20):
        stage.say('&0\n문약, 바이디 시의 구조를 설명해 주세요.\n&20\n네.\n바이디시는 청두처럼 3층 건물을 가지고 있습니다.\n&20\n하지만 청두보다는 조금 작아요,\n그 결과, 이동이 오히려 더 불편해집니다.')
    if stage.unitClickTest(23):
        stage.say('&23\n주홍 새 보석은 전략가형 유닛만 장착할 수 있습니다.\n&23\n이런 보물과 함께,\n그다음에는 최고불꽃 주홍새 전략을 사용할 수 있습니다.')
    if stage.unitClickTest(15):
        stage.say('&15\n마수도 과소평가해서는 안 됩니다.')
    if stage.unitClickTest(19):
        stage.say('&19\n바이디 시티의 위치가 좀 이상하다고 느껴집니다.\n&19\n아마도 이 도시를 공격하는 것은 예상보다 더 어려울 것이다.')
    if stage.unitClickTest(2):
        stage.say('&2\n슈의 잔재가 바이디 시에 있나......?\n옛 고향은 지나갔지만, 내 그리움과 그리움은 변함없이 변하지 않는다.\n정말 가슴 아픕니다.')
    if stage.unitClickTest(1):
        stage.say('&1\n이 전투는 모든 적을 저승으로 보낼 것이다!')
    return False

def __dispatch__():
    label('__dispatch_loop')
    if stage.menuVisible():
        name = f"scene{stage.sceneIndex()}"
        if call(name):
            stage.setMenuVisible(False)
            stage.incSceneIdx()
        else:
            return None
    name = f"scene{stage.sceneIndex()}"
    if not hasFunc(name):
        stage.end()
        return None
    call(name)
    stage.incSceneIdx()
    if stage.menuVisible():
        return None
    goto('__dispatch_loop')
