# Source Generated with Decompyle++
# File: S_55.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28], [
        '(19,11)',
        '(19,14)',
        '(15,12)',
        '(23,13)',
        '(8,24)',
        '(11,24)',
        '(10,20)',
        '(9,28)',
        '(4,7)'])
    stage.nearEvent([
        3,
        34])
    stage.nearEvent([
        0,
        50,
        19,
        37], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 50, 'hide': 1, 'x': 9, 'y': 35, 'lv': 6, 'ai': 6, 'targetX': 3, 'targetY': 6, 'i': 0},
         {'id': 37, 'hide': 1, 'x': 10, 'y': 35, 'lv': 6, 'ai': 6, 'targetX': 4, 'targetY': 7, 'i': 1},
         {'id': 210, 'x': 5, 'y': 8, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 4, 'y': 8, 'lv': 0, 'i': 3},
         {'id': 212, 'x': 5, 'y': 7, 'lv': 0, 'i': 4},
         {'id': 234, 'x': 3, 'y': 8, 'lv': 0, 'i': 5},
         {'id': 235, 'x': 3, 'y': 9, 'lv': 0, 'i': 6},
         {'id': 236, 'x': 5, 'y': 6, 'lv': 0, 'i': 7},
         {'id': 237, 'x': 6, 'y': 6, 'lv': 0, 'i': 8},
         {'id': 298, 'x': 3, 'y': 10, 'lv': 0, 'ai': 0, 'i': 9},
         {'id': 299, 'x': 3, 'y': 11, 'lv': 0, 'ai': 0, 'i': 10},
         {'id': 300, 'x': 7, 'y': 6, 'lv': 0, 'ai': 0, 'i': 11},
         {'id': 301, 'x': 8, 'y': 6, 'lv': 0, 'ai': 0, 'i': 12},
         {'id': 34, 'x': 19, 'y': 14, 'dir': 3, 'lv': 6, 'i': 13},
         {'id': 36, 'x': 19, 'y': 11, 'dir': 3, 'lv': 6, 'i': 14},
         {'id': 213, 'x': 15, 'y': 12, 'dir': 3, 'lv': 0, 'i': 15},
         {'id': 214, 'x': 23, 'y': 13, 'dir': 3, 'lv': 0, 'i': 16},
         {'id': 215, 'x': 17, 'y': 12, 'dir': 3, 'lv': 0, 'i': 17},
         {'id': 216, 'x': 17, 'y': 13, 'dir': 3, 'lv': 0, 'i': 18},
         {'id': 258, 'x': 18, 'y': 12, 'dir': 3, 'lv': 0, 'i': 19},
         {'id': 259, 'x': 18, 'y': 13, 'dir': 3, 'lv': 0, 'i': 20},
         {'id': 282, 'x': 18, 'y': 11, 'dir': 3, 'lv': 0, 'i': 21},
         {'id': 283, 'x': 18, 'y': 14, 'dir': 3, 'lv': 0, 'i': 22},
         {'id': 302, 'x': 20, 'y': 12, 'dir': 3, 'lv': 0, 'i': 23},
         {'id': 303, 'x': 20, 'y': 13, 'dir': 3, 'lv': 0, 'i': 24},
         {'id': 55, 'x': 8, 'y': 24, 'lv': 4, 'i': 25},
         {'id': 56, 'x': 11, 'y': 24, 'lv': 4, 'i': 26},
         {'id': 45, 'x': 9, 'y': 24, 'lv': 4, 'i': 27},
         {'id': 65, 'x': 10, 'y': 24, 'lv': 4, 'i': 28},
         {'id': 217, 'x': 9, 'y': 28, 'lv': 0, 'i': 29},
         {'id': 218, 'x': 10, 'y': 20, 'lv': 0, 'i': 30},
         {'id': 219, 'x': 9, 'y': 26, 'lv': 0, 'i': 31},
         {'id': 220, 'x': 10, 'y': 26, 'lv': 0, 'i': 32},
         {'id': 238, 'x': 8, 'y': 25, 'lv': 0, 'i': 33},
         {'id': 239, 'x': 9, 'y': 25, 'lv': 0, 'i': 34},
         {'id': 240, 'x': 10, 'y': 25, 'lv': 0, 'i': 35},
         {'id': 241, 'x': 11, 'y': 25, 'lv': 0, 'i': 36},
         {'id': 304, 'x': 9, 'y': 23, 'lv': 0, 'i': 37},
         {'id': 305, 'x': 10, 'y': 23, 'lv': 0, 'i': 38},
         {'id': 57, 'hide': 1, 'x': 1, 'y': 15, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 39},
         {'id': 58, 'hide': 1, 'x': 0, 'y': 15, 'dir': 1, 'lv': 6, 'ai': 1, 'i': 40},
         {'id': 462, 'hide': 1, 'x': 1, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 41},
         {'id': 463, 'hide': 1, 'x': 0, 'y': 14, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 42},
         {'id': 464, 'hide': 1, 'x': 1, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 43},
         {'id': 465, 'hide': 1, 'x': 0, 'y': 16, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 44},
         {'id': 466, 'hide': 1, 'x': 1, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 45},
         {'id': 467, 'hide': 1, 'x': 0, 'y': 13, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 46},
         {'id': 468, 'hide': 1, 'x': 1, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 47},
         {'id': 469, 'hide': 1, 'x': 0, 'y': 17, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 48},
         {'id': 72, 'hide': 1, 'x': 9, 'y': 33, 'dir': 0, 'lv': 6, 'ai': 1, 'i': 49},
         {'id': 73, 'hide': 1, 'x': 8, 'y': 33, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 50},
         {'id': 71, 'hide': 1, 'x': 10, 'y': 33, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 51},
         {'id': 310, 'hide': 1, 'x': 9, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 52},
         {'id': 390, 'hide': 1, 'x': 8, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 53},
         {'id': 382, 'hide': 1, 'x': 10, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 54},
         {'id': 391, 'hide': 1, 'x': 7, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 55},
         {'id': 392, 'hide': 1, 'x': 7, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 56},
         {'id': 383, 'hide': 1, 'x': 11, 'y': 33, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 57},
         {'id': 384, 'hide': 1, 'x': 11, 'y': 34, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 58},
         {'id': 311, 'hide': 1, 'x': 9, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 59},
         {'id': 312, 'hide': 1, 'x': 8, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 60},
         {'id': 313, 'hide': 1, 'x': 10, 'y': 35, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 61}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 9,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 1,
            'x': 8,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 2,
            'x': 10,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 3,
            'x': 7,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 4,
            'x': 11,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 5,
            'x': 9,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 6,
            'x': 8,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 7,
            'x': 10,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 8,
            'x': 7,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 9,
            'x': 11,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 10,
            'x': 9,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 11,
            'x': 8,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 12,
            'x': 10,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 13,
            'x': 7,
            'y': 35,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 14,
            'x': 11,
            'y': 35,
            'dir': 0,
            'hide': 1 }])
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.loadBg(55)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab24')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab24')
    stage.draw()
    stage.bgSound(6)
    stage.unit(50).show()
    stage.unit(50).move(9, 32, 0)
    stage.unit(37).show()
    stage.unit(37).move(10, 32, 0)
    stage.unit(50).setAction(9)
    stage.say('&50\n휴, 드디어 조의 군대 앞에 도착했다.')
    stage.unit(37).setDir(stage.countDir(37, 50))
    stage.say('&37\n그러나 마초와 남부 야만군은 아직 도착하지 않았다.')
    stage.unit(50).setDir(stage.countDir(50, 37))
    stage.say('&50\n상관없다, 이미 양평관에서 적군를 대면하라는 통보를 받았다.\n언젠가는 도착할 거야.')
    stage.unit(37).setDir(2)
    stage.say('&37\n조의 군대가 지연된다면,\n이것은 우리에게 유익합니다.')
    stage.unit(50).move(9, 27, 0)
    stage.unit(37).move(10, 27, 0)
    stage.unit(50).setDir(stage.countDir(50, 45))
    stage.unit(45).setDir(stage.countDir(45, 50))
    stage.unit(65).setDir(stage.countDir(65, 50))
    stage.unit(55).setDir(stage.countDir(55, 50))
    stage.unit(56).setDir(stage.countDir(56, 50))
    stage.say('&50\n군대 전체가 내 지시를 따라 자리를 잡았지?\n이렇게 하면 좀 더 안심할 수 있습니다.\n&45\n그는 이미 지시에 따라 양평관에서 대기 중이었다.\n&65\n(공명 이 녀석은 꼭 가져야 할 녀석이야,\n실제로 마수 같은 아이를 임명했어.\n슈가 곧 잃을 것 같아, 쳇! )\n&55\n적군 우장위안에게 가까이 가지 않는 한 그걸로 충분하다.\n항상 전력을 다해 방어할 방법이 있어.\n&56\n이제, 오직 공명 씨만이 믿는다,\n그리고 이곳을 죽을 때까지 붙잡고 있을 뿐이야.')
    stage.unit(50).move(9, 22, 0)
    stage.unit(37).move(10, 22, 0)
    stage.unit(3, 1).show()
    stage.unit(3, 1).move(7, 32, 0)
    stage.unit(1, 1).show()
    stage.unit(1, 1).move(8, 32, 0)
    stage.unit(0, 1).show()
    stage.unit(0, 1).move(9, 32, 0)
    stage.unit(2, 1).show()
    stage.unit(2, 1).move(10, 32, 0)
    stage.unit(4, 1).show()
    stage.unit(4, 1).move(11, 32, 0)
    stage.unit(8, 1).show()
    stage.unit(8, 1).move(7, 33, 0)
    stage.unit(6, 1).show()
    stage.unit(6, 1).move(8, 33, 0)
    stage.unit(5, 1).show()
    stage.unit(5, 1).move(9, 33, 0)
    stage.unit(7, 1).show()
    stage.unit(7, 1).move(10, 33, 0)
    stage.unit(9, 1).show()
    stage.unit(9, 1).move(11, 33, 0)
    stage.unit(13, 1).show()
    stage.unit(13, 1).move(7, 34, 0)
    stage.unit(11, 1).show()
    stage.unit(11, 1).move(8, 34, 0)
    stage.unit(10, 1).show()
    stage.unit(10, 1).move(9, 34, 0)
    stage.unit(12, 1).show()
    stage.unit(12, 1).move(10, 34, 0)
    stage.unit(14, 1).show()
    stage.unit(14, 1).move(11, 34, 0)
    stage.unit(0).setDir(stage.countDir(0, 50))
    stage.say('&0\n방어가 너무 견고해,\n공명 목적지가 바로 앞에 있음을 나타냅니다.')
    stage.unit(37).setDir(stage.countDir(37, 0))
    stage.say('&37\n쳇, 벌써 왔네?')
    stage.unit(50).move(9, 17, 0)
    stage.unit(37).move(10, 17, 0)
    stage.unit(50).setDir(stage.countDir(50, 36))
    stage.unit(36).setDir(stage.countDir(36, 50))
    stage.unit(34).setDir(stage.countDir(34, 50))
    stage.say('&50\n조운, 두 장군황충 양쪽 측면에서 공격했다.\n&36\n걱정 마. 두 개의 날개는 우리에게 맡겨!\n&34\n조운 열심히 싸워야 해!')
    stage.bgSound(5)
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[555] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[754] and not vars[11] and stage.round() == 5 and stage.curCamp() == 2:
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(466).show()
        stage.unit(467).show()
        stage.unit(468).show()
        stage.unit(469).show()
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.say('&58\n흠, 벌써 전투가 시작된 건가?\n산길을 오르는 것은 너무 많은 시간을 낭비했다.')
        if not vars[50]:
            stage.unit(50).setDir(stage.countDir(50, 58))
            stage.say('&50\n아, 마초랑 마다이다!\n드디어 따라잡았어.')
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.say('&57\n배신자 조, 도망가지 마!\n아무리 멀리 가도,\n아버지의 복수를 원해!')
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&0\n정말 끈질긴 사람이네요.\n어떻게 해야 할까? 여기서도 돌파 전술을 써야 할까?')
        sel = stage.choice('양평관 돌파\n전멸시키적군', -1)
        if sel == 1:
            stage.say('&0\n다시 돌파에 집중하는 것이 좋겠습니다.\n적군의 포위망을 뚫고 나면, 이제 장군 공명 을 추격하겠습니다.')
            stage.unit(57).setAction(5)
            stage.say('&57\n흥! 네 뜻대로 할 생각도 하지 마!\n돌격! 모두 부숴버려!')
            stage.unit(57).setAction(0)
            if not vars[31]:
                if not vars[53]:
                    stage.unit(36).setDir(stage.countDir(36, 0))
                    stage.say('&36\n조조, 어디 가는 거야!\n우리도 얘기하자!')
                if not vars[52]:
                    stage.unit(34).setDir(stage.countDir(34, 0))
                    stage.say('&34\n나도 싸울 거야.')
                stage.setAI(14, 8, 23, 17, 2, 1)
                vars[31] = 1
            stage.setWinCondition('승리 조건\n1. 북서쪽 끝에 도달조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('양평관을 돌파하라!')
            stage.heightLight(0, 0, 1, 3)
            vars[2] = 1
        elif sel == 2:
            stage.say('&0\n안 돼, 이곳의 적군부터 반드시 소멸시켜서,\n뒤에 걱정거리를 끊어야 해.\n&57\n좋아, 공격하자!')
        vars[11] = 1
    if not vars[12] and not vars[754] and stage.round() == 5 and stage.curCamp() == 2:
        stage.unit(57).show()
        stage.unit(58).show()
        stage.unit(462).show()
        stage.unit(463).show()
        stage.unit(464).show()
        stage.unit(465).show()
        stage.unit(58).setDir(stage.countDir(58, 0))
        stage.say('&58\n흠, 벌써 전투가 시작된 건가?\n산길을 오르는 것은 너무 많은 시간을 낭비했다.')
        if not vars[50]:
            stage.unit(50).setDir(stage.countDir(50, 58))
            stage.say('&50\n아, 마초랑 마다이다!\n드디어 따라잡았어.')
        stage.say('&57\n배신자 조, 도망가지 마!\n아무리 멀리 가도,\n아버지의 복수를 원해!')
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&0\n정말 끈질긴 사람이네요.')
        vars[12] = 1
    if vars[754] and not vars[13] and stage.round() == 7 and stage.curCamp() == 2:
        stage.unit(72).show()
        stage.unit(310).show()
        stage.unit(73).show()
        stage.unit(390).show()
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(391).show()
        stage.unit(392).show()
        stage.unit(383).show()
        stage.unit(384).show()
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.say('&71\n아, 늦었네.\n북쪽 산길은 정말 적응하기 힘들어,\n하지만 그는 여전히 길을 잃었어. 하! 하! 하!')
        if not vars[50]:
            stage.unit(50).setDir(stage.countDir(50, 71))
            stage.say('&50\n타이밍 좋네요!\n이렇게 하면 도시를 방어할 수 있습니다.')
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(72).setAction(5)
        stage.say('&72\n자, 모두, 함께 싸우자!\n좋은 성과를 내고 지연된 군사 성과를 만회하세요!')
        stage.unit(72).setAction(0)
        stage.say('&73\n정말 쉬고 싶어요......')
        stage.unit(0).setDir(stage.countDir(0, 72))
        stage.say('&0\n뜻밖에도 남부 야만인들도 그들을 쫓고 있었다.')
        if not vars[2]:
            stage.say('&0\n더 이상 지체할 수 없어. 어떻게 할까? 돌파 전술을 취해야 하나?')
            sel = stage.choice('양평관 돌파\n전멸시키적군', -1)
            if sel == 1:
                stage.say('&0\n더 이상 늦출 순 없어. 적군의 포위망을 뚫고 나서, 공명을 추격하자!')
                stage.unit(71).setDir(stage.countDir(71, 0))
                stage.unit(71).setAction(5)
                stage.say('&71\n하하하, 그렇게 쉽게 도망칠 수 있다고 생각하지 마!\n여러분, 힘내세요!')
                stage.unit(71).setAction(0)
                if not vars[31]:
                    if not vars[53]:
                        stage.unit(36).setDir(stage.countDir(36, 0))
                        stage.say('&36\n조조 도망치지 마!\n나도 따라갈게!')
                    if not vars[52]:
                        stage.unit(34).setDir(stage.countDir(34, 0))
                        stage.say('&34\n나도 싸울 거야.')
                    stage.setAI(14, 8, 23, 17, 2, 1)
                    vars[31] = 1
                stage.setWinCondition('승리 조건\n1. 북서쪽 끝에 도달조조.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
                stage.showWinCondition('양평관을 돌파하라!')
                stage.heightLight(0, 0, 1, 3)
                vars[2] = 1
            elif sel == 2:
                stage.say('&0\n안 돼, 이곳의 적군을 먼저 소멸시켜서,\n후환을 없애야 해.\n&72\n하하하! 네가 정말 할 수 있겠어? 하하하!')
        vars[13] = 1
    if not vars[14] and not vars[754] and stage.round() == 7 and stage.curCamp() == 2:
        stage.unit(72).show()
        stage.unit(310).show()
        stage.unit(73).show()
        stage.unit(390).show()
        stage.unit(71).show()
        stage.unit(382).show()
        stage.unit(71).setDir(stage.countDir(71, 0))
        stage.say('&71\n아, 늦었네.\n내가 다치지 않았다면......')
        if not vars[50]:
            stage.unit(50).setDir(stage.countDir(50, 71))
            stage.say('&50\n타이밍 좋네요!\n이렇게 하면 도시를 방어할 수 있습니다.')
        stage.unit(72).setDir(stage.countDir(72, 0))
        stage.unit(72).setAction(5)
        stage.say('&72\n자, 모두, 함께 싸우자!\n좋은 성과를 내고 지연된 군사 성과를 만회하세요!')
        stage.unit(72).setAction(0)
        stage.say('&73\n정말 쉬고 싶어요......')
        vars[14] = 1
    if not vars[20] and stage.isInPos(1025, 19, 11):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 19, 14):
        stage.getItem(152, -1, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 15, 12):
        stage.getItem(151, -1, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 23, 13):
        stage.getItem(151, -1, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 8, 24):
        stage.getItem(152, -1, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 11, 24):
        stage.getItem(152, -1, True, 1025)
        vars[25] = 1
    if not vars[26] and stage.isInPos(1025, 10, 20):
        stage.getItem(151, -1, True, 1025)
        vars[26] = 1
    if not vars[27] and stage.isInPos(1025, 9, 28):
        stage.getItem(151, -1, True, 1025)
        vars[27] = 1
    if not vars[28] and stage.isInPos(1025, 4, 7):
        stage.getItem(151, -1, True, 1025)
        vars[28] = 1
    if not vars[30] and stage.isInRect(1025, 6, 19, 13, 29):
        if not vars[61]:
            stage.unit(45).setDir(stage.countDir(45, 0))
            stage.say('&45\n마침내 그들은 싸우러 왔다.')
        if not vars[62]:
            stage.unit(65).setDir(stage.countDir(65, 0))
            stage.say('&65\n여러분, 힘내세요!')
        if not vars[59]:
            stage.unit(55).setDir(stage.countDir(55, 0))
            stage.say('&55\n그들은 절대 조의 군대가 이곳을 통과하게 해서는 안 된다.\n무조건 차단하려고 노력하세요.')
        if not vars[60]:
            stage.unit(56).setDir(stage.countDir(56, 0))
            stage.say('&56\n공격이 최고의 방어입니다.\n우리가 조조 군대를 먼저 막아야 해!')
        stage.setAI(6, 19, 13, 29, 2, 1)
        vars[30] = 1
    if not vars[31] and stage.curCamp() == 2 and stage.isInRect(1025, 14, 8, 23, 17):
        if not vars[53]:
            stage.unit(36).setDir(stage.countDir(36, 0))
            stage.say('&36\n결과는 이 한 수에 달려 있습니다.\n공격!')
        if not vars[52]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n나는 조조의 군대가 다시는 돌아오지 못하게 하고 싶다.')
        stage.setAI(14, 8, 23, 17, 2, 1)
        vars[31] = 1
    if not vars[32] and stage.curCamp() == 2 and stage.isInRect(1025, 0, 0, 8, 11):
        if not vars[50] and stage.isInPos(50, 3, 6):
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n그럼에도 불구하고 조의 군대는 이 지점에 도달했다.\n진정으로 조조라고 불릴 만한 존재였다.\n대단해, 대단해!')
        if not vars[51] and stage.isInPos(37, 4, 7):
            stage.unit(37).setDir(stage.countDir(37, 0))
            stage.say('&37\n정말 끈질긴 사람이네요.\n내가 싸울 거야.')
        if not vars[31]:
            if not vars[53]:
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.say('&36\n조조 도망칠 거야!\n서둘러 쫓아!')
            if not vars[52]:
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&34\n측면적군 공격해!\n전군, 동원!')
            vars[31] = 1
        stage.setAI(0, 0, 23, 35, 2, 1)
        vars[32] = 1
    if vars[2] and not vars[33] and stage.isInRect(0, 0, 0, 1, 3):
        stage.resumeCtrl()
        if not vars[50]:
            stage.unit(50).setDir(stage.countDir(50, 0))
            stage.say('&50\n아-아, 안 돼!\n뜻밖에도, 조의 군대가 장걸을 지나기 전에 예상치 못했다.\n이제 그는 그가 양평관을 뚫고 나가는 모습을 눈앞에서 지켜보고 있었다.\n&50\n흠, 어떻게 공명 사장님을 마주하죠?\n차라리 숨기는 게 낫지.')
            stage.unit(50).hide()
        if not vars[51]:
            stage.unit(37).setDir(stage.countDir(37, 0))
            stage.say('&37\n훗, 또 패배했네.\n우장 평원으로 후퇴하라!')
        if not vars[54]:
            stage.unit(57).setDir(stage.countDir(57, 0))
            stage.unit(57).setAction(5)
            stage.say('&57\n다른 방법은 없었다.\n그래서 당분간 군대를 철수할 수밖에 없었다.\n먼저 우장 평원을 우회한 뒤, 조조의 군대를 정면으로 공격하라!')
            stage.unit(57).setAction(0)
        if not vars[56]:
            stage.unit(71).setDir(stage.countDir(71, 0))
            stage.say('&71\n탈출했구나?\n다음엔 어디로 가야 할까?')
        if not vars[52]:
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&34\n남은 병력을 모으며,\n전략가 진영으로 후퇴하세요.\n빨리!')
        stage.setRectUnitHide(0, 0, 23, 35, 2)
        vars[33] = 1
        stage.say('&0\n양평관을 돌파하는 아군 보자마자 왜 바로 후퇴했을까?\n흠, 스파이를 보내서 확인해 보세요.\n퇴각하는 슈군이 공명가 있는 곳으로 급히 달려갔음에 틀림없다.\n&0\n전체 군대는 북쪽으로 계속 진격했다.\n전략가들은 이 기회를 이용해 제단의 위치를 조사했다.\n&0\n시간이 많지 않아.\n가능한 모든 방법을 다 써도,\n그는 또한 그를 죽공명 찾아야 한다.')
        stage.reward(0, [
            145,
            -1])
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[655] = 1
        return True
    if not vars[40] and stage.isNear(3, 34, False):
        stage.unit(34).setDir(stage.countDir(34, 3))
        stage.unit(3).setDir(stage.countDir(3, 34))
        stage.say('&3\n쯔롱.\n&34\n뜻밖에도 품위 있는 관우은 서나라에 반란을 일으켜 위나라에 항복했다.\n자, 진정하자!')
        fight = stage.startFight(3, 34, 5)
        fight.showUnit(True, '쯔롱, 제발 기다려!\n이 문제는 더 이상 단순한 두 나라 간의 분쟁이 아닙니다.\n제가 설명할 내용을 잘 들어주세요.', 6)
        fight.showUnit(False, '좋아,\n어떻게 설명하느냐에 따라 다릅니다.', 0)
        fight.setAction(True, 0)
        fight.say(True, '그의 형brother유비과 셋째 동생을 죽이는 일,\n사실, 공명의 음모였다.\n그의 진짜 목표는 마왕을 부활시키는 것이었다.', True)
        fight.setAction(True, 8)
        fight.say(True, '공명 문제를 일으키면 세상은 순식간에 파괴될 거야.\n왜냐하면 공명은 이제 마왕에게 빙의되었기 때문이다.', True)
        fight.setAction(False, 6)
        fight.say(False, '흥미롭네요,\n안타깝게도 저는 한쪽 말만 듣고 한 가지를 믿을 수 없습니다,\n그리고 반역의 주범이 된다.', True)
        fight.setAction(False, 9)
        fight.say(False, '마왕 같은 존재는 말할 것도 없고,\n어떻게 그렇게 쉽게 믿을 수 있지?\n더 이상 말할 필요 없으니, 우리 둘이 이 문제를 해결합시다!', True)
        fight.setAction(True, 9)
        fight.say(True, '그래서 이렇게 될 수밖에 없었다.\n조심해, 나, 관은 절대 굴복하지 않을 거야!', True)
        fight.setAction(False, 8)
        fight.say(False, '내 바람대로!', True)
        fight.showStart()
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(False, 1, False)
        fight.attack1(True, 1, False)
        fight.attack1(True, 3, False)
        fight.setAction(True, 2)
        fight.attack1(True, 2, True)
        fight.setAction(True, 2)
        fight.attack2(False, 1, True)
        fight.setAction(True, 1)
        fight.setAction(True, 8)
        fight.setAction(False, 1)
        fight.attack1(True, 3, True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 3, False)
        fight.setAction(False, 1)
        fight.setAction(False, 2)
        fight.setAction(False, 1)
        fight.setAction(True, 2)
        fight.setAction(True, 2)
        fight.attack1(False, 3, True)
        fight.setAction(False, 2)
        fight.attack2(False, 0, True)
        fight.attack2(False, 0, True)
        fight.attack2(True, 0, True)
        fight.attack2(True, 0, True)
        fight.attack1(True, 4, False)
        fight.setAction(True, 1)
        fight.attack1(True, 2, True)
        stage.delay(20)
        fight.setAction(True, 6)
        fight.say(True, '무술 실력이 대단하네, 자룡!', True)
        fight.setAction(False, 0)
        fight.say(False, '관장군은 진정한 영웅이다, 예년과 다름없이,\n소중한 칼날이 가는 곳은 무적이다!', True)
        fight.setAction(False, 6)
        fight.say(False, '관장군께서 더 이상 말씀하지 말아 달라고 부탁드립니다,\n조운 슈에게 충성하려 할 뿐이야.', True)
        fight.setAction(True, 0)
        fight.say(True, '조운............', True)
        fight.end()
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 50, True):
        stage.unit(50).setDir(stage.countDir(50, 0))
        stage.unit(0).setDir(stage.countDir(0, 50))
        stage.say('&0\n말들이 앞으로 나와, 빨리 떠나!\n&50\n나는 공명 선생님의 지시를 따라 이 길을 지켰다,\n아무도 이곳을 쉽게 통과할 수 없어.\n&0\n그래서 조는 어쩔 수 없이 억지로 통과할 수밖에 없었다.\n&50\n쳇, 쳇, 쳇!\n감히 나를 깔보다니, 공명 선배 제자라니?\n나중에 곤란해질 거야!')
        vars[41] = 1
    if not vars[43] and stage.isNear(19, 37, True):
        stage.unit(37).setDir(stage.countDir(37, 19))
        stage.unit(19).setDir(stage.countDir(19, 37))
        stage.say('&37\n당신이 조의 전략가인 것 같군요,\n네 목을 가져가서 보상을 받아가게 해줘!\n&19\n알고 보니 공명의 부하였다,\n안타깝게도 나는 너와 싸울 생각이 없다.\n&37\n무슨 부하!?\n헛소리 그만해, 나는 슈 군대의 장군이야.\n그 남자의 부하가 아니야!\n&19\n시간을 벌어야 하는 거 아니공명?\n이것이 부하 상태와 어떻게 다른가요?\n&37\n그 남자가 마지막 제단을 짓고 싶다고 했어,\n그래서 그들은 숨을 핑계를 찾았다.\n우리가 우리 중 하나임에도 불구하고, 이 굴욕을 삼킬 수가 없어!\n&19\n(마지막 제단?)\n이 제단은 세 번째여야 해......\n설두의 제단이 이미 완성된 걸까요!? )\n&19\n그렇다면 그를 지적할 수 있습니다.\n&37\n그걸 뭐라고 부르지? 이 사람은 벌써 5장을 넘었어......\n와, 정말 대단하구나.\n난 네가 쉽게 빠져나갈 수 있는 사람이 아니야!')
        vars[43] = 1
    if not vars[50] and stage.unitStateTest(50, 7, 0, 2):
        stage.say('&50\n와!\n내가 여기서 죽을 줄은 몰랐어.')
        stage.unit(50).hide(2)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n내 삶을 평화롭게 공명 줄 수 없었다.\n빨리 후퇴해!')
        stage.unit(37).hide(1)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n일단 후퇴하자.')
        stage.unit(34).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(36, 7, 0, 2):
        stage.say('&36\n내가 정말 나이 든 걸까?\n후퇴!')
        stage.unit(36).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n또 길을 잃었어......\n후퇴!')
        stage.unit(57).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(58, 7, 0, 2):
        stage.say('&58\n좋지 않아!\n빨리 후퇴해, 빨리 후퇴해!')
        stage.unit(58).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(71, 7, 0, 2):
        stage.say('&71\n음음!\n아직 체력이 부족한 것 같아. 후퇴하자!\n하지만 이번에는 길을 안내할 가이드를 찾아야 해.')
        stage.unit(71).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(73, 7, 0, 2):
        stage.say('&71\n후퇴.........\n그런데 어디로 후퇴해야 할까요?\n뭐, 나 먼저 가야겠다!')
        stage.unit(73).hide(1)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(72, 7, 0, 2):
        stage.say('&72\n아!\n여자한테 그렇게 무례하게 굴지 마.\n어쨌든, 싸움은 꽤 장난기 많았다.\n나 간다!')
        stage.unit(72).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(55, 7, 0, 2):
        stage.say('&55\n아직도 못 버텼...... 으악!')
        stage.unit(55).hide(2)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(56, 7, 0, 2):
        stage.say('&56\n내 인생은 끝났어...... 절대 안 돼!')
        stage.unit(56).hide(2)
        vars[60] = 1
    if not vars[61] and stage.unitStateTest(45, 7, 0, 2):
        stage.say('&45\n대부님, 제 아들도 죽을 거예요.........')
        stage.unit(45).hide(2)
        vars[61] = 1
    if not vars[62] and stage.unitStateTest(65, 7, 0, 2):
        stage.say('&65\n오, 안 돼!\n마수의 계획을 믿지 말았어야 했다......\n정말 받아들일 수 없어요.........')
        stage.unit(65).hide(2)
        vars[62] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n좋습니다. 이제 후방 걱정이 없습니다.\n다음 단계의 임무는 오직 공명을 찾아내는 것뿐입니다.\n밀사를 보내서 그들의 은퇴처를 찾게 하십시오!\n전군이 계속 북상합니다.\n군사들은 이 틈타서 제단 위치를 탐지해 보겠습니다.\n우리의 시간은 많지 않습니다.\n모든 방법을 동원하더라도,\n공명을 반드시 찾아내어 처형해야 합니다.')
        stage.reward(0, [
            145,
            -1])
        stage.end()
        vars[0] = 1
        vars[655] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조의 군대는 쑤나라 군대에 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
