# Source Generated with Decompyle++
# File: S_37.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21], [
        '(9,7)',
        '(10,7)'])
    stage.nearEvent([
        62,
        4])
    stage.nearEvent([
        0,
        57,
        0,
        37,
        0,
        62,
        0,
        4], 1)
    stage.initFight()
    stage.setGlobalData(30, -2, -1, 0, 1, 1)
    stage.createFriend([
        {
            'id': 4,
            'hide': 1,
            'x': 9,
            'y': 1,
            'lv': 4,
            'ai': 3,
            'targetId': 0,
            'i': 0 },
        {
            'id': 210,
            'hide': 1,
            'x': 10,
            'y': 1,
            'lv': 0,
            'ai': 3,
            'targetId': 0,
            'i': 1 },
        {
            'id': 211,
            'hide': 1,
            'x': 10,
            'y': 0,
            'lv': 0,
            'ai': 3,
            'targetId': 0,
            'i': 2 },
        {
            'id': 236,
            'hide': 1,
            'x': 9,
            'y': 0,
            'lv': 0,
            'ai': 3,
            'targetId': 0,
            'i': 3 }])
    stage.createEnemy(
        [{'id': 57, 'x': 13, 'y': 8, 'lv': 6, 'ai': 1, 'i': 0},
         {'id': 37, 'x': 6, 'y': 6, 'lv': 6, 'ai': 1, 'i': 1},
         {'id': 62, 'x': 9, 'y': 7, 'lv': 4, 'ai': 1, 'i': 2},
         {'id': 318, 'x': 7, 'y': 4, 'lv': 0, 'ai': 1, 'i': 3},
         {'id': 319, 'x': 7, 'y': 9, 'lv': 0, 'ai': 1, 'i': 4},
         {'id': 320, 'x': 12, 'y': 5, 'lv': 0, 'ai': 1, 'i': 5},
         {'id': 321, 'x': 12, 'y': 10, 'lv': 0, 'ai': 1, 'i': 6},
         {'id': 310, 'hide': 1, 'x': 7, 'y': 8, 'lv': 0, 'ai': 1, 'i': 7},
         {'id': 311, 'x': 10, 'y': 9, 'lv': 0, 'ai': 1, 'i': 8},
         {'id': 312, 'x': 14, 'y': 6, 'lv': 0, 'ai': 1, 'i': 9},
         {'id': 45, 'hide': 1, 'x': 9, 'y': 23, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 10},
         {'id': 65, 'hide': 1, 'x': 10, 'y': 23, 'dir': 0, 'lv': 4, 'ai': 1, 'i': 11},
         {'id': 390, 'hide': 1, 'x': 8, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 391, 'hide': 1, 'x': 11, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 382, 'hide': 1, 'x': 8, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 383, 'hide': 1, 'x': 11, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 234, 'hide': 1, 'x': 9, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 235, 'hide': 1, 'x': 10, 'y': 23, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 32, 'hide': 1, 'x': 12, 'y': 22, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 18},
         {'id': 33, 'hide': 1, 'x': 12, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 19},
         {'id': 36, 'hide': 1, 'x': 11, 'y': 22, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 20},
         {'id': 258, 'hide': 1, 'x': 11, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 21},
         {'id': 259, 'hide': 1, 'x': 13, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 22},
         {'id': 282, 'hide': 1, 'x': 13, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 23},
         {'id': 35, 'hide': 1, 'x': 7, 'y': 22, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 24},
         {'id': 34, 'hide': 1, 'x': 7, 'y': 21, 'dir': 0, 'lv': 6, 'ai': 0, 'i': 25},
         {'id': 260, 'hide': 1, 'x': 6, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 26},
         {'id': 261, 'hide': 1, 'x': 8, 'y': 21, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 27},
         {'id': 283, 'hide': 1, 'x': 6, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 28},
         {'id': 284, 'hide': 1, 'x': 8, 'y': 22, 'dir': 0, 'lv': 0, 'ai': 0, 'i': 29},
         {'id': 213, 'x': 9, 'y': 4, 'lv': 0, 'ai': 1, 'i': 30},
         {'id': 214, 'x': 9, 'y': 10, 'lv': 0, 'ai': 1, 'i': 31}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 9,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 1,
            'x': 10,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 2,
            'x': 8,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 3,
            'x': 11,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 4,
            'x': 8,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 5,
            'x': 11,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 6,
            'x': 9,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 7,
            'x': 10,
            'y': 23,
            'dir': 0,
            'hide': 1 },
        {
            'idx': 8,
            'dir': 0 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.setEnemyEquip(33, 37, 0, -1, 0, -1)
    stage.setEnemyEquip(34, -1, 0, 13, 0, -1)
    stage.setEnemyEquip(32, 32, 0, -1, 0, 14)
    stage.setEnemyEquip(35, 51, 0, 26, 0, 9)
    stage.setEnemyEquip(62, -1, 0, -1, 0, 11)
    stage.loadBg(37)
    stage.setObjects(True, 26, [
        [
            0,
            6,
            4],
        [
            0,
            6,
            5]])
    stage.setObjects(True, 26, [
        [
            0,
            6,
            9],
        [
            0,
            6,
            10]])
    stage.setObjects(True, 26, [
        [
            0,
            8,
            5],
        [
            0,
            9,
            5]])
    stage.setObject(True, 26, 0, 11, 5)
    stage.setObject(True, 26, 0, 11, 7)
    stage.setObjects(True, 26, [
        [
            0,
            13,
            4],
        [
            0,
            13,
            5]])
    stage.setObject(True, 26, 0, 13, 10)
    stage.setObjects(True, 26, [
        [
            0,
            14,
            4],
        [
            0,
            14,
            5]])
    stage.setObjects(True, 26, [
        [
            0,
            14,
            9],
        [
            0,
            14,
            10]])
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab40')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab40')
    stage.draw()
    stage.bgSound(6)
    stage.unit(2, 1).show()
    stage.unit(2, 1).move(8, 19, 0)
    stage.unit(0, 1).show()
    stage.unit(0, 1).move(9, 19, 0)
    stage.unit(1, 1).show()
    stage.unit(1, 1).move(10, 19, 0)
    stage.unit(3, 1).show()
    stage.unit(3, 1).move(11, 19, 0)
    stage.unit(4, 1).show()
    stage.unit(4, 1).move(8, 20, 0)
    stage.unit(6, 1).show()
    stage.unit(6, 1).move(9, 20, 0)
    stage.unit(7, 1).show()
    stage.unit(7, 1).move(10, 20, 0)
    stage.unit(5, 1).show()
    stage.unit(5, 1).move(11, 20, 0)
    stage.say('&0\n불길은 점점 커지고 있었다.\n그래도 ......를 놓친 것 같네요')
    stage.unit(2, 1).move(8, 14, 0)
    stage.unit(0, 1).move(9, 14, 0)
    stage.unit(1, 1).move(10, 14, 0)
    stage.unit(3, 1).move(11, 14, 0)
    stage.unit(4, 1).move(8, 15, 0)
    stage.unit(6, 1).move(9, 15, 0)
    stage.unit(7, 1).move(10, 15, 0)
    stage.unit(5, 1).move(11, 15, 0)
    stage.say('&57\n하하하, 조조 늦었네!\n&62\n이곳은 이미 함락되었고,\n절대 돌아갈 수 없어.\n&37\n만약 내가 널 죽일 수 있다면,\n완전한 승리아군 될 것입니다.\n그냥 순순히 머리를 내밀어!\n&0\n음, 음, ......')
    stage.unit(390).show()
    stage.unit(390).move(8, 19, 0)
    stage.unit(45).show()
    stage.unit(45).move(9, 19, 0)
    stage.unit(65).show()
    stage.unit(65).move(10, 19, 0)
    stage.unit(391).show()
    stage.unit(391).move(11, 19, 0)
    stage.unit(382).show()
    stage.unit(382).move(8, 20, 0)
    stage.unit(234).show()
    stage.unit(234).move(9, 20, 0)
    stage.unit(235).show()
    stage.unit(235).move(10, 20, 0)
    stage.unit(383).show()
    stage.unit(383).move(11, 20, 0)
    stage.unit(45).setAction(9)
    stage.say('&45\n아......\n드디어 따라잡았다.\n조조조! 내 목숨을 내걸어라!\n&65\n와, 일이 꽤 잘 되고 있네요!\n이것은 기여할 수 있는 좋은 기회였습니다.')
    stage.unit(0).setDir(stage.countDir(0, 65))
    stage.say('&0\n그 뒤에는 적들도 있다......\n안 좋네, 도망칠 방법이 없어!')
    stage.unit(4).show()
    stage.unit(210).show()
    stage.unit(211).show()
    stage.unit(236).show()
    stage.unit(4).setDir(stage.countDir(4, 0))
    stage.say('&4\n아버지! 아버지!\n아버지, 어디 계세요!?')
    stage.unit(0).setDir(stage.countDir(0, 4))
    stage.say('&0\n조창!? 조창이세요?\n&4\n아, 아버지! 무사하시군요?\n제가 바로 가서 모시겠습니다!\n&0\n만약 조창과 합류할 방법을 찾을 수 있다면,\n위험한 곳에서 벗어날 수도 있을 텐데요...')
    stage.setWinCondition('승리 조건\n1. 모든 적군를 전멸시켜라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
    stage.showWinCondition('전부 전멸시적군!')
    stage.startOper()
    vars[537] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if not vars[11] and stage.curCamp() == 2 and stage.round() == 3:
        stage.unit(260).show()
        stage.unit(34).show()
        stage.unit(261).show()
        stage.unit(283).show()
        stage.unit(35).show()
        stage.unit(284).show()
        stage.unit(258).show()
        stage.unit(33).show()
        stage.unit(259).show()
        stage.unit(36).show()
        stage.unit(32).show()
        stage.unit(282).show()
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.say('&32\n진정으로 조조가 될 만한 존재—그들을 잡는 것이 그리 쉽지 않을 것 같다.\n하지만 내가 주력과 함께 도착했으니,\n네 인생은 여기서 끝이야!')
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n흠, 주력 부대도 도착적군 건가?\n후퇴만이 유일한 선택일까요!?')
        sel = stage.choice('포위 돌파\n완전히 저항하세요', -1)
        vars[11] = 1
        if sel == 1:
            if stage.isInRect(0, 7, 0, 12, 3):
                stage.resumeCtrl()
                stage.unit(0).setAction(5)
                stage.say('&0\n유비 이곳을 떠나게 해.\n후퇴!')
                stage.unit(0).setAction(0)
                stage.unit(32).setDir(stage.countDir(32, 0))
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.setRectUnitHide(0, 0, 19, 23, 4)
                stage.say('&32\n아-아, 안 돼!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 반드시 잡아야 해!\n&35\n조조을 치우지 않으면 모든 것이 헛되이 됩니다.\n이 기회를 놓치면 정말 아쉬울 것입니다.\n&33\n용기 있으면 도망치지 마라니 무슨 뜻이야!\n&36\n하하하.\n그들이 너무 빨리 도망쳤어!\n&34\n흠.')
                stage.reward()
                stage.end()
                vars[100] = 1
                vars[0] = 1
                vars[637] = 1
                return True
            stage.unit(0).setAction(5)
            stage.say('&0\n모든 병사들은 명령을 따른다!\n이제 곡물 창고 적군을 공격하며,\n한 번에 돌진해 적진을 돌파하라!\n&0\n적의 사격 속 움직임은 꽤 느렸다,\n우리가 신속하게 행동하기만 하면 성공할 수 있습니다.\n군대 전체, 나를 따라와!')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 적을 완전히 제거한다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(7, 0, 12, 3)
            stage.unit(32).setDir(stage.countDir(32, 0))
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.unit(33).setDir(stage.countDir(33, 0))
            stage.unit(36).setDir(stage.countDir(36, 0))
            stage.unit(34).setDir(stage.countDir(34, 0))
            stage.say('&32\n조조 도망칠 거야!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 잡아!\n&35\n만약 조조 탈출한다면, 완전한 실패가 될 것이다.\n반드시 잡아야 조조!\n&33\n조조Don 도망가지 마!"\n&36\n화살로 조조 쏴버릴게요!\n&34\n조자룡이 도착했습니다!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            vars[2] = 1
        elif sel == 2:
            if stage.totalRectUnit(2, 0, 0, 19, 20) < 9:
                stage.say('&0\n소모전을 한다면 여전히 승리할 가능성이 있습니다,\n이곳을 굳게 지킨다면,\n유비 단기 전략도 매우 수동적일 것입니다.\n&32\n더 이상 도망치지 않아, 그렇지! 진심으로 하늘에 감사해.\n네가 출마하지 않으니까 우리가 일을 처리하기가 더 쉬워.')
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.say('&35\n딩준산은 이미 점령되었지만,\n이곳을 점령하지 못하면 위를 공격하기 어려울 것이다.\n조조 이 늙은 도둑의 결정은 정말 영리했다.')
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&33\n하하하.\n손이 간지러워!\n&36\n화살로 조조 쏴버릴게요!\n&34\n조자룡이 도착했습니다!')
                stage.setAI(0, 0, 19, 23, 2, 1)
                stage.unit(0).setAction(2)
                stage.say('&0\n오고 싶으면 그냥 와!\n이 자리는 꼭 지킬 거야.')
            elif stage.totalRectUnit(4, 0, 17, 19, 23) >= 1:
                stage.say('&0\n소모전을 한다면 여전히 승리할 가능성이 있습니다,\n이곳을 굳게 지킨다면,\n유비 단기 전략도 매우 수동적일 것입니다.\n&32\n더 이상 도망치지 않아, 그렇지! 진심으로 하늘에 감사해.\n네가 출마하지 않으니까 우리가 일을 처리하기가 더 쉬워.')
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.say('&35\n딩준산은 이미 점령되었지만,\n이곳을 점령하지 못하면 위를 공격하기 어려울 것이다.\n조조 이 늙은 도둑의 결정은 정말 영리했다.')
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&33\n하하하.\n손이 간지러워!\n&36\n화살로 조조 쏴버릴게요!\n&34\n조자룡이 도착했습니다!')
                stage.setAI(0, 0, 19, 23, 2, 1)
                stage.unit(0).setAction(2)
                stage.say('&0\n오고 싶으면 그냥 와!\n이 자리는 꼭 지킬 거야.')
            else:
                stage.say('&0\n소모전을 한다면 여전히 승리할 가능성이 있습니다,\n이곳을 굳게 지킨다면,\n유비 단기 전략도 매우 수동적일 것입니다.\n&32\n더 이상 도망치지 않아! 운명을 받아들였니?')
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.say('&35\n딩준산은 이미 점령되었지만,\n하지만 이 지역을 점령하지 못하면 위나라를 공격하기 어려울 것입니다.\n조조 이 늙은 도둑의 결정은 정말 훌륭했다.\n&32\n모두가 이곳으로 달려와 지쳐 있었다,\n먼저 숨 좀 고르는 게 낫지.\n병사들이 휴식을 취한 후, 전 군대가 전면적인 공격을 개시할 것이다.')
                stage.unit(35).setDir(stage.countDir(35, 32))
                stage.say('&35\n주군, 지연이 길어질수록,\n그는 조조만 도와주고 있어.\n즉시 공격하는 게 낫다!')
                stage.unit(32).setDir(stage.countDir(32, 35))
                stage.say('&32\n나도 이걸 알아,\n하지만 병사들이 이렇게 지친 상태에서 어떻게 전투를 치를 수 있겠는가?\n나머지는 눈 깜짝할 사이에 불과합니다.\n&35\n주군 말했으니까......\n공명 더 이상 강요하지 않았다.........\n하지만 항상 조조의 행동에 주의를 기울여야 합니다.\n&32\n흠!')
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&33\n조조 바로 앞에 있는데 싸울 수 없어?\n&36\n나 걱정할 필요 전혀 없어!\n&34\n주군 이렇게 설명했으니까요......\n좋아, 군대 전체가 휴식을 취하고 명령을 기다린다!')
                stage.setAI(0, 0, 19, 20, 2, 1)
                stage.setAI(0, 21, 19, 23, 2, 2)
                stage.unit(0).setAction(5)
                stage.say('&0\n어!? 유비 안 움직여?\n정말 많은 도움이 되었어요,\n이 기회를 이용해 적군을 최대한 약화시키세요!')
                stage.unit(0).setAction(0)
                vars[3] = 1
    if not vars[20] and stage.isInPos(1025, 9, 7):
        stage.getItem(152, -1, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 10, 7):
        stage.getItem(152, -1, True, 1025)
        vars[21] = 1
    if vars[3] and not vars[6] and not vars[7] and not vars[50] and not vars[51] and stage.curCamp() == 2 and stage.totalRectUnit(2, 0, 0, 19, 20) < 9 and stage.round() >= 4:
        stage.unit(35).setDir(stage.countDir(35, 32))
        stage.say('&35\n주군, 빨리 행동하지 않으면,\n조조 도망치려 하고 있었다.\n전 군대에 공격 명령을 내려라!')
        stage.unit(32).setAction(5)
        stage.say('&32\n만약 조조가 도망친다면,\n그건 오판이야!\n전면 돌격!')
        stage.unit(32).setAction(0)
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n흠, 주력 부대가 움직이고 있어!\n도망치는 게 유일한 선택일까?')
        sel = stage.choice('전 군대가 포위망을 돌파했다\n전면적인 저항', -1)
        vars[6] = 1
        if sel == 1:
            if stage.isInRect(0, 7, 0, 12, 3):
                stage.resumeCtrl()
                stage.say('좋습니다! 후퇴합니다!\n악당 공명!\n이 빚은 반드시 당신과 정산하겠습니다!')
                stage.unit(32).setDir(stage.countDir(32, 0))
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.setRectUnitHide(0, 0, 19, 23, 4)
                stage.say('&32\n아-아, 안 돼!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 반드시 잡아야 해!\n&35\n뜻밖에도 결국 조조는 탈출했다,\n이 일로 내 계획이 망가졌어!\n정말 안타깝네요.........\n&33\n아......\n또 도망쳤어......\n&36\n흠, 그래도 치명타를 가하지 못했어.\n&34\n흥! 또 도망치는 거야?')
                stage.reward()
                stage.end()
                vars[100] = 1
                vars[0] = 1
                vars[637] = 1
                return True
            stage.say('&0\n모든 병사들은 명령을 따른다!\n이제 곡물 창고 적군을 공격하며,\n한 번에 전진해 적진을 돌파하라\n&0\n적의 사격 속 움직임은 꽤 느렸다,\n빠르게 행동하기만 하면 성공은 어렵지 않을 거예요.')
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(7, 0, 12, 3)
            stage.unit(32).setDir(stage.countDir(32, 0))
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.say('&32\n조조 도망칠 거야!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 반드시 잡아야 해!\n&35\n만약 조조 탈출한다면, 완전한 실패가 될 것이다.\n반드시 잡아야 조조!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            if not vars[52]:
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.say('&33\n하하하.\n손이 간지러워!')
            if not vars[54]:
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.say('&36\n화살로 조조 쏴버릴게요!')
            if not vars[53]:
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&34\n조자룡이 도착했습니다!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            vars[2] = 1
        elif sel == 2:
            stage.say('&0\n아직 버틸 수 있지만, 지금 후퇴하면,\n앞으로는 유비를 이길 희망은 더욱 줄어들 것이다.\n이제 유비를 죽여야만 내일을 가질 수 있어!')
            if not vars[52]:
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.say('&33\n하하하.\n손이 간지러워!')
            if not vars[54]:
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.say('&36\n어디 있조조!\n나랑 황충 합의해!')
            if not vars[53]:
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&34\n조자룡이 도착했습니다!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            stage.say('&0\n어서!\n이 자리는 꼭 지킬 거예요!')
    if vars[3] and not vars[6] and not vars[7] and not vars[50] and not vars[51] and stage.totalRectUnit(4, 0, 17, 19, 23) >= 1:
        stage.unit(35).setDir(stage.countDir(35, 32))
        stage.say('&35\n주군, 빨리 행동하지 않으면,\n조조 도망치려 하고 있었다.\n전 군대에 공격 명령을 내려라!')
        stage.unit(32).setAction(5)
        stage.say('&32\n만약 조조가 도망친다면,\n그건 오판이야!\n전면 돌격!')
        stage.unit(32).setAction(0)
        stage.unit(0).setDir(stage.countDir(0, 32))
        stage.say('&0\n흠, 주력 부대는 아직 움직이고 있어!\n도망치는 게 유일한 선택일까?')
        sel = stage.choice('전 군대가 포위망을 돌파했다\n전면적인 저항', -1)
        vars[7] = 1
        if sel == 1:
            if stage.isInRect(0, 7, 0, 12, 3):
                stage.resumeCtrl()
                stage.say('좋습니다! 후퇴합니다!\n악당 공명!\n이 빚은 반드시 당신과 정산하겠습니다!')
                stage.unit(32).setDir(stage.countDir(32, 0))
                stage.unit(35).setDir(stage.countDir(35, 0))
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.setRectUnitHide(0, 0, 19, 23, 4)
                stage.say('&32\n아-아, 안 돼!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 반드시 잡아야 해!\n&35\n뜻밖에도 결국 조조는 탈출했다,\n이 일로 내 계획이 망가졌어!\n정말 안타깝네요.........\n&33\n아......\n또 도망쳤어......\n&36\n흠, 그래도 치명타를 가하지 못했어.\n&34\n흥! 또 도망치는 거야?')
                stage.reward()
                stage.end()
                vars[100] = 1
                vars[0] = 1
                vars[637] = 1
                return True
            stage.say('&0\n모든 병사들은 명령을 따른다!\n이제 곡물 창고 적군을 공격하며,\n한 번에 돌진해 적진을 돌파하라!\n&0\n적의 사격 속 움직임은 꽤 느렸다,\n빠르게 행동하기만 하면 성공은 어렵지 않을 거예요.')
            stage.setWinCondition('승리 조건\n1. 조조 북쪽 끝에 도달합니다.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 30명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(7, 0, 12, 3)
            stage.unit(32).setDir(stage.countDir(32, 0))
            stage.unit(35).setDir(stage.countDir(35, 0))
            stage.say('&32\n조조 도망칠 거야!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 잡아!\n&35\n만약 조조 탈출한다면, 완전한 실패가 될 것이다.\n반드시 잡아야 조조!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            if not vars[52]:
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.say('&33\n하하하.\n손이 간지러워!')
            if not vars[54]:
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.say('&36\n화살로 조조 쏴버릴게요!')
            if not vars[53]:
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&34\n조자룡이 도착했습니다!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            vars[2] = 1
        elif sel == 2:
            stage.say('&0\n아직 버틸 수 있지만, 지금 후퇴하면,\n앞으로는 유비를 이길 희망은 더욱 줄어들 것이다.\n이제 유비를 죽여야만 내일을 가질 수 있어!')
            if not vars[52]:
                stage.unit(33).setDir(stage.countDir(33, 0))
                stage.say('&33\n하하하.\n손이 간지러워!')
            if not vars[54]:
                stage.unit(36).setDir(stage.countDir(36, 0))
                stage.say('&36\n어디 있조조!\n나랑 황충 합의해!')
            if not vars[53]:
                stage.unit(34).setDir(stage.countDir(34, 0))
                stage.say('&34\n조자룡이 도착했습니다!')
            stage.setAI(0, 0, 19, 23, 2, 1)
            stage.say('&0\n어서!\n이 자리는 꼭 지킬 거예요!')
    if vars[2] and not vars[30] and stage.isInRect(0, 7, 0, 12, 3):
        stage.resumeCtrl()
        stage.say('좋습니다! 후퇴합니다!\n악당 공명!\n이 빚은 반드시 갚겠습니다!')
        stage.unit(32).setDir(stage.countDir(32, 0))
        stage.unit(35).setDir(stage.countDir(35, 0))
        stage.unit(33).setDir(stage.countDir(33, 0))
        stage.unit(36).setDir(stage.countDir(36, 0))
        stage.unit(34).setDir(stage.countDir(34, 0))
        stage.setRectUnitHide(0, 0, 19, 23, 4)
        stage.say('&32\n아-아, 안 돼!\n쫓아가! 도망가지 못하게 조조!\n무슨 일이 있어도 반드시 잡아야 해!\n&35\n뜻밖에도 결국 조조는 탈출했다,\n이 일로 내 계획이 망가졌어!\n정말 안타깝네요.........\n&33\n아......\n또 도망쳤어......\n&36\n흠, 그래도 치명타를 가하지 못했어.\n&34\n아! 또 도망쳤구나?')
        stage.reward()
        stage.end()
        vars[100] = 1
        vars[0] = 1
        vars[637] = 1
        return True
    if not vars[40] and stage.isNear(0, 57, True):
        stage.unit(57).setDir(stage.countDir(57, 0))
        stage.unit(0).setDir(stage.countDir(0, 57))
        stage.say('&57\n오늘 나는 아버지의 죽음을 복수할 것이다!\n&0\n난 그렇게 쉽게 죽지 않을 거야.')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 37, True):
        stage.unit(37).setDir(stage.countDir(37, 0))
        stage.unit(0).setDir(stage.countDir(0, 37))
        stage.say('&37\n조조, 내가 널 죽이기만 하면,\n전쟁은 끝났다.\n네 삶을 저승으로 되돌려 놓을 거야!\n&0\n흥!\n야망 없는 너한테 지지 않을 거야.')
        vars[41] = 1
    if not vars[42] and stage.isNear(0, 62, True):
        stage.unit(62).setDir(stage.countDir(62, 0))
        stage.unit(0).setDir(stage.countDir(0, 62))
        stage.say('&62\n이쯤 되니 순순히 머리를 넘기는 게 낫지!\n&0\n아직 이긴 게 아니야.\n능력이 있다면 직접 와서 가져가세요.')
        vars[42] = 1
    if not vars[43] and stage.isNear(0, 4, True):
        stage.unit(4).setDir(stage.countDir(4, 0))
        stage.unit(0).setDir(stage.countDir(0, 4))
        stage.say('&4\n다행히도 아버지는 무사하셨습니다.\n내가 조장이 여기 있는 한,\n유비 네가 아무리 병력을 가져도 나한테는 신경도 안 써!\n&0\n넌 여전히 똑같구나, 차오장.\n상황은 심각하며 가볍게 여겨서는 안 됩니다.\n우리는 이 어려운 시기를 극복할 방법을 찾아야 합니다!\n&4\n네!')
        vars[43] = 1
    if not vars[44] and stage.isNear(62, 4, False):
        stage.unit(4).setDir(stage.countDir(4, 62))
        stage.unit(62).setDir(stage.countDir(62, 4))
        stage.say('&62\n마첸라이가 이름을 발표할 거야!\n&4\n조장(자문이라 불림)은 조조의 둘째 아들이었다.')
        fight = stage.startFight(4, 62, 5)
        fight.showUnit(True, '너랑 거래하는 건 남자야,\n아버지가 개입할 필요 없어.\n내가 충분히 상대할 수 있어!', 8)
        fight.showUnit(False, '아! 참 거만한 말투네!\n그가 조조의 아들이기 때문에,\n당분간 널 알게 될 거야!', 9)
        fight.showStart()
        fight.setAction(False, 6)
        fight.say(False, '이걸 받아라!', True)
        fight.say(True, '움직임이 너무 느렸다!', False)
        fight.setAction(True, 2)
        fight.attack2(True, 1, False)
        stage.delay(10)
        fight.say(False, '뭐...... 와!', True)
        fight.setAction(False, 11)
        fight.death(True)
        fight.setAction(True, 10)
        fight.setAction(True, 6)
        stage.delay(5)
        fight.say(True, '적군 장군 우란은 이미 나, 조장이 죽였다!', True)
        fight.end()
        stage.unit(62).hide(2)
        stage.getItem(118, -1, True, 4)
        vars[44] = 1
    if not vars[50] and stage.unitStateTest(35, 7, 0, 2):
        stage.say('&35\n뜻밖에도, 결말을 보기 전에,\n그는 실제로 다시 돌아가야 했다......')
        stage.unit(35).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(32, 7, 0, 2):
        stage.say('&32\n음, 아직 죽을 수 없어.\n후퇴!\n&32\n(조조 ah조조.........\n앞으로는 그런 기회가 좀처럼 없을지도 모릅니다,\n그들은 장군으로서 전선에서 만났다. )\n&32\n(나라를 다스리는 이들에게도 무력하다.)\n아마 앞으로 전장에서 다시 만나지 못할지도 몰라......\n안녕! )')
        stage.unit(32).hide(1)
        stage.getItem(30, -1, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(33, 7, 0, 2):
        stage.say('&33\n젠장!\n이게 조조를 죽일 마지막 기회일지도 몰라!\n정말 받아들일 수 없어......... 후퇴!')
        stage.unit(33).hide(1)
        stage.getItem(35, -1, True, 1027)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(34, 7, 0, 2):
        stage.say('&34\n너무 부주의해...... 후퇴!')
        stage.unit(34).hide(1)
        vars[53] = 1
    if not vars[54] and stage.unitStateTest(36, 7, 0, 2):
        stage.say('&36\n내가 벌써 나이 들었나......?\n이제 은퇴하고 집으로 돌아가야 할 때인 것 같아.\n후퇴.')
        stage.unit(36).hide(1)
        vars[54] = 1
    if not vars[55] and stage.unitStateTest(45, 7, 0, 2):
        stage.say('&45\n아, 아파...... 음.\n음, 다시는 전장에 가지 않을 거야.\n후퇴.')
        stage.unit(45).hide(1)
        vars[55] = 1
    if not vars[56] and stage.unitStateTest(57, 7, 0, 2):
        stage.say('&57\n어떻게 이런 일이 일어날 수 있지......\n선택의 여지가 없어, 후퇴해!')
        stage.unit(57).hide(1)
        vars[56] = 1
    if not vars[57] and stage.unitStateTest(62, 7, 0, 2):
        stage.say('&62\n나... 졌어......\n거의 죽일 뻔했어......\n거짓말 아니.........')
        stage.unit(62).hide(2)
        stage.getItem(118, -1, True, 1027)
        vars[57] = 1
    if not vars[58] and stage.unitStateTest(65, 7, 0, 2):
        stage.say('&65\n이 모든 게 위에 있는 바보들 때문이야,\n항상 부하들이 손실을 입게 만듭니다.\n다시는 장군이 되고 싶지 않아!')
        stage.unit(65).hide(1)
        vars[58] = 1
    if not vars[59] and stage.unitStateTest(37, 7, 0, 2):
        stage.say('&37\n음, 내 운이 너무 안 좋아!\n다음번에는 네가 그렇게 쉽게 성공하지 못하게 할 거야.\n후퇴!')
        stage.unit(37).hide(1)
        vars[59] = 1
    if not vars[60] and stage.unitStateTest(4, 7, 0, 2):
        stage.say('&4\n안 돼! 빨리 후퇴해!\n도우러 왔는데, 결국 공포에 질려 도망쳤어요!\n정말 안타깝네요......')
        stage.unit(4).hide(1)
        vars[60] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n마침내 우리는 이 어려운 시기를 극복했습니다.\n정말 힘든 싸움이었어!')
        if not vars[2]:
            stage.reward(0, [
                121,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[637] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 유비군에게 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
