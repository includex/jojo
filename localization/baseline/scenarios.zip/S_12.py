# Source Generated with Decompyle++
# File: S_12.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20,
        21,
        22,
        23,
        24,
        25], [
        '(0,10)',
        '(1,8)',
        '(1,11)',
        '(4,3)',
        '(4,16)',
        '(0,9)'])
    stage.nearEvent([
        0,
        143,
        0,
        23], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, -1, 0, 0, 1)
    stage.createEnemy(
        [{'id': 143, 'x': 0, 'y': 9, 'lv': 6, 'i': 0},
         {'id': 23, 'x': 0, 'y': 10, 'lv': 6, 'i': 1},
         {'id': 210, 'x': 1, 'y': 8, 'lv': 0, 'i': 2},
         {'id': 211, 'x': 1, 'y': 11, 'lv': 0, 'i': 3},
         {'id': 212, 'x': 2, 'y': 2, 'dir': 3, 'lv': 0, 'i': 4},
         {'id': 213, 'x': 2, 'y': 17, 'dir': 3, 'lv': 0, 'i': 5},
         {'id': 214, 'x': 6, 'y': 9, 'dir': 1, 'lv': 0, 'i': 6},
         {'id': 215, 'x': 6, 'y': 10, 'dir': 1, 'lv': 0, 'i': 7},
         {'id': 234, 'x': 3, 'y': 5, 'dir': 3, 'lv': 0, 'i': 8},
         {'id': 235, 'x': 3, 'y': 14, 'dir': 3, 'lv': 0, 'i': 9},
         {'id': 216, 'hide': 1, 'x': 0, 'y': 4, 'lv': 0, 'ai': 1, 'i': 10},
         {'id': 217, 'hide': 1, 'x': 1, 'y': 4, 'lv': 0, 'ai': 1, 'i': 11},
         {'id': 218, 'hide': 1, 'x': 2, 'y': 4, 'lv': 0, 'ai': 1, 'i': 12},
         {'id': 219, 'hide': 1, 'x': 0, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 13},
         {'id': 220, 'hide': 1, 'x': 1, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 14},
         {'id': 221, 'hide': 1, 'x': 2, 'y': 15, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 15},
         {'id': 236, 'hide': 1, 'x': 3, 'y': 8, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 16},
         {'id': 237, 'hide': 1, 'x': 3, 'y': 9, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 17},
         {'id': 238, 'hide': 1, 'x': 3, 'y': 10, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 18},
         {'id': 239, 'hide': 1, 'x': 3, 'y': 11, 'dir': 1, 'lv': 0, 'ai': 1, 'i': 19},
         {'id': 258, 'hide': 1, 'x': 26, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 20},
         {'id': 259, 'hide': 1, 'x': 26, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 21},
         {'id': 260, 'hide': 1, 'x': 26, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 22},
         {'id': 261, 'hide': 1, 'x': 27, 'y': 3, 'dir': 3, 'lv': 0, 'ai': 1, 'i': 23},
         {'id': 262, 'hide': 1, 'x': 22, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 24},
         {'id': 263, 'hide': 1, 'x': 23, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 25},
         {'id': 264, 'hide': 1, 'x': 24, 'y': 18, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 26},
         {'id': 265, 'hide': 1, 'x': 24, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'i': 27},
         {'id': 318, 'hide': 1, 'x': 23, 'y': 2, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 28},
         {'id': 319, 'hide': 1, 'x': 26, 'y': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 29},
         {'id': 320, 'hide': 1, 'x': 24, 'y': 6, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 30},
         {'id': 321, 'hide': 1, 'x': 26, 'y': 5, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 31},
         {'id': 322, 'hide': 1, 'x': 21, 'y': 18, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 32},
         {'id': 323, 'hide': 1, 'x': 22, 'y': 13, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 33},
         {'id': 324, 'hide': 1, 'x': 26, 'y': 12, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 34},
         {'id': 325, 'hide': 1, 'x': 26, 'y': 16, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 35},
         {'id': 282, 'hide': 1, 'x': 27, 'y': 1, 'dir': 3, 'lv': 0, 'ai': 1, 'targetId': 0, 'i': 36},
         {'id': 283, 'hide': 1, 'x': 27, 'y': 2, 'dir': 3, 'lv': 0, 'ai': 1, 'targetId': 0, 'i': 37},
         {'id': 284, 'hide': 1, 'x': 22, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 0, 'i': 38},
         {'id': 285, 'hide': 1, 'x': 23, 'y': 19, 'dir': 0, 'lv': 0, 'ai': 1, 'targetId': 0, 'i': 39},
         {'id': 326, 'hide': 1, 'x': 24, 'y': 0, 'lv': 0, 'ai': 3, 'targetId': 0, 'i': 40}]
    )
    stage.createMine([
        {
            'idx': 0,
            'x': 11,
            'y': 9,
            'dir': 3 },
        {
            'idx': 1,
            'x': 11,
            'y': 10,
            'dir': 3 },
        {
            'idx': 2,
            'x': 10,
            'y': 8,
            'dir': 3 },
        {
            'idx': 3,
            'x': 10,
            'y': 11,
            'dir': 3 },
        {
            'idx': 4,
            'x': 10,
            'y': 9,
            'dir': 3 },
        {
            'idx': 5,
            'x': 10,
            'y': 10,
            'dir': 3 },
        {
            'idx': 6,
            'x': 11,
            'y': 8,
            'dir': 3 },
        {
            'idx': 7,
            'x': 11,
            'y': 11,
            'dir': 3 },
        {
            'idx': 8,
            'dir': 0 },
        {
            'idx': 9,
            'dir': 0 },
        {
            'idx': 10,
            'dir': 0 },
        {
            'idx': 11,
            'dir': 0 },
        {
            'idx': 12,
            'dir': 0 },
        {
            'idx': 13,
            'dir': 0 },
        {
            'idx': 14,
            'dir': 0 }])
    stage.loadBg(12)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab21')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab21')
    stage.draw()
    stage.bgSound(1)
    stage.say('&143\n조의 군대는 3일 연속 시먼 ......을 공격했다.')
    stage.unit(23).setDir(stage.countDir(23, 143))
    stage.say('&23\n적은 아마도 동문 성벽이 이미 오래되고 손상된 것을 보았을 것이다,\n그래서 계획은 서쪽을 공격하면서 기만 움직이는 것입니다.\n&143\n그럼, 진짜 목표는...... 동문!?')
    stage.unit(143).setDir(1)
    stage.say('&23\n맞아요, 하지만 걱정 마세요.\n&23\n이제 조조 자신의 계획에 자부심을 느끼고 있다,\n이렇게 하면 우리의 계획을 간파하기 매우 어려울 것입니다.\n&23\n이것은 실제로 기회로 활용될 수 있습니다.\n이 일은 나에게 맡겨.')
    stage.unit(143).setDir(stage.countDir(143, 23))
    stage.say('&143\n정말?\n가후, 모든 것은 당신에게 달려 있습니다.')
    stage.bgSound(2)
    stage.setWinCondition('승리 조건\n1. 도시 내 모든 적군을 전멸시킨다.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('도시의 모든 적군을 전멸시켜라!')
    stage.startOper()
    vars[512] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[3] and not vars[2] and not vars[11] and stage.curCamp() == 2 and stage.round() >= 7:
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(262).show()
        stage.unit(263).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(285).show()
        stage.unit(0).setDir(stage.countDir(0, 258))
        stage.say('&0\n응? 류뱌오가 증원군을 보내고 있다고?\n이제 상황이 어려워졌어.')
        vars[11] = 1
    if vars[30] and not vars[2] and not vars[12] and stage.curCamp() == 0 and stage.round() >= 1:
        stage.unit(0).setDir(3)
        stage.unit(0).setDir(1)
        stage.say('&0\n이렇게 계속 끌면,\n류비아오의 증원군이 곧 도착할 예정이었다......\n잠시 쉬두로 돌아가야 할까요......?')
        sel = stage.choice('그리고 쉬두로 후퇴했다\n장수에 대한 캠페인', -1)
        if sel == 1:
            stage.unit(0).setDir(1)
            stage.unit(0).setAction(5)
            stage.say('&0\n퇴각! \n허도로 물러나라!')
            stage.unit(0).setAction(0)
            stage.unit(143).setAction(5)
            stage.say('&143\n놓치지 마!\n전면 군대 추격!')
            stage.unit(143).setAction(0)
            stage.setWinCondition('승리 조건\n1. 북동쪽 끝에 도달조조.\n2. 모든 것을 전멸시적군.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 도망쳐!')
            stage.heightLight(27, 1, 27, 4)
            vars[2] = 1
        elif sel == 2:
            stage.unit(0).setAction(6)
            stage.say('&0\n결과는 아직 알려지지 않았습니다!\n우리는 류표의 증원군이 도착할 때까지 기다려야 한다,\n이 도시를 점령하라!')
            stage.unit(0).setAction(0)
            stage.unit(143).setAI(0)
            stage.unit(23).setAI(0)
            stage.unit(210).setAI(0)
            stage.unit(211).setAI(0)
            vars[3] = 1
        vars[12] = 1
    if vars[2] and not vars[3] and not vars[13] and not vars[32] and stage.round() >= 10 and stage.curCamp() == 2:
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(262).show()
        stage.unit(263).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(285).show()
        stage.unit(0).setDir(stage.countDir(0, 258))
        stage.say('&0\n응? 류뱌오가 증원군을 보내고 있다고?\n이제 상황이 어려워졌어.')
        vars[13] = 1
    if not vars[20] and stage.isInPos(1025, 0, 10):
        stage.getItem(156, 0, True, 1025)
        vars[20] = 1
    if not vars[21] and stage.isInPos(1025, 1, 8):
        stage.getItem(150, 0, True, 1025)
        vars[21] = 1
    if not vars[22] and stage.isInPos(1025, 1, 11):
        stage.getItem(150, 0, True, 1025)
        vars[22] = 1
    if not vars[23] and stage.isInPos(1025, 4, 3):
        stage.getItem(150, 0, True, 1025)
        vars[23] = 1
    if not vars[24] and stage.isInPos(1025, 4, 16):
        stage.getItem(150, 0, True, 1025)
        vars[24] = 1
    if not vars[25] and stage.isInPos(1025, 0, 9):
        stage.getItem(151, 0, True, 1025)
        vars[25] = 1
    if not vars[2] and not vars[6] and stage.totalRectUnit(5, 0, 0, 6, 19) == 0:
        stage.resumeCtrl()
        stage.setRectUnitHide(0, 0, 27, 19, 5)
        stage.say('좋습니다. 동쪽 성지를 이미 통제했으니,\n이제는 서쪽 성지에서 침투하겠습니다!')
        stage.info('조조 완청 동문을 통제하고 있었다,\n계속 장수을 찾아보세요.')
        stage.info('그러다 긴급한 보고를 받았다,\n원소 쉬 두의 약한 방어를 탐욕스럽게 노려보고 있었다.\nThus조조 어쩔 수 없이 캠페인을 중단할 수밖에 없었다.')
        stage.reward(0, [
            160,
            -1])
        stage.end()
        vars[0] = 1
        vars[100] = 1
        vars[612] = 1
        return True
    if not vars[30] and not vars[31] and not vars[50] and not vars[51] and stage.round() >= 2 and stage.curCamp() == 2 and stage.isInRect(1025, 0, 0, 6, 19):
        stage.unit(216).show()
        stage.unit(217).show()
        stage.unit(218).show()
        stage.unit(219).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(236).show()
        stage.unit(237).show()
        stage.unit(238).show()
        stage.unit(239).show()
        stage.unit(212).setAI(1)
        stage.unit(213).setAI(1)
        stage.unit(214).setAI(1)
        stage.unit(215).setAI(1)
        stage.unit(234).setAI(1)
        stage.unit(235).setAI(1)
        stage.unit(143).setDir(stage.countDir(143, 0))
        stage.unit(23).setDir(stage.countDir(23, 0))
        stage.say('&143\n하하하, 조조 속았네요.\n우린 네 계략을 오래전에 간파했어!\n&23\n이 전략을 적을 유인하기 위해 썼다,\n나쁘지 않죠?')
        stage.unit(0).setDir(stage.countDir(0, 143))
        stage.say('&0\n음, 음!\n제 예상을 완전히 뛰어넘는 경험이었어요!')
        vars[30] = 1
    if vars[2] and not vars[13] and not vars[32] and stage.curCamp() == 2 and stage.isInRect(1025, 16, 0, 27, 19):
        stage.unit(318).show()
        stage.unit(319).show()
        stage.unit(320).show()
        stage.unit(321).show()
        stage.unit(322).show()
        stage.unit(323).show()
        stage.unit(324).show()
        stage.unit(325).show()
        stage.unit(326).show()
        stage.unit(0).setDir(stage.countDir(0, 318))
        stage.unit(0).setAction(10)
        stage.say('&0\n흠, 적의 매복인가요?\n이런 곳에서조차, 누가 상상이나 했겠어요,\n그는 또한 병력을 배치했다!')
        vars[32] = 1
    if vars[2] and vars[32] and not vars[33] and not vars[34] and stage.curCamp() == 2 and stage.totalRectUnit(0, 21, 12, 27, 19) == 0 and stage.isInRect(1025, 18, 0, 27, 7):
        stage.unit(262).show()
        stage.unit(263).show()
        stage.unit(264).show()
        stage.unit(265).show()
        stage.unit(284).show()
        stage.unit(285).show()
        stage.unit(0).setDir(stage.countDir(0, 262))
        stage.unit(0).setAction(2)
        stage.say('유표의 원군까지... 하필 이 시기에 도착하다니……!')
        vars[33] = 1
    if vars[2] and vars[32] and not vars[33] and not vars[34] and stage.curCamp() == 2 and stage.totalRectUnit(0, 21, 0, 27, 6) == 0 and stage.isInRect(1025, 20, 11, 27, 19):
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(261).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(0).setDir(stage.countDir(0, 258))
        stage.unit(0).setAction(4)
        stage.say('&0\n류비아오의 증원군도 도착했나?\n음음!')
        vars[34] = 1
    if vars[2] and not vars[35] and stage.isInRect(0, 27, 1, 27, 4):
        stage.resumeCtrl()
        stage.say('&0\n휴, 드디어 위험에서 벗어났네요.')
        vars[35] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[101] = 1
        vars[612] = 1
        return True
    if not vars[40] and stage.isNear(0, 143, True):
        stage.unit(0).setDir(stage.countDir(0, 143))
        stage.unit(143).setDir(stage.countDir(143, 0))
        stage.say('&0\n장수, 이번에는 반드시 목을 베겠다!\n&143\n무슨 헛소리를 하는 거야!\n어떻게 너한테 질 수 있겠어!')
        vars[40] = 1
    if not vars[41] and stage.isNear(0, 23, True):
        stage.unit(0).setDir(stage.countDir(0, 23))
        stage.unit(23).setDir(stage.countDir(23, 0))
        stage.say('&0\n내 계략을 간파한 자들,\n너가후 맞지?\n진정으로 가치 있는 적이었다.\n&23\n나는 항상 전략에 능숙가후,\n이렇게 작은 계획이라면 걱정할 필요 없어요.\n이렇게 칭찬할 필요 없어!\n&0\n말솜씨가 꽤 좋네요.\n&23\n하지만 내가 널 죽일 수 없다면,\n이 전략은 의미를 잃게 됩니다.\n죽을 준비해.\n&0\n그게 바로 내가 말하고 싶었던 거야.')
        vars[41] = 1
    if not vars[50] and stage.unitStateTest(143, 7, 0, 2):
        stage.say('&143\n흠, 먼저 후퇴하자!\n도시 서쪽에서 군대와 합류한다.')
        stage.unit(143).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(23, 7, 0, 2):
        stage.say('&23\n응, 잠시 도시 서쪽으로 후퇴하자!\n....... 버틸 수 있는 한만')
        stage.unit(23).hide(1)
        vars[51] = 1
    if not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('좋습니다. 동쪽 성지를 이미 통제했으니,\n이제는 서쪽 성지에서 침투하겠습니다!')
        stage.info('조조 완청 동문을 통제하고 있었다,\n계속 장수을 찾아보세요.')
        stage.info('하지만 곧 긴급한 보고를 받았다:\n원소 쉬 두의 약한 방어를 탐욕스럽게 노려보고 있었다.\nThus조조 어쩔 수 없이 캠페인을 중단할 수밖에 없었다.')
        if vars[3]:
            stage.reward(0, [
                160,
                -1])
        else:
            stage.reward()
        stage.end()
        vars[0] = 1
        vars[612] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 장수군에 패배했다.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
