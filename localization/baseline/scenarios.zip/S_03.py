# Source Generated with Decompyle++
# File: S_03.marshal (Python 3.9)


def scene0():
    stage.itemVars([
        20], [
        '(8,9)'])
    stage.nearEvent([
        0,
        132], 1)
    stage.initFight()
    stage.setGlobalData(20, -2, 132, 0, 2, 1)
    stage.createEnemy([
        {
            'id': 127,
            'x': 27,
            'y': 10,
            'dir': 3,
            'lv': 4,
            'ai': 0,
            'i': 0 },
        {
            'id': 210,
            'x': 27,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 1 },
        {
            'id': 211,
            'x': 27,
            'y': 11,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 2 },
        {
            'id': 132,
            'x': 26,
            'y': 10,
            'dir': 3,
            'lv': 4,
            'i': 3 },
        {
            'id': 212,
            'x': 25,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 4 },
        {
            'id': 213,
            'x': 25,
            'y': 10,
            'dir': 3,
            'lv': 0,
            'ai': 0,
            'i': 5 },
        {
            'id': 214,
            'x': 8,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'i': 6 },
        {
            'id': 215,
            'x': 8,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'i': 7 },
        {
            'id': 234,
            'x': 9,
            'y': 9,
            'dir': 3,
            'lv': 0,
            'i': 8 },
        {
            'id': 119,
            'hide': 1,
            'x': 22,
            'y': 8,
            'dir': 3,
            'lv': 6,
            'i': 9 },
        {
            'id': 258,
            'hide': 1,
            'x': 21,
            'y': 7,
            'dir': 3,
            'lv': 0,
            'i': 10 },
        {
            'id': 259,
            'hide': 1,
            'x': 21,
            'y': 12,
            'dir': 3,
            'lv': 0,
            'i': 11 },
        {
            'id': 260,
            'hide': 1,
            'x': 22,
            'y': 11,
            'dir': 3,
            'lv': 0,
            'i': 12 },
        {
            'id': 282,
            'hide': 1,
            'x': 23,
            'y': 8,
            'dir': 3,
            'lv': 0,
            'i': 13 },
        {
            'id': 283,
            'hide': 1,
            'x': 23,
            'y': 11,
            'dir': 3,
            'lv': 0,
            'i': 14 },
        {
            'id': 130,
            'hide': 1,
            'x': 4,
            'y': 13,
            'dir': 0,
            'lv': 4,
            'ai': 1,
            'i': 15 },
        {
            'id': 216,
            'hide': 1,
            'x': 3,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 16 },
        {
            'id': 217,
            'hide': 1,
            'x': 4,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 17 },
        {
            'id': 218,
            'hide': 1,
            'x': 5,
            'y': 12,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 18 },
        {
            'id': 235,
            'hide': 1,
            'x': 3,
            'y': 13,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 19 },
        {
            'id': 236,
            'hide': 1,
            'x': 5,
            'y': 13,
            'dir': 0,
            'lv': 0,
            'ai': 1,
            'i': 20 },
        {
            'id': 131,
            'hide': 1,
            'x': 14,
            'y': 5,
            'lv': 4,
            'ai': 1,
            'i': 21 },
        {
            'id': 219,
            'hide': 1,
            'x': 13,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 22 },
        {
            'id': 220,
            'hide': 1,
            'x': 14,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 23 },
        {
            'id': 221,
            'hide': 1,
            'x': 15,
            'y': 6,
            'lv': 0,
            'ai': 1,
            'i': 24 },
        {
            'id': 237,
            'hide': 1,
            'x': 13,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 25 },
        {
            'id': 238,
            'hide': 1,
            'x': 15,
            'y': 5,
            'lv': 0,
            'ai': 1,
            'i': 26 }])
    stage.createMine([
        {
            'idx': 0,
            'y': 6,
            'dir': 1 },
        {
            'idx': 1,
            'x': 1,
            'y': 5,
            'dir': 1 },
        {
            'idx': 2,
            'x': 1,
            'y': 8,
            'dir': 1 },
        {
            'idx': 3,
            'x': 1,
            'y': 6,
            'dir': 1 },
        {
            'idx': 4,
            'x': 1,
            'y': 7,
            'dir': 1 },
        {
            'idx': 5,
            'y': 5,
            'dir': 1 },
        {
            'idx': 6,
            'y': 8,
            'dir': 1 },
        {
            'idx': 7,
            'dir': 1 },
        {
            'idx': 8,
            'dir': 1 },
        {
            'idx': 9,
            'dir': 1 },
        {
            'idx': 10,
            'dir': 1 },
        {
            'idx': 11,
            'dir': 1 },
        {
            'idx': 12,
            'dir': 1 },
        {
            'idx': 13,
            'dir': 1 },
        {
            'idx': 14,
            'dir': 1 }])
    stage.setEnemyEquip(119, 38, 0, -1, 0, 16)
    stage.setEnemyEquip(130, -1, 0, -1, 0, 2)
    stage.loadBg(3)
    if vars[1013]:
        gvars[4076] = 0
        pvars[1] = 4882144
        gvars[10] = 0
        gvars[3] = 0
        gvars[4] = 0
        gvars[5] = 0
        label('lab25')
        if gvars[10] <= 120:
            if stage.varTest(1, 1, 2, 0, 1023):
                stage.varOper(2, 0, 2, 1, 1)
                if gvars[0] <= 169:
                    gvars[11] = stage.unitAttr(gvars[0], 16)
                    if gvars[11] != 1:
                        gvars[4076] = 0
                        gvars[1] = gvars[0]
                        gvars[2] = 5259072
                        gvars[1] *= 4
                        gvars[1] += gvars[2]
                        gvars[4076] = 1
                        pvars[0] = gvars[1]
                        stage.varOper(2, 3, 2, 1, 0)
                        stage.setUnitAttr(gvars[0], 17, gvars[3])
                        gvars[4] = 0
                        if gvars[3] >= 24 and gvars[3] <= 33:
                            gvars[4] = 1
                        if gvars[3] >= 65 and gvars[3] <= 66:
                            gvars[4] = 1
                        if gvars[3] == 69:
                            gvars[4] = 1
                        if gvars[3] == 74:
                            gvars[4] = 1
                        if gvars[3] == 0:
                            gvars[4] = 2
                        if gvars[3] == 57:
                            gvars[4] = 2
                        if gvars[3] == 67:
                            gvars[4] = 2
                        if gvars[3] == 71:
                            gvars[4] = 2
                        if gvars[3] == 79:
                            gvars[4] = 2
                        gvars[4076] = 0
                        gvars[6] = stage.unitAttr(gvars[0], 9)
                        gvars[7] = stage.unitAttr(gvars[0], 10)
                        gvars[8] = stage.unitAttr(gvars[0], 11)
                        gvars[9] = stage.unitAttr(gvars[0], 8)
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[9] -= gvars[20]
                        if gvars[4] == 0 and gvars[6] <= 34:
                            stage.setUnitAbility(gvars[0], 10, 0, 35)
                            stage.setUnitAbility(gvars[0], 11, 0, 35)
                        if gvars[4] == 1:
                            if gvars[8] <= 34:
                                stage.setUnitAbility(gvars[0], 12, 0, 35)
                            if gvars[9] <= 35:
                                stage.setUnitAbility(gvars[0], 6, 1, 30)
                                stage.setUnitAbility(gvars[0], 8, 1, 30)
                        if gvars[3] <= 59:
                            if gvars[20] >= 15:
                                gvars[3] += 1
                            if gvars[20] >= 30:
                                gvars[3] += 1
                        gvars[102] = gvars[3]
                        if 0 == 0:
                            gvars[4076] = 0
                            gvars[2] = 0
                            gvars[4081] = 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(0)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(1)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(2)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(3)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(4)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(5)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(6)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(7)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(8)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(9)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(10)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(11)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(12)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(13)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(14)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(15)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(16)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(17)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(18)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(19)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(20)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(21)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(22)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(23)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(24)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(25)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(26)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(27)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(28)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(29)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(30)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(31)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(32)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(33)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(34)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(35)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(36)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(37)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(38)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(39)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(40)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(41)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(42)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(43)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(44)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(45)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(46)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(47)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(48)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(49)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(50)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(51)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(52)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(53)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(54)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(55)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(56)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(57)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(58)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(59)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(60)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(61)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(62)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(63)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(64)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(65)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(66)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(67)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(68)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(69)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(70)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(71)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(72)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(73)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(74)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(75)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(76)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(77)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(78)
                            gvars[2] += 1
                            if gvars[102] == gvars[2]:
                                stage.unit(gvars[0]).setPosts(79)
                            gvars[4081] = 0
                        gvars[20] = stage.unitAttr(gvars[0], 18)
                        gvars[21] = stage.unitAttr(gvars[0], 20)
                        gvars[22] = stage.unitAttr(gvars[0], 23)
                        gvars[23] = 0
                        stage.setUnitAttr(gvars[0], 22, gvars[23])
                        stage.setUnitAttr(gvars[0], 25, gvars[23])
                        if gvars[21] < 30:
                            gvars[27] = gvars[21]
                            gvars[27] %= 3
                            if gvars[20] < 15:
                                if gvars[27] == 1:
                                    gvars[21] -= 1
                                if gvars[27] == 2:
                                    gvars[21] -= 2
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[27] == 0:
                                    gvars[21] += 1
                                if gvars[27] == 2:
                                    gvars[21] -= 1
                            if gvars[20] >= 30:
                                if gvars[27] == 0:
                                    gvars[21] += 2
                                if gvars[27] == 1:
                                    gvars[21] += 1
                            stage.setUnitAttr(gvars[0], 20, gvars[21])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 21, gvars[24])
                        if gvars[22] < 79:
                            gvars[28] = gvars[22]
                            gvars[28] %= 3
                            if gvars[20] < 15:
                                if gvars[28] == 0:
                                    gvars[22] -= 2
                                if gvars[28] == 2:
                                    gvars[22] -= 1
                            if gvars[20] >= 15 and gvars[20] < 30:
                                if gvars[28] == 0:
                                    gvars[22] -= 1
                                if gvars[28] == 1:
                                    gvars[22] += 1
                            if gvars[20] >= 30:
                                if gvars[28] == 1:
                                    gvars[22] += 2
                                if gvars[28] == 2:
                                    gvars[22] += 1
                            stage.setUnitAttr(gvars[0], 23, gvars[22])
                            if gvars[20] < 5:
                                gvars[24] = 1
                            if gvars[20] >= 5 and gvars[20] < 10:
                                gvars[24] = 2
                            if gvars[20] >= 10 and gvars[20] < 15:
                                gvars[24] = 3
                            if gvars[20] >= 15 and gvars[20] < 20:
                                gvars[24] = 1
                            if gvars[20] >= 20 and gvars[20] < 25:
                                gvars[24] = 2
                            if gvars[20] >= 25 and gvars[20] < 30:
                                gvars[24] = 3
                            if gvars[20] >= 30 and gvars[20] < 35:
                                gvars[24] = 1
                            if gvars[20] >= 35 and gvars[20] < 40:
                                gvars[24] = 2
                            if gvars[20] >= 40:
                                gvars[24] = 3
                            stage.setUnitAttr(gvars[0], 24, gvars[24])
            pvars[1] += 48
            gvars[10] += 1
            goto('lab25')
    stage.draw()
    stage.bgSound(4)
    stage.unit(0).setAction(5)
    stage.say('&0\n체이스! 놓치지 마동탁!')
    stage.unit(0).setAction(0)
    stage.unit(127).setDir(stage.countDir(127, 132))
    stage.unit(132).setDir(stage.countDir(132, 127))
    stage.say('&127\n흥, 이 사람들은 절대 멈추지 않아.\n리루, 네가 버티는 법을 찾아야 해!\n&132\n나, 리루는 막 그들을 만나려던 참이었어,\n반드시 이길 거야.\n&127\n아주 좋아요, 그럼 맡기겠습니다.\n&132\n그래! 모든 게 내 몫이야, 리루,\n주군assured 쉬고 장안으로 가라.')
    stage.unit(132).setDir(3)
    stage.setRectUnitHide(27, 9, 27, 11, 2)
    stage.setWinCondition('승리 조건\n1. 리루를 물리쳐라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
    stage.showWinCondition('리루를 물리쳐라!')
    stage.unit(132).heightLight()
    stage.startOper()
    vars[503] = 1
    stage.setMenuVisible(True)
    return False


def scene1():
    if vars[6] and not vars[11] and stage.round() >= 10 and stage.curCamp() == 2:
        stage.unit(119).setDir(stage.countDir(119, 132))
        stage.unit(132).setDir(stage.countDir(132, 119))
        stage.say('&119\n리루, 우리가 싸워서 빠져나갈 거야?\n&132\n지금이 적기인 것 같아; 동 총리는 이미 멀리 갔어,\n잠시 돌격하다가 후퇴하자.\n&119\n이번에는 조조 머리를 가져야 한다,\n리루, 넌 누가 빠져나간 사람들을 정리하러 온 거지.\n&132\n내게 맡겨.')
        stage.unit(119).setDir(3)
        stage.unit(132).setDir(3)
        stage.unit(119).setAction(6)
        stage.say('&119\n좋아, 전투 시작하자!')
        stage.unit(119).setAction(0)
        stage.unit(119).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        vars[11] = 1
    if vars[6] and not vars[2] and not vars[12] and stage.round() >= 11 and stage.totalUnit(0) < 6 and stage.totalUnit(2) >= 7:
        stage.say('&0\n아군 한계에 다다랐다!\n후퇴해야 할까요......?')
        sel = stage.choice('즉시 후퇴하라\n추격 계속해', -1)
        if sel == 1:
            stage.unit(0).setAction(4)
            stage.unit(0).setAction(6)
            stage.say('&0\n군대 전체를 후퇴시키고, 즉시 철수하라! (단 한 걸음만 남았다...\n동탁를 따라잡기 직전이야...\n정말 안타깝네요. )')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 서쪽 끝에 도착한다.\n2. 리루를 물리쳐라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 서쪽 끝으로 도망쳐!')
            stage.heightLight(0, 4, 0, 9)
            vars[2] = 1
            vars[11] = 1
            stage.say('&132\n도망치고 싶어? 헛되이 버둥거리지 마.\n장군님들, 제발 나가서 싸우십시오!\n이제 우리가 추격할 차례야.\n&119\n조조, 절대 그냥 넘어가지 않을 거야!')
            stage.unit(119).setAI(3, 0, 0, 0)
            stage.unit(130).setAI(3, 0, 0, 0)
            stage.unit(131).setAI(3, 0, 0, 0)
            stage.unit(258).setAI(3, 0, 0, 0)
            stage.unit(259).setAI(3, 0, 0, 0)
            stage.unit(260).setAI(3, 0, 0, 0)
            stage.unit(282).setAI(3, 0, 0, 0)
            stage.unit(283).setAI(3, 0, 0, 0)
            stage.unit(216).setAI(3, 0, 0, 0)
            stage.unit(217).setAI(3, 0, 0, 0)
            stage.unit(218).setAI(3, 0, 0, 0)
            stage.unit(219).setAI(3, 0, 0, 0)
            stage.unit(220).setAI(3, 0, 0, 0)
            stage.unit(221).setAI(3, 0, 0, 0)
            stage.unit(235).setAI(3, 0, 0, 0)
            stage.unit(236).setAI(3, 0, 0, 0)
            stage.unit(237).setAI(3, 0, 0, 0)
            stage.unit(238).setAI(3, 0, 0, 0)
        elif sel == 2:
            stage.unit(0).setDir(stage.countDir(0, 132))
            stage.say('&0\n이 시점에서 어떻게 그냥 후퇴할 수 있겠어!\n추격을 결정했기에 끝까지 버텨야 했다.')
        vars[12] = 1
    if not vars[20] and stage.isInPos(1025, 8, 9):
        stage.getItem(151, 0, True, 1025)
        if not vars[6]:
            stage.retreatConfirm()
            stage.unit(0).setDir(3)
            stage.unit(0).setDir(1)
            stage.unit(0).setAction(2)
            stage.say('이상하네요... 왜 적병만 이렇게 적은 거죠...?')
        vars[20] = 1
    if not vars[6] and stage.curCamp() == 2 and stage.totalRectUnit(0, 11, 0, 27, 19) >= 4:
        stage.unit(132).setAction(1)
        stage.say('&132\n하하하! 조조 너무 경험이 부족해요.\n내 전략 앞에서 그는 돼지처럼 멍청했다.\n&132\n장군님들, 노력만 하신다면,\n빨리 움직이면 조조 목을 베어버릴 수 있어!')
        stage.unit(131).show()
        stage.unit(219).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(237).show()
        stage.unit(238).show()
        stage.unit(131).setAction(7)
        stage.say('&131\n오늘은 육각별이 숲에 길조의 징조가 있다고 말합니다.\n맞는 것 같네요, 하하하!\n&131\n조조, 내 칼로 네 행운을 가져다 줘!\n전체 군대가 전진하라!')
        stage.unit(131).setAction(0)
        stage.unit(130).show()
        stage.unit(216).show()
        stage.unit(217).show()
        stage.unit(218).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(130).setAction(5)
        stage.say('&130\n흥, 리루의 계획은 좋지만,\n더 이상 숨고 싶지 않아요.\n내가 살인 광란을 벌이는 걸 지켜봐.')
        stage.unit(130).setAction(0)
        stage.unit(119).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(119).setAction(1)
        stage.say('&119\n조조, 전쟁의 기술상 혼자서 적진 깊숙이 진격하는 것은 금지되어 있습니다.\n신용을 위해 신용을 얻으려는 것은 결코 좋은 결과가 나오지 않습니다.\n이제 어디로 달려가는지 보자!')
        stage.unit(0).setDir(0)
        stage.unit(0).setDir(1)
        stage.unit(0).setDir(2)
        stage.unit(0).setDir(3)
        stage.say('&0\n아-아, 안 돼!\n뜻밖에도 적의 매복에 빠졌고...\n이제 양쪽에서 공격받고 있어......!')
        sel = stage.choice('즉시 후퇴하라\n추격 계속해', -1)
        if sel == 1:
            stage.unit(0).setAction(4)
            stage.unit(0).setAction(6)
            stage.say('&0\n군대 전체를 후퇴시켜라! 즉시 후퇴하라! (단 한 걸음만 남았다...\n동탁를 따라잡기 직전이야...\n정말 안타깝네요. )')
            stage.unit(0).setAction(0)
            stage.setWinCondition('승리 조건\n1. 조조 서쪽 끝에 도착한다.\n2. 리루를 물리쳐라.\n\n패배 조건\n1. 조조 죽음.\n2. 턴 수가 20명을 초과한다.')
            stage.showWinCondition('조조 서쪽 끝으로 도망쳐!')
            stage.heightLight(0, 4, 0, 9)
            vars[2] = 1
            vars[11] = 1
            stage.say('&132\n도망치고 싶어? 헛되이 버둥거리지 마.\n장군님들, 제발 나가서 싸우십시오!\n이제 우리가 추격할 차례야.\n&119\n조조, 절대 그냥 넘어가지 않을 거야!')
            stage.unit(119).setAI(3, 0, 0, 0)
            stage.unit(130).setAI(3, 0, 0, 0)
            stage.unit(131).setAI(3, 0, 0, 0)
            stage.unit(258).setAI(3, 0, 0, 0)
            stage.unit(259).setAI(3, 0, 0, 0)
            stage.unit(260).setAI(3, 0, 0, 0)
            stage.unit(282).setAI(3, 0, 0, 0)
            stage.unit(283).setAI(3, 0, 0, 0)
            stage.unit(216).setAI(3, 0, 0, 0)
            stage.unit(217).setAI(3, 0, 0, 0)
            stage.unit(218).setAI(3, 0, 0, 0)
            stage.unit(219).setAI(3, 0, 0, 0)
            stage.unit(220).setAI(3, 0, 0, 0)
            stage.unit(221).setAI(3, 0, 0, 0)
            stage.unit(235).setAI(3, 0, 0, 0)
            stage.unit(236).setAI(3, 0, 0, 0)
            stage.unit(237).setAI(3, 0, 0, 0)
            stage.unit(238).setAI(3, 0, 0, 0)
        elif sel == 2:
            stage.unit(0).setDir(stage.countDir(0, 132))
            stage.say('&0\n지금은 물러나기도 어렵네요...\n그렇다면 유일한 선택지는 리루를 공격하는 것이다.')
        vars[6] = 1
    if not vars[6] and not vars[30] and stage.isInRect(1025, 2, 11, 6, 14):
        stage.unit(130).show()
        stage.unit(216).show()
        stage.unit(217).show()
        stage.unit(218).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(130).setAction(10)
        stage.say('&130\n젠장, 아무리 애써도 도망칠 수가 없어......\n군대 전체가 전면적인 공격을 개시했다!\n&132\n네가 조조 있는 게 당연하지—내 계획을 간파했구나.\n그렇다면, 저는 싸울 수밖에 없습니다.')
        stage.unit(131).show()
        stage.unit(219).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(237).show()
        stage.unit(238).show()
        stage.unit(131).setAction(6)
        stage.say('&131\n젠장, 쉬롱, 이 녀석 운이 정말 안 좋아.\n결국 군대 전체가 전진하며 조조를 추격했다.')
        stage.unit(131).setAction(0)
        stage.unit(119).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.say('&119\n대단하네, 내 매복을 간파했구나.\n하지만 이길 수 없다면 떠날 생각조차 하지 마me여포.\n&0\n정말 매복이 있었......!\n이번 전투는 매우 치열할 것 같다.......')
        vars[6] = 1
        vars[30] = 1
    if not vars[6] and not vars[31] and stage.isInRect(1025, 12, 3, 16, 7):
        stage.unit(131).show()
        stage.unit(219).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(237).show()
        stage.unit(238).show()
        stage.unit(131).setAction(10)
        stage.say('&131\n어떻게? 발각됐어......?\n이번에는 점술이 정확하지 않아!\n좋아, 군대 전체가 공격을 개시했다!\n&132\n진정으로 조조 받을 자격이 있고, 내 계획을 꿰뚫어봤어,\n그렇다면, 저는 싸울 수밖에 없습니다.')
        stage.unit(130).show()
        stage.unit(216).show()
        stage.unit(217).show()
        stage.unit(218).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(130).setDir(stage.countDir(130, 0))
        stage.say('&130\n좋아, 드디어 공격할 수 있어!\n큰 전투를 할 거야, 죽이자!')
        stage.unit(119).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.say('&119\n조조, 오늘이 네 죽는 날이야!\n&0\n정말 매복이 있었......!\n이번 전투는 매우 치열할 것 같다.......')
        vars[6] = 1
        vars[31] = 1
    if not vars[6] and not vars[32] and stage.isInRect(1025, 18, 0, 27, 19) and stage.curCamp() == 2:
        stage.unit(132).setAction(1)
        stage.say('&132\n하하하! 조조 너무 경험이 부족해요.\n내 전략 앞에서 그는 돼지처럼 멍청했다.\n&132\n장군님들, 노력만 하신다면,\n빨리 움직이면 조조 목을 베어버릴 수 있어!')
        stage.unit(131).show()
        stage.unit(219).show()
        stage.unit(220).show()
        stage.unit(221).show()
        stage.unit(237).show()
        stage.unit(238).show()
        stage.unit(131).setAction(7)
        stage.say('&131\n오늘은 육각별이 숲에 길조의 징조가 있다고 말합니다.\n맞는 것 같네요, 하하하!\n&131\n조조, 내 칼로 네 행운을 가져다 줘!\n전체 군대가 전진하라!')
        stage.unit(131).setAction(0)
        stage.unit(130).show()
        stage.unit(216).show()
        stage.unit(217).show()
        stage.unit(218).show()
        stage.unit(235).show()
        stage.unit(236).show()
        stage.unit(130).setAction(5)
        stage.say('&130\n흥, 리루의 계획은 좋지만,\n더 이상 숨고 싶지 않아요.\n내가 살인 광란을 벌이는 걸 지켜봐.')
        stage.unit(130).setAction(0)
        stage.unit(119).show()
        stage.unit(258).show()
        stage.unit(259).show()
        stage.unit(260).show()
        stage.unit(282).show()
        stage.unit(283).show()
        stage.unit(119).setAction(1)
        stage.say('&119\n조조, 전쟁의 기술상 혼자서 적진 깊숙이 진격하는 것은 금지되어 있습니다.\n신용을 위해 신용을 얻으려는 것은 결코 좋은 결과가 나오지 않습니다.\n이제 어디로 달려가는지 보자!')
        vars[6] = 1
        vars[32] = 1
    if vars[6] and not vars[11] and not vars[33] and stage.curCamp() == 2 and stage.isInRect(1025, 18, 0, 27, 19):
        stage.unit(119).setAction(6)
        stage.say('&119\n우리도 싸워, 조조 박살내자!\n공격!')
        stage.unit(119).setAction(0)
        stage.unit(119).setAI(1)
        stage.unit(258).setAI(1)
        stage.unit(259).setAI(1)
        stage.unit(260).setAI(1)
        stage.unit(282).setAI(1)
        stage.unit(283).setAI(1)
        vars[11] = 1
        vars[33] = 1
    if vars[2] and not vars[34] and stage.isInRect(0, 0, 4, 0, 9):
        stage.resumeCtrl()
        stage.say('&0\n휴, 드디어 탈출했네요.')
        vars[34] = 1
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[100] = 1
        vars[603] = 1
        vars[703] = 1
        return True
    if not vars[35] and stage.isInRect(1025, 7, 0, 27, 19):
        stage.unit(234).setAI(0)
        vars[35] = 1
    if not vars[40] and stage.isNear(0, 132, True):
        stage.unit(0).setDir(stage.countDir(0, 132))
        stage.unit(132).setDir(stage.countDir(132, 0))
        stage.say('&0\n리루, 준비해!\n&132\n정말 놀라운 일이었다.\n하지만 우리는 이미 이 싸움에서 이겼습니다,\n다시는 동탁 총리님을 잡지 못할 거야.')
        vars[40] = 1
    if not vars[50] and stage.unitStateTest(119, 7, 0, 2):
        stage.say('&119\n나도 장안에 갈 거야.\n조조! 언젠가는 다시 만날 거야.')
        stage.unit(119).hide(1)
        vars[50] = 1
    if not vars[51] and stage.unitStateTest(130, 7, 0, 2):
        stage.say('&130\n좋지 않아... 음 음!')
        stage.unit(130).hide(2)
        stage.getItem(109, 0, True, 1027)
        vars[51] = 1
    if not vars[52] and stage.unitStateTest(131, 7, 0, 2):
        stage.say('&131\n아파! 젠장, 후퇴!\n다음번에는 챔파가 싸우기 전에 점술을 시전해야 할 거야!')
        stage.unit(131).hide(1)
        vars[52] = 1
    if not vars[53] and stage.unitStateTest(132, 7, 0, 2):
        stage.say('&132\n흠, 인상적이네요! 하지만 총리동탁 이미 멀리 나아갔어요,\n다시는 따라잡지 못할 거야.\n&132\n이곳은 오래 머무르기 좋은 곳이 아닌 것 같아.\n안타깝네요, 조조. 먼저 가야 해요!')
        stage.setRectUnitHide(0, 0, 27, 19, 2)
        vars[53] = 1
        stage.resumeCtrl()
        stage.info('조조 동탁를 이겼어!\n군대가 큰 피해를 입었However조조,\n그는 동탁을 쫓는 것을 포기할 수밖에 없었다.')
        stage.reward(0, [
            122,
            0])
        stage.end()
        vars[0] = 1
        vars[101] = 1
        vars[603] = 1
        return True
    if vars[100] and vars[101] and not vars[0] and stage.winTest():
        stage.resumeCtrl()
        stage.say('&0\n아주 좋아, 드디어 적을 전멸시켰어!\n이건 아군의 승리야!')
        stage.info('조조 동탁를 이겼어!\n군대가 큰 피해를 입었However조조,\n그는 동탁을 쫓는 것을 포기할 수밖에 없었다.')
        stage.reward()
        stage.end()
        vars[0] = 1
        vars[603] = 1
        return True
    if not vars[1] and stage.loseTest():
        stage.info('조조 동탁에게 졌어.')
        stage.end()
        stage.lose()
        vars[1] = 1
        return True


def scene2():
    stage.bgSound(-1)
    stage.setMenuVisible(False)
    return False

def __dispatch__():
    label('__dispatch_loop')
    idx = stage.sceneIndex()
    if idx == 1:
        finished = scene1()
        if not finished and not vars['1'] and stage.curCamp() == 2 and stage.round() >= stage.maxRound():
            stage.info('너무 긴 전투로 인해 게임이 패배했습니다!')
            stage.end()
            stage.lose()
            vars['1'] = True
            finished = True
        if not finished:
            return None
    elif idx == 0:
        scene0()
    elif idx == 2:
        if not stage.isLose():
            scene2()
        else:
            return None
    stage.incSceneIdx()
    goto('__dispatch_loop')
